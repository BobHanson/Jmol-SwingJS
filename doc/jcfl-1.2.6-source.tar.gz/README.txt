Java CML Server Library (JCFL) Project
======================================

All but one of the classes are distributed with the following 
license:

    Copyright (c) 2000 E.L. Willighagen (egonw@sci.kun.nl)

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License
    as published by the Free Software Foundation; either version 2
    of the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

The other class (FortranFormat.java) was written by Dan Gezelter. This
class is distributed with the following license:

    Copyright (c) 1998 J. Daniel Gezelter All Rights Reserved.

    J. Daniel Gezelter grants you ("Licensee") a non-exclusive, royalty
    free, license to use, modify and redistribute this software in
    source and binary code form, provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.

    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

    This software is provided "AS IS," without a warranty of any
    kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
    WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
    EXCLUDED.  J. DANIEL GEZELTER AND HIS LICENSORS SHALL NOT BE LIABLE
    FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
    MODIFYING OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO
    EVENT WILL J. DANIEL GEZELTER OR HIS LICENSORS BE LIABLE FOR ANY
    LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
    CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND
    REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR
    INABILITY TO USE SOFTWARE, EVEN IF J. DANIEL GEZELTER HAS BEEN
    ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

    This software is not designed or intended for use in on-line
    control of aircraft, air traffic, aircraft navigation or aircraft
    communications; or in the design, construction, operation or
    maintenance of any nuclear facility. Licensee represents and
    warrants that it will not use or redistribute the Software for such
    purposes.


More Information
================

See the website at: 
  
  http://openscience.chem.nd.edu/~egonw/cml/

The GNU License can be found at:

  http://www.gnu.org/copyleft/
