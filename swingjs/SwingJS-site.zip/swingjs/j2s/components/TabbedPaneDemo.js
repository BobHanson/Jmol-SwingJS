(function(){var P$=Clazz.newPackage("components"),I$=[['java.awt.GridLayout','javax.swing.JTabbedPane','java.awt.Dimension','javax.swing.JPanel','javax.swing.JLabel','javax.swing.ImageIcon','javax.swing.JFrame','javax.swing.SwingUtilities','javax.swing.UIManager','java.lang.Boolean','components.TabbedPaneDemo$1']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "TabbedPaneDemo", null, 'javax.swing.JPanel');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$$java_awt_LayoutManager.apply(this, [Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[1, 1])]);
C$.$init$.apply(this);
var tabbedPane = Clazz.new_((I$[2]||$incl$(2)));
var icon = C$.createImageIcon$S("images/middle.gif");
var panel1 = this.makeTextPanel$S("Panel #1");
tabbedPane.addTab$S$javax_swing_Icon$java_awt_Component$S("Tab 1", icon, panel1, "Does nothing");
tabbedPane.setMnemonicAt$I$I(0, 49);
var panel2 = this.makeTextPanel$S("Panel #2");
tabbedPane.addTab$S$javax_swing_Icon$java_awt_Component$S("This is Tab 2", icon, panel2, "Does twice as much nothing");
tabbedPane.setMnemonicAt$I$I(1, 50);
var panel3 = this.makeTextPanel$S("Panel #3");
tabbedPane.addTab$S$javax_swing_Icon$java_awt_Component$S("Tab 3", icon, panel3, "Still does nothing");
tabbedPane.setMnemonicAt$I$I(2, 51);
var panel3b = this.makeTextPanel$S("Panel #3");
tabbedPane.addTab$S$javax_swing_Icon$java_awt_Component$S("Tab 3b", icon, panel3b, "Still does nothing");
tabbedPane.setMnemonicAt$I$I(2, 51);
var panel3c = this.makeTextPanel$S("Panel #3");
tabbedPane.addTab$S$javax_swing_Icon$java_awt_Component$S("Tab 3", icon, panel3c, "Still does nothing");
tabbedPane.setMnemonicAt$I$I(2, 51);
var panel3d = this.makeTextPanel$S("Panel #3");
tabbedPane.addTab$S$javax_swing_Icon$java_awt_Component$S("Tab 3", icon, panel3d, "Still does nothing");
tabbedPane.setMnemonicAt$I$I(2, 51);
var panel3e = this.makeTextPanel$S("Panel #3");
tabbedPane.addTab$S$javax_swing_Icon$java_awt_Component$S("Tab 3", icon, panel3e, "Still does nothing");
tabbedPane.setMnemonicAt$I$I(2, 51);
var panel3f = this.makeTextPanel$S("Panel #3");
tabbedPane.addTab$S$javax_swing_Icon$java_awt_Component$S("Tab 3", icon, panel3f, "Still does nothing");
tabbedPane.setMnemonicAt$I$I(2, 51);
var panel4 = this.makeTextPanel$S("Panel #4 (has a preferred size of 410 x 50).");
panel4.setPreferredSize$java_awt_Dimension(Clazz.new_((I$[3]||$incl$(3)).c$$I$I,[410, 50]));
tabbedPane.addTab$S$javax_swing_Icon$java_awt_Component$S("Tab 4", icon, panel4, "Does nothing at all");
tabbedPane.setMnemonicAt$I$I(3, 52);
this.add$java_awt_Component(tabbedPane);
tabbedPane.setTabLayoutPolicy$I(0);
}, 1);

Clazz.newMeth(C$, 'makeTextPanel$S', function (text) {
var panel = Clazz.new_((I$[4]||$incl$(4)).c$$Z,[false]);
var filler = Clazz.new_((I$[5]||$incl$(5)).c$$S,[text]);
filler.setHorizontalAlignment$I(0);
panel.setLayout$java_awt_LayoutManager(Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[1, 1]));
panel.add$java_awt_Component(filler);
return panel;
});

Clazz.newMeth(C$, 'createImageIcon$S', function (path) {
var imgURL = Clazz.getClass(C$).getResource$S(path);
if (imgURL != null ) {
return Clazz.new_((I$[6]||$incl$(6)).c$$java_net_URL,[imgURL]);
} else {
System.err.println$S("Couldn't find file: " + path);
return null;
}}, 1);

Clazz.newMeth(C$, 'createAndShowGUI', function () {
var frame = Clazz.new_((I$[7]||$incl$(7)).c$$S,["TabbedPaneDemo"]);
frame.setDefaultCloseOperation$I(3);
frame.add$java_awt_Component$O(Clazz.new_(C$), "Center");
frame.pack();
frame.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$, 'main', function (args) {
(I$[8]||$incl$(8)).invokeLater$Runnable(((
(function(){var C$=Clazz.newClass(P$, "TabbedPaneDemo$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'run', function () {
(I$[9]||$incl$(9)).put$O$O("swing.boldMetal", (I$[10]||$incl$(10)).FALSE);
P$.TabbedPaneDemo.createAndShowGUI();
});
})()
), Clazz.new_((I$[11]||$incl$(11)).$init$, [this, null])));
}, 1);
})();
//Created 2018-07-24 16:18:04 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
