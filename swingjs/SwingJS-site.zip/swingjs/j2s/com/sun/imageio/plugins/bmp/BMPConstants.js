(function(){var P$=Clazz.newPackage("com.sun.imageio.plugins.bmp"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "BMPConstants");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-08-23 10:05:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
