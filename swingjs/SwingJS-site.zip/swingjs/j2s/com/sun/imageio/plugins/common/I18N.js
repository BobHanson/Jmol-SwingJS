(function(){var P$=Clazz.newPackage("com.sun.imageio.plugins.common"),I$=[[0,'com.sun.imageio.plugins.common.I18NImpl']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "I18N", null, 'com.sun.imageio.plugins.common.I18NImpl');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getString$S',  function (key) {
return $I$(1).getString$S$S$S("com.sun.imageio.plugins.common.I18N", "iio-plugin.properties", key);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v4');//Created 2022-03-19 05:24:43 Java2ScriptVisitor version 3.3.1-v4 net.sf.j2s.core.jar version 3.3.1-v4
