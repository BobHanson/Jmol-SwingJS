(function(){var P$=Clazz.newPackage("com.sun.imageio.plugins.png"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "PNGImageWriteParam", null, 'javax.imageio.ImageWriteParam');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$java_util_Locale',  function (locale) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
this.canWriteProgressive=true;
this.locale=locale;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-11-28 16:08:39 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
