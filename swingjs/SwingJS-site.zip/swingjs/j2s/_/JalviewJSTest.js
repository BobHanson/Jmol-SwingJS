(function(){var P$=Clazz.newPackage("_"),I$=[[0,'test.JalviewJSTest','javax.swing.JFrame','javax.swing.JPanel','java.awt.Dimension','java.awt.BorderLayout','java.awt.GridLayout','javax.swing.border.TitledBorder','javax.swing.JCheckBox','java.awt.Font','javax.swing.ImageIcon','java.awt.ComponentOrientation','javax.swing.JRadioButton']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "JalviewJSTest", null, 'javax.swing.JPanel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'main$SA', function (args) {
Clazz.new_(Clazz.load('test.JalviewJSTest')).doTest$();
}, 1);

Clazz.newMeth(C$, 'doTest$', function () {
var main=Clazz.new_(Clazz.load('javax.swing.JFrame'));
main.setContentPane$java_awt_Container(this.getVisualPaneContent$());
main.pack$();
main.setVisible$Z(true);
});

Clazz.newMeth(C$, 'getVisualPaneContent$', function () {
var panel=Clazz.new_(Clazz.load('javax.swing.JPanel'));
panel.setPreferredSize$java_awt_Dimension(Clazz.new_(Clazz.load('java.awt.Dimension').c$$I$I,[400, 500]));
panel.setOpaque$Z(true);
panel.setLayout$java_awt_LayoutManager(Clazz.new_(Clazz.load('java.awt.BorderLayout')));
var firstColumn=Clazz.new_($I$(3));
firstColumn.setLayout$java_awt_LayoutManager(Clazz.new_(Clazz.load('java.awt.GridLayout').c$$I$I,[8, 1]));
firstColumn.setBorder$javax_swing_border_Border(Clazz.new_(Clazz.load('javax.swing.border.TitledBorder').c$$S,["column 1"]));
var cb1=Clazz.new_(Clazz.load('javax.swing.JCheckBox'));
var font=Clazz.new_(Clazz.load('java.awt.Font').c$$S$I$I,["Verdana", 0, 11]);
cb1.setFont$java_awt_Font(font);
cb1.setText$S("Maximise Window");
cb1.setHorizontalTextPosition$I(10);
cb1.setHorizontalAlignment$I(2);
var cb2=Clazz.new_($I$(8).c$$S,["Open Overview"]);
cb2.setFont$java_awt_Font(font);
cb2.setHorizontalTextPosition$I(10);
var icon=Clazz.new_(Clazz.load('javax.swing.ImageIcon').c$$java_net_URL$S,[this.getClass$().getClassLoader$().getResource$S("test2.png"), "test"]);
var cb3=Clazz.new_($I$(8).c$$S$javax_swing_Icon,["leading,left-to-right", icon]);
cb3.setFont$java_awt_Font(font);
cb3.setComponentOrientation$java_awt_ComponentOrientation(Clazz.load('java.awt.ComponentOrientation').LEFT_TO_RIGHT);
cb3.setHorizontalTextPosition$I(10);
var cb4=Clazz.new_($I$(8).c$$S,["leading,right-to-left"]);
cb4.setFont$java_awt_Font(font);
cb4.setIcon$javax_swing_Icon(icon);
cb4.setComponentOrientation$java_awt_ComponentOrientation($I$(11).RIGHT_TO_LEFT);
cb4.setHorizontalTextPosition$I(10);
var cb5=Clazz.new_($I$(8).c$$S,["trailing,left-to-right"]);
cb5.setFont$java_awt_Font(font);
cb5.setIcon$javax_swing_Icon(icon);
cb5.setComponentOrientation$java_awt_ComponentOrientation($I$(11).LEFT_TO_RIGHT);
cb5.setHorizontalTextPosition$I(11);
var cb6=Clazz.new_($I$(8).c$$S,["trailing,right-to-left"]);
cb6.setFont$java_awt_Font(font);
cb6.setIcon$javax_swing_Icon(icon);
cb6.setComponentOrientation$java_awt_ComponentOrientation($I$(11).RIGHT_TO_LEFT);
cb6.setHorizontalTextPosition$I(11);
var rb1=Clazz.new_(Clazz.load('javax.swing.JRadioButton').c$$S,["trailing,right-to-left"]);
rb1.setFont$java_awt_Font(font);
rb1.setIcon$javax_swing_Icon(icon);
rb1.setComponentOrientation$java_awt_ComponentOrientation($I$(11).RIGHT_TO_LEFT);
rb1.setHorizontalTextPosition$I(11);
firstColumn.add$java_awt_Component(cb1);
firstColumn.add$java_awt_Component(cb2);
firstColumn.add$java_awt_Component(cb3);
firstColumn.add$java_awt_Component(cb4);
firstColumn.add$java_awt_Component(cb5);
firstColumn.add$java_awt_Component(cb6);
firstColumn.add$java_awt_Component(rb1);
firstColumn.setBounds$I$I$I$I(20, 20, 200, 400);
var theTab=Clazz.new_($I$(3));
theTab.setLayout$java_awt_LayoutManager(null);
theTab.add$java_awt_Component(firstColumn);
panel.add$java_awt_Component(theTab);
return panel;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-21 10:21:14 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
