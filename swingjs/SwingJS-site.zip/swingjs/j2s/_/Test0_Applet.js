(function(){var P$=Clazz.newPackage("_"),I$=[];
var C$=Clazz.newClass(P$, "Test0_Applet", null, 'javax.swing.JApplet');
C$.staticVar=null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.staticVar="staticVar";
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['init$','init'], function () {
System.out.println$S("Hello from Test0_Applet");
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.07');//Created 2018-09-23 23:47:29 Java2ScriptVisitor version 3.2.2.07 net.sf.j2s.core.jar version 3.2.2.07
