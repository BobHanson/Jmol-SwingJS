(function(){var P$=Clazz.newPackage("a2s"),I$=[];
var C$=Clazz.newClass(P$, "Util");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'drawString$java_awt_Graphics$S$I$I', function (g, text, x, y) {
g.drawString$S$I$I(text, x, y);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.07');//Created 2018-09-23 15:17:33 Java2ScriptVisitor version 3.2.2.07 net.sf.j2s.core.jar version 3.2.2.07
