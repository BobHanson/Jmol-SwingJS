(function(){var P$=Clazz.newPackage("a2s"),p$1={},I$=[[0,'a2s.A2SListener','java.net.URL']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Applet", null, 'javax.swing.JApplet', 'a2s.A2SContainer');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.listener=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
p$1.fixAppletPaint.apply(this, []);
this.listener=Clazz.new_(Clazz.load('a2s.A2SListener'));
this.addMouseListener$java_awt_event_MouseListener(this.listener);
this.addMouseMotionListener$java_awt_event_MouseMotionListener(this.listener);
}, 1);

Clazz.newMeth(C$, ['setBackground$java_awt_Color','setBackground'], function (c) {
C$.superclazz.prototype.setBackground$java_awt_Color.apply(this, [c]);
this.getContentPane$().setBackground$java_awt_Color(c);
});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
});

Clazz.newMeth(C$, 'fixAppletPaint', function () {

try{ if (this.paint$java_awt_Graphics.exClazz != C$ && this.paint$java_awt_Graphics.toString().indexOf("C$.superclazz.prototype.paint$java_awt_Graphics.apply(this") < 0) { var oldPaint = this.paint$java_awt_Graphics;
this.paint$java_awt_Graphics = function(g) { C$.prototype.paint$java_awt_Graphics.apply(this,[g]);
oldPaint.apply(this,[g]);
};
} } catch(e) { System.out.println("a2s.Applet.fixAppletPaint() exception: " + e);
}
}, p$1);

Clazz.newMeth(C$, ['getA2SListener$','getA2SListener'], function () {
return this.listener;
});

Clazz.newMeth(C$, ['getCodeBase$','getCodeBase'], function () {
var codeBase=C$.superclazz.prototype.getCodeBase$.apply(this, []).toString();
if (codeBase.endsWith$S("/bin/")) {
var appletPath=this.getClass$().getName$();
codeBase += appletPath.substring$I$I(0, appletPath.lastIndexOf$S(".") + 1).replace$C$C(".", "/");
}try {
return Clazz.new_(Clazz.load('java.net.URL').c$$S,[codeBase]);
} catch (e) {
if (Clazz.exceptionOf(e,"java.net.MalformedURLException")){
return null;
} else {
throw e;
}
}
});
})();
;Clazz.setTVer('3.2.2.07');//Created 2018-09-23 23:47:30 Java2ScriptVisitor version 3.2.2.07 net.sf.j2s.core.jar version 3.2.2.07
