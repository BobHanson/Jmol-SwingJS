(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(P$, "Comparable");
})();
;Clazz.setTVer('3.2.2.07');//Created 2018-09-23 15:17:56 Java2ScriptVisitor version 3.2.2.07 net.sf.j2s.core.jar version 3.2.2.07
