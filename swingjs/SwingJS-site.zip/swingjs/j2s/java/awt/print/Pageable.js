(function(){var P$=Clazz.newPackage("java.awt.print"),I$=[];
var C$=Clazz.newInterface(P$, "Pageable");
C$.UNKNOWN_NUMBER_OF_PAGES=0;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.UNKNOWN_NUMBER_OF_PAGES=-1;
}
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-22 06:54:48 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
