(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "MimeTypeParseException", null, 'Exception');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S',  function (s) {
;C$.superclazz.c$$S.apply(this,[s]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-11-28 16:08:56 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
