(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newClass(P$, "MenuItem", null, 'a2s.MenuItem');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$S$java_awt_MenuShortcut.apply(this, ["", null]);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (label) {
C$.c$$S$java_awt_MenuShortcut.apply(this, [label, null]);
}, 1);

Clazz.newMeth(C$, 'c$$S$java_awt_MenuShortcut', function (label, s) {
C$.superclazz.c$$S.apply(this, [label]);
C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.2.2.07');//Created 2018-09-23 15:17:43 Java2ScriptVisitor version 3.2.2.07 net.sf.j2s.core.jar version 3.2.2.07
