(function(){var P$=Clazz.newPackage("java.awt.geom"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "GeneralPath", null, ['java.awt.geom.Path2D','.Float']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$I$I.apply(this,[1, 20]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I',  function (rule) {
;C$.superclazz.c$$I$I.apply(this,[rule, 20]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I',  function (rule, initialCapacity) {
;C$.superclazz.c$$I$I.apply(this,[rule, initialCapacity]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Shape',  function (s) {
;C$.superclazz.c$$java_awt_Shape$java_awt_geom_AffineTransform.apply(this,[s, null]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$BA$I$FA$I',  function (windingRule, pointTypes, numTypes, pointCoords, numCoords) {
Clazz.super_(C$, this);
this.windingRule=windingRule;
this.pointTypes=pointTypes;
this.numTypes=numTypes;
this.floatCoords=pointCoords;
this.numCoords=numCoords;
}, 1);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-02-18 18:08:00 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
