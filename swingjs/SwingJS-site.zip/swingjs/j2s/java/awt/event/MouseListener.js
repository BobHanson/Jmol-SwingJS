(function(){var P$=Clazz.newPackage("java.awt.event"),I$=[];
var C$=Clazz.newInterface(P$, "MouseListener", null, null, 'java.util.EventListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
;Clazz.setTVer('3.2.4.09');//Created 2019-10-27 12:18:33 Java2ScriptVisitor version 3.2.4.09 net.sf.j2s.core.jar version 3.2.4.09
