(function(){var P$=Clazz.newPackage("java.awt.font"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "MultipleMaster");
})();
;Clazz.setTVer('3.2.7-v1');//Created 2020-01-08 10:33:32 Java2ScriptVisitor version 3.2.7-v1 net.sf.j2s.core.jar version 3.2.7-v1
