(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "FontFormatException", null, 'Exception');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$S', function (reason) {
;C$.superclazz.c$$S.apply(this,[reason]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.7-v1');//Created 2020-01-08 10:33:26 Java2ScriptVisitor version 3.2.7-v1 net.sf.j2s.core.jar version 3.2.7-v1
