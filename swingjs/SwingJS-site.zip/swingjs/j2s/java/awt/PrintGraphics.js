(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "PrintGraphics");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-08-23 10:05:40 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
