(function(){var P$=Clazz.newPackage("java.awt.im"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "InputMethodRequests");
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-11-28 16:09:00 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
