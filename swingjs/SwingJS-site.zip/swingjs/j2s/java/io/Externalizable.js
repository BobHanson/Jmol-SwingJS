(function(){var P$=java.io,I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Externalizable", null, null, 'java.io.Serializable');

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-08-23 10:05:49 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
