(function(){var P$=java.io,I$=[[0,'java.io.FileInputStream']],$I$=function(i,n){return(i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i};
/*c*/var C$=Clazz.newClass(P$, "FileReader", null, 'java.io.InputStreamReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$S', function (fileName) {
;C$.superclazz.c$$java_io_InputStream.apply(this,[Clazz.new_($I$(1,1).c$$S,[fileName])]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_io_File', function (file) {
;C$.superclazz.c$$java_io_InputStream.apply(this,[Clazz.new_($I$(1,1).c$$java_io_File,[file])]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_io_FileDescriptor', function (fd) {
;C$.superclazz.c$$java_io_InputStream.apply(this,[Clazz.new_($I$(1,1).c$$java_io_FileDescriptor,[fd])]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.7-v1');//Created 2020-01-08 10:33:37 Java2ScriptVisitor version 3.2.7-v1 net.sf.j2s.core.jar version 3.2.7-v1
