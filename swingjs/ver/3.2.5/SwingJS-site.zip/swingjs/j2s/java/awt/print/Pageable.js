(function(){var P$=Clazz.newPackage("java.awt.print"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Pageable");
C$.UNKNOWN_NUMBER_OF_PAGES=0;

C$.$static$ = function() {C$.$static$=0;
C$.UNKNOWN_NUMBER_OF_PAGES=-1;
}
})();
;Clazz.setTVer('3.2.5-v1');//Created 2019-11-27 14:06:31 Java2ScriptVisitor version 3.2.5-v1 net.sf.j2s.core.jar version 3.2.5-v1
