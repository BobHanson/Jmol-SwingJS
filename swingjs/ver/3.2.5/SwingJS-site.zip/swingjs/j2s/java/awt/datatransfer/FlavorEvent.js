(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "FlavorEvent", null, 'java.util.EventObject');

C$.$clinit$=1;

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_datatransfer_Clipboard', function (source) {
;C$.superclazz.c$$O.apply(this, [source]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.5-v1');//Created 2019-11-27 14:06:24 Java2ScriptVisitor version 3.2.5-v1 net.sf.j2s.core.jar version 3.2.5-v1
