(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "RenderedImage");
})();
;Clazz.setTVer('3.2.5-v1');//Created 2019-11-27 14:06:30 Java2ScriptVisitor version 3.2.5-v1 net.sf.j2s.core.jar version 3.2.5-v1
