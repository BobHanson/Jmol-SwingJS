(function(){var P$=java.lang,I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Runnable");
})();
;Clazz.setTVer('3.2.5-v1');//Created 2019-11-27 14:06:38 Java2ScriptVisitor version 3.2.5-v1 net.sf.j2s.core.jar version 3.2.5-v1
