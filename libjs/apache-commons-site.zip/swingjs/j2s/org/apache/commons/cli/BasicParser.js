(function(){var P$=Clazz.newPackage("org.apache.commons.cli"),I$=[];
var C$=Clazz.newClass(P$, "BasicParser", null, 'org.apache.commons.cli.Parser');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'flatten$org_apache_commons_cli_Options$SA$Z', function (options, $arguments, stopAtNonOption) {
return $arguments;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-20 09:28:10 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
