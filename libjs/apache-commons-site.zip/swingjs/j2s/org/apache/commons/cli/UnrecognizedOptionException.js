(function(){var P$=Clazz.newPackage("org.apache.commons.cli"),I$=[];
var C$=Clazz.newClass(P$, "UnrecognizedOptionException", null, 'org.apache.commons.cli.ParseException');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.option=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (message) {
C$.superclazz.c$$S.apply(this, [message]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$S', function (message, option) {
C$.c$$S.apply(this, [message]);
this.option=option;
}, 1);

Clazz.newMeth(C$, 'getOption$', function () {
return this.option;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-20 09:28:11 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
