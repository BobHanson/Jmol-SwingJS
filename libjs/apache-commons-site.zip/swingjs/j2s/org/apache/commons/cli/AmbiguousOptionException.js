(function(){var P$=Clazz.newPackage("org.apache.commons.cli"),I$=[];
var C$=Clazz.newClass(P$, "AmbiguousOptionException", null, 'org.apache.commons.cli.UnrecognizedOptionException');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.matchingOptions=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S$java_util_Collection', function (option, matchingOptions) {
C$.superclazz.c$$S$S.apply(this, [C$.createMessage$S$java_util_Collection(option, matchingOptions), option]);
C$.$init$.apply(this);
this.matchingOptions=matchingOptions;
}, 1);

Clazz.newMeth(C$, 'getMatchingOptions$', function () {
return this.matchingOptions;
});

Clazz.newMeth(C$, 'createMessage$S$java_util_Collection', function (option, matchingOptions) {
var buf=Clazz.new_(Clazz.load('StringBuilder').c$$S,["Ambiguous option: \'"]);
buf.append$S(option);
buf.append$S("\'  (could be: ");
var it=matchingOptions.iterator$();
while (it.hasNext$()){
buf.append$S("\'");
buf.append$S(it.next$());
buf.append$S("\'");
if (it.hasNext$()) {
buf.append$S(", ");
}}
buf.append$S(")");
return buf.toString();
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-20 09:28:10 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
