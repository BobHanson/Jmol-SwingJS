(function(){var P$=Clazz.newPackage("org.apache.commons.cli"),I$=[[0,'java.util.LinkedHashMap','StringBuilder']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "OptionGroup", null, null, 'java.io.Serializable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.optionMap=null;
this.selected=null;
this.required=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.optionMap=Clazz.new_(Clazz.load('java.util.LinkedHashMap'));
}, 1);

Clazz.newMeth(C$, 'addOption$org_apache_commons_cli_Option', function (option) {
this.optionMap.put$TK$TV(option.getKey$(), option);
return this;
});

Clazz.newMeth(C$, 'getNames$', function () {
return this.optionMap.keySet$();
});

Clazz.newMeth(C$, 'getOptions$', function () {
return this.optionMap.values$();
});

Clazz.newMeth(C$, 'setSelected$org_apache_commons_cli_Option', function (option) {
if (option == null ) {
this.selected=null;
return;
}if (this.selected == null  || this.selected.equals$O(option.getKey$()) ) {
this.selected=option.getKey$();
} else {
throw Clazz.new_(Clazz.load('org.apache.commons.cli.AlreadySelectedException').c$$org_apache_commons_cli_OptionGroup$org_apache_commons_cli_Option,[this, option]);
}});

Clazz.newMeth(C$, 'getSelected$', function () {
return this.selected;
});

Clazz.newMeth(C$, 'setRequired$Z', function (required) {
this.required=required;
});

Clazz.newMeth(C$, 'isRequired$', function () {
return this.required;
});

Clazz.newMeth(C$, 'toString', function () {
var buff=Clazz.new_(Clazz.load('StringBuilder'));
var iter=this.getOptions$().iterator$();
buff.append$S("[");
while (iter.hasNext$()){
var option=iter.next$();
if (option.getOpt$() != null ) {
buff.append$S("-");
buff.append$S(option.getOpt$());
} else {
buff.append$S("--");
buff.append$S(option.getLongOpt$());
}if (option.getDescription$() != null ) {
buff.append$S(" ");
buff.append$S(option.getDescription$());
}if (iter.hasNext$()) {
buff.append$S(", ");
}}
buff.append$S("]");
return buff.toString();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-20 09:28:10 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
