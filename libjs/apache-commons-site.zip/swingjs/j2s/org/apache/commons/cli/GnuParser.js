(function(){var P$=Clazz.newPackage("org.apache.commons.cli"),I$=[];
var C$=Clazz.newClass(P$, "GnuParser", null, 'org.apache.commons.cli.Parser');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'flatten$org_apache_commons_cli_Options$SA$Z', function (options, $arguments, stopAtNonOption) {
var tokens=Clazz.new_(Clazz.load('java.util.ArrayList'));
var eatTheRest=false;
for (var i=0; i < $arguments.length; i++) {
var arg=$arguments[i];
if ("--".equals$O(arg)) {
eatTheRest=true;
tokens.add$TE("--");
} else if ("-".equals$O(arg)) {
tokens.add$TE("-");
} else if (arg.startsWith$S("-")) {
var opt=Clazz.load('org.apache.commons.cli.Util').stripLeadingHyphens$S(arg);
if (options.hasOption$S(opt)) {
tokens.add$TE(arg);
} else {
if (opt.indexOf$I("=") != -1 && options.hasOption$S(opt.substring$I$I(0, opt.indexOf$I("="))) ) {
tokens.add$TE(arg.substring$I$I(0, arg.indexOf$I("=")));
tokens.add$TE(arg.substring$I(arg.indexOf$I("=") + 1));
} else if (options.hasOption$S(arg.substring$I$I(0, 2))) {
tokens.add$TE(arg.substring$I$I(0, 2));
tokens.add$TE(arg.substring$I(2));
} else {
eatTheRest=stopAtNonOption;
tokens.add$TE(arg);
}}} else {
tokens.add$TE(arg);
}if (eatTheRest) {
for (i++; i < $arguments.length; i++) {
tokens.add$TE($arguments[i]);
}
}}
return tokens.toArray$TTA(Clazz.array(String, [tokens.size$()]));
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-20 09:28:10 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
