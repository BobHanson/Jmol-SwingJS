(function(){var P$=Clazz.newPackage("org.apache.commons.cli"),p$1={},I$=[[0,'java.util.ArrayList','java.util.Arrays']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "PosixParser", null, 'org.apache.commons.cli.Parser');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.tokens=null;
this.eatTheRest=false;
this.currentOption=null;
this.$options=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.tokens=Clazz.new_(Clazz.load('java.util.ArrayList'));
}, 1);

Clazz.newMeth(C$, 'init', function () {
this.eatTheRest=false;
this.tokens.clear$();
}, p$1);

Clazz.newMeth(C$, 'flatten$org_apache_commons_cli_Options$SA$Z', function (options, $arguments, stopAtNonOption) {
p$1.init.apply(this, []);
this.$options=options;
var iter=Clazz.load('java.util.Arrays').asList$TTA($arguments).iterator$();
while (iter.hasNext$()){
var token=iter.next$();
if ("-".equals$O(token) || "--".equals$O(token) ) {
this.tokens.add$TE(token);
} else if (token.startsWith$S("--")) {
var pos=token.indexOf$I("=");
var opt=pos == -1 ? token : token.substring$I$I(0, pos);
var matchingOpts=options.getMatchingOptions$S(opt);
if (matchingOpts.isEmpty$()) {
p$1.processNonOptionToken$S$Z.apply(this, [token, stopAtNonOption]);
} else if (matchingOpts.size$() > 1) {
throw Clazz.new_(Clazz.load('org.apache.commons.cli.AmbiguousOptionException').c$$S$java_util_Collection,[opt, matchingOpts]);
} else {
this.currentOption=options.getOption$S(matchingOpts.get$I(0));
this.tokens.add$TE("--" + this.currentOption.getLongOpt$());
if (pos != -1) {
this.tokens.add$TE(token.substring$I(pos + 1));
}}} else if (token.startsWith$S("-")) {
if (token.length$() == 2 || options.hasOption$S(token) ) {
p$1.processOptionToken$S$Z.apply(this, [token, stopAtNonOption]);
} else if (!options.getMatchingOptions$S(token).isEmpty$()) {
var matchingOpts=options.getMatchingOptions$S(token);
if (matchingOpts.size$() > 1) {
throw Clazz.new_(Clazz.load('org.apache.commons.cli.AmbiguousOptionException').c$$S$java_util_Collection,[token, matchingOpts]);
}var opt=options.getOption$S(matchingOpts.get$I(0));
p$1.processOptionToken$S$Z.apply(this, ["-" + opt.getLongOpt$(), stopAtNonOption]);
} else {
this.burstToken$S$Z(token, stopAtNonOption);
}} else {
p$1.processNonOptionToken$S$Z.apply(this, [token, stopAtNonOption]);
}p$1.gobble$java_util_Iterator.apply(this, [iter]);
}
return this.tokens.toArray$TTA(Clazz.array(String, [this.tokens.size$()]));
});

Clazz.newMeth(C$, 'gobble$java_util_Iterator', function (iter) {
if (this.eatTheRest) {
while (iter.hasNext$()){
this.tokens.add$TE(iter.next$());
}
}}, p$1);

Clazz.newMeth(C$, 'processNonOptionToken$S$Z', function (value, stopAtNonOption) {
if (stopAtNonOption && (this.currentOption == null  || !this.currentOption.hasArg$() ) ) {
this.eatTheRest=true;
this.tokens.add$TE("--");
}this.tokens.add$TE(value);
}, p$1);

Clazz.newMeth(C$, 'processOptionToken$S$Z', function (token, stopAtNonOption) {
if (stopAtNonOption && !this.$options.hasOption$S(token) ) {
this.eatTheRest=true;
}if (this.$options.hasOption$S(token)) {
this.currentOption=this.$options.getOption$S(token);
}this.tokens.add$TE(token);
}, p$1);

Clazz.newMeth(C$, 'burstToken$S$Z', function (token, stopAtNonOption) {
for (var i=1; i < token.length$(); i++) {
var ch=String.valueOf$C(token.charAt$I(i));
if (this.$options.hasOption$S(ch)) {
this.tokens.add$TE("-" + ch);
this.currentOption=this.$options.getOption$S(ch);
if (this.currentOption.hasArg$() && token.length$() != i + 1 ) {
this.tokens.add$TE(token.substring$I(i + 1));
break;
}} else if (stopAtNonOption) {
p$1.processNonOptionToken$S$Z.apply(this, [token.substring$I(i), true]);
break;
} else {
this.tokens.add$TE(token);
break;
}}
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-20 09:28:11 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
