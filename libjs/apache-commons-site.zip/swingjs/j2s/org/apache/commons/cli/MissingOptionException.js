(function(){var P$=Clazz.newPackage("org.apache.commons.cli"),I$=[];
var C$=Clazz.newClass(P$, "MissingOptionException", null, 'org.apache.commons.cli.ParseException');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.missingOptions=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (message) {
C$.superclazz.c$$S.apply(this, [message]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_util_List', function (missingOptions) {
C$.c$$S.apply(this, [C$.createMessage$java_util_List(missingOptions)]);
this.missingOptions=missingOptions;
}, 1);

Clazz.newMeth(C$, 'getMissingOptions$', function () {
return this.missingOptions;
});

Clazz.newMeth(C$, 'createMessage$java_util_List', function (missingOptions) {
var buf=Clazz.new_(Clazz.load('StringBuilder').c$$S,["Missing required option"]);
buf.append$S(missingOptions.size$() == 1 ? "" : "s");
buf.append$S(": ");
var it=missingOptions.iterator$();
while (it.hasNext$()){
buf.append$O(it.next$());
if (it.hasNext$()) {
buf.append$S(", ");
}}
return buf.toString();
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-20 09:28:10 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
