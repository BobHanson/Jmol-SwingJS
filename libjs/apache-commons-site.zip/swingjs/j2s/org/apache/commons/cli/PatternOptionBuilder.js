(function(){var P$=Clazz.newPackage("org.apache.commons.cli"),I$=[[0,'java.util.Date','java.io.FileInputStream','java.io.File','java.net.URL','org.apache.commons.cli.Options','org.apache.commons.cli.Option']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "PatternOptionBuilder");
C$.STRING_VALUE=null;
C$.OBJECT_VALUE=null;
C$.NUMBER_VALUE=null;
C$.DATE_VALUE=null;
C$.CLASS_VALUE=null;
C$.EXISTING_FILE_VALUE=null;
C$.FILE_VALUE=null;
C$.FILES_VALUE=null;
C$.URL_VALUE=null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.STRING_VALUE=Clazz.getClass(String);
C$.OBJECT_VALUE=Clazz.getClass(java.lang.Object);
C$.NUMBER_VALUE=Clazz.getClass(Number);
C$.DATE_VALUE=Clazz.getClass(Clazz.load('java.util.Date'));
C$.CLASS_VALUE=Clazz.getClass(Class);
C$.EXISTING_FILE_VALUE=Clazz.getClass(Clazz.load('java.io.FileInputStream'));
C$.FILE_VALUE=Clazz.getClass(Clazz.load('java.io.File'));
C$.FILES_VALUE=Clazz.array($I$(3), -1);
C$.URL_VALUE=Clazz.getClass(Clazz.load('java.net.URL'));
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getValueClass$C', function (ch) {
switch (ch.$c()) {
case 64:
return C$.OBJECT_VALUE;
case 58:
return C$.STRING_VALUE;
case 37:
return C$.NUMBER_VALUE;
case 43:
return C$.CLASS_VALUE;
case 35:
return C$.DATE_VALUE;
case 60:
return C$.EXISTING_FILE_VALUE;
case 62:
return C$.FILE_VALUE;
case 42:
return C$.FILES_VALUE;
case 47:
return C$.URL_VALUE;
}
return null;
}, 1);

Clazz.newMeth(C$, 'isValueCode$C', function (ch) {
return ch == "@" || ch == ":"  || ch == "%"  || ch == "+"  || ch == "#"  || ch == "<"  || ch == ">"  || ch == "*"  || ch == "/"  || ch == "!" ;
}, 1);

Clazz.newMeth(C$, 'parsePattern$S', function (pattern) {
var opt=" ";
var required=false;
var type=null;
var options=Clazz.new_(Clazz.load('org.apache.commons.cli.Options'));
for (var i=0; i < pattern.length$(); i++) {
var ch=pattern.charAt$I(i);
if (!C$.isValueCode$C(ch)) {
if (opt != " ") {
var option=Clazz.load('org.apache.commons.cli.Option').builder$S(String.valueOf$C(opt)).hasArg$Z(type != null ).required$Z(required).type$Class(type).build$();
options.addOption$org_apache_commons_cli_Option(option);
required=false;
type=null;
opt=" ";
}opt=ch;
} else if (ch == "!") {
required=true;
} else {
type=C$.getValueClass$C(ch);
}}
if (opt != " ") {
var option=$I$(6).builder$S(String.valueOf$C(opt)).hasArg$Z(type != null ).required$Z(required).type$Class(type).build$();
options.addOption$org_apache_commons_cli_Option(option);
}return options;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-20 09:28:10 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
