(function(){var P$=Clazz.newPackage("org.apache.commons.cli");
var C$=Clazz.newClass(P$, "AlreadySelectedException", null, 'org.apache.commons.cli.ParseException');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.group=null;
this.option=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (message) {
C$.superclazz.c$$S.apply(this, [message]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$org_apache_commons_cli_OptionGroup$org_apache_commons_cli_Option', function (group, option) {
C$.c$$S.apply(this, ["The option '" + option.getKey$() + "' was specified but an option from this group " + "has already been selected: '" + group.getSelected$() + "'" ]);
this.group=group;
this.option=option;
}, 1);

Clazz.newMeth(C$, 'getOptionGroup$', function () {
return this.group;
});

Clazz.newMeth(C$, 'getOption$', function () {
return this.option;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-20 09:28:10 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
