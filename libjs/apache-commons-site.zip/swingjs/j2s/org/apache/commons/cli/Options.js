(function(){var P$=Clazz.newPackage("org.apache.commons.cli"),I$=[[0,'java.util.LinkedHashMap','java.util.ArrayList','java.util.HashSet','org.apache.commons.cli.Option','java.util.Collections','org.apache.commons.cli.Util','StringBuilder']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Options", null, null, 'java.io.Serializable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.shortOpts=null;
this.longOpts=null;
this.requiredOpts=null;
this.optionGroups=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.shortOpts=Clazz.new_(Clazz.load('java.util.LinkedHashMap'));
this.longOpts=Clazz.new_($I$(1));
this.requiredOpts=Clazz.new_(Clazz.load('java.util.ArrayList'));
this.optionGroups=Clazz.new_($I$(1));
}, 1);

Clazz.newMeth(C$, 'addOptionGroup$org_apache_commons_cli_OptionGroup', function (group) {
if (group.isRequired$()) {
this.requiredOpts.add$TE(group);
}for (var option, $option = group.getOptions$().iterator$(); $option.hasNext$()&&((option=($option.next$())),1);) {
option.setRequired$Z(false);
this.addOption$org_apache_commons_cli_Option(option);
this.optionGroups.put$TK$TV(option.getKey$(), group);
}
return this;
});

Clazz.newMeth(C$, 'getOptionGroups$', function () {
return Clazz.new_(Clazz.load('java.util.HashSet').c$$java_util_Collection,[this.optionGroups.values$()]);
});

Clazz.newMeth(C$, 'addOption$S$S', function (opt, description) {
this.addOption$S$S$Z$S(opt, null, false, description);
return this;
});

Clazz.newMeth(C$, 'addOption$S$Z$S', function (opt, hasArg, description) {
this.addOption$S$S$Z$S(opt, null, hasArg, description);
return this;
});

Clazz.newMeth(C$, 'addOption$S$S$Z$S', function (opt, longOpt, hasArg, description) {
this.addOption$org_apache_commons_cli_Option(Clazz.new_(Clazz.load('org.apache.commons.cli.Option').c$$S$S$Z$S,[opt, longOpt, hasArg, description]));
return this;
});

Clazz.newMeth(C$, 'addRequiredOption$S$S$Z$S', function (opt, longOpt, hasArg, description) {
var option=Clazz.new_($I$(4).c$$S$S$Z$S,[opt, longOpt, hasArg, description]);
option.setRequired$Z(true);
this.addOption$org_apache_commons_cli_Option(option);
return this;
});

Clazz.newMeth(C$, 'addOption$org_apache_commons_cli_Option', function (opt) {
var key=opt.getKey$();
if (opt.hasLongOpt$()) {
this.longOpts.put$TK$TV(opt.getLongOpt$(), opt);
}if (opt.isRequired$()) {
if (this.requiredOpts.contains$O(key)) {
this.requiredOpts.remove$I(this.requiredOpts.indexOf$O(key));
}this.requiredOpts.add$TE(key);
}this.shortOpts.put$TK$TV(key, opt);
return this;
});

Clazz.newMeth(C$, 'getOptions$', function () {
return Clazz.load('java.util.Collections').unmodifiableCollection$java_util_Collection(this.helpOptions$());
});

Clazz.newMeth(C$, 'helpOptions$', function () {
return Clazz.new_($I$(2).c$$java_util_Collection,[this.shortOpts.values$()]);
});

Clazz.newMeth(C$, 'getRequiredOptions$', function () {
return $I$(5).unmodifiableList$java_util_List(this.requiredOpts);
});

Clazz.newMeth(C$, 'getOption$S', function (opt) {
opt=Clazz.load('org.apache.commons.cli.Util').stripLeadingHyphens$S(opt);
if (this.shortOpts.containsKey$O(opt)) {
return this.shortOpts.get$O(opt);
}return this.longOpts.get$O(opt);
});

Clazz.newMeth(C$, 'getMatchingOptions$S', function (opt) {
opt=$I$(6).stripLeadingHyphens$S(opt);
var matchingOpts=Clazz.new_($I$(2));
if (this.longOpts.keySet$().contains$O(opt)) {
return $I$(5).singletonList$TT(opt);
}for (var longOpt, $longOpt = this.longOpts.keySet$().iterator$(); $longOpt.hasNext$()&&((longOpt=($longOpt.next$())),1);) {
if (longOpt.startsWith$S(opt)) {
matchingOpts.add$TE(longOpt);
}}
return matchingOpts;
});

Clazz.newMeth(C$, 'hasOption$S', function (opt) {
opt=$I$(6).stripLeadingHyphens$S(opt);
return this.shortOpts.containsKey$O(opt) || this.longOpts.containsKey$O(opt) ;
});

Clazz.newMeth(C$, 'hasLongOption$S', function (opt) {
opt=$I$(6).stripLeadingHyphens$S(opt);
return this.longOpts.containsKey$O(opt);
});

Clazz.newMeth(C$, 'hasShortOption$S', function (opt) {
opt=$I$(6).stripLeadingHyphens$S(opt);
return this.shortOpts.containsKey$O(opt);
});

Clazz.newMeth(C$, 'getOptionGroup$org_apache_commons_cli_Option', function (opt) {
return this.optionGroups.get$O(opt.getKey$());
});

Clazz.newMeth(C$, 'toString', function () {
var buf=Clazz.new_(Clazz.load('StringBuilder'));
buf.append$S("[ Options: [ short ");
buf.append$S(this.shortOpts.toString());
buf.append$S(" ] [ long ");
buf.append$O(this.longOpts);
buf.append$S(" ]");
return buf.toString();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-20 09:28:10 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
