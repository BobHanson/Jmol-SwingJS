(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa"),p$1={},I$=[[0,'com.actelion.research.chem.phesa.PheSAMolecule','com.actelion.research.chem.conf.ConformerSetGenerator','java.util.ArrayList',['com.actelion.research.chem.alignment3d.PheSAAlignmentOptimizer','.PheSASetting'],'com.actelion.research.chem.phesa.MolecularVolume','com.actelion.research.chem.alignment3d.transformation.TransformationSequence','com.actelion.research.chem.alignment3d.transformation.Translation','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.Canonizer','com.actelion.research.chem.conf.ConformerSet','com.actelion.research.chem.conf.Conformer','com.actelion.research.chem.alignment3d.PheSAAlignmentOptimizer','com.actelion.research.chem.phesaflex.FlexibleShapeAlignment','com.actelion.research.chem.descriptor.DescriptorConstants','StringBuilder','com.actelion.research.chem.IDCodeParserWithoutCoordinateInvention']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DescriptorHandlerShape", null, null, 'com.actelion.research.chem.descriptor.DescriptorHandler');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['singleBaseConformation','flexible'],'D',['ppWeight'],'I',['maxConfs'],'O',['preProcessTransformations','java.util.List','previousAlignment','com.actelion.research.chem.StereoMolecule[]','previousPhesaResult','double[]','phesaSetting','com.actelion.research.chem.alignment3d.PheSAAlignmentOptimizer.PheSASetting','threadMaster','com.actelion.research.calc.ThreadMaster','conformerGenerator','com.actelion.research.chem.conf.ConformerSetGenerator']]
,['O',['INSTANCE','com.actelion.research.chem.phesa.DescriptorHandlerShape','FAILED_OBJECT','com.actelion.research.chem.phesa.PheSAMolecule']]]

Clazz.newMeth(C$, 'c$',  function () {
C$.c$$Z$I$D.apply(this, [false, 200, 0.5]);
}, 1);

Clazz.newMeth(C$, 'c$$Z',  function (useSingleBaseConformation) {
C$.c$$Z$I$D.apply(this, [useSingleBaseConformation, 200, 0.5]);
}, 1);

Clazz.newMeth(C$, 'c$$Z$D',  function (useSingleBaseConformation, ppWeight) {
C$.c$$Z$I$D.apply(this, [useSingleBaseConformation, 200, ppWeight]);
}, 1);

Clazz.newMeth(C$, 'c$$I$D',  function (maxConfs, ppWeight) {
C$.c$$Z$I$D.apply(this, [false, maxConfs, ppWeight]);
}, 1);

Clazz.newMeth(C$, 'c$$D',  function (ppWeight) {
C$.c$$Z$I$D.apply(this, [false, 200, ppWeight]);
}, 1);

Clazz.newMeth(C$, 'c$$Z$I$D',  function (useSingleBaseConformation, maxConfs, ppWeight) {
;C$.$init$.apply(this);
this.flexible=false;
this.singleBaseConformation=useSingleBaseConformation;
this.maxConfs=maxConfs;
this.ppWeight=ppWeight;
this.init$();
this.conformerGenerator=Clazz.new_($I$(2,1).c$$I,[maxConfs]);
this.conformerGenerator.setThreadMaster$com_actelion_research_calc_ThreadMaster(this.threadMaster);
this.preProcessTransformations=Clazz.new_($I$(3,1));
this.phesaSetting=Clazz.new_($I$(4,1));
}, 1);

Clazz.newMeth(C$, 'getPhesaSetting$',  function () {
return this.phesaSetting;
});

Clazz.newMeth(C$, 'setPhesaSetting$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_PheSASetting',  function (phesaSetting) {
this.phesaSetting=phesaSetting;
});

Clazz.newMeth(C$, 'setThreadMaster$com_actelion_research_calc_ThreadMaster',  function (tm) {
this.threadMaster=tm;
});

Clazz.newMeth(C$, 'getPreProcessTransformations$',  function () {
return this.preProcessTransformations;
});

Clazz.newMeth(C$, 'createDescriptor$com_actelion_research_chem_conf_ConformerSet',  function (confSet) {
this.preProcessTransformations=Clazz.new_($I$(3,1));
try {
this.init$();
var molecularVolumes=Clazz.new_($I$(3,1));
var mol=confSet.first$().toMolecule$();
if (mol.getAtoms$() > 200) return C$.FAILED_OBJECT;
var refMolVol=Clazz.new_($I$(5,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
var molVol;
for (var conformer, $conformer = confSet.iterator$(); $conformer.hasNext$()&&((conformer=($conformer.next$())),1);) {
if (conformer == null ) {
break;
} else {
molVol=Clazz.new_($I$(5,1).c$$com_actelion_research_chem_phesa_MolecularVolume$com_actelion_research_chem_conf_Conformer,[refMolVol, conformer]);
var com=molVol.getCOM$();
var rotation=molVol.preProcess$com_actelion_research_chem_conf_Conformer(conformer);
var transformation=Clazz.new_($I$(6,1));
transformation.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(rotation.getInvert$());
transformation.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(Clazz.new_([Clazz.array(Double.TYPE, -1, [com.x, com.y, com.z])],$I$(7,1).c$$DA));
this.preProcessTransformations.add$O(transformation);
molecularVolumes.add$O(molVol);
}}
mol=confSet.first$().toMolecule$();
return Clazz.new_($I$(1,1).c$$com_actelion_research_chem_StereoMolecule$java_util_ArrayList,[mol, molecularVolumes]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return C$.FAILED_OBJECT;
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'init$',  function () {
this.previousAlignment=Clazz.array($I$(8), [2]);
});

Clazz.newMeth(C$, ['createDescriptor$com_actelion_research_chem_StereoMolecule','createDescriptor$O'],  function (mol) {
var shapeMolecule=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_Molecule,[mol]);
shapeMolecule.ensureHelperArrays$I(31);
var has3Dcoordinates=false;
for (var atom=1; atom < mol.getAllAtoms$(); atom++) {
if (Math.abs(mol.getAtomZ$I(atom) - mol.getAtomZ$I(0)) > 0.1 ) {
has3Dcoordinates=true;
break;
}}
shapeMolecule.stripSmallFragments$();
var can=Clazz.new_($I$(9,1).c$$com_actelion_research_chem_StereoMolecule,[shapeMolecule]);
shapeMolecule=can.getCanMolecule$Z(true);
var confSet=Clazz.new_($I$(10,1));
if (!this.singleBaseConformation) {
confSet=this.conformerGenerator.generateConformerSet$com_actelion_research_chem_StereoMolecule(shapeMolecule);
} else if (!has3Dcoordinates) {
return C$.FAILED_OBJECT;
} else {
if (shapeMolecule.getAllAtoms$() - shapeMolecule.getAtoms$() == 0) {
System.err.println$S("missing hydrogens in 3D structure");
return C$.FAILED_OBJECT;
}confSet.add$O(Clazz.new_($I$(11,1).c$$com_actelion_research_chem_StereoMolecule,[shapeMolecule]));
}return this.createDescriptor$com_actelion_research_chem_conf_ConformerSet(confSet);
});

Clazz.newMeth(C$, ['getSimilarity$com_actelion_research_chem_phesa_PheSAMolecule$com_actelion_research_chem_phesa_PheSAMolecule','getSimilarity$O$O'],  function (query, base) {
var bestPair=Clazz.array($I$(8), -1, [query.getMolecule$(), base.getMolecule$()]);
var result=$I$(12).align$com_actelion_research_chem_phesa_PheSAMolecule$com_actelion_research_chem_phesa_PheSAMolecule$com_actelion_research_chem_StereoMoleculeA$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_PheSASetting(query, base, bestPair, this.phesaSetting);
this.setPreviousAlignment$com_actelion_research_chem_StereoMoleculeA(bestPair);
this.setPreviousPheSAResult$DA(result);
if (this.flexible) {
var fsa=Clazz.new_($I$(13,1).c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule,[bestPair[0], bestPair[1]]);
fsa.setSettings$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_PheSASetting(this.phesaSetting);
result=fsa.align$();
this.setPreviousPheSAResult$DA(result);
}return result[0];
});

Clazz.newMeth(C$, 'getPreviousAlignment$',  function () {
return this.previousAlignment;
});

Clazz.newMeth(C$, 'getPreviousPheSAResult$',  function () {
return this.previousPhesaResult;
});

Clazz.newMeth(C$, 'setPreviousAlignment$com_actelion_research_chem_StereoMoleculeA',  function (previousAlignment) {
this.previousAlignment=previousAlignment;
});

Clazz.newMeth(C$, 'setPreviousPheSAResult$DA',  function (previousPhesaResult) {
this.previousPhesaResult=previousPhesaResult;
});

Clazz.newMeth(C$, 'getVersion$',  function () {
return $I$(14).DESCRIPTOR_ShapeAlign.version;
});

Clazz.newMeth(C$, 'getInfo$',  function () {
return $I$(14).DESCRIPTOR_ShapeAlign;
});

Clazz.newMeth(C$, ['encode$com_actelion_research_chem_phesa_PheSAMolecule','encode$O'],  function (o) {
if (this.calculationFailed$com_actelion_research_chem_phesa_PheSAMolecule(o)) {
return "Calculation Failed";
}var molVols=null;
var shapeMol;
if (Clazz.instanceOf(o, "com.actelion.research.chem.phesa.PheSAMolecule")) {
shapeMol=o;
molVols=shapeMol.getVolumes$();
} else {
return "Calculation Failed";
}var shapeString=Clazz.new_($I$(15,1));
var nrOfMolVols=molVols.size$();
shapeString.append$S(Integer.toString$I(nrOfMolVols));
shapeString.append$S("   ");
shapeString.append$S(molVols.get$I(0).encodeFull$());
shapeString.append$S("   ");
for (var i=1; i < nrOfMolVols; i++) {
shapeString.append$S(molVols.get$I(i).encodeCoordsOnly$());
shapeString.append$S("   ");
}
shapeString.append$S("   ");
var mol=Clazz.new_([shapeMol.getMolecule$()],$I$(8,1).c$$com_actelion_research_chem_Molecule);
var can=Clazz.new_($I$(9,1).c$$com_actelion_research_chem_StereoMolecule$I,[mol, 64]);
var idcoords=can.getEncodedCoordinates$Z(true);
var idcode=can.getIDCode$();
shapeString.append$S(idcode);
shapeString.append$S("   ");
shapeString.append$S(idcoords);
return shapeString.toString();
});

Clazz.newMeth(C$, 'decode$S',  function (s) {
try {
return s == null  || s.length$() == 0  ? null : s.equals$O("Calculation Failed") ? C$.FAILED_OBJECT : p$1.getDecodedObject$S.apply(this, [s]);
} catch (e1) {
if (Clazz.exceptionOf(e1,"RuntimeException")){
return C$.FAILED_OBJECT;
} else {
throw e1;
}
}
});

Clazz.newMeth(C$, 'getDecodedObject$S',  function (string64) {
var splitted=string64.split$S("   ");
var idcode=splitted[splitted.length - 2];
var idcoords=splitted[splitted.length - 1];
var mol=Clazz.new_($I$(8,1));
var parser=Clazz.new_($I$(16,1));
parser.parse$com_actelion_research_chem_StereoMolecule$S$S(mol, idcode, idcoords);
mol.ensureHelperArrays$I(31);
var molVols=Clazz.new_($I$(3,1));
var nrOfMolVols=(Integer.decode$S(splitted[0])).$c();
var refMolVol=$I$(5).decodeFull$S$com_actelion_research_chem_StereoMolecule(splitted[1], mol);
molVols.add$O(refMolVol);
for (var i=2; i < nrOfMolVols + 1; i++) {
molVols.add$O($I$(5).decodeCoordsOnly$S$com_actelion_research_chem_phesa_MolecularVolume(splitted[i], refMolVol));
}
var shapeMol=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_StereoMolecule$java_util_ArrayList,[mol, molVols]);
return shapeMol;
}, p$1);

Clazz.newMeth(C$, 'decode$BA',  function (arr) {
return this.decode$S( String.instantialize(arr));
});

Clazz.newMeth(C$, ['calculationFailed$com_actelion_research_chem_phesa_PheSAMolecule','calculationFailed$O'],  function (o) {
return o.getVolumes$().size$() == 0;
});

Clazz.newMeth(C$, 'getThreadSafeCopy$',  function () {
var dhs=Clazz.new_(C$);
dhs.ppWeight=this.ppWeight;
dhs.flexible=this.flexible;
dhs.maxConfs=this.maxConfs;
return dhs;
});

Clazz.newMeth(C$, 'getDefaultInstance$',  function () {
if (C$.INSTANCE == null ) {
C$.INSTANCE=Clazz.new_(C$);
}return C$.INSTANCE;
}, 1);

Clazz.newMeth(C$, 'setMaxConfs$I',  function (maxConfs) {
this.maxConfs=maxConfs;
this.init$();
});

Clazz.newMeth(C$, 'setFlexible$Z',  function (flexible) {
this.flexible=flexible;
});

Clazz.newMeth(C$, 'isFlexible$',  function () {
return this.flexible;
});

Clazz.newMeth(C$, 'getPpWeight$',  function () {
return this.ppWeight;
});

C$.$static$=function(){C$.$static$=0;
C$.FAILED_OBJECT=Clazz.new_($I$(1,1));
};
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:27 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
