(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'com.actelion.research.chem.Coordinates','com.actelion.research.chem.AtomFunctionAnalyzer','com.actelion.research.chem.AtomTypeCalculator','StringBuilder','com.actelion.research.chem.IDCodeParser','com.actelion.research.chem.SSSearcher','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.Canonizer','com.actelion.research.calc.ArrayUtilsCalc','com.actelion.research.calc.statistics.median.MedianStatisticFunctions','java.util.ArrayList','java.util.Arrays','java.util.LinkedList','java.util.HashSet']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ExtendedMoleculeFunctions");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['arrRGroupsAtomicNo','int[]','arrRGroupsSymbol','String[]']]]

Clazz.newMeth(C$, 'getCenterGravity$com_actelion_research_chem_ExtendedMolecule',  function (mol) {
var n=mol.getAllAtoms$();
var indices=Clazz.array(Integer.TYPE, [n]);
for (var i=0; i < indices.length; i++) {
indices[i]=i;
}
return C$.getCenterGravity$com_actelion_research_chem_ExtendedMolecule$IA(mol, indices);
}, 1);

Clazz.newMeth(C$, 'getCenterGravity$com_actelion_research_chem_ExtendedMolecule$IA',  function (mol, indices) {
var c=Clazz.new_($I$(1,1));
for (var i=0; i < indices.length; i++) {
c.x+=mol.getAtomX$I(indices[i]);
c.y+=mol.getAtomY$I(indices[i]);
c.z+=mol.getAtomZ$I(indices[i]);
}
c.x/=indices.length;
c.y/=indices.length;
c.z/=indices.length;
return c;
}, 1);

Clazz.newMeth(C$, 'makeSkeleton$com_actelion_research_chem_StereoMolecule',  function (mol) {
for (var bond=0; bond < mol.getAllBonds$(); bond++) mol.setBondType$I$I(bond, 1);

for (var atom=0; atom < mol.getAllAtoms$(); atom++) mol.setAtomicNo$I$I(atom, 6);

}, 1);

Clazz.newMeth(C$, 'analyzeMolecule$com_actelion_research_chem_StereoMolecule',  function (mol) {
var nAtoms=mol.getAtoms$();
for (var atom=0; atom < nAtoms; atom++) {
if ($I$(2).isAcidicOxygen$com_actelion_research_chem_StereoMolecule$I(mol, atom)) {
System.out.println$S("Acidic oxygen " + atom);
}if ($I$(2).isNitroGroupN$com_actelion_research_chem_StereoMolecule$I(mol, atom)) {
System.out.println$S("Nitro group N " + atom);
}if ($I$(2).isMemberOfNitroGroup$com_actelion_research_chem_StereoMolecule$I(mol, atom)) {
System.out.println$S("Member of group " + atom);
}if ($I$(2).isBasicNitrogen$com_actelion_research_chem_StereoMolecule$I(mol, atom)) {
System.out.println$S("Basic nitrogen " + atom);
}}
System.out.println$S("Index\tAtomic no\tAtom type");
for (var indexAtom=0; indexAtom < mol.getAllAtoms$(); indexAtom++) {
var atomType=-1;
try {
atomType=$I$(3).getAtomType$com_actelion_research_chem_StereoMolecule$I$I(mol, indexAtom, 6241);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
System.out.println$S(indexAtom + "\t" + mol.getAtomicNo$I(indexAtom) + "\t" + C$.hexAlign$J(atomType) + "\t" + $I$(3).toString$J(atomType) );
}
System.out.println$();
}, 1);

Clazz.newMeth(C$, 'hexAlign$J',  function (atomType) {
var s="0000000000000000" + Long.toHexString$J(atomType);
return "0x" + s.substring$I(s.length$() - 16);
}, 1);

Clazz.newMeth(C$, 'getColorVal2String$com_actelion_research_chem_Molecule$I',  function (mol, indexAtom) {
var color=mol.getAtomColor$I(indexAtom);
return C$.getcAtomColor2String$I(color);
}, 1);

Clazz.newMeth(C$, 'getcAtomColor2String$I',  function (cAtomColor) {
var sColor="";
switch (cAtomColor) {
case 0:
sColor="black";
break;
case 64:
sColor="blue";
break;
case 128:
sColor="red";
break;
case 192:
sColor="green";
break;
case 256:
sColor="magenta";
break;
case 320:
sColor="orange";
break;
case 384:
sColor="darkGreen";
break;
case 448:
sColor="darkRed";
break;
default:
break;
}
return sColor;
}, 1);

Clazz.newMeth(C$, 'getColorRecord$com_actelion_research_chem_Molecule$java_util_Collection$I',  function (mol, liIndexAtom, cAtomColor) {
var sb=Clazz.new_($I$(4,1));
var cc=0;
for (var indexAtom, $indexAtom = liIndexAtom.iterator$(); $indexAtom.hasNext$()&&((indexAtom=($indexAtom.next$()).intValue$()),1);) {
var sColor=C$.getcAtomColor2String$I(cAtomColor);
sColor+=":" + indexAtom;
sb.append$S(sColor);
if (cc < liIndexAtom.size$() - 1) {
sb.append$S(";");
}++cc;
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'getNumQueryAtoms$com_actelion_research_chem_ExtendedMolecule$IA',  function (mol, arrAtomicNoQuery) {
var hetero=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
var atomicNo=mol.getAtomicNo$I(i);
for (var j=0; j < arrAtomicNoQuery.length; j++) {
if (arrAtomicNoQuery[j] == atomicNo) {
++hetero;
break;
}}
}
return hetero;
}, 1);

Clazz.newMeth(C$, 'getNumBondsNoHydrogen$com_actelion_research_chem_ExtendedMolecule',  function (mol) {
var bnds=0;
for (var i=0; i < mol.getBonds$(); i++) {
var at1=mol.getBondAtom$I$I(0, i);
var atNo1=mol.getAtomicNo$I(at1);
var at2=mol.getBondAtom$I$I(1, i);
var atNo2=mol.getAtomicNo$I(at2);
if (atNo1 != 1 && atNo2 != 1 ) {
++bnds;
}}
return bnds;
}, 1);

Clazz.newMeth(C$, 'getNumNonHydrogenAtoms$com_actelion_research_chem_ExtendedMolecule',  function (mol) {
var non=0;
for (var i=0; i < mol.getAtoms$(); i++) {
var atomicNo=mol.getAtomicNo$I(i);
if (atomicNo != 1) {
++non;
}}
return non;
}, 1);

Clazz.newMeth(C$, 'getNumCarbonAtoms$com_actelion_research_chem_ExtendedMolecule',  function (mol) {
var carbon=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
var atomicNo=mol.getAtomicNo$I(i);
if (atomicNo == 6) {
++carbon;
}}
return carbon;
}, 1);

Clazz.newMeth(C$, 'getNumHeteroAtoms$com_actelion_research_chem_ExtendedMolecule',  function (mol) {
var hetero=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
var atomicNo=mol.getAtomicNo$I(i);
if ((atomicNo > 1) && (atomicNo != 6) && (atomicNo <= 118)  ) {
++hetero;
}}
return hetero;
}, 1);

Clazz.newMeth(C$, 'isHetero$com_actelion_research_chem_ExtendedMolecule$I',  function (mol, indexAtom) {
var hetero=false;
var atomicNo=mol.getAtomicNo$I(indexAtom);
if ((atomicNo > 1) && (atomicNo != 6) && (atomicNo <= 118)  ) {
hetero=true;
}return hetero;
}, 1);

Clazz.newMeth(C$, 'getNumNitroGroupN$com_actelion_research_chem_StereoMolecule',  function (mol) {
var n=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
if ($I$(2).isNitroGroupN$com_actelion_research_chem_StereoMolecule$I(mol, i)) {
++n;
}}
return n;
}, 1);

Clazz.newMeth(C$, 'getNumAmide$com_actelion_research_chem_StereoMolecule',  function (mol) {
var n=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
if ($I$(2).isAmide$com_actelion_research_chem_StereoMolecule$I(mol, i)) {
++n;
}}
return n;
}, 1);

Clazz.newMeth(C$, 'getNumCarboxy$com_actelion_research_chem_StereoMolecule',  function (mol) {
var n=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (C$.isCarboxyC$com_actelion_research_chem_StereoMolecule$I(mol, i)) {
++n;
}}
return n;
}, 1);

Clazz.newMeth(C$, 'getNumAcidicOxygen$com_actelion_research_chem_StereoMolecule',  function (mol) {
var n=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
if ($I$(2).isAcidicOxygen$com_actelion_research_chem_StereoMolecule$I(mol, i)) {
++n;
}}
return n;
}, 1);

Clazz.newMeth(C$, 'getNumBasicNitrogen$com_actelion_research_chem_StereoMolecule',  function (mol) {
var n=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
if ($I$(2).isBasicNitrogen$com_actelion_research_chem_StereoMolecule$I(mol, i)) {
++n;
}}
return n;
}, 1);

Clazz.newMeth(C$, 'getNumAliphaticRingAtoms$com_actelion_research_chem_ExtendedMolecule$I',  function (mol, atomicNoQuery) {
var n=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
var atomicNo=mol.getAtomicNo$I(i);
if (mol.isRingAtom$I(i) && atomicNo == atomicNoQuery ) {
++n;
}}
return n;
}, 1);

Clazz.newMeth(C$, 'getNumHeavyAtoms$com_actelion_research_chem_ExtendedMolecule',  function (mol) {
var heavy=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
var atomicNo=mol.getAtomicNo$I(i);
if (atomicNo > 1 && atomicNo <= 118 ) {
++heavy;
}}
return heavy;
}, 1);

Clazz.newMeth(C$, 'getNumAromaticAtoms$com_actelion_research_chem_ExtendedMolecule',  function (mol) {
var n=0;
for (var i=0; i < mol.getAtoms$(); i++) {
if (mol.isAromaticAtom$I(i)) {
++n;
}}
return n;
}, 1);

Clazz.newMeth(C$, 'getNumArylAmine$com_actelion_research_chem_StereoMolecule',  function (mol) {
var n=0;
for (var i=0; i < mol.getAtoms$(); i++) {
if ($I$(2).isArylAmine$com_actelion_research_chem_StereoMolecule$I(mol, i)) {
++n;
}}
return n;
}, 1);

Clazz.newMeth(C$, 'getNumHeteroAromaticAtoms$com_actelion_research_chem_ExtendedMolecule',  function (mol) {
var n=0;
for (var i=0; i < mol.getAtoms$(); i++) {
if (mol.isRingAtom$I(i) && mol.isAromaticAtom$I(i) && mol.getAtomicNo$I(i) != 6  ) {
++n;
}}
return n;
}, 1);

Clazz.newMeth(C$, 'getNumIsopropyl$com_actelion_research_chem_ExtendedMolecule',  function (mol) {
var n=0;
for (var i=0; i < mol.getAtoms$(); i++) {
if (mol.isRingAtom$I(i) && mol.isAromaticAtom$I(i) && mol.getAtomicNo$I(i) != 6  ) {
++n;
}}
return n;
}, 1);

Clazz.newMeth(C$, 'getNumSubstructure$com_actelion_research_chem_StereoMolecule$S',  function (mol, idcodeFragment) {
var parser=Clazz.new_($I$(5,1));
var frag=parser.getCompactMolecule$S(idcodeFragment);
frag.ensureHelperArrays$I(7);
var ssSearcher=Clazz.new_($I$(6,1));
ssSearcher.setMol$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule(frag, mol);
var nMatches=ssSearcher.findFragmentInMolecule$();
return nMatches;
}, 1);

Clazz.newMeth(C$, 'getBondNo$com_actelion_research_chem_ExtendedMolecule$I$I',  function (mol, atm1, atm2) {
for (var bnd=0; bnd < mol.getAllBonds$(); bnd++) if (((mol.getBondAtom$I$I(0, bnd) == atm1) && (mol.getBondAtom$I$I(1, bnd) == atm2) ) || ((mol.getBondAtom$I$I(0, bnd) == atm2) && (mol.getBondAtom$I$I(1, bnd) == atm1) ) ) return bnd;

return -1;
}, 1);

Clazz.newMeth(C$, 'getBondOrder$com_actelion_research_chem_ExtendedMolecule$I$I',  function (mol, atm1, atm2) {
var bndno=C$.getBondNo$com_actelion_research_chem_ExtendedMolecule$I$I(mol, atm1, atm2);
if (bndno == -1) return -1;
var bndord=mol.getBondOrder$I(bndno);
return bndord;
}, 1);

Clazz.newMeth(C$, 'getBondType$com_actelion_research_chem_ExtendedMolecule$I$I',  function (mol, atm1, atm2) {
var bndno=C$.getBondNo$com_actelion_research_chem_ExtendedMolecule$I$I(mol, atm1, atm2);
if (bndno == -1) return -1;
var bndtype=mol.getBondType$I(bndno);
return bndtype;
}, 1);

Clazz.newMeth(C$, 'getBondParity$com_actelion_research_chem_ExtendedMolecule$I$I',  function (mol, atm1, atm2) {
var bndno=C$.getBondNo$com_actelion_research_chem_ExtendedMolecule$I$I(mol, atm1, atm2);
if (bndno == -1) return -1;
var bndtype=mol.getBondParity$I(bndno);
return bndtype;
}, 1);

Clazz.newMeth(C$, 'deleteBond$com_actelion_research_chem_ExtendedMolecule$I$I',  function (mol, atm1, atm2) {
var bndno=C$.getBondNo$com_actelion_research_chem_ExtendedMolecule$I$I(mol, atm1, atm2);
if (bndno == -1) return false;
mol.deleteBond$I(bndno);
return true;
}, 1);

Clazz.newMeth(C$, 'getBiggestFragmentIDCode$S',  function (idCode) {
var mol=Clazz.new_($I$(7,1));
Clazz.new_($I$(5,1).c$$Z,[false]).parse$com_actelion_research_chem_StereoMolecule$S(mol, idCode);
var frags=mol.getFragments$();
var idBiggest=idCode;
if (frags.length > 1) {
var biggest=mol;
var maxAtoms=0;
for (var ii=0; ii < frags.length; ii++) {
if (frags[ii].getAllAtoms$() > maxAtoms) {
maxAtoms=frags[ii].getAllAtoms$();
biggest=frags[ii];
}}
var canFrag=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_StereoMolecule,[biggest]);
idBiggest=canFrag.getIDCode$();
}return idBiggest;
}, 1);

Clazz.newMeth(C$, 'getBiggestFragment$com_actelion_research_chem_StereoMolecule',  function (mol) {
var frags=mol.getFragments$();
var biggest=mol;
if (frags.length > 1) {
var maxAtoms=0;
for (var ii=0; ii < frags.length; ii++) {
if (frags[ii].getAllAtoms$() > maxAtoms) {
maxAtoms=frags[ii].getAllAtoms$();
biggest=frags[ii];
}}
}return biggest;
}, 1);

Clazz.newMeth(C$, 'getConverted2CarbonSkeleton$com_actelion_research_chem_StereoMolecule',  function (m) {
var skel=Clazz.new_($I$(7,1).c$$com_actelion_research_chem_Molecule,[m]);
skel.ensureHelperArrays$I(7);
for (var i=0; i < skel.getAtoms$(); i++) {
if (skel.getAtomicNo$I(i) > 1) {
skel.setAtomicNo$I$I(i, 6);
}}
skel.ensureHelperArrays$I(7);
return skel;
}, 1);

Clazz.newMeth(C$, 'getComparatorAtomsBonds$',  function () {
return ((P$.ExtendedMoleculeFunctions$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "ExtendedMoleculeFunctions$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule','compare$O$O'],  function (m1, m2) {
if (m1.getAllAtoms$() > m2.getAllAtoms$()) {
return 1;
} else if (m1.getAllAtoms$() < m2.getAllAtoms$()) {
return -1;
} else if (m1.getAllBonds$() > m2.getAllBonds$()) {
return 1;
} else if (m1.getAllBonds$() < m2.getAllBonds$()) {
return -1;
}return 0;
});
})()
), Clazz.new_(P$.ExtendedMoleculeFunctions$1.$init$,[this, null]));
}, 1);

Clazz.newMeth(C$, 'checkBiggestFragmentForUnwanted$com_actelion_research_chem_StereoMolecule$java_util_List',  function (mol, liAtomicNo) {
var bOk=true;
var frags=mol.getFragments$();
var indexBiggestFrag=0;
if (frags.length > 1) {
var maxAtoms=0;
for (var ii=0; ii < frags.length; ii++) {
if (frags[ii].getAllAtoms$() > maxAtoms) {
indexBiggestFrag=ii;
maxAtoms=frags[ii].getAllAtoms$();
}}
}var frag=frags[indexBiggestFrag];
for (var i=0; i < frag.getAllAtoms$(); i++) {
if (liAtomicNo.contains$O( new Integer(frag.getAtomicNo$I(i)))) {
bOk=false;
break;
}}
return bOk;
}, 1);

Clazz.newMeth(C$, 'containsAtLeastOneAtomicNumbersFromHashSet$com_actelion_research_chem_ExtendedMolecule$java_util_HashSet',  function (mol, hsAtomicNo) {
var bOk=false;
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (hsAtomicNo.contains$O(Integer.valueOf$I(mol.getAtomicNo$I(i)))) {
bOk=true;
break;
}}
return bOk;
}, 1);

Clazz.newMeth(C$, 'containsHeteroAtom$com_actelion_research_chem_ExtendedMolecule$IA',  function (mol, arrIndexAt) {
var hetero=false;
for (var indexAt, $indexAt = 0, $$indexAt = arrIndexAt; $indexAt<$$indexAt.length&&((indexAt=($$indexAt[$indexAt])),1);$indexAt++) {
if (mol.getAtomicNo$I(indexAt) != 6 && mol.getAtomicNo$I(indexAt) != 1 ) {
hetero=true;
break;
}}
return hetero;
}, 1);

Clazz.newMeth(C$, 'containsSolelyAtomicNumbersFromHashSet$com_actelion_research_chem_ExtendedMolecule$java_util_HashSet',  function (mol, hsAtomicNo) {
var allAtomicNosInHashset=true;
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (!hsAtomicNo.contains$O(Integer.valueOf$I(mol.getAtomicNo$I(i)))) {
allAtomicNosInHashset=false;
break;
}}
return allAtomicNosInHashset;
}, 1);

Clazz.newMeth(C$, 'atomAtomSubStrucMatch$com_actelion_research_chem_StereoMolecule$I$com_actelion_research_chem_StereoMolecule',  function (molecule, at, fragment) {
var bMatch=false;
var sss=Clazz.new_($I$(6,1));
sss.setMol$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule(fragment, molecule);
var numFrags=sss.findFragmentInMolecule$I$I(4, 8);
if (numFrags == 0) return false;
var liAtomLists=sss.getMatchList$();
$I$(9).removeDoubletsIntOrderIndepend$java_util_List(liAtomLists);
var atomMarkedInQuery=-1;
for (var i=0; i < fragment.getAllAtoms$(); i++) {
if (fragment.getAtomColor$I(i) == 128) {
atomMarkedInQuery=i;
}}
for (var iter=liAtomLists.iterator$(); iter.hasNext$(); ) {
var arrInd=iter.next$();
if (arrInd[atomMarkedInQuery] == at) {
bMatch=true;
break;
}}
return bMatch;
}, 1);

Clazz.newMeth(C$, 'getDistanceArray$com_actelion_research_chem_ExtendedMolecule',  function (mol) {
var arr=Clazz.array(Double.TYPE, [mol.getAllAtoms$(), mol.getAllAtoms$()]);
for (var i=0; i < arr.length; i++) {
for (var j=i + 1; j < arr.length; j++) {
var dx=mol.getAtomX$I(i) - mol.getAtomX$I(j);
var dy=mol.getAtomY$I(i) - mol.getAtomY$I(j);
var dz=mol.getAtomZ$I(i) - mol.getAtomZ$I(j);
var v=Math.sqrt(dx * dx + dy * dy + dz * dz);
arr[i][j]=v;
arr[j][i]=v;
}
}
return arr;
}, 1);

Clazz.newMeth(C$, 'getTopologicalDistances$IAA$IA$IA',  function (topoDistMatrix, at1, at2) {
var d=Clazz.array(Integer.TYPE, [at1.length * at2.length]);
var cc=0;
for (var i=0; i < at1.length; i++) {
for (var j=0; j < at2.length; j++) {
d[cc++]=topoDistMatrix[at1[i]][at2[j]];
}
}
return d;
}, 1);

Clazz.newMeth(C$, 'getMedianTopologicalDistance$IAA$IA$IA',  function (topoDistMatrix, at1, at2) {
var d=C$.getTopologicalDistances$IAA$IA$IA(topoDistMatrix, at1, at2);
var medTopoDist=$I$(10).getMedianForInteger$IA(d).median;
return medTopoDist;
}, 1);

Clazz.newMeth(C$, 'getTopologicalDistance$com_actelion_research_chem_ExtendedMolecule$I$I',  function (mol, at1, at2) {
var dist=0;
if (at1 == at2) return 0;
var liExamine=Clazz.new_($I$(11,1));
var liSphere=Clazz.new_($I$(11,1));
var liVisited=Clazz.new_($I$(11,1));
liExamine.add$O( new Integer(at1));
liSphere.add$O( new Integer(1));
var bFound=false;
while (!liExamine.isEmpty$()){
dist=(liSphere.remove$I(0)).intValue$();
var indAtCenter=(liExamine.remove$I(0)).intValue$();
liVisited.add$O( new Integer(indAtCenter));
var numJNeighbors=mol.getAllConnAtoms$I(indAtCenter);
for (var i=0; i < numJNeighbors; i++) {
var indAtNeighb=mol.getConnAtom$I$I(indAtCenter, i);
if (indAtNeighb == at2) {
bFound=true;
break;
}if (!liVisited.contains$O( new Integer(indAtNeighb))) {
liExamine.add$O( new Integer(indAtNeighb));
liSphere.add$O( new Integer(dist + 1));
}}
if (bFound) break;
}
if (!bFound) dist=-1;
return dist;
}, 1);

Clazz.newMeth(C$, 'getTopologicalDistanceMatrix$com_actelion_research_chem_StereoMolecule',  function (mol) {
return C$.getNumberOfBondsBetweenAtoms$com_actelion_research_chem_StereoMolecule$I$IAA(mol, mol.getBonds$(), null);
}, 1);

Clazz.newMeth(C$, 'getNumberOfBondsBetweenAtoms$com_actelion_research_chem_StereoMolecule$I$IAA',  function (mol, maxBonds, dist) {
if (dist == null ) dist=Clazz.array(Integer.TYPE, [mol.getAtoms$(), mol.getAtoms$()]);
var N=dist.length;
for (var i=0; i < N; i++) {
dist[i][i]=0;
for (var j=i + 1; j < N; j++) {
dist[i][j]=dist[j][i]=-1;
}
}
for (var j=0; j < maxBonds; j++) {
for (var i=0; i < mol.getBonds$(); i++) {
var a1=mol.getBondAtom$I$I(0, i);
var a2=mol.getBondAtom$I$I(1, i);
if (a1 >= N || a2 >= N ) continue;
for (var a0=0; a0 < N; a0++) {
if (dist[a0][a1] >= 0 && (dist[a0][a2] == -1 || dist[a0][a1] + 1 < dist[a0][a2] )  && dist[a0][a1] < maxBonds ) {
dist[a2][a0]=(dist[a0][a2]=(dist[a0][a1] + 1));
}if (dist[a0][a2] >= 0 && (dist[a0][a1] == -1 || dist[a0][a2] + 1 < dist[a0][a1] )  && dist[a0][a2] < maxBonds ) {
dist[a1][a0]=(dist[a0][a1]=(dist[a0][a2] + 1));
}}
}
}
return dist;
}, 1);

Clazz.newMeth(C$, 'isAliphaticAtom$com_actelion_research_chem_StereoMolecule$I',  function (mol, atm) {
var aliphatic=true;
if (mol.getAtomicNo$I(atm) != 6) return false;
var nConn=mol.getAllConnAtoms$I(atm);
for (var i=0; i < nConn; i++) {
var atmConn=mol.getConnAtom$I$I(atm, i);
var atomicNoConn=mol.getAtomicNo$I(atmConn);
if ((atomicNoConn == 7) || (atomicNoConn == 8) || (atomicNoConn == 9) || (atomicNoConn == 15) || (atomicNoConn == 16) || (atomicNoConn == 17)  ) {
aliphatic=false;
break;
}}
return aliphatic;
}, 1);

Clazz.newMeth(C$, 'isAcceptor$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
var acceptor=true;
if (mol.getAtomicNo$I(atom) != 8 && mol.getAtomicNo$I(atom) != 7 ) return false;
return acceptor;
}, 1);

Clazz.newMeth(C$, 'isDonor$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
var donor=true;
if (mol.getAtomicNo$I(atom) != 8 && mol.getAtomicNo$I(atom) != 7 ) return false;
if (mol.getAllHydrogens$I(atom) == 0) {
return false;
}return donor;
}, 1);

Clazz.newMeth(C$, 'isCarbonTwoValencesMinimum$com_actelion_research_chem_StereoMolecule',  function (mol) {
var twoValencesMin=true;
var atoms=mol.getAtoms$();
for (var i=0; i < atoms; i++) {
var atomicNo=mol.getAtomicNo$I(i);
if (atomicNo == 6) {
var connected=mol.getConnAtoms$I(i);
if (connected < 2) {
twoValencesMin=false;
break;
}}}
return twoValencesMin;
}, 1);

Clazz.newMeth(C$, 'isCarbonOnlyConnected2Hetero$com_actelion_research_chem_StereoMolecule',  function (mol) {
var hetero=true;
var atoms=mol.getAtoms$();
 outer : for (var i=0; i < atoms; i++) {
var atomicNo=mol.getAtomicNo$I(i);
if (atomicNo == 6) {
var connected=mol.getConnAtoms$I(i);
for (var j=0; j < connected; j++) {
var indexConnecetd=mol.getConnAtom$I$I(i, j);
if (mol.getAtomicNo$I(indexConnecetd) == 6) {
hetero=false;
break outer;
}}
if (mol.isRingAtom$I(i)) {
hetero=true;
break;
}}}
return hetero;
}, 1);

Clazz.newMeth(C$, 'isCarbonConnected2Hetero$com_actelion_research_chem_StereoMolecule$I',  function (mol, atomIndex) {
var hetero=false;
var atomicNo=mol.getAtomicNo$I(atomIndex);
if (atomicNo == 6) {
var connected=mol.getConnAtoms$I(atomIndex);
for (var j=0; j < connected; j++) {
var indexConnected=mol.getConnAtom$I$I(atomIndex, j);
if (mol.getAtomicNo$I(indexConnected) != 6 && mol.getAtomicNo$I(indexConnected) != 1 ) {
hetero=true;
break;
}}
}return hetero;
}, 1);

Clazz.newMeth(C$, 'isConnected2Hetero$com_actelion_research_chem_StereoMolecule$IA',  function (mol, arrAtomIndex) {
var hetero=false;
for (var atomIndex, $atomIndex = 0, $$atomIndex = arrAtomIndex; $atomIndex<$$atomIndex.length&&((atomIndex=($$atomIndex[$atomIndex])),1);$atomIndex++) {
var connected=mol.getConnAtoms$I(atomIndex);
for (var j=0; j < connected; j++) {
var indexConnected=mol.getConnAtom$I$I(atomIndex, j);
if (mol.getAtomicNo$I(indexConnected) != 6 && mol.getAtomicNo$I(indexConnected) != 1 ) {
hetero=true;
break;
}}
}
return hetero;
}, 1);

Clazz.newMeth(C$, 'isRingInMolecule$com_actelion_research_chem_StereoMolecule',  function (mol) {
var ring=false;
var atoms=mol.getAtoms$();
for (var i=0; i < atoms; i++) {
if (mol.isRingAtom$I(i)) {
ring=true;
break;
}}
return ring;
}, 1);

Clazz.newMeth(C$, 'isRingExclusively$com_actelion_research_chem_StereoMolecule',  function (mol) {
var ring=true;
var atoms=mol.getAtoms$();
for (var i=0; i < atoms; i++) {
if (!mol.isRingAtom$I(i)) {
ring=false;
break;
}}
return ring;
}, 1);

Clazz.newMeth(C$, 'containsFiveBindingCarbon$com_actelion_research_chem_StereoMolecule',  function (mol) {
var five=false;
for (var i=0; i < mol.getAtoms$(); i++) {
if (mol.getAtomicNo$I(i) == 6) {
var sumBO=0;
for (var j=0; j < mol.getConnAtoms$I(i); j++) {
var bo=mol.getConnBondOrder$I$I(i, j);
sumBO+=bo;
}
if (sumBO > 4) {
five=true;
break;
}}}
return five;
}, 1);

Clazz.newMeth(C$, 'containsFiveBindingNitrogenWithoutCharge$com_actelion_research_chem_StereoMolecule',  function (mol) {
var fiveBindingNNoPositiveCharge=false;
for (var i=0; i < mol.getAtoms$(); i++) {
if (mol.getAtomicNo$I(i) == 5) {
var sumBO=0;
for (var j=0; j < mol.getConnAtoms$I(i); j++) {
var bo=mol.getConnBondOrder$I$I(i, j);
sumBO+=bo;
}
if (sumBO == 5) {
if (mol.getAtomCharge$I(i) != 1) {
fiveBindingNNoPositiveCharge=true;
break;
}}}}
return fiveBindingNNoPositiveCharge;
}, 1);

Clazz.newMeth(C$, 'isCyanoN$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
if (mol.getAtomicNo$I(atom) != 7) {
return false;
}var nConn=mol.getConnAtoms$I(atom);
if (nConn != 1) {
return false;
}var indexConn=mol.getConnAtom$I$I(atom, 0);
var bond=mol.getBond$I$I(atom, indexConn);
if (mol.getBondOrder$I(bond) != 3) {
return false;
}return true;
}, 1);

Clazz.newMeth(C$, 'isThioEther$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
if (mol.getAtomicNo$I(atom) != 16) {
return false;
}var nConn=mol.getConnAtoms$I(atom);
if (nConn != 2) {
return false;
}var thio=true;
for (var i=0; i < nConn; i++) {
var indexConn=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(indexConn) != 6) {
thio=false;
break;
}}
return thio;
}, 1);

Clazz.newMeth(C$, 'isWildcard$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
if (mol.getAtomicNo$I(atom) == 0) {
return true;
}return false;
}, 1);

Clazz.newMeth(C$, 'isSulfoxyGroup$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
if (mol.getAtomicNo$I(atom) != 16) {
return false;
}var nConn=mol.getConnAtoms$I(atom);
var oxy=false;
for (var i=0; i < nConn; i++) {
var indexConn=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(indexConn) == 8) {
oxy=true;
break;
}}
return oxy;
}, 1);

Clazz.newMeth(C$, 'isIsolatedCarbon$com_actelion_research_chem_StereoMolecule$I$IA',  function (mol, indexAtCentral, arrIndexAt) {
var isolated=true;
var nConnected=mol.getConnAtoms$I(indexAtCentral);
var arrConnected=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
for (var i=0; i < nConnected; i++) {
arrConnected[mol.getConnAtom$I$I(indexAtCentral, i)]=true;
}
for (var indexAt, $indexAt = 0, $$indexAt = arrIndexAt; $indexAt<$$indexAt.length&&((indexAt=($$indexAt[$indexAt])),1);$indexAt++) {
if (!arrConnected[indexAt]) {
continue;
}if (mol.getAtomicNo$I(indexAt) == 6) {
isolated=false;
break;
}}
return isolated;
}, 1);

Clazz.newMeth(C$, 'extractAromaticRing$com_actelion_research_chem_StereoMolecule$IA',  function (mol, arrIndexAt) {
var rc=mol.getRingSet$();
var arrRingMemberMarker=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
var arrIndexAromaticRing=null;
for (var i=0; i < rc.getSize$(); i++) {
if (!rc.isAromatic$I(i)) {
continue;
}$I$(12).fill$ZA$Z(arrRingMemberMarker, false);
var arrRingAtoms=rc.getRingAtoms$I(i);
for (var indexRingAtom, $indexRingAtom = 0, $$indexRingAtom = arrRingAtoms; $indexRingAtom<$$indexRingAtom.length&&((indexRingAtom=($$indexRingAtom[$indexRingAtom])),1);$indexRingAtom++) {
arrRingMemberMarker[indexRingAtom]=true;
}
var sum=0;
for (var indexAt, $indexAt = 0, $$indexAt = arrIndexAt; $indexAt<$$indexAt.length&&((indexAt=($$indexAt[$indexAt])),1);$indexAt++) {
if (arrRingMemberMarker[indexAt]) {
++sum;
}}
if (sum == arrRingAtoms.length) {
arrIndexAromaticRing=arrRingAtoms;
break;
}}
return arrIndexAromaticRing;
}, 1);

Clazz.newMeth(C$, 'getNumCyanoGroups$com_actelion_research_chem_StereoMolecule',  function (mol) {
var n=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (C$.isCyanoN$com_actelion_research_chem_StereoMolecule$I(mol, i)) {
++n;
}}
return n;
}, 1);

Clazz.newMeth(C$, 'getTotalCharge$com_actelion_research_chem_StereoMolecule',  function (mol) {
var n=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
n+=mol.getAtomCharge$I(i);
}
return n;
}, 1);

Clazz.newMeth(C$, 'getNumAtomsCharged$com_actelion_research_chem_StereoMolecule',  function (mol) {
var n=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (mol.getAtomCharge$I(i) != 0) {
++n;
}}
return n;
}, 1);

Clazz.newMeth(C$, 'getNumAlcoholicOxygen$com_actelion_research_chem_StereoMolecule',  function (mol) {
var n=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (C$.isAlcoholicOxygen$com_actelion_research_chem_StereoMolecule$I(mol, i)) {
++n;
}}
return n;
}, 1);

Clazz.newMeth(C$, 'getNumThioEther$com_actelion_research_chem_StereoMolecule',  function (mol) {
var n=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (C$.isThioEther$com_actelion_research_chem_StereoMolecule$I(mol, i)) {
++n;
}}
return n;
}, 1);

Clazz.newMeth(C$, 'getNumSulfOxyGroups$com_actelion_research_chem_StereoMolecule',  function (mol) {
var n=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (C$.isSulfoxyGroup$com_actelion_research_chem_StereoMolecule$I(mol, i)) {
++n;
}}
return n;
}, 1);

Clazz.newMeth(C$, 'getNumWildcards$com_actelion_research_chem_StereoMolecule',  function (mol) {
var n=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (C$.isWildcard$com_actelion_research_chem_StereoMolecule$I(mol, i)) {
++n;
}}
return n;
}, 1);

Clazz.newMeth(C$, 'isAlcoholicOxygen$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
if (mol.getAtomicNo$I(atom) != 8 || mol.isAromaticAtom$I(atom) ) return false;
var nConnected=mol.getConnAtoms$I(atom);
if (nConnected != 1) {
return false;
}var indConn=mol.getConnAtom$I$I(atom, 0);
if (mol.getAtomicNo$I(indConn) != 6) {
return false;
}if ($I$(2).getNegativeNeighbourCount$com_actelion_research_chem_StereoMolecule$I(mol, indConn) > 1) {
return false;
}return true;
}, 1);

Clazz.newMeth(C$, 'isEtherOxygenAtAromatic$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
var aromaticEtherO=false;
if (mol.getAtomicNo$I(atom) != 8 || mol.isAromaticAtom$I(atom) ) return false;
var nConnected=mol.getConnAtoms$I(atom);
if (nConnected != 2) {
return false;
}var indConn1=mol.getConnAtom$I$I(atom, 0);
var indConn2=mol.getConnAtom$I$I(atom, 1);
if (mol.isAromaticAtom$I(indConn1)) {
aromaticEtherO=true;
} else if (mol.isAromaticAtom$I(indConn2)) {
aromaticEtherO=true;
}return aromaticEtherO;
}, 1);

Clazz.newMeth(C$, 'isCarboxyC$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
if (mol.getAtomicNo$I(atom) != 6 || mol.getAtomPi$I(atom) != 0 ) return false;
var carboxyO=false;
var etherO=false;
for (var i=0; i < mol.getConnAtoms$I(atom); i++) {
var conn=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(conn) == 6) {
var bond=mol.getBond$I$I(atom, conn);
var bo=mol.getBondOrder$I(bond);
if (bo == 1) {
etherO=true;
} else if (bo == 2) {
carboxyO=true;
}}}
var carboxyC=false;
if (carboxyO && etherO ) {
carboxyC=true;
}return carboxyC;
}, 1);

Clazz.newMeth(C$, 'replaceAtoms$com_actelion_research_chem_ExtendedMoleculeA$I$I',  function (arr, atnoOrig, atnoRpl) {
var cc=0;
for (var i=0; i < arr.length; i++) {
cc+=C$.replaceAtoms$com_actelion_research_chem_ExtendedMolecule$I$I(arr[i], atnoOrig, atnoRpl);
}
return cc;
}, 1);

Clazz.newMeth(C$, 'replaceAtoms$com_actelion_research_chem_ExtendedMolecule$I$I',  function (mol, atnoOrig, atnoRpl) {
var cc=0;
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (mol.getAtomicNo$I(i) == atnoOrig) {
mol.setAtomicNo$I$I(i, atnoRpl);
++cc;
}}
return cc;
}, 1);

Clazz.newMeth(C$, 'removeSubStructures$java_util_List',  function (liInput) {
var sss=Clazz.new_($I$(6,1));
var li=Clazz.new_($I$(13,1).c$$java_util_Collection,[liInput]);
for (var i=li.size$() - 1; i >= 0; i--) {
var mol1=li.get$I(i);
for (var j=0; j < li.size$(); j++) {
if (i != j) {
var mol2=li.get$I(j);
if (mol1.getAtoms$() < mol2.getAtoms$()) {
sss.setMol$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule(mol1, mol2);
if (sss.isFragmentInMolecule$()) {
li.remove$I(i);
break;
}}}}
}
return li;
}, 1);

Clazz.newMeth(C$, 'removeSubstructuresFromMolecule$com_actelion_research_chem_StereoMolecule$java_util_List',  function (mol, liFragment) {
var molReduced=Clazz.new_($I$(7,1).c$$com_actelion_research_chem_Molecule,[mol]);
molReduced.ensureHelperArrays$I(7);
var sss=Clazz.new_($I$(6,1));
var hsIndexMatchingAtoms=Clazz.new_($I$(14,1));
for (var frag, $frag = liFragment.iterator$(); $frag.hasNext$()&&((frag=($frag.next$())),1);) {
sss.setMol$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule(frag, molReduced);
if (sss.findFragmentInMolecule$() > 0) {
var liMatch=sss.getMatchList$();
hsIndexMatchingAtoms.clear$();
for (var arrMatch, $arrMatch = liMatch.iterator$(); $arrMatch.hasNext$()&&((arrMatch=($arrMatch.next$())),1);) {
for (var i=0; i < arrMatch.length; i++) {
hsIndexMatchingAtoms.add$O(Integer.valueOf$I(arrMatch[i]));
}
}
var arrIndexMatchingAtomsUnique=$I$(9).toIntArray$java_util_Collection(hsIndexMatchingAtoms);
molReduced.deleteAtoms$IA(arrIndexMatchingAtomsUnique);
molReduced.ensureHelperArrays$I(7);
}}
return molReduced;
}, 1);

Clazz.newMeth(C$, 'removeSubstructureFromMolecule$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule',  function (mol, frag) {
var molReduced=Clazz.new_($I$(7,1).c$$com_actelion_research_chem_Molecule,[mol]);
molReduced.ensureHelperArrays$I(7);
var sss=Clazz.new_($I$(6,1));
sss.setMol$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule(frag, molReduced);
if (sss.findFragmentInMolecule$() > 0) {
var liMatch=sss.getMatchList$();
if (liMatch.size$() > 1) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Fragment found more than once!"]);
}if (liMatch.size$() == 1) {
var arrMatchIndex=liMatch.get$I(0);
molReduced.deleteAtoms$IA(arrMatchIndex);
molReduced.ensureHelperArrays$I(7);
}}return molReduced;
}, 1);

Clazz.newMeth(C$, 'removeWildcards$com_actelion_research_chem_StereoMolecule',  function (mol) {
var molReduced=Clazz.new_($I$(7,1).c$$com_actelion_research_chem_Molecule,[mol]);
molReduced.ensureHelperArrays$I(7);
for (var i=molReduced.getAtoms$() - 1; i >= 0; i--) {
if (molReduced.getAtomicNo$I(i) == 0) {
molReduced.deleteAtom$I(i);
}}
molReduced.ensureHelperArrays$I(7);
return molReduced;
}, 1);

Clazz.newMeth(C$, 'setColorMCS2Molecule$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule',  function (mol, molMCS) {
for (var i=0; i < mol.getAtoms$(); i++) {
mol.setAtomColor$I$I(i, 0);
}
var sss=Clazz.new_($I$(6,1));
sss.setMol$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule(molMCS, mol);
if (sss.findFragmentInMolecule$() > 0) {
var liMatch=sss.getMatchList$();
var arrIndexMatch=liMatch.get$I(0);
for (var i=0; i < arrIndexMatch.length; i++) {
mol.setAtomColor$I$I(arrIndexMatch[i], 64);
}
}}, 1);

Clazz.newMeth(C$, 'setColorMolecule$com_actelion_research_chem_StereoMolecule$IA',  function (mol, arrIndexMatch) {
for (var i=0; i < mol.getAtoms$(); i++) {
mol.setAtomColor$I$I(i, 0);
}
for (var i=0; i < arrIndexMatch.length; i++) {
mol.setAtomColor$I$I(arrIndexMatch[i], 64);
}
}, 1);

Clazz.newMeth(C$, 'setColorMoleculeFromBondIndex$com_actelion_research_chem_StereoMolecule$IA$I',  function (mol, arrIndexBonds, color) {
for (var i=0; i < arrIndexBonds.length; i++) {
var indexAtom1=mol.getBondAtom$I$I(0, arrIndexBonds[i]);
var indexAtom2=mol.getBondAtom$I$I(1, arrIndexBonds[i]);
mol.setAtomColor$I$I(indexAtom1, color);
mol.setAtomColor$I$I(indexAtom2, color);
}
}, 1);

Clazz.newMeth(C$, 'setCoordinatesNull$com_actelion_research_chem_StereoMolecule',  function (mol) {
for (var i=0; i < mol.getAtoms$(); i++) {
mol.setAtomX$I$D(i, 0);
mol.setAtomY$I$D(i, 0);
mol.setAtomZ$I$D(i, 0);
}
}, 1);

Clazz.newMeth(C$, 'getColorVectorSubstructure$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$I',  function (mol, frag, atomColor) {
var sss=Clazz.new_($I$(6,1));
sss.setMol$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule(frag, mol);
var hsAtomIndex=Clazz.new_($I$(14,1));
if (sss.findFragmentInMolecule$() > 0) {
var liMatch=sss.getMatchList$();
var arr=liMatch.get$I(0);
for (var i=0; i < arr.length; i++) {
hsAtomIndex.add$O(Integer.valueOf$I(arr[i]));
}
}var sAtomColor=C$.getColorRecord$com_actelion_research_chem_Molecule$java_util_Collection$I(mol, hsAtomIndex, atomColor);
return sAtomColor;
}, 1);

Clazz.newMeth(C$, 'getSimilarity$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_descriptor_DescriptorHandler',  function (m1, m2, dh) {
var d1=dh.createDescriptor$O(m1);
var d2=dh.createDescriptor$O(m2);
return dh.getSimilarity$O$O(d1, d2);
}, 1);

Clazz.newMeth(C$, 'getSphere$com_actelion_research_chem_StereoMolecule$I$I',  function (mol, rootAtom, depth) {
mol.ensureHelperArrays$I(7);
var fragment=Clazz.new_([mol.getAtoms$(), mol.getBonds$()],$I$(7,1).c$$I$I);
var atomList=Clazz.array(Integer.TYPE, [mol.getAtoms$()]);
var atomMask=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
if (rootAtom != 0) $I$(12).fill$ZA$Z(atomMask, false);
var min=0;
var max=0;
for (var sphere=0; sphere < depth && max < mol.getAtoms$() ; sphere++) {
if (max == 0) {
atomList[0]=rootAtom;
atomMask[rootAtom]=true;
max=1;
} else {
var newMax=max;
for (var i=min; i < max; i++) {
var atom=atomList[i];
for (var j=0; j < mol.getConnAtoms$I(atom); j++) {
var connAtom=mol.getConnAtom$I$I(atom, j);
if (!atomMask[connAtom]) {
atomMask[connAtom]=true;
atomList[newMax++]=connAtom;
}}
}
min=max;
max=newMax;
}mol.copyMoleculeByAtoms$com_actelion_research_chem_ExtendedMolecule$ZA$Z$IA(fragment, atomMask, true, null);
}
return fragment;
}, 1);

Clazz.newMeth(C$, 'getAtomicNoRGroup$I',  function (r) {
if (r > C$.arrRGroupsAtomicNo.length) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,[""]);
}return C$.arrRGroupsAtomicNo[r - 1];
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.arrRGroupsAtomicNo=Clazz.array(Integer.TYPE, -1, [142, 143, 144, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141]);
C$.arrRGroupsSymbol=Clazz.array(String, -1, ["R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8", "R9", "R10", "R11", "R12", "R13", "R14", "R15", "R16"]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:34 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
