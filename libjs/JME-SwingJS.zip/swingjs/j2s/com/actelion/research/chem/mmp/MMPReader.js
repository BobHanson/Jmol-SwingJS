(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mmp"),p$1={},p$2={},I$=[[0,'java.util.ArrayList','java.util.Arrays','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.IDCodeParser','com.actelion.research.chem.reaction.Reaction','com.actelion.research.chem.reaction.ReactionEncoder','java.util.HashMap','com.actelion.research.chem.mmp.MMPUniqueFragments','com.actelion.research.chem.mmp.MMPPropertyCalculator','java.util.regex.Pattern','java.util.LinkedHashMap','com.actelion.research.chem.mmp.MMPFragmenter',['com.actelion.research.chem.mmp.MMPReader','.DataField'],['com.actelion.research.chem.mmp.MMP','.MoleculeIndex'],'java.util.HashSet','StringBuilder','java.text.DecimalFormat',['com.actelion.research.chem.mmp.MMPReader','.MatchedMolecularPairExamples'],'java.util.Collections',['com.actelion.research.chem.mmp.MMPReader','.MatchedMolecularPair'],'java.util.Random','java.awt.image.BufferedImage','com.actelion.research.gui.generic.GenericRectangle','com.actelion.research.chem.ExtendedDepictor','com.actelion.research.gui.swing.SwingDrawContext','java.awt.RenderingHints','java.io.ByteArrayOutputStream',['com.actelion.research.util.Base64','.OutputStream'],'javax.imageio.ImageIO']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MMPReader", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['DataField',1],['MatchedMolecularPairExamples',2],['MatchedMolecularPair',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['datasetName','date','version'],'O',['wholeMoleculesIndex','java.util.HashMap','molecules','java.util.List','+dataFields','+uniqueFragmentsIndex','mmpUniqueFragments','com.actelion.research.chem.mmp.MMPUniqueFragments','mmpFragmentsIndex','java.util.HashMap','+mmpIndex','keysMinAtoms','Integer','mPropertyCalculator','com.actelion.research.chem.mmp.MMPPropertyCalculator']]
,['O',['NUMBER_OF_EXAMPLES_SORT','java.util.Comparator','+SIMILARITY_SORT','+EXAMPLES_SIMILARITY_SORT']]]

Clazz.newMeth(C$, 'c$$java_io_BufferedReader$Z',  function (br, verbose) {
;C$.$init$.apply(this);
this.mmpFragmentsIndex=Clazz.new_($I$(7,1));
this.mmpIndex=Clazz.new_($I$(7,1));
this.mmpUniqueFragments=Clazz.new_($I$(8,1));
this.mPropertyCalculator=Clazz.new_($I$(9,1));
p$2.readMMPFile$java_io_BufferedReader$Z.apply(this, [br, verbose]);
br.close$();
}, 1);

Clazz.newMeth(C$, 'readMMPFile$java_io_BufferedReader$Z',  function (br, verbose) {
var rowCounts=Clazz.new_($I$(7,1));
var rowCountsCounter=0;
var strLine;
var pattern1=$I$(10,"compile$S",["<(.*?)=\"(.*?)\">"]);
var pattern2=$I$(10,"compile$S",["<(.*?rowcount)=([0-9]*?)>"]);
while ((strLine=br.readLine$()) != null  && rowCountsCounter < 4 ){
var matcher1=pattern1.matcher$CharSequence(strLine);
if (matcher1.find$()) {
if (matcher1.group$I(1).equals$O("dataset")) {
this.datasetName=matcher1.group$I(2);
} else if (matcher1.group$I(1).equals$O("date")) {
this.date=matcher1.group$I(2);
} else if (matcher1.group$I(1).equals$O("keysminatoms")) {
this.keysMinAtoms=Integer.valueOf$I(Integer.parseInt$S(matcher1.group$I(2)));
} else if (matcher1.group$I(1).equals$O("version")) {
this.version=matcher1.group$I(2);
}} else {
var matcher2=pattern2.matcher$CharSequence(strLine);
if (matcher2.find$()) {
rowCounts.put$O$O(matcher2.group$I(1), Integer.valueOf$I(Integer.parseInt$S(matcher2.group$I(2))));
++rowCountsCounter;
}}}
if (rowCountsCounter < 4) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["General: cannot find the four rowcount lines"]);
}if (verbose) {
System.out.println$S("The dataset contains " + rowCounts.get$O("moleculesrowcount") + " molecules, " + rowCounts.get$O("mmpuniquefragmentsrowcount") + " unique fragments, " + rowCounts.get$O("mmpfragmentsrowcount") + " molecules fragments combinations and " + rowCounts.get$O("mmprowcount") + " MMPs." );
System.out.println$S("                  0        10        20        30        40        50        60        70        80        90       100");
}p$2.readMolecules$java_io_BufferedReader$I$Z.apply(this, [br, (rowCounts.get$O("moleculesrowcount")).$c(), verbose]);
p$2.readUniqueFragments$java_io_BufferedReader$I$Z.apply(this, [br, (rowCounts.get$O("mmpuniquefragmentsrowcount")).$c(), verbose]);
p$2.readFragments$java_io_BufferedReader$I$Z.apply(this, [br, (rowCounts.get$O("mmpfragmentsrowcount")).$c(), verbose]);
p$2.readMMPs$java_io_BufferedReader$I$Z.apply(this, [br, (rowCounts.get$O("mmprowcount")).$c(), verbose]);
}, p$2);

Clazz.newMeth(C$, 'readMolecules$java_io_BufferedReader$I$Z',  function (br, rowCount, verbose) {
this.wholeMoleculesIndex=Clazz.new_($I$(11,1));
this.dataFields=Clazz.new_($I$(1,1));
this.molecules=Clazz.new_($I$(1,1));
this.keysMinAtoms=$I$(12).KEYS_MIN_ATOMS;
if (verbose) System.out.print$S("Molecules:        #");
try {
var strLine;
var moleculesBlock=false;
var linesToRead=11;
var entries=0;
var lastEntryIndex=-1;
var tagPattern=$I$(10,"compile$S",["<(columnName=.*?)>"]);
var attValue=$I$(10,"compile$S",["(\\w+)=\"(.*?)\""]);
while ((strLine=br.readLine$()) != null  && entries < rowCount ){
if (strLine.startsWith$S("<molecules>") || (moleculesBlock == true  && linesToRead > 0 ) ) {
moleculesBlock=true;
var matcher=tagPattern.matcher$CharSequence(strLine);
if (matcher.find$()) {
matcher=attValue.matcher$CharSequence(matcher.group$I(1));
var fieldName=null;
var longFieldName=null;
var categoryName=null;
var percentile5=null;
var percentile95=null;
while (matcher.find$()){
if (matcher.group$I(1).equals$O("columnName")) {
fieldName=matcher.group$I(2);
} else if (matcher.group$I(1).equals$O("longName")) {
longFieldName=matcher.group$I(2);
} else if (matcher.group$I(1).equals$O("percentile5")) {
percentile5=matcher.group$I(2);
} else if (matcher.group$I(1).equals$O("percentile95")) {
percentile95=matcher.group$I(2);
} else if (matcher.group$I(1).equals$O("category")) {
categoryName=matcher.group$I(2);
}}
if (fieldName != null  && !fieldName.equals$O("moleculeIndex")  && !fieldName.equals$O("idcoordinates2D")  && !fieldName.equals$O("molecule")  && !fieldName.equals$O("moleculeName") ) {
this.dataFields.add$O(Clazz.new_($I$(13,1).c$$S$S$S$S$S,[this, null, fieldName, longFieldName, categoryName, percentile5, percentile95]));
++linesToRead;
}}--linesToRead;
} else if (moleculesBlock == true  && linesToRead == 0 ) {
var items=strLine.split$S$I("\t", -1);
if (items.length == this.dataFields.size$() + 4) {
items=strLine.split$S$I("\t", 5);
var data=items[4].split$S$I("\t", -1);
var molIndex=Integer.parseInt$S(items[0]);
var moleculeIndex;
var moleculesIndex=Clazz.new_($I$(1,1));
if (molIndex == lastEntryIndex) {
moleculeIndex=Clazz.new_($I$(14,1).c$$I$S$SA,[molIndex, items[3], data]);
moleculesIndex=this.wholeMoleculesIndex.get$O(items[2]);
} else {
moleculeIndex=Clazz.new_($I$(14,1).c$$I$S$S$S$SA,[molIndex, items[1], items[2], items[3], data]);
this.molecules.add$O(items[2]);
if (this.molecules.size$() != Integer.parseInt$S(items[0]) + 1) {
System.out.println$I(this.molecules.size$());
}}moleculesIndex.add$O(moleculeIndex);
this.wholeMoleculesIndex.put$O$O(items[2], moleculesIndex);
p$2.printProgress$Z$I$I.apply(this, [verbose, rowCount, entries]);
++entries;
lastEntryIndex=molIndex;
} else if (strLine.startsWith$S("</molecules>")) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["molecules: Bad number of entries"]);
}}}
} catch (ioe) {
if (Clazz.exceptionOf(ioe,"java.io.IOException")){
} else {
throw ioe;
}
}
if (verbose) System.out.print$S("\n");
}, p$2);

Clazz.newMeth(C$, 'readUniqueFragments$java_io_BufferedReader$I$Z',  function (br, rowCount, verbose) {
this.uniqueFragmentsIndex=Clazz.new_($I$(1,1).c$$I,[rowCount]);
if (verbose) System.out.print$S("Unique Fragments: #");
try {
var strLine;
var mmpUniqueFragmentsBlock=false;
var linesToRead=17;
var entries=0;
while ((strLine=br.readLine$()) != null  && entries < rowCount ){
if (strLine.startsWith$S("<mmpUniqueFragments>") || (mmpUniqueFragmentsBlock == true  && linesToRead > 0 ) ) {
mmpUniqueFragmentsBlock=true;
--linesToRead;
} else if (mmpUniqueFragmentsBlock == true  && linesToRead == 0 ) {
var items=strLine.split$S$I("\t", -1);
if (items.length == 7) {
this.uniqueFragmentsIndex.add$O(items[0]);
this.mmpUniqueFragments.addFragment$S$I$SA(items[0], Integer.parseInt$S(items[1]), Clazz.array(String, -1, [items[2], items[3], items[4], items[5], items[6]]));
p$2.printProgress$Z$I$I.apply(this, [verbose, rowCount, entries]);
++entries;
} else if (strLine.startsWith$S("</mmpUniqueFragments>")) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["mmpUniqueFragments: Bad number of entries"]);
}}}
} catch (ioe) {
if (Clazz.exceptionOf(ioe,"java.io.IOException")){
} else {
throw ioe;
}
}
if (verbose) System.out.print$S("\n");
}, p$2);

Clazz.newMeth(C$, 'readFragments$java_io_BufferedReader$I$Z',  function (br, rowCount, verbose) {
if (verbose) System.out.print$S("Fragments:        #");
try {
var strLine;
var mmpFragmentsBlock=false;
var linesToRead=9;
var entries=0;
while ((strLine=br.readLine$()) != null  && entries < rowCount ){
if (strLine.startsWith$S("<mmpFragments>") || (mmpFragmentsBlock == true  && linesToRead > 0 ) ) {
mmpFragmentsBlock=true;
--linesToRead;
} else if (mmpFragmentsBlock == true  && linesToRead == 0 ) {
var items=strLine.split$S$I("\t", -1);
if (items.length == 5) {
if (items[3].equals$O("1")) {
p$2.addFragment$S$IA.apply(this, [items[0], Clazz.array(Integer.TYPE, -1, [Integer.parseInt$S(items[2]), Integer.parseInt$S(items[4])])]);
if ((this.mmpUniqueFragments.getFragmentAtoms$S(this.uniqueFragmentsIndex.get$I(Integer.parseInt$S(items[2])))).$c() < (this.keysMinAtoms).$c() ) {
p$2.addFragment$S$IA.apply(this, [items[2], Clazz.array(Integer.TYPE, -1, [Integer.parseInt$S(items[0]), Integer.parseInt$S(items[4])])]);
}} else {
p$2.addFragment$S$IA.apply(this, [items[0] + "\t" + items[1] , Clazz.array(Integer.TYPE, -1, [Integer.parseInt$S(items[2]), Integer.parseInt$S(items[4])])]);
}p$2.printProgress$Z$I$I.apply(this, [verbose, rowCount, entries]);
++entries;
}} else if (strLine.startsWith$S("</mmpFragments>")) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["mmpFragments: Bad number of entries"]);
}}
} catch (ioe) {
if (Clazz.exceptionOf(ioe,"java.io.IOException")){
} else {
throw ioe;
}
}
if (verbose) System.out.print$S("\n");
}, p$2);

Clazz.newMeth(C$, 'readMMPs$java_io_BufferedReader$I$Z',  function (br, rowCount, verbose) {
if (verbose) System.out.print$S("MMPs:             #");
try {
var strLine;
var mmpBlock=false;
var linesToRead=11;
var entries=0;
var value1Atoms=-1;
var tempMMPIndex=null;
while ((strLine=br.readLine$()) != null  && entries < rowCount ){
if (strLine.startsWith$S("<matchedMolecularPairs>") || (mmpBlock == true  && linesToRead > 0 ) ) {
mmpBlock=true;
--linesToRead;
} else if (mmpBlock == true  && linesToRead == 0 ) {
var items=strLine.split$S$I("\t", -1);
if (items.length == 7) {
if (this.version === "1.1" ) {
var val1Atoms=Integer.parseInt$S(items[1]);
if (val1Atoms != value1Atoms) {
if (tempMMPIndex != null ) {
this.mmpIndex.putAll$java_util_Map(tempMMPIndex);
}tempMMPIndex=Clazz.new_($I$(7,1));
value1Atoms=val1Atoms;
}tempMMPIndex=p$2.addTempMMP$java_util_HashMap$I$I$I$SA.apply(this, [tempMMPIndex, Integer.parseInt$S(items[0]), Integer.parseInt$S(items[3]), Integer.parseInt$S(items[2]), items[6].split$S$I("\\|", -1)]);
} else {
p$2.addMMP$I$I$I$SA.apply(this, [Integer.parseInt$S(items[0]), Integer.parseInt$S(items[3]), Integer.parseInt$S(items[2]), items[6].split$S$I("\\|", -1)]);
}p$2.printProgress$Z$I$I.apply(this, [verbose, rowCount, entries]);
++entries;
}} else if (strLine.startsWith$S("</matchedMolecularPairs>")) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["matchedMolecularPairs: Bad number of entries"]);
}}
if (tempMMPIndex != null ) {
this.mmpIndex.putAll$java_util_Map(tempMMPIndex);
}} catch (ioe) {
if (Clazz.exceptionOf(ioe,"java.io.IOException")){
} else {
throw ioe;
}
}
if (verbose) System.out.print$S("\n");
}, p$2);

Clazz.newMeth(C$, 'printProgress$Z$I$I',  function (verbose, rowCount, entries) {
if (verbose) {
var percentage=(entries + 1) * 100.0 / rowCount;
var one=100.0 / rowCount;
if (Math.floor(percentage) != Math.floor(percentage - one) ) {
if (Math.floor(percentage) % 10.0 == 0 ) {
System.out.print$S("#");
} else {
System.out.print$S(".");
}}}}, p$2);

Clazz.newMeth(C$, 'addFragment$S$IA',  function (keys, data) {
var datas=Clazz.new_($I$(1,1));
if (this.mmpFragmentsIndex.containsKey$O(keys)) {
datas=this.mmpFragmentsIndex.get$O(keys);
}datas.add$O(data);
this.mmpFragmentsIndex.put$O$O(keys, datas);
}, p$2);

Clazz.newMeth(C$, 'addTempMMP$java_util_HashMap$I$I$I$SA',  function (tempMMPIndex, value1FragmentIndex, value2Atoms, value2, examples) {
var val2_examples=Clazz.array(Integer.TYPE, [examples.length * 2 + 1]);
val2_examples[0]=value2;
var counter=1;
for (var value2AndExample, $value2AndExample = 0, $$value2AndExample = examples; $value2AndExample<$$value2AndExample.length&&((value2AndExample=($$value2AndExample[$value2AndExample])),1);$value2AndExample++) {
var items=value2AndExample.split$S(",");
val2_examples[counter]=Integer.parseInt$S(items[0]);
val2_examples[counter + 1]=Integer.parseInt$S(items[1]);
counter+=2;
}
var values2=Clazz.new_($I$(7,1));
var values2OfSizeX=Clazz.new_($I$(1,1));
if (tempMMPIndex.containsKey$O(Integer.valueOf$I(value1FragmentIndex))) {
values2=tempMMPIndex.get$O(Integer.valueOf$I(value1FragmentIndex));
if (values2.containsKey$O(Integer.valueOf$I(value2Atoms))) {
values2OfSizeX=values2.get$O(Integer.valueOf$I(value2Atoms));
}}values2OfSizeX.add$O(val2_examples);
values2.put$O$O(Integer.valueOf$I(value2Atoms), values2OfSizeX);
tempMMPIndex.put$O$O(Integer.valueOf$I(value1FragmentIndex), values2);
return tempMMPIndex;
}, p$2);

Clazz.newMeth(C$, 'addMMP$I$I$I$SA',  function (value1FragmentIndex, value2Atoms, value2, examples) {
var val2_examples=Clazz.array(Integer.TYPE, [examples.length * 2 + 1]);
val2_examples[0]=value2;
var counter=1;
for (var value2AndExample, $value2AndExample = 0, $$value2AndExample = examples; $value2AndExample<$$value2AndExample.length&&((value2AndExample=($$value2AndExample[$value2AndExample])),1);$value2AndExample++) {
var items=value2AndExample.split$S(",");
val2_examples[counter]=Integer.parseInt$S(items[0]);
val2_examples[counter + 1]=Integer.parseInt$S(items[1]);
counter+=2;
}
var values2=Clazz.new_($I$(7,1));
var values2OfSizeX=Clazz.new_($I$(1,1));
if (this.mmpIndex.containsKey$O(Integer.valueOf$I(value1FragmentIndex))) {
values2=this.mmpIndex.get$O(Integer.valueOf$I(value1FragmentIndex));
if (values2.containsKey$O(Integer.valueOf$I(value2Atoms))) {
values2OfSizeX=values2.get$O(Integer.valueOf$I(value2Atoms));
}}values2OfSizeX.add$O(val2_examples);
values2.put$O$O(Integer.valueOf$I(value2Atoms), values2OfSizeX);
this.mmpIndex.put$O$O(Integer.valueOf$I(value1FragmentIndex), values2);
}, p$2);

Clazz.newMeth(C$, 'fragmentToFragmentIndex$S',  function (fragment) {
if (this.uniqueFragmentsIndex.contains$O(fragment)) {
return Integer.valueOf$I(this.uniqueFragmentsIndex.indexOf$O(fragment));
}return null;
});

Clazz.newMeth(C$, 'fragmentToFragmentIndex$SA',  function (fragments) {
var retVal=Clazz.array(Integer, [fragments.length]);
for (var i=0; i < fragments.length; i++) {
retVal[i]=this.fragmentToFragmentIndex$S(fragments[i]);
}
return retVal;
});

Clazz.newMeth(C$, 'fragmentToFragmentSize$S',  function (fragment) {
return this.mmpUniqueFragments.getFragmentAtoms$S(fragment);
});

Clazz.newMeth(C$, 'getChemicalSpaceSize$S',  function (key) {
return this.getChemicalSpaceSize$SA(Clazz.array(String, -1, [key]));
});

Clazz.newMeth(C$, 'getChemicalSpaceSize$SA',  function (keys) {
var chemicalSpaceSize=0;
var keysIndex=this.fragmentToFragmentIndex$SA(keys);
var keysString=p$2.keysToKeysString$IntegerA.apply(this, [keysIndex]);
if (keysString != null  && this.mmpFragmentsIndex.containsKey$O(keysString) ) {
var chemicalSpace=this.mmpFragmentsIndex.get$O(keysString);
var molList=Clazz.new_($I$(15,1));
for (var chemSpace, $chemSpace = chemicalSpace.iterator$(); $chemSpace.hasNext$()&&((chemSpace=($chemSpace.next$())),1);) {
molList.add$O(Integer.valueOf$I(chemSpace[1]));
}
chemicalSpaceSize=molList.size$();
}return chemicalSpaceSize;
});

Clazz.newMeth(C$, 'getChemicalSpace$SA$S$S',  function (keys, value, dataField) {
var chemicalSpaceMolecules=Clazz.new_($I$(1,1));
var chemicalSpace=Clazz.new_($I$(1,1));
var keysIndex=this.fragmentToFragmentIndex$SA(keys);
var keysString=p$2.keysToKeysString$IntegerA.apply(this, [keysIndex]);
var dataFieldIndex=-1;
if (dataField != null ) {
for (var i=0; i < this.dataFields.size$(); i++) {
if (this.dataFields.get$I(i).fieldName.equals$O(dataField) || this.dataFields.get$I(i).longFieldName.equals$O(dataField) ) {
dataFieldIndex=i;
break;
}}
}if (keysString != null  && this.mmpFragmentsIndex.containsKey$O(keysString) ) {
chemicalSpace=this.mmpFragmentsIndex.get$O(keysString);
var molList=Clazz.new_($I$(15,1));
for (var chemSpace, $chemSpace = chemicalSpace.iterator$(); $chemSpace.hasNext$()&&((chemSpace=($chemSpace.next$())),1);) {
molList.add$O(Integer.valueOf$I(chemSpace[1]));
}
for (var molIndex, $molIndex = molList.iterator$(); $molIndex.hasNext$()&&((molIndex=($molIndex.next$())),1);) {
var idCode=this.molecules.get$I((molIndex).$c());
var idCoord=null;
for (var moleculeIndex, $moleculeIndex = this.wholeMoleculesIndex.get$O(idCode).iterator$(); $moleculeIndex.hasNext$()&&((moleculeIndex=($moleculeIndex.next$())),1);) {
if (idCoord == null ) {
idCoord=moleculeIndex.moleculeIDCoord;
}if (dataFieldIndex == -1) {
chemicalSpaceMolecules.add$O(idCode + "\t" + idCoord + "\t" + moleculeIndex.moleculeName );
} else {
chemicalSpaceMolecules.add$O(idCode + "\t" + idCoord + "\t" + moleculeIndex.moleculeName + "\t" + moleculeIndex.moleculeData[dataFieldIndex] );
}}
}
}return chemicalSpaceMolecules;
});

Clazz.newMeth(C$, 'getChemicalSpaceDWAR$S$SA$S',  function (moleculeIDCode, keys, dataField) {
var dataFieldIndex=-1;
if (dataField != null ) {
for (var i=0; i < this.dataFields.size$(); i++) {
if (this.dataFields.get$I(i).fieldName.equals$O(dataField) || this.dataFields.get$I(i).longFieldName.equals$O(dataField) ) {
dataFieldIndex=i;
dataField=this.dataFields.get$I(i).fieldName;
break;
}}
}var dWAR=Clazz.new_($I$(16,1));
dWAR.append$S("<datawarrior-fileinfo>\n");
dWAR.append$S("<version=\"3.1\">\n");
var chemicalSpace=this.getChemicalSpace$SA$S$S(keys, null, dataField);
dWAR.append$S("<rowcount=\"" + chemicalSpace.size$() + "\">\n" );
dWAR.append$S("</datawarrior-fileinfo>\n");
dWAR.append$S("<column properties>\n");
dWAR.append$S("<columnName=\"Structure\">\n");
dWAR.append$S("<columnProperty=\"specialType\tidcode\">\n");
dWAR.append$S("<columnName=\"idcoordinates2D\">\n");
dWAR.append$S("<columnProperty=\"specialType\tidcoordinates2D\">\n");
dWAR.append$S("<columnProperty=\"parent\tStructure\">\n");
dWAR.append$S("</column properties>\n");
if (dataField != null ) {
dWAR.append$S("Structure\tidcoordinates2D\tActelion No\t" + dataField + "\n" );
} else {
dWAR.append$S("Structure\tidcoordinates2D\tActelion No\n");
}for (var chemSpace, $chemSpace = chemicalSpace.iterator$(); $chemSpace.hasNext$()&&((chemSpace=($chemSpace.next$())),1);) {
dWAR.append$S(chemSpace + "\n");
}
dWAR.append$S("<datawarrior properties>\n");
if (dataFieldIndex != -1) {
dWAR.append$S("<columnDescriptionCount=\"1\">\n");
dWAR.append$S("<columnDescription_0=\"" + dataField + "\t" + this.dataFields.get$I(dataFieldIndex).longFieldName + "\">\n" );
dWAR.append$S("<colorMaxBackground__TableStructure=\"" + this.dataFields.get$I(dataFieldIndex).percentile95 + "\">\n" );
dWAR.append$S("<colorMinBackground__TableStructure=\"" + this.dataFields.get$I(dataFieldIndex).percentile5 + "\">\n" );
dWAR.append$S("<colorBackground__TableStructure_0=\"-13395457\">\n");
dWAR.append$S("<colorBackground__TableStructure_1=\"-39322\">\n");
dWAR.append$S("<colorColumnBackground__TableStructure=\"" + dataField + "\">\n" );
dWAR.append$S("<colorListModeBackground__TableStructure=\"straight\">\n");
}dWAR.append$S("<columnWidth_Table_Structure=\"150\">\n");
dWAR.append$S("<detailView=\"height[Data]=0.7;height[Structure]=0.3\">\n");
dWAR.append$S("<filter0=\"#browser#\t<disabled>\">\n");
dWAR.append$S("<filter1=\"#structure#\tStructure\">\n");
dWAR.append$S("<filter2=\"#double#	" + dataField + "\">\n" );
dWAR.append$S("<mainViewCount=\"2\">\n");
dWAR.append$S("<mainViewDockInfo0=\"root\">\n");
dWAR.append$S("<mainViewDockInfo1=\"Table\tright\t0.5\">\n");
dWAR.append$S("<mainViewName0=\"Table\">\n");
dWAR.append$S("<mainViewName1=\"Structure\">\n");
dWAR.append$S("<mainViewType0=\"tableView\">\n");
dWAR.append$S("<mainViewType1=\"structureView\">\n");
dWAR.append$S("<rightSplitting=\"0.6\">\n");
dWAR.append$S("<rowHeight_Table=\"80\">\n");
dWAR.append$S("<structureGridColumn_Structure=\"Structure\">\n");
dWAR.append$S("<structureGridColumns_Structure=\"4\">\n");
dWAR.append$S("</datawarrior properties>\n");
return dWAR.toString();
});

Clazz.newMeth(C$, 'getMMPsDWAR$S$SA$S$S$I$java_util_List',  function (moleculeIDCode, keys, value1, value2, replacementSize, properties) {
var transformations=p$2.getTransformations$S$SA$S$I$I$S.apply(this, [moleculeIDCode, keys, value1, replacementSize, replacementSize, null]);
var formatter=Clazz.new_($I$(17,1).c$$S,["#.##"]);
var dWAR=Clazz.new_($I$(16,1));
dWAR.append$S("<datawarrior-fileinfo>\n");
dWAR.append$S("<version=\"3.1\">\n");
for (var transformation, $transformation = transformations.iterator$(); $transformation.hasNext$()&&((transformation=($transformation.next$())),1);) {
if (transformation.value2.equals$O(value2)) {
dWAR.append$S("<rowcount=\"" + transformation.numberOfExamples + "\">\n" );
break;
}}
dWAR.append$S("</datawarrior-fileinfo>\n");
dWAR.append$S("<column properties>\n");
dWAR.append$S("<columnName=\"Structure (1)\">\n");
dWAR.append$S("<columnProperty=\"specialType\tidcode\">\n");
dWAR.append$S("<columnName=\"idcoordinates2D (1)\">\n");
dWAR.append$S("<columnProperty=\"specialType\tidcoordinates2D\">\n");
dWAR.append$S("<columnProperty=\"parent\tStructure (1)\">\n");
dWAR.append$S("<columnName=\"Structure (2)\">\n");
dWAR.append$S("<columnProperty=\"specialType\tidcode\">\n");
dWAR.append$S("<columnName=\"idcoordinates2D (2)\">\n");
dWAR.append$S("<columnProperty=\"specialType\tidcoordinates2D\">\n");
dWAR.append$S("<columnProperty=\"parent\tStructure (2)\">\n");
dWAR.append$S("<columnName=\"FragFp 2\">\n");
dWAR.append$S("<columnProperty=\"specialType\tFragFp\">\n");
dWAR.append$S("<columnProperty=\"parent\tStructure (2)\">\n");
dWAR.append$S("<columnProperty=\"version\t1.2.1\">\n");
dWAR.append$S("</column properties>\n");
dWAR.append$S("FragFp 2\tStructure (1)\tidcoordinates2D (1)\tStructure (2)\tidcoordinates2D (2)\tActelion No (1)\tActelion No (2)\tSimilarity");
for (var property, $property = properties.iterator$(); $property.hasNext$()&&((property=($property.next$())),1);) {
dWAR.append$S("\t" + property + " (1)\t" + property + " (2)\t" + property + " (delta)" );
}
dWAR.append$S("\n");
for (var transformation, $transformation = transformations.iterator$(); $transformation.hasNext$()&&((transformation=($transformation.next$())),1);) {
if (transformation.value2.equals$O(value2)) {
for (var j=0; j < transformation.numberOfExamples; j++) {
var example1=transformation.mmpExamples.get$I(j).example1.get$I(0);
var example2=transformation.mmpExamples.get$I(j).example2.get$I(0);
dWAR.append$S("\t" + example1.moleculeIDCode + "\t" + example1.moleculeIDCoord + "\t" + example2.moleculeIDCode + "\t" + example2.moleculeIDCoord + "\t" + example1.moleculeName + "\t" + example2.moleculeName + "\t" + Integer.toString$I((transformation.similarities.get$I(j)).$c()) );
for (var property, $property = properties.iterator$(); $property.hasNext$()&&((property=($property.next$())),1);) {
var fieldIndex=-1;
for (var i=0; i < this.dataFields.size$(); i++) {
if (this.dataFields.get$I(i).fieldName.equals$O(property) || this.dataFields.get$I(i).longFieldName.equals$O(property) ) {
fieldIndex=i;
break;
}}
if (fieldIndex != -1) {
var data1=example1.moleculeData[fieldIndex];
var data2="";
if (example2.moleculeData != null ) {
data2=example2.moleculeData[fieldIndex];
}var delta="";
if (!data1.equals$O("") && !data1.startsWith$S(">") && !data1.startsWith$S("<") && !data2.equals$O("") && !data2.startsWith$S(">") && !data2.startsWith$S("<")  ) {
delta=formatter.format$D(Double.parseDouble$S(data2) - Double.parseDouble$S(data1));
}dWAR.append$S("\t" + data1 + "\t" + data2 + "\t" + delta );
}}
dWAR.append$S("\n");
}
}}
dWAR.append$S("<datawarrior properties>\n");
if (properties.size$() > 0) {
dWAR.append$S("<axisColumn_2D View_0=\"" + properties.get$I(0) + " (1)\">\n" );
dWAR.append$S("<axisColumn_2D View_1=\"" + properties.get$I(0) + " (2)\">\n" );
}dWAR.append$S("<chartType_2D View=\"scatter\">\n");
dWAR.append$S("<columnDescriptionCount=\"" + (properties.size$() * 3 + 1) + "\">\n" );
dWAR.append$S("<columnDescription_0=\"Similarity\tSimilarity of the local environment. 6: seed compound; 0-5: number of atoms identical to the seed compound; -1: key not found\">\n");
var descriptionCounter=1;
for (var property, $property = properties.iterator$(); $property.hasNext$()&&((property=($property.next$())),1);) {
var fieldIndex=-1;
for (var i=0; i < this.dataFields.size$(); i++) {
if (this.dataFields.get$I(i).fieldName.equals$O(property) || this.dataFields.get$I(i).longFieldName.equals$O(property) ) {
fieldIndex=i;
break;
}}
if (fieldIndex != -1) {
dWAR.append$S("<columnDescription_" + descriptionCounter + "=\"" + property + " (1)	First compound " + this.dataFields.get$I(fieldIndex).longFieldName + "\">\n" );
dWAR.append$S("<columnDescription_" + (descriptionCounter + 1) + "=\"" + property + " (2)	Second compound " + this.dataFields.get$I(fieldIndex).longFieldName + "\">\n" );
dWAR.append$S("<columnDescription_" + (descriptionCounter + 2) + "=\"" + property + " (delta)	Difference of " + this.dataFields.get$I(fieldIndex).longFieldName + "\">\n" );
descriptionCounter+=3;
}}
dWAR.append$S("<columnWidth_Table_Structure (1)=\"150\">\n");
dWAR.append$S("<columnWidth_Table_Structure (2)=\"150\">\n");
dWAR.append$S("<detailView=\"height[Data]=0.5;height[Structure (1)]=0.25;height[Structure (2)]=0.25\">\n");
dWAR.append$S("<filter0=\"#browser#\t#disabled#\tStructure (1)\">\n");
dWAR.append$S("<filter1=\"#structure#\tStructure (2)\">\n");
dWAR.append$S("<filter2=\"#category#\tSimilarity\">\n");
var filterCounter=3;
for (var property, $property = properties.iterator$(); $property.hasNext$()&&((property=($property.next$())),1);) {
dWAR.append$S("<filter" + filterCounter + "=\"#double#	" + property + " (1)	#disabled#\">\n" );
dWAR.append$S("<filter" + (filterCounter + 1) + "=\"#double#	" + property + " (2)	#disabled#\">\n" );
dWAR.append$S("<filter" + (filterCounter + 2) + "=\"#double#	" + property + " (delta)	#disabled#\">\n" );
filterCounter+=3;
}
dWAR.append$S("<mainSplitting=\"0.8\">\n");
dWAR.append$S("<mainView=\"Structure (2)\">\n");
dWAR.append$S("<mainViewCount=\"4\">\n");
dWAR.append$S("<mainViewDockInfo0=\"root\">\n");
dWAR.append$S("<mainViewDockInfo1=\"Table\tbottom\t0.7\">\n");
dWAR.append$S("<mainViewDockInfo2=\"Table\tright\t0.5\">\n");
dWAR.append$S("<mainViewDockInfo3=\"Structure (1)\tright\t0.5\">\n");
dWAR.append$S("<mainViewName0=\"Table\">\n");
dWAR.append$S("<mainViewName1=\"2D View\">\n");
dWAR.append$S("<mainViewName2=\"Structure (1)\">\n");
dWAR.append$S("<mainViewName3=\"Structure (2)\">\n");
dWAR.append$S("<mainViewType0=\"tableView\">\n");
dWAR.append$S("<mainViewType1=\"2Dview\">\n");
dWAR.append$S("<mainViewType2=\"structureView\">\n");
dWAR.append$S("<mainViewType3=\"structureView\">\n");
dWAR.append$S("<rightSplitting=\"0.6\">\n");
dWAR.append$S("<rowHeight_Table=\"80\">\n");
dWAR.append$S("<showNaNValues_2D View=\"true\">\n");
dWAR.append$S("<structureGridColumn_Structure (1)=\"Structure (1)\">\n");
dWAR.append$S("<structureGridColumn_Structure (2)=\"Structure (2)\">\n");
dWAR.append$S("<structureGridColumns_Structure (1)=\"3\">\n");
dWAR.append$S("<structureGridColumns_Structure (2)=\"3\">\n");
dWAR.append$S("</datawarrior properties>\n");
return dWAR.toString();
});

Clazz.newMeth(C$, 'getTransformationsSize$S$I$I',  function (value1, minAtoms, maxAtoms) {
var mmpSize=0;
var value1Fragment=this.mmpUniqueFragments.fragmentIDToFragment$S(value1);
if (value1Fragment != null ) {
var value1Atoms=Integer.valueOf$I(value1Fragment.getFragmentAtoms$());
var value1Index=Integer.valueOf$I(value1Fragment.getFragmentIndex$());
if (value1Index != null  && this.mmpIndex.containsKey$O(value1Index) ) {
var mmps=this.mmpIndex.get$O(value1Index);
for (var size=((value1Atoms).$c() + minAtoms)|0; size <= ((value1Atoms).$c() + maxAtoms)|0; size++) {
if (mmps.containsKey$O(Integer.valueOf$I(size))) {
mmpSize+=mmps.get$O(Integer.valueOf$I(size)).size$();
}}
}}return mmpSize;
});

Clazz.newMeth(C$, 'getTransformations$S$SA$S$I$I$S',  function (moleculeIDCode, keys, value1, minAtoms, maxAtoms, sortBy) {
var retVal=Clazz.new_($I$(1,1));
var keyIndex=this.fragmentToFragmentIndex$SA(keys);
var keyIndexString=null;
if (keyIndex.length == 1 && keyIndex[0] != null  ) {
keyIndexString=Integer.toString$I((keyIndex[0]).$c());
} else if (keyIndex.length == 2 && keyIndex[0] != null   && keyIndex[1] != null  ) {
keyIndexString=Integer.toString$I((keyIndex[0]).$c()) + "\t" + Integer.toString$I((keyIndex[1]).$c()) ;
}var value1Fragment=this.mmpUniqueFragments.fragmentIDToFragment$S(value1);
if (value1Fragment != null ) {
var value1Atoms=Integer.valueOf$I(value1Fragment.getFragmentAtoms$());
var value1Index=Integer.valueOf$I(value1Fragment.getFragmentIndex$());
var keysFragment=this.mmpUniqueFragments.fragmentIDToFragment$SA(keys);
var keysFP=null;
if (keysFragment != null ) {
keysFP=keysFragment.getFragmentFP$();
}var value1FP=value1Fragment.getFragmentFP$();
if (value1Index != null  && this.mmpIndex.containsKey$O(value1Index) ) {
var mmps=this.mmpIndex.get$O(value1Index);
var fragmentsIndex=null;
if (keyIndexString != null  && this.mmpFragmentsIndex.containsKey$O(keyIndexString) ) {
fragmentsIndex=this.mmpFragmentsIndex.get$O(keyIndexString);
}for (var size=((value1Atoms).$c() + minAtoms)|0; size <= ((value1Atoms).$c() + maxAtoms)|0; size++) {
if (mmps.containsKey$O(Integer.valueOf$I(size))) {
var values2=mmps.get$O(Integer.valueOf$I(size));
for (var value2_and_examples, $value2_and_examples = values2.iterator$(); $value2_and_examples.hasNext$()&&((value2_and_examples=($value2_and_examples.next$())),1);) {
var value2Index=value2_and_examples[0];
var value2=this.uniqueFragmentsIndex.get$I(value2Index);
var targetExists=-1;
if (fragmentsIndex != null ) {
for (var fragmentIndex, $fragmentIndex = fragmentsIndex.iterator$(); $fragmentIndex.hasNext$()&&((fragmentIndex=($fragmentIndex.next$())),1);) {
if (fragmentIndex[0] == value2Index) {
targetExists=fragmentIndex[1];
break;
}}
}var mmpExamples=p$2.examplesToMolecules$IA$SA$I$I.apply(this, [value2_and_examples, keysFP, value2Index, targetExists]);
if (targetExists == -1) {
var currents=this.wholeMoleculesIndex.get$O(moleculeIDCode);
if (currents == null ) {
var virtualMol=Clazz.new_($I$(3,1));
var idCodeParser=Clazz.new_($I$(4,1));
idCodeParser.parse$com_actelion_research_chem_StereoMolecule$S(virtualMol, moleculeIDCode);
var current=Clazz.new_([-1, "", moleculeIDCode, "", p$2.generateData$com_actelion_research_chem_StereoMolecule.apply(this, [virtualMol])],$I$(14,1).c$$I$S$S$S$SA);
currents=Clazz.new_($I$(1,1));
currents.add$O(current);
} else {
currents.get$I(0).setIDCode$S(moleculeIDCode);
}var virtualMol=p$2.molFromKeyValue$SA$S.apply(this, [keys, value2]);
var virtual=Clazz.new_([-1, "", virtualMol.getIDCode$(), "", p$2.generateData$com_actelion_research_chem_StereoMolecule.apply(this, [virtualMol])],$I$(14,1).c$$I$S$S$S$SA);
var virtuals=Clazz.new_($I$(1,1));
virtuals.add$O(virtual);
var matchedMolecularPairExamples=Clazz.new_($I$(18,1).c$$java_util_ArrayList$java_util_ArrayList$I,[this, null, currents, virtuals, 6]);
mmpExamples.add$I$O(0, matchedMolecularPairExamples);
}$I$(19).sort$java_util_List$java_util_Comparator(mmpExamples, C$.EXAMPLES_SIMILARITY_SORT);
var value2Fragment=this.mmpUniqueFragments.fragmentIDToFragment$S(value2);
var value2FP=value2Fragment.getFragmentFP$();
retVal.add$O(Clazz.new_([value1, (value1Index).$c(), (value1Atoms).$c(), value1FP, value2, value2Index, size, value2FP, mmpExamples, this.dataFields.size$(), targetExists],$I$(20,1).c$$S$I$I$SA$S$I$I$SA$java_util_List$I$I));
}
}}
}}if (sortBy == null  || sortBy.equals$O("results") ) {
$I$(19).sort$java_util_List$java_util_Comparator(retVal, C$.NUMBER_OF_EXAMPLES_SORT);
} else if (sortBy.equals$O("similarity")) {
$I$(19).sort$java_util_List$java_util_Comparator(retVal, C$.SIMILARITY_SORT);
}return retVal;
}, p$2);

Clazz.newMeth(C$, 'getTransformationsDWAR$S$SA$S$I$I$Integer$java_util_List',  function (moleculeIDCode, keys, value1, minAtoms, maxAtoms, environmentSize, properties) {
if (environmentSize == null ) {
environmentSize=Integer.valueOf$I(0);
}var transformations=p$2.getTransformations$S$SA$S$I$I$S.apply(this, [moleculeIDCode, keys, value1, minAtoms, maxAtoms, null]);
var formatter=Clazz.new_($I$(17,1).c$$S,["#.##"]);
var dWAR=Clazz.new_($I$(16,1));
dWAR.append$S("<datawarrior-fileinfo>\n");
dWAR.append$S("<version=\"3.1\">\n");
dWAR.append$S("<rowcount=\"" + transformations.size$() + "\">\n" );
dWAR.append$S("</datawarrior-fileinfo>\n");
dWAR.append$S("<column properties>\n");
dWAR.append$S("<columnName=\"Transformation\">\n");
dWAR.append$S("<columnProperty=\"specialType\trxncode\">\n");
dWAR.append$S("<columnName=\"Product\">\n");
dWAR.append$S("<columnProperty=\"specialType\tidcode\">\n");
dWAR.append$S("<columnName=\"Structure\">\n");
dWAR.append$S("<columnProperty=\"specialType\tidcode\">\n");
dWAR.append$S("<columnName=\"idcoordinates2D\">\n");
dWAR.append$S("<columnProperty=\"specialType\tidcoordinates2D\">\n");
dWAR.append$S("<columnProperty=\"parent\tStructure\">\n");
dWAR.append$S("</column properties>\n");
dWAR.append$S("Transformation\tProduct\tDeltaAtoms\tStructure\tidcoordinates2D\tActelion No\tExists\tExamples");
for (var property, $property = properties.iterator$(); $property.hasNext$()&&((property=($property.next$())),1);) {
dWAR.append$S("\t" + property + " Avg\t" + property + " SD\t" + property + " n" );
}
dWAR.append$S("\n");
for (var transformation, $transformation = transformations.iterator$(); $transformation.hasNext$()&&((transformation=($transformation.next$())),1);) {
p$1.calcTransformationString.apply(transformation, []);
var buildingBlock=p$2.generateBuildingBlock$S.apply(this, [transformation.value2]);
dWAR.append$S(transformation.transformationString + "\t" + buildingBlock + "\t" + (transformation.value2Atoms - transformation.value1Atoms) );
if (!transformation.targetExists) {
var virtualMol=p$2.molFromKeyValue$SA$S.apply(this, [keys, transformation.value2]);
dWAR.append$S("\t" + virtualMol.getIDCode$() + "\t\t" );
} else {
dWAR.append$S("\t" + transformation.mmpExamples.get$I(0).example2.get$I(0).moleculeIDCode + "\t" + transformation.mmpExamples.get$I(0).example2.get$I(0).moleculeIDCoord + "\t" + transformation.mmpExamples.get$I(0).example1.get$I(0).moleculeName );
}dWAR.append$S("\t" + transformation.targetExists + "\t" + transformation.numberOfExamples );
for (var property, $property = properties.iterator$(); $property.hasNext$()&&((property=($property.next$())),1);) {
var fieldIndex=-1;
for (var i=0; i < this.dataFields.size$(); i++) {
if (this.dataFields.get$I(i).fieldName.equals$O(property) || this.dataFields.get$I(i).longFieldName.equals$O(property) ) {
fieldIndex=i;
break;
}}
if (fieldIndex != -1) {
if (transformation.average[fieldIndex][(environmentSize).$c()] != null ) {
dWAR.append$S("\t" + formatter.format$O(transformation.average[fieldIndex][(environmentSize).$c()]));
} else {
dWAR.append$S("\t");
}if (transformation.sd[fieldIndex][(environmentSize).$c()] != null ) {
if (Double.isNaN$D((transformation.sd[fieldIndex][(environmentSize).$c()]).valueOf())) {
dWAR.append$S("\t0.0");
} else {
dWAR.append$S("\t" + formatter.format$O(transformation.sd[fieldIndex][(environmentSize).$c()]));
}} else {
dWAR.append$S("\t");
}dWAR.append$S("\t" + transformation.n[fieldIndex][(environmentSize).$c()]);
}}
dWAR.append$S("\n");
}
dWAR.append$S("<datawarrior properties>\n");
if (properties.size$() > 0) {
dWAR.append$S("<axisColumn_2D View_0=\"" + properties.get$I(0) + " Avg\">\n" );
if (properties.size$() > 1) {
dWAR.append$S("<axisColumn_2D View_1=\"" + properties.get$I(1) + " Avg\">\n" );
} else {
dWAR.append$S("<axisColumn_2D View_1=\"" + properties.get$I(0) + " Avg\">\n" );
}}dWAR.append$S("<chartType_2D View=\"scatter\">\n");
dWAR.append$S("<columnDescriptionCount=\"" + (properties.size$() * 3 + 3) + "\">\n" );
dWAR.append$S("<columnDescription_0=\"DeltaAtoms\tDifference of number of heavy atoms between seed and target\">\n");
dWAR.append$S("<columnDescription_1=\"Exists\tTarget structure exists in the dataset or not\">\n");
dWAR.append$S("<columnDescription_2=\"Examples\tNumber of MMPs\">\n");
var descriptionCounter=3;
for (var property, $property = properties.iterator$(); $property.hasNext$()&&((property=($property.next$())),1);) {
var fieldIndex=-1;
for (var i=0; i < this.dataFields.size$(); i++) {
if (this.dataFields.get$I(i).fieldName.equals$O(property) || this.dataFields.get$I(i).longFieldName.equals$O(property) ) {
fieldIndex=i;
break;
}}
if (fieldIndex != -1) {
dWAR.append$S("<columnDescription_" + descriptionCounter + "=\"" + property + " Avg	Average of MMPs of " + this.dataFields.get$I(fieldIndex).longFieldName + "\">\n" );
dWAR.append$S("<columnDescription_" + (descriptionCounter + 1) + "=\"" + property + " SD	SD of MMPs of " + this.dataFields.get$I(fieldIndex).longFieldName + "\">\n" );
dWAR.append$S("<columnDescription_" + (descriptionCounter + 2) + "=\"" + property + " n	Number of MMPs of " + this.dataFields.get$I(fieldIndex).longFieldName + "\">\n" );
descriptionCounter+=3;
}}
dWAR.append$S("<columnWidth_Table_Structure=\"150\">\n");
dWAR.append$S("<columnWidth_Table_Transformation=\"260\">\n");
dWAR.append$S("<detailView=\"height[Data]=0.7;height[Structure]=0.3\">\n");
dWAR.append$S("<filter0=\"#browser#\t#disabled#\tTransformation\">\n");
dWAR.append$S("<filter1=\"#structure#\tStructure\">\n");
var filterCounter=2;
if (minAtoms != maxAtoms) {
dWAR.append$S("<filter2=\"#double#\tDeltaAtoms\">\n");
++filterCounter;
}dWAR.append$S("<filter" + filterCounter + "=\"#double#	Examples\">\n" );
++filterCounter;
dWAR.append$S("<filter" + filterCounter + "=\"#category#	Exists\">\n" );
++filterCounter;
for (var property, $property = properties.iterator$(); $property.hasNext$()&&((property=($property.next$())),1);) {
dWAR.append$S("<filter" + filterCounter + "=\"#double#	" + property + " Avg	#disabled#\">\n" );
filterCounter+=1;
}
dWAR.append$S("<mainSplitting=\"0.8\">\n");
dWAR.append$S("<mainView=\"Structures\">\n");
dWAR.append$S("<mainViewCount=\"3\">\n");
dWAR.append$S("<mainViewDockInfo0=\"root\">\n");
var tableName="Transformations";
if ((environmentSize).$c() !== 0 ) {
tableName="Transformations (environment size " + Integer.toString$I((environmentSize).$c()) + ")" ;
}dWAR.append$S("<mainViewDockInfo1=\"" + tableName + "	bottom	0.7\">\n" );
dWAR.append$S("<mainViewDockInfo2=\"" + tableName + "	right	0.7\">\n" );
dWAR.append$S("<mainViewName0=\"" + tableName + "\">\n" );
dWAR.append$S("<mainViewName1=\"2D View\">\n");
dWAR.append$S("<mainViewName2=\"Structures\">\n");
dWAR.append$S("<mainViewType0=\"tableView\">\n");
dWAR.append$S("<mainViewType1=\"2Dview\">\n");
dWAR.append$S("<mainViewType2=\"structureView\">\n");
dWAR.append$S("<rightSplitting=\"0.6\">\n");
dWAR.append$S("<rowHeight_" + tableName + "=\"80\">\n" );
dWAR.append$S("<showNaNValues_2D View=\"true\">\n");
dWAR.append$S("<structureGridColumn_Structures=\"Structure\">\n");
dWAR.append$S("<structureGridColumns_Structures=\"3\">\n");
dWAR.append$S("</datawarrior properties>\n");
return dWAR.toString();
});

Clazz.newMeth(C$, 'transformationsListToTable$SA$S$I$I',  function (keys, value1, minAtoms, maxAtoms) {
var transformations=p$2.getTransformations$S$SA$S$I$I$S.apply(this, [null, keys, value1, minAtoms, maxAtoms, null]);
var retVal=Clazz.new_($I$(1,1));
for (var transformation, $transformation = transformations.iterator$(); $transformation.hasNext$()&&((transformation=($transformation.next$())),1);) {
var isCurrent=transformation.targetExists ? "1" : "0";
retVal.add$O(Clazz.array(String, -1, [transformation.value1, transformation.value2, Integer.toString$I(transformation.numberOfExamples), isCurrent]));
}
return retVal;
});

Clazz.newMeth(C$, 'getTransformationsJSON$S$SA$S$I$I$S',  function (moleculeIDCode, keys, value1, minAtoms, maxAtoms, sortBy) {
var transformations=p$2.getTransformations$S$SA$S$I$I$S.apply(this, [moleculeIDCode, keys, value1, minAtoms, maxAtoms, sortBy]);
var formatter=Clazz.new_($I$(17,1).c$$S,["#.##"]);
var jSON=Clazz.new_($I$(16,1));
jSON.append$S("{\"transformations\": [");
var counter=0;
for (var transformation, $transformation = transformations.iterator$(); $transformation.hasNext$()&&((transformation=($transformation.next$())),1);) {
if (counter > 0) {
jSON.append$S(", ");
}jSON.append$S("\n\t{\"value1\": \"" + transformation.value1.replace$CharSequence$CharSequence("\\", "\\\\") + "\"" );
jSON.append$S(",\n\t \"value2\": \"" + transformation.value2.replace$CharSequence$CharSequence("\\", "\\\\") + "\"" );
jSON.append$S(",\n\t \"n\": " + transformation.numberOfExamples);
jSON.append$S(",\n\t \"delta_atoms\": " + (transformation.value2Atoms - transformation.value1Atoms));
jSON.append$S(",\n\t \"similarity\": " + transformation.similarity);
var isCurrent=transformation.targetExists ? "true" : "false";
jSON.append$S(",\n\t \"current\": " + isCurrent + "" );
try {
jSON.append$S(",\n\t \"image\": \"" + C$.getB64Image$java_awt_image_BufferedImage(C$.getImage$S$S$I$I(transformation.value1, transformation.value2, 580, 266)) + "\"" );
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
jSON.append$S(",\n\t \"compounds\": [");
for (var j=0; j < transformation.numberOfExamples; j++) {
if (j > 0) {
jSON.append$S(", ");
}jSON.append$S("[\"" + transformation.mmpExamples.get$I(j).example1.get$I(0).moleculeName + "\", \"" + transformation.mmpExamples.get$I(j).example2.get$I(0).moleculeName + "\"]" );
}
jSON.append$S("]");
jSON.append$S(",\n\t \"similarities\": [");
for (var j=0; j < transformation.numberOfExamples; j++) {
if (j > 0) {
jSON.append$S(", ");
}jSON.append$I(transformation.mmpExamples.get$I(j).similarity);
}
jSON.append$S("]");
jSON.append$S(",\n\t \"structures\": [");
for (var j=0; j < transformation.numberOfExamples; j++) {
if (j > 0) {
jSON.append$S(", ");
}jSON.append$S("[\"" + transformation.mmpExamples.get$I(j).example1.get$I(0).moleculeIDCode.replace$CharSequence$CharSequence("\\", "\\\\") + "\", \"" + transformation.mmpExamples.get$I(j).example2.get$I(0).moleculeIDCode.replace$CharSequence$CharSequence("\\", "\\\\") + "\"]" );
}
jSON.append$S("]");
jSON.append$S(",\n\t \"coordinates\": [");
for (var j=0; j < transformation.numberOfExamples; j++) {
if (j > 0) {
jSON.append$S(", ");
}jSON.append$S("[\"" + transformation.mmpExamples.get$I(j).example1.get$I(0).moleculeIDCoord.replace$CharSequence$CharSequence("\\", "\\\\") + "\", \"" + transformation.mmpExamples.get$I(j).example2.get$I(0).moleculeIDCoord.replace$CharSequence$CharSequence("\\", "\\\\") + "\"]" );
}
jSON.append$S("]");
jSON.append$S(",\n\t \"datas\": [");
for (var i=0; i < transformation.n.length; i++) {
if (i > 0) {
jSON.append$S(", ");
}jSON.append$S("{");
for (var j=0; j < 6; j++) {
if (j > 0) {
jSON.append$S(", ");
}jSON.append$S("\n\t\t\"similarity" + j + "\":" );
jSON.append$S("\n\t\t{\"n\": " + transformation.n[i][j]);
jSON.append$S(",\n\t\t \"increase\": " + transformation.increase[i][j]);
jSON.append$S(",\n\t\t \"decrease\": " + transformation.decrease[i][j]);
jSON.append$S(",\n\t\t \"neutral\": " + transformation.neutral[i][j]);
if (transformation.average[i][j] != null ) {
jSON.append$S(",\n\t\t \"average\": " + formatter.format$O(transformation.average[i][j]));
} else {
jSON.append$S(",\n\t\t \"average\": " + transformation.average[i][j].toString());
}if (transformation.sd[i][j] != null ) {
if (Double.isNaN$D((transformation.sd[i][j]).valueOf())) {
jSON.append$S(",\n\t\t \"sd\": 0.0");
} else {
jSON.append$S(",\n\t\t \"sd\": " + formatter.format$O(transformation.sd[i][j]));
}} else {
jSON.append$S(",\n\t\t \"sd\": " + transformation.sd[i][j].toString());
}jSON.append$S("}");
}
jSON.append$S(",\n\t\t \"data\": [");
for (var j=0; j < transformation.numberOfExamples; j++) {
var example1=transformation.mmpExamples.get$I(j).example1;
var example2=transformation.mmpExamples.get$I(j).example2;
if (j > 0) {
jSON.append$S(",");
}var data1="";
if (example1.get$I(0).moleculeData != null ) {
data1=example1.get$I(0).moleculeData[i];
}var data2="";
if (example2.get$I(0).moleculeData != null ) {
data2=example2.get$I(0).moleculeData[i];
}if (data1.equals$O("")) {
data1="\"n.a.\"";
} else if (data1.startsWith$S(">") || data1.startsWith$S("<") ) {
data1="\"" + data1 + "\"" ;
} else {
data1=formatter.format$D(Double.parseDouble$S(data1));
}if (data2.equals$O("")) {
data2="\"n.a.\"";
} else if (data2.startsWith$S(">") || data2.startsWith$S("<") ) {
data2="\"" + data2 + "\"" ;
} else {
data2=formatter.format$D(Double.parseDouble$S(data2));
}jSON.append$S("[" + data1 + ", " + data2 + "]" );
}
jSON.append$S("]}");
}
jSON.append$S("]}");
counter+=1;
}
jSON.append$S("]}");
return jSON.toString();
});

Clazz.newMeth(C$, 'changeR1ToR2$com_actelion_research_chem_StereoMolecule',  function (mol) {
for (var i=0; i < mol.getAtoms$(); i++) {
if (mol.getAtomicNo$I(i) == 142) {
mol.setAtomicNo$I$I(i, 143);
break;
}}
return mol;
}, p$2);

Clazz.newMeth(C$, 'generateBuildingBlock$S',  function (value) {
var mol=Clazz.new_($I$(3,1));
var idCodeParser=Clazz.new_($I$(4,1));
idCodeParser.parse$com_actelion_research_chem_StereoMolecule$S(mol, value);
for (var i=0; i < mol.getAtoms$(); i++) {
if (mol.getAtomicNo$I(i) >= 142) {
mol.setAtomQueryFeature$I$J$Z(i, 1, true);
} else {
mol.setAtomQueryFeature$I$J$Z(i, 2048, true);
}}
return mol.getIDCode$();
}, p$2);

Clazz.newMeth(C$, 'molFromKeyValue$SA$S',  function (keys, value) {
var firstAtoms=Clazz.array(Integer.TYPE, [2 * keys.length]);
var rBonds=Clazz.array(Integer.TYPE, [2 * keys.length]);
var rGroupAtoms=Clazz.array(Integer.TYPE, [2 * keys.length]);
var secondAtoms=Clazz.array(Integer.TYPE, [2 * keys.length]);
var rGroupsIndex=Clazz.array(Integer.TYPE, [2 * keys.length]);
var rGroupCounters=Clazz.array(Integer.TYPE, [keys.length]);
var atomLabel;
var mol1=Clazz.new_($I$(3,1));
var mol2=Clazz.new_($I$(3,1));
var idCodeParser=Clazz.new_($I$(4,1));
idCodeParser.parse$com_actelion_research_chem_StereoMolecule$S(mol1, value);
idCodeParser.parse$com_actelion_research_chem_StereoMolecule$S(mol2, keys[0]);
mol1.addMolecule$com_actelion_research_chem_Molecule(mol2);
if (keys.length == 2) {
var mol3=Clazz.new_($I$(3,1));
idCodeParser.parse$com_actelion_research_chem_StereoMolecule$S(mol3, keys[1]);
mol3=p$2.changeR1ToR2$com_actelion_research_chem_StereoMolecule.apply(this, [mol3]);
mol1.addMolecule$com_actelion_research_chem_Molecule(mol3);
rGroupCounters[1]=2;
}mol1.ensureHelperArrays$I(1);
for (var bond=0; bond < mol1.getBonds$(); bond++) {
var atom1=mol1.getBondAtom$I$I(0, bond);
var atom2=mol1.getBondAtom$I$I(1, bond);
if (mol1.getAtomicNo$I(atom1) == 0 || mol1.getAtomicNo$I(atom1) >= 142  || mol1.getAtomicNo$I(atom2) == 0  || mol1.getAtomicNo$I(atom2) >= 142 ) {
if (mol1.getAtomicNo$I(atom1) == 0 || mol1.getAtomicNo$I(atom1) >= 142 ) {
atomLabel=mol1.getAtomicNo$I(atom1) - 142;
rBonds[rGroupCounters[atomLabel]]=bond;
firstAtoms[rGroupCounters[atomLabel]]=atom1;
rGroupAtoms[rGroupCounters[atomLabel]]=0;
secondAtoms[rGroupCounters[atomLabel]]=atom2;
rGroupsIndex[rGroupCounters[atomLabel]]=atomLabel;
} else {
atomLabel=mol1.getAtomicNo$I(atom2) - 142;
rBonds[rGroupCounters[atomLabel]]=bond;
firstAtoms[rGroupCounters[atomLabel]]=atom2;
rGroupAtoms[rGroupCounters[atomLabel]]=1;
secondAtoms[rGroupCounters[atomLabel]]=atom1;
rGroupsIndex[rGroupCounters[atomLabel]]=atomLabel;
}++rGroupCounters[atomLabel];
}}
mol1.setBondAtom$I$I$I(rGroupAtoms[0], rBonds[0], secondAtoms[1]);
mol1.markBondForDeletion$I(rBonds[1]);
mol1.markAtomForDeletion$I(firstAtoms[1]);
mol1.markAtomForDeletion$I(firstAtoms[0]);
if (keys.length == 2) {
mol1.setBondAtom$I$I$I(rGroupAtoms[2], rBonds[2], secondAtoms[3]);
mol1.markBondForDeletion$I(rBonds[3]);
mol1.markAtomForDeletion$I(firstAtoms[3]);
mol1.markAtomForDeletion$I(firstAtoms[2]);
}mol1.deleteMarkedAtomsAndBonds$();
return mol1;
}, p$2);

Clazz.newMeth(C$, 'examplesToMolecules$IA$SA$I$I',  function (examples, keys1FP, value2Index, targetExists) {
var retVal=Clazz.new_($I$(1,1));
var fragmentsIndex=null;
if (this.mmpFragmentsIndex.containsKey$O(Integer.toString$I(value2Index))) {
fragmentsIndex=this.mmpFragmentsIndex.get$O(Integer.toString$I(value2Index));
}for (var i=1; i < examples.length; i+=2) {
var example1=p$2.molIndexToMolecule$I.apply(this, [examples[i]]);
var example2=p$2.molIndexToMolecule$I.apply(this, [examples[i + 1]]);
var similarity=-1;
if (fragmentsIndex != null ) {
for (var fragmentIndex, $fragmentIndex = fragmentsIndex.iterator$(); $fragmentIndex.hasNext$()&&((fragmentIndex=($fragmentIndex.next$())),1);) {
if (fragmentIndex[1] == examples[i + 1]) {
if (fragmentIndex[1] == targetExists) {
similarity=6;
} else {
similarity=0;
var keyIndex=fragmentIndex[0];
var keyID=this.uniqueFragmentsIndex.get$I(keyIndex);
var keysFragment=this.mmpUniqueFragments.fragmentIDToFragment$S(keyID);
var keys2FP=keysFragment.getFragmentFP$();
if (keys1FP != null ) {
for (var j=keys1FP.length - 1; j >= 0; j--) {
if (keys1FP[j].equals$O(keys2FP[j])) {
similarity=j + 1;
break;
}}
}}break;
}}
}var matchedMolecularPairExamples=Clazz.new_($I$(18,1).c$$java_util_ArrayList$java_util_ArrayList$I,[this, null, example1, example2, similarity]);
retVal.add$O(matchedMolecularPairExamples);
}
return retVal;
}, p$2);

Clazz.newMeth(C$, 'molIndexToMolecule$I',  function (molIndex) {
var moleculeIDCode=this.molecules.get$I(molIndex);
var moleculesIndex=this.wholeMoleculesIndex.get$O(moleculeIDCode);
for (var moleculeIndex, $moleculeIndex = moleculesIndex.iterator$(); $moleculeIndex.hasNext$()&&((moleculeIndex=($moleculeIndex.next$())),1);) {
moleculeIndex.setIDCode$S(moleculeIDCode);
}
return moleculesIndex;
}, p$2);

Clazz.newMeth(C$, 'getIDCodeFromMolName$S',  function (molName) {
for (var cursor, $cursor = this.wholeMoleculesIndex.entrySet$().iterator$(); $cursor.hasNext$()&&((cursor=($cursor.next$())),1);) {
for (var moleculeIndex, $moleculeIndex = cursor.getValue$().iterator$(); $moleculeIndex.hasNext$()&&((moleculeIndex=($moleculeIndex.next$())),1);) {
if (moleculeIndex.moleculeName.equals$O(molName)) {
if (cursor.getValue$().get$I(0).moleculeIDCoord != null ) {
return cursor.getKey$() + "\t" + cursor.getValue$().get$I(0).moleculeIDCoord ;
}return cursor.getKey$();
}}
}
return null;
});

Clazz.newMeth(C$, 'keysToKeysString$IntegerA',  function (keys) {
var keysString=null;
if (keys.length == 1 && keys[0] != null  ) {
keysString=Integer.toString$I((keys[0]).$c());
} else if (keys.length == 2 && keys[0] != null   && keys[1] != null  ) {
keysString=Integer.toString$I((keys[0]).$c()) + "\t" + Integer.toString$I((keys[1]).$c()) ;
}return keysString;
}, p$2);

Clazz.newMeth(C$, 'getDataFields$S',  function (what) {
var retVal=Clazz.new_($I$(1,1));
for (var dataField, $dataField = this.dataFields.iterator$(); $dataField.hasNext$()&&((dataField=($dataField.next$())),1);) {
if (what.equals$O("fieldName")) {
retVal.add$O(dataField.fieldName);
} else if (what.equals$O("longFieldName")) {
if (dataField.longFieldName != null ) {
retVal.add$O(dataField.longFieldName);
} else {
retVal.add$O(dataField.fieldName);
}} else if (what.equals$O("categoryName")) {
if (dataField.categoryName != null ) {
retVal.add$O(dataField.categoryName);
} else {
retVal.add$O("Other");
}} else if (what.equals$O("percentile5")) {
retVal.add$O(dataField.percentile5);
} else if (what.equals$O("percentile95")) {
retVal.add$O(dataField.percentile95);
}}
return retVal;
});

Clazz.newMeth(C$, 'getWhat$S',  function (what) {
if (what.equals$O("datasetName")) {
return this.datasetName;
} else if (what.equals$O("date")) {
return this.date;
} else if (what.equals$O("numberOfMolecules")) {
return Integer.toString$I(this.wholeMoleculesIndex.size$());
} else if (what.equals$O("randomMoleculeName")) {
var randomGenerator=Clazz.new_($I$(21,1));
if (this.molecules.size$() > 0) {
var index=randomGenerator.nextInt$I(this.molecules.size$());
var moleculesIndex=this.wholeMoleculesIndex.get$O(this.molecules.get$I(index));
if (moleculesIndex.size$() > 0) {
return moleculesIndex.get$I(0).moleculeName;
}return null;
}return null;
}return null;
});

Clazz.newMeth(C$, 'getImage$S$S$I$I',  function (value1, value2, width, height) {
var bufferedImage=Clazz.new_($I$(22,1).c$$I$I$I,[width, height, 2]);
var viewRect=Clazz.new_($I$(23,1).c$$D$D$D$D,[0, 0, width, height]);
var extendedDepictor;
var mol1=Clazz.new_($I$(3,1));
var idCodeParser=Clazz.new_($I$(4,1));
idCodeParser.parse$com_actelion_research_chem_StereoMolecule$S(mol1, value1);
if (value2 == null ) {
extendedDepictor=Clazz.new_([Clazz.array($I$(3), -1, [mol1]), null],$I$(24,1).c$$com_actelion_research_chem_StereoMoleculeA$com_actelion_research_chem_DrawingObjectList);
} else {
var mol2=Clazz.new_($I$(3,1));
idCodeParser.parse$com_actelion_research_chem_StereoMolecule$S(mol2, value2);
var rxn=Clazz.new_([Clazz.array($I$(3), -1, [mol1, mol2]), 1],$I$(5,1).c$$com_actelion_research_chem_StereoMoleculeA$I);
extendedDepictor=Clazz.new_([rxn, rxn.getDrawingObjects$(), true],$I$(24,1).c$$com_actelion_research_chem_reaction_Reaction$com_actelion_research_chem_DrawingObjectList$Z);
}var graphics2D=bufferedImage.getGraphics$();
var context=Clazz.new_($I$(25,1).c$$java_awt_Graphics2D,[graphics2D]);
extendedDepictor.validateView$com_actelion_research_gui_generic_GenericDrawContext$com_actelion_research_gui_generic_GenericRectangle$I(context, viewRect, 65581);
var renderingHints=Clazz.new_([$I$(26).KEY_ANTIALIASING, $I$(26).VALUE_ANTIALIAS_ON],$I$(26,1).c$$java_awt_RenderingHints_Key$O);
graphics2D.addRenderingHints$java_util_Map(renderingHints);
extendedDepictor.paint$com_actelion_research_gui_generic_GenericDrawContext(context);
return bufferedImage;
}, 1);

Clazz.newMeth(C$, 'getB64Image$java_awt_image_BufferedImage',  function (bufferedImage) {
var outputStream=Clazz.new_($I$(27,1));
var b64=Clazz.new_($I$(28,1).c$$java_io_OutputStream,[outputStream]);
$I$(29).write$java_awt_image_RenderedImage$S$java_io_OutputStream(bufferedImage, "png", b64);
return outputStream.toString$S("UTF-8");
}, 1);

Clazz.newMeth(C$, 'generateData$com_actelion_research_chem_StereoMolecule',  function (mol) {
var datas=Clazz.array(String, [this.dataFields.size$()]);
$I$(2).fill$OA$O(datas, "");
for (var i=0; i < this.dataFields.size$(); i++) {
if (this.dataFields.get$I(i).categoryName.equals$O("Calculated")) {
var data=this.mPropertyCalculator.getCalculatedValue$S$com_actelion_research_chem_StereoMolecule(this.dataFields.get$I(i).fieldName, mol);
if (data != null ) {
datas[i]=data;
}}}
return datas;
}, p$2);

C$.$static$=function(){C$.$static$=0;
C$.NUMBER_OF_EXAMPLES_SORT=((P$.MMPReader$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "MMPReader$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$com_actelion_research_chem_mmp_MMPReader_MatchedMolecularPair$com_actelion_research_chem_mmp_MMPReader_MatchedMolecularPair','compare$O$O'],  function (matchedMolecularPair1, matchedMolecularPair2) {
return matchedMolecularPair2.numberOfExamples - matchedMolecularPair1.numberOfExamples;
});
})()
), Clazz.new_(P$.MMPReader$1.$init$,[this, null]));
C$.SIMILARITY_SORT=((P$.MMPReader$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "MMPReader$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]]

Clazz.newMeth(C$, ['compare$com_actelion_research_chem_mmp_MMPReader_MatchedMolecularPair$com_actelion_research_chem_mmp_MMPReader_MatchedMolecularPair','compare$O$O'],  function (matchedMolecularPair1, matchedMolecularPair2) {
return matchedMolecularPair2.similarity - matchedMolecularPair1.similarity;
});
})()
), Clazz.new_(P$.MMPReader$2.$init$,[this, null]));
C$.EXAMPLES_SIMILARITY_SORT=((P$.MMPReader$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "MMPReader$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]]

Clazz.newMeth(C$, ['compare$com_actelion_research_chem_mmp_MMPReader_MatchedMolecularPairExamples$com_actelion_research_chem_mmp_MMPReader_MatchedMolecularPairExamples','compare$O$O'],  function (matchedMolecularPairExample1, matchedMolecularPairExample2) {
return matchedMolecularPairExample2.similarity - matchedMolecularPairExample1.similarity;
});
})()
), Clazz.new_(P$.MMPReader$3.$init$,[this, null]));
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.MMPReader, "DataField", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['fieldName','longFieldName','categoryName','percentile5','percentile95']]]

Clazz.newMeth(C$, 'c$$S$S$S$S$S',  function (fieldName, longFieldName, categoryName, percentile5, percentile95) {
;C$.$init$.apply(this);
this.fieldName=fieldName;
this.categoryName=categoryName;
this.longFieldName=longFieldName;
this.percentile5=percentile5;
this.percentile95=percentile95;
}, 1);

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.MMPReader, "MatchedMolecularPairExamples", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['similarity'],'O',['example1','java.util.ArrayList','+example2']]]

Clazz.newMeth(C$, 'c$$java_util_ArrayList$java_util_ArrayList$I',  function (example1, example2, similarity) {
;C$.$init$.apply(this);
this.example1=example1;
this.example2=example2;
this.similarity=similarity;
}, 1);

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.MMPReader, "MatchedMolecularPair", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['targetExists'],'I',['numberOfExamples','value1Index','value1Atoms','value2Index','value2Atoms','similarity'],'S',['value1','value2','transformationString'],'O',['transformation','com.actelion.research.chem.reaction.Reaction','mmpExamples','java.util.List','datas','java.util.ArrayList','+similarities','n','int[][]','+increase','+decrease','+neutral','average','Double[][]','+sd','numberOfIncrease','Integer[][]','+numberOfDecrease','+numberOfNeutral']]]

Clazz.newMeth(C$, 'c$$S$I$I$SA$S$I$I$SA$java_util_List$I$I',  function (value1, value1Index, value1Atoms, value1FP, value2, value2Index, value2Atoms, value2FP, mmpExamples, numberOfFields, targetExists) {
;C$.$init$.apply(this);
this.numberOfExamples=mmpExamples.size$();
this.value1=value1;
this.value1Index=value1Index;
this.value1Atoms=value1Atoms;
this.value2=value2;
this.value2Index=value2Index;
this.value2Atoms=value2Atoms;
this.transformation=p$1.reactionFromTwoValues$S$S.apply(this, [value1, value2]);
this.transformationString=null;
this.mmpExamples=mmpExamples;
this.datas=Clazz.new_($I$(1,1));
this.similarities=Clazz.new_($I$(1,1));
this.n=Clazz.array(Integer.TYPE, [numberOfFields, 6]);
this.average=Clazz.array(Double, [numberOfFields, 6]);
this.sd=Clazz.array(Double, [numberOfFields, 6]);
this.increase=Clazz.array(Integer.TYPE, [numberOfFields, 6]);
this.decrease=Clazz.array(Integer.TYPE, [numberOfFields, 6]);
this.neutral=Clazz.array(Integer.TYPE, [numberOfFields, 6]);
this.targetExists=targetExists > -1 ? true : false;
for (var i=0; i < numberOfFields; i++) {
this.datas.add$O(Clazz.new_($I$(1,1)));
}
for (var i=0; i < this.numberOfExamples; i++) {
var example1=mmpExamples.get$I(i).example1;
var example2=mmpExamples.get$I(i).example2;
var similarity=mmpExamples.get$I(i).similarity;
var example1Data=p$1.averageData$java_util_ArrayList$I.apply(this, [example1, numberOfFields]);
var example2Data=p$1.averageData$java_util_ArrayList$I.apply(this, [example2, numberOfFields]);
this.similarities.add$O(Integer.valueOf$I(similarity));
for (var j=0; j < numberOfFields; j++) {
if (example1Data[j] != null  && example2Data[j] != null  ) {
for (var k=0; k < 6; k++) {
if (similarity == -1 || similarity >= k ) {
this.n[j][k]+=1;
}}
var data=this.datas.get$I(j);
data.add$O(Double.valueOf$D((example2Data[j]).$c() - (example1Data[j]).$c()));
this.datas.set$I$O(j, data);
}}
}
for (var i=0; i < numberOfFields; i++) {
for (var j=0; j < 6; j++) {
this.average[i][j]=C$.calcAverage$java_util_List(this.datas.get$I(i).subList$I$I(0, this.n[i][j]));
if (this.n[i][j] > 1) {
this.sd[i][j]=Double.valueOf$D(C$.calcStanDev$java_util_List(this.datas.get$I(i).subList$I$I(0, this.n[i][j])));
} else {
this.sd[i][j]=null;
}var tendency=C$.calcTendency$java_util_List(this.datas.get$I(i).subList$I$I(0, this.n[i][j]));
this.increase[i][j]=tendency[0];
this.decrease[i][j]=tendency[1];
this.neutral[i][j]=tendency[2];
}
}
this.similarity=0;
for (var i=value1FP.length - 1; i >= 0; i--) {
if (value1FP[i].equals$O(value2FP[i])) {
this.similarity=i + 1;
break;
}}
}, 1);

Clazz.newMeth(C$, 'calcTransformationString',  function () {
this.transformationString=p$1.idCodeFromTwoValues$S$S.apply(this, [this.value1, this.value2]);
}, p$1);

Clazz.newMeth(C$, 'calcAverage$java_util_List',  function (data) {
if (data.size$() > 0) {
var allData=0.0;
var numberOfData=0;
for (var d, $d = data.iterator$(); $d.hasNext$()&&((d=($d.next$())),1);) {
++numberOfData;
allData+=(d).$c();
}
return Double.valueOf$D(allData / numberOfData);
}return null;
}, 1);

Clazz.newMeth(C$, 'calcStanDev$java_util_List',  function (data) {
return Math.pow(C$.calcVariance$java_util_List(data), 0.5);
}, 1);

Clazz.newMeth(C$, 'calcVariance$java_util_List',  function (data) {
var n=data.size$();
var total=0;
var sTotal=0;
var scalar=1 / (n - 1);
for (var d, $d = data.iterator$(); $d.hasNext$()&&((d=($d.next$())),1);) {
total+=(d).$c();
sTotal+=Math.pow((d).valueOf(), 2);
}
return (scalar * (sTotal - (Math.pow(total, 2) / n)));
}, 1);

Clazz.newMeth(C$, 'calcTendency$java_util_List',  function (data) {
var retVal=Clazz.array(Integer.TYPE, [3]);
$I$(2).fill$IA$I(retVal, 0);
for (var d, $d = data.iterator$(); $d.hasNext$()&&((d=($d.next$())),1);) {
if ((d).$c() >= 0.1 ) {
retVal[0]+=1;
} else if ((d).$c() <= -0.1 ) {
retVal[1]+=1;
} else {
retVal[2]+=1;
}}
return retVal;
}, 1);

Clazz.newMeth(C$, 'reactionFromTwoValues$S$S',  function (value1, value2) {
var mol1=Clazz.new_($I$(3,1));
var mol2=Clazz.new_($I$(3,1));
var idCodeParser=Clazz.new_($I$(4,1));
idCodeParser.parse$com_actelion_research_chem_StereoMolecule$S(mol1, value1);
idCodeParser.parse$com_actelion_research_chem_StereoMolecule$S(mol2, value2);
var rxn=Clazz.new_([Clazz.array($I$(3), -1, [mol1, mol2]), 1],$I$(5,1).c$$com_actelion_research_chem_StereoMoleculeA$I);
return rxn;
}, p$1);

Clazz.newMeth(C$, 'idCodeFromTwoValues$S$S',  function (value1, value2) {
var mol1=Clazz.new_($I$(3,1));
var mol2=Clazz.new_($I$(3,1));
var idCodeParser=Clazz.new_($I$(4,1));
idCodeParser.parse$com_actelion_research_chem_StereoMolecule$S(mol1, value1);
idCodeParser.parse$com_actelion_research_chem_StereoMolecule$S(mol2, value2);
var rxn=Clazz.new_([Clazz.array($I$(3), -1, [mol1, mol2]), 1],$I$(5,1).c$$com_actelion_research_chem_StereoMoleculeA$I);
var rxnEncoder=$I$(6).encode$com_actelion_research_chem_reaction_Reaction$Z(rxn, false);
return value1 + "!" + value2 + "##" + rxnEncoder[2] ;
}, p$1);

Clazz.newMeth(C$, 'averageData$java_util_ArrayList$I',  function (example, numberOfFields) {
var numberOfValues=Clazz.array(Integer.TYPE, [numberOfFields]);
var values=Clazz.array(Double, [numberOfFields]);
$I$(2).fill$IA$I(numberOfValues, 0);
$I$(2,"fill$OA$O",[values, Double.valueOf$D(0.0)]);
for (var i=0; i < numberOfFields; i++) {
for (var moleculeIndex, $moleculeIndex = example.iterator$(); $moleculeIndex.hasNext$()&&((moleculeIndex=($moleculeIndex.next$())),1);) {
if (moleculeIndex.moleculeData != null  && C$.isNumeric$S(moleculeIndex.moleculeData[i]) ) {
numberOfValues[i]+=1;
values[i]=Double.valueOf$D((values[i]).valueOf()+(Double.parseDouble$S(moleculeIndex.moleculeData[i])));
}}
}
for (var i=0; i < numberOfFields; i++) {
if (numberOfValues[i] != 0) {
values[i]=Double.valueOf$D((values[i]).valueOf()/(numberOfValues[i]));
} else {
values[i]=null;
}}
return values;
}, p$1);

Clazz.newMeth(C$, 'isNumeric$S',  function (str) {
if (str == null ) {
return true;
}try {
Double.parseDouble$S(str);
} catch (nfe) {
if (Clazz.exceptionOf(nfe,"NumberFormatException")){
return false;
} else {
throw nfe;
}
}
return true;
}, 1);

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:27 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
