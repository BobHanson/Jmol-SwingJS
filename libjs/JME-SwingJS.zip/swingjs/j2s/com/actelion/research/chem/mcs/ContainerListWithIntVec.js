(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mcs"),p$1={},I$=[[0,'com.actelion.research.util.datamodel.IntArray','java.util.ArrayList','com.actelion.research.chem.mcs.ListWithIntVec']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ContainerListWithIntVec");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['sizeVector'],'O',['li','java.util.List','arrAvailable','com.actelion.research.util.datamodel.IntArray']]
,['I',['CAPACITY_ADD']]]

Clazz.newMeth(C$, 'c$$I$I',  function (sizeVector, capacity) {
;C$.$init$.apply(this);
this.sizeVector=sizeVector;
this.arrAvailable=Clazz.new_($I$(1,1).c$$I,[capacity]);
this.li=Clazz.new_($I$(2,1).c$$I,[capacity]);
p$1.initResources$I.apply(this, [capacity]);
}, 1);

Clazz.newMeth(C$, 'reset$',  function () {
this.arrAvailable.reset$();
for (var i=0; i < this.li.size$(); i++) {
this.arrAvailable.add$I(i);
}
});

Clazz.newMeth(C$, 'initResources$I',  function (capacity) {
var indexStart=this.li.size$();
for (var i=0; i < capacity; i++) {
var index=indexStart + i;
this.li.add$O(Clazz.new_($I$(3,1).c$$I$I,[this.sizeVector, index]));
this.arrAvailable.add$I(index);
}
}, p$1);

Clazz.newMeth(C$, 'get$',  function () {
if (this.arrAvailable.length$() == 0) {
p$1.initResources$I.apply(this, [C$.CAPACITY_ADD]);
}var index=this.arrAvailable.removeLast$();
var liv=this.li.get$I(index);
liv.reset$();
return liv;
});

Clazz.newMeth(C$, 'back$com_actelion_research_chem_mcs_ListWithIntVec',  function (liv) {
this.arrAvailable.add$I(liv.getPositionInContainer$());
});

Clazz.newMeth(C$, 'getWithCopy$com_actelion_research_chem_mcs_ListWithIntVec',  function (orign) {
var liv=this.get$();
liv.copyIntoThis$com_actelion_research_chem_mcs_ListWithIntVec(orign);
return liv;
});

C$.$static$=function(){C$.$static$=0;
C$.CAPACITY_ADD=1024;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:39 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
