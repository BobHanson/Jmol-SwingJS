(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io.pdb.parser"),I$=[[0,'com.actelion.research.chem.io.pdb.parser.Residue']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ProteinSynthesizer");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.terminalC=-1;
},1);

C$.$fields$=[['I',['terminalC'],'O',['protein','com.actelion.research.chem.Molecule3D']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'addResidue$com_actelion_research_chem_Molecule3D',  function (residue) {
var coupled=false;
var toDelete=-1;
var newTerminalN=-1;
var newTerminalC=-1;
for (var atom=0; atom < residue.getAtoms$(); atom++) {
if (residue.getAtomicNo$I(atom) == 7 && residue.getAtomCustomLabel$I(atom) == null  ) newTerminalN=atom;
if (residue.getAtomicNo$I(atom) == 6 && residue.getAtomCustomLabel$I(atom) == null  ) newTerminalC=atom;
}
if (this.protein == null ) {
this.protein=residue;
this.terminalC=newTerminalC;
coupled=true;
} else if (newTerminalN > -1 && this.terminalC > -1 ) {
var coordsC=this.protein.getCoordinates$I(this.terminalC);
var coordsN=residue.getCoordinates$I(newTerminalN);
if (coordsC.distanceSquared$com_actelion_research_chem_Coordinates(coordsN) < $I$(1).BOND_CUTOFF_SQ ) {
var notFound=true;
for (var i=0; i < this.protein.getConnAtoms$I(this.terminalC) && notFound ; i++) {
var a=this.protein.getConnAtom$I$I(this.terminalC, i);
var b=this.protein.getBond$I$I(this.terminalC, a);
if (this.protein.getAtomicNo$I(a) == 8 && this.protein.getBondOrder$I(b) == 1 ) {
notFound=false;
toDelete=this.protein.getConnAtom$I$I(this.terminalC, i);
}}
if (toDelete >= 0) {
this.protein.deleteAtom$I(toDelete);
var atomMap=this.protein.addMolecule$com_actelion_research_chem_Molecule(residue);
this.protein.addBond$I$I$I(this.terminalC, atomMap[newTerminalN], 1);
this.terminalC=this.protein.getAllAtoms$() - (residue.getAllAtoms$() - newTerminalC);
coupled=true;
}}}this.protein.ensureHelperArrays$I(1);
return coupled;
});

Clazz.newMeth(C$, 'retrieveProtein$',  function () {
return this.protein;
});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:26 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
