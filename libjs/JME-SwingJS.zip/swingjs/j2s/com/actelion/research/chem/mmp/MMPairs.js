(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mmp"),I$=[[0,'java.io.File','java.io.PrintWriter','java.io.BufferedReader','java.io.FileReader']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MMPairs");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.temp=$I$(1).createTempFile$S$S("matchedmolecularpairs", ".tmp");
this.mmpWriter=Clazz.new_($I$(2,1).c$$java_io_File,[this.temp]);
this.numberOfLines=0;
},1);

C$.$fields$=[['I',['numberOfLines'],'O',['temp','java.io.File','mmpWriter','java.io.PrintWriter']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.mmpWriter.println$S("value1FragmentIndex\tvalue1Atoms\tvalue2FragmentIndex\tvalue2Atoms\tcutType\tnumberOfExamples\texamples");
}, 1);

Clazz.newMeth(C$, 'writeMMPEnumeration$java_util_HashMap',  function (mMPs) {
if (mMPs != null  && mMPs.size$() > 0 ) {
for (var entry, $entry = mMPs.entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) {
var examples="";
for (var example, $example = entry.getValue$().iterator$(); $example.hasNext$()&&((example=($example.next$())),1);) {
if (examples === "" ) {
examples=example[0] + "," + example[1] ;
} else {
examples+="|" + example[0] + "," + example[1] ;
}}
this.mmpWriter.println$S(entry.getKey$() + "\t" + Integer.toString$I(entry.getValue$().size$()) + "\t" + examples );
++this.numberOfLines;
}
}});

Clazz.newMeth(C$, 'getMMPsCount$',  function () {
return this.numberOfLines;
});

Clazz.newMeth(C$, 'writeMMPs$java_io_PrintWriter',  function (printWriter) {
this.mmpWriter.close$();
printWriter.println$S("<matchedMolecularPairs>");
printWriter.println$S("<column properties>");
printWriter.println$S("<columnName=\"value1FragmentIndex\">");
printWriter.println$S("<columnName=\"value1Atoms\">");
printWriter.println$S("<columnName=\"value2FragmentIndex\">");
printWriter.println$S("<columnName=\"value2Atoms\">");
printWriter.println$S("<columnName=\"cutType\">");
printWriter.println$S("<columnName=\"numberOfExamples\">");
printWriter.println$S("<columnName=\"examples\">");
printWriter.println$S("</column properties>");
var br=Clazz.new_([Clazz.new_($I$(4,1).c$$java_io_File,[this.temp])],$I$(3,1).c$$java_io_Reader);
var strLine;
while ((strLine=br.readLine$()) != null ){
printWriter.println$S(strLine);
}
br.close$();
this.temp.delete$();
printWriter.println$S("</matchedMolecularPairs>");
});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:27 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
