(function(){var P$=Clazz.newPackage("com.actelion.research.chem.inchi"),I$=[[0,'java.util.Hashtable','net.sf.jniinchi.JniInchiInputInchi','net.sf.jniinchi.JniInchiWrapper','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.MolfileParser','net.sf.jniinchi.JniInchiInput','net.sf.jniinchi.JniInchiStructure','net.sf.jniinchi.JniInchiAtom','com.actelion.research.chem.Molecule','net.sf.jniinchi.JniInchiBond','net.sf.jniinchi.INCHI_BOND_TYPE','net.sf.jniinchi.INCHI_BOND_STEREO','org.iupac.InchiUtils','java.util.HashMap']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InChIJNI1", null, 'com.actelion.research.chem.inchi.InChIOCL');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.mapAtomToIndex=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['O',['jniInchiStructure','net.sf.jniinchi.JniInchiOutputStructure','mapAtomToIndex','java.util.Map','thisAtom','net.sf.jniinchi.JniInchiAtom','thisBond','net.sf.jniinchi.JniInchiBond','thisStereo','net.sf.jniinchi.JniInchiStereo0D']]]

Clazz.newMeth(C$, 'initAndRun$Runnable',  function (r) {
r.run$();
});

Clazz.newMeth(C$, 'implementsMolDataToInChI$',  function () {
return false;
});

Clazz.newMeth(C$, 'getInchiImpl$com_actelion_research_chem_StereoMolecule$S$S',  function (mol, molFileDataOrInChI, options) {
try {
var inchi=null;
var jniInchiInput=null;
if (this.isInputInChI) {
if (this.getKey) {
inchi=molFileDataOrInChI;
} else {
jniInchiInput=Clazz.new_($I$(2,1).c$$S$S,[molFileDataOrInChI, options]);
if (this.getInchiModel) {
} else {
inchi=$I$(3).getInchiFromInchi$net_sf_jniinchi_JniInchiInputInchi(jniInchiInput).getInchi$();
}}} else {
if (mol == null ) {
mol=Clazz.new_($I$(4,1));
Clazz.new_($I$(5,1)).parse$com_actelion_research_chem_StereoMolecule$S(mol, molFileDataOrInChI);
}var out=$I$(3,"getInchi$net_sf_jniinchi_JniInchiInput",[Clazz.new_([C$.newJniInchiStructure$com_actelion_research_chem_StereoMolecule(mol), options],$I$(6,1).c$$net_sf_jniinchi_JniInchiStructure$S)]);
var msg=out.getMessage$();
if (msg != null ) System.err.println$S(msg);
inchi=out.getInchi$();
if (this.getInchiModel) {
jniInchiInput=Clazz.new_($I$(2,1).c$$S$S,[inchi, options]);
}}if (this.getInchiModel) {
return C$.toJSON$net_sf_jniinchi_JniInchiOutputStructure($I$(3).getStructureFromInchi$net_sf_jniinchi_JniInchiInputInchi(jniInchiInput));
}return (this.getKey ? $I$(3).getInchiKey$S(inchi).getKey$() : inchi);
} catch (e) {
System.out.println$O(e);
if (e.getMessage$().indexOf$S("ption") >= 0) System.out.println$S(e.getMessage$() + ": " + options.toLowerCase$() + "\n See https://www.inchi-trust.org/download/104/inchi-faq.pdf for valid options" );
 else e.printStackTrace$();
return "";
}
});

Clazz.newMeth(C$, 'newJniInchiStructure$com_actelion_research_chem_StereoMolecule',  function (mol) {
mol.ensureHelperArrays$I(1);
var struc=Clazz.new_($I$(7,1));
var nAtoms=mol.getAllAtoms$();
var atoms=Clazz.array($I$(8), [nAtoms]);
for (var i=0; i < nAtoms; i++) {
var elem=mol.getAtomicNo$I(i);
var sym=$I$(9).cAtomLabel[elem];
var iso=mol.getAtomMass$I(i);
if (elem == 1) {
sym="H";
}var a=atoms[i]=Clazz.new_([mol.getAtomX$I(i), -mol.getAtomY$I(i), mol.getAtomZ$I(i), sym],$I$(8,1).c$$D$D$D$S);
struc.addAtom$net_sf_jniinchi_JniInchiAtom(a);
a.setCharge$I(mol.getAtomCharge$I(i));
if (iso > 0) a.setIsotopicMass$I(iso);
a.setImplicitH$I(mol.getImplicitHydrogens$I(i));
}
var nBonds=mol.getAllBonds$();
for (var i=0; i < nBonds; i++) {
var oclOrder=mol.getBondTypeSimple$I(i);
var order=C$.getInChIOrder$I(oclOrder);
if (order != null ) {
var atom1=mol.getBondAtom$I$I(0, i);
var atom2=mol.getBondAtom$I$I(1, i);
var oclType=mol.getBondType$I(i);
var oclParity=mol.getBondParity$I(i);
var stereo=C$.getInChIStereo$I$I$I(oclOrder, oclType, oclParity);
var bond=Clazz.new_($I$(10,1).c$$net_sf_jniinchi_JniInchiAtom$net_sf_jniinchi_JniInchiAtom$net_sf_jniinchi_INCHI_BOND_TYPE$net_sf_jniinchi_INCHI_BOND_STEREO,[atoms[atom1], atoms[atom2], order, stereo]);
struc.addBond$net_sf_jniinchi_JniInchiBond(bond);
}}
return struc;
}, 1);

Clazz.newMeth(C$, 'getInChIOrder$I',  function (oclOrder) {
switch (oclOrder) {
case 1:
return $I$(11).SINGLE;
case 2:
return $I$(11).DOUBLE;
case 4:
return $I$(11).TRIPLE;
case 8:
return $I$(11).ALTERN;
case 16:
default:
return null;
}
}, 1);

Clazz.newMeth(C$, 'getInChIStereo$I$I$I',  function (oclOrder, oclType, oclParity) {
if (oclOrder == 1) {
switch (oclType) {
case 129:
return $I$(12).SINGLE_1DOWN;
case 257:
return $I$(12).SINGLE_1UP;
default:
if (oclParity == 3) {
return (oclOrder == 2 ? $I$(12).DOUBLE_EITHER : $I$(12).SINGLE_1EITHER);
}}
}return $I$(12).NONE;
}, 1);

Clazz.newMeth(C$, 'initializeInchiModel$S',  function (inchi) {
this.jniInchiStructure=$I$(3,"getStructureFromInchi$net_sf_jniinchi_JniInchiInputInchi",[Clazz.new_($I$(2,1).c$$S,[inchi])]);
for (var i=this.getNumAtoms$(); --i >= 0; ) this.mapAtomToIndex.put$O$O(this.jniInchiStructure.getAtom$I(i), Integer.valueOf$I(i));

});

Clazz.newMeth(C$, 'getNumAtoms$',  function () {
return this.jniInchiStructure.getNumAtoms$();
});

Clazz.newMeth(C$, 'setAtom$I',  function (i) {
this.thisAtom=this.jniInchiStructure.getAtom$I(i);
return this;
});

Clazz.newMeth(C$, 'getElementType$',  function () {
return this.thisAtom.getElementType$();
});

Clazz.newMeth(C$, 'getX$',  function () {
return this.thisAtom.getX$();
});

Clazz.newMeth(C$, 'getY$',  function () {
return this.thisAtom.getY$();
});

Clazz.newMeth(C$, 'getZ$',  function () {
return this.thisAtom.getZ$();
});

Clazz.newMeth(C$, 'getCharge$',  function () {
return this.thisAtom.getCharge$();
});

Clazz.newMeth(C$, 'getIsotopicMass$',  function () {
return $I$(13,"getActualMass$S$I",[this.getElementType$(), this.thisAtom.getIsotopicMass$()]);
});

Clazz.newMeth(C$, 'getImplicitH$',  function () {
return this.thisAtom.getImplicitH$();
});

Clazz.newMeth(C$, 'getNumBonds$',  function () {
return this.jniInchiStructure.getNumBonds$();
});

Clazz.newMeth(C$, 'setBond$I',  function (i) {
this.thisBond=this.jniInchiStructure.getBond$I(i);
return this;
});

Clazz.newMeth(C$, 'getIndexOriginAtom$',  function () {
return this.mapAtomToIndex.get$O(this.thisBond.getOriginAtom$()).intValue$();
});

Clazz.newMeth(C$, 'getIndexTargetAtom$',  function () {
return this.mapAtomToIndex.get$O(this.thisBond.getTargetAtom$()).intValue$();
});

Clazz.newMeth(C$, 'getInchiBondType$',  function () {
return this.thisBond.getBondType$().name$();
});

Clazz.newMeth(C$, 'getNumStereo0D$',  function () {
return this.jniInchiStructure.getNumStereo0D$();
});

Clazz.newMeth(C$, 'setStereo0D$I',  function (i) {
this.thisStereo=this.jniInchiStructure.getStereo0D$I(i);
return this;
});

Clazz.newMeth(C$, 'getNeighbors$',  function () {
var an=this.thisStereo.getNeighbors$();
var n=an.length;
var a=Clazz.array(Integer.TYPE, [n]);
for (var i=0; i < n; i++) {
a[i]=this.mapAtomToIndex.get$O(an[i]).intValue$();
}
return a;
});

Clazz.newMeth(C$, 'getCenterAtom$',  function () {
var ca=this.thisStereo.getCentralAtom$();
return (ca == null  ? -1 : this.mapAtomToIndex.get$O(ca).intValue$());
});

Clazz.newMeth(C$, 'getStereoType$',  function () {
return this.thisStereo.getStereoType$().toString();
});

Clazz.newMeth(C$, 'getParity$',  function () {
return this.thisStereo.getParity$().toString();
});

Clazz.newMeth(C$, 'toJSON$net_sf_jniinchi_JniInchiOutputStructure',  function (inchiModel) {
var na=inchiModel.getNumAtoms$();
var nb=inchiModel.getNumBonds$();
var ns=inchiModel.getNumStereo0D$();
var mapAtoms=Clazz.new_($I$(14,1));
var haveXYZ=false;
for (var i=0; i < na; i++) {
var a=inchiModel.getAtom$I(i);
if (a.getX$() != 0  || a.getY$() != 0   || a.getZ$() != 0  ) {
haveXYZ=true;
break;
}}
var s="{";
s+="\n\"atomCount\":" + na + ",\n" ;
s+="\"atoms\":[\n";
for (var i=0; i < na; i++) {
var a=inchiModel.getAtom$I(i);
mapAtoms.put$O$O(a, Integer.valueOf$I(i));
if (i > 0) s+=",\n";
s+="{";
s+=C$.toJSONInt$S$I$S("index", (Integer.valueOf$I(i)).$c(), "");
s+=C$.toJSONNotNone$S$O$S("elname", a.getElementType$(), ",");
if (haveXYZ) {
s+=C$.toJSONDouble$S$D$S("x", a.getX$(), ",");
s+=C$.toJSONDouble$S$D$S("y", a.getY$(), ",");
s+=C$.toJSONDouble$S$D$S("z", a.getZ$(), ",");
}s+=C$.toJSONNotNone$S$O$S("radical", a.getRadical$(), ",");
s+=C$.toJSONNonZero$S$I$S("charge", a.getCharge$(), ",");
s+=C$.toJSONNonZero$S$I$S("isotopeMass", a.getIsotopicMass$(), ",");
if (a.getImplicitH$() > 0) s+=C$.toJSONNonZero$S$I$S("implicitH", a.getImplicitH$(), ",");
s+=C$.toJSONNonZero$S$I$S("implicitDeuterium", a.getImplicitDeuterium$(), ",");
s+=C$.toJSONNonZero$S$I$S("implicitProtium", a.getImplicitProtium$(), ",");
s+=C$.toJSONNonZero$S$I$S("implicitTritium", a.getImplicitTritium$(), ",");
s+="}";
}
s+="\n],";
s+="\n\"bondCount\":" + nb + "," ;
s+="\n\"bonds\":[\n";
for (var i=0; i < nb; i++) {
if (i > 0) s+=",\n";
s+="{";
var b=inchiModel.getBond$I(i);
s+=C$.toJSONInt$S$I$S("originAtom", mapAtoms.get$O(b.getOriginAtom$()).intValue$(), "");
s+=C$.toJSONInt$S$I$S("targetAtom", mapAtoms.get$O(b.getTargetAtom$()).intValue$(), ",");
var bt=b.getBondType$().toString();
if (!bt.equals$O("SINGLE")) s+=C$.toJSONString$S$S$S("type", bt, ",");
s+=C$.toJSONNotNone$S$O$S("stereo", b.getBondStereo$(), ",");
s+="}";
}
s+="\n]";
if (ns > 0) {
s+=",\n\"stereoCount\":" + ns + ",\n" ;
s+="\"stereo\":[\n";
for (var i=0; i < ns; i++) {
if (i > 0) s+=",\n";
s+="{";
var d=inchiModel.getStereo0D$I(i);
var a=d.getCentralAtom$();
s+=C$.toJSONNotNone$S$O$S("parity", d.getParity$(), "");
s+=C$.toJSONNotNone$S$O$S("type", d.getStereoType$(), ",");
if (a != null ) s+=C$.toJSONInt$S$I$S("centralAtom", mapAtoms.get$O(a).intValue$(), ",");
var an=d.getNeighbors$();
var nbs=Clazz.array(Integer.TYPE, [an.length]);
for (var j=0; j < an.length; j++) {
nbs[j]=mapAtoms.get$O(d.getNeighbor$I(j)).intValue$();
}
s+=C$.toJSONArray$S$IA$S("neighbors", nbs, ",");
s+="}";
}
s+="\n]";
}s+="}";
return s;
}, 1);

Clazz.newMeth(C$, 'toJSONArray$S$IA$S',  function (key, val, term) {
var s=term + "\"" + key + "\":[" + val[0] ;
for (var i=1; i < val.length; i++) {
s+="," + val[i];
}
return s + "]";
}, 1);

Clazz.newMeth(C$, 'toJSONNonZero$S$I$S',  function (key, val, term) {
return (val == 0 ? "" : C$.toJSONInt$S$I$S(key, val, term));
}, 1);

Clazz.newMeth(C$, 'toJSONInt$S$I$S',  function (key, val, term) {
return term + "\"" + key + "\":" + val ;
}, 1);

Clazz.newMeth(C$, 'toJSONDouble$S$D$S',  function (key, val, term) {
var s;
if (val == 0 ) {
s="0";
} else {
s="" + (new Double(val + (val > 0  ? 1.0E-8 : -1.0E-8)).toString());
s=s.substring$I$I(0, s.indexOf$S(".") + 5);
var n=s.length$();
while (s.charAt$I(--n) == "0"){
}
s=s.substring$I$I(0, n + 1);
}return term + "\"" + key + "\":" + s ;
}, 1);

Clazz.newMeth(C$, 'toJSONString$S$S$S',  function (key, val, term) {
return term + "\"" + key + "\":\"" + val + "\"" ;
}, 1);

Clazz.newMeth(C$, 'toJSONNotNone$S$O$S',  function (key, val, term) {
var s=val.toString();
return ("NONE".equals$O(s) ? "" : term + "\"" + key + "\":\"" + s + "\"" );
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-15 22:26:00 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
