114D - dna with some HOH
1A00 - hemoglobin ... nothing strange
1A7C - ? 
1ALE - multiple conformations ... small
1ALM - alpha carbons only ... large
1ARJ - multiple conformations ... large
1B07 - ?
1CRN - RasMol classic
1D66 - DNA + protein ... group 28 is oriented incorrectly
1D68 - short dna section
1EBL - ?
1GFL - green florescent
1HJE - alternate locations
1IHA - ?
1JGQ - alpha carbon only + phosphorus only + dna
1LCD - multiple conformations
1MBO - has strange FORMUL records because the HEM is on two lines
1NE6 - ?
1OHG - large spiral with large header
1OLD - dna with something hanging off of it
1PN8 - alpha carbon only protein AND phosphorus-only nucleic polymer
233D - dna with something strange
2CYH - ?
3DFR - ?
3OVO - ?
5CRO - ?
fullRhinovirus.pdb.gz - rather large: almost 400K atoms ... 392520 atoms


modified files for testing Jmol secondary structure predictions:
1CRN_noSS - 1CRN with secondary structure records removed.
1NE6_noSS - 1NE6 with secondary structure records removed.
3DFR_noSS - 3DFR with secondary structure records removed.

