miguel 2005 07 17

search mailing list archives during July 2005

useful URLs

http://ftp.ccl.net/cca/software/SOURCES/C/scarecrow/gcube2plt.c
http://www.cup.uni-muenchen.de/oc/zipse/lv18099/orb_MOLDEN.html
http://www.nersc.gov/nusers/resources/software/apps/chemistry/gaussian/g98/00000430.htm

this contains some erroneous info
http://astronomy.swin.edu.au/~pbourke/geomformats/cube/

the g98help.zip file contains the gaussian 98 info ... not much
