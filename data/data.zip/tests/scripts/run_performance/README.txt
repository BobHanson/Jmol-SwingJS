This directory contains script files for testing Jmol features.
All .spt files will be run automatically by JUnit tests for testing script execution.
The time taken to run each command will also be measured.
