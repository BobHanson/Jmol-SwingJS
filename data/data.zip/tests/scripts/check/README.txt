This directory contains script files for testing Jmol features.
All .spt files will be run automatically by JUnit tests for testing script syntax (no actual execution of scripts).


monster_script.spt should be the same here as in ../run