resources/

place here files that will go into the site/swingjs/j2s directory
such as images that will be available to JavaScript classes.

Note that you may have to duplicate data files if your root 
directory in Java is the project default directory. 