(function(){var P$=Clazz.newPackage("org.jmol.awtjs2d"),I$=[[0,'org.jmol.awtjs2d.JSPopupHelper']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JSModelKitPopup", null, 'org.jmol.modelkit.ModelKitPopup');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.helper=Clazz.new_($I$(1,1).c$$org_jmol_popup_GenericPopup,[this]);
}, 1);

Clazz.newMeth(C$, 'menuShowPopup$org_jmol_api_SC$I$I',  function (popup, x, y) {
try {
(popup).show$org_jmol_awtjs_swing_Component$I$I(this.isTainted ? this.vwr.html5Applet : null, x, y);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
this.isTainted=false;
});

Clazz.newMeth(C$, 'menuHidePopup$org_jmol_api_SC',  function (popup) {
try {
(popup).setVisible$Z(false);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'getImageIcon$S',  function (fileName) {
return "org/jmol/modelkit/images/" + fileName;
});

Clazz.newMeth(C$, 'menuCheckBoxCallback$org_jmol_api_SC',  function (source) {
this.doMenuCheckBoxCallback$org_jmol_api_SC(source);
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:43 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
