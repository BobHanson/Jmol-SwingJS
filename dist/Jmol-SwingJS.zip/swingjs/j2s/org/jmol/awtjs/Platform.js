(function(){var P$=Clazz.newPackage("org.jmol.awtjs"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Platform", null, 'org.jmol.awtjs2d.Platform');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'drawImage$O$O$I$I$I$I$Z',  function (g, img, x, y, width, height, isDTI) {
});

Clazz.newMeth(C$, 'getTextPixels$S$org_jmol_util_Font$O$O$I$I$I',  function (text, font3d, gObj, image, width, height, ascent) {
return null;
});

Clazz.newMeth(C$, 'getGraphics$O',  function (image) {
return null;
});

Clazz.newMeth(C$, 'getStaticGraphics$O$Z',  function (image, backgroundTransparent) {
return null;
});

Clazz.newMeth(C$, 'newBufferedImage$O$I$I',  function (image, w, h) {
return null;
});

Clazz.newMeth(C$, 'newOffScreenImage$I$I',  function (w, h) {
return null;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:43 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
