(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "JRadioButtonMenuItem", null, 'org.jmol.awtjs.swing.JMenuItem');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.isRadio=true;
},1);

C$.$fields$=[['Z',['isRadio']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$S$I.apply(this,["rad", 3]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-09-01 22:08:10 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
