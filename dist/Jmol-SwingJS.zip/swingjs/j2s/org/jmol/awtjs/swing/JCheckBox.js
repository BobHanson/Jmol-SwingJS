(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "JCheckBox", null, 'org.jmol.awtjs.swing.AbstractButton');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$S.apply(this,["chkJCB"]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'toHTML$',  function () {
var s="<label><input type=checkbox id='" + this.id + "' class='JCheckBox' style='" + this.getCSSstyle$I$I(0, 0) + "' " + (this.selected ? "checked=\'checked\' " : "") + "onclick='SwingController.click(this)'>" + this.text + "</label>" ;
return s;
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:43 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
