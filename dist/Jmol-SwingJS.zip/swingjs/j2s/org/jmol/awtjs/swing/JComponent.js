(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "JComponent", null, 'org.jmol.awtjs.swing.Container');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['autoScrolls'],'S',['actionCommand'],'O',['actionListener','java.lang.Object']]]

Clazz.newMeth(C$, 'c$$S',  function (type) {
;C$.superclazz.c$$S.apply(this,[type]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'setAutoscrolls$Z',  function (b) {
this.autoScrolls=b;
});

Clazz.newMeth(C$, 'addActionListener$O',  function (listener) {
this.actionListener=listener;
});

Clazz.newMeth(C$, 'getActionCommand$',  function () {
return this.actionCommand;
});

Clazz.newMeth(C$, 'setActionCommand$S',  function (actionCommand) {
this.actionCommand=actionCommand;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:43 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
