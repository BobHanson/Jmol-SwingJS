(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Insets");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['top','left','bottom','right']]]

Clazz.newMeth(C$, 'c$$I$I$I$I',  function (top, left, bottom, right) {
;C$.$init$.apply(this);
this.top=top;
this.left=left;
this.bottom=bottom;
this.right=right;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:43 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
