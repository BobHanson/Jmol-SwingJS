(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Dimension");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['width','height']]]

Clazz.newMeth(C$, 'c$$I$I',  function (w, h) {
;C$.$init$.apply(this);
this.set$I$I(w, h);
}, 1);

Clazz.newMeth(C$, 'set$I$I',  function (w, h) {
this.width=w;
this.height=h;
return this;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:43 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
