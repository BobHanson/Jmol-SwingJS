(function(){var P$=Clazz.newPackage("org.jmol.adapter.smarter"),p$1={},p$2={},I$=[[0,'org.jmol.symmetry.SpaceGroup','org.jmol.util.Logger','org.jmol.symmetry.SymmetryOperation','org.jmol.symmetry.UnitCell','javajs.util.M4d','javajs.util.M3d','javajs.util.P3d','javajs.util.PT','javajs.util.A4d','javajs.util.V3d','java.util.HashSet',['org.jmol.adapter.smarter.XtalSymmetry','.FileSymmetry'],'java.util.Hashtable','javajs.util.BS','org.jmol.adapter.smarter.Atom','org.jmol.util.BSUtil','org.jmol.util.SimpleUnitCell','javajs.util.P3i','javajs.util.SB','javajs.util.Lst']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "XtalSymmetry", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['FileSymmetry',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.bondsFound=Clazz.new_($I$(11,1));
this.doNormalize=true;
this.ndims=3;
this.ptOffset=Clazz.new_($I$(7,1));
this.unitCellParams=null;
},1);

C$.$fields$=[['Z',['applySymmetryToBonds','centroidPacked','checkAll','checkNearAtoms','crystalReaderLatticeOpsOnly','doCentroidUnitCell','doNormalize','doPackUnitCell'],'D',['packingRange','symmetryRange'],'I',['bondCount0','disorderMapMax','firstAtom','latticeOp','ndims','noSymmetryCount'],'S',['filterSymop'],'O',['acr','org.jmol.adapter.smarter.AtomSetCollectionReader','asc','org.jmol.adapter.smarter.AtomSetCollection','baseSymmetry','org.jmol.adapter.smarter.XtalSymmetry.FileSymmetry','bondsFound','java.util.Set','disorderMap','java.util.Map','latticeCells','int[]','mident','javajs.util.M4d','minXYZ','javajs.util.P3i','+maxXYZ','minXYZ0','javajs.util.P3d','+maxXYZ0','mTemp','javajs.util.M3d','ptOffset','javajs.util.P3d','+ptTemp','+rmin','+rmax','symmetry','org.jmol.adapter.smarter.XtalSymmetry.FileSymmetry','trajectoryUnitCells','javajs.util.Lst','unitCellParams','double[]','unitCellTranslations','javajs.util.V3d[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'addRotatedTensor$org_jmol_adapter_smarter_Atom$org_jmol_util_Tensor$I$Z$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry',  function (a, t, iSym, reset, symmetry) {
if (this.ptTemp == null ) {
this.ptTemp=Clazz.new_($I$(7,1));
this.mTemp=Clazz.new_($I$(6,1));
}return a.addTensor$org_jmol_util_Tensor$S$Z((this.acr.getInterface$S("org.jmol.util.Tensor")).setFromEigenVectors$javajs_util_T3dA$DA$S$S$org_jmol_util_Tensor(symmetry.rotateAxes$I$javajs_util_V3dA$javajs_util_P3d$javajs_util_M3d(iSym, t.eigenVectors, this.ptTemp, this.mTemp), t.eigenValues, t.isIsotropic ? "iso" : t.type, t.id, t), null, reset);
});

Clazz.newMeth(C$, 'applySymmetryBio$java_util_Map$Z$S',  function (thisBiomolecule, applySymmetryToBonds, filter) {
var biomts=thisBiomolecule.get$O("biomts");
var len=biomts.size$();
if (this.mident == null ) {
this.mident=Clazz.new_($I$(5,1));
this.mident.setIdentity$();
}this.acr.lstNCS=null;
p$2.setLatticeCells.apply(this, []);
var lc=(this.latticeCells != null  && this.latticeCells[0] != 0  ? Clazz.array(Integer.TYPE, [3]) : null);
if (lc != null ) for (var i=0; i < 3; i++) lc[i]=this.latticeCells[i];

this.latticeCells=null;
var sep="";
var bmChains=this.acr.getFilterWithCase$S("BMCHAINS");
var fixBMChains=-1;
if (bmChains != null  && (bmChains=bmChains.trim$()).length$() > 0 ) {
if (bmChains.charAt$I(0) == "=") bmChains=bmChains.substring$I(1).trim$();
if (bmChains.equals$O("_")) {
sep="_";
fixBMChains=0;
} else {
fixBMChains=(bmChains.length$() == 0 ? 0 : $I$(8).parseInt$S(bmChains));
if (fixBMChains == -2147483648) {
fixBMChains=-bmChains.charAt$I(0).$c();
}}}var particleMode=(filter.indexOf$S("BYCHAIN") >= 0 ? 1 : filter.indexOf$S("BYSYMOP") >= 0 ? 2 : 0);
this.doNormalize=false;
var biomtchains=thisBiomolecule.get$O("chains");
(this.symmetry=Clazz.new_($I$(12,1))).setSpaceGroup$Z(this.doNormalize);
this.addSpaceGroupOperation$S$Z("x,y,z", false);
var name=thisBiomolecule.get$O("name");
p$2.setAtomSetSpaceGroupName$S.apply(this, [this.acr.sgName=name]);
this.applySymmetryToBonds=applySymmetryToBonds;
this.bondCount0=this.asc.bondCount;
this.firstAtom=this.asc.getLastAtomSetAtomIndex$();
var atomMax=this.asc.ac;
var ht=Clazz.new_($I$(13,1));
var nChain=0;
var atoms=this.asc.atoms;
var addBonds=(this.bondCount0 > this.asc.bondIndex0 && applySymmetryToBonds );
switch (particleMode) {
case 1:
for (var i=atomMax; --i >= this.firstAtom; ) {
var id=Integer.valueOf$I(atoms[i].chainID);
var bs=ht.get$O(id);
if (bs == null ) {
++nChain;
ht.put$O$O(id, bs=Clazz.new_($I$(14,1)));
}bs.set$I(i);
}
this.asc.bsAtoms=Clazz.new_($I$(14,1));
for (var i=0; i < nChain; i++) {
this.asc.bsAtoms.set$I(atomMax + i);
var a=Clazz.new_($I$(15,1));
a.set$D$D$D(0, 0, 0);
a.radius=16;
this.asc.addAtom$org_jmol_adapter_smarter_Atom(a);
}
var ichain=0;
for (var e, $e = ht.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) {
var a=atoms[atomMax + ichain++];
var bs=e.getValue$();
for (var i=bs.nextSetBit$I(0); i >= 0; i=bs.nextSetBit$I(i + 1)) a.add$javajs_util_T3d(atoms[i]);

a.scale$D(1.0 / bs.cardinality$());
a.atomName="Pt" + ichain;
a.chainID=e.getKey$().intValue$();
}
this.firstAtom=atomMax;
atomMax+=nChain;
addBonds=false;
break;
case 2:
this.asc.bsAtoms=Clazz.new_($I$(14,1));
this.asc.bsAtoms.set$I(atomMax);
var a=atoms[atomMax]=Clazz.new_($I$(15,1));
a.set$D$D$D(0, 0, 0);
for (var i=atomMax; --i >= this.firstAtom; ) a.add$javajs_util_T3d(atoms[i]);

a.scale$D(1.0 / (atomMax - this.firstAtom));
a.atomName="Pt";
a.radius=16;
this.asc.addAtom$org_jmol_adapter_smarter_Atom(a);
this.firstAtom=atomMax++;
addBonds=false;
break;
}
var assemblyIdAtoms=thisBiomolecule.get$O("asemblyIdAtoms");
if (filter.indexOf$S("#<") >= 0) {
len=Math.min(len, $I$(8,"parseInt$S",[filter.substring$I(filter.indexOf$S("#<") + 2)]) - 1);
filter=$I$(8).rep$S$S$S(filter, "#<", "_<");
}var maxChain=0;
for (var iAtom=this.firstAtom; iAtom < atomMax; iAtom++) {
atoms[iAtom].bsSymmetry=Clazz.new_($I$(14,1));
var chainID=atoms[iAtom].chainID;
if (chainID > maxChain) maxChain=chainID;
}
var bsAtoms=this.asc.bsAtoms;
var atomMap=(addBonds ? Clazz.array(Integer.TYPE, [this.asc.ac]) : null);
for (var imt=(biomtchains == null  ? 1 : 0); imt < len; imt++) {
if (filter.indexOf$S("!#") >= 0) {
if (filter.indexOf$S("!#" + (imt + 1) + ";" ) >= 0) continue;
} else if (filter.indexOf$S("#") >= 0 && filter.indexOf$S("#" + (imt + 1) + ";" ) < 0 ) {
continue;
}var mat=biomts.get$I(imt);
var notIdentity=!mat.equals$O(this.mident);
var chains=(biomtchains == null  ? null : biomtchains.get$I(imt));
if (chains != null  && assemblyIdAtoms != null  ) {
bsAtoms=Clazz.new_($I$(14,1));
for (var e, $e = assemblyIdAtoms.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) if (chains.indexOf$S(":" + e.getKey$() + ";" ) >= 0) bsAtoms.or$javajs_util_BS(e.getValue$());

if (this.asc.bsAtoms != null ) bsAtoms.and$javajs_util_BS(this.asc.bsAtoms);
chains=null;
}var lastID=-1;
var id;
var skipping=false;
for (var iAtom=this.firstAtom; iAtom < atomMax; iAtom++) {
if (bsAtoms != null ) {
skipping=!bsAtoms.get$I(iAtom);
} else if (chains != null  && (id=atoms[iAtom].chainID) != lastID ) {
skipping=(chains.indexOf$S(":" + this.acr.vwr.getChainIDStr$I(lastID=id) + ";" ) < 0);
}if (skipping) continue;
try {
var atomSite=atoms[iAtom].atomSite;
var atom1;
if (addBonds) atomMap[atomSite]=this.asc.ac;
atom1=this.asc.newCloneAtom$org_jmol_adapter_smarter_Atom(atoms[iAtom]);
atom1.bondingRadius=imt;
this.asc.atomSymbolicMap.put$O$O("" + atom1.atomSerial, atom1);
if (this.asc.bsAtoms != null ) this.asc.bsAtoms.set$I(atom1.index);
atom1.atomSite=atomSite;
if (notIdentity) mat.rotTrans$javajs_util_T3d(atom1);
atom1.bsSymmetry=$I$(16).newAndSetBit$I(imt);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.asc.errorMessage="appendAtomCollection error: " + e;
} else {
throw e;
}
}
}
if (notIdentity) this.symmetry.addBioMoleculeOperation$javajs_util_M4d$Z(mat, false);
if (addBonds) {
for (var bondNum=this.asc.bondIndex0; bondNum < this.bondCount0; bondNum++) {
var bond=this.asc.bonds[bondNum];
var iAtom1=atomMap[atoms[bond.atomIndex1].atomSite];
var iAtom2=atomMap[atoms[bond.atomIndex2].atomSite];
this.asc.addNewBondWithOrder$I$I$I(iAtom1, iAtom2, bond.order);
}
}}
if (biomtchains != null ) {
if (this.asc.bsAtoms == null ) this.asc.bsAtoms=$I$(16).newBitSet2$I$I(0, this.asc.ac);
this.asc.bsAtoms.clearBits$I$I(this.firstAtom, atomMax);
if (particleMode == 0) {
if (fixBMChains != -1) {
var assignABC=(fixBMChains != 0);
var bsChains=(assignABC ? Clazz.new_($I$(14,1)) : null);
atoms=this.asc.atoms;
var firstNew=0;
if (assignABC) {
firstNew=(fixBMChains < 0 ? Math.max(-fixBMChains, maxChain + 1) : Math.max(maxChain + fixBMChains, 65));
bsChains.setBits$I$I(0, firstNew - 1);
bsChains.setBits$I$I(91, 97);
bsChains.setBits$I$I(123, 200);
}var bsAll=(this.asc.structureCount == 1 ? this.asc.structures[0].bsAll : null);
var chainMap=Clazz.new_($I$(13,1));
var knownMap=Clazz.new_($I$(13,1));
var knownAtomMap=(bsAll == null  ? null : Clazz.new_($I$(13,1)));
var lastKnownAtom=null;
for (var i=atomMax, n=this.asc.ac; i < n; i++) {
var ic=atoms[i].chainID;
var isym=atoms[i].bsSymmetry.nextSetBit$I(0);
var ch0=this.acr.vwr.getChainIDStr$I(ic);
var ch=(isym == 0 ? ch0 : ch0 + sep + isym );
var known=chainMap.get$O(ch);
if (known == null ) {
if (assignABC && isym != 0 ) {
var pt=(firstNew < 200 ? bsChains.nextClearBit$I(firstNew) : 200);
if (pt < 200) {
bsChains.set$I(pt);
known=Integer.valueOf$I(this.acr.vwr.getChainID$S$Z("" + String.fromCharCode(pt), true));
firstNew=pt;
} else {
}}if (known == null ) known=Integer.valueOf$I(this.acr.vwr.getChainID$S$Z(ch, true));
if (ch != ch0) {
knownMap.put$O$O(known, Integer.valueOf$I(ic));
if (bsAll != null ) {
if (lastKnownAtom != null ) lastKnownAtom[1]=i;
knownAtomMap.put$O$O(known, lastKnownAtom=Clazz.array(Integer.TYPE, -1, [i, n]));
}}chainMap.put$O$O(ch, known);
}atoms[i].chainID=known.intValue$();
}
if (this.asc.structureCount > 0) {
var strucs=this.asc.structures;
var nStruc=this.asc.structureCount;
for (var e, $e = knownMap.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) {
var known=e.getKey$();
var ch1=known.intValue$();
var ch0=e.getValue$().intValue$();
for (var i=0; i < nStruc; i++) {
var s=strucs[i];
if (s.bsAll != null ) {
} else if (s.startChainID == s.endChainID) {
if (s.startChainID == ch0) {
var s1=s.clone$();
s1.startChainID=s1.endChainID=ch1;
this.asc.addStructure$org_jmol_adapter_smarter_Structure(s1);
}} else {
System.err.println$S("XtalSymmetry not processing biomt chain structure " + this.acr.vwr.getChainIDStr$I(ch0) + " to " + this.acr.vwr.getChainIDStr$I(ch1) );
}}
}
}}var vConnect=this.asc.getAtomSetAuxiliaryInfoValue$I$S(-1, "PDB_CONECT_bonds");
if (!addBonds && vConnect != null  ) {
for (var i=vConnect.size$(); --i >= 0; ) {
var bond=vConnect.get$I(i);
var a=this.asc.getAtomFromName$S("" + bond[0]);
var b=this.asc.getAtomFromName$S("" + bond[1]);
if (a != null  && b != null   && a.bondingRadius != b.bondingRadius   && (bsAtoms == null  || bsAtoms.get$I(a.index) && bsAtoms.get$I(b.index)  )  && a.distanceSquared$javajs_util_T3d(b) > 25.0  ) {
vConnect.removeItemAt$I(i);
System.out.println$S("XtalSymmetry: long interchain bond removed for @" + a.atomSerial + "-@" + b.atomSerial );
}}
}}for (var i=atomMax, n=this.asc.ac; i < n; i++) {
this.asc.atoms[i].bondingRadius=NaN;
}
}this.noSymmetryCount=atomMax - this.firstAtom;
p$2.finalizeSymmetry$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry.apply(this, [this.symmetry]);
p$2.setCurrentModelInfo$I$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry$IA.apply(this, [len, null, null]);
p$2.reset.apply(this, []);
});

Clazz.newMeth(C$, 'getBaseSymmetry$',  function () {
return (this.baseSymmetry == null  ? this.symmetry : this.baseSymmetry);
});

Clazz.newMeth(C$, 'getSymmetry$',  function () {
return (this.symmetry == null  ? (this.symmetry=Clazz.new_($I$(12,1))) : this.symmetry);
});

Clazz.newMeth(C$, 'getOverallSpan$',  function () {
return (this.maxXYZ0 == null  ? $I$(10).new3$D$D$D(this.maxXYZ.x - this.minXYZ.x, this.maxXYZ.y - this.minXYZ.y, this.maxXYZ.z - this.minXYZ.z) : $I$(10).newVsub$javajs_util_T3d$javajs_util_T3d(this.maxXYZ0, this.minXYZ0));
});

Clazz.newMeth(C$, 'isWithinCell$I$javajs_util_P3d$D$D$D$D$D$D$D',  function (ndims, pt, minX, maxX, minY, maxY, minZ, maxZ, slop) {
return (pt.x > minX - slop  && pt.x < maxX + slop   && (ndims < 2 || pt.y > minY - slop  && pt.y < maxY + slop   )  && (ndims < 3 || pt.z > minZ - slop  && pt.z < maxZ + slop   ) );
});

Clazz.newMeth(C$, 'set$org_jmol_adapter_smarter_AtomSetCollectionReader',  function (reader) {
this.acr=reader;
this.asc=reader.asc;
this.getSymmetry$();
return this;
});

Clazz.newMeth(C$, 'setLatticeParameter$I',  function (latt) {
this.symmetry.setSpaceGroup$Z(this.doNormalize);
this.symmetry.setLattice$I(latt);
});

Clazz.newMeth(C$, 'addSpaceGroupOperation$S$Z',  function (xyz, andSetLattice) {
this.symmetry.setSpaceGroup$Z(this.doNormalize);
if (andSetLattice && this.symmetry.getSpaceGroupOperationCount$() == 1 ) p$2.setLatticeCells.apply(this, []);
return this.symmetry.addSpaceGroupOperation$S$I(xyz, 0);
});

Clazz.newMeth(C$, 'setSymmetryFromAuditBlock$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry',  function (symmetry) {
return (this.symmetry=symmetry);
});

Clazz.newMeth(C$, 'applySymmetryFromReader$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry',  function (readerSymmetry) {
this.asc.setCoordinatesAreFractional$Z(this.acr.iHaveFractionalCoordinates);
p$2.setAtomSetSpaceGroupName$S.apply(this, [this.acr.sgName]);
this.symmetryRange=this.acr.symmetryRange;
this.asc.setInfo$S$O("symmetryRange", Double.valueOf$D(this.symmetryRange));
if (this.acr.doConvertToFractional || this.acr.fileCoordinatesAreFractional ) {
p$2.setLatticeCells.apply(this, []);
var doApplySymmetry=true;
if (this.acr.ignoreFileSpaceGroupName || !this.acr.iHaveSymmetryOperators ) {
if (!this.acr.merging || readerSymmetry == null  ) readerSymmetry=Clazz.new_($I$(12,1));
if (this.acr.unitCellParams[0] == 0  && this.acr.unitCellParams[2] == 0  ) {
$I$(17).fillParams$javajs_util_V3d$javajs_util_V3d$javajs_util_V3d$DA(null, null, null, this.acr.unitCellParams);
}doApplySymmetry=readerSymmetry.createSpaceGroup$I$S$O$I(this.acr.desiredSpaceGroupIndex, (this.acr.sgName.indexOf$S("!") >= 0 ? "P1" : this.acr.sgName), this.acr.unitCellParams, this.acr.modDim);
} else {
this.acr.doPreSymmetry$Z(doApplySymmetry);
readerSymmetry=null;
}this.packingRange=this.acr.getPackingRangeValue$D(0);
if (doApplySymmetry) {
if (readerSymmetry != null ) this.getSymmetry$().setSpaceGroupTo$O(readerSymmetry.getSpaceGroup$());
p$2.applySymmetryLattice.apply(this, []);
if (readerSymmetry != null  && this.filterSymop == null  ) p$2.setAtomSetSpaceGroupName$S.apply(this, [readerSymmetry.getSpaceGroupName$()]);
} else {
p$2.setUnitCellSafely.apply(this, []);
}}if (this.acr.iHaveFractionalCoordinates && this.acr.merging && readerSymmetry != null   ) {
var atoms=this.asc.atoms;
for (var i=this.asc.getLastAtomSetAtomIndex$(), n=this.asc.ac; i < n; i++) readerSymmetry.toCartesian$javajs_util_T3d$Z(atoms[i], true);

this.asc.setCoordinatesAreFractional$Z(false);
this.acr.addVibrations=false;
}return this.symmetry;
});

Clazz.newMeth(C$, 'finalizeMoments$S$S',  function (spinFrame, spinFrameExt) {
this.getSymmetry$().preSymmetryFinalizeMoments$org_jmol_adapter_smarter_AtomSetCollectionReader$org_jmol_adapter_smarter_AtomSetCollection$S$S(this.acr, this.asc, spinFrame, spinFrameExt);
});

Clazz.newMeth(C$, 'setMagneticMoments$Z',  function (isCartesian) {
return (this.asc.iSet < 0 || !this.acr.vibsFractional  ? 0 : this.getBaseSymmetry$().postSymmetrySetMagneticMoments$org_jmol_adapter_smarter_AtomSetCollection$Z(this.asc, isCartesian));
});

Clazz.newMeth(C$, 'setTensors$',  function () {
var n=this.asc.ac;
for (var i=this.asc.getLastAtomSetAtomIndex$(); i < n; i++) {
var a=this.asc.atoms[i];
if (a.anisoBorU == null ) continue;
a.addTensor$org_jmol_util_Tensor$S$Z(this.symmetry.getTensor$org_jmol_viewer_Viewer$DA(this.acr.vwr, a.anisoBorU), null, false);
if (Double.isNaN$D(a.bfactor)) a.bfactor=a.anisoBorU[7] * 100.0;
a.anisoBorU=null;
}
});

Clazz.newMeth(C$, 'adjustRangeMinMax$javajs_util_T3dA',  function (oabc) {
this.symmetry.adjustRangeMinMax$javajs_util_T3dA$D$javajs_util_P3i$javajs_util_P3i$javajs_util_P3d$javajs_util_P3d$javajs_util_P3i$javajs_util_P3i(oabc, (this.acr.forcePacked ? this.packingRange : NaN), this.minXYZ, this.maxXYZ, this.rmin, this.rmax, this.minXYZ, this.maxXYZ);
}, p$2);

Clazz.newMeth(C$, 'applyAllSymmetry$org_jmol_adapter_smarter_MSInterface$javajs_util_BS',  function (ms, bsAtoms) {
if (this.asc.ac == 0 || bsAtoms != null  && bsAtoms.isEmpty$()  ) return;
var n=this.noSymmetryCount=this.asc.baseSymmetryAtomCount > 0 ? this.asc.baseSymmetryAtomCount : bsAtoms == null  ? this.asc.getLastAtomSetAtomCount$() : this.asc.ac - bsAtoms.nextSetBit$I(this.asc.getLastAtomSetAtomIndex$());
this.asc.setTensors$();
this.applySymmetryToBonds=this.acr.applySymmetryToBonds;
this.doPackUnitCell=this.acr.doPackUnitCell && !this.applySymmetryToBonds ;
this.bondCount0=this.asc.bondCount;
this.ndims=$I$(17).getDimensionFromParams$DA(this.acr.unitCellParams);
p$2.finalizeSymmetry$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry.apply(this, [this.symmetry]);
var operationCount=this.symmetry.getSpaceGroupOperationCount$();
var excludedOps=(this.acr.thisBiomolecule == null  ? null : Clazz.new_($I$(14,1)));
this.checkNearAtoms=this.acr.checkNearAtoms || excludedOps != null  ;
$I$(17).setMinMaxLatticeParameters$I$javajs_util_P3i$javajs_util_P3i$I(this.ndims, this.minXYZ, this.maxXYZ, 0);
this.latticeOp=this.symmetry.getLatticeOp$();
this.crystalReaderLatticeOpsOnly=(this.asc.crystalReaderLatticeOpsOnly && this.latticeOp >= 0 );
if (this.doCentroidUnitCell) this.asc.setInfo$S$O("centroidMinMax", Clazz.array(Integer.TYPE, -1, [this.minXYZ.x, this.minXYZ.y, this.minXYZ.z, this.maxXYZ.x, this.maxXYZ.y, this.maxXYZ.z, (this.centroidPacked ? ((100 * this.packingRange)|0) : 0)]));
if (this.doCentroidUnitCell || this.acr.doPackUnitCell || this.symmetryRange != 0  && this.maxXYZ.x - this.minXYZ.x == 1  && this.maxXYZ.y - this.minXYZ.y == 1  && this.maxXYZ.z - this.minXYZ.z == 1   ) {
this.minXYZ0=$I$(7).new3$D$D$D(this.minXYZ.x, this.minXYZ.y, this.minXYZ.z);
this.maxXYZ0=$I$(7).new3$D$D$D(this.maxXYZ.x, this.maxXYZ.y, this.maxXYZ.z);
if (ms != null ) {
ms.setMinMax0$javajs_util_P3d$javajs_util_P3d(this.minXYZ0, this.maxXYZ0);
this.minXYZ.set$I$I$I((this.minXYZ0.x|0), (this.minXYZ0.y|0), (this.minXYZ0.z|0));
this.maxXYZ.set$I$I$I((this.maxXYZ0.x|0), (this.maxXYZ0.y|0), (this.maxXYZ0.z|0));
}switch (this.ndims) {
case 3:
--this.minXYZ.z;
++this.maxXYZ.z;
case 2:
--this.minXYZ.y;
++this.maxXYZ.y;
case 1:
--this.minXYZ.x;
++this.maxXYZ.x;
}
}var nCells=(this.maxXYZ.x - this.minXYZ.x) * (this.maxXYZ.y - this.minXYZ.y) * (this.maxXYZ.z - this.minXYZ.z) ;
var nsym=n * (this.crystalReaderLatticeOpsOnly ? 4 : operationCount);
var cartesianCount=(this.checkNearAtoms || this.acr.thisBiomolecule != null   ? nsym * nCells : this.symmetryRange > 0  ? nsym : 1);
var cartesians=Clazz.array($I$(7), [cartesianCount]);
var atoms=this.asc.atoms;
for (var i=0; i < n; i++) atoms[this.firstAtom + i].bsSymmetry=$I$(14,"newN$I",[operationCount * (nCells + 1)]);

var pt=0;
this.unitCellTranslations=Clazz.array($I$(10), [nCells]);
var iCell=0;
var cell555Count=0;
var absRange=Math.abs(this.symmetryRange);
var checkCartesianRange=(this.symmetryRange != 0 );
var checkRangeNoSymmetry=(this.symmetryRange < 0 );
var checkRange111=(this.symmetryRange > 0 );
if (checkCartesianRange) {
this.rmin=$I$(7).new3$D$D$D(1.7976931348623157E308, 1.7976931348623157E308, 1.7976931348623157E308);
this.rmax=$I$(7).new3$D$D$D(-1.7976931348623157E308, -1.7976931348623157E308, -1.7976931348623157E308);
}var sym=this.symmetry;
var lastSymmetry=sym;
this.checkAll=(this.crystalReaderLatticeOpsOnly || this.asc.atomSetCount == 1 && this.checkNearAtoms  && this.latticeOp >= 0  );
var lstNCS=this.acr.lstNCS;
if (lstNCS != null  && lstNCS.get$I(0).m33 == 0  ) {
var nOp=sym.getSpaceGroupOperationCount$();
var nn=lstNCS.size$();
for (var i=nn; --i >= 0; ) {
var m=lstNCS.get$I(i);
m.m33=1;
sym.toFractionalM$javajs_util_M4d(m);
}
for (var i=1; i < nOp; i++) {
var m1=sym.getSpaceGroupOperation$I(i);
for (var j=0; j < nn; j++) {
var m=$I$(5,"newM4$javajs_util_M4d",[lstNCS.get$I(j)]);
m.mul2$javajs_util_M4d$javajs_util_M4d(m1, m);
if (this.doNormalize && this.noSymmetryCount > 0 ) $I$(3).normalizeOperationToCentroid$I$javajs_util_M4d$javajs_util_P3dA$I$I(3, m, atoms, this.firstAtom, this.noSymmetryCount);
lstNCS.addLast$O(m);
}
}
}var pttemp=null;
var op=sym.getSpaceGroupOperation$I(0);
if (this.doPackUnitCell) {
pttemp=Clazz.new_($I$(7,1));
this.ptOffset.set$D$D$D(0, 0, 0);
}var atomMap=(this.bondCount0 > this.asc.bondIndex0 && this.applySymmetryToBonds  ? Clazz.array(Integer.TYPE, [n]) : null);
var unitCells=Clazz.array(Integer.TYPE, [nCells]);
for (var tx=this.minXYZ.x; tx < this.maxXYZ.x; tx++) {
for (var ty=this.minXYZ.y; ty < this.maxXYZ.y; ty++) {
for (var tz=this.minXYZ.z; tz < this.maxXYZ.z; tz++) {
this.unitCellTranslations[iCell]=$I$(10).new3$D$D$D(tx, ty, tz);
unitCells[iCell++]=555 + tx * 100 + ty * 10 + tz;
if (tx != 0 || ty != 0  || tz != 0  || cartesians.length == 0 ) continue;
for (pt=0; pt < n; pt++) {
var atom=atoms[this.firstAtom + pt];
if (ms != null ) {
sym=ms.getAtomSymmetry$org_jmol_adapter_smarter_Atom$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry(atom, this.symmetry);
if (sym !== lastSymmetry ) {
if (sym.getSpaceGroupOperationCount$() == 0) p$2.finalizeSymmetry$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry.apply(this, [sym]);
lastSymmetry=sym;
op=sym.getSpaceGroupOperation$I(0);
}}var c=$I$(7).newP$javajs_util_T3d(atom);
op.rotTrans$javajs_util_T3d(c);
sym.toCartesian$javajs_util_T3d$Z(c, false);
if (this.doPackUnitCell) {
sym.toUnitCellRnd$javajs_util_T3d$javajs_util_T3d(c, this.ptOffset);
pttemp.setT$javajs_util_T3d(c);
sym.toFractional$javajs_util_T3d$Z(pttemp, false);
if (bsAtoms == null ) atom.setT$javajs_util_T3d(pttemp);
 else if (atom.distance$javajs_util_T3d(pttemp) < 1.0E-4 ) bsAtoms.set$I(atom.index);
 else {
bsAtoms.clear$I(atom.index);
continue;
}}if (bsAtoms != null ) atom.bsSymmetry.clearAll$();
atom.bsSymmetry.set$I(iCell * operationCount);
atom.bsSymmetry.set$I(0);
if (checkCartesianRange) $I$(4).setSymmetryMinMax$javajs_util_P3d$javajs_util_P3d$javajs_util_P3d(c, this.rmin, this.rmax);
if (pt < cartesianCount) cartesians[pt]=c;
}
if (checkRangeNoSymmetry) {
this.rmin.x-=absRange;
this.rmin.y-=absRange;
this.rmin.z-=absRange;
this.rmax.x+=absRange;
this.rmax.y+=absRange;
this.rmax.z+=absRange;
}cell555Count=pt=p$2.symmetryAddAtoms$I$I$I$I$I$I$javajs_util_P3dA$org_jmol_adapter_smarter_MSInterface$javajs_util_BS$IA.apply(this, [0, 0, 0, 0, pt, iCell * operationCount, cartesians, ms, excludedOps, atomMap]);
}
}
}
if (checkRange111) {
this.rmin.x-=absRange;
this.rmin.y-=absRange;
this.rmin.z-=absRange;
this.rmax.x+=absRange;
this.rmax.y+=absRange;
this.rmax.z+=absRange;
}iCell=0;
for (var tx=this.minXYZ.x; tx < this.maxXYZ.x; tx++) {
for (var ty=this.minXYZ.y; ty < this.maxXYZ.y; ty++) {
for (var tz=this.minXYZ.z; tz < this.maxXYZ.z; tz++) {
++iCell;
if (tx != 0 || ty != 0  || tz != 0 ) pt=p$2.symmetryAddAtoms$I$I$I$I$I$I$javajs_util_P3dA$org_jmol_adapter_smarter_MSInterface$javajs_util_BS$IA.apply(this, [tx, ty, tz, cell555Count, pt, iCell * operationCount, cartesians, ms, excludedOps, atomMap]);
}
}
}
if (iCell * n == this.asc.ac - this.firstAtom) p$2.duplicateAtomProperties$I.apply(this, [iCell]);
p$2.setCurrentModelInfo$I$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry$IA.apply(this, [n, sym, unitCells]);
this.unitCellParams=null;
p$2.reset.apply(this, []);
}, p$2);

Clazz.newMeth(C$, 'applyRangeSymmetry$javajs_util_BS',  function (bsAtoms) {
var range=this.acr.fillRange;
bsAtoms=p$2.updateBSAtoms.apply(this, []);
this.acr.forcePacked=true;
this.doPackUnitCell=false;
var minXYZ2=$I$(18).new3$I$I$I(this.minXYZ.x, this.minXYZ.y, this.minXYZ.z);
var maxXYZ2=$I$(18).new3$I$I$I(this.maxXYZ.x, this.maxXYZ.y, this.maxXYZ.z);
var oabc=Clazz.array($I$(7), [4]);
for (var i=0; i < 4; i++) oabc[i]=$I$(7).newP$javajs_util_T3d(range[i]);

p$2.setUnitCellSafely.apply(this, []);
p$2.adjustRangeMinMax$javajs_util_T3dA.apply(this, [oabc]);
var superSymmetry=Clazz.new_($I$(12,1));
superSymmetry.getUnitCell$javajs_util_T3dA$Z$S(this.acr.fillRange, false, null);
p$2.applyAllSymmetry$org_jmol_adapter_smarter_MSInterface$javajs_util_BS.apply(this, [this.acr.ms, bsAtoms]);
var pt0=Clazz.new_($I$(7,1));
var atoms=this.asc.atoms;
for (var i=this.asc.ac; --i >= this.firstAtom; ) {
pt0.setT$javajs_util_T3d(atoms[i]);
this.symmetry.toCartesian$javajs_util_T3d$Z(pt0, false);
superSymmetry.toFractional$javajs_util_T3d$Z(pt0, false);
if (this.acr.noPack ? !C$.removePacking$I$javajs_util_P3d$D$D$D$D$D$D$D(this.ndims, pt0, minXYZ2.x, maxXYZ2.x, minXYZ2.y, maxXYZ2.y, minXYZ2.z, maxXYZ2.z, this.packingRange) : !this.isWithinCell$I$javajs_util_P3d$D$D$D$D$D$D$D(this.ndims, pt0, minXYZ2.x, maxXYZ2.x, minXYZ2.y, maxXYZ2.y, minXYZ2.z, maxXYZ2.z, this.packingRange)) bsAtoms.clear$I(i);
}
}, p$2);

Clazz.newMeth(C$, 'applySuperSymmetry$S$javajs_util_BS$I$javajs_util_T3dA$javajs_util_P3d$javajs_util_V3dA$D',  function (supercell, bsAtoms, iAtomFirst, oabc, pt0, vabc, slop) {
this.asc.setGlobalBoolean$I(7);
var doPack0=this.doPackUnitCell;
this.doPackUnitCell=doPack0;
p$2.applyAllSymmetry$org_jmol_adapter_smarter_MSInterface$javajs_util_BS.apply(this, [this.acr.ms, null]);
this.doPackUnitCell=doPack0;
var atoms=this.asc.atoms;
var atomCount=this.asc.ac;
for (var i=iAtomFirst; i < atomCount; i++) {
this.symmetry.toCartesian$javajs_util_T3d$Z(atoms[i], true);
bsAtoms.set$I(i);
}
this.asc.setCurrentModelInfo$S$O("unitcell_conventional", this.symmetry.getV0abc$O$javajs_util_M4d("a,b,c", null));
var va=vabc[0];
var vb=vabc[1];
var vc=vabc[2];
this.symmetry=Clazz.new_($I$(12,1));
p$2.setUnitCell$DA$javajs_util_M3d$javajs_util_P3d.apply(this, [Clazz.array(Double.TYPE, -1, [0, 0, 0, 0, 0, 0, va.x, va.y, va.z, vb.x, vb.y, vb.z, vc.x, vc.y, vc.z, 0, 0, 0, 0, 0, 0, NaN, NaN, NaN, NaN, NaN, slop]), null, null]);
var name=oabc == null  || supercell == null   ? "P1" : "cell=" + supercell;
p$2.setAtomSetSpaceGroupName$S.apply(this, [name]);
this.symmetry.setSpaceGroupName$S(name);
this.symmetry.setSpaceGroup$Z(this.doNormalize);
this.symmetry.addSpaceGroupOperation$S$I("x,y,z", 0);
if (pt0 != null  && pt0.length$() == 0  ) pt0=null;
if (pt0 != null ) this.symmetry.toFractional$javajs_util_T3d$Z(pt0, true);
for (var i=iAtomFirst; i < atomCount; i++) {
this.symmetry.toFractional$javajs_util_T3d$Z(atoms[i], true);
if (pt0 != null ) atoms[i].sub$javajs_util_T3d(pt0);
}
this.asc.haveAnisou=false;
this.asc.setCurrentModelInfo$S$O("matUnitCellOrientation", null);
}, p$2);

Clazz.newMeth(C$, 'applySymmetryLattice',  function () {
if (!this.asc.coordinatesAreFractional || this.symmetry.getSpaceGroup$() == null  ) return;
var maxX=this.latticeCells[0];
var maxY=this.latticeCells[1];
var maxZ=Math.abs(this.latticeCells[2]);
var kcode=this.latticeCells[3];
this.firstAtom=this.asc.getLastAtomSetAtomIndex$();
var bsAtoms=this.asc.bsAtoms;
if (bsAtoms != null ) {
p$2.updateBSAtoms.apply(this, []);
this.firstAtom=bsAtoms.nextSetBit$I(this.firstAtom);
}this.rmin=$I$(7).new3$D$D$D(1.7976931348623157E308, 1.7976931348623157E308, 1.7976931348623157E308);
this.rmax=$I$(7).new3$D$D$D(-1.7976931348623157E308, -1.7976931348623157E308, -1.7976931348623157E308);
if (this.acr.latticeType == null ) this.acr.latticeType="" + this.symmetry.getLatticeType$();
if (this.acr.isPrimitive) {
this.asc.setCurrentModelInfo$S$O("isprimitive", Boolean.TRUE);
if (!"P".equals$O(this.acr.latticeType) || this.acr.primitiveToCrystal != null  ) {
this.asc.setCurrentModelInfo$S$O("unitcell_conventional", this.symmetry.getConventionalUnitCell$S$javajs_util_M3d(this.acr.latticeType, this.acr.primitiveToCrystal));
}}p$2.setUnitCellSafely.apply(this, []);
this.asc.setCurrentModelInfo$S$O("f2c", this.symmetry.getUnitCellF2C$());
var s=this.symmetry.getSpaceGroupTitle$();
if (s.indexOf$S("--") < 0) this.asc.setCurrentModelInfo$S$O("f2cTitle", s);
this.asc.setCurrentModelInfo$S$O("f2cParams", this.symmetry.getUnitCellParams$());
if (this.acr.latticeType != null ) {
this.asc.setCurrentModelInfo$S$O("latticeType", this.acr.latticeType);
if (Clazz.instanceOf(this.acr.fillRange, "java.lang.String")) {
var range=p$2.setLatticeRange$S$S.apply(this, [this.acr.latticeType, this.acr.fillRange]);
if (range == null ) {
this.acr.appendLoadNote$S(this.acr.fillRange + " symmetry could not be implemented");
this.acr.fillRange=null;
} else {
this.acr.fillRange=range;
}}}this.baseSymmetry=this.symmetry;
if (this.acr.fillRange != null ) {
p$2.setMinMax$I$I$I$I$I.apply(this, [this.ndims, kcode, maxX, maxY, maxZ]);
p$2.applyRangeSymmetry$javajs_util_BS.apply(this, [bsAtoms]);
return;
}var oabc=null;
var slop=1.0E-6;
this.baseSymmetry.nSpins=0;
var supercell=this.acr.strSupercell;
var isSuper=(supercell != null  && supercell.indexOf$S(",") >= 0 );
var matSuper=null;
var pt0=null;
var vabc=Clazz.array($I$(10), [3]);
if (isSuper) {
matSuper=Clazz.new_($I$(5,1));
if (this.mident == null ) this.mident=Clazz.new_($I$(5,1));
p$2.setUnitCellSafely.apply(this, []);
oabc=this.symmetry.getV0abc$O$javajs_util_M4d(supercell, matSuper);
matSuper.transpose33$();
if (oabc != null  && !matSuper.equals$O(this.mident) ) {
p$2.setMinMax$I$I$I$I$I.apply(this, [this.ndims, kcode, maxX, maxY, maxZ]);
pt0=$I$(7).newP$javajs_util_T3d(oabc[0]);
vabc[0]=$I$(10).newV$javajs_util_T3d(oabc[1]);
vabc[1]=$I$(10).newV$javajs_util_T3d(oabc[2]);
vabc[2]=$I$(10).newV$javajs_util_T3d(oabc[3]);
p$2.adjustRangeMinMax$javajs_util_T3dA.apply(this, [oabc]);
}}var iAtomFirst=this.asc.getLastAtomSetAtomIndex$();
if (bsAtoms != null ) iAtomFirst=bsAtoms.nextSetBit$I(iAtomFirst);
if (this.rmin.x == 1.7976931348623157E308 ) {
supercell=null;
oabc=null;
} else {
bsAtoms=p$2.updateBSAtoms.apply(this, []);
slop=this.symmetry.getPrecision$();
p$2.applySuperSymmetry$S$javajs_util_BS$I$javajs_util_T3dA$javajs_util_P3d$javajs_util_V3dA$D.apply(this, [supercell, bsAtoms, iAtomFirst, oabc, pt0, vabc, slop]);
}p$2.setMinMax$I$I$I$I$I.apply(this, [this.ndims, kcode, maxX, maxY, maxZ]);
if (oabc == null ) {
p$2.applyAllSymmetry$org_jmol_adapter_smarter_MSInterface$javajs_util_BS.apply(this, [this.acr.ms, bsAtoms]);
if (!this.acr.noPack && (!this.applySymmetryToBonds || !this.acr.doPackUnitCell ) ) {
return;
}p$2.setMinMax$I$I$I$I$I.apply(this, [this.ndims, kcode, maxX, maxY, maxZ]);
}if (this.acr.forcePacked || this.acr.doPackUnitCell || this.acr.noPack  ) {
p$2.trimToUnitCell$I.apply(this, [iAtomFirst]);
}p$2.updateSupercellAtomSites$javajs_util_M4d$javajs_util_BS$D.apply(this, [matSuper, bsAtoms, slop]);
}, p$2);

Clazz.newMeth(C$, 'duplicateAtomProperties$I',  function (nTimes) {
var p=this.asc.getAtomSetAuxiliaryInfoValue$I$S(-1, "atomProperties");
if (p != null ) for (var entry, $entry = p.entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) {
var key=entry.getKey$();
var val=entry.getValue$();
if (Clazz.instanceOf(val, "java.lang.String")) {
var data=val;
var s=Clazz.new_($I$(19,1));
for (var i=nTimes; --i >= 0; ) s.append$S(data);

p.put$O$O(key, s.toString());
} else {
var f=val;
var fnew=Clazz.array(Double.TYPE, [f.length * nTimes]);
for (var i=nTimes; --i >= 0; ) System.arraycopy$O$I$O$I$I(f, 0, fnew, i * f.length, f.length);

}}
}, p$2);

Clazz.newMeth(C$, 'finalizeSymmetry$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry',  function (symmetry) {
var name=this.asc.getAtomSetAuxiliaryInfoValue$I$S(-1, "spaceGroup");
symmetry.setFinalOperations$I$S$javajs_util_P3dA$I$I$Z$S(this.ndims, name, this.asc.atoms, this.firstAtom, this.noSymmetryCount, this.doNormalize, this.filterSymop);
if (this.filterSymop != null  || name == null   || name.equals$O("unspecified!") ) {
p$2.setAtomSetSpaceGroupName$S.apply(this, [symmetry.getUnitCellDisplayName$()]);
}if (this.unitCellParams != null  || Double.isNaN$D(this.acr.unitCellParams[0]) ) return;
if (symmetry.fixUnitCell$DA(this.acr.unitCellParams)) {
this.acr.appendLoadNote$S("Unit cell parameters were adjusted to match space group!");
}p$2.setUnitCellSafely.apply(this, []);
}, p$2);

Clazz.newMeth(C$, 'removePacking$I$javajs_util_P3d$D$D$D$D$D$D$D',  function (ndims, pt, minX, maxX, minY, maxY, minZ, maxZ, slop) {
return (pt.x > minX - slop  && pt.x < maxX - slop   && (ndims < 2 || pt.y > minY - slop  && pt.y < maxY - slop   )  && (ndims < 3 || pt.z > minZ - slop  && pt.z < maxZ - slop   ) );
}, 1);

Clazz.newMeth(C$, 'reset',  function () {
this.asc.coordinatesAreFractional=false;
this.asc.setCurrentModelInfo$S$O("hasSymmetry", Boolean.TRUE);
this.asc.setGlobalBoolean$I(1);
}, p$2);

Clazz.newMeth(C$, 'setAtomSetSpaceGroupName$S',  function (spaceGroupName) {
this.symmetry.setSpaceGroupName$S(spaceGroupName);
var s=spaceGroupName + "";
this.asc.setCurrentModelInfo$S$O("f2cTitle", s);
this.asc.setCurrentModelInfo$S$O("spaceGroup", s);
}, p$2);

Clazz.newMeth(C$, 'setCurrentModelInfo$I$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry$IA',  function (n, sym, unitCells) {
if (sym == null ) {
this.asc.setCurrentModelInfo$S$O("presymmetryAtomCount", Integer.valueOf$I(this.noSymmetryCount));
this.asc.setCurrentModelInfo$S$O("biosymmetryCount", Integer.valueOf$I(n));
this.asc.setCurrentModelInfo$S$O("bioSymmetry", this.symmetry);
} else {
this.asc.setCurrentModelInfo$S$O("fileSymmetry", this.symmetry);
this.asc.setCurrentModelInfo$S$O("presymmetryAtomCount", Integer.valueOf$I(n));
this.asc.setCurrentModelInfo$S$O("latticeDesignation", sym.getLatticeDesignation$());
this.asc.setCurrentModelInfo$S$O("ML_unitCellRange", unitCells);
if (this.acr.isSUPERCELL) this.asc.setCurrentModelInfo$S$O("supercell", this.acr.strSupercell);
}this.asc.setCurrentModelInfo$S$O("presymmetryAtomIndex", Integer.valueOf$I(this.firstAtom));
var operationCount=this.symmetry.getSpaceGroupOperationCount$();
if (operationCount > 0) {
this.asc.setCurrentModelInfo$S$O("symmetryOperations", this.symmetry.getSymopList$Z(this.doNormalize));
this.asc.setCurrentModelInfo$S$O("symOpsTemp", this.symmetry.getSymmetryOperations$());
}this.asc.setCurrentModelInfo$S$O("symmetryCount", Integer.valueOf$I(operationCount));
this.asc.setCurrentModelInfo$S$O("latticeType", this.acr.latticeType == null  ? "P" : this.acr.latticeType);
this.asc.setCurrentModelInfo$S$O("intlTableNo", this.symmetry.getIntTableNumber$());
this.asc.setCurrentModelInfo$S$O("intlTableIndex", this.symmetry.getSpaceGroupInfoObj$S$O$Z$Z("itaIndex", null, false, false));
this.asc.setCurrentModelInfo$S$O("intlTableTransform", this.symmetry.getSpaceGroupInfoObj$S$O$Z$Z("itaTransform", null, false, false));
this.asc.setCurrentModelInfo$S$O("intlTableJmolId", this.symmetry.getSpaceGroupJmolId$());
this.asc.setCurrentModelInfo$S$O("spaceGroupIndex", Integer.valueOf$I(this.symmetry.getSpaceGroupIndex$()));
this.asc.setCurrentModelInfo$S$O("spaceGroupTitle", this.symmetry.getSpaceGroupTitle$());
if (this.acr.sgName == null  || this.acr.sgName.indexOf$S("?") >= 0  || this.acr.sgName.indexOf$S("!") >= 0 ) p$2.setAtomSetSpaceGroupName$S.apply(this, [this.acr.sgName=this.symmetry.getSpaceGroupName$()]);
}, p$2);

Clazz.newMeth(C$, 'setCurrentModelUCInfo$DA$javajs_util_P3d$javajs_util_M3d',  function (unitCellParams, unitCellOffset, matUnitCellOrientation) {
if (unitCellParams != null ) this.asc.setCurrentModelInfo$S$O("unitCellParams", unitCellParams);
if (unitCellOffset != null ) this.asc.setCurrentModelInfo$S$O("unitCellOffset", unitCellOffset);
if (matUnitCellOrientation != null ) this.asc.setCurrentModelInfo$S$O("matUnitCellOrientation", matUnitCellOrientation);
}, p$2);

Clazz.newMeth(C$, 'setLatticeCells',  function () {
this.latticeCells=this.acr.latticeCells;
var isLatticeRange=(this.latticeCells[0] <= 555 && this.latticeCells[1] >= 555  && (this.latticeCells[2] == 0 || this.latticeCells[2] == 1  || this.latticeCells[2] == -1 ) );
this.doNormalize=this.latticeCells[0] != 0 && (!isLatticeRange || this.latticeCells[2] == 1 ) ;
this.applySymmetryToBonds=this.acr.applySymmetryToBonds;
this.doPackUnitCell=this.acr.doPackUnitCell && !this.applySymmetryToBonds ;
this.doCentroidUnitCell=this.acr.doCentroidUnitCell;
this.centroidPacked=this.acr.centroidPacked;
this.filterSymop=this.acr.filterSymop;
}, p$2);

Clazz.newMeth(C$, 'setLatticeRange$S$S',  function (latticetype, rangeType) {
var range=null;
var isRhombohedral="R".equals$O(latticetype);
if (rangeType.equals$O("conventional")) {
range=this.symmetry.getConventionalUnitCell$S$javajs_util_M3d(latticetype, this.acr.primitiveToCrystal);
} else if (rangeType.equals$O("primitive")) {
range=this.symmetry.getUnitCellVectors$();
this.symmetry.toFromPrimitive$Z$C$javajs_util_T3dA$javajs_util_M3d(true, latticetype.charAt$I(0), range, this.acr.primitiveToCrystal);
} else if (isRhombohedral && rangeType.equals$O("rhombohedral") ) {
if (this.symmetry.getUnitCellInfoType$I(8) == 1 ) {
rangeType="2/3a+1/3b+1/3c,-1/3a+1/3b+1/3c,-1/3a-2/3b+1/3c";
} else {
rangeType=null;
}} else if (isRhombohedral && rangeType.equals$O("trigonal") ) {
if (this.symmetry.getUnitCellInfoType$I(9) == 1 ) {
rangeType="a-b,b-c,a+b+c";
} else {
rangeType=null;
}} else if (rangeType.equals$O("spin")) {
rangeType=this.getBaseSymmetry$().spinFrameStr;
} else if (rangeType.startsWith$S("unitcell_")) {
rangeType=this.asc.getAtomSetAuxiliaryInfoValue$I$S(-1, rangeType);
} else if (rangeType.indexOf$S(",") < 0 || rangeType.indexOf$S("a") < 0  || rangeType.indexOf$S("b") < 0  || rangeType.indexOf$S("c") < 0 ) {
rangeType=null;
}if (rangeType != null  && range == null   && (range=this.symmetry.getV0abc$O$javajs_util_M4d(rangeType, null)) == null  ) {
rangeType=null;
}if (rangeType == null ) return null;
this.acr.addJmolScript$S("unitcell " + $I$(8).esc$S(rangeType));
return range;
}, p$2);

Clazz.newMeth(C$, 'setMinMax$I$I$I$I$I',  function (dim, kcode, maxX, maxY, maxZ) {
this.minXYZ=Clazz.new_($I$(18,1));
this.maxXYZ=$I$(18).new3$I$I$I(maxX, maxY, maxZ);
$I$(17).setMinMaxLatticeParameters$I$javajs_util_P3i$javajs_util_P3i$I(dim, this.minXYZ, this.maxXYZ, kcode);
}, p$2);

Clazz.newMeth(C$, 'setUnitCell$DA$javajs_util_M3d$javajs_util_P3d',  function (info, matUnitCellOrientation, unitCellOffset) {
this.unitCellParams=Clazz.array(Double.TYPE, [info.length]);
for (var i=0; i < info.length; i++) this.unitCellParams[i]=info[i];

this.asc.haveUnitCell=true;
if (this.asc.isTrajectory) {
if (this.trajectoryUnitCells == null ) {
this.trajectoryUnitCells=Clazz.new_($I$(20,1));
this.asc.setInfo$S$O("unitCells", this.trajectoryUnitCells);
}this.trajectoryUnitCells.addLast$O(this.unitCellParams);
}this.asc.setGlobalBoolean$I(2);
this.getSymmetry$().setUnitCellFromParams$DA$Z$D(this.unitCellParams, false, this.unitCellParams[26]);
if (unitCellOffset != null ) this.symmetry.setOffsetPt$javajs_util_T3d(unitCellOffset);
if (matUnitCellOrientation != null ) this.symmetry.initializeOrientation$javajs_util_M3d(matUnitCellOrientation);
p$2.setCurrentModelUCInfo$DA$javajs_util_P3d$javajs_util_M3d.apply(this, [this.unitCellParams, unitCellOffset, matUnitCellOrientation]);
}, p$2);

Clazz.newMeth(C$, 'setUnitCellSafely',  function () {
if (this.unitCellParams == null ) p$2.setUnitCell$DA$javajs_util_M3d$javajs_util_P3d.apply(this, [this.acr.unitCellParams, this.acr.matUnitCellOrientation, this.acr.unitCellOffset]);
}, p$2);

Clazz.newMeth(C$, 'symmetryAddAtoms$I$I$I$I$I$I$javajs_util_P3dA$org_jmol_adapter_smarter_MSInterface$javajs_util_BS$IA',  function (transX, transY, transZ, baseCount, pt, iCellOpPt, cartesians, ms, excludedOps, atomMap) {
var isBaseCell=(baseCount == 0);
var addBonds=(atomMap != null );
if (this.doPackUnitCell) this.ptOffset.set$D$D$D(transX, transY, transZ);
var range2=this.symmetryRange * this.symmetryRange;
var checkRangeNoSymmetry=(this.symmetryRange < 0 );
var checkRange111=(this.symmetryRange > 0 );
var checkSymmetryMinMax=(isBaseCell && checkRange111 );
checkRange111=!!(checkRange111&(!isBaseCell));
var nOp=this.symmetry.getSpaceGroupOperationCount$();
var lstNCS=this.acr.lstNCS;
var nNCS=(lstNCS == null  ? 0 : lstNCS.size$());
var nOperations=nOp + nNCS;
nNCS=(nNCS/nOp|0);
var checkNearAtoms=(this.checkNearAtoms && (nOperations > 1 || this.doPackUnitCell ) );
var checkSymmetryRange=(checkRangeNoSymmetry || checkRange111 );
var checkDistances=(checkNearAtoms || checkSymmetryRange );
var checkOps=(excludedOps != null );
var addCartesian=(checkNearAtoms || checkSymmetryMinMax );
var bsAtoms=(this.acr.isMolecular ? null : this.asc.bsAtoms);
var sym=this.symmetry;
if (checkRangeNoSymmetry) baseCount=this.noSymmetryCount;
var atomMax=this.firstAtom + this.noSymmetryCount;
var bondAtomMin=(this.asc.firstAtomToBond < 0 ? atomMax : this.asc.firstAtomToBond);
var pttemp=Clazz.new_($I$(7,1));
var code=null;
var minCartDist2=(checkOps ? 0.01 : 1.0E-4);
var subSystemId="\u0000";
var j00=(bsAtoms == null  ? this.firstAtom : bsAtoms.nextSetBit$I(this.firstAtom));
 out : for (var iSym=0; iSym < nOperations; iSym++) {
if (isBaseCell && iSym == 0  || this.crystalReaderLatticeOpsOnly && iSym > 0  && (iSym % this.latticeOp) != 0   || excludedOps != null  && excludedOps.get$I(iSym)  ) continue;
var pt0=this.firstAtom + (checkNearAtoms ? pt : checkRange111 ? baseCount : 0);
var timeReversal=(iSym >= nOp ? 0 : this.asc.vibScale == 0 ? sym.getSpinOp$I(iSym) : this.asc.vibScale);
var i0=Math.max(this.firstAtom, (bsAtoms == null  ? 0 : bsAtoms.nextSetBit$I(0)));
var checkDistance=checkDistances;
var spt=(iSym >= nOp ? ((iSym - nOp)/nNCS|0) : iSym);
var cpt=spt + iCellOpPt;
for (var i=i0; i < atomMax; i++) {
var a=this.asc.atoms[i];
if (bsAtoms != null  && !bsAtoms.get$I(i) ) continue;
if (ms == null ) {
sym.newSpaceGroupPoint$javajs_util_P3d$I$javajs_util_M4d$I$I$I$javajs_util_P3d(a, iSym, (iSym >= nOp ? lstNCS.get$I(iSym - nOp) : null), transX, transY, transZ, pttemp);
} else {
sym=ms.getAtomSymmetry$org_jmol_adapter_smarter_Atom$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry(a, this.symmetry);
sym.newSpaceGroupPoint$javajs_util_P3d$I$javajs_util_M4d$I$I$I$javajs_util_P3d(a, iSym, null, transX, transY, transZ, pttemp);
code=sym.getSpaceGroupOperationCode$I(iSym);
if (code != null ) {
subSystemId=code.charAt$I(0);
sym=ms.getSymmetryFromCode$S(code);
if (sym.getSpaceGroupOperationCount$() == 0) p$2.finalizeSymmetry$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry.apply(this, [sym]);
}}var c=$I$(7).newP$javajs_util_T3d(pttemp);
sym.toCartesian$javajs_util_T3d$Z(c, false);
if (this.doPackUnitCell) {
sym.toUnitCellRnd$javajs_util_T3d$javajs_util_T3d(c, this.ptOffset);
pttemp.setT$javajs_util_T3d(c);
sym.toFractional$javajs_util_T3d$Z(pttemp, false);
if (!this.isWithinCell$I$javajs_util_P3d$D$D$D$D$D$D$D(this.ndims, pttemp, this.minXYZ0.x, this.maxXYZ0.x, this.minXYZ0.y, this.maxXYZ0.y, this.minXYZ0.z, this.maxXYZ0.z, this.packingRange)) {
continue;
}}if (checkSymmetryMinMax) $I$(4).setSymmetryMinMax$javajs_util_P3d$javajs_util_P3d$javajs_util_P3d(c, this.rmin, this.rmax);
var special=null;
if (checkDistance) {
if (checkSymmetryRange && (c.x < this.rmin.x  || c.y < this.rmin.y   || c.z < this.rmin.z   || c.x > this.rmax.x   || c.y > this.rmax.y   || c.z > this.rmax.z  ) ) continue;
var minDist2=1.7976931348623157E308;
var j0=(this.checkAll ? this.asc.ac : pt0);
var name=a.atomName;
var id=(code == null  ? a.altLoc : subSystemId);
for (var j=j00; j < j0; j++) {
if (bsAtoms != null  && !bsAtoms.get$I(j) ) continue;
var pc=cartesians[j - this.firstAtom];
if (pc == null ) continue;
var d2=c.distanceSquared$javajs_util_T3d(pc);
if (checkNearAtoms && d2 < minCartDist2  ) {
if (checkOps) {
excludedOps.set$I(iSym);
continue out;
}special=this.asc.atoms[j];
if ((special.atomName == null  || special.atomName.equals$O(name) ) && special.altLoc == id ) break;
special=null;
}if (checkRange111 && j < baseCount  && d2 < minDist2  ) minDist2=d2;
}
if (checkRange111 && minDist2 > range2  ) continue;
}if (checkOps) {
checkDistance=false;
}var atomSite=a.atomSite;
if (special != null ) {
if (addBonds) atomMap[atomSite]=special.index;
special.bsSymmetry.set$I(cpt);
special.bsSymmetry.set$I(spt);
} else {
if (addBonds) atomMap[atomSite]=this.asc.ac;
var atom1=a.copyTo$javajs_util_P3d$org_jmol_adapter_smarter_AtomSetCollection(pttemp, this.asc);
if (this.asc.bsAtoms != null ) this.asc.bsAtoms.set$I(atom1.index);
if (timeReversal != 0 && atom1.vib != null  ) {
(sym.getSpaceGroupOperation$I(iSym)).rotateSpin$javajs_util_T3d(atom1.vib);
atom1.vib.scale$D(timeReversal);
}if (atom1.part < 0) {
var key=Integer.valueOf$I(iSym * 1000 + 500 + atom1.part);
if (this.disorderMap == null ) this.disorderMap=Clazz.new_($I$(13,1));
var ch=this.disorderMap.get$O(key);
if (ch == null ) {
var ia=Integer.valueOf$I(atom1.part);
var isNew=(this.disorderMap.get$O(ia) == null );
if (this.disorderMapMax == 0 || this.disorderMapMax == 122  ) {
this.disorderMapMax="@".$c();
} else if (this.disorderMapMax == 90 ) {
this.disorderMapMax="`".$c();
}ch=Clazz.new_(Character.c$$C,[isNew ? atom1.altLoc : String.fromCharCode(++this.disorderMapMax)]);
this.disorderMap.put$O$O(key, ch);
if (isNew) this.disorderMap.put$O$O(ia, ch);
}atom1.altLoc=ch.charValue$();
}atom1.atomSite=atomSite;
if (code != null ) atom1.altLoc=subSystemId;
atom1.bsSymmetry=$I$(16).newAndSetBit$I(cpt);
atom1.bsSymmetry.set$I(spt);
if (addCartesian) cartesians[pt++]=c;
var tensors=a.tensors;
if (tensors != null ) {
atom1.tensors=null;
for (var j=tensors.size$(); --j >= 0; ) {
var t=tensors.get$I(j);
if (t == null ) continue;
if (nOp == 1) atom1.addTensor$org_jmol_util_Tensor$S$Z(t.copyTensor$(), null, false);
 else this.addRotatedTensor$org_jmol_adapter_smarter_Atom$org_jmol_util_Tensor$I$Z$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry(atom1, t, iSym, false, sym);
}
}}}
if (addBonds) {
var bonds=this.asc.bonds;
var atoms=this.asc.atoms;
var key;
for (var bondNum=this.asc.bondIndex0; bondNum < this.bondCount0; bondNum++) {
var bond=bonds[bondNum];
var atom1=atoms[bond.atomIndex1];
var atom2=atoms[bond.atomIndex2];
if (atom1 == null  || atom2 == null   || atom2.atomSetIndex < atom1.atomSetIndex ) continue;
var ia1=atomMap[atom1.atomSite];
var ia2=atomMap[atom2.atomSite];
if (ia1 > ia2) {
var i=ia1;
ia1=ia2;
ia2=i;
}if ((ia1 != ia2 && (ia1 >= bondAtomMin || ia2 >= bondAtomMin ) ) && !this.bondsFound.contains$O(key="-" + ia1 + "," + ia2 ) ) {
this.bondsFound.add$O(key);
this.asc.addNewBondWithOrder$I$I$I(ia1, ia2, bond.order);
}}
}}
return pt;
}, p$2);

Clazz.newMeth(C$, 'setPartProperty$',  function () {
for (var iset=this.asc.atomSetCount; --iset >= 0; ) {
var parts=Clazz.array(Double.TYPE, [this.asc.getAtomSetAtomCount$I(iset)]);
for (var i=0, ia=this.asc.getAtomSetAtomIndex$I(iset), n=parts.length; i < n; i++) {
var a=this.asc.atoms[ia++];
parts[i]=a.part;
}
this.asc.setAtomProperties$S$O$I$Z("part", parts, iset, false);
}
});

Clazz.newMeth(C$, 'trimToUnitCell$I',  function (iAtomFirst) {
var atoms=this.asc.atoms;
var bs=p$2.updateBSAtoms.apply(this, []);
if (this.acr.noPack) {
for (var i=bs.nextSetBit$I(iAtomFirst); i >= 0; i=bs.nextSetBit$I(i + 1)) {
if (!C$.removePacking$I$javajs_util_P3d$D$D$D$D$D$D$D(this.ndims, atoms[i], this.minXYZ.x, this.maxXYZ.x, this.minXYZ.y, this.maxXYZ.y, this.minXYZ.z, this.maxXYZ.z, this.packingRange)) bs.clear$I(i);
}
} else {
for (var i=bs.nextSetBit$I(iAtomFirst); i >= 0; i=bs.nextSetBit$I(i + 1)) {
if (!this.isWithinCell$I$javajs_util_P3d$D$D$D$D$D$D$D(this.ndims, atoms[i], this.minXYZ.x, this.maxXYZ.x, this.minXYZ.y, this.maxXYZ.y, this.minXYZ.z, this.maxXYZ.z, this.packingRange)) bs.clear$I(i);
}
}}, p$2);

Clazz.newMeth(C$, 'updateBSAtoms',  function () {
var bs=this.asc.bsAtoms;
if (bs == null ) bs=this.asc.bsAtoms=$I$(16).newBitSet2$I$I(0, this.asc.ac);
if (bs.nextSetBit$I(this.firstAtom) < 0) bs.setBits$I$I(this.firstAtom, this.asc.ac);
return bs;
}, p$2);

Clazz.newMeth(C$, 'updateSupercellAtomSites$javajs_util_M4d$javajs_util_BS$D',  function (matSuper, bsAtoms, slop) {
var n=bsAtoms.cardinality$();
var baseAtoms=Clazz.array($I$(15), [n]);
var nbase=0;
var slop2=slop * slop;
for (var i=bsAtoms.nextSetBit$I(0); i >= 0; i=bsAtoms.nextSetBit$I(i + 1)) {
var a=this.asc.atoms[i];
var p=Clazz.new_($I$(15,1));
p.setT$javajs_util_T3d(a);
if (matSuper != null ) {
matSuper.rotTrans$javajs_util_T3d(p);
$I$(17).unitizeDimRnd$I$javajs_util_T3d$D(3, p, slop);
}p.atomSerial=a.atomSite;
p.atomSite=a.atomSite;
this.symmetry.unitize$javajs_util_T3d(p);
var found=false;
for (var ib=0; ib < nbase; ib++) {
var b=baseAtoms[ib];
if (p.atomSerial == b.atomSerial && p.distanceSquared$javajs_util_T3d(b) < slop2  ) {
found=true;
a.atomSite=b.atomSite;
break;
}}
if (!found) {
a.atomSite=p.atomSite=nbase;
baseAtoms[nbase++]=p;
}}
}, p$2);

Clazz.newMeth(C$, 'newFileSymmetry$',  function () {
return Clazz.new_($I$(12,1));
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.XtalSymmetry, "FileSymmetry", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'org.jmol.symmetry.Symmetry');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['nSpins'],'S',['spinFrameStr','spinFrameExt'],'O',['spinFramePp','javajs.util.M4d','spinFrameToCartXYZ','javajs.util.M3d','+spinFrameRotationMatrix','spinPointGroupAxesXYZ','javajs.util.P3d[]']]]

Clazz.newMeth(C$, 'mapSpins$java_util_Map',  function (map) {
this.spaceGroup.mapSpins$java_util_Map(map);
});

Clazz.newMeth(C$, 'addMagLatticeVectors$javajs_util_Lst',  function (lattvecs) {
return this.spaceGroup.addMagLatticeVectors$javajs_util_Lst(lattvecs);
});

Clazz.newMeth(C$, 'addSpinLattice$javajs_util_Lst$java_util_Map',  function (lstSpinFrames, mapSpinIdToUVW) {
this.spaceGroup.addSpinLattice$javajs_util_Lst$java_util_Map(lstSpinFrames, mapSpinIdToUVW);
});

Clazz.newMeth(C$, 'setSpinList$S',  function (configuration) {
return this.spaceGroup.setSpinList$S(configuration);
});

Clazz.newMeth(C$, 'createSpaceGroup$I$S$O$I',  function (desiredSpaceGroupIndex, name, data, modDim) {
this.spaceGroup=$I$(1).createSpaceGroup$I$S$O$I(desiredSpaceGroupIndex, name, data, modDim);
if (this.spaceGroup != null  && $I$(2).debugging ) $I$(2,"debug$S",["using generated space group " + this.spaceGroup.dumpInfo$()]);
return this.spaceGroup != null ;
});

Clazz.newMeth(C$, 'fcoord$javajs_util_T3d',  function (p) {
return $I$(3).fcoord$javajs_util_T3d$S(p, " ");
});

Clazz.newMeth(C$, 'getRotTransArrayAndXYZ$S$DA',  function (xyz, rotTransMatrix) {
$I$(3).getRotTransArrayAndXYZ$org_jmol_symmetry_SymmetryOperation$S$DA$Z$Z$Z$S(null, xyz, rotTransMatrix, false, true, false, null);
});

Clazz.newMeth(C$, 'getSpaceGroupOperationCode$I',  function (iOp) {
return this.spaceGroup.symmetryOperations[iOp].subsystemCode;
});

Clazz.newMeth(C$, 'getTensor$org_jmol_viewer_Viewer$DA',  function (vwr, parBorU) {
if (parBorU == null ) return null;
if (this.unitCell == null ) this.unitCell=$I$(4,"fromParams$DA$Z$D",[Clazz.array(Double.TYPE, -1, [1, 1, 1, 90, 90, 90]), true, 1.0E-4]);
return this.unitCell.getTensor$org_jmol_viewer_Viewer$DA(vwr, parBorU);
});

Clazz.newMeth(C$, 'getSpaceGroupTitle$',  function () {
var s=this.getSpaceGroupName$();
return (s.startsWith$S("cell=") ? s : this.spaceGroup != null  ? this.spaceGroup.asString$() : this.unitCell != null  && this.unitCell.name.length$() > 0  ? "cell=" + this.unitCell.name : "");
});

Clazz.newMeth(C$, 'setPrecision$D',  function (prec) {
this.unitCell.setPrecision$D(prec);
});

Clazz.newMeth(C$, 'toFractionalM$javajs_util_M4d',  function (m) {
if (!this.isBio) this.unitCell.toFractionalM$javajs_util_M4d(m);
});

Clazz.newMeth(C$, 'toUnitCellRnd$javajs_util_T3d$javajs_util_T3d',  function (pt, offset) {
this.unitCell.toUnitCellRnd$javajs_util_T3d$javajs_util_T3d(pt, offset);
});

Clazz.newMeth(C$, 'twelfthify$javajs_util_P3d',  function (pt) {
this.unitCell.twelfthify$javajs_util_P3d(pt);
});

Clazz.newMeth(C$, 'getConventionalUnitCell$S$javajs_util_M3d',  function (latticeType, primitiveToCrystal) {
return (this.unitCell == null  || latticeType == null   ? null : this.unitCell.getConventionalUnitCell$S$javajs_util_M3d(latticeType, primitiveToCrystal));
});

Clazz.newMeth(C$, 'getSpaceGroupIndex$',  function () {
return this.spaceGroup.getIndex$();
});

Clazz.newMeth(C$, 'getUnitCellF2C$',  function () {
return this.unitCell.getF2C$();
});

Clazz.newMeth(C$, 'addInversion$',  function () {
var ops=this.spaceGroup.symmetryOperations;
var inv=Clazz.new_($I$(5,1));
inv.m00=inv.m11=inv.m22=-1;
inv.m33=1;
var n=this.getSpaceGroupOperationCount$();
var m=Clazz.new_($I$(5,1));
for (var i=0; i < n; i++) {
m.mul2$javajs_util_M4d$javajs_util_M4d(inv, ops[i]);
var s=$I$(3).getXYZFromMatrix$javajs_util_M4d$Z$Z$Z(m, true, true, false);
this.addSpaceGroupOperation$S$I(s, 0);
}
});

Clazz.newMeth(C$, 'rotateAxes$I$javajs_util_V3dA$javajs_util_P3d$javajs_util_M3d',  function (iop, axes, ptTemp, mTemp) {
return (iop == 0 ? axes : this.spaceGroup.symmetryOperations[iop].rotateAxes$javajs_util_V3dA$org_jmol_symmetry_UnitCell$javajs_util_P3d$javajs_util_M3d(axes, this.unitCell, ptTemp, mTemp));
});

Clazz.newMeth(C$, 'preSymmetryFinalizeMoments$org_jmol_adapter_smarter_AtomSetCollectionReader$org_jmol_adapter_smarter_AtomSetCollection$S$S',  function (acr, asc, spinFrameStr, spinFrameExt) {
this.spinFrameStr=spinFrameStr;
this.spinFrameExt=spinFrameExt;
this.spinFramePp=null;
this.spinFrameToCartXYZ=null;
var a=acr.unitCellParams[0];
var b=acr.unitCellParams[1];
var c=acr.unitCellParams[2];
if (spinFrameStr != null ) {
var spinABC=p$1.preSymmetrySetSpinFrameMatrices$org_jmol_adapter_smarter_AtomSetCollectionReader.apply(this, [acr]);
a=spinABC[1].length$();
b=spinABC[2].length$();
c=spinABC[3].length$();
this.spinFrameToCartXYZ=Clazz.new_($I$(6,1));
for (var i=4; --i > 0; ) {
this.spinFrameToCartXYZ.setColumnV$I$javajs_util_T3d(i - 1, spinABC[i]);
}
if (this.spinFrameRotationMatrix != null ) {
this.spinFrameToCartXYZ.mul2$javajs_util_M3d$javajs_util_M3d(this.spinFrameRotationMatrix, this.spinFrameToCartXYZ);
}this.spinPointGroupAxesXYZ=Clazz.array($I$(7), -1, [Clazz.new_($I$(7,1)), Clazz.new_($I$(7,1)), Clazz.new_($I$(7,1))]);
this.spinPointGroupAxesXYZ[0].setP$javajs_util_T3d(spinABC[1]).scale$D(1 / a);
this.spinPointGroupAxesXYZ[1].setP$javajs_util_T3d(spinABC[2]).scale$D(1 / b);
this.spinPointGroupAxesXYZ[2].setP$javajs_util_T3d(spinABC[3]).scale$D(1 / c);
System.out.println$S("XtalSymmetry spinFramePp=\n " + spinFrameStr + "\nrotation=\n " + this.spinFrameRotationMatrix + "\nspinFrameCartXYZ=\n " + this.spinFrameToCartXYZ );
if (this.spinFrameRotationMatrix != null ) asc.setCurrentModelInfo$S$O("spinFrameRotationMatrix", this.spinFrameRotationMatrix);
asc.setCurrentModelInfo$S$O("pointGroupAxes", this.spinPointGroupAxesXYZ);
}var magneticScaling=$I$(7).new3$D$D$D(1 / a, 1 / b, 1 / c);
var i0=asc.getAtomSetAtomIndex$I(asc.iSet);
var vt=Clazz.new_($I$(7,1));
for (var i=asc.ac; --i >= i0; ) {
var v=asc.atoms[i].vib;
if (v != null ) {
v.scaleT$javajs_util_T3d(magneticScaling);
if (v.isFractional) {
if (v.magMoment == 0 ) {
if (this.unitCell == null ) {
this.setUnitCellFromParams$DA$Z$D(acr.unitCellParams, false, NaN);
}this.toCartesian$javajs_util_T3d$Z(vt.setP$javajs_util_T3d(v), true);
v.magMoment=vt.length$();
}}}}
});

Clazz.newMeth(C$, 'preSymmetrySetSpinFrameMatrices$org_jmol_adapter_smarter_AtomSetCollectionReader',  function (acr) {
System.out.println$S("XtalSymmetry.setSpinFrameMatrices using frame " + this.spinFrameStr);
this.setUnitCellFromParams$DA$Z$D(acr.unitCellParams, false, NaN);
this.spinFramePp=Clazz.new_($I$(5,1));
var spinABC=$I$(4).getMatrixAndUnitCell$org_jmol_viewer_Viewer$org_jmol_util_SimpleUnitCell$O$javajs_util_M4d(acr.vwr, this.unitCell, this.spinFrameStr, this.spinFramePp);
var strAxis=p$1.getSpinExt$S$S.apply(this, [this.spinFrameExt, "axis"]);
if (strAxis != null ) {
var angle=$I$(8,"parseDouble$S",[p$1.getSpinExt$S$S.apply(this, [this.spinFrameExt, "angle"])]);
if (!Double.isNaN$D(angle)) {
var axis=p$1.getAxis$S.apply(this, [strAxis]);
if (axis != null ) {
acr.addMoreUnitCellInfo$S("rotation_axis_xyz=" + new Double(axis.x).toString() + "," + new Double(axis.y).toString() + "," + new Double(axis.z).toString() );
this.spinFrameRotationMatrix=Clazz.new_($I$(6,1)).setAA$javajs_util_A4d($I$(9,"newVA$javajs_util_V3d$D",[axis, angle * (0.017453292519943295)]));
}}}return spinABC;
}, p$1);

Clazz.newMeth(C$, 'getVariableAxis$S',  function (strAxis) {
var pt=$I$(7).new3$D$D$D(1, 1, 1);
strAxis.replace$C$C("n", " ").replace$C$C("u", "x").replace$C$C("v", "y").replace$C$C("w", "z");
var m=this.convertTransform$S$javajs_util_M4d(strAxis, null);
m.rotate$javajs_util_T3d(pt);
return Clazz.array(Double.TYPE, -1, [pt.x, pt.y, pt.z]);
}, p$1);

Clazz.newMeth(C$, 'getAxis$S',  function (axis) {
var v=null;
var abc=null;
var isCartesian=false;
if (axis.indexOf$S("n") >= 0) {
abc=p$1.getVariableAxis$S.apply(this, [axis]);
} else if (axis.startsWith$S("[")) {
axis=axis.replace$C$C("[", " ").replace$C$C("]", " ").replace$C$C(",", " ").trim$();
axis=$I$(8).rep$S$S$S(axis, "  ", " ");
v=$I$(8).split$S$S(axis, " ");
isCartesian=true;
} else {
v=axis.split$S(",");
}if (abc == null  && v.length == 3 ) {
abc=Clazz.array(Double.TYPE, [3]);
for (var i=3; --i >= 0; ) {
abc[i]=$I$(8,"parseDouble$S",[v[i].trim$()]);
if (Double.isNaN$D(abc[i])) {
return null;
}}
}if (abc == null ) return null;
var a=$I$(10).new3$D$D$D(abc[0], abc[1], abc[2]);
if (!isCartesian) this.unitCell.toCartesian$javajs_util_T3d$Z(a, true);
a.normalize$();
return a;
}, p$1);

Clazz.newMeth(C$, 'getSpinExt$S$S',  function (spinFrameExt, name) {
if (spinFrameExt == null ) return null;
name=";" + name + "=" ;
var pt=spinFrameExt.indexOf$S(name);
return (pt < 0 ? null : spinFrameExt.substring$I$I(pt + name.length$(), spinFrameExt.indexOf$I$I(";", pt + 1)));
}, p$1);

Clazz.newMeth(C$, 'postSymmetrySetMagneticMoments$org_jmol_adapter_smarter_AtomSetCollection$Z',  function (asc, isCartesian) {
if (this.nSpins > 0) return this.nSpins;
var i0=asc.getAtomSetAtomIndex$I(asc.iSet);
for (var i=asc.ac; --i >= i0; ) {
var v=asc.atoms[i].vib;
if (v != null ) {
if (v.modDim > 0) {
(v).setMoment$();
++this.nSpins;
} else {
var v1=v.clone$();
if (this.spinFrameToCartXYZ != null ) {
this.spinFrameToCartXYZ.rotate$javajs_util_T3d(v1);
} else if (!isCartesian) {
this.toCartesian$javajs_util_T3d$Z(v1, true);
}if (v1.lengthSquared$() > 0 ) {
if (v1.magMoment != 0 ) v1.scale$D(v1.magMoment / v1.length$());
++this.nSpins;
} else if (v1.modDim == 0) {
v1=null;
}asc.atoms[i].vib=v1;
}}}
return this.nSpins;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:41 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
