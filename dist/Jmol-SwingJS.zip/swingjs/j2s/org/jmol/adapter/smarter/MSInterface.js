(function(){var P$=Clazz.newPackage("org.jmol.adapter.smarter"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "MSInterface");
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:16:07 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
