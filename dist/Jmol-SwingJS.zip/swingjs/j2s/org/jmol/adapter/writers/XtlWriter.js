(function(){var P$=Clazz.newPackage("org.jmol.adapter.writers"),p$1={},I$=[[0,'javajs.util.PT']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "XtlWriter");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.haveUnitCell=true;
this.isHighPrecision=true;
},1);

C$.$fields$=[['Z',['haveUnitCell','isHighPrecision'],'D',['slop'],'I',['precision']]
,['D',['SLOPD'],'F',['SLOPF'],'O',['twelfths','String[]','+twelfthsF']]]

Clazz.newMeth(C$, 'clean$D',  function (d) {
if (!this.isHighPrecision) return p$1.cleanF$F.apply(this, [d]);
var t;
return (!this.haveUnitCell || (t=C$.twelfthsOf$D(d)) < 0  ? $I$(1).formatD$D$I$I$Z$Z(d, 18, 12, false, false) : (d < 0  ? "   -" : "    ") + C$.twelfths[t]);
});

Clazz.newMeth(C$, 'twelfthsOf$D',  function (f) {
if (f == 0 ) return 0;
f=Math.abs(f * 12);
var i=Long.$ival(Math.round$D(f));
return (i <= 12 && Math.abs(f - i) < C$.SLOPD * 12   ? i : -1);
}, 1);

Clazz.newMeth(C$, 'cleanF$F',  function (f) {
var t;
if (this.slop != 0 ) return p$1.cleanSlop$D.apply(this, [f]);
return (!this.haveUnitCell || (t=C$.twelfthsOfF$F(f)) < 0  ? $I$(1).formatD$D$I$I$Z$Z(f, 12, 7, false, false) : (f < 0  ? "   -" : "    ") + C$.twelfthsF[t]);
}, p$1);

Clazz.newMeth(C$, 'cleanSlop$D',  function (f) {
return $I$(1).formatD$D$I$I$Z$Z(f, this.precision + 6, this.precision, false, false);
}, p$1);

Clazz.newMeth(C$, 'twelfthsOfF$F',  function (f) {
if (f == 0 ) return 0;
f=Math.abs(f * 12);
var i=Math.round(f);
return (i <= 12 && Math.abs(f - i) < C$.SLOPF * 12   ? i : -1);
}, 1);

Clazz.newMeth(C$, 'cleanT$D',  function (d) {
var s=this.clean$D(d);
if (this.isHighPrecision) return s;
var i=s.length$();
while (--i >= 2 && s.charAt$I(i) == "0"  && s.charAt$I(i - 1) != "." ){
}
return s.substring$I$I(0, i + 1);
});

C$.$static$=function(){C$.$static$=0;
C$.SLOPD=1.0E-11;
C$.SLOPF=1.0E-6;
C$.twelfths=Clazz.array(String, -1, ["0.000000000000", "0.083333333333", "0.166666666667", "0.250000000000", "0.333333333333", "0.416666666667", "0.500000000000", "0.583333333333", "0.666666666667", "0.750000000000", "0.833333333333", "0.916666666667", "1.000000000000"]);
C$.twelfthsF=Clazz.array(String, -1, ["0.0000000", "0.0833333", "0.1666667", "0.2500000", "0.3333333", "0.4166667", "0.5000000", "0.5833333", "0.6666667", "0.7500000", "0.8333333", "0.9166667", "1.0000000"]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-09-01 22:08:07 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
