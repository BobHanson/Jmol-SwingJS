(function(){var P$=Clazz.newPackage("org.jmol.adapter.writers"),I$=[[0,'javajs.util.P3d','org.jmol.util.BSUtil','org.jmol.api.Interface','javajs.util.SB','org.jmol.viewer.Viewer','javajs.util.PT','javajs.util.BS']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CIFWriter", null, 'org.jmol.adapter.writers.XtlWriter', 'org.jmol.api.JmolWriter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['isP1','isCIF2','haveCustom'],'I',['nops'],'H',['modelIndex'],'O',['vwr','org.jmol.viewer.Viewer','oc','javajs.util.OC','data','Object[]','uc','org.jmol.api.SymmetryInterface','bsOut','javajs.util.BS','atoms','org.jmol.modelset.Atom[]','atomLabels','String[]','jmol_atoms','javajs.util.SB','modelInfo','java.util.Map']]
,['O',['fset0','javajs.util.T3d']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'set$org_jmol_viewer_Viewer$javajs_util_OC$OA',  function (viewer, oc, data) {
this.vwr=viewer;
this.oc=(oc == null  ? this.vwr.getOutputChannel$S$SA(null, null) : oc);
this.data=data;
this.isP1=(data != null  && data.length > 0  && "P1".equals$O(data[0]) );
});

Clazz.newMeth(C$, 'write$javajs_util_BS',  function (bs) {
try {
bs=(bs == null  ? this.vwr.bsA$() : $I$(2).copy$javajs_util_BS(bs));
if (bs.isEmpty$()) return "";
this.modelInfo=this.vwr.ms.getModelAuxiliaryInfo$I(this.vwr.ms.at[bs.nextSetBit$I(0)].mi);
var info=this.modelInfo.get$O("scifInfo");
var writer;
if (info == null ) {
writer=this;
} else {
writer=$I$(3).getInterface$S$org_jmol_viewer_Viewer$S("org.jmol.adapter.writers.FSG2SCIFConverter", this.vwr, "cifwriter");
writer.set$org_jmol_viewer_Viewer$javajs_util_OC$OA(this.vwr, null, Clazz.array(java.lang.Object, -1, [this.modelInfo, info]));
this.isCIF2=true;
}writer.prepareAtomSet$javajs_util_BS(bs);
var sb=Clazz.new_($I$(4,1));
if (this.isCIF2) {
sb.append$S("#\\#CIF_2.0\n");
}sb.append$S("## CIF file created by Jmol " + $I$(5).getJmolVersion$());
if (writer.haveCustom) {
sb.append$S($I$(6,"rep$S$S$S",["\n" + this.uc.getUnitCellInfo$Z(false), "\n", "\n##Jmol_orig "]));
}sb.append$S("\ndata_global\n\n");
writer.writeHeader$javajs_util_SB(sb);
writer.writeParams$javajs_util_SB(sb);
writer.writeOperations$javajs_util_SB(sb);
var nAtoms=writer.writeAtomSite$javajs_util_SB(sb);
if (writer.jmol_atoms != null ) {
sb.appendSB$javajs_util_SB(writer.jmol_atoms);
sb.append$S("\n_jmol_atom_count   " + nAtoms);
}sb.append$S("\n_jmol_precision    " + writer.precision + "\n" );
this.oc.append$S(sb.toString());
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
if (!$I$(5).isJS) e.printStackTrace$();
} else {
throw e;
}
}
return this.toString();
});

Clazz.newMeth(C$, 'prepareAtomSet$javajs_util_BS',  function (bs) {
this.atoms=this.vwr.ms.at;
this.modelIndex=this.atoms[bs.nextSetBit$I(0)].mi;
var n0=bs.cardinality$();
bs.and$javajs_util_BS(this.vwr.getModelUndeletedAtomsBitSet$I(this.modelIndex));
if (n0 < bs.cardinality$()) {
System.err.println$S("CIFWriter Warning: Atoms not in model " + (this.modelIndex + 1) + " ignored" );
}this.uc=this.vwr.ms.getUnitCell$I(this.modelIndex);
this.haveUnitCell=(this.uc != null );
if (!this.haveUnitCell) this.uc=this.vwr.getSymTemp$().setUnitCellFromParams$DA$Z$D(null, false, 1.0E-5);
this.nops=(this.isP1 ? 0 : this.uc.getSpaceGroupOperationCount$());
this.slop=this.uc.getPrecision$();
this.precision=(-Math.log10(this.slop)|0);
this.isHighPrecision=(this.slop == 1.0E-12 );
var fractionalOffset=(this.uc.getFractionalOffset$Z(true) != null );
var fset;
this.haveCustom=(fractionalOffset || (fset=this.uc.getUnitCellMultiplier$()) != null  && (fset.z == 1  ? !fset.equals$O(C$.fset0) : fset.z != 0 )  );
var ucm=this.uc.getUnitCellMultiplied$();
this.isP1=(this.isP1 || ucm !== this.uc   || fractionalOffset  || this.uc.getSpaceGroupOperationCount$() < 2 );
this.uc=ucm;
var modelAU=(!this.haveUnitCell ? bs : this.isP1 ? this.uc.removeDuplicates$org_jmol_modelset_ModelSet$javajs_util_BS$Z(this.vwr.ms, bs, false) : this.vwr.ms.am[this.modelIndex].bsAsymmetricUnit);
if (modelAU == null ) {
this.bsOut=bs;
} else {
this.bsOut=Clazz.new_($I$(7,1));
this.bsOut.or$javajs_util_BS(modelAU);
this.bsOut.and$javajs_util_BS(bs);
}this.vwr.setErrorMessage$S$S(null, " (" + this.bsOut.cardinality$() + " atoms)" );
});

Clazz.newMeth(C$, 'writeHeader$javajs_util_SB',  function (sb) {
var hallName;
var hmName;
var ita;
if (this.isP1) {
ita="1";
hallName="P 1";
hmName="P1";
} else {
this.uc.getSpaceGroupInfo$org_jmol_modelset_ModelSet$S$I$Z$DA(this.vwr.ms, null, this.modelIndex, true, null);
ita=this.uc.geCIFWriterValue$S("ita");
hallName=this.uc.geCIFWriterValue$S("HallSymbol");
hmName=this.uc.geCIFWriterValue$S("HermannMauguinSymbol");
}this.appendKey$javajs_util_SB$S$I(sb, "_space_group_IT_number", 27).append$S(ita == null  ? "?" : ita.toString());
this.appendKey$javajs_util_SB$S$I(sb, "_space_group_name_Hall", 27).append$S(hallName == null  || hallName.equals$O("?")  ? "?" : "'" + hallName + "'" );
this.appendKey$javajs_util_SB$S$I(sb, "_space_group_name_H-M_alt", 27).append$S(hmName == null  ? "?" : "'" + hmName + "'" );
});

Clazz.newMeth(C$, 'writeOperations$javajs_util_SB',  function (sb) {
sb.append$S("\n\nloop_\n_space_group_symop_id\n_space_group_symop_operation_xyz");
if (this.nops == 0) {
sb.append$S("\n1 x,y,z");
} else {
var symops=this.uc.getSymmetryOperations$();
for (var i=0; i < this.nops; i++) {
var sop=symops[i].getXyz$Z(true);
sb.append$S("\n").appendI$I(i + 1).append$S("\t").append$S(sop.replaceAll$S$S(" ", ""));
}
}});

Clazz.newMeth(C$, 'writeParams$javajs_util_SB',  function (sb) {
var params=this.uc.getUnitCellAsArray$Z(false);
this.appendKey$javajs_util_SB$S$I(sb, "_cell_length_a", 27).append$S(this.cleanT$D(params[0]));
this.appendKey$javajs_util_SB$S$I(sb, "_cell_length_b", 27).append$S(this.cleanT$D(params[1]));
this.appendKey$javajs_util_SB$S$I(sb, "_cell_length_c", 27).append$S(this.cleanT$D(params[2]));
this.appendKey$javajs_util_SB$S$I(sb, "_cell_angle_alpha", 27).append$S(this.cleanT$D(params[3]));
this.appendKey$javajs_util_SB$S$I(sb, "_cell_angle_beta", 27).append$S(this.cleanT$D(params[4]));
this.appendKey$javajs_util_SB$S$I(sb, "_cell_angle_gamma", 27).append$S(this.cleanT$D(params[5]));
sb.append$S("\n");
});

Clazz.newMeth(C$, 'writeAtomSite$javajs_util_SB',  function (sb) {
var elements="";
var haveOccupancy=false;
var occ=(this.haveUnitCell ? this.vwr.ms.occupancies : null);
if (occ != null ) {
for (var i=this.bsOut.nextSetBit$I(0); i >= 0; i=this.bsOut.nextSetBit$I(i + 1)) {
if (occ[i] != 1 ) {
haveOccupancy=true;
break;
}}
}var haveAltLoc=false;
for (var i=this.bsOut.nextSetBit$I(0); i >= 0; i=this.bsOut.nextSetBit$I(i + 1)) {
if (this.atoms[i].altloc != "\u0000") {
haveAltLoc=true;
break;
}}
var parts=(haveAltLoc ? this.vwr.getDataObj$S$javajs_util_BS$I("property_part", this.bsOut, 1) : null);
var sbLength=sb.length$();
sb.append$S("\n\nloop_\n_atom_site_label\n_atom_site_type_symbol\n_atom_site_fract_x\n_atom_site_fract_y\n_atom_site_fract_z");
if (haveAltLoc) {
sb.append$S("\n_atom_site_disorder_group");
}if (haveOccupancy) {
sb.append$S("\n_atom_site_occupancy");
} else if (!this.haveUnitCell) {
sb.append$S("\n_atom_site_Cartn_x\n_atom_site_Cartn_y\n_atom_site_Cartn_z");
}sb.append$S("\n");
this.jmol_atoms=Clazz.new_($I$(4,1));
this.jmol_atoms.append$S("\n\nloop_\n_jmol_atom_index\n_jmol_atom_name\n_jmol_atom_site_label\n");
var nAtoms=0;
var p=Clazz.new_($I$(1,1));
var elemNums=Clazz.array(Integer.TYPE, [130]);
this.atomLabels=Clazz.array(String, [this.bsOut.cardinality$()]);
for (var pi=0, labeli=0, i=this.bsOut.nextSetBit$I(0); i >= 0; i=this.bsOut.nextSetBit$I(i + 1)) {
var a=this.atoms[i];
p.setT$javajs_util_T3d(a);
if (this.haveUnitCell) {
this.uc.toFractional$javajs_util_T3d$Z(p, !this.isP1);
}++nAtoms;
var name=a.getAtomName$();
var sym=a.getElementSymbol$();
var elemno=a.getElementNumber$();
var key=sym + "\n";
if (elements.indexOf$S(key) < 0) elements+=key;
var label=sym + ++elemNums[elemno];
C$.appendField$javajs_util_SB$S$I(sb, label, 5);
C$.appendField$javajs_util_SB$S$I(sb, sym, 3);
this.atomLabels[labeli++]=label;
this.append3$javajs_util_SB$javajs_util_T3d(sb, p);
if (haveAltLoc) {
sb.append$S(" ");
var sdis;
if (parts != null ) {
var part=(parts[pi++]|0);
sdis=(part == 0 ? "." : "" + part);
} else {
sdis="" + (a.altloc == "\u0000" ? "." : a.altloc);
}sb.append$S(sdis);
}if (haveOccupancy) sb.append$S(" ").append$S(this.clean$D(occ[i] / 100));
 else if (!this.haveUnitCell) this.append3$javajs_util_SB$javajs_util_T3d(sb, a);
sb.append$S("\n");
C$.appendField$javajs_util_SB$S$I(this.jmol_atoms, "" + a.getIndex$(), 3);
this.writeChecked$javajs_util_SB$S(this.jmol_atoms, name);
C$.appendField$javajs_util_SB$S$I(this.jmol_atoms, label, 5);
this.jmol_atoms.append$S("\n");
}
if (nAtoms > 0) {
sb.append$S("\nloop_\n_atom_type_symbol\n").append$S(elements).append$S("\n");
} else {
sb.setLength$I(sbLength);
this.jmol_atoms=null;
}return nAtoms;
});

Clazz.newMeth(C$, 'appendField$javajs_util_SB$S$I',  function (sb, val, width) {
sb.append$S($I$(6).formatS$S$I$I$Z$Z(val, width, 0, true, false)).append$S(" ");
}, 1);

Clazz.newMeth(C$, 'append3$javajs_util_SB$javajs_util_T3d',  function (sb, a) {
sb.append$S(this.clean$D(a.x)).append$S(this.clean$D(a.y)).append$S(this.clean$D(a.z));
});

Clazz.newMeth(C$, 'writeChecked$javajs_util_SB$S',  function (output, val) {
if (val == null  || val.length$() == 0 ) {
output.append$S(". ");
return false;
}var escape=val.charAt$I(0) == "_";
var escapeCharStart="\'";
var escapeCharEnd="\' ";
var hasWhitespace=false;
var hasSingle=false;
var hasDouble=false;
for (var i=0; i < val.length$(); i++) {
var c=val.charAt$I(i);
switch (c.$c()) {
case 9:
case 32:
hasWhitespace=true;
break;
case 10:
this.writeMultiline$javajs_util_SB$S(output, val);
return true;
case 34:
if (hasSingle) {
this.writeMultiline$javajs_util_SB$S(output, val);
return true;
}hasDouble=true;
escape=true;
escapeCharStart="\'";
escapeCharEnd="\' ";
break;
case 39:
if (hasDouble) {
this.writeMultiline$javajs_util_SB$S(output, val);
return true;
}escape=true;
hasSingle=true;
escapeCharStart="\"";
escapeCharEnd="\" ";
break;
}
}
var fst=val.charAt$I(0);
if (!escape && (fst == "#" || fst == "$"  || fst == ";"  || fst == "["  || fst == "]"  || hasWhitespace ) ) {
escapeCharStart="\'";
escapeCharEnd="\' ";
escape=true;
}if (escape) {
output.append$S(escapeCharStart).append$S(val).append$S(escapeCharEnd);
} else {
output.append$S(val).append$S(" ");
}return false;
});

Clazz.newMeth(C$, 'writeMultiline$javajs_util_SB$S',  function (output, val) {
output.append$S("\n;").append$S(val).append$S("\n;\n");
});

Clazz.newMeth(C$, 'appendKey$javajs_util_SB$S$I',  function (sb, key, width) {
return sb.append$S("\n").append$S($I$(6).formatS$S$I$I$Z$Z(key, width, 0, true, false));
});

Clazz.newMeth(C$, 'toString',  function () {
return (this.oc == null  ? "" : this.oc.toString());
});

C$.$static$=function(){C$.$static$=0;
C$.fset0=$I$(1).new3$D$D$D(555, 555, 1);
};
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-09-01 22:08:07 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
