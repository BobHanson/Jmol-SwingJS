(function(){var P$=Clazz.newPackage("org.jmol.adapter.writers"),p$1={},I$=[[0,'javajs.util.PT']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "XSFWriter", null, null, 'org.jmol.api.JmolWriter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['len'],'O',['vwr','org.jmol.viewer.Viewer','oc','javajs.util.OC','uc','org.jmol.api.SymmetryInterface']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'set$org_jmol_viewer_Viewer$javajs_util_OC$OA',  function (viewer, oc, data) {
this.vwr=viewer;
this.oc=(oc == null  ? this.vwr.getOutputChannel$S$SA(null, null) : oc);
});

Clazz.newMeth(C$, 'write$javajs_util_BS',  function (bs) {
if (bs == null ) bs=this.vwr.bsA$();
this.len=bs.length$();
if (this.len == 0) return "";
try {
var a=this.vwr.ms.at;
var i0=bs.nextSetBit$I(0);
this.uc=this.vwr.ms.getUnitCellForAtom$I(i0);
var model1=a[i0].getModelIndex$();
var model2=a[this.len - 1].getModelIndex$();
var isAnim=(model2 != model1);
if (isAnim) {
var nModels=this.vwr.ms.getModelBS$javajs_util_BS$Z(bs, false).cardinality$();
this.oc.append$S("ANIMSTEPS " + nModels + "\n" );
}if (this.uc != null ) this.oc.append$S("CRYSTAL\n");
var f="%4i%18.12p%18.12p%18.12p\n";
var prefix=(this.uc == null  ? "ATOMS" : "PRIMCOORD");
for (var lastmi=-1, imodel=0, i=bs.nextSetBit$I(0); i >= 0; i=bs.nextSetBit$I(i + 1)) {
var atom=a[i];
var mi=atom.getModelIndex$();
if (mi != lastmi) {
var sn=(isAnim ? " " + (++imodel) : "");
var header=prefix + sn + "\n" ;
this.uc=this.vwr.ms.getUnitCellForAtom$I(i);
if (this.uc == null ) {
this.oc.append$S(header);
} else {
p$1.writeLattice$S.apply(this, [sn]);
this.oc.append$S(header);
var bsm=this.vwr.restrictToModel$javajs_util_BS$I(bs, mi);
this.oc.append$S($I$(1,"formatStringI$S$S$I",["%6i 1\n", "i", bsm.cardinality$()]));
}lastmi=mi;
}this.oc.append$S($I$(1,"sprintf$S$S$OA",[f, "ip", Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(atom.getElementNumber$()), atom])]));
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
return this.toString();
});

Clazz.newMeth(C$, 'writeLattice$S',  function (sn) {
var abc=this.uc.getUnitCellVectors$();
var f="%18.10p%18.10p%18.10p\n";
var s=$I$(1,"sprintf$S$S$OA",[f, "p", Clazz.array(java.lang.Object, -1, [abc[1]])]) + $I$(1,"sprintf$S$S$OA",[f, "p", Clazz.array(java.lang.Object, -1, [abc[2]])]) + $I$(1,"sprintf$S$S$OA",[f, "p", Clazz.array(java.lang.Object, -1, [abc[3]])]) ;
this.oc.append$S("PRIMVEC" + sn + "\n" ).append$S(s).append$S("CONVVEC" + sn + "\n" ).append$S(s);
}, p$1);

Clazz.newMeth(C$, 'toString',  function () {
return (this.oc == null  ? "" : this.oc.toString());
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-09-01 22:08:07 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
