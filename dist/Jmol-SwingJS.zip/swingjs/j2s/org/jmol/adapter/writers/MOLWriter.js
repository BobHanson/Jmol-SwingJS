(function(){var P$=Clazz.newPackage("org.jmol.adapter.writers"),p$1={},I$=[[0,'org.jmol.viewer.Viewer','org.jmol.viewer.PropertyManager','org.jmol.util.Escape','javajs.util.P3d','javajs.util.PT','org.jmol.script.T','javajs.util.SB','java.util.Hashtable','javajs.util.Lst','org.jmol.util.Elements','javajs.util.V3d','java.util.Arrays','javajs.util.MeasureD']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MOLWriter");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['vwr','org.jmol.viewer.Viewer','ptTemp','javajs.util.P3d','vNorm','javajs.util.T3d','+vTemp','connections','int[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'setViewer$org_jmol_viewer_Viewer',  function (vwr) {
this.vwr=vwr;
return this;
});

Clazz.newMeth(C$, 'addMolFile$S$I$javajs_util_SB$javajs_util_BS$javajs_util_BS$Z$Z$Z$javajs_util_Qd$Z',  function (title, iModel, mol, bsAtoms, bsBonds, asV3000, asJSON, noAromatic, q, is2d) {
var nAtoms=bsAtoms.cardinality$();
var nBonds=bsBonds.cardinality$();
if (!asV3000 && !asJSON && (nAtoms > 999 || nBonds > 999 )  ) return false;
if (!asJSON) {
if (title.length$() > 80) title=title.substring$I$I(0, 77) + "...";
mol.append$S(title).append$S("\n");
var version=$I$(1).getJmolVersion$();
mol.append$S($I$(2).getSDFDateLine$S$Z("__Jmol-" + version, is2d));
mol.append$S("Jmol version ").append$S(version).append$S(" EXTRACT: ").append$S($I$(3).eBS$javajs_util_BS(bsAtoms)).append$S("\n");
}var asSDF=(iModel >= 0);
var molData=(asSDF ? this.vwr.ms.getInfo$I$S(iModel, "molData") : null);
var _keyList=(asSDF ? this.vwr.ms.getInfo$I$S(iModel, "molDataKeys") : null);
var ms=this.vwr.ms;
var atomMap=Clazz.array(Integer.TYPE, [ms.ac]);
var pTemp=Clazz.new_($I$(4,1));
if (asV3000) {
mol.append$S("  0  0  0  0  0  0            999 V3000");
} else if (asJSON) {
mol.append$S("{\"mol\":{\"createdBy\":\"Jmol " + $I$(1).getJmolVersion$() + "\",\"a\":[" );
} else {
$I$(5).rightJustify$javajs_util_SB$S$S(mol, "   ", "" + nAtoms);
$I$(5).rightJustify$javajs_util_SB$S$S(mol, "   ", "" + nBonds);
mol.append$S("  0  0  0  0            999 V2000");
}if (!asJSON) mol.append$S("\n");
if (asV3000) {
mol.append$S("M  V30 BEGIN CTAB\nM  V30 COUNTS ").appendI$I(nAtoms).append$S(" ").appendI$I(nBonds).append$S(" 0 0 0\n").append$S("M  V30 BEGIN ATOM\n");
}var o=(molData == null  ? null : molData.get$O("atom_value_name"));
if (Clazz.instanceOf(o, "org.jmol.script.SV")) o=(o).asString$();
var valueType=(o == null  ? 0 : $I$(6).getTokFromName$S("" + o));
var atomValues=(valueType == 0 && !asSDF  ? null : Clazz.new_($I$(7,1)));
for (var i=bsAtoms.nextSetBit$I(0), n=0; i >= 0; i=bsAtoms.nextSetBit$I(i + 1)) {
p$1.getAtomRecordMOL$I$org_jmol_modelset_ModelSet$javajs_util_SB$I$org_jmol_modelset_Atom$javajs_util_Qd$javajs_util_P3d$Z$Z$javajs_util_SB$I$Z.apply(this, [iModel, ms, mol, atomMap[i]=++n, ms.at[i], q, pTemp, asV3000, asJSON, atomValues, valueType, asSDF]);
}
if (asV3000) {
mol.append$S("M  V30 END ATOM\nM  V30 BEGIN BOND\n");
} else if (asJSON) {
mol.append$S("],\"b\":[");
}for (var i=bsBonds.nextSetBit$I(0), n=0; i >= 0; i=bsBonds.nextSetBit$I(i + 1)) {
p$1.getBondRecordMOL$javajs_util_SB$I$org_jmol_modelset_Bond$IA$Z$Z$Z$Z.apply(this, [mol, ++n, ms.bo[i], atomMap, asV3000, asJSON, noAromatic, is2d]);
}
if (asV3000) {
mol.append$S("M  V30 END BOND\nM  V30 END CTAB\n");
}if (asJSON) mol.append$S("]}}");
 else {
if (atomValues != null  && atomValues.length$() > 0 ) mol.append$S(atomValues.toString());
mol.append$S("M  END\n");
}if (asSDF) {
try {
var pc=ms.getPartialCharges$();
if (molData == null ) molData=Clazz.new_($I$(8,1));
var sb=Clazz.new_($I$(7,1));
if (pc != null ) {
sb.appendI$I(nAtoms).appendC$C("\n");
for (var i=bsAtoms.nextSetBit$I(0), n=0; i >= 0; i=bsAtoms.nextSetBit$I(i + 1)) sb.appendI$I(++n).append$S(" ").appendD$D(pc[i]).appendC$C("\n");

molData.put$O$O("jmol_partial_charges", sb.toString());
}sb.setLength$I(0);
sb.appendI$I(nAtoms).appendC$C("\n");
for (var i=bsAtoms.nextSetBit$I(0), n=0; i >= 0; i=bsAtoms.nextSetBit$I(i + 1)) {
var name=ms.at[i].getAtomName$().trim$();
if (name.length$() == 0) name=".";
sb.appendI$I(++n).append$S(" ").append$S(name.replace$C$C(" ", "_")).appendC$C("\n");
}
molData.put$O$O("jmol_atom_names", sb.toString());
if (_keyList == null ) _keyList=Clazz.new_($I$(9,1));
for (var key, $key = molData.keySet$().iterator$(); $key.hasNext$()&&((key=($key.next$())),1);) if (!_keyList.contains$O(key)) _keyList.addLast$O(key);

for (var i=0, n=_keyList.size$(); i < n; i++) {
var key=_keyList.get$I(i);
if (key.startsWith$S(">")) continue;
o=molData.get$O(key);
if (Clazz.instanceOf(o, "org.jmol.script.SV")) o=(o).asString$();
mol.append$S("> <" + key.toUpperCase$() + ">\n" );
p$1.output80CharWrap$javajs_util_SB$S$I.apply(this, [mol, o.toString(), 80]);
mol.append$S("\n\n");
}
} catch (e) {
}
mol.append$S("$$$$\n");
}return true;
});

Clazz.newMeth(C$, 'getAtomRecordMOL$I$org_jmol_modelset_ModelSet$javajs_util_SB$I$org_jmol_modelset_Atom$javajs_util_Qd$javajs_util_P3d$Z$Z$javajs_util_SB$I$Z',  function (iModel, ms, mol, n, a, q, pTemp, asV3000, asJSON, atomValues, tokValue, asSDF) {
ms.getPointTransf$I$org_jmol_modelset_Atom$javajs_util_Qd$javajs_util_P3d(iModel, a, q, pTemp);
var elemNo=a.getElementNumber$();
var sym=(a.isDeleted$() ? "Xx" : $I$(10).elementSymbolFromNumber$I(elemNo));
var isotope=a.getIsotopeNumber$();
var charge=a.getFormalCharge$();
var o=Clazz.array(java.lang.Object, -1, [pTemp]);
if (asV3000) {
mol.append$S("M  V30 ").appendI$I(n).append$S(" ").append$S(sym).append$S($I$(5).sprintf$S$S$OA(" %12.5p %12.5p %12.5p 0", "p", o));
if (charge != 0) mol.append$S(" CHG=").appendI$I(charge);
if (isotope != 0) mol.append$S(" MASS=").appendI$I(isotope);
mol.append$S("\n");
} else if (asJSON) {
if (n != 1) mol.append$S(",");
mol.append$S("{");
if (a.getElementNumber$() != 6) mol.append$S("\"l\":\"").append$S(a.getElementSymbol$()).append$S("\",");
if (charge != 0) mol.append$S("\"c\":").appendI$I(charge).append$S(",");
if (isotope != 0) mol.append$S("\"m\":").appendI$I(isotope).append$S(",");
mol.append$S("\"x\":").appendD$D(a.x).append$S(",\"y\":").appendD$D(a.y).append$S(",\"z\":").appendD$D(a.z).append$S("}");
} else {
mol.append$S($I$(5).sprintf$S$S$OA("%10.4p%10.4p%10.4p", "p", o));
mol.append$S(" ").append$S(sym);
if (sym.length$() == 1) mol.append$S(" ");
$I$(5,"rightJustify$javajs_util_SB$S$S",[mol, "   ", "" + (isotope > 0 ? isotope - $I$(10,"getNaturalIsotope$I",[a.getElementNumber$()]) : 0)]);
if (asSDF && isotope > 0 ) {
atomValues.append$S("M  ISO  1");
$I$(5).rightJustify$javajs_util_SB$S$S(atomValues, "    ", "" + n);
$I$(5).rightJustify$javajs_util_SB$S$S(atomValues, "    ", "" + isotope);
atomValues.append$S("\n");
}$I$(5,"rightJustify$javajs_util_SB$S$S",[mol, "   ", "" + (charge == 0 ? 0 : 4 - charge)]);
mol.append$S("  ").append$S(p$1.getAtomParity$org_jmol_modelset_Atom.apply(this, [a]));
mol.append$S("  0  0  0\n");
var label=(tokValue == 0 || asV3000  ? null : p$1.getAtomPropertyAsString$org_jmol_modelset_Atom$I.apply(this, [a, tokValue]));
if (label != null  && (label=label.trim$()).length$() > 0 ) {
var sn="   " + n + " " ;
atomValues.append$S("V  ").append$S(sn.substring$I(sn.length$() - 4));
p$1.output80CharWrap$javajs_util_SB$S$I.apply(this, [atomValues, label, 73]);
}}}, p$1);

Clazz.newMeth(C$, 'getAtomParity$org_jmol_modelset_Atom',  function (a) {
if (a.getCovalentBondCount$() == 4) {
if (this.connections == null ) {
this.connections=Clazz.array(Integer.TYPE, [4]);
this.vTemp=Clazz.new_($I$(11,1));
this.vNorm=Clazz.new_($I$(11,1));
}var bonds=a.bonds;
var nH=0;
for (var pt=0, i=bonds.length; --i >= 0; ) {
if (bonds[i].isCovalent$()) {
var b=bonds[i].getOtherAtom$org_jmol_modelset_Atom(a);
if (b.getAtomicAndIsotopeNumber$() == 1) ++nH;
this.connections[pt++]=b.i;
}}
if (nH < 3) {
$I$(12).sort$IA(this.connections);
var atoms=this.vwr.ms.at;
$I$(13).getNormalThroughPoints$javajs_util_T3d$javajs_util_T3d$javajs_util_T3d$javajs_util_T3d$javajs_util_T3d(atoms[this.connections[0]], atoms[this.connections[1]], atoms[this.connections[2]], this.vNorm, this.vTemp);
this.vTemp.sub2$javajs_util_T3d$javajs_util_T3d(atoms[this.connections[3]], atoms[this.connections[0]]);
return (this.vTemp.dot$javajs_util_T3d(this.vNorm) > 0  ? "1" : "2");
}}return "0";
}, p$1);

Clazz.newMeth(C$, 'getAtomPropertyAsString$org_jmol_modelset_Atom$I',  function (a, tok) {
switch (tok & 1136656384) {
case 1094713344:
var i=a.atomPropertyInt$I(tok);
return (tok == 1765808134 ? $I$(5,"trim$S$S",[$I$(3).escapeColor$I(i), "[x]"]).toUpperCase$() : "" + i);
case 1086324736:
return a.atomPropertyString$org_jmol_viewer_Viewer$I(this.vwr, tok);
case 1111490560:
var f=a.atomPropertyFloat$org_jmol_viewer_Viewer$I$javajs_util_P3d(this.vwr, tok, null);
return (Double.isNaN$D(f) ? null : "" + new Double(f).toString());
default:
if (this.ptTemp == null ) this.ptTemp=Clazz.new_($I$(4,1));
a.atomPropertyTuple$org_jmol_viewer_Viewer$I$javajs_util_P3d(this.vwr, tok, this.ptTemp);
return (this.ptTemp == null  ? null : this.ptTemp.toString());
}
}, p$1);

Clazz.newMeth(C$, 'getBondRecordMOL$javajs_util_SB$I$org_jmol_modelset_Bond$IA$Z$Z$Z$Z',  function (mol, n, b, atomMap, asV3000, asJSON, noAromatic, is2d) {
var a1=atomMap[b.atom1.i];
var a2=atomMap[b.atom2.i];
var order=b.getValence$();
var cfg="";
if (order > 3) order=1;
if (is2d) {
if (asJSON) {
} else {
switch (b.order) {
case 1057:
cfg=(asV3000 ? "  CFG=3" : "  4");
break;
case 1025:
cfg=(asV3000 ? "  CFG=1" : "  1");
break;
case 1041:
cfg=(asV3000 ? "  CFG=2" : "  3");
break;
default:
cfg="  0";
break;
}
}}switch (b.order & 131071) {
case 515:
order=(asJSON ? -3 : 4);
break;
case 66:
order=(asJSON ? -3 : 5);
break;
case 513:
order=(asJSON || noAromatic  ? 1 : 6);
break;
case 514:
order=(asJSON || noAromatic  ? 2 : 7);
break;
case 33:
order=(asJSON ? -1 : 8);
break;
}
if (asV3000) {
mol.append$S("M  V30 ").appendI$I(n).append$S(" ").appendI$I(order).append$S(" ").appendI$I(a1).append$S(" ").appendI$I(a2).append$S(cfg).appendC$C("\n");
} else if (asJSON) {
if (n != 1) mol.append$S(",");
mol.append$S("{\"b\":").appendI$I(a1 - 1).append$S(",\"e\":").appendI$I(a2 - 1);
if (order != 1) {
mol.append$S(",\"o\":");
if (order < 0) {
mol.appendD$D(-order / 2.0);
} else {
mol.appendI$I(order);
}}mol.append$S("}");
} else {
$I$(5).rightJustify$javajs_util_SB$S$S(mol, "   ", "" + a1);
$I$(5).rightJustify$javajs_util_SB$S$S(mol, "   ", "" + a2);
mol.append$S("  ").appendI$I(order).append$S(cfg).append$S("\n");
}}, p$1);

Clazz.newMeth(C$, 'output80CharWrap$javajs_util_SB$S$I',  function (mol, data, maxN) {
if (maxN < 80) data=$I$(5).rep$S$S$S(data, "\n", "|");
var lines=$I$(5,"split$S$S",[$I$(5,"trim$S$S",[$I$(5).rep$S$S$S(data, "\n\n", "\n"), "\n"]), "\n"]);
for (var i=0; i < lines.length; i++) p$1.outputLines$javajs_util_SB$S$I.apply(this, [mol, lines[i], maxN]);

}, p$1);

Clazz.newMeth(C$, 'outputLines$javajs_util_SB$S$I',  function (mol, data, maxN) {
var done=false;
for (var i=0, n=data.length$(); i < n && !done ; i+=80) {
mol.append$S(data.substring$I$I(i, Math.min(i + maxN, n)));
if (!(done=(maxN != 80)) && i + 80 < n ) mol.append$S("+");
mol.append$S("\n");
}
}, p$1);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:14 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
