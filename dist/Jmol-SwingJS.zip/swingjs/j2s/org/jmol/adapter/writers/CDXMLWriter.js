(function(){var P$=Clazz.newPackage("org.jmol.adapter.writers"),p$1={},I$=[[0,'java.util.Stack','javajs.util.SB','org.jmol.adapter.smarter.SmarterJmolAdapter','org.jmol.adapter.writers.CMLWriter','java.util.Hashtable','javajs.util.PT','java.io.FileInputStream','javajs.util.BinaryDocument','java.io.BufferedInputStream','javajs.util.Rdr']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CDXMLWriter", null, 'org.jmol.adapter.writers.CMLWriter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.objects=Clazz.new_($I$(1,1));
this.sb=Clazz.new_($I$(2,1));
},1);

C$.$fields$=[['I',['sbpt','id'],'O',['doc','javajs.api.GenericBinaryDocument','objects','java.util.Stack','sb','javajs.util.SB']]
,['O',['cdxAttributes','String[]']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'set$org_jmol_viewer_Viewer$javajs_util_OC$OA',  function (viewer, out, data) {
throw Clazz.new_(Clazz.load('NullPointerException').c$$S,["CDXMLWriter is not implemented for writing"]);
});

Clazz.newMeth(C$, 'write$javajs_util_BS',  function (bs) {
throw Clazz.new_(Clazz.load('NullPointerException').c$$S,["CDXMLWriter is not implemented for writing"]);
});

Clazz.newMeth(C$, 'fromCDX$javajs_api_GenericBinaryDocument',  function (binaryDoc) {
return p$1.cdxToCdxml$javajs_api_GenericBinaryDocument.apply(Clazz.new_(C$), [binaryDoc]);
}, 1);

Clazz.newMeth(C$, 'fromASC$org_jmol_adapter_smarter_AtomSetCollection',  function (asc) {
return p$1.ascToCdxml$org_jmol_adapter_smarter_AtomSetCollection.apply(Clazz.new_(C$), [asc]);
}, 1);

Clazz.newMeth(C$, 'ascToCdxml$org_jmol_adapter_smarter_AtomSetCollection',  function (asc) {
var a=Clazz.new_($I$(3,1));
var atomIterator=a.getAtomIterator$O(asc);
var bondIterator=a.getBondIterator$O(asc);
$I$(4).openDocument$javajs_util_SB(this.sb);
C$.appendHeader$javajs_util_SB(this.sb);
$I$(4).openTag$javajs_util_SB$S(this.sb, "page");
this.id=0;
p$1.openID$javajs_util_SB$S.apply(this, [this.sb, "fragment"]);
$I$(4).terminateTag$javajs_util_SB(this.sb);
var indexToID=Clazz.new_($I$(5,1));
while (atomIterator.hasNext$()){
p$1.openID$javajs_util_SB$S.apply(this, [this.sb, "n"]);
indexToID.put$O$O(atomIterator.getUniqueID$(), Integer.valueOf$I(this.id));
var xyz=atomIterator.getXYZ$();
var ele=atomIterator.getElement$();
var iso=atomIterator.getIsotope$();
var charge=atomIterator.getFormalCharge$();
$I$(4,"addAttribute$javajs_util_SB$S$S",[this.sb, "p", C$.cdxCoord$D$I(xyz.x, 200) + " " + C$.cdxCoord$D$I(-xyz.y, 400) ]);
if (ele != 6) $I$(4).addAttribute$javajs_util_SB$S$S(this.sb, "Element", "" + ele);
if (iso != 0) $I$(4).addAttribute$javajs_util_SB$S$S(this.sb, "Isotope", "" + iso);
if (charge != 0) $I$(4).addAttribute$javajs_util_SB$S$S(this.sb, "Charge", "" + charge);
$I$(4).terminateEmptyTag$javajs_util_SB(this.sb);
}
while (bondIterator.hasNext$()){
p$1.openID$javajs_util_SB$S.apply(this, [this.sb, "b"]);
var id1=bondIterator.getAtomUniqueID1$();
var id2=bondIterator.getAtomUniqueID2$();
var order="1";
var display=null;
var display2=null;
var bo=bondIterator.getEncodedOrder$();
switch (bo) {
case 515:
order="1.5";
display2="Dash";
break;
case 514:
order="2";
break;
default:
if ((bo & 7) != 0) order="" + (bo & 7);
break;
}
switch (bo) {
case 1025:
order="1";
display="WedgeBegin";
break;
case 1041:
order="1";
display="WedgedHashBegin";
break;
case 1057:
order="1";
display="Wavy";
break;
}
$I$(4,"addAttribute$javajs_util_SB$S$S",[this.sb, "B", indexToID.get$O(id1).toString()]);
$I$(4,"addAttribute$javajs_util_SB$S$S",[this.sb, "E", indexToID.get$O(id2).toString()]);
if (!order.equals$O("1")) $I$(4).addAttribute$javajs_util_SB$S$S(this.sb, "Order", order);
if (display != null ) $I$(4).addAttribute$javajs_util_SB$S$S(this.sb, "Display", display);
if (display2 != null ) $I$(4).addAttribute$javajs_util_SB$S$S(this.sb, "Display2", display2);
$I$(4).terminateEmptyTag$javajs_util_SB(this.sb);
}
$I$(4).closeTag$javajs_util_SB$S(this.sb, "fragment");
$I$(4).closeTag$javajs_util_SB$S(this.sb, "page");
$I$(4).closeTag$javajs_util_SB$S(this.sb, "CDXML");
return this.sb.toString();
}, p$1);

Clazz.newMeth(C$, 'cdxCoord$D$I',  function (x, off) {
return "" + (new Double(off + Math.round$D(x / 1.45 * 14.4 * 100) / 100.0).toString());
}, 1);

Clazz.newMeth(C$, 'openID$javajs_util_SB$S',  function (sb, name) {
$I$(4).startOpenTag$javajs_util_SB$S(sb, name);
$I$(4).addAttribute$javajs_util_SB$S$S(sb, "id", "" + ++this.id);
}, p$1);

Clazz.newMeth(C$, 'cdxToCdxml$javajs_api_GenericBinaryDocument',  function (doc) {
this.doc=doc;
try {
$I$(4).openDocument$javajs_util_SB(this.sb);
C$.appendHeader$javajs_util_SB(this.sb);
doc.setStreamData$java_io_DataInputStream$Z(null, false);
doc.seek$J(22);
p$1.processObject$I.apply(this, [doc.readShort$()]);
this.sb.append$S("</CDXML>\n");
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$S(this.sb + "\n" + this.objects );
e.printStackTrace$();
return null;
} else {
throw e;
}
}
return this.sb.toString();
}, p$1);

Clazz.newMeth(C$, 'appendHeader$javajs_util_SB',  function (sb) {
sb.append$S("<!DOCTYPE CDXML SYSTEM \"http://www.cambridgesoft.com/xml/cdxml.dtd\" >\n");
$I$(4).startOpenTag$javajs_util_SB$S(sb, "CDXML");
$I$(4).addAttributes$javajs_util_SB$SA(sb, C$.cdxAttributes);
$I$(4).terminateTag$javajs_util_SB(sb);
}, 1);

Clazz.newMeth(C$, 'processObject$I',  function (type) {
var id=this.doc.readInt$();
type=type & 65535;
var terminated=false;
var name=null;
switch (type) {
case 32768:
case 32770:
default:
id=-2147483648;
terminated=true;
break;
case 32769:
name="page";
id=-2147483648;
break;
case 32771:
name="fragment";
break;
case 32772:
name="n";
break;
case 32773:
name="b";
break;
case 32774:
name="t";
id=-2147483648;
break;
}
this.sbpt=this.sb.length$();
this.objects.push$O(name);
if (name != null ) {
$I$(4).startOpenTag$javajs_util_SB$S(this.sb, name);
if (id != -2147483648) {
$I$(4).addAttribute$javajs_util_SB$S$S(this.sb, "id", "" + id);
}}var prop;
while ((prop=this.doc.readShort$()) != 0){
if ((prop & 32768) != 0) {
if (!terminated) {
$I$(4).terminateTag$javajs_util_SB(this.sb);
terminated=true;
}p$1.processObject$I.apply(this, [prop]);
continue;
}var len=p$1.readLength.apply(this, []);
switch (type) {
case 32772:
p$1.writeNodeProperties$I$I.apply(this, [prop, len]);
break;
case 32774:
if (!terminated) {
$I$(4).terminateTag$javajs_util_SB(this.sb);
terminated=true;
}p$1.writeTextProperty$I$I.apply(this, [prop, len]);
break;
case 32773:
p$1.writeBondProperties$I$I.apply(this, [prop, len]);
break;
default:
p$1.skip$I.apply(this, [len]);
break;
}
}
if (name != null ) {
if (!terminated) {
$I$(4).terminateEmptyTag$javajs_util_SB(this.sb);
} else {
$I$(4).closeTag$javajs_util_SB$S(this.sb, name);
}}}, p$1);

Clazz.newMeth(C$, 'writeNodeProperties$I$I',  function (prop, len) {
switch (prop) {
case 512:
var y=C$.toPoint$I(p$1.readInt$I.apply(this, [len >> 1]));
var x=C$.toPoint$I(p$1.readInt$I.apply(this, [len >> 1]));
$I$(4,"addAttribute$javajs_util_SB$S$S",[this.sb, "p", new Double(x).toString() + " " + new Double(y).toString() ]);
break;
case 1024:
var nodeType=C$.getNodeType$I(p$1.readInt$I.apply(this, [len]));
$I$(4).addAttribute$javajs_util_SB$S$S(this.sb, "NodeType", nodeType);
break;
case 1026:
$I$(4,"addAttribute$javajs_util_SB$S$S",[this.sb, "Element", "" + p$1.readInt$I.apply(this, [len])]);
break;
case 1056:
$I$(4,"addAttribute$javajs_util_SB$S$S",[this.sb, "Isotope", "" + p$1.readInt$I.apply(this, [len])]);
break;
case 1057:
$I$(4,"addAttribute$javajs_util_SB$S$S",[this.sb, "Charge", "" + p$1.readInt$I.apply(this, [len])]);
break;
case 16:
$I$(4,"addAttribute$javajs_util_SB$S$S",[this.sb, "Warning", p$1.readString$I.apply(this, [len])]);
break;
case 1073:
$I$(4,"addAttribute$javajs_util_SB$S$S",[this.sb, "BondOrdering", p$1.readArray.apply(this, [])]);
break;
case 1285:
$I$(4,"addAttribute$javajs_util_SB$S$S",[this.sb, "ConnectionOrder", p$1.readArray.apply(this, [])]);
break;
case 1074:
$I$(4,"addAttribute$javajs_util_SB$S$S",[this.sb, "Attachments", p$1.readArray.apply(this, [])]);
break;
case 1075:
$I$(4,"addAttribute$javajs_util_SB$S$S",[this.sb, "GenericNickname", p$1.readString$I.apply(this, [len])]);
break;
default:
p$1.skip$I.apply(this, [len]);
}
}, p$1);

Clazz.newMeth(C$, 'writeBondProperties$I$I',  function (prop, len) {
switch (prop) {
case 1536:
var order=C$.getBondOrder$I(p$1.readInt$I.apply(this, [len]));
if (order == null ) {
p$1.removeObject.apply(this, []);
return;
}$I$(4).addAttribute$javajs_util_SB$S$S(this.sb, "Order", order);
break;
case 1537:
var d=C$.getBondDisplay$I(p$1.readInt$I.apply(this, [len]));
if (d == null ) {
p$1.removeObject.apply(this, []);
return;
}$I$(4).addAttribute$javajs_util_SB$S$S(this.sb, "Display", d);
break;
case 1538:
var d2=C$.getBondDisplay$I(p$1.readInt$I.apply(this, [len]));
if (d2 != null ) $I$(4).addAttribute$javajs_util_SB$S$S(this.sb, "Display2", d2);
break;
case 1540:
$I$(4,"addAttribute$javajs_util_SB$S$S",[this.sb, "B", "" + p$1.readInt$I.apply(this, [len])]);
break;
case 1541:
$I$(4,"addAttribute$javajs_util_SB$S$S",[this.sb, "E", "" + p$1.readInt$I.apply(this, [len])]);
break;
case 1544:
$I$(4,"addAttribute$javajs_util_SB$S$S",[this.sb, "BeginAttach", "" + p$1.readInt$I.apply(this, [len])]);
break;
case 1545:
$I$(4,"addAttribute$javajs_util_SB$S$S",[this.sb, "EndAttach", "" + p$1.readInt$I.apply(this, [len])]);
break;
default:
p$1.skip$I.apply(this, [len]);
}
}, p$1);

Clazz.newMeth(C$, 'writeTextProperty$I$I',  function (prop, len) {
switch (prop) {
case 1792:
var text=p$1.readString$I.apply(this, [len]);
System.out.println$S("CDXMLW text=" + text);
$I$(4).openTag$javajs_util_SB$S(this.sb, "s");
this.sb.setLength$I(this.sb.length$() - 1);
this.sb.append$S(C$.wrapCData$S(text));
$I$(4).closeTag$javajs_util_SB$S(this.sb, "s");
break;
default:
p$1.skip$I.apply(this, [len]);
}
}, p$1);

Clazz.newMeth(C$, 'wrapCData$S',  function (s) {
return (s.indexOf$S("&") < 0 && s.indexOf$S("<") < 0  ? s : "<![CDATA[" + $I$(6).rep$S$S$S(s, "]]>", "]]]]><![CDATA[>") + "]]>" );
}, 1);

Clazz.newMeth(C$, 'getNodeType$I',  function (n) {
var name=null;
switch (n) {
case 0:
return "Unspecified";
case 1:
return "Element";
case 4:
return "Nickname";
case 5:
return "Fragment";
case 7:
return "GenericNickname";
case 10:
return "MultiAttachment";
case 11:
return "VariableAttachment";
case 12:
return "ExternalConnectionPoint";
case 2:
name="ElementList";
break;
case 3:
name="ElementListNickname";
break;
case 6:
name="Formula";
break;
case 8:
name="AnonymousAlternativeGroup";
break;
case 9:
name="NamedAnonymousGroup";
break;
case 13:
name="LinkNode";
break;
}
System.err.println$S("CDXMLWriter Node type " + name + " not identified" );
return "_";
}, 1);

Clazz.newMeth(C$, 'getBondDisplay$I',  function (i) {
switch (i) {
case 0:
return "Solid";
case 1:
return "Dash";
case 2:
return "Hash";
case 3:
return "WedgedHashBegin";
case 4:
return "WedgedHashEnd";
case 5:
return "Bold";
case 6:
return "WedgeBegin";
case 7:
return "WedgeEnd";
case 8:
return "Wavy";
case 9:
return "HollowWedgeBegin";
case 10:
return "HollowWedgeEnd";
case 11:
return "WavyWedgeBegin";
case 12:
return "WavyWedgeEnd";
case 13:
return "Dot";
case 14:
return "DashDot";
}
return null;
}, 1);

Clazz.newMeth(C$, 'getBondOrder$I',  function (i) {
switch (i) {
case 1:
return "1";
case 2:
return "2";
case 4:
return "3";
case 8:
return "4";
case 16:
return "5";
case 32:
return "6";
case 64:
return "0.5";
case 128:
return "1.5";
case 256:
return "2.5";
case 512:
return "3.5";
case 1024:
return "4.5";
case 2048:
return "5.5";
case 4096:
return "dative";
case 8192:
return "ionic";
case 16384:
return "hydrogen";
case 32768:
return "threecenter";
}
return null;
}, 1);

Clazz.newMeth(C$, 'removeObject',  function () {
this.sb.setLength$I(this.sbpt);
}, p$1);

Clazz.newMeth(C$, 'skip$I',  function (len) {
this.doc.seek$J(Long.$add(this.doc.getPosition$(),len));
}, p$1);

Clazz.newMeth(C$, 'readInt$I',  function (len) {
switch (len) {
case 1:
return (256 + this.doc.readByte$()) % 256;
case 2:
return this.doc.readShort$();
case 4:
return this.doc.readInt$();
case 8:
return Long.$ival(this.doc.readLong$());
}
System.err.println$S("CDXMLWriter.readInt len " + len);
return 0;
}, p$1);

Clazz.newMeth(C$, 'readString$I',  function (len) {
var nStyles=this.doc.readShort$();
len-=2;
switch (nStyles) {
case 0:
break;
default:
p$1.skip$I.apply(this, [nStyles * 10]);
len-=nStyles * 10;
break;
}
return this.doc.readString$I(len);
}, p$1);

Clazz.newMeth(C$, 'readArray',  function () {
var s="";
for (var i=this.doc.readShort$(); --i >= 0; ) {
s+=" " + this.doc.readInt$();
}
return s.trim$();
}, p$1);

Clazz.newMeth(C$, 'readLength',  function () {
var len=this.doc.readShort$();
if (len == -1) {
len=this.doc.readInt$();
}return len;
}, p$1);

Clazz.newMeth(C$, 'toPoint$I',  function (i) {
return Math.round$D(i / 655.36) / 100.0;
}, 1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
try {
var fis=Clazz.new_($I$(7,1).c$$S,["c:/temp/t2.cdx"]);
var doc=Clazz.new_($I$(8,1));
doc.setStream$java_io_BufferedInputStream$Z(Clazz.new_($I$(9,1).c$$java_io_InputStream,[fis]), false);
System.out.println$S(C$.fromCDX$javajs_api_GenericBinaryDocument(doc));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'fromString$org_jmol_viewer_Viewer$S$S',  function (vwr, type, mol) {
var htParams=Clazz.new_($I$(5,1));
htParams.put$O$O("filter", "filetype=" + type);
var o;
try {
o=vwr.getModelAdapter$().getAtomSetCollectionFromReader$S$O$java_util_Map("", $I$(10).getBR$S(mol), htParams);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
return null;
} else {
throw e;
}
}
if (Clazz.instanceOf(o, "java.lang.String")) {
return null;
}return C$.fromASC$org_jmol_adapter_smarter_AtomSetCollection(o);
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.cdxAttributes=Clazz.array(String, -1, ["HashSpacing", "2.50", "MarginWidth", "1.60", "LineWidth", "0.60", "BoldWidth", "2", "BondLength", "14.40", "BondSpacing", "18"]);
};
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:59 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
