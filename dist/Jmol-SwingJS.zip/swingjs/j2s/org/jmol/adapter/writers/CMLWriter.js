(function(){var P$=Clazz.newPackage("org.jmol.adapter.writers"),I$=[[0,'javajs.util.SB','javajs.util.BS','javajs.util.PT','org.jmol.util.Edge']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CMLWriter", null, null, 'org.jmol.api.JmolWriter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['addBonds','doTransform','allTrajectories'],'I',['atomsMax'],'O',['vwr','org.jmol.viewer.Viewer','oc','javajs.util.OC']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'set$org_jmol_viewer_Viewer$javajs_util_OC$OA',  function (viewer, out, data) {
this.vwr=viewer;
this.oc=(this.oc == null  ? this.vwr.getOutputChannel$S$SA(null, null) : this.oc);
this.atomsMax=(data[0]).intValue$();
this.addBonds=(data[1]).booleanValue$();
this.doTransform=(data[2]).booleanValue$();
this.allTrajectories=(data[3]).booleanValue$();
});

Clazz.newMeth(C$, 'write$javajs_util_BS',  function (bs) {
var sb=Clazz.new_($I$(1,1));
var nAtoms=bs.cardinality$();
if (nAtoms == 0) return "";
C$.openTag$javajs_util_SB$S(sb, "molecule");
C$.openTag$javajs_util_SB$S(sb, "atomArray");
var bsAtoms=Clazz.new_($I$(2,1));
var atoms=this.vwr.ms.at;
for (var i=bs.nextSetBit$I(0); i >= 0; i=bs.nextSetBit$I(i + 1)) {
if (--this.atomsMax < 0) break;
var atom=atoms[i];
var name=atom.getAtomName$();
$I$(3).rep$S$S$S(name, "\"", "\'\'");
bsAtoms.set$I(atom.i);
C$.appendEmptyTag$javajs_util_SB$S$SA(sb, "atom", Clazz.array(String, -1, ["id", "a" + (atom.i + 1), "title", atom.getAtomName$(), "elementType", atom.getElementSymbol$(), "x3", "" + new Double(atom.x).toString(), "y3", "" + new Double(atom.y).toString(), "z3", "" + new Double(atom.z).toString()]));
}
C$.closeTag$javajs_util_SB$S(sb, "atomArray");
if (this.addBonds) {
C$.openTag$javajs_util_SB$S(sb, "bondArray");
var bondCount=this.vwr.ms.bondCount;
var bonds=this.vwr.ms.bo;
for (var i=0; i < bondCount; i++) {
var bond=bonds[i];
if (bond == null ) continue;
var a1=bond.atom1;
var a2=bond.atom2;
if (!bsAtoms.get$I(a1.i) || !bsAtoms.get$I(a2.i) ) continue;
var order=$I$(4).getCmlBondOrder$I(bond.order);
if (order == null ) continue;
C$.appendEmptyTag$javajs_util_SB$S$SA(sb, "bond", Clazz.array(String, -1, ["atomRefs2", "a" + (bond.atom1.i + 1) + " a" + (bond.atom2.i + 1) , "order", order]));
}
C$.closeTag$javajs_util_SB$S(sb, "bondArray");
}C$.closeTag$javajs_util_SB$S(sb, "molecule");
this.oc.append$S(sb.toString());
return this.toString();
});

Clazz.newMeth(C$, 'openDocument$javajs_util_SB',  function (sb) {
sb.append$S("<?xml version=\"1.0\"?>\n");
}, 1);

Clazz.newMeth(C$, 'openTag$javajs_util_SB$S',  function (sb, name) {
sb.append$S("<").append$S(name).append$S(">\n");
}, 1);

Clazz.newMeth(C$, 'startOpenTag$javajs_util_SB$S',  function (sb, name) {
sb.append$S("<").append$S(name);
}, 1);

Clazz.newMeth(C$, 'terminateTag$javajs_util_SB',  function (sb) {
sb.append$S(">\n");
}, 1);

Clazz.newMeth(C$, 'terminateEmptyTag$javajs_util_SB',  function (sb) {
sb.append$S("/>\n");
}, 1);

Clazz.newMeth(C$, 'appendEmptyTag$javajs_util_SB$S$SA',  function (sb, name, attributes) {
C$.startOpenTag$javajs_util_SB$S(sb, name);
C$.addAttributes$javajs_util_SB$SA(sb, attributes);
C$.terminateEmptyTag$javajs_util_SB(sb);
}, 1);

Clazz.newMeth(C$, 'addAttributes$javajs_util_SB$SA',  function (sb, attributes) {
for (var i=0; i < attributes.length; i++) {
C$.addAttribute$javajs_util_SB$S$S(sb, attributes[i], attributes[++i]);
}
}, 1);

Clazz.newMeth(C$, 'addAttribute$javajs_util_SB$S$S',  function (sb, key, val) {
sb.append$S(" ").append$S(key).append$S("=").append$S($I$(3).esc$S(val));
}, 1);

Clazz.newMeth(C$, 'closeTag$javajs_util_SB$S',  function (sb, name) {
sb.append$S("</").append$S(name).append$S(">\n");
}, 1);

Clazz.newMeth(C$, 'toString',  function () {
return (this.oc == null  ? "" : this.oc.toString());
});
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:34 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
