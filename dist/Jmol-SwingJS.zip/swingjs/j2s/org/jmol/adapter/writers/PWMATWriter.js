(function(){var P$=Clazz.newPackage("org.jmol.adapter.writers"),p$1={},I$=[[0,'javajs.util.PT','org.jmol.util.Logger','javajs.util.P3d']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PWMATWriter", null, 'org.jmol.adapter.writers.XtlWriter', 'org.jmol.api.JmolWriter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.writeGlobals=false;
},1);

C$.$fields$=[['Z',['isPrecision','isSlab','writeGlobals'],'O',['vwr','org.jmol.viewer.Viewer','oc','javajs.util.OC','uc','org.jmol.api.SymmetryInterface','names','javajs.util.Lst','bs','javajs.util.BS']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'set$org_jmol_viewer_Viewer$javajs_util_OC$OA',  function (viewer, oc, data) {
this.vwr=viewer;
this.isSlab=(data != null  && data[0] != null   && data[0].equals$O("slab") );
this.oc=(oc == null  ? this.vwr.getOutputChannel$S$SA(null, null) : oc);
});

Clazz.newMeth(C$, 'write$javajs_util_BS',  function (bs) {
if (bs == null ) bs=this.vwr.bsA$();
try {
this.uc=this.vwr.ms.getUnitCellForAtom$I(bs.nextSetBit$I(0));
this.bs=(this.isSlab ? bs : this.uc.removeDuplicates$org_jmol_modelset_ModelSet$javajs_util_BS$Z(this.vwr.ms, bs, false));
this.isPrecision=true;
this.names=this.vwr.getDataObj$S$javajs_util_BS$I("property_pwm_*", null, -1);
p$1.writeHeader.apply(this, []);
p$1.writeLattice.apply(this, []);
p$1.writePositions.apply(this, []);
p$1.writeDataBlocks.apply(this, []);
if (this.writeGlobals) p$1.writeGlobalBlocks.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("Error writing PWmat file " + e);
} else {
throw e;
}
}
return this.toString();
});

Clazz.newMeth(C$, 'writeHeader',  function () {
this.oc.append$S($I$(1,"formatStringI$S$S$I",["%12i\n", "i", this.bs.cardinality$()]));
}, p$1);

Clazz.newMeth(C$, 'writeLattice',  function () {
this.oc.append$S("Lattice vector\n");
if (this.uc == null ) {
this.uc=this.vwr.getSymTemp$();
var bb=this.vwr.getBoundBoxCornerVector$();
var len=Long.$ival(Math.round$D(bb.length$() * 2));
this.uc.setUnitCell$DA$Z(Clazz.array(Double.TYPE, -1, [len, len, len, 90, 90, 90]), false);
}var abc=this.uc.getUnitCellVectors$();
if (this.isPrecision) {
var f="%18.10P%18.10P%18.10P\n";
this.oc.append$S($I$(1,"sprintf$S$S$OA",[f, "P", Clazz.array(java.lang.Object, -1, [abc[1]])]));
this.oc.append$S($I$(1,"sprintf$S$S$OA",[f, "P", Clazz.array(java.lang.Object, -1, [abc[2]])]));
this.oc.append$S($I$(1,"sprintf$S$S$OA",[f, "P", Clazz.array(java.lang.Object, -1, [abc[3]])]));
} else {
var f="%12.6p%12.6p%12.6p\n";
this.oc.append$S($I$(1,"sprintf$S$S$OA",[f, "p", Clazz.array(java.lang.Object, -1, [abc[1]])]));
this.oc.append$S($I$(1,"sprintf$S$S$OA",[f, "p", Clazz.array(java.lang.Object, -1, [abc[2]])]));
this.oc.append$S($I$(1,"sprintf$S$S$OA",[f, "p", Clazz.array(java.lang.Object, -1, [abc[3]])]));
}$I$(2).info$S("PWMATWriter: LATTICE VECTORS");
}, p$1);

Clazz.newMeth(C$, 'writePositions',  function () {
var cx=p$1.getData$S.apply(this, ["CONSTRAINTS_X"]);
var cy=(cx == null  ? null : p$1.getData$S.apply(this, ["CONSTRAINTS_Y"]));
var cz=(cy == null  ? null : p$1.getData$S.apply(this, ["CONSTRAINTS_Z"]));
this.oc.append$S("Position, move_x, move_y, move_z\n");
var a=this.vwr.ms.at;
var coord;
var p=Clazz.new_($I$(3,1));
var f=(this.isPrecision ? "%4i%78s   " : "%4i%36s   ") + (cz == null  ? "  1  1  1" : "%3i%3i%3i") + "\n" ;
for (var ic=0, i=this.bs.nextSetBit$I(0); i >= 0; i=this.bs.nextSetBit$I(i + 1), ic++) {
if (this.isPrecision) {
p.setT$javajs_util_T3d(a[i]);
this.uc.toFractional$javajs_util_T3d$Z(p, false);
coord=this.clean$D(p.x) + this.clean$D(p.y) + this.clean$D(p.z) ;
} else {
p.setT$javajs_util_T3d(a[i]);
this.uc.toFractional$javajs_util_T3d$Z(p, false);
coord=this.cleanF$D(p.x) + this.cleanF$D(p.y) + this.cleanF$D(p.z) ;
}if (cz == null ) {
this.oc.append$S($I$(1,"sprintf$S$S$OA",[f, "is", Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(a[i].getElementNumber$()), coord])]));
} else {
var ix=(cx[ic]|0);
var iy=(cy[ic]|0);
var iz=(cz[ic]|0);
this.oc.append$S($I$(1,"sprintf$S$S$OA",[f, "isiii", Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(a[i].getElementNumber$()), coord, Integer.valueOf$I(ix), Integer.valueOf$I(iy), Integer.valueOf$I(iz)])]));
}}
$I$(2).info$S("PWMATWriter: POSITIONS");
}, p$1);

Clazz.newMeth(C$, 'getData$S',  function (name) {
name="property_pwm_" + name.toLowerCase$();
for (var i=this.names.size$(); --i >= 0; ) {
var n=this.names.get$I(i);
if (name.equalsIgnoreCase$S(n)) {
this.names.removeItemAt$I(i);
return this.vwr.getDataObj$S$javajs_util_BS$I(n, this.bs, 1);
}}
return null;
}, p$1);

Clazz.newMeth(C$, 'getVectors$S',  function (name) {
var vectors=Clazz.array(Double.TYPE, -2, [p$1.getData$S.apply(this, [name + "_x"]), p$1.getData$S.apply(this, [name + "_y"]), p$1.getData$S.apply(this, [name + "_z"])]);
return (vectors[0] == null  || vectors[1] == null   || vectors[2] == null   ? null : vectors);
}, p$1);

Clazz.newMeth(C$, 'writeDataBlocks',  function () {
p$1.writeVectors$S.apply(this, ["FORCE"]);
p$1.writeVectors$S.apply(this, ["VELOCITY"]);
p$1.writeMagnetic.apply(this, []);
p$1.writeMoreData.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'writeVectors$S',  function (name) {
var xyz=p$1.getVectors$S.apply(this, [name]);
if (xyz == null ) return;
var a=this.vwr.ms.at;
var p=Clazz.new_($I$(3,1));
this.oc.append$S(name.toUpperCase$()).append$S("\n");
var f="%4i%26.15p%26.15p%26.15p\n";
for (var ic=0, i=this.bs.nextSetBit$I(0); i >= 0; i=this.bs.nextSetBit$I(i + 1), ic++) {
p.set$D$D$D(xyz[0][ic], xyz[1][ic], xyz[2][ic]);
this.oc.append$S($I$(1,"sprintf$S$S$OA",[f, "ip", Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(a[i].getElementNumber$()), p])]));
}
$I$(2).info$S("PWMATWriter: " + name);
}, p$1);

Clazz.newMeth(C$, 'writeMagnetic',  function () {
var m=p$1.writeItems$S.apply(this, ["MAGNETIC"]);
if (m == null ) return;
p$1.writeItem2$DA$S.apply(this, [m, "CONSTRAINT_MAG"]);
}, p$1);

Clazz.newMeth(C$, 'writeItem2$DA$S',  function (m, name) {
var v=p$1.getData$S.apply(this, [name]);
if (v == null ) return;
var a=this.vwr.ms.at;
this.oc.append$S(name.toUpperCase$()).append$S("\n");
var f="%4i%26.15f%26.15f\n";
for (var ic=0, i=this.bs.nextSetBit$I(0); i >= 0; i=this.bs.nextSetBit$I(i + 1), ic++) {
this.oc.append$S($I$(1,"sprintf$S$S$OA",[f, "idd", Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(a[i].getElementNumber$()), Double.valueOf$D(m[ic]), Double.valueOf$D(v[ic])])]));
}
}, p$1);

Clazz.newMeth(C$, 'writeItems$S',  function (name) {
var m=p$1.getData$S.apply(this, [name]);
if (m == null ) return null;
var a=this.vwr.ms.at;
name=name.toUpperCase$();
this.oc.append$S(name).append$S("\n");
var f="%4i%26.15f\n";
for (var ic=0, i=this.bs.nextSetBit$I(0); i >= 0; i=this.bs.nextSetBit$I(i + 1), ic++) {
this.oc.append$S($I$(1,"sprintf$S$S$OA",[f, "id", Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(a[i].getElementNumber$()), Double.valueOf$D(m[ic])])]));
}
$I$(2).info$S("PWMATWriter: " + name);
return m;
}, p$1);

Clazz.newMeth(C$, 'writeMoreData',  function () {
var n=this.names.size$();
var i0=0;
while (this.names.size$() > i0 && --n >= 0 ){
var name=this.names.get$I(i0).substring$I(13);
System.out.println$S(name);
if (name.endsWith$S("_y") || name.endsWith$S("_z") ) {
++i0;
continue;
}if (name.endsWith$S("_x")) {
p$1.writeVectors$S.apply(this, [name.substring$I$I(0, name.length$() - 2)]);
i0=0;
} else {
p$1.writeItems$S.apply(this, [name]);
}}
}, p$1);

Clazz.newMeth(C$, 'writeGlobalBlocks',  function () {
var globals=this.vwr.getModelForAtomIndex$I(this.bs.nextSetBit$I(0)).auxiliaryInfo.get$O("globalPWmatData");
if (globals != null ) for (var e, $e = globals.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) {
this.oc.append$S(e.getKey$()).append$S("\n");
var lines=e.getValue$();
for (var i=0; i < lines.length; i++) this.oc.append$S(lines[i]).append$S("\n");

}
}, p$1);

Clazz.newMeth(C$, 'toString',  function () {
return (this.oc == null  ? "" : this.oc.toString());
});
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:14 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
