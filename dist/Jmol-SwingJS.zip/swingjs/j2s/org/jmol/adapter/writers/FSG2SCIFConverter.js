(function(){var P$=Clazz.newPackage("org.jmol.adapter.writers"),p$1={},I$=[[0,'javajs.util.V3d','javajs.util.Qd','org.jmol.adapter.writers.CIFWriter','javajs.util.BS']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FSG2SCIFConverter", null, 'org.jmol.adapter.writers.CIFWriter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['scifInfo','java.util.Map','spinIndex','int[]']]
,['O',['v0','javajs.util.V3d','headerKeys','String[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'prepareAtomSet$javajs_util_BS',  function (bs) {
C$.superclazz.prototype.prepareAtomSet$javajs_util_BS.apply(this, [bs]);
this.modelInfo=this.data[0];
this.scifInfo=this.data[1];
});

Clazz.newMeth(C$, 'writeHeader$javajs_util_SB',  function (sb) {
var axis=null;
var angle=0;
var m3=this.modelInfo.get$O("spinRotationMatrixApplied");
if (m3 != null ) {
var q=$I$(2).newM$javajs_util_M3d(m3);
axis=q.getNormalDirected$javajs_util_V3d(C$.v0);
angle=q.getThetaDirectedV$javajs_util_V3d(C$.v0);
if (Math.abs(angle) < 1 ) axis=null;
}for (var i=0; i < C$.headerKeys.length; i++) {
var type=this.scifInfo.get$O("configuration");
var s;
switch (i) {
case 0:
s=this.scifInfo.get$O("spinFrame");
break;
case 1:
s=(type.equals$O("Collinear") ? "1,0,0" : ".");
break;
case 2:
s=(type.equals$O("Coplanar") ? "0,0,1" : ".");
break;
case 3:
s=(axis == null  ? "?" : "[ " + new Double(axis.x).toString() + " " + new Double(axis.y).toString() + " " + new Double(axis.z).toString() + " ]" );
break;
case 4:
s=(angle == 0  ? "?" : this.clean$D(angle));
break;
case 5:
s=this.scifInfo.get$O("fsgID");
break;
case 6:
s="\n;\n" + this.scifInfo.get$O("simpleName") + "\n;\n" ;
break;
default:
s="??";
break;
}
$I$(3).appendField$javajs_util_SB$S$I(sb, C$.headerKeys[i], 45);
sb.append$S(s).append$S("\n");
}
});

Clazz.newMeth(C$, 'writeOperations$javajs_util_SB',  function (sb) {
var refsOp=this.scifInfo.get$O("G0_operationURefs");
var refsLat=this.scifInfo.get$O("G0_spinLatticeURefs");
var bsUparts=p$1.getReferences$IA$IA.apply(this, [refsOp, refsLat]);
var timeRev=this.scifInfo.get$O("SCIF_spinListTR");
p$1.addOps$javajs_util_SB$S$S$IA$IA.apply(this, [sb, "\nloop_\n_space_group_symop_spin_operation.id\n_space_group_symop_spin_operation.xyzt\n_space_group_symop_spin_operation.uvw_id\n", "G0_operations", refsOp, timeRev]);
p$1.addOps$javajs_util_SB$S$S$IA$IA.apply(this, [sb, "\nloop_\n_space_group_symop_spin_lattice.id\n_space_group_symop_spin_lattice.xyzt\n_space_group_symop_spin_lattice.uvw_id\n", "G0_spinLattice", refsLat, timeRev]);
sb.append$S("\nloop_\n_space_group_symop_spin_Upart.id\n_space_group_symop_spin_Upart.time_reversal\n_space_group_symop_spin_Upart.uvw\n");
var uparts=this.scifInfo.get$O("SCIF_spinList");
for (var i=bsUparts.nextSetBit$I(0); i >= 0; i=bsUparts.nextSetBit$I(i + 1)) {
$I$(3,"appendField$javajs_util_SB$S$I",[sb, "" + (this.spinIndex[i]), 3]);
$I$(3).appendField$javajs_util_SB$S$I(sb, "" + timeRev[i], 3);
$I$(3,"appendField$javajs_util_SB$S$I",[sb, uparts.get$I(i), 30]);
sb.append$S("\n");
}
});

Clazz.newMeth(C$, 'getReferences$IA$IA',  function (refsOp, refsLat) {
var bs=Clazz.new_($I$(4,1));
for (var i=refsOp.length; --i >= 0; ) bs.set$I(refsOp[i]);

if (refsLat != null ) for (var i=refsLat.length; --i >= 0; ) bs.set$I(refsLat[i]);

this.spinIndex=Clazz.array(Integer.TYPE, [bs.length$()]);
for (var pt=0, i=bs.nextSetBit$I(0); i >= 0; i=bs.nextSetBit$I(i + 1)) {
this.spinIndex[i]=++pt;
}
return bs;
}, p$1);

Clazz.newMeth(C$, 'timeRevValue$I',  function (t) {
return (t < 0 ? "-1" : "+1");
}, 1);

Clazz.newMeth(C$, 'addOps$javajs_util_SB$S$S$IA$IA',  function (sb, loopKeys, opsKey, refs, timeReversal) {
var ops=this.scifInfo.get$O(opsKey);
if (ops == null ) return;
sb.append$S(loopKeys);
for (var i=0, n=ops.size$(); i < n; i++) {
var xyz=ops.get$I(i).substring$I$I(0, ops.get$I(i).indexOf$I("("));
$I$(3,"appendField$javajs_util_SB$S$I",[sb, "" + (i + 1), 3]);
$I$(3,"appendField$javajs_util_SB$S$I",[sb, xyz + "," + C$.timeRevValue$I(timeReversal[refs[i]]) , 30]);
$I$(3).appendField$javajs_util_SB$S$I(sb, "" + this.spinIndex[refs[i]], 3);
sb.append$S("\n");
}
}, p$1);

Clazz.newMeth(C$, 'writeAtomSite$javajs_util_SB',  function (sb) {
var natoms=C$.superclazz.prototype.writeAtomSite$javajs_util_SB.apply(this, [sb]);
sb.append$S("\nloop_\n_atom_site_spin_moment.label\n_atom_site_spin_moment.axis_u\n_atom_site_spin_moment.axis_v\n_atom_site_spin_moment.axis_w\n_atom_site_spin_moment.symmform_uvw\n_atom_site_spin_moment.magnitude\n");
for (var i=this.bsOut.nextSetBit$I(0), p=0; i >= 0; i=this.bsOut.nextSetBit$I(i + 1)) {
var a=this.atoms[i];
var label=this.atomLabels[p++];
var m=a.getVibrationVector$();
if (m == null  || m.magMoment == 0  ) continue;
$I$(3).appendField$javajs_util_SB$S$I(sb, label, 5);
var v=(m.v0 == null  ? m : m.v0);
this.append3$javajs_util_SB$javajs_util_T3d(sb, v);
sb.append$S(" ?");
sb.append$S(" ").append$S(this.clean$D(v.length$()));
sb.append$S("\n");
}
this.jmol_atoms=null;
return natoms;
});

C$.$static$=function(){C$.$static$=0;
C$.v0=$I$(1).new3$D$D$D(3.14159, 2.71828, 1.4142);
C$.headerKeys=Clazz.array(String, -1, ["_space_group_spin.transform_spinframe_P_abc", "_space_group_spin.collinear_direction", "_space_group_spin.coplanar_perp_uvw", "_space_group_spin.rotation_axis_cartn", "_space_group_spin.rotation_angle", "_space_group_spin.number_SpSG_Chen", "_space_group_spin.name_SpSG_Chen"]);
};
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:42 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
