(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.pdb"),I$=[[0,'java.util.Hashtable','javajs.util.PT','org.jmol.util.Logger','org.jmol.util.Parser','javajs.util.P3d','org.jmol.util.Vibration','org.jmol.util.C','org.jmol.util.Escape','org.jmol.script.T','javajs.util.Lst']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JmolDataReader", null, 'org.jmol.adapter.readers.pdb.PdbReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.originatingModel=-1;
},1);

C$.$fields$=[['Z',['isSpin'],'D',['spinFactor'],'I',['originatingModel'],'S',['jmolDataHeader'],'O',['props','java.util.Map','residueNames','String[]','+atomNames','jmolDataScaling','javajs.util.P3d[]']]]

Clazz.newMeth(C$, 'checkRemark$',  function () {
while (true){
if (this.line.length$() < 30 || this.line.indexOf$S("Jmol") != 11 ) break;
switch ("Ppard".indexOf$S(this.line.substring$I$I(16, 17))) {
case 0:
this.props=Clazz.new_($I$(1,1));
this.isSpin=(this.line.indexOf$S(": spin;") >= 0);
this.originatingModel=-1;
var pt=this.line.indexOf$S("for model ");
if (pt > 0) this.originatingModel=$I$(2,"parseInt$S",[this.line.substring$I(pt + 10)]);
this.jmolDataHeader=this.line;
if (!this.line.endsWith$S("#noautobond")) this.line+="#noautobond";
break;
case 1:
var pt1=this.line.indexOf$S("[");
var pt2=this.line.indexOf$S("]");
if (pt1 < 25 || pt2 <= pt1 ) return;
var name=this.line.substring$I$I(25, pt1).trim$();
this.line=this.line.substring$I$I(pt1 + 1, pt2).replace$C$C(",", " ");
var tokens=this.getTokens$();
$I$(3).info$S("reading " + name + " " + tokens.length );
var prop=Clazz.array(Double.TYPE, [tokens.length]);
for (var i=prop.length; --i >= 0; ) prop[i]=this.parseDoubleStr$S(tokens[i]);

this.props.put$O$O(name, prop);
break;
case 2:
this.line=this.line.substring$I(27);
this.atomNames=this.getTokens$();
$I$(3).info$S("reading atom names " + this.atomNames.length);
break;
case 3:
this.line=this.line.substring$I(30);
this.residueNames=this.getTokens$();
$I$(3).info$S("reading residue names " + this.residueNames.length);
break;
case 4:
$I$(3).info$S(this.line);
var data=Clazz.array(Double.TYPE, [15]);
$I$(4,"parseStringInfestedDoubleArray$S$javajs_util_BS$DA",[this.line.substring$I(10).replace$C$C("=", " ").replace$C$C("{", " ").replace$C$C("}", " "), null, data]);
var minXYZ=$I$(5).new3$D$D$D(data[0], data[1], data[2]);
var maxXYZ=$I$(5).new3$D$D$D(data[3], data[4], data[5]);
this.fileScaling=$I$(5).new3$D$D$D(data[6], data[7], data[8]);
this.fileOffset=$I$(5).new3$D$D$D(data[9], data[10], data[11]);
var plotScale=$I$(5).new3$D$D$D(data[12], data[13], data[14]);
if (plotScale.x <= 0 ) plotScale.x=100;
if (plotScale.y <= 0 ) plotScale.y=100;
if (plotScale.z <= 0 ) plotScale.z=100;
if (this.fileScaling.y == 0 ) this.fileScaling.y=1;
if (this.fileScaling.z == 0 ) this.fileScaling.z=1;
if (this.isSpin) {
this.spinFactor=plotScale.x / maxXYZ.x;
} else {
this.setFractionalCoordinates$Z(true);
this.latticeCells=Clazz.array(Integer.TYPE, [4]);
this.asc.xtalSymmetry=null;
this.setUnitCell$D$D$D$D$D$D(plotScale.x * 2 / (maxXYZ.x - minXYZ.x), plotScale.y * 2 / (maxXYZ.y - minXYZ.y), plotScale.z * 2 / (maxXYZ.z == minXYZ.z  ? 1 : maxXYZ.z - minXYZ.z), 90, 90, 90);
this.unitCellOffset=$I$(5).newP$javajs_util_T3d(plotScale);
this.unitCellOffset.scale$D(-1);
this.getSymmetry$();
this.symmetry.toFractional$javajs_util_T3d$Z(this.unitCellOffset, false);
this.unitCellOffset.scaleAdd2$D$javajs_util_T3d$javajs_util_T3d(-1.0, minXYZ, this.unitCellOffset);
this.symmetry.setOffsetPt$javajs_util_T3d(this.unitCellOffset);
this.doApplySymmetry=true;
}this.jmolDataScaling=Clazz.array($I$(5), -1, [minXYZ, maxXYZ, plotScale]);
break;
}
break;
}
this.checkCurrentLineForScript$();
});

Clazz.newMeth(C$, 'processAtom2$org_jmol_adapter_smarter_Atom$I$D$D$D$I',  function (atom, serial, x, y, z, charge) {
if (this.isSpin) {
var vib=Clazz.new_($I$(6,1));
vib.set$D$D$D(x, y, z);
vib.isFrom000=true;
atom.vib=vib;
x*=this.spinFactor;
y*=this.spinFactor;
z*=this.spinFactor;
}C$.superclazz.prototype.processAtom2$org_jmol_adapter_smarter_Atom$I$D$D$D$I.apply(this, [atom, serial, x, y, z, charge]);
});

Clazz.newMeth(C$, 'setAdditionalAtomParameters$org_jmol_adapter_smarter_Atom',  function (atom) {
if (this.residueNames != null  && atom.index < this.residueNames.length ) atom.group3=this.residueNames[atom.index];
if (this.atomNames != null  && atom.index < this.atomNames.length ) atom.atomName=this.atomNames[atom.index];
});

Clazz.newMeth(C$, 'finalizeSubclassReader$',  function () {
if (this.jmolDataHeader == null ) return;
var info=Clazz.new_($I$(1,1));
info.put$O$O("header", this.jmolDataHeader);
info.put$O$O("originatingModel", Integer.valueOf$I(this.originatingModel));
info.put$O$O("properties", this.props);
info.put$O$O("jmolDataScaling", this.jmolDataScaling);
this.asc.setInfo$S$O("jmolData", info);
this.finalizeReaderPDB$();
});

Clazz.newMeth(C$, 'getJmolDataFrameScripts$org_jmol_viewer_Viewer$I$I$I$S$S$SA$Z',  function (vwr, tok, modelIndex, modelCount, type, qFrame, props, isSpinPointGroup) {
var script;
var script2=null;
switch (tok) {
default:
script="frame 0.0; frame last; reset;select visible;wireframe only;";
break;
case 1715472409:
vwr.setFrameTitle$I$S(modelCount - 1, type + " plot for model " + vwr.getModelNumberDotted$I(modelIndex) );
script="frame 0.0; frame last; reset;select visible; spacefill 3.0; wireframe 0;draw plotAxisX" + modelCount + " {100 -100 -100} {-100 -100 -100} \"" + props[0] + "\";" + "draw plotAxisY" + modelCount + " {-100 100 -100} {-100 -100 -100} \"" + props[1] + "\";" ;
if (props[2] != null ) script+="draw plotAxisZ" + modelCount + " {-100 -100 100} {-100 -100 -100} \"" + props[2] + "\";" ;
break;
case 4138:
vwr.setFrameTitle$I$S(modelCount - 1, "ramachandran plot for model " + vwr.getModelNumberDotted$I(modelIndex));
script="frame 0.0; frame last; reset;select visible; color structure; spacefill 3.0; wireframe 0;draw ramaAxisX" + modelCount + " {100 0 0} {-100 0 0} \"phi\";" + "draw ramaAxisY" + modelCount + " {0 100 0} {0 -100 0} \"psi\";" ;
break;
case 134221850:
case 136314895:
vwr.setFrameTitle$I$S(modelCount - 1, type.replace$C$C("w", " ") + qFrame + " for model " + vwr.getModelNumberDotted$I(modelIndex) );
case 1095241729:
var color=($I$(7).getHexCode$H(vwr.cm.colixBackgroundContrast));
script="frame 0.0; frame last; reset;select visible; wireframe 0; spacefill 3.0; isosurface quatSphere" + modelCount + " color " + color + " sphere 100.0 mesh nofill frontonly translucent 0.8;" + "draw quatAxis" + modelCount + "X {100 0 0} {-100 0 0} color red \"x\";" + "draw quatAxis" + modelCount + "Y {0 100 0} {0 -100 0} color green \"y\";" + "draw quatAxis" + modelCount + "Z {0 0 100} {0 0 -100} color blue \"z\";" + (tok == 1095241729 ? "vectors 2.0;spacefill off;" : "color structure;") + "draw quatCenter" + modelCount + "{0 0 0} scale 0.02;" ;
if (isSpinPointGroup) {
script2=";set symmetryhm;draw spin pointgroup;var name = {2.1}.pointgroup().hmName;set echo hmname 100% 100%;set echo hmname RIGHT;set echo hmname model 2.1;echo @name;";
}break;
}
return Clazz.array(String, -1, [script, script2]);
});

Clazz.newMeth(C$, 'getJmolDataFrameProperties$org_jmol_script_ScriptEval$I$IA$SA$javajs_util_BS$javajs_util_P3d$javajs_util_P3d$S$Z',  function (e, tok, propToks, props, bs, minXYZ, maxXYZ, format, isPdbFormat) {
var pdbFactor=1;
var dataX=null;
var dataY=null;
var dataZ=null;
dataX=e.getBitsetPropertyFloat$javajs_util_BS$I$S$D$D(bs, propToks[0] | 224, propToks[0] == 1715472409 ? props[0] : null, (minXYZ == null  ? NaN : minXYZ.x), (maxXYZ == null  ? NaN : maxXYZ.x));
var propData=Clazz.array(String, [3]);
propData[0]=props[0] + " " + $I$(8).eAD$DA(dataX) ;
if (props[1] != null ) {
dataY=e.getBitsetPropertyFloat$javajs_util_BS$I$S$D$D(bs, propToks[1] | 224, propToks[1] == 1715472409 ? props[1] : null, (minXYZ == null  ? NaN : minXYZ.y), (maxXYZ == null  ? NaN : maxXYZ.y));
propData[1]=props[1] + " " + $I$(8).eAD$DA(dataY) ;
}if (props[2] != null ) {
dataZ=e.getBitsetPropertyFloat$javajs_util_BS$I$S$D$D(bs, propToks[2] | 224, propToks[2] == 1715472409 ? props[2] : null, (minXYZ == null  ? NaN : minXYZ.z), (maxXYZ == null  ? NaN : maxXYZ.z));
propData[2]=props[2] + " " + $I$(8).eAD$DA(dataZ) ;
}if (minXYZ == null ) minXYZ=$I$(5,"new3$D$D$D",[C$.getPlotMinMax$DA$Z$I(dataX, false, propToks[0]), C$.getPlotMinMax$DA$Z$I(dataY, false, propToks[1]), C$.getPlotMinMax$DA$Z$I(dataZ, false, propToks[2])]);
if (maxXYZ == null ) maxXYZ=$I$(5,"new3$D$D$D",[C$.getPlotMinMax$DA$Z$I(dataX, true, propToks[0]), C$.getPlotMinMax$DA$Z$I(dataY, true, propToks[1]), C$.getPlotMinMax$DA$Z$I(dataZ, true, propToks[2])]);
$I$(3).info$S("plot min/max: " + minXYZ + " " + maxXYZ );
var center=null;
var factors=null;
if (isPdbFormat) {
factors=$I$(5).new3$D$D$D(1, 1, 1);
center=Clazz.new_($I$(5,1));
center.ave$javajs_util_T3d$javajs_util_T3d(maxXYZ, minXYZ);
factors.sub2$javajs_util_T3d$javajs_util_T3d(maxXYZ, minXYZ);
if (tok != 1095241729) factors.set$D$D$D(factors.x / 200, factors.y / 200, factors.z / 200);
if ($I$(9).tokAttr$I$I(propToks[0], 1094713344)) {
factors.x=1;
center.x=0;
} else if (factors.x > 0.1  && factors.x <= 10  ) {
factors.x=1;
}if ($I$(9).tokAttr$I$I(propToks[1], 1094713344)) {
factors.y=1;
center.y=0;
} else if (factors.y > 0.1  && factors.y <= 10  ) {
factors.y=1;
}if ($I$(9).tokAttr$I$I(propToks[2], 1094713344)) {
factors.z=1;
center.z=0;
} else if (factors.z > 0.1  && factors.z <= 10  ) {
factors.z=1;
}if (props[2] == null  || props[1] == null  ) center.z=minXYZ.z=maxXYZ.z=factors.z=0;
for (var i=0; i < dataX.length; i++) dataX[i]=(dataX[i] - center.x) / factors.x * pdbFactor;

if (props[1] != null ) for (var i=0; i < dataY.length; i++) dataY[i]=(dataY[i] - center.y) / factors.y * pdbFactor;

if (props[2] != null ) for (var i=0; i < dataZ.length; i++) dataZ[i]=(dataZ[i] - center.z) / factors.z * pdbFactor;

}return Clazz.array(java.lang.Object, -1, [bs, dataX, dataY, dataZ, minXYZ, maxXYZ, factors, center, format, propData, Double.valueOf$D(1)]);
});

Clazz.newMeth(C$, 'getPlotMinMax$DA$Z$I',  function (data, isMax, tok) {
if (data == null ) return 0;
switch (tok) {
case 1111490568:
case 1111490569:
case 1111490570:
return (isMax ? 180 : -180);
case 1111490565:
case 1111490576:
return (isMax ? 360 : 0);
case 1111490574:
return (isMax ? 1 : -1);
}
var fmax=(isMax ? -1.0E10 : 1.0E10);
for (var i=data.length; --i >= 0; ) {
var f=data[i];
if (Double.isNaN$D(f)) continue;
if (isMax == (f > fmax ) ) fmax=f;
}
return fmax;
}, 1);

Clazz.newMeth(C$, 'setJmolDataFrame$org_jmol_modelset_ModelSet$S$I$I',  function (ms, type, modelIndex, modelDataIndex) {
ms.haveJmolDataFrames=true;
var mdata=ms.am[modelDataIndex];
var model0=ms.am[type == null  ? mdata.dataSourceFrame : modelIndex];
if (type == null ) {
type=mdata.jmolFrameType;
}if (modelIndex >= 0) {
if (model0.dataFrames == null ) {
model0.dataFrames=Clazz.new_($I$(1,1));
}mdata.dataSourceFrame=modelIndex;
mdata.jmolFrameType=type;
model0.dataFrames.put$O$O(type, Integer.valueOf$I(modelDataIndex));
if (mdata.jmolFrameTypeInt == 134221850 && type.indexOf$S("deriv") < 0 ) {
type=type.substring$I$I(0, type.indexOf$S(" "));
model0.dataFrames.put$O$O(type, Integer.valueOf$I(modelDataIndex));
}mdata.uvw0=ms.getModelAuxiliaryInfo$I(modelIndex).get$O("pointGroupAxes");
if (mdata.uvw0 != null ) {
mdata.uvw0[0].scale$D(105);
mdata.uvw0[1].scale$D(105);
mdata.uvw0[2].scale$D(105);
mdata.uvw=Clazz.array($I$(5), -1, [$I$(5).newP$javajs_util_T3d(mdata.uvw0[0]), $I$(5).newP$javajs_util_T3d(mdata.uvw0[1]), $I$(5).newP$javajs_util_T3d(mdata.uvw0[2])]);
}}});

Clazz.newMeth(C$, 'getPlotSpinSet$org_jmol_viewer_Viewer$javajs_util_BS$I$javajs_util_P3d$javajs_util_P3d',  function (vwr, bs, modelIndex, minXYZ, maxXYZ) {
if (bs.nextSetBit$I(0) < 0) {
bs=vwr.getModelUndeletedAtomsBitSet$I(modelIndex);
}if (bs.isEmpty$()) return null;
var len=0;
for (var i=bs.nextSetBit$I(0); i >= 0; i=bs.nextSetBit$I(i + 1)) {
var v=vwr.ms.getVibration$I$Z(i, false);
if (v == null ) bs.clear$I(i);
 else len=Math.max(len, v.length$());
}
if (len == 0 ) return null;
minXYZ.set$D$D$D(-len, -len, -len);
maxXYZ.set$D$D$D(len, len, len);
var lst=Clazz.new_($I$(10,1));
for (var i=bs.nextSetBit$I(0); i >= 0; i=bs.nextSetBit$I(i + 1)) {
var v=vwr.ms.getVibration$I$Z(i, false);
var found=false;
for (var j=lst.size$(); --j >= 0; ) {
if (v.distance$javajs_util_T3d(lst.get$I(j)) < 0.1 ) {
found=true;
bs.clear$I(i);
break;
}}
if (!found) lst.addLast$O(v);
}
return bs;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:37 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
