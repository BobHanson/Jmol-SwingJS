(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.spartan"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "OdysseyReader", null, 'org.jmol.adapter.readers.spartan.SpartanInputReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'initializeReader$',  function () {
var title=this.readInputRecords$();
this.asc.setAtomSetName$S(title == null  ? "Odyssey file" : title);
while (this.line != null  && this.line.indexOf$S("END ") < 0  && this.line.indexOf$S("MOLSTATE") < 0 )this.rd$();

if (this.line != null  && this.line.indexOf$S("MOLSTATE") >= 0 ) this.readTransform$();
this.continuing=false;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:57 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
