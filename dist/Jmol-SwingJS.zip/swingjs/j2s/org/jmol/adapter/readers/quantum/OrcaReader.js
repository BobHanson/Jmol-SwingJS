(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.quantum"),p$1={},I$=[[0,'javajs.util.Lst','java.util.Hashtable','org.jmol.adapter.readers.quantum.BasisFunctionReader','org.jmol.util.Logger','org.jmol.util.Escape','javajs.util.AU','javajs.util.PT','org.jmol.quantum.QS','org.jmol.adapter.smarter.AtomSetCollectionReader']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "OrcaReader", null, 'org.jmol.adapter.readers.quantum.MOReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['xyzBohr'],'I',['atomCount','moModelSet'],'S',['chargeTag']]]

Clazz.newMeth(C$, 'initializeReader$',  function () {
this.chargeTag=(this.checkAndRemoveFilterKey$S("CHARGE=LOW") ? "LOEW" : "MULL");
});

Clazz.newMeth(C$, 'checkLine$',  function () {
if (this.line.startsWith$S("! Bohrs")) {
this.xyzBohr=true;
return true;
}if (this.line.startsWith$S("* xyz") || this.line.startsWith$S("*xyz") ) {
p$1.processInputFile.apply(this, []);
this.continuing=false;
return false;
}if (this.line.indexOf$S("CARTESIAN COORDINATES (ANG") >= 0) {
this.processAtoms$();
return true;
}if (this.line.indexOf$S("ATOMIC CHARGES") >= 0 && this.line.indexOf$S(this.chargeTag) >= 0 ) {
this.processAtomicCharges$();
return true;
}if (this.line.startsWith$S("Total Energy")) {
p$1.processEnergyLine.apply(this, []);
return true;
}if (this.line.indexOf$S("BASIS SET IN INPUT FORMAT") == 0) {
p$1.processBasis.apply(this, []);
}if (this.line.trim$().equals$O("MOLECULAR ORBITALS")) {
p$1.processMolecularOrbitals.apply(this, []);
}return true;
});

Clazz.newMeth(C$, 'processEnergyLine',  function () {
var tokens=this.getTokens$();
this.asc.setAtomSetEnergy$S$D(tokens[3], Double.parseDouble$S(tokens[3]));
}, p$1);

Clazz.newMeth(C$, 'processInputFile',  function () {
while (this.rd$() != null ){
while (this.line.trim$().length$() == 0 || this.line.startsWith$S("#") ){
this.rd$();
}
if (this.line.indexOf$S("*") >= 0) break;
var tokens=this.getTokens$();
var a=this.addAtomXYZSymName$SA$I$S$S(tokens, 1, tokens[0], null);
if (this.xyzBohr) a.scale$D(0.5291772);
}
}, p$1);

Clazz.newMeth(C$, 'processAtoms$',  function () {
++this.modelNumber;
if (!this.doGetModel$I$S(this.modelNumber, null)) return;
this.asc.newAtomSet$();
this.baseAtomIndex=this.asc.ac;
this.rd$();
while (this.rd$() != null ){
var tokens=this.getTokens$();
if (tokens.length != 4) break;
this.addAtomXYZSymName$SA$I$S$S(tokens, 1, tokens[0], null);
}
if (this.baseAtomIndex == 0) this.atomCount=this.asc.ac;
});

Clazz.newMeth(C$, 'processAtomicCharges$',  function () {
this.rd$();
for (var i=0; i < this.atomCount; i++) {
this.rd$();
this.asc.atoms[i + this.baseAtomIndex].partialCharge=Double.parseDouble$S(this.line.substring$I(this.line.indexOf$S(":") + 1));
}
});

Clazz.newMeth(C$, 'processBasis',  function () {
if (this.shells != null ) return;
this.shells=Clazz.new_($I$(1,1));
var gdata=Clazz.new_($I$(1,1));
var doSphericalF=true;
var doSphericalD=true;
this.calculationType="5D7F";
var basisLines=Clazz.new_($I$(2,1));
this.rd$();
while (this.discardLinesUntilContains2$S$S("#", "-----").indexOf$S("#") >= 0){
var element=this.line.substring$I(this.line.indexOf$S(":") + 1).trim$();
var lines=Clazz.new_($I$(1,1));
basisLines.put$O$O(element, lines);
this.rd$();
while (this.rd$().indexOf$S("end;") < 0){
if (this.line.length$() > 10) this.line=this.line.substring$I(4);
lines.addLast$O(this.getTokens$());
}
}
for (var ac=0; ac < this.atomCount; ac++) {
var lines=basisLines.get$O(this.asc.atoms[ac].elementSymbol);
for (var j=0; j < lines.size$(); ) {
var tokens=lines.get$I(j++);
++this.shellCount;
var slater=Clazz.array(Integer.TYPE, [4]);
slater[0]=ac + 1;
var oType=tokens[0];
if (doSphericalF && oType.indexOf$S("F") >= 0  || doSphericalD && oType.indexOf$S("D") >= 0  ) slater[1]=$I$(3).getQuantumShellTagIDSpherical$S(oType);
 else slater[1]=$I$(3).getQuantumShellTagID$S(oType);
var nGaussians=this.parseIntStr$S(tokens[1]);
slater[2]=this.gaussianCount + 1;
slater[3]=nGaussians;
if (this.debugging) $I$(4,"debug$S",["Slater " + this.shells.size$() + " " + $I$(5).eAI$IA(slater) ]);
this.shells.addLast$O(slater);
this.gaussianCount+=nGaussians;
for (var i=0; i < nGaussians; i++) {
tokens=lines.get$I(j++);
if (this.debugging) $I$(4,"debug$S",["Gaussians " + (i + 1) + " " + $I$(5).eAS$SA$Z(tokens, true) ]);
gdata.addLast$O(tokens);
}
}
}
this.gaussians=$I$(6).newDouble2$I(this.gaussianCount);
for (var i=0; i < this.gaussianCount; i++) {
var tokens=gdata.get$I(i);
this.gaussians[i]=Clazz.array(Double.TYPE, [tokens.length]);
for (var j=0; j < tokens.length; j++) this.gaussians[i][j]=this.parseDoubleStr$S(tokens[j]);

}
$I$(4).info$S(this.shellCount + " slater shells read");
$I$(4).info$S(this.gaussianCount + " gaussian primitives read");
}, p$1);

Clazz.newMeth(C$, 'processMolecularOrbitals',  function () {
if (this.shells == null ) return;
var mos=$I$(6).createArrayOfHashtable$I(6);
var data=$I$(6).createArrayOfArrayList$I(6);
var nThisLine=0;
this.rd$();
var labels=Clazz.new_($I$(1,1));
while (this.rd$() != null  && this.line.indexOf$S("----") < 0 ){
if (this.line.length$() == 0) continue;
var tokens;
if (this.line.startsWith$S("          ")) {
p$1.addMODataOR$I$javajs_util_Lst$javajs_util_LstA$java_util_MapA.apply(this, [nThisLine, labels, data, mos]);
labels.clear$();
this.rd$();
tokens=this.getTokens$();
nThisLine=tokens.length;
for (var i=0; i < nThisLine; i++) {
mos[i]=Clazz.new_($I$(2,1));
data[i]=Clazz.new_($I$(1,1));
mos[i].put$O$O("energy", Double.valueOf$S(tokens[i]));
}
this.rd$();
tokens=this.getTokens$();
for (var i=0; i < nThisLine; i++) {
mos[i].put$O$O("occupancy", Double.valueOf$S(tokens[i]));
}
this.rd$();
continue;
}try {
tokens=this.getTokens$();
var type=tokens[tokens.length - nThisLine - 1 ].substring$I(1).toUpperCase$();
labels.addLast$O(type);
if ($I$(7,"isDigit$C",[type.charAt$I(0)])) type=type.substring$I(1);
if (!$I$(8,"isQuantumBasisSupported$C",[type.charAt$I(0)]) && "XYZ".indexOf$I(type.charAt$I(0)) >= 0 ) type=(type.length$() == 2 ? "D" : "F") + type;
if (!$I$(8,"isQuantumBasisSupported$C",[type.charAt$I(0)])) continue;
tokens=$I$(9,"getStrings$S$I$I",[this.line.substring$I(this.line.length$() - 10 * nThisLine), nThisLine, 10]);
for (var i=0; i < nThisLine; i++) data[i].addLast$O(tokens[i]);

} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
$I$(4).error$S("Error reading Gaussian file Molecular Orbitals at line: " + this.line);
break;
} else {
throw e;
}
}
}
p$1.addMODataOR$I$javajs_util_Lst$javajs_util_LstA$java_util_MapA.apply(this, [nThisLine, labels, data, mos]);
this.setMOData$Z(this.moModelSet != this.asc.atomSetCount);
this.moModelSet=this.asc.atomSetCount;
}, p$1);

Clazz.newMeth(C$, 'addMODataOR$I$javajs_util_Lst$javajs_util_LstA$java_util_MapA',  function (nThisLine, labels, data, mos) {
if (labels.size$() == 0) return;
for (var i=0; i < labels.size$(); i++) {
if (labels.get$I(i).equals$O("PZ")) {
for (var j=0; j < nThisLine; j++) {
var d=data[j];
var s=d.removeItemAt$I(i);
d.add$I$O(i + 2, s);
}
}}
this.addMOData$I$javajs_util_LstA$java_util_MapA(nThisLine, data, mos);
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:32 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
