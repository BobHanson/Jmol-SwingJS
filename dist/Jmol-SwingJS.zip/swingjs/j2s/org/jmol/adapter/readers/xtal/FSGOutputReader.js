(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.xtal"),p$1={},I$=[[0,'javajs.util.P3d','javajs.util.PT','org.jmol.api.JmolAdapter','javajs.util.SB','org.jmol.symmetry.SymmetryOperation','org.jmol.util.Logger','javajs.util.M3d','javajs.util.M4d','org.jmol.adapter.smarter.Atom','org.jmol.util.Vibration','org.jmol.util.BSUtil','java.util.Hashtable','javajs.util.Lst']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FSGOutputReader", null, 'org.jmol.adapter.smarter.AtomSetCollectionReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.convertToABC=true;
this.p2=Clazz.new_($I$(1,1));
this.p1=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['Z',['spinOnly','convertToABC','isCoplanar','isCollinear'],'I',['firstTranslation'],'S',['configuration','spinFrame','fullName'],'O',['elementNumbers','short[]','json','java.util.Map','p2','javajs.util.P3d','+p1']]]

Clazz.newMeth(C$, 'initializeReader$',  function () {
C$.superclazz.prototype.initializeReader$.apply(this, []);
this.convertToABC=false;
this.spinOnly=this.checkFilterKey$S("SPINONLY");
this.checkNearAtoms=!this.checkFilterKey$S("NOSPECIAL");
if (!this.filteredPrecision) {
this.precision=5;
this.filteredPrecision=true;
}System.out.println$S("FSGOutput using precision " + this.precision);
var symbols=this.getFilterWithCase$S("elements=");
if (symbols != null ) {
var s=$I$(2,"split$S$S",[symbols.replace$C$C(",", " "), " "]);
this.elementNumbers=Clazz.array(Short.TYPE, [s.length]);
for (var i=s.length; --i >= 0; ) {
this.elementNumbers[i]=($I$(3).getElementNumber$S(s[i])|0);
}
}var sb=Clazz.new_($I$(4,1));
try {
while (this.rd$() != null )sb.append$S(this.line);

this.json=this.vwr.parseJSONMap$S(sb.toString());
p$1.processJSON.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
this.continuing=false;
});

Clazz.newMeth(C$, 'processJSON',  function () {
p$1.getHeaderInfo.apply(this, []);
var info=C$.getList$java_util_Map$S(this.json, "G0_std_Cell");
p$1.getCellInfo$javajs_util_Lst.apply(this, [p$1.getListItem$javajs_util_Lst$I.apply(this, [info, 0])]);
this.configuration=this.json.get$O("Configuration");
this.isCoplanar="Coplanar".equals$O(this.configuration);
this.isCollinear="Collinear".equals$O(this.configuration);
this.addMoreUnitCellInfo$S("configuration=" + this.configuration);
p$1.readAllOperators$javajs_util_Lst.apply(this, [C$.getList$java_util_Map$S(this.json, "G0_std_operations")]);
var symbols=p$1.getSymbols$java_util_Map.apply(this, [this.json.get$O("AtomTypeDict")]);
p$1.readAtomsAndMoments$javajs_util_Lst$SA.apply(this, [info, symbols]);
}, p$1);

Clazz.newMeth(C$, 'getSymbols$java_util_Map',  function (map) {
if (map == null ) {
return null;
}var symbols=Clazz.array(String, [map.size$() + 1]);
for (var e, $e = map.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) {
symbols[Integer.parseInt$S(e.getKey$())]=e.getValue$();
}
return symbols;
}, p$1);

Clazz.newMeth(C$, 'getListItem$javajs_util_Lst$I',  function (info, i) {
return info.get$I(i);
}, p$1);

Clazz.newMeth(C$, 'getList$java_util_Map$S',  function (json, key) {
return json.get$O(key);
}, 1);

Clazz.newMeth(C$, 'getHeaderInfo',  function () {
this.fullName=this.json.get$O("SSG_international_symbol");
this.setSpaceGroupName$S(p$1.fixName$S.apply(this, [this.fullName]));
}, p$1);

Clazz.newMeth(C$, 'fixName$S',  function (name) {
System.out.println$S("FSGOutput " + name);
var pt;
while ((pt=name.indexOf$S("\\frac{")) >= 0){
var pt2=name.indexOf$S$I("{", pt + 7);
var pt3=name.indexOf$S$I("}", pt2 + 1);
name=name.substring$I$I(0, pt) + "(" + name.substring$I$I(pt + 5, pt2) + "/" + name.substring$I$I(pt2, pt3) + ")" + name.substring$I(pt3) ;
}
name=$I$(2).rep$S$S$S(name, "\\pi", "\u03c0");
name=$I$(2).rep$S$S$S(name, "\\enspace", " ");
name=$I$(2).rep$S$S$S(name, "\\infty", "\u221e");
name=$I$(2).rep$S$S$S(name, "\\\\^", "^");
name=$I$(2).replaceAllCharacters$S$S$S(name, "{}", "");
return name;
}, p$1);

Clazz.newMeth(C$, 'getCellInfo$javajs_util_Lst',  function (list) {
this.setFractionalCoordinates$Z(true);
for (var i=0; i < 3; i++) {
var v=C$.getPoint$javajs_util_Lst(p$1.getListItem$javajs_util_Lst$I.apply(this, [list, i]));
this.addExplicitLatticeVector$I$DA$I(i, Clazz.array(Double.TYPE, -1, [v.x, v.y, v.z]), 0);
}
}, p$1);

Clazz.newMeth(C$, 'getPoint$javajs_util_Lst',  function (item) {
return $I$(1,"new3$D$D$D",[C$.getValue$javajs_util_Lst$I(item, 0), C$.getValue$javajs_util_Lst$I(item, 1), C$.getValue$javajs_util_Lst$I(item, 2)]);
}, 1);

Clazz.newMeth(C$, 'getValue$javajs_util_Lst$I',  function (item, i) {
return (item.get$I(i)).doubleValue$();
}, 1);

Clazz.newMeth(C$, 'readAllOperators$javajs_util_Lst',  function (info) {
var n=info.size$();
var nops=0;
for (var i=0; i < n; i++) {
var op=info.get$I(i);
var mspin=p$1.readMatrix$javajs_util_Lst$javajs_util_Lst.apply(this, [p$1.getListItem$javajs_util_Lst$I.apply(this, [op, 0]), null]);
var mop=p$1.readMatrix$javajs_util_Lst$javajs_util_Lst.apply(this, [p$1.getListItem$javajs_util_Lst$I.apply(this, [op, 1]), p$1.getListItem$javajs_util_Lst$I.apply(this, [op, 2])]);
var s=$I$(5).getTransformXYZ$javajs_util_M4d(mop) + $I$(5).getSpinString$javajs_util_M34d$Z$Z(mspin, true, true) + (this.isCoplanar ? "+" : "") ;
var iop=this.setSymmetryOperator$S(s);
if ($I$(6).debugging) System.out.println$S("FSGOutput op[" + (i + 1) + "]=" + s + (iop < 0 ? " SKIPPED" : "") );
if (iop >= 0) {
var isTranslation=$I$(5).isTranslation$javajs_util_M4d(mop);
if (this.firstTranslation == 0 && isTranslation ) this.firstTranslation=nops;
++nops;
}}
if (this.firstTranslation == 0) this.firstTranslation=nops;
System.out.println$S("FSGOutput G0_operationCount(initial)=" + n);
}, p$1);

Clazz.newMeth(C$, 'readMatrix$javajs_util_Lst$javajs_util_Lst',  function (rot, trans) {
if (rot == null ) return null;
var r=Clazz.new_($I$(7,1));
for (var i=0; i < 3; i++) {
r.setRowV$I$javajs_util_T3d(i, C$.getPoint$javajs_util_Lst(p$1.getListItem$javajs_util_Lst$I.apply(this, [rot, i])));
}
var t=(trans == null  ? Clazz.new_($I$(1,1)) : C$.getPoint$javajs_util_Lst(trans));
return $I$(8).newMV$javajs_util_M3d$javajs_util_T3d(r, t);
}, p$1);

Clazz.newMeth(C$, 'readAtomsAndMoments$javajs_util_Lst$SA',  function (info, symbols) {
var atoms=p$1.getListItem$javajs_util_Lst$I.apply(this, [info, 1]);
var ids=p$1.getListItem$javajs_util_Lst$I.apply(this, [info, 2]);
var moments=p$1.getListItem$javajs_util_Lst$I.apply(this, [info, 3]);
for (var i=0, n=atoms.size$(); i < n; i++) {
var xyz=C$.getPoint$javajs_util_Lst(p$1.getListItem$javajs_util_Lst$I.apply(this, [atoms, i]));
var id=(C$.getValue$javajs_util_Lst$I(ids, i)|0);
var a=Clazz.new_($I$(9,1));
a.setT$javajs_util_T3d(xyz);
this.setAtomCoord$org_jmol_adapter_smarter_Atom(a);
var moment=C$.getPoint$javajs_util_Lst(p$1.getListItem$javajs_util_Lst$I.apply(this, [moments, i]));
var mag=moment.length$();
if (mag > 0 ) {
if ($I$(6).debugging) System.out.println$S("FGSOutput moment " + i + " " + moment + " " + new Double(mag).toString() );
var v=Clazz.new_($I$(10,1));
v.setType$I(-2);
v.setT$javajs_util_T3d(moment);
v.magMoment=mag;
a.vib=v;
System.out.println$S("FSGOutput atom/spin " + i + " " + a.vib + " " + new Double(mag).toString() );
} else {
if (this.spinOnly) continue;
}if (symbols != null ) {
a.elementSymbol=symbols[id];
} else if (this.elementNumbers != null  && id <= this.elementNumbers.length ) {
a.elementNumber=this.elementNumbers[id - 1];
} else {
a.elementNumber=($s$[0] = (id + 2), $s$[0]);
}this.asc.addAtom$org_jmol_adapter_smarter_Atom(a);
}
}, p$1);

Clazz.newMeth(C$, 'warnSkippingOperation$S',  function (xyz) {
});

Clazz.newMeth(C$, 'doPreSymmetry$Z',  function (doApplySymmetry) {
var fs=this.asc.getSymmetry$();
var bs=$I$(11).newBitSet2$I$I(0, this.asc.ac);
var i=0;
this.symmetry.setPrecision$D(1.0E-4);
while ((i=p$1.excludeAtoms$I$javajs_util_BS$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry.apply(this, [i, bs, fs])) >= 0){
}
for (var n=0, j=bs.nextSetBit$I(0); j >= 0; j=bs.nextSetBit$I(j + 1)) {
this.asc.atoms[j].atomSite=n++;
}
p$1.filterFsgAtoms$javajs_util_BS.apply(this, [bs]);
p$1.preSymmetrySetMoments.apply(this, []);
System.out.println$S("FSGOutputReader using atoms " + bs);
var lst=fs.setSpinList$S(this.configuration);
if (lst != null ) {
this.asc.setCurrentModelInfo$S$O("spinList", lst);
this.appendLoadNote$S(lst.size$() + " spin operations -- see _M.spinList and atom.spin");
}System.out.println$S("FSGOutput operationCount=" + fs.getSpaceGroupOperationCount$());
var info=p$1.getSCIFInfo$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry$javajs_util_Lst.apply(this, [fs, lst]);
this.asc.setCurrentModelInfo$S$O("scifInfo", info);
this.asc.setCurrentModelInfo$S$O("spinFrame", this.spinFrame);
});

Clazz.newMeth(C$, 'preSymmetrySetMoments',  function () {
var a=this.symmetry.getUnitCellInfoType$I(0);
var b=this.symmetry.getUnitCellInfoType$I(1);
var c=this.symmetry.getUnitCellInfoType$I(2);
for (var i=this.asc.ac; --i >= 0; ) {
var v=this.asc.atoms[i].vib;
if (v != null ) p$1.spinCartesianToFractional$org_jmol_util_Vibration$D$D$D.apply(this, [v, a, b, c]);
}
}, p$1);

Clazz.newMeth(C$, 'spinCartesianToFractional$org_jmol_util_Vibration$D$D$D',  function (v, a, b, c) {
var p=$I$(1).newP$javajs_util_T3d(v);
this.symmetry.toFractional$javajs_util_T3d$Z(v, true);
v.x*=a;
v.y*=b;
v.z*=c;
v.setV0$();
v.setT$javajs_util_T3d(p);
}, p$1);

Clazz.newMeth(C$, 'filterFsgAtoms$javajs_util_BS',  function (bs) {
for (var p=0, i=bs.nextSetBit$I(0); i >= 0; p++, i=bs.nextSetBit$I(i + 1)) {
this.asc.atoms[p]=this.asc.atoms[i];
this.asc.atoms[p].index=p;
}
this.asc.atomSetAtomCounts[0]=this.asc.ac=bs.cardinality$();
}, p$1);

Clazz.newMeth(C$, 'finalizeSubclassReader$',  function () {
this.asc.setNoAutoBond$();
this.applySymmetryAndSetTrajectory$();
this.addJmolScript$S("vectors on;vectors 0.15;");
this.vibsFractional=true;
var n=this.asc.getXSymmetry$().setMagneticMoments$Z(true);
this.asc.getXSymmetry$().getSymmetry$().setPrecision$D(1.0E-4);
this.appendLoadNote$S(n + " magnetic moments - use VECTORS ON/OFF or VECTOR MAX x.x or SELECT VXYZ>0");
});

Clazz.newMeth(C$, 'getSCIFInfo$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry$javajs_util_Lst',  function (fs, spinList) {
var m=Clazz.new_($I$(12,1));
try {
System.out.println$S("FSGOutput SSG_international_symbol=" + this.fullName);
C$.mput$java_util_Map$S$O(m, "SSG_international_symbol", this.fullName);
System.out.println$S("FSGOutput simpleName=" + this.sgName);
C$.mput$java_util_Map$S$O(m, "simpleName", this.sgName);
var msgNum=this.json.get$O("MSG_num");
System.out.println$S("FSGOutput MSG_num=" + msgNum);
C$.mput$java_util_Map$S$O(m, "MSG_num", msgNum);
System.out.println$S("FSGOutput Configuration=" + this.configuration);
C$.mput$java_util_Map$S$O(m, "configuration", this.configuration);
var gSymbol=this.json.get$O("G_symbol");
System.out.println$S("FSGOutput G_symbol=" + gSymbol);
C$.mput$java_util_Map$S$O(m, "G_Symbol", gSymbol);
var g0Symbol=this.json.get$O("G0_symbol");
System.out.println$S("FSGOutput G0=" + g0Symbol);
C$.mput$java_util_Map$S$O(m, "G0_Symbol", g0Symbol);
var pt=g0Symbol.indexOf$I("(");
var g0ItaNo=Integer.parseInt$S(g0Symbol.substring$I$I(pt + 1, g0Symbol.length$() - 1));
var g0HMName=g0Symbol.substring$I$I(0, pt).trim$();
C$.mput$java_util_Map$S$O(m, "G0_ItaNo", Integer.valueOf$I(g0ItaNo));
C$.mput$java_util_Map$S$O(m, "G0_HMName", g0HMName);
var l0Symbol=this.json.get$O("L0_symbol");
System.out.println$S("FSGOutput L0=" + l0Symbol);
C$.mput$java_util_Map$S$O(m, "L0_Symbol", l0Symbol);
pt=l0Symbol.indexOf$I("(");
var l0ItaNo=Integer.parseInt$S(l0Symbol.substring$I$I(pt + 1, l0Symbol.length$() - 1));
var ik=(this.json.get$O("ik")).intValue$();
var fsgID="" + l0ItaNo + "." + g0ItaNo + "." + ik + ".?" ;
this.appendLoadNote$S("FSG ID " + fsgID);
C$.mput$java_util_Map$S$O(m, "fsgID", fsgID);
System.out.println$S("fsgID=" + fsgID);
var isPrimitive=g0HMName.charAt$I(0) == "P";
C$.mput$java_util_Map$S$O(m, "G0_isPrimitive", Boolean.valueOf$Z(isPrimitive));
C$.mput$java_util_Map$S$O(m, "G0_atomCount", Integer.valueOf$I(this.asc.ac));
System.out.println$S("FSGOutput G0_atomCount=" + this.asc.ac);
var r0=C$.getList$java_util_Map$S(this.json, "transformation_matrix_ini_G0");
var t0=C$.getList$java_util_Map$S(this.json, "origin_shift_ini_G0");
var m2g0=p$1.readMatrix$javajs_util_Lst$javajs_util_Lst.apply(this, [r0, t0]);
var abcm=$I$(5).getTransformABC$javajs_util_M34d$Z(m2g0, false);
C$.mput$java_util_Map$S$O(m, "msgTransform", abcm);
this.asc.setCurrentModelInfo$S$O("unitcell_msg", abcm);
this.symmetry.setUnitCellFromParams$DA$Z$D(this.unitCellParams, true, 1.0E-4);
this.spinFrame=p$1.calculateSpinFrame$javajs_util_M4d.apply(this, [p$1.readMatrix$javajs_util_Lst$javajs_util_Lst.apply(this, [C$.getList$java_util_Map$S(this.json, "transformation_matrix_spin_cartesian_lattice_G0"), null])]);
System.out.println$S("FSGOutput G0 spinFrame=" + this.spinFrame);
this.addMoreUnitCellInfo$S("spinFrame=" + this.spinFrame);
this.asc.setCurrentModelInfo$S$O("unitcell_spin", this.spinFrame);
var spinLattice=fs.getLatticeCentering$();
var lattice=$I$(5,"getLatticeCenteringStrings$org_jmol_symmetry_SymmetryOperationA",[fs.getSymmetryOperations$()]);
if (!lattice.isEmpty$()) {
lattice.add$I$O(0, "x,y,z(u,v,w)");
C$.mput$java_util_Map$S$O(m, "G0_spinLattice", lattice);
}var abc=C$.calculateChildTransform$javajs_util_Lst(spinLattice);
C$.mput$java_util_Map$S$O(m, "childTransform", abc);
System.out.println$S("FSGOutput G0_childTransform=" + abc);
var ops=Clazz.new_($I$(13,1));
var symops=fs.getSymmetryOperations$();
for (var i=0; i < this.firstTranslation; i++) {
ops.addLast$O(symops[i].getXyz$Z(false));
}
if (spinList != null ) {
C$.mput$java_util_Map$S$O(m, "G0_spinList", spinList);
var mapSpinToID=Clazz.new_($I$(12,1));
var scifList=null;
var scifListTimeRev=Clazz.array(Integer.TYPE, [spinList.size$()]);
var newSpinFrame=(this.convertToABC ? "a,b,c" : this.spinFrame);
scifList=Clazz.new_($I$(13,1));
var msf=null;
var msfInv=null;
if (!this.spinFrame.equals$O(newSpinFrame)) {
msf=$I$(5).staticConvertOperation$S$javajs_util_M34d$S(this.spinFrame, null, null);
msf.transpose$();
msfInv=$I$(8).newM4$javajs_util_M4d(msf);
msfInv.invert$();
}for (var i=0, n=spinList.size$(); i < n; i++) {
var fsgOp=spinList.get$I(i);
mapSpinToID.put$O$O(fsgOp, Integer.valueOf$I(i));
var m4=this.symmetry.convertTransform$S$javajs_util_M4d(fsgOp, null);
if (msf != null ) {
m4.mul2$javajs_util_M4d$javajs_util_M4d(m4, msfInv);
m4.mul2$javajs_util_M4d$javajs_util_M4d(msf, m4);
}var s=$I$(5).getTransformUVW$javajs_util_M4d(m4);
System.out.println$S(s + "\t <- " + fsgOp );
scifList.addLast$O(s);
var timeReversal=Long.$ival(Math.round$D(m4.determinant3$()));
scifListTimeRev[i]=timeReversal;
}
C$.mput$java_util_Map$S$O(m, "spinFrame", newSpinFrame);
C$.mput$java_util_Map$S$O(m, "SCIF_spinList", scifList);
C$.mput$java_util_Map$S$O(m, "SCIF_spinListTR", scifListTimeRev);
ops=p$1.setSCIFSpinLists$java_util_Map$java_util_Map$javajs_util_Lst$I$S.apply(this, [m, mapSpinToID, ops, this.firstTranslation, "G0_operationURefs"]);
p$1.setSCIFSpinLists$java_util_Map$java_util_Map$javajs_util_Lst$I$S.apply(this, [m, mapSpinToID, lattice, lattice.size$(), "G0_spinLatticeURefs"]);
}C$.mput$java_util_Map$S$O(m, "G0_operations", ops);
C$.mput$java_util_Map$S$O(m, "G0_operationCount", Integer.valueOf$I(ops.size$()));
System.out.println$S("FSGOutput G0_operationCount(w/o translations)=" + ops.size$());
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
C$.mput$java_util_Map$S$O(m, "exception", e.toString());
e.printStackTrace$();
} else {
throw e;
}
}
return m;
}, p$1);

Clazz.newMeth(C$, 'excludeAtoms$I$javajs_util_BS$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry',  function (i0, bs, fs) {
for (var i=bs.nextSetBit$I(i0 + 1); i >= 0; i=bs.nextSetBit$I(i + 1)) {
if (p$1.findSymop$I$I$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry.apply(this, [i0, i, fs])) {
bs.clear$I(i);
}}
return bs.nextSetBit$I(i0 + 1);
}, p$1);

Clazz.newMeth(C$, 'findSymop$I$I$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry',  function (i1, i2, fs) {
var a=this.asc.atoms[i1];
var b=this.asc.atoms[i2];
if (a.elementNumber != b.elementNumber) return false;
this.p2.setP$javajs_util_T3d(b);
this.symmetry.unitize$javajs_util_T3d(this.p2);
this.symmetry.toCartesian$javajs_util_T3d$Z(this.p2, true);
var ops=fs.getSymmetryOperations$();
var nops=fs.getSpaceGroupOperationCount$();
for (var i=1; i < nops; i++) {
this.p1.setP$javajs_util_T3d(a);
ops[i].rotTrans$javajs_util_T3d(this.p1);
this.symmetry.unitize$javajs_util_T3d(this.p1);
this.symmetry.toCartesian$javajs_util_T3d$Z(this.p1, true);
if (this.p1.distanceSquared$javajs_util_T3d(this.p2) < 0.01 ) {
return true;
}}
return false;
}, p$1);

Clazz.newMeth(C$, 'setSCIFSpinLists$java_util_Map$java_util_Map$javajs_util_Lst$I$S',  function (m, mapSpinToID, ops, len, key) {
var lst=Clazz.new_($I$(13,1));
var lstOpsIncluded=Clazz.new_($I$(13,1));
for (var i=0, n=len; i < n; i++) {
var o=ops.get$I(i);
var pt=o.indexOf$S("(");
var uvw=o.substring$I$I(pt + 1, o.indexOf$I$I(")", pt + 1));
var ipt=mapSpinToID.get$O(uvw);
lst.addLast$O(ipt);
lstOpsIncluded.addLast$O(o);
}
var val=Clazz.array(Integer.TYPE, [lst.size$()]);
for (var i=val.length; --i >= 0; ) val[i]=lst.get$I(i).intValue$();

m.put$O$O(key, val);
return lstOpsIncluded;
}, p$1);

Clazz.newMeth(C$, 'mput$java_util_Map$S$O',  function (m, key, val) {
if (val != null ) m.put$O$O(key, val);
}, 1);

Clazz.newMeth(C$, 'calculateChildTransform$javajs_util_Lst',  function (spinLattice) {
if (spinLattice == null  || spinLattice.isEmpty$() ) {
return "a,b,c";
}var minx=1;
var miny=1;
var minz=1;
for (var i=spinLattice.size$(); --i >= 0; ) {
var c=spinLattice.get$I(i);
if (c.x > 0  && c.x < minx  ) minx=c.x;
if (c.y > 0  && c.y < miny  ) miny=c.y;
if (c.z > 0  && c.z < minz  ) minz=c.z;
}
return (minx > 0  && minx < 1   ? "" + Long.$s(Math.round$D(1 / minx)) : "") + "a," + (miny > 0  && miny < 1   ? "" + Long.$s(Math.round$D(1 / miny)) : "") + "b," + (minz > 0  && minz < 1   ? "" + Long.$s(Math.round$D(1 / minz)) : "") + "c" ;
}, 1);

Clazz.newMeth(C$, 'calculateSpinFrame$javajs_util_M4d',  function (m4) {
if (m4 == null ) {
m4=Clazz.new_($I$(8,1));
var a1=$I$(1).new3$D$D$D(1, 0, 0);
var a2=$I$(1).new3$D$D$D(0, 1, 0);
var a3=$I$(1).new3$D$D$D(0, 0, 1);
this.symmetry.toFractional$javajs_util_T3d$Z(a1, true);
this.symmetry.toFractional$javajs_util_T3d$Z(a2, true);
this.symmetry.toFractional$javajs_util_T3d$Z(a3, true);
var d=a1.length$();
a1.normalize$();
a2.scale$D(1 / d);
a3.scale$D(1 / d);
m4.setColumn4$I$D$D$D$D(0, a1.x, a1.y, a1.z, 0);
m4.setColumn4$I$D$D$D$D(1, a2.x, a2.y, a2.z, 0);
m4.setColumn4$I$D$D$D$D(2, a3.x, a3.y, a3.z, 0);
} else {
m4.invert$();
}return $I$(5).getTransformABC$javajs_util_M34d$Z(m4, false);
}, p$1);
var $s$ = new Int16Array(1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:41 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
