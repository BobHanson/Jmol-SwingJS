(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.xtal"),p$1={},I$=[[0,'javajs.util.PT']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "EspressoReader", null, 'org.jmol.adapter.smarter.AtomSetCollectionReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['endFlag'],'D',['alat'],'O',['cellParams','double[]','totEnergy','Double']]]

Clazz.newMeth(C$, 'initializeReader$',  function () {
this.setSpaceGroupName$S("P1");
this.doApplySymmetry=true;
});

Clazz.newMeth(C$, 'checkLine$',  function () {
if (this.line.contains$CharSequence("lattice parameter (a_0)") || this.line.contains$CharSequence("lattice parameter (alat)") ) {
p$1.readAparam.apply(this, []);
} else if (this.line.contains$CharSequence("crystal axes:")) {
p$1.readCellParam$Z.apply(this, [false]);
} else if (this.line.contains$CharSequence("CELL_PARAMETERS (")) {
p$1.readCellParam$Z.apply(this, [true]);
} else if (this.line.contains$CharSequence("Cartesian axes")) {
this.discardLinesUntilContains$S("positions (");
if (this.doGetModel$I$S(++this.modelNumber, null)) p$1.readAtoms.apply(this, []);
} else if (this.line.contains$CharSequence("POSITIONS (")) {
if (this.doGetModel$I$S(++this.modelNumber, null)) p$1.readAtoms.apply(this, []);
} else if (this.line.contains$CharSequence("!    total energy")) {
p$1.readEnergy.apply(this, []);
} else if (this.line.contains$CharSequence("A final scf")) {
this.endFlag=true;
}return true;
});

Clazz.newMeth(C$, 'readAparam',  function () {
this.alat=this.parseDoubleStr$S(this.getTokens$()[4]) * 0.5291772;
}, p$1);

Clazz.newMeth(C$, 'readCellParam$Z',  function (andAlat) {
var i0=(andAlat ? 0 : 3);
if (this.line.contains$CharSequence("bohr")) this.alat=0.5291772;
 else if (this.line.contains$CharSequence("angstrom")) this.alat=1;
if (andAlat && this.line.contains$CharSequence("=") ) this.alat=this.parseDoubleStr$S(this.line.substring$I(this.line.indexOf$S("=") + 1)) * 0.5291772;
this.cellParams=Clazz.array(Double.TYPE, [9]);
for (var n=0, i=0; n < 3; n++) {
var tokens=$I$(1,"getTokens$S",[this.rd$()]);
this.cellParams[i++]=this.parseDoubleStr$S(tokens[i0]) * this.alat;
this.cellParams[i++]=this.parseDoubleStr$S(tokens[i0 + 1]) * this.alat;
this.cellParams[i++]=this.parseDoubleStr$S(tokens[i0 + 2]) * this.alat;
}
}, p$1);

Clazz.newMeth(C$, 'newAtomSet',  function () {
this.asc.newAtomSet$();
if (this.totEnergy != null ) p$1.setEnergy.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'setCellParams',  function () {
if (this.cellParams != null ) {
this.addExplicitLatticeVector$I$DA$I(0, this.cellParams, 0);
this.addExplicitLatticeVector$I$DA$I(1, this.cellParams, 3);
this.addExplicitLatticeVector$I$DA$I(2, this.cellParams, 6);
this.setSpaceGroupName$S("P1");
}}, p$1);

Clazz.newMeth(C$, 'readAtoms',  function () {
p$1.newAtomSet.apply(this, []);
var isAlat=(this.line.contains$CharSequence("alat") || this.line.contains$CharSequence("a_0") );
var firstStr=(this.line.contains$CharSequence("site n."));
var isFractional=this.line.contains$CharSequence("crystal");
var isBohr=this.line.contains$CharSequence("bohr");
var isAngstrom=this.line.contains$CharSequence("angstrom");
if (isAlat || isFractional || isAngstrom  ) p$1.setCellParams.apply(this, []);
this.setFractionalCoordinates$Z(isFractional);
while (this.rd$() != null  && this.line.length$() > 45 ){
var tokens=this.getTokens$();
var atom=this.asc.addNewAtom$();
atom.atomName=tokens[(isBohr || tokens.length == 4  || !firstStr  ? 0 : 1)];
var i1=(isBohr || tokens.length == 4  || !firstStr  ? 1 : tokens.length - 4);
var x=this.parseDoubleStr$S(tokens[i1++]);
var y=this.parseDoubleStr$S(tokens[i1++]);
var z=this.parseDoubleStr$S(tokens[i1++]);
atom.set$D$D$D(x, y, z);
if (isBohr) {
atom.scale$D(0.5291772);
} else if (isAlat) {
atom.scale$D(this.alat);
}this.setAtomCoord$org_jmol_adapter_smarter_Atom(atom);
}
this.applySymmetryAndSetTrajectory$();
if (this.endFlag) this.discardLinesUntilContains$S("Harris-Foulkes estimate");
}, p$1);

Clazz.newMeth(C$, 'readEnergy',  function () {
this.totEnergy=Double.valueOf$D(Double.parseDouble$S($I$(1,"getTokens$S",[this.line.substring$I(this.line.indexOf$S("=") + 1)])[0]));
}, p$1);

Clazz.newMeth(C$, 'setEnergy',  function () {
this.asc.setAtomSetEnergy$S$D("" + this.totEnergy.toString(), this.totEnergy.doubleValue$());
this.asc.setInfo$S$O("Energy", this.totEnergy);
this.asc.setAtomSetName$S("E = " + this.totEnergy.toString() + " Ry" );
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:40 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
