(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.xml"),p$1={},p$2={},p$3={},I$=[[0,'java.util.BitSet','java.util.ArrayList',['org.jmol.adapter.readers.xml.CDXMLReader','.CDBond'],'org.jmol.adapter.readers.xml.CDXMLReader',['org.jmol.adapter.readers.xml.CDXMLReader','.CDNode'],'java.util.HashMap','java.util.Stack','org.jmol.adapter.smarter.AtomSetCollectionReader','org.jmol.util.Logger',['org.jmol.adapter.readers.xml.CDXMLReader','.BracketedGroup'],'org.jmol.util.Edge']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CDXMLReader", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.jmol.adapter.readers.xml.XmlReader');
C$.$classes$=[['CDNode',0],['CDBond',0],['BracketedGroup',0]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.minX=1.7976931348623157E308;
this.minY=1.7976931348623157E308;
this.minZ=1.7976931348623157E308;
this.maxZ=-1.7976931348623157E308;
this.maxY=-1.7976931348623157E308;
this.maxX=-1.7976931348623157E308;
this.idnext=100000;
this.bsAtoms=Clazz.new_($I$(1,1));
this.bsBonds=Clazz.new_($I$(1,1));
this.atoms=Clazz.new_($I$(2,1));
this.bonds=Clazz.new_($I$(2,1));
this.bondIDMap=Clazz.new_($I$(6,1));
this.fragments=Clazz.new_($I$(7,1));
this.nodes=Clazz.new_($I$(7,1));
this.nostereo=Clazz.new_($I$(2,1));
this.objectsByID=Clazz.new_($I$(6,1));
},1);

C$.$fields$=[['Z',['no3D','isCDX'],'D',['minX','minY','minZ','maxZ','maxY','maxX'],'I',['idnext'],'S',['thisFragmentID','textBuffer'],'O',['bsAtoms','java.util.BitSet','+bsBonds','atoms','java.util.List','+bonds','bondIDMap','java.util.Map','bracketedGroups','java.util.Stack','+fragments','thisNode','org.jmol.adapter.readers.xml.CDXMLReader.CDNode','nodes','java.util.Stack','nostereo','java.util.List','objectsByID','java.util.Map']]]

Clazz.newMeth(C$, 'processXml$org_jmol_adapter_readers_xml_XmlReader$O',  function (parent, saxReader) {
this.is2D=true;
if (parent == null ) {
this.processXml2$org_jmol_adapter_readers_xml_XmlReader$O(this, saxReader);
parent=this;
} else {
this.no3D=parent.checkFilterKey$S("NO3D");
this.noHydrogens=parent.noHydrogens;
this.processXml2$org_jmol_adapter_readers_xml_XmlReader$O(parent, saxReader);
this.filter=parent.filter;
}});

Clazz.newMeth(C$, 'processStartElement$S$S',  function (localName, nodeName) {
var id=this.atts.get$O("id");
switch (localName) {
case "n":
this.objectsByID.put$O$O(id, p$3.setNode$S.apply(this, [id]));
break;
case "b":
this.objectsByID.put$O$O(id, p$3.setBond$S.apply(this, [id]));
break;
case "t":
this.textBuffer="";
break;
case "s":
this.setKeepChars$Z(true);
break;
case "fragment":
this.objectsByID.put$O$O(id, p$3.setFragment$S.apply(this, [id]));
break;
case "bracketedgroup":
p$3.setBracketedGroup$S$java_util_Map.apply(this, [id, this.atts]);
break;
case "crossingbond":
var bg=(this.bracketedGroups == null  || this.bracketedGroups.isEmpty$()  ? null : this.bracketedGroups.get$I(this.bracketedGroups.size$() - 1));
if (bg != null  && bg.repeatCount > 0 ) {
bg.addCrossing$S$S(this.atts.get$O("inneratomid"), this.atts.get$O("bondid"));
}break;
}
});

Clazz.newMeth(C$, 'nextID$',  function () {
return "" + (this.idnext++);
});

Clazz.newMeth(C$, 'getBondKey$I$I',  function (atomIndex1, atomIndex2) {
return Math.min(atomIndex1, atomIndex2) + "_" + Math.max(atomIndex1, atomIndex2) ;
}, 1);

Clazz.newMeth(C$, 'getBond$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode',  function (a, b) {
return this.bondIDMap.get$O(C$.getBondKey$I$I(a.index, b.index));
});

Clazz.newMeth(C$, 'processEndElement$S',  function (localName) {
switch (localName) {
case "fragment":
this.thisFragmentID=this.fragments.pop$();
return;
case "n":
this.thisNode=(this.nodes.size$() == 0 ? null : this.nodes.pop$());
return;
case "bracketedgroup":
break;
case "s":
this.textBuffer+=this.chars.toString();
break;
case "t":
if (this.thisNode == null ) {
System.out.println$S("CDXReader unassigned text: " + this.textBuffer);
} else {
this.thisNode.text=this.textBuffer;
if (this.thisAtom.elementNumber == 0) {
System.err.println$S("XmlChemDrawReader: Problem with \"" + this.textBuffer + "\"" );
}if (this.thisNode.warning != null ) this.parent.appendLoadNote$S("Warning: " + this.textBuffer + " " + this.thisNode.warning );
}this.textBuffer="";
break;
}
this.setKeepChars$Z(false);
});

Clazz.newMeth(C$, 'getTokens$S',  function (s) {
return s.split$S("\\s");
}, p$3);

Clazz.newMeth(C$, 'split$S$S',  function (s, p) {
return s.split$S(p);
}, p$3);

Clazz.newMeth(C$, 'parseInt$S',  function (s) {
try {
return Integer.parseInt$S(s);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return -2147483648;
} else {
throw e;
}
}
}, p$3);

Clazz.newMeth(C$, 'parseDouble$S',  function (s) {
try {
return Double.parseDouble$S(s);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return NaN;
} else {
throw e;
}
}
}, p$3);

Clazz.newMeth(C$, 'setNode$S',  function (id) {
var nodeType=this.atts.get$O("nodetype");
if (this.thisNode != null ) this.nodes.push$O(this.thisNode);
if ("_".equals$O(nodeType)) {
this.thisAtom=this.thisNode=null;
return null;
}this.thisAtom=this.thisNode=Clazz.new_($I$(5,1).c$$S$S$S$org_jmol_adapter_readers_xml_CDXMLReader_CDNode,[this, null, id, nodeType, this.thisFragmentID, this.thisNode]);
this.addAtom$org_jmol_adapter_readers_xml_CDXMLReader_CDNode(this.thisNode);
var w=this.atts.get$O("warning");
if (w != null ) {
this.thisNode.warning=w.replace$CharSequence$CharSequence("&apos;", "\'");
this.thisNode.isValid=(w.indexOf$S("ChemDraw can\'t interpret") < 0);
}var element=this.atts.get$O("element");
var s=this.atts.get$O("genericnickname");
if (s != null ) {
element=s;
}this.thisAtom.elementNumber=($s$[0] = Math.max(0, (!p$3.checkWarningOK$S.apply(this, [w]) ? 0 : element == null  ? 6 : p$3.parseInt$S.apply(this, [element]))), $s$[0]);
element=$I$(8).getElementSymbol$I(this.thisAtom.elementNumber);
s=this.atts.get$O("isotope");
if (s != null ) element=s + element;
this.setElementAndIsotope$org_jmol_adapter_smarter_Atom$S(this.thisAtom, element);
s=this.atts.get$O("charge");
if (s != null ) {
this.thisAtom.formalCharge=p$3.parseInt$S.apply(this, [s]);
}p$3.handleCoordinates$java_util_Map.apply(this, [this.atts]);
s=this.atts.get$O("attachments");
if (s != null ) {
this.thisNode.setMultipleAttachments$SA(p$3.split$S$S.apply(this, [s.trim$(), " "]));
}s=this.atts.get$O("bondordering");
if (s != null ) {
this.thisNode.setBondOrdering$SA(p$3.split$S$S.apply(this, [s.trim$(), " "]));
}if ($I$(9).debugging) $I$(9,"info$S",["XmlChemDraw id=" + id + " " + element + " " + this.thisAtom ]);
return this.thisNode;
}, p$3);

Clazz.newMeth(C$, 'checkWarningOK$S',  function (warning) {
return (warning == null  || warning.indexOf$S("valence") >= 0  || warning.indexOf$S("very close") >= 0  || warning.indexOf$S("two identical colinear bonds") >= 0 );
}, p$3);

Clazz.newMeth(C$, 'setFragment$S',  function (id) {
this.fragments.push$O(this.thisFragmentID=id);
var fragmentNode=(this.thisNode == null  || !this.thisNode.isFragment  ? null : this.thisNode);
if (fragmentNode != null ) {
fragmentNode.setInnerFragmentID$S(id);
}var s=this.atts.get$O("connectionorder");
if (s != null ) {
this.thisNode.setConnectionOrder$SA(s.trim$().split$S(" "));
}return fragmentNode;
}, p$3);

Clazz.newMeth(C$, 'setBond$S',  function (id) {
var atom1=this.atts.get$O("b");
var atom2=this.atts.get$O("e");
var a=this.atts.get$O("beginattach");
var beginAttach=(a == null  ? 0 : p$3.parseInt$S.apply(this, [a]));
a=this.atts.get$O("endattach");
var endAttach=(a == null  ? 0 : p$3.parseInt$S.apply(this, [a]));
var s=this.atts.get$O("order");
var disp=this.atts.get$O("display");
var disp2=this.atts.get$O("display2");
var order=this.getBondOrder$S("null");
var invertEnds=false;
if (disp == null ) {
if (s == null ) {
order=1;
} else if (s.equals$O("1.5")) {
order=this.getBondOrder$S("delocalized");
} else {
if (s.indexOf$S(".") > 0 && !"Dash".equals$O(disp2) ) {
s=s.substring$I$I(0, s.indexOf$S("."));
}order=this.getBondOrder$S(s);
}} else if (disp.equals$O("WedgeBegin")) {
order=this.getBondOrder$S("up");
} else if (disp.equals$O("Hash") || disp.equals$O("WedgedHashBegin") ) {
order=this.getBondOrder$S("down");
} else if (disp.equals$O("WedgeEnd")) {
invertEnds=true;
order=this.getBondOrder$S("up");
} else if (disp.equals$O("WedgedHashEnd")) {
invertEnds=true;
order=this.getBondOrder$S("down");
} else if (disp.equals$O("Bold")) {
order=this.getBondOrder$S("single");
} else if (disp.equals$O("Wavy")) {
order=this.getBondOrder$S("either");
}if (order == this.getBondOrder$S("null")) {
System.err.println$S("XmlChemDrawReader ignoring bond type " + s);
return null;
}var b=(invertEnds ? Clazz.new_($I$(3,1).c$$S$S$S$I,[this, null, id, atom2, atom1, order]) : Clazz.new_($I$(3,1).c$$S$S$S$I,[this, null, id, atom1, atom2, order]));
var node1=this.getAtom$I(b.atomIndex1);
var node2=this.getAtom$I(b.atomIndex2);
if (order == 1057) {
if (!this.nostereo.contains$O(node1)) this.nostereo.add$O(node1);
if (!this.nostereo.contains$O(node2)) this.nostereo.add$O(node2);
}if (node1.hasMultipleAttachments) {
node1.attachedAtom=node2;
return b;
} else if (node2.hasMultipleAttachments) {
node2.attachedAtom=node1;
return b;
}if (node1.isFragment && beginAttach == 0 ) beginAttach=1;
if (node2.isFragment && endAttach == 0 ) endAttach=1;
if (beginAttach > 0) {
(invertEnds ? node2 : node1).addAttachedAtom$org_jmol_adapter_readers_xml_CDXMLReader_CDBond$I(b, beginAttach);
}if (endAttach > 0) {
(invertEnds ? node1 : node2).addAttachedAtom$org_jmol_adapter_readers_xml_CDXMLReader_CDBond$I(b, endAttach);
}if (node1.isExternalPt) {
node1.setInternalAtom$org_jmol_adapter_readers_xml_CDXMLReader_CDNode(node2);
}if (node2.isExternalPt) {
node2.setInternalAtom$org_jmol_adapter_readers_xml_CDXMLReader_CDNode(node1);
}this.addBond$org_jmol_adapter_readers_xml_CDXMLReader_CDBond(b);
return b;
}, p$3);

Clazz.newMeth(C$, 'setBracketedGroup$S$java_util_Map',  function (id, atts) {
var usage=atts.get$O("bracketusage");
if (this.bracketedGroups == null ) this.bracketedGroups=Clazz.new_($I$(7,1));
if ("MultipleGroup".equals$O(usage)) {
var ids=p$3.getTokens$S.apply(this, [atts.get$O("bracketedobjectids")]);
var repeatCount=p$3.parseInt$S.apply(this, [atts.get$O("repeatcount")]);
this.bracketedGroups.add$O(Clazz.new_($I$(10,1).c$$S$SA$I,[this, null, id, ids, repeatCount]));
}}, p$3);

Clazz.newMeth(C$, 'setAtom$S',  function (key) {
var xyz=this.atts.get$O(key);
var tokens=p$3.getTokens$S.apply(this, [xyz]);
var x=p$3.parseDouble$S.apply(this, [tokens[0]]);
var y=-p$3.parseDouble$S.apply(this, [tokens[1]]);
var z=(key === "xyz"  ? p$3.parseDouble$S.apply(this, [tokens[2]]) : 0);
if (x < this.minX ) this.minX=x;
if (x > this.maxX ) this.maxX=x;
if (y < this.minY ) this.minY=y;
if (y > this.maxY ) this.maxY=y;
if (z < this.minZ ) this.minZ=z;
if (z > this.maxZ ) this.maxZ=z;
this.thisAtom.set$D$D$D(x, y, z);
}, p$3);

Clazz.newMeth(C$, 'finalizeSubclassReader$',  function () {
p$3.fixConnections.apply(this, []);
p$3.fixInvalidAtoms.apply(this, []);
p$3.fixBracketedGroups.apply(this, []);
p$3.centerAndScale.apply(this, []);
this.createMolecule$();
});

Clazz.newMeth(C$, 'fixInvalidAtoms',  function () {
for (var i=this.getAtomCount$(); --i >= 0; ) {
var a=this.getAtom$I(i);
a.atomSerial=-2147483648;
if (a.isFragment || a.isExternalPt || !a.isConnected && (!a.isValid || a.elementNumber == 6  || a.elementNumber == 0 )   ) {
this.bsAtoms.clear$I(a.index);
}}
p$3.reserializeAtoms.apply(this, []);
for (var i=this.getBondCount$(); --i >= 0; ) {
var b=this.getBond$I(i);
if (b.isValid$()) {
this.bsBonds.set$I(i);
} else {
}}
}, p$3);

Clazz.newMeth(C$, 'reserializeAtoms',  function () {
for (var p=0, i=this.bsAtoms.nextSetBit$I(0); i >= 0; i=this.bsAtoms.nextSetBit$I(i + 1)) {
var a=this.getAtom$I(i);
a.atomSerial=++p;
}
}, p$3);

Clazz.newMeth(C$, 'fixBracketedGroups',  function () {
if (this.bracketedGroups == null ) return;
for (var i=this.bracketedGroups.size$(); --i >= 0; ) {
this.bracketedGroups.remove$I(i).process$();
}
}, p$3);

Clazz.newMeth(C$, 'fixConnections',  function () {
for (var i=this.getAtomCount$(); --i >= 0; ) {
var a=this.getAtom$I(i);
if (a.isFragment || a.hasMultipleAttachments ) a.fixAttachments$();
}
for (var i=0, n=this.getBondCount$(); i < n; i++) {
var b=this.getBond$I(i);
if (b == null ) {
continue;
}var a1=this.getAtom$I(b.atomIndex1);
var a2=this.getAtom$I(b.atomIndex2);
a1.isConnected=true;
a2.isConnected=true;
if (this.nostereo.contains$O(a1) != this.nostereo.contains$O(a2) ) {
b.order=1;
}}
}, p$3);

Clazz.newMeth(C$, 'centerAndScale',  function () {
if (this.minX > this.maxX ) return;
var sum=0;
var n=0;
var lenH=1;
for (var i=this.getBondCount$(); --i >= 0; ) {
var b=this.getBond$I(i);
var a1=b.atom1;
var a2=b.atom2;
var d=a1.distance$javajs_util_T3d(a2);
if (a1.elementNumber > 1 && a2.elementNumber > 1 ) {
sum+=d;
++n;
} else {
lenH=d;
}}
var f=(sum > 0  ? 1.45 * n / sum : lenH > 0  ? 1 / lenH : 1);
if (f > 0.5 ) f=1;
var cx=(this.maxX + this.minX) / 2;
var cy=(this.maxY + this.minY) / 2;
var cz=(this.maxZ + this.minZ) / 2;
for (var i=this.getAtomCount$(); --i >= 0; ) {
var a=this.getAtom$I(i);
a.x=(a.x - cx) * f;
a.y=(a.y - cy) * f;
a.z=(a.z - cz) * f;
}
for (var i=this.getBondCount$(); --i >= 0; ) {
var b=this.getBond$I(i);
var a1=b.atom1;
var a2=b.atom2;
var d=a1.distance$javajs_util_T3d(a2);
d=a1.distance$javajs_util_T3d(a2);
}
return;
}, p$3);

Clazz.newMeth(C$, 'getAtom$I',  function (i) {
return this.atoms.get$I(i);
});

Clazz.newMeth(C$, 'addAtom$org_jmol_adapter_readers_xml_CDXMLReader_CDNode',  function (atom) {
this.bsAtoms.set$I(atom.index=this.atoms.size$());
this.atoms.add$O(atom);
return atom;
});

Clazz.newMeth(C$, 'getAtomCount$',  function () {
return this.atoms.size$();
});

Clazz.newMeth(C$, 'addBond$org_jmol_adapter_readers_xml_CDXMLReader_CDBond',  function (b) {
this.bsBonds.set$I(b.index=this.getBondCount$());
this.bonds.add$O(b);
return b;
});

Clazz.newMeth(C$, 'getBond$I',  function (i) {
return this.bonds.get$I(i);
});

Clazz.newMeth(C$, 'getBondCount$',  function () {
return this.bonds.size$();
});

Clazz.newMeth(C$, 'getBondOrder$S',  function (key) {
switch (key) {
case "1":
case "single":
return 1;
case "2":
case "double":
return 2;
case "3":
case "triple":
return 3;
case "up":
return 1025;
case "down":
return 1041;
case "either":
return 1057;
case "null":
return 131071;
case "delocalized":
return 515;
default:
case "partial":
return $I$(11).getBondOrderFromString$S(key);
}
});

Clazz.newMeth(C$, 'handleCoordinates$java_util_Map',  function (atts) {
var hasXYZ=(atts.containsKey$O("xyz"));
var hasXY=(atts.containsKey$O("p"));
if (hasXYZ && (!this.no3D || !hasXY ) ) {
this.is2D=false;
p$3.setAtom$S.apply(this, ["xyz"]);
} else if (atts.containsKey$O("p")) {
p$3.setAtom$S.apply(this, ["p"]);
}}, p$3);

Clazz.newMeth(C$, 'createMolecule$',  function () {
p$3.reserializeAtoms.apply(this, []);
for (var i=this.bsAtoms.nextSetBit$I(0); i >= 0; i=this.bsAtoms.nextSetBit$I(i + 1)) {
var a=this.getAtom$I(i);
a.index=this.asc.ac;
this.asc.addAtom$org_jmol_adapter_smarter_Atom(a);
}
for (var i=this.bsBonds.nextSetBit$I(0); i >= 0; i=this.bsBonds.nextSetBit$I(i + 1)) {
var bond=this.bonds.get$I(i);
bond.atomIndex1=bond.atom1.index;
bond.atomIndex2=bond.atom2.index;
this.asc.addBondNoCheck$org_jmol_adapter_smarter_Bond(bond);
}
this.parent.appendLoadNote$S((this.isCDX ? "CDX: " : "CDXML: ") + (this.is2D ? "2D" : "3D"));
this.asc.setInfo$S$O("minimize3D", Boolean.valueOf$Z(!this.is2D && !this.noHydrogens ));
this.asc.setInfo$S$O("is2D", Boolean.valueOf$Z(this.is2D));
if (this.is2D) {
this.optimize2D=!this.noHydrogens && !this.noMinimize ;
this.asc.setModelInfoForSet$S$O$I("dimension", "2D", this.asc.iSet);
this.set2D$();
}});
var $s$ = new Int16Array(1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.CDXMLReader, "CDNode", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'org.jmol.adapter.smarter.Atom');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.isValid=true;
},1);

C$.$fields$=[['Z',['isValid','isConnected','isExternalPt','isFragment','hasMultipleAttachments'],'I',['intID'],'S',['warning','id','nodeType','outerFragmentID','innerFragmentID','text'],'O',['parentNode','org.jmol.adapter.readers.xml.CDXMLReader.CDNode','orderedConnectionBonds','java.util.List','internalAtom','org.jmol.adapter.readers.xml.CDXMLReader.CDNode','orderedExternalPoints','java.util.List','attachments','String[]','+bondOrdering','+connectionOrder','attachedAtom','org.jmol.adapter.readers.xml.CDXMLReader.CDNode','bsConnections','java.util.BitSet']]]

Clazz.newMeth(C$, 'c$$S$S$S$org_jmol_adapter_readers_xml_CDXMLReader_CDNode',  function (id, nodeType, fragmentID, parent) {
Clazz.super_(C$, this);
this.id=id;
this.outerFragmentID=fragmentID;
this.atomSerial=this.intID=Integer.parseInt$S(id);
this.nodeType=nodeType;
this.parentNode=parent;
this.bsConnections=Clazz.new_($I$(1,1));
this.isFragment="Fragment".equals$O(nodeType) || "Nickname".equals$O(nodeType) ;
this.isExternalPt="ExternalConnectionPoint".equals$O(nodeType);
}, 1);

Clazz.newMeth(C$, 'set$D$D',  function (x, y) {
this.x=x;
this.y=y;
});

Clazz.newMeth(C$, 'setInnerFragmentID$S',  function (id) {
this.innerFragmentID=id;
});

Clazz.newMeth(C$, 'setBondOrdering$SA',  function (bondOrdering) {
this.bondOrdering=bondOrdering;
});

Clazz.newMeth(C$, 'setConnectionOrder$SA',  function (connectionOrder) {
this.connectionOrder=connectionOrder;
});

Clazz.newMeth(C$, 'setMultipleAttachments$SA',  function (attachments) {
this.attachments=attachments;
this.hasMultipleAttachments=true;
});

Clazz.newMeth(C$, 'addExternalPoint$org_jmol_adapter_readers_xml_CDXMLReader_CDNode',  function (externalPoint) {
if (this.orderedExternalPoints == null ) this.orderedExternalPoints=Clazz.new_($I$(2,1));
var i=this.orderedExternalPoints.size$();
while (--i >= 0 && this.orderedExternalPoints.get$I(i).intID >= externalPoint.internalAtom.intID ){
}
this.orderedExternalPoints.add$I$O(++i, externalPoint);
});

Clazz.newMeth(C$, 'setInternalAtom$org_jmol_adapter_readers_xml_CDXMLReader_CDNode',  function (a) {
this.internalAtom=a;
if (this.parentNode != null ) {
this.parentNode.addExternalPoint$org_jmol_adapter_readers_xml_CDXMLReader_CDNode(this);
}});

Clazz.newMeth(C$, 'addAttachedAtom$org_jmol_adapter_readers_xml_CDXMLReader_CDBond$I',  function (bond, pt) {
if (this.orderedConnectionBonds == null ) this.orderedConnectionBonds=Clazz.new_($I$(2,1));
var i=this.orderedConnectionBonds.size$();
while (--i >= 0 && (this.orderedConnectionBonds.get$I(i)[0]).intValue$() > pt ){
}
this.orderedConnectionBonds.add$I$O(++i, Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(pt), bond]));
});

Clazz.newMeth(C$, 'fixAttachments$',  function () {
if (this.hasMultipleAttachments && this.attachedAtom != null  ) {
var order=this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].getBondOrder$S.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLReader'], ["partial"]);
var a1=this.attachedAtom;
for (var i=this.attachments.length; --i >= 0; ) {
var a=this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].objectsByID.get$O(this.attachments[i]);
if (a != null ) {
this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].addBond$org_jmol_adapter_readers_xml_CDXMLReader_CDBond.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLReader'], [Clazz.new_($I$(3,1).c$$S$S$S$I,[this, null, null, a1.id, a.id, order])]);
}}
}if (this.orderedExternalPoints == null  || this.text == null  ) return;
var n=this.orderedExternalPoints.size$();
if (n != this.orderedConnectionBonds.size$()) {
System.err.println$S("XmlCdxReader cannot fix attachments for fragment " + this.text);
return;
}if (this.bondOrdering == null ) {
this.bondOrdering=Clazz.array(String, [n]);
for (var i=0; i < n; i++) {
this.bondOrdering[i]=(this.orderedConnectionBonds.get$I(i)[1]).id;
}
}if (this.connectionOrder == null ) {
this.connectionOrder=Clazz.array(String, [n]);
for (var i=0; i < n; i++) {
this.connectionOrder[i]=this.orderedExternalPoints.get$I(i).id;
}
}for (var i=0; i < n; i++) {
var b=this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].objectsByID.get$O(this.bondOrdering[i]);
var a=(this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].objectsByID.get$O(this.connectionOrder[i])).internalAtom;
p$1.updateExternalBond$org_jmol_adapter_readers_xml_CDXMLReader_CDBond$org_jmol_adapter_readers_xml_CDXMLReader_CDNode.apply(this, [b, a]);
}
});

Clazz.newMeth(C$, 'updateExternalBond$org_jmol_adapter_readers_xml_CDXMLReader_CDBond$org_jmol_adapter_readers_xml_CDXMLReader_CDNode',  function (bond2f, intAtom) {
this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].bsBonds.set$I(bond2f.index);
bond2f.disconnect$();
if (bond2f.atomIndex2 == this.index) {
bond2f.connect$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode(bond2f.atom1, intAtom);
} else if (bond2f.atomIndex1 == this.index) {
bond2f.connect$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode(intAtom, bond2f.atom2);
} else {
System.err.println$S("CDXMLParser attachment failed! " + intAtom + " " + bond2f );
}}, p$1);

Clazz.newMeth(C$, 'clone$',  function () {
var a;
try {
a=Clazz.clone(this);
a.id=this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].nextID$.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLReader'], []);
this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].objectsByID.put$O$O(a.id, a);
a.x+=Math.random() * 0.1 - 0.05;
a.y+=Math.random() * 0.1 - 0.05;
a.z+=Math.random() * 0.1 - 0.05;
this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].addAtom$org_jmol_adapter_readers_xml_CDXMLReader_CDNode.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLReader'], [a]);
a.bsConnections=Clazz.new_($I$(1,1));
return a;
} catch (e) {
if (Clazz.exceptionOf(e,"CloneNotSupportedException")){
return null;
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'toString',  function () {
return "[CDNode " + this.id + " " + this.elementSymbol + " " + this.elementNumber + " index=" + this.index + " ext=" + this.isExternalPt + " frag=" + this.isFragment + " " + this.elementSymbol + " " + new Double(this.x).toString() + " " + new Double(this.y).toString() + "]" ;
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.CDXMLReader, "CDBond", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'org.jmol.adapter.smarter.Bond');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['invalidated'],'I',['index'],'S',['id','id1','id2'],'O',['atom1','org.jmol.adapter.readers.xml.CDXMLReader.CDNode','+atom2']]]

Clazz.newMeth(C$, 'c$$S$S$S$I',  function (id, id1, id2, order) {
;C$.superclazz.c$$I$I$I.apply(this,[(this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].objectsByID.get$O(id1)).index, (this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].objectsByID.get$O(id2)).index, order]);C$.$init$.apply(this);
this.id=(id == null  ? this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].nextID$.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLReader'], []) : id);
this.id1=id1;
this.id2=id2;
this.atom1=this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].objectsByID.get$O(id1);
this.atom2=this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].objectsByID.get$O(id2);
this.atom1.bsConnections.set$I(this.atomIndex2);
this.atom2.bsConnections.set$I(this.atomIndex1);
this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].bondIDMap.put$O$O($I$(4).getBondKey$I$I(this.atomIndex1, this.atomIndex2), this);
}, 1);

Clazz.newMeth(C$, 'connect$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode',  function (atomA, atomB) {
this.atom1=atomA;
this.atomIndex1=atomA.index;
this.atom2=atomB;
this.atomIndex2=atomB.index;
atomA.bsConnections.set$I(atomB.index);
atomB.bsConnections.set$I(atomA.index);
});

Clazz.newMeth(C$, 'disconnect$',  function () {
this.atom1.bsConnections.clear$I(this.atom2.index);
this.atom2.bsConnections.clear$I(this.atom1.index);
});

Clazz.newMeth(C$, 'getOtherNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode',  function (a) {
return this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].getAtom$I.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLReader'], [this.atomIndex1 == a.index ? this.atomIndex2 : this.atomIndex1]);
});

Clazz.newMeth(C$, 'invalidate$',  function () {
this.invalidated=true;
this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].bsBonds.clear$I(this.index);
this.atomIndex1=this.atomIndex2=-1;
});

Clazz.newMeth(C$, 'isValid$',  function () {
return (!this.invalidated && this.atom1.atomSerial >= 0  && this.atom2.atomSerial >= 0 );
});

Clazz.newMeth(C$, 'toString',  function () {
return "[CDBond index " + this.index + " id " + this.id + " id1=" + this.id1 + " id2=" + this.id2 + C$.superclazz.prototype.toString.apply(this, []) + "]" ;
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.CDXMLReader, "BracketedGroup", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.bondIDs=Clazz.array(String, [2]);
this.innerAtomIDs=Clazz.array(String, [2]);
},1);

C$.$fields$=[['I',['repeatCount','pt'],'S',['id'],'O',['ids','String[]','+bondIDs','+innerAtomIDs']]]

Clazz.newMeth(C$, 'c$$S$SA$I',  function (id, ids, repeatCount) {
;C$.$init$.apply(this);
this.id=id;
this.ids=ids;
this.repeatCount=repeatCount;
}, 1);

Clazz.newMeth(C$, 'addCrossing$S$S',  function (innerAtomID, bondID) {
if (this.pt == 2) {
System.err.println$S("BracketedGroup has more than two crossings");
return;
}this.bondIDs[this.pt]=bondID;
this.innerAtomIDs[this.pt]=innerAtomID;
++this.pt;
});

Clazz.newMeth(C$, 'process$',  function () {
if (this.pt != 2) return;
var a1i=this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].objectsByID.get$O(this.innerAtomIDs[1]);
var a2i=this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].objectsByID.get$O(this.innerAtomIDs[0]);
var b1=this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].objectsByID.get$O(this.bondIDs[1]);
var b2=this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].objectsByID.get$O(this.bondIDs[0]);
var a1o=b1.getOtherNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode(a1i);
var a2o=b2.getOtherNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode(a2i);
var bsBracketed=Clazz.new_($I$(1,1));
for (var i=this.ids.length; --i >= 0; ) {
bsBracketed.set$I((this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].objectsByID.get$O(this.ids[i])).index);
}
var a1=a1i;
var a2iLast=a2i;
for (var i=1; i < this.repeatCount; i++) {
var newNodes=p$2.duplicateBracketAtoms$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$java_util_BitSet.apply(this, [a1o, a1i, a2i, bsBracketed]);
a1=newNodes[0];
p$2.patch$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDBond$org_jmol_adapter_readers_xml_CDXMLReader_CDNode.apply(this, [a2iLast, b1, a1]);
a2iLast=newNodes[1];
}
p$2.patch$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDBond$org_jmol_adapter_readers_xml_CDXMLReader_CDNode.apply(this, [a2iLast, b2, a2o]);
b2.invalidate$();
});

Clazz.newMeth(C$, 'duplicateBracketAtoms$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$java_util_BitSet',  function (a1o, a1i, a2i, bsBracketed) {
var aNew=a1i.clone$();
var a12i=Clazz.array($I$(5), -1, [aNew, a1i === a2i  ? aNew : null]);
var bsDone=Clazz.new_($I$(1,1));
p$2.buildBranch$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$java_util_BitSet$java_util_BitSet$org_jmol_adapter_readers_xml_CDXMLReader_CDNodeA.apply(this, [null, a1i, a2i, aNew, bsDone, bsBracketed, a12i]);
return a12i;
}, p$2);

Clazz.newMeth(C$, 'buildBranch$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$java_util_BitSet$java_util_BitSet$org_jmol_adapter_readers_xml_CDXMLReader_CDNodeA',  function (prev, aRoot, aEnd, a, bsDone, bsBracketed, a12i) {
bsDone.set$I(aRoot.index);
for (var i=aRoot.bsConnections.nextSetBit$I(0); i >= 0; i=aRoot.bsConnections.nextSetBit$I(i + 1)) {
if (!bsBracketed.get$I(i)) continue;
var aBranch=this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].getAtom$I.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLReader'], [i]);
if (aBranch === prev ) continue;
var isNew=!bsDone.get$I(i);
var bBranch=this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].getBond$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLReader'], [aRoot, aBranch]);
var aNext=(isNew ? aBranch.clone$() : aBranch);
if (aBranch === aEnd  && a12i[1] == null  ) {
a12i[1]=aNext;
}this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].addBond$org_jmol_adapter_readers_xml_CDXMLReader_CDBond.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLReader'], [Clazz.new_($I$(3,1).c$$S$S$S$I,[this, null, null, a.id, aNext.id, bBranch.order])]);
if (isNew) {
p$2.buildBranch$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$java_util_BitSet$java_util_BitSet$org_jmol_adapter_readers_xml_CDXMLReader_CDNodeA.apply(this, [aRoot, aBranch, aEnd, aNext, bsDone, bsBracketed, a12i]);
}}
}, p$2);

Clazz.newMeth(C$, 'patch$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDBond$org_jmol_adapter_readers_xml_CDXMLReader_CDNode',  function (a1, b, a2) {
var b1=this.b$['org.jmol.adapter.readers.xml.CDXMLReader'].addBond$org_jmol_adapter_readers_xml_CDXMLReader_CDBond.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLReader'], [Clazz.new_($I$(3,1).c$$S$S$S$I,[this, null, null, a1.id, a2.id, b.order])]);
b1.disconnect$();
b1.connect$org_jmol_adapter_readers_xml_CDXMLReader_CDNode$org_jmol_adapter_readers_xml_CDXMLReader_CDNode(a1, a2);
}, p$2);

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-19 05:58:15 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
