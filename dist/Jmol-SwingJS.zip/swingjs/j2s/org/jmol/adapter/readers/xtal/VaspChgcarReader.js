(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.xtal"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "VaspChgcarReader", null, 'org.jmol.adapter.readers.xtal.VaspPoscarReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:16:07 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
