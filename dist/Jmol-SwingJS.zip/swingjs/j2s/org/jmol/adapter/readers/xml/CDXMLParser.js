(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.xml"),p$1={},p$2={},p$3={},I$=[[0,'javajs.util.BS','javajs.util.Lst',['org.jmol.adapter.readers.xml.CDXMLParser','.CDBond'],'org.jmol.adapter.readers.xml.CDXMLParser','java.util.HashMap',['org.jmol.adapter.readers.xml.CDXMLParser','.CDNode'],['org.jmol.adapter.readers.xml.CDXMLParser','.BracketedGroup']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CDXMLParser", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['CDXReaderI',9],['CDNode',0],['CDBond',0],['BracketedGroup',0]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.minX=1.7976931348623157E308;
this.minY=1.7976931348623157E308;
this.minZ=1.7976931348623157E308;
this.maxZ=-1.7976931348623157E308;
this.maxY=-1.7976931348623157E308;
this.maxX=-1.7976931348623157E308;
this.idnext=100000;
this.bsAtoms=Clazz.new_($I$(1,1));
this.bsBonds=Clazz.new_($I$(1,1));
this.atoms=Clazz.new_($I$(2,1));
this.bonds=Clazz.new_($I$(2,1));
this.bondIDMap=Clazz.new_($I$(5,1));
this.fragments=Clazz.new_($I$(2,1));
this.nodes=Clazz.new_($I$(2,1));
this.nostereo=Clazz.new_($I$(2,1));
this.objectsByID=Clazz.new_($I$(5,1));
},1);

C$.$fields$=[['Z',['ignoreText'],'D',['minX','minY','minZ','maxZ','maxY','maxX'],'I',['idnext'],'S',['thisFragmentID','textBuffer'],'O',['bsAtoms','javajs.util.BS','+bsBonds','atoms','javajs.util.Lst','+bonds','bondIDMap','java.util.Map','bracketedGroups','javajs.util.Lst','rdr','org.jmol.adapter.readers.xml.CDXMLParser.CDXReaderI','mapCloned','java.util.Map','fragments','javajs.util.Lst','thisNode','org.jmol.adapter.readers.xml.CDXMLParser.CDNode','+thisAtom','nodes','javajs.util.Lst','+nostereo','objectsByID','java.util.Map']]]

Clazz.newMeth(C$, 'c$$org_jmol_adapter_readers_xml_CDXMLParser_CDXReaderI',  function (reader) {
;C$.$init$.apply(this);
this.rdr=reader;
}, 1);

Clazz.newMeth(C$, 'processStartElement$S$java_util_Map',  function (localName, atts) {
var id=atts.get$O("id");
switch (localName) {
case "n":
this.objectsByID.put$O$O(id, p$3.setNode$S$java_util_Map.apply(this, [id, atts]));
break;
case "b":
this.objectsByID.put$O$O(id, p$3.setBond$S$java_util_Map.apply(this, [id, atts]));
break;
case "t":
this.textBuffer="";
break;
case "s":
this.rdr.setKeepChars$Z(true);
break;
case "fragment":
this.objectsByID.put$O$O(id, p$3.setFragment$S$java_util_Map.apply(this, [id, atts]));
break;
case "objecttag":
switch (atts.get$O("name")) {
case "parameterizedBracketLabel":
case "bracketusage":
this.ignoreText=true;
break;
}
break;
case "bracketedgroup":
p$3.setBracketedGroup$S$java_util_Map.apply(this, [id, atts]);
break;
case "crossingbond":
var bg=(this.bracketedGroups == null  || this.bracketedGroups.isEmpty$()  ? null : this.bracketedGroups.get$I(this.bracketedGroups.size$() - 1));
if (bg != null  && bg.repeatCount > 0 ) {
bg.addCrossing$S$S(atts.get$O("inneratomid"), atts.get$O("bondid"));
}break;
}
});

Clazz.newMeth(C$, 'nextID$',  function () {
return "" + (this.idnext++);
});

Clazz.newMeth(C$, 'getBondKey$I$I',  function (atomIndex1, atomIndex2) {
return Math.min(atomIndex1, atomIndex2) + "_" + Math.max(atomIndex1, atomIndex2) ;
}, 1);

Clazz.newMeth(C$, 'getBond$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode',  function (a, b) {
return this.bondIDMap.get$O(C$.getBondKey$I$I(a.index, b.index));
});

Clazz.newMeth(C$, 'processEndElement$S$S',  function (localName, chars) {
switch (localName) {
case "fragment":
this.thisFragmentID=this.fragments.removeItemAt$I(this.fragments.size$() - 1);
return;
case "objecttag":
this.ignoreText=false;
return;
case "n":
this.thisNode=(this.nodes.size$() == 0 ? null : this.nodes.removeItemAt$I(this.nodes.size$() - 1));
return;
case "bracketedgroup":
break;
case "s":
this.textBuffer+=chars.toString();
break;
case "t":
if (this.ignoreText) {
} else if (this.thisNode == null ) {
System.out.println$S("CDXReader unassigned text: " + this.textBuffer);
} else {
this.thisNode.text=this.textBuffer;
if (this.thisAtom.elementNumber == 0) {
System.err.println$S("XmlChemDrawReader: Problem with \"" + this.textBuffer + "\"" );
}if (this.thisNode.warning != null ) this.rdr.warn$S("Warning: " + this.textBuffer + " " + this.thisNode.warning );
}this.textBuffer="";
break;
}
this.rdr.setKeepChars$Z(false);
});

Clazz.newMeth(C$, 'getTokens$S',  function (s) {
return s.split$S("\\s");
}, p$3);

Clazz.newMeth(C$, 'split$S$S',  function (s, p) {
return s.split$S(p);
}, p$3);

Clazz.newMeth(C$, 'parseInt$S',  function (s) {
try {
return Integer.parseInt$S(s);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return -2147483648;
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'parseDouble$S',  function (s) {
try {
return Double.parseDouble$S(s);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return NaN;
} else {
throw e;
}
}
}, p$3);

Clazz.newMeth(C$, 'setNode$S$java_util_Map',  function (id, atts) {
var nodeType=atts.get$O("nodetype");
if (this.thisNode != null ) this.nodes.addLast$O(this.thisNode);
if ("_".equals$O(nodeType)) {
this.thisAtom=this.thisNode=null;
return null;
}this.thisAtom=this.thisNode=Clazz.new_([this, null, this.atoms.size$(), id, nodeType, this.thisFragmentID, this.thisNode],$I$(6,1).c$$I$S$S$S$org_jmol_adapter_readers_xml_CDXMLParser_CDNode);
this.addAtom$org_jmol_adapter_readers_xml_CDXMLParser_CDNode(this.thisNode);
var w=atts.get$O("warning");
if (w != null ) {
this.thisNode.warning=w.replace$CharSequence$CharSequence("&apos;", "\'");
this.thisNode.isValid=(w.indexOf$S("ChemDraw can\'t interpret") < 0);
}var element=atts.get$O("element");
var s=atts.get$O("genericnickname");
if (s != null ) {
element=s;
}this.thisAtom.element=element;
this.thisAtom.elementNumber=($s$[0] = Math.max(0, (!p$3.checkWarningOK$S.apply(this, [w]) ? 0 : element == null  ? 6 : this.parseInt$S(element))), $s$[0]);
this.thisAtom.isotope=atts.get$O("isotope");
s=atts.get$O("charge");
if (s != null ) {
this.thisAtom.formalCharge=this.parseInt$S(s);
}this.rdr.handleCoordinates$java_util_Map(atts);
s=atts.get$O("attachments");
if (s != null ) {
this.thisNode.setMultipleAttachments$SA(p$3.split$S$S.apply(this, [s.trim$(), " "]));
}s=atts.get$O("bondordering");
if (s != null ) {
this.thisNode.setBondOrdering$SA(p$3.split$S$S.apply(this, [s.trim$(), " "]));
}return this.thisNode;
}, p$3);

Clazz.newMeth(C$, 'checkWarningOK$S',  function (warning) {
return (warning == null  || warning.indexOf$S("valence") >= 0  || warning.indexOf$S("very close") >= 0  || warning.indexOf$S("two identical colinear bonds") >= 0 );
}, p$3);

Clazz.newMeth(C$, 'setFragment$S$java_util_Map',  function (id, atts) {
this.fragments.addLast$O(this.thisFragmentID=id);
var fragmentNode=(this.thisNode == null  || !this.thisNode.isFragment  ? null : this.thisNode);
if (fragmentNode != null ) {
fragmentNode.setInnerFragmentID$S(id);
}var s=atts.get$O("connectionorder");
if (s != null ) {
this.thisNode.setConnectionOrder$SA(s.trim$().split$S(" "));
}return fragmentNode;
}, p$3);

Clazz.newMeth(C$, 'setBond$S$java_util_Map',  function (id, atts) {
var atom1=atts.get$O("b");
var atom2=atts.get$O("e");
var a=atts.get$O("beginattach");
var beginAttach=(a == null  ? 0 : this.parseInt$S(a));
a=atts.get$O("endattach");
var endAttach=(a == null  ? 0 : this.parseInt$S(a));
var s=atts.get$O("order");
var disp=atts.get$O("display");
var disp2=atts.get$O("display2");
var order=this.rdr.getBondOrder$S("null");
var invertEnds=false;
if (disp == null ) {
if (s == null ) {
order=1;
} else if (s.equals$O("1.5")) {
order=this.rdr.getBondOrder$S("delocalized");
} else {
if (s.indexOf$S(".") > 0 && !"Dash".equals$O(disp2) ) {
s=s.substring$I$I(0, s.indexOf$S("."));
}order=this.rdr.getBondOrder$S(s);
}} else if (disp.equals$O("WedgeBegin")) {
order=this.rdr.getBondOrder$S("up");
} else if (disp.equals$O("Hash") || disp.equals$O("WedgedHashBegin") ) {
order=this.rdr.getBondOrder$S("down");
} else if (disp.equals$O("WedgeEnd")) {
invertEnds=true;
order=this.rdr.getBondOrder$S("up");
} else if (disp.equals$O("WedgedHashEnd")) {
invertEnds=true;
order=this.rdr.getBondOrder$S("down");
} else if (disp.equals$O("Bold")) {
order=this.rdr.getBondOrder$S("single");
} else if (disp.equals$O("Wavy")) {
order=this.rdr.getBondOrder$S("either");
}if (order == this.rdr.getBondOrder$S("null")) {
System.err.println$S("XmlChemDrawReader ignoring bond type " + s);
return null;
}var b=(invertEnds ? Clazz.new_($I$(3,1).c$$S$S$S$I,[this, null, id, atom2, atom1, order]) : Clazz.new_($I$(3,1).c$$S$S$S$I,[this, null, id, atom1, atom2, order]));
var node1=this.getAtom$I(b.atomIndex1);
var node2=this.getAtom$I(b.atomIndex2);
if (order == this.rdr.getBondOrder$S("either")) {
if (!this.nostereo.contains$O(node1)) this.nostereo.addLast$O(node1);
if (!this.nostereo.contains$O(node2)) this.nostereo.addLast$O(node2);
}if (node1.hasMultipleAttachments) {
node1.attachedAtom=node2;
return b;
} else if (node2.hasMultipleAttachments) {
node2.attachedAtom=node1;
return b;
}if (node1.isFragment && beginAttach == 0 ) beginAttach=1;
if (node2.isFragment && endAttach == 0 ) endAttach=1;
if (beginAttach > 0) {
(invertEnds ? node2 : node1).addAttachedAtom$org_jmol_adapter_readers_xml_CDXMLParser_CDBond$I(b, beginAttach);
}if (endAttach > 0) {
(invertEnds ? node1 : node2).addAttachedAtom$org_jmol_adapter_readers_xml_CDXMLParser_CDBond$I(b, endAttach);
}if (node1.isExternalPt) {
node1.setInternalAtom$org_jmol_adapter_readers_xml_CDXMLParser_CDNode(node2);
}if (node2.isExternalPt) {
node2.setInternalAtom$org_jmol_adapter_readers_xml_CDXMLParser_CDNode(node1);
}this.addBond$org_jmol_adapter_readers_xml_CDXMLParser_CDBond(b);
return b;
}, p$3);

Clazz.newMeth(C$, 'setBracketedGroup$S$java_util_Map',  function (id, atts) {
var usage=atts.get$O("bracketusage");
if (this.bracketedGroups == null ) this.bracketedGroups=Clazz.new_($I$(2,1));
if ("MultipleGroup".equals$O(usage)) {
var ids=p$3.getTokens$S.apply(this, [atts.get$O("bracketedobjectids")]);
var repeatCount=this.parseInt$S(atts.get$O("repeatcount"));
this.bracketedGroups.addLast$O(Clazz.new_($I$(7,1).c$$S$SA$I,[this, null, id, ids, repeatCount]));
}}, p$3);

Clazz.newMeth(C$, 'setAtom$S$java_util_Map',  function (key, atts) {
var xyz=atts.get$O(key);
var tokens=p$3.getTokens$S.apply(this, [xyz]);
var x=p$3.parseDouble$S.apply(this, [tokens[0]]);
var y=-p$3.parseDouble$S.apply(this, [tokens[1]]);
var z=(key === "xyz"  ? p$3.parseDouble$S.apply(this, [tokens[2]]) : 0);
if (x < this.minX ) this.minX=x;
if (x > this.maxX ) this.maxX=x;
if (y < this.minY ) this.minY=y;
if (y > this.maxY ) this.maxY=y;
if (z < this.minZ ) this.minZ=z;
if (z > this.maxZ ) this.maxZ=z;
this.thisAtom.set$D$D$D(x, y, z);
});

Clazz.newMeth(C$, 'fixInvalidAtoms',  function () {
for (var i=this.getAtomCount$(); --i >= 0; ) {
var a=this.getAtom$I(i);
a.intID=-2147483648;
if (a.isFragment || a.isExternalPt || !a.isConnected && (!a.isValid || a.elementNumber < 10 )   ) {
this.bsAtoms.clear$I(a.index);
}}
p$3.reserializeAtoms.apply(this, []);
this.bsBonds.clearAll$();
for (var i=this.getBondCount$(); --i >= 0; ) {
var b=this.getBond$I(i);
if (b.isValid$()) {
this.bsBonds.set$I(i);
} else {
}}
}, p$3);

Clazz.newMeth(C$, 'reserializeAtoms',  function () {
for (var p=0, i=this.bsAtoms.nextSetBit$I(0); i >= 0; i=this.bsAtoms.nextSetBit$I(i + 1)) {
this.getAtom$I(i).intID=++p;
}
}, p$3);

Clazz.newMeth(C$, 'reindexAtomsAndBonds',  function () {
p$3.reserializeAtoms.apply(this, []);
for (var p=0, i=this.bsAtoms.nextSetBit$I(0); i >= 0; i=this.bsAtoms.nextSetBit$I(i + 1)) {
this.getAtom$I(i).index=p++;
}
for (var i=this.bsBonds.nextSetBit$I(0); i >= 0; i=this.bsBonds.nextSetBit$I(i + 1)) {
var b=this.getBond$I(i);
b.atomIndex1=b.atom1.index;
b.atomIndex2=b.atom2.index;
}
}, p$3);

Clazz.newMeth(C$, 'fixConnections',  function () {
for (var i=this.getAtomCount$(); --i >= 0; ) {
var a=this.getAtom$I(i);
if (a.isFragment || a.hasMultipleAttachments ) a.fixAttachments$();
}
for (var i=0, n=this.getBondCount$(); i < n; i++) {
var b=this.getBond$I(i);
if (b == null ) {
continue;
}var a1=b.atom1;
var a2=b.atom2;
a1.isConnected=true;
a2.isConnected=true;
if (this.nostereo.contains$O(a1) != this.nostereo.contains$O(a2) ) {
b.order=1;
}}
}, p$3);

Clazz.newMeth(C$, 'fixBracketedGroups',  function () {
if (this.bracketedGroups == null ) return;
for (var i=this.bracketedGroups.size$(); --i >= 0; ) {
this.bracketedGroups.removeItemAt$I(i).process$();
}
}, p$3);

Clazz.newMeth(C$, 'dumpGraph$',  function () {
for (var i=0, n=this.getAtomCount$(); i < n; i++) {
var a=this.getAtom$I(i);
System.out.println$S("CDXMLP " + i + " id=" + a.id + a.bsConnections + " cid=" + a.clonedIndex + " fa=" + a.bsFragmentAtoms + " xp=" + a.isExternalPt + " ifd=" + a.innerFragmentID + " ofd= " + a.outerFragmentID );
}
for (var i=0, n=this.getBondCount$(); i < n; i++) {
var b=this.getBond$I(i);
System.out.println$S("CDXMLP bond " + i + " " + b.atomIndex1 + " " + b.atomIndex2 + b );
}
System.out.println$O(this.bondIDMap);
return;
});

Clazz.newMeth(C$, 'centerAndScale',  function () {
if (this.minX > this.maxX ) return;
var sum=0;
var n=0;
var lenH=1;
for (var i=this.getBondCount$(); --i >= 0; ) {
var b=this.getBond$I(i);
var a1=b.atom1;
var a2=b.atom2;
var d=a1.distance$org_jmol_adapter_readers_xml_CDXMLParser_CDNode(a2);
if (a1.elementNumber > 1 && a2.elementNumber > 1 ) {
sum+=d;
++n;
} else {
lenH=d;
}}
var f=(sum > 0  ? 1.45 * n / sum : lenH > 0  ? 1 / lenH : 1);
if (f > 0.5 ) f=1;
var cx=(this.maxX + this.minX) / 2;
var cy=(this.maxY + this.minY) / 2;
var cz=(this.maxZ + this.minZ) / 2;
for (var i=this.getAtomCount$(); --i >= 0; ) {
var a=this.getAtom$I(i);
a.x=(a.x - cx) * f;
a.y=(a.y - cy) * f;
a.z=(a.z - cz) * f;
}
}, p$3);

Clazz.newMeth(C$, 'getAtom$I',  function (i) {
return this.atoms.get$I(i);
});

Clazz.newMeth(C$, 'addAtom$org_jmol_adapter_readers_xml_CDXMLParser_CDNode',  function (atom) {
this.atoms.addLast$O(atom);
this.bsAtoms.set$I(atom.index);
return atom;
});

Clazz.newMeth(C$, 'getAtomCount$',  function () {
return this.atoms.size$();
});

Clazz.newMeth(C$, 'addBond$org_jmol_adapter_readers_xml_CDXMLParser_CDBond',  function (b) {
this.bsBonds.set$I(b.index=this.getBondCount$());
this.bonds.addLast$O(b);
return b;
});

Clazz.newMeth(C$, 'getBond$I',  function (i) {
return this.bonds.get$I(i);
});

Clazz.newMeth(C$, 'getBondCount$',  function () {
return this.bonds.size$();
});

Clazz.newMeth(C$, 'finalizeParsing$',  function () {
p$3.fixConnections.apply(this, []);
p$3.fixInvalidAtoms.apply(this, []);
p$3.fixBracketedGroups.apply(this, []);
p$3.centerAndScale.apply(this, []);
p$3.reindexAtomsAndBonds.apply(this, []);
});
var $s$ = new Int16Array(1);
;
(function(){/*i*/var C$=Clazz.newInterface(P$.CDXMLParser, "CDXReaderI", function(){
});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.CDXMLParser, "CDNode", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'Cloneable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.isValid=true;
this.clonedIndex=-1;
},1);

C$.$fields$=[['Z',['isValid','isConnected','isExternalPt','isFragment','hasMultipleAttachments'],'D',['x','y','z'],'I',['index','intID','elementNumber','formalCharge','clonedIndex'],'S',['id','isotope','element','nodeType','warning','outerFragmentID','innerFragmentID','text'],'O',['parentNode','org.jmol.adapter.readers.xml.CDXMLParser.CDNode','orderedConnectionBonds','javajs.util.Lst','internalAtom','org.jmol.adapter.readers.xml.CDXMLParser.CDNode','orderedExternalPoints','javajs.util.Lst','attachments','String[]','+bondOrdering','+connectionOrder','attachedAtom','org.jmol.adapter.readers.xml.CDXMLParser.CDNode','bsConnections','javajs.util.BS','+bsFragmentAtoms']]]

Clazz.newMeth(C$, 'c$$I$S$S$S$org_jmol_adapter_readers_xml_CDXMLParser_CDNode',  function (index, id, nodeType, fragmentID, parent) {
;C$.$init$.apply(this);
if (id == null ) return;
this.id=id;
this.index=index;
this.outerFragmentID=fragmentID;
this.intID=Integer.parseInt$S(id);
this.nodeType=nodeType;
this.parentNode=parent;
this.bsConnections=Clazz.new_($I$(1,1));
this.isFragment="Fragment".equals$O(nodeType) || "Nickname".equals$O(nodeType) ;
this.isExternalPt="ExternalConnectionPoint".equals$O(nodeType);
if (this.isFragment) {
this.bsFragmentAtoms=Clazz.new_($I$(1,1));
} else if (parent != null  && !this.isExternalPt ) {
if (parent.bsFragmentAtoms == null ) {
parent.isFragment=true;
parent.bsFragmentAtoms=Clazz.new_($I$(1,1));
}parent.bsFragmentAtoms.set$I(index);
}}, 1);

Clazz.newMeth(C$, 'set$D$D$D',  function (x, y, z) {
this.x=x;
this.y=y;
this.z=z;
});

Clazz.newMeth(C$, 'setInnerFragmentID$S',  function (id) {
this.innerFragmentID=id;
});

Clazz.newMeth(C$, 'setBondOrdering$SA',  function (bondOrdering) {
this.bondOrdering=bondOrdering;
});

Clazz.newMeth(C$, 'setConnectionOrder$SA',  function (connectionOrder) {
this.connectionOrder=connectionOrder;
});

Clazz.newMeth(C$, 'setMultipleAttachments$SA',  function (attachments) {
this.attachments=attachments;
this.hasMultipleAttachments=true;
});

Clazz.newMeth(C$, 'addExternalPoint$org_jmol_adapter_readers_xml_CDXMLParser_CDNode',  function (externalPoint) {
if (this.orderedExternalPoints == null ) this.orderedExternalPoints=Clazz.new_($I$(2,1));
var i=this.orderedExternalPoints.size$();
while (--i >= 0 && this.orderedExternalPoints.get$I(i).intID >= externalPoint.internalAtom.intID ){
}
this.orderedExternalPoints.add$I$O(++i, externalPoint);
});

Clazz.newMeth(C$, 'setInternalAtom$org_jmol_adapter_readers_xml_CDXMLParser_CDNode',  function (a) {
this.internalAtom=a;
if (this.parentNode != null ) {
this.parentNode.addExternalPoint$org_jmol_adapter_readers_xml_CDXMLParser_CDNode(this);
}});

Clazz.newMeth(C$, 'addAttachedAtom$org_jmol_adapter_readers_xml_CDXMLParser_CDBond$I',  function (bond, pt) {
if (this.orderedConnectionBonds == null ) this.orderedConnectionBonds=Clazz.new_($I$(2,1));
var i=this.orderedConnectionBonds.size$();
while (--i >= 0 && (this.orderedConnectionBonds.get$I(i)[0]).intValue$() > pt ){
}
this.orderedConnectionBonds.add$I$O(++i, Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(pt), bond]));
});

Clazz.newMeth(C$, 'fixAttachments$',  function () {
if (this.hasMultipleAttachments && this.attachedAtom != null  ) {
var order=this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].rdr.getBondOrder$S("partial");
var a1=this.attachedAtom;
for (var i=this.attachments.length; --i >= 0; ) {
var a=this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].objectsByID.get$O(this.attachments[i]);
if (a != null ) {
this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].addBond$org_jmol_adapter_readers_xml_CDXMLParser_CDBond.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLParser'], [Clazz.new_($I$(3,1).c$$S$S$S$I,[this, null, null, a1.id, a.id, order])]);
}}
}if (this.orderedExternalPoints == null  || this.text == null  ) return;
var n=this.orderedExternalPoints.size$();
if (n != this.orderedConnectionBonds.size$()) {
System.err.println$S("XmlCdxReader cannot fix attachments for fragment " + this.text);
return;
}if (this.bondOrdering == null ) {
this.bondOrdering=Clazz.array(String, [n]);
for (var i=0; i < n; i++) {
this.bondOrdering[i]=(this.orderedConnectionBonds.get$I(i)[1]).id;
}
}if (this.connectionOrder == null ) {
this.connectionOrder=Clazz.array(String, [n]);
for (var i=0; i < n; i++) {
this.connectionOrder[i]=this.orderedExternalPoints.get$I(i).id;
}
}for (var i=0; i < n; i++) {
var b=this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].objectsByID.get$O(this.bondOrdering[i]);
var a=(this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].objectsByID.get$O(this.connectionOrder[i])).internalAtom;
p$1.updateExternalBond$org_jmol_adapter_readers_xml_CDXMLParser_CDBond$org_jmol_adapter_readers_xml_CDXMLParser_CDNode.apply(this, [b, a]);
}
});

Clazz.newMeth(C$, 'updateExternalBond$org_jmol_adapter_readers_xml_CDXMLParser_CDBond$org_jmol_adapter_readers_xml_CDXMLParser_CDNode',  function (bond2f, intAtom) {
this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].bsBonds.set$I(bond2f.index);
bond2f.disconnect$();
if (bond2f.atomIndex2 == this.index) {
bond2f.connect$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode(bond2f.atom1, intAtom);
} else if (bond2f.atomIndex1 == this.index) {
bond2f.connect$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode(intAtom, bond2f.atom2);
} else {
System.err.println$S("CDXMLParser attachment failed! " + intAtom + " " + bond2f );
}}, p$1);

Clazz.newMeth(C$, 'clone$',  function () {
var a;
try {
a=Clazz.clone(this);
a.index=this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].atoms.size$();
a.id=this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].nextID$.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLParser'], []);
this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].mapCloned.put$O$O(this.id, a);
a.clonedIndex=this.index;
a.bsConnections=Clazz.new_($I$(1,1));
this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].objectsByID.put$O$O(a.id, a);
this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].addAtom$org_jmol_adapter_readers_xml_CDXMLParser_CDNode.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLParser'], [a]);
return a;
} catch (e) {
if (Clazz.exceptionOf(e,"CloneNotSupportedException")){
return null;
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'toString',  function () {
return "[CDNode " + this.id + " " + this.elementNumber + " index=" + this.index + " ext=" + this.isExternalPt + " frag=" + this.isFragment + " " + " " + new Double(this.x).toString() + " " + new Double(this.y).toString() + "]" ;
});

Clazz.newMeth(C$, 'distance$org_jmol_adapter_readers_xml_CDXMLParser_CDNode',  function (a2) {
var dx=(this.x - a2.x);
var dy=(this.y - a2.y);
return Math.sqrt(dx * dx + dy * dy);
});

Clazz.newMeth(C$, 'addBracketedAtoms$javajs_util_BS',  function (bsBracketed) {
if (this.isFragment) bsBracketed.or$javajs_util_BS(this.bsFragmentAtoms);
 else if (!this.isExternalPt) bsBracketed.set$I(this.index);
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.CDXMLParser, "CDBond", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'Cloneable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['invalidated'],'I',['atomIndex1','atomIndex2','order','index'],'S',['id','id1','id2'],'O',['atom1','org.jmol.adapter.readers.xml.CDXMLParser.CDNode','+atom2']]]

Clazz.newMeth(C$, 'c$$S$S$S$I',  function (id, id1, id2, order) {
;C$.$init$.apply(this);
if (id1 == null ) return;
this.id=(id == null  ? this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].nextID$.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLParser'], []) : id);
this.id1=id1;
this.id2=id2;
this.order=order;
this.atom1=this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].objectsByID.get$O(id1);
this.atom2=this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].objectsByID.get$O(id2);
this.atomIndex1=this.atom1.index;
this.atomIndex2=this.atom2.index;
this.atom1.bsConnections.set$I(this.atomIndex2);
this.atom2.bsConnections.set$I(this.atomIndex1);
this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].bondIDMap.put$O$O($I$(4).getBondKey$I$I(this.atomIndex1, this.atomIndex2), this);
}, 1);

Clazz.newMeth(C$, 'connect$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode',  function (atomA, atomB) {
this.atom1=atomA;
this.atomIndex1=atomA.index;
this.atom2=atomB;
this.atomIndex2=atomB.index;
atomA.bsConnections.set$I(atomB.index);
atomB.bsConnections.set$I(atomA.index);
this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].bondIDMap.put$O$O($I$(4).getBondKey$I$I(this.atomIndex1, this.atomIndex2), this);
});

Clazz.newMeth(C$, 'disconnect$',  function () {
this.atom1.bsConnections.clear$I(this.atomIndex2);
this.atom2.bsConnections.clear$I(this.atomIndex1);
this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].bondIDMap.remove$O($I$(4).getBondKey$I$I(this.atomIndex1, this.atomIndex2));
});

Clazz.newMeth(C$, 'getOtherNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode',  function (a) {
return this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].getAtom$I.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLParser'], [this.atomIndex1 == a.index ? this.atomIndex2 : this.atomIndex1]);
});

Clazz.newMeth(C$, 'invalidate$',  function () {
this.invalidated=true;
this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].bsBonds.clear$I(this.index);
this.atomIndex1=this.atomIndex2=-1;
});

Clazz.newMeth(C$, 'isValid$',  function () {
return (!this.invalidated && this.atom1.intID >= 0  && this.atom2.intID >= 0 );
});

Clazz.newMeth(C$, 'toString',  function () {
return "[CDBond index " + this.index + " id " + this.id + " v=" + this.isValid$() + " id1=" + this.id1 + "/" + this.atom1.index + "/" + this.atom1.clonedIndex + " id2=" + this.id2 + "/" + this.atom2.index + "/" + this.atom2.clonedIndex + "]" ;
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.CDXMLParser, "BracketedGroup", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.bondIDs=Clazz.array(String, [2]);
this.innerAtomIDs=Clazz.array(String, [2]);
},1);

C$.$fields$=[['I',['repeatCount','pt'],'S',['id'],'O',['ids','String[]','+bondIDs','+innerAtomIDs']]]

Clazz.newMeth(C$, 'c$$S$SA$I',  function (id, ids, repeatCount) {
;C$.$init$.apply(this);
this.id=id;
this.ids=ids;
this.repeatCount=repeatCount;
}, 1);

Clazz.newMeth(C$, 'addCrossing$S$S',  function (innerAtomID, bondID) {
if (this.pt == 2) {
System.err.println$S("BracketedGroup has more than two crossings");
return;
}this.bondIDs[this.pt]=bondID;
this.innerAtomIDs[this.pt]=innerAtomID;
++this.pt;
});

Clazz.newMeth(C$, 'process$',  function () {
if (this.pt != 2 || this.repeatCount < 2 ) return;
var b1=this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].objectsByID.get$O(this.bondIDs[1]);
var a1i=this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].objectsByID.get$O(this.innerAtomIDs[1]);
var a2i=this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].objectsByID.get$O(this.innerAtomIDs[0]);
var b2=this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].objectsByID.get$O(this.bondIDs[0]);
var a2o=b2.getOtherNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode(a2i);
var bsTrailingAtoms=Clazz.new_($I$(1,1));
p$2.buildBranch$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$javajs_util_BS$javajs_util_BS$org_jmol_adapter_readers_xml_CDXMLParser_CDNodeA.apply(this, [a2i, a2o, null, null, bsTrailingAtoms, null, null]);
var offset=Clazz.array(Double.TYPE, -1, [a2o.x - a1i.x, a2o.y - a1i.y, a2o.z - a1i.z]);
var bsBracketed=Clazz.new_($I$(1,1));
for (var i=this.ids.length; --i >= 0; ) {
var node=this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].objectsByID.get$O(this.ids[i]);
node.addBracketedAtoms$javajs_util_BS(bsBracketed);
}
var a1=a1i;
var a2iLast=a2i;
for (var i=1; i < this.repeatCount; i++) {
var nAtoms=this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].getAtomCount$.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLParser'], []);
var newNodes=p$2.duplicateBracketAtoms$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$javajs_util_BS.apply(this, [a1i, a2i, bsBracketed]);
a1=newNodes[0];
p$2.patch$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDBond$org_jmol_adapter_readers_xml_CDXMLParser_CDNode.apply(this, [a2iLast, b1, a1]);
a2iLast=newNodes[1];
p$2.shiftAtoms$I$DA$I$javajs_util_BS.apply(this, [nAtoms, offset, i, null]);
}
p$2.patch$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDBond$org_jmol_adapter_readers_xml_CDXMLParser_CDNode.apply(this, [a2iLast, b2, a2o]);
p$2.shiftAtoms$I$DA$I$javajs_util_BS.apply(this, [0, offset, this.repeatCount - 1, bsTrailingAtoms]);
b2.invalidate$();
});

Clazz.newMeth(C$, 'shiftAtoms$I$DA$I$javajs_util_BS',  function (firstAtom, d, multiplier, bs) {
if (bs == null ) {
for (var i=this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].getAtomCount$.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLParser'], []); --i >= firstAtom; ) {
var a=this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].getAtom$I.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLParser'], [i]);
a.x+=d[0] * multiplier;
a.y+=d[1] * multiplier;
a.z+=d[2] * multiplier;
}
} else {
for (var i=bs.nextSetBit$I(0); i >= 0; i=bs.nextSetBit$I(i + 1)) {
var a=this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].getAtom$I.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLParser'], [i]);
a.x+=d[0] * multiplier;
a.y+=d[1] * multiplier;
a.z+=d[2] * multiplier;
}
}}, p$2);

Clazz.newMeth(C$, 'duplicateBracketAtoms$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$javajs_util_BS',  function (a1i, a2i, bsBracketed) {
this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].mapCloned=Clazz.new_($I$(5,1));
var aNew=a1i.clone$();
var a12i=Clazz.array($I$(6), -1, [aNew, a1i === a2i  ? aNew : null]);
var bsDone=Clazz.new_($I$(1,1));
p$2.buildBranch$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$javajs_util_BS$javajs_util_BS$org_jmol_adapter_readers_xml_CDXMLParser_CDNodeA.apply(this, [null, a1i, a2i, aNew, bsDone, bsBracketed, a12i]);
return a12i;
}, p$2);

Clazz.newMeth(C$, 'buildBranch$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$javajs_util_BS$javajs_util_BS$org_jmol_adapter_readers_xml_CDXMLParser_CDNodeA',  function (prev, aRoot, aEnd, a, bsDone, bsBracketed, a12i) {
bsDone.set$I(aRoot.index);
var aNext=null;
for (var i=aRoot.bsConnections.nextSetBit$I(0); i >= 0; i=aRoot.bsConnections.nextSetBit$I(i + 1)) {
var aBranch=this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].getAtom$I.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLParser'], [i]);
if (aBranch === prev ) continue;
var isNew=!bsDone.get$I(i);
if (bsBracketed != null ) {
if (!bsBracketed.get$I(i) || aBranch.isExternalPt ) continue;
var bBranch=this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].getBond$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLParser'], [aRoot, aBranch]);
aNext=(isNew ? aBranch.clone$() : this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].mapCloned.get$O(aBranch.id));
if (aBranch === aEnd  && a12i[1] == null  ) {
a12i[1]=aNext;
}var b=(bBranch.atom1 === aBranch  ? Clazz.new_($I$(3,1).c$$S$S$S$I,[this, null, null, aNext.id, a.id, bBranch.order]) : Clazz.new_($I$(3,1).c$$S$S$S$I,[this, null, null, a.id, aNext.id, bBranch.order]));
this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].addBond$org_jmol_adapter_readers_xml_CDXMLParser_CDBond.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLParser'], [b]);
}if (isNew) {
p$2.buildBranch$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$javajs_util_BS$javajs_util_BS$org_jmol_adapter_readers_xml_CDXMLParser_CDNodeA.apply(this, [aRoot, aBranch, aEnd, aNext, bsDone, bsBracketed, a12i]);
}}
}, p$2);

Clazz.newMeth(C$, 'patch$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDBond$org_jmol_adapter_readers_xml_CDXMLParser_CDNode',  function (a1, b, a2) {
var b1=this.b$['org.jmol.adapter.readers.xml.CDXMLParser'].addBond$org_jmol_adapter_readers_xml_CDXMLParser_CDBond.apply(this.b$['org.jmol.adapter.readers.xml.CDXMLParser'], [Clazz.new_($I$(3,1).c$$S$S$S$I,[this, null, null, a1.id, a2.id, b.order])]);
b1.disconnect$();
b1.connect$org_jmol_adapter_readers_xml_CDXMLParser_CDNode$org_jmol_adapter_readers_xml_CDXMLParser_CDNode(a1, a2);
}, p$2);

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:40 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
