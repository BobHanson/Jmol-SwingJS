(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.spartan"),p$1={},I$=[[0,'javajs.util.PT','org.jmol.adapter.smarter.AtomSetCollectionReader','org.jmol.util.Logger','org.jmol.adapter.smarter.Bond']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SpartanInputReader", null, 'org.jmol.adapter.readers.quantum.BasisFunctionReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.bondData="";
this.constraints="";
},1);

C$.$fields$=[['I',['modelAtomCount'],'S',['bondData','constraints']]]

Clazz.newMeth(C$, 'readInputRecords$',  function () {
var ac0=this.asc.ac;
var modelName=p$1.readInputHeader.apply(this, []);
while (this.rd$() != null ){
var tokens=this.getTokens$();
if (tokens.length == 2 && this.parseIntStr$S(tokens[0]) != -2147483648  && this.parseIntStr$S(tokens[1]) >= 0 ) break;
}
if (this.line == null ) return null;
p$1.readInputAtoms.apply(this, []);
this.discardLinesUntilContains$S("ATOMLABELS");
if (this.line != null ) p$1.readAtomNames.apply(this, []);
if (this.modelAtomCount > 1) {
this.discardLinesUntilContains$S("HESSIAN");
if (this.line != null ) p$1.readBonds$I.apply(this, [ac0]);
if (this.line != null  && this.line.indexOf$S("BEGINCONSTRAINTS") >= 0 ) p$1.readConstraints.apply(this, []);
}return modelName;
});

Clazz.newMeth(C$, 'readConstraints',  function () {
this.constraints="";
while (this.rd$() != null  && this.line.indexOf$S("END") < 0 )this.constraints+=(this.constraints === ""  ? "" : "\n") + this.line;

this.rd$();
if (this.constraints.length$() == 0) return;
this.asc.setCurrentModelInfo$S$O("constraints", this.constraints);
this.asc.setAtomSetModelProperty$S$S(".PATH", "EnergyProfile");
this.asc.setAtomSetModelProperty$S$S("Constraint", this.constraints);
}, p$1);

Clazz.newMeth(C$, 'readTransform$',  function () {
this.rd$();
var tokens=$I$(1,"getTokens$S",[this.rd$() + " " + this.rd$() ]);
this.setTransform$D$D$D$D$D$D$D$D$D(this.parseDoubleStr$S(tokens[0]), this.parseDoubleStr$S(tokens[1]), this.parseDoubleStr$S(tokens[2]), this.parseDoubleStr$S(tokens[4]), this.parseDoubleStr$S(tokens[5]), this.parseDoubleStr$S(tokens[6]), this.parseDoubleStr$S(tokens[8]), this.parseDoubleStr$S(tokens[9]), this.parseDoubleStr$S(tokens[10]));
});

Clazz.newMeth(C$, 'readInputHeader',  function () {
while (this.rd$() != null  && !this.line.startsWith$S(" ") ){
}
this.rd$();
return this.line.substring$I$I(0, (this.line + ";").indexOf$S(";")).trim$();
}, p$1);

Clazz.newMeth(C$, 'readInputAtoms',  function () {
this.modelAtomCount=0;
while (this.rd$() != null  && !this.line.startsWith$S("ENDCART") ){
var tokens=this.getTokens$();
this.addAtomXYZSymName$SA$I$S$S(tokens, 1, $I$(2,"getElementSymbol$I",[this.parseIntStr$S(tokens[0])]), null);
++this.modelAtomCount;
}
if (this.debugging) $I$(3).debug$S(this.asc.ac + " atoms read");
}, p$1);

Clazz.newMeth(C$, 'readAtomNames',  function () {
var atom0=this.asc.ac - this.modelAtomCount;
for (var i=0; i < this.modelAtomCount; i++) {
this.line=this.rd$().trim$();
var name=this.line.substring$I$I(1, this.line.length$() - 1);
this.asc.atoms[atom0 + i].atomName=name;
}
}, p$1);

Clazz.newMeth(C$, 'readBonds$I',  function (ac0) {
var nAtoms=this.modelAtomCount;
this.bondData="";
while (this.rd$() != null  && !this.line.startsWith$S("ENDHESS") ){
var tokens=this.getTokens$();
this.bondData+=this.line + " ";
if (nAtoms == 0) {
var sourceIndex=this.parseIntStr$S(tokens[0]) - 1 + ac0;
var targetIndex=this.parseIntStr$S(tokens[1]) - 1 + ac0;
var bondOrder=this.parseIntStr$S(tokens[2]);
if (bondOrder > 0) {
this.asc.addBond$org_jmol_adapter_smarter_Bond(Clazz.new_([sourceIndex, targetIndex, bondOrder < 4 ? bondOrder : bondOrder == 5 ? 515 : 1],$I$(4,1).c$$I$I$I));
}} else {
nAtoms-=tokens.length;
}}
this.rd$();
if (this.debugging) $I$(3).debug$S(this.asc.bondCount + " bonds read");
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-14 10:10:17 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
