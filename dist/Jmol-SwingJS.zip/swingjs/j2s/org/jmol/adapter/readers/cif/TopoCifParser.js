(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.cif"),p$1={},p$2={},p$3={},p$4={},I$=[[0,'javajs.util.P3d','org.jmol.adapter.readers.cif.TopoCifParser','javajs.util.Lst',['org.jmol.adapter.readers.cif.TopoCifParser','.TNode'],'java.util.Hashtable',['org.jmol.adapter.readers.cif.TopoCifParser','.TLink'],['org.jmol.adapter.readers.cif.TopoCifParser','.TAtom'],'org.jmol.adapter.readers.cif.Cif2DataParser','javajs.util.M4d','org.jmol.symmetry.SymmetryOperation','javajs.util.BS','org.jmol.api.JmolAdapter','org.jmol.util.JmolMolecule',['org.jmol.adapter.readers.cif.TopoCifParser','.TNet']]],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TopoCifParser", function(){
Clazz.newInstance(this, arguments,0,C$);
}, null, [['org.jmol.adapter.readers.cif.CifReader','org.jmol.adapter.readers.cif.CifReader.Parser']]);
C$.$classes$=[['TPoint',10],['TNet',2],['TAtom',2],['TNode',2],['TLink',2]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.atoms=Clazz.new_($I$(3,1));
this.nodes=Clazz.new_($I$(3,1));
this.links=Clazz.new_($I$(3,1));
this.nets=Clazz.new_($I$(3,1));
this.temp1=Clazz.new_($I$(1,1));
this.temp2=Clazz.new_($I$(1,1));
this.ac0=-1;
this.netNotes="";
},1);

C$.$fields$=[['I',['netCount','linkCount','atomCount','ac0','bc0','i0','b0'],'S',['failed','allowedTypes','netNotes','selectedNet'],'O',['reader','org.jmol.adapter.readers.cif.CifReader','atoms','javajs.util.Lst','+nodes','+links','+nets','singleNet','org.jmol.adapter.readers.cif.TopoCifParser.TNet','temp1','javajs.util.T3d','+temp2','cifParser','javajs.api.GenericCifDataParser','ops','javajs.util.M4d[]','sym','org.jmol.symmetry.Symmetry']]
,['D',['ERROR_TOLERANCE'],'S',['linkTypes'],'O',['topolFields','String[]','ZERO','javajs.util.P3d']]]

Clazz.newMeth(C$, 'getBondType$S$I',  function (type, order) {
if (type == null ) return 0;
type=type.toUpperCase$();
if (type.equals$O("V")) return (order == 0 ? 1 : order);
if (type.equals$O("sb")) type="?";
switch ((type.charCodeAt$I(0))) {
case 86:
return 14;
}
if (type.length$() > 3) type=type.substring$I$I(0, 3);
return Math.max(1, (C$.linkTypes.indexOf$S(type)/3|0));
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'setReader$org_jmol_adapter_readers_cif_CifReader',  function (reader) {
if (!reader.checkFilterKey$S("TOPOL")) {
reader.appendLoadNote$S("This file has Topology analysis records.\nUse LOAD \"\" {1 1 1} FILTER \"TOPOL\"  to load the topology.");
return this;
}this.reader=reader;
var net=reader.getFilter$S("TOPOLNET=");
this.selectedNet=net;
var types=reader.getFilter$S("TOPOS_TYPES=");
if (types == null ) types=reader.getFilter$S("TOPOS_TYPE=");
if (types != null  && types.length$() > 0 ) {
types="+" + types.toLowerCase$() + "+" ;
this.allowedTypes=types;
}this.i0=reader.baseAtomIndex;
this.b0=reader.baseBondIndex;
return this;
});

Clazz.newMeth(C$, 'ProcessRecord$S$S',  function (key, data) {
if (this.reader == null  || this.failed != null  ) {
return;
}var pt=key.indexOf$S(".");
if (pt < 0) {
pt=key.indexOf$I$I("_", key.indexOf$I$I("_", 1) + 1);
if (pt < 0) return;
key=key.substring$I$I(0, pt) + '.' + key.substring$I(pt + 1) ;
}this.processBlock$S(key);
});

Clazz.newMeth(C$, 'processBlock$S',  function (key) {
if (this.reader == null  || this.failed != null  ) {
return false;
}if (this.ac0 < 0) {
this.reader.asc.firstAtomToBond=this.reader.asc.getAtomSetAtomIndex$I(this.reader.asc.iSet);
this.ac0=this.reader.asc.ac;
this.bc0=this.reader.asc.bondCount;
}if (this.reader.ucItems != null ) {
this.reader.allow_a_len_1=true;
for (var i=0; i < 6; i++) this.reader.setUnitCellItem$I$D(i, this.reader.ucItems[i]);

}this.reader.parseLoopParameters$SA(C$.topolFields);
this.cifParser=this.reader.cifParser;
if (key.startsWith$S("_topol_net")) {
p$4.processNets.apply(this, []);
} else if (key.startsWith$S("_topol_link")) {
p$4.processLinks.apply(this, []);
} else if (key.startsWith$S("_topol_node")) {
p$4.processNodes.apply(this, []);
} else if (key.startsWith$S("_topol_atom")) {
p$4.processAtoms.apply(this, []);
} else {
return false;
}return true;
});

Clazz.newMeth(C$, 'processNets',  function () {
while (this.cifParser.getData$()){
var id=p$4.getDataValue$B.apply(this, [0]);
var netLabel=p$4.getDataValue$B.apply(this, [1]);
if (id == null ) id="" + (this.netCount + 1);
var net=this.getNetFor$S$S$Z(id, netLabel, true);
net.specialDetails=p$4.getDataValue$B.apply(this, [2]);
net.line=this.reader.line;
}
}, p$4);

Clazz.newMeth(C$, 'processLinks',  function () {
while (this.cifParser.getData$()){
var t=p$4.getDataValue$B.apply(this, [18]);
var type=(t == null  ? null : t.toLowerCase$());
if (this.allowedTypes != null  && (type == null  || this.allowedTypes.indexOf$S("+" + type + "+" ) < 0 ) ) continue;
var link=Clazz.new_($I$(6,1),[this, null]);
link.type=type;
var t1=Clazz.array(Integer.TYPE, [3]);
var t2=Clazz.array(Integer.TYPE, [3]);
var n=this.cifParser.getColumnCount$();
for (var i=0; i < n; ++i) {
var tok=this.reader.fieldProperty$I(i);
var field=this.reader.field;
switch (tok) {
case 3:
link.id=field;
break;
case 4:
link.netID=field;
break;
case 5:
link.nodeIds[0]=field;
break;
case 6:
link.nodeIds[1]=field;
break;
case 56:
link.nodeLabels[0]=field;
break;
case 57:
link.nodeLabels[1]=field;
break;
case 46:
case 7:
link.symops[0]=p$4.getInt$S.apply(this, [field]) - 1;
break;
case 50:
case 12:
link.symops[1]=p$4.getInt$S.apply(this, [field]) - 1;
break;
case 21:
link.topoOrder=p$4.getInt$S.apply(this, [field]);
break;
case 54:
case 47:
case 48:
case 49:
case 8:
case 9:
case 10:
case 11:
t1=p$4.processTranslation$I$IA$S.apply(this, [tok, t1, field]);
break;
case 55:
case 51:
case 52:
case 53:
case 13:
case 14:
case 15:
case 16:
t2=p$4.processTranslation$I$IA$S.apply(this, [tok, t2, field]);
break;
case 17:
link.cartesianDistance=p$4.getFloat$S.apply(this, [field]);
break;
case 19:
link.multiplicity=p$4.getInt$S.apply(this, [field]);
break;
case 20:
link.voronoiAngle=p$4.getFloat$S.apply(this, [field]);
}
}
if (!link.setLink$IA$IA$S(t1, t2, this.reader.line)) {
this.failed="invalid link! " + link;
return;
}this.links.addLast$O(link);
}
}, p$4);

Clazz.newMeth(C$, 'processNodes',  function () {
while (this.cifParser.getData$()){
var node=Clazz.new_($I$(4,1),[this, null]);
var t=Clazz.array(Integer.TYPE, [3]);
var n=this.cifParser.getColumnCount$();
for (var i=0; i < n; ++i) {
var tok=this.reader.fieldProperty$I(i);
var field=this.reader.field;
switch (tok) {
case 22:
node.id=field;
break;
case 24:
node.label=field;
break;
case 23:
node.netID=field;
break;
case 25:
node.symop=p$4.getInt$S.apply(this, [field]) - 1;
break;
case 26:
case 27:
case 28:
case 29:
t=p$4.processTranslation$I$IA$S.apply(this, [tok, t, field]);
break;
case 30:
node.x=p$4.getFloat$S.apply(this, [field]);
break;
case 31:
node.y=p$4.getFloat$S.apply(this, [field]);
break;
case 32:
node.z=p$4.getFloat$S.apply(this, [field]);
break;
}
}
if (node.setNode$IA$S(t, this.reader.line)) this.nodes.addLast$O(node);
}
}, p$4);

Clazz.newMeth(C$, 'processAtoms',  function () {
while (this.cifParser.getData$()){
var atom=Clazz.new_($I$(7,1),[this, null]);
var t=Clazz.array(Integer.TYPE, [3]);
var n=this.cifParser.getColumnCount$();
for (var i=0; i < n; ++i) {
var tok=this.reader.fieldProperty$I(i);
var field=this.reader.field;
switch (tok) {
case 33:
atom.id=field;
break;
case 34:
atom.atomLabel=field;
break;
case 35:
atom.nodeID=field;
break;
case 36:
atom.linkID=field;
break;
case 37:
atom.symop=p$4.getInt$S.apply(this, [field]) - 1;
break;
case 38:
case 39:
case 40:
case 41:
t=p$4.processTranslation$I$IA$S.apply(this, [tok, t, field]);
break;
case 42:
atom.x=p$4.getFloat$S.apply(this, [field]);
break;
case 43:
atom.y=p$4.getFloat$S.apply(this, [field]);
break;
case 44:
atom.z=p$4.getFloat$S.apply(this, [field]);
break;
case 45:
atom.elementSymbol=field;
break;
}
}
if (atom.setAtom$IA$S(t, this.reader.line)) this.atoms.addLast$O(atom);
}
}, p$4);

Clazz.newMeth(C$, 'processTranslation$I$IA$S',  function (p, t, field) {
switch (p) {
case 54:
case 55:
case 8:
case 13:
case 26:
case 38:
t=$I$(8).getIntArrayFromStringList$S$I(field, 3);
break;
case 47:
case 51:
case 9:
case 14:
case 27:
case 39:
t[0]=p$4.getInt$S.apply(this, [field]);
break;
case 48:
case 52:
case 10:
case 15:
case 28:
case 40:
t[1]=p$4.getInt$S.apply(this, [field]);
break;
case 49:
case 53:
case 11:
case 16:
case 29:
case 41:
t[2]=p$4.getInt$S.apply(this, [field]);
break;
}
return t;
}, p$4);

Clazz.newMeth(C$, 'finalizeReader$',  function () {
if (this.reader == null  || this.reader.symops == null  ) return false;
this.cifParser=null;
this.reader.applySymmetryToBonds=true;
var symops=this.reader.symops;
var nOps=symops.size$();
this.ops=Clazz.array($I$(9), [nOps]);
var v=Clazz.array(Double.TYPE, [16]);
for (var i=0; i < nOps; i++) {
this.ops[i]=$I$(10,"getMatrixFromXYZ$S$DA$Z",["!" + symops.get$I(i), v, true]);
}
for (var i=0; i < this.atoms.size$(); i++) {
this.atoms.get$I(i).finalizeAtom$();
}
this.sym=this.reader.getSymmetry$();
for (var i=0; i < this.links.size$(); i++) {
this.links.get$I(i).finalizeLink$();
}
for (var i=this.links.size$(); --i >= 0; ) {
if (!this.links.get$I(i).finalized) this.links.removeItemAt$I(i);
}
if (this.reader.doApplySymmetry) {
this.reader.applySymmetryAndSetTrajectory$();
}if (this.selectedNet != null ) p$4.selectNet.apply(this, []);
return true;
});

Clazz.newMeth(C$, 'selectNet',  function () {
var net=this.getNetFor$S$S$Z(null, this.selectedNet, false);
if (net == null ) {
net=this.getNetFor$S$S$Z(this.selectedNet, null, false);
}if (net == null ) return;
var bsAtoms=this.reader.asc.getBSAtoms$I(-1);
var atoms=this.reader.asc.atoms;
for (var i=this.reader.asc.ac; --i >= 0; ) {
var a=atoms[i];
if (!(Clazz.instanceOf(a, "org.jmol.adapter.readers.cif.TopoCifParser.TPoint")) || (a).getNet$() !== net  ) {
bsAtoms.clear$I(i);
}}
}, p$4);

Clazz.newMeth(C$, 'finalizeSymmetry$Z',  function (haveSymmetry) {
if (this.reader == null  || !haveSymmetry  || this.links.size$() == 0 ) return;
var bsConnected=Clazz.new_($I$(11,1));
var bsAtoms=Clazz.new_($I$(11,1));
var nLinks=p$4.processAssociations$javajs_util_BS$javajs_util_BS.apply(this, [bsConnected, bsAtoms]);
var bsExclude=C$.shiftBits$javajs_util_BS$javajs_util_BS(bsAtoms, bsConnected);
if (!bsConnected.isEmpty$()) {
this.reader.asc.bsAtoms=bsAtoms;
this.reader.asc.atomSetInfo.put$O$O("bsExcludeBonding", bsExclude);
}this.reader.appendLoadNote$S("TopoCifParser created " + bsConnected.cardinality$() + " nodes and " + nLinks + " links" );
var info=Clazz.new_($I$(3,1));
for (var i=0, n=this.links.size$(); i < n; i++) {
info.addLast$O(this.links.get$I(i).getLinkInfo$());
}
this.reader.asc.setCurrentModelInfo$S$O("topology", info);
var script="if (autobond) {delete !connected && !(atomName LIKE \'*_Link*\' or atomName LIKE \'*_Node*\')}; display displayed or " + this.nets.get$I(0).label + "__*" ;
this.reader.addJmolScript$S(script);
for (var i=0; i < this.nets.size$(); i++) {
this.nets.get$I(i).finalizeNet$();
}
});

Clazz.newMeth(C$, 'shiftBits$javajs_util_BS$javajs_util_BS',  function (bsAtoms, bs) {
var bsNew=Clazz.new_($I$(11,1));
for (var pt=0, i=bsAtoms.nextSetBit$I(0); i >= 0; i=bsAtoms.nextSetBit$I(i + 1)) {
while (bsAtoms.get$I(i)){
bsNew.setBitTo$I$Z(pt++, bs.get$I(i++));
}
}
return bsNew;
}, 1);

Clazz.newMeth(C$, 'processAssociations$javajs_util_BS$javajs_util_BS',  function (bsConnected, bsAtoms) {
var nlinks=0;
var bsAtoms0=this.reader.asc.bsAtoms;
var atoms=this.reader.asc.atoms;
for (var i=this.reader.asc.ac; --i >= this.ac0; ) {
var a=atoms[i];
if (bsAtoms0 != null  && !bsAtoms0.get$I(i) ) continue;
var idx=(Clazz.instanceOf(a, "org.jmol.adapter.readers.cif.TopoCifParser.TAtom") ? (a).idx1 : 0);
if (idx == -2147483648 || idx == 0 ) continue;
if (idx > 0) {
var node=this.getAssociatedNodeByIdx$I(idx - 1);
if (node.bsAtoms == null ) node.bsAtoms=Clazz.new_($I$(11,1));
node.bsAtoms.set$I(this.i0 + a.index);
} else {
var link=this.getAssoiatedLinkByIdx$I(-idx - 1);
if (link != null ) {
if (link.bsAtoms == null ) link.bsAtoms=Clazz.new_($I$(11,1));
link.bsAtoms.set$I(this.i0 + a.index);
}}bsAtoms.set$I(a.index);
}
var checkDistance=this.reader.doPackUnitCell;
var distance;
var bonds=this.reader.asc.bonds;
for (var i=this.reader.asc.bondCount; --i >= this.bc0; ) {
var b=bonds[i];
if (b.order >= 33554432) {
bonds[i]=null;
} else if (b.order >= 16777216) {
if (bsAtoms0 != null  && (!bsAtoms0.get$I(b.atomIndex1) || !bsAtoms0.get$I(b.atomIndex2) ) ) {
bonds[i]=null;
continue;
}b.order-=16777216;
var link=this.getAssoiatedLinkByIdx$I(b.order >> 4);
if (checkDistance && Math.abs((distance=this.calculateDistance$javajs_util_P3d$javajs_util_P3d(atoms[b.atomIndex1], atoms[b.atomIndex2])) - link.distance) >= C$.ERROR_TOLERANCE  ) {
System.err.println$S("Distance error! removed! distance=" + new Double(distance).toString() + " for " + link + link.linkNodes[0] + link.linkNodes[1] );
bonds[i]=null;
continue;
}if (link.bsBonds == null ) link.bsBonds=Clazz.new_($I$(11,1));
link.bsBonds.set$I(this.b0 + i);
switch (b.order & 15) {
default:
b.order=1;
break;
case 2:
b.order=2;
break;
case 3:
b.order=3;
break;
case 4:
b.order=4;
break;
case 5:
b.order=5;
break;
case 6:
b.order=6;
break;
case 10:
b.order=1;
break;
case 11:
case 12:
b.order=515;
break;
case 13:
b.order=2048;
break;
case 14:
b.order=33;
break;
}
bsConnected.set$I(b.atomIndex1);
bsConnected.set$I(b.atomIndex2);
++nlinks;
}}
bsAtoms.or$javajs_util_BS(bsConnected);
if (bsAtoms0 != null ) bsAtoms.and$javajs_util_BS(bsAtoms0);
for (var i=this.nodes.size$(); --i >= 0; ) {
var node=this.nodes.get$I(i);
if (node.bsAtoms != null ) {
node.bsAtoms=C$.shiftBits$javajs_util_BS$javajs_util_BS(bsAtoms, node.bsAtoms);
}}
for (var i=this.links.size$(); --i >= 0; ) {
var link=this.links.get$I(i);
if (link.bsAtoms != null ) {
link.bsAtoms=C$.shiftBits$javajs_util_BS$javajs_util_BS(bsAtoms, link.bsAtoms);
}}
return nlinks;
}, p$4);

Clazz.newMeth(C$, 'isEqualD$javajs_util_T3d$javajs_util_T3d$D',  function (p1, p2, d) {
return (Double.isNaN$D(d) || Math.abs(p1.distance$javajs_util_T3d(p2) - d) < C$.ERROR_TOLERANCE  );
}, 1);

Clazz.newMeth(C$, 'getDataValue$B',  function (key) {
var f=this.reader.getFieldString$B(key);
return ("\u0000".equals$O(f) ? null : f);
}, p$4);

Clazz.newMeth(C$, 'getInt$S',  function (f) {
return (f == null  ? -2147483648 : this.reader.parseIntStr$S(f));
}, p$4);

Clazz.newMeth(C$, 'getFloat$S',  function (f) {
return (f == null  ? NaN : this.reader.parseDoubleStr$S(f));
}, p$4);

Clazz.newMeth(C$, 'getMF$javajs_util_Lst',  function (tatoms) {
var n=tatoms.size$();
if (n < 2) return (n == 0 ? "" : tatoms.get$I(0).elementSymbol);
var atNos=Clazz.array(Integer.TYPE, [n]);
for (var i=0; i < n; i++) {
atNos[i]=$I$(12,"getElementNumber$S",[tatoms.get$I(i).getElementSymbol$()]);
}
var m=Clazz.new_($I$(13,1));
m.atNos=atNos;
return m.getMolecularFormula$Z$DA$Z(false, null, false);
}, 1);

Clazz.newMeth(C$, 'setTAtom$org_jmol_adapter_smarter_Atom$org_jmol_adapter_smarter_Atom',  function (a, b) {
b.setT$javajs_util_T3d(a);
b.formalCharge=a.formalCharge;
b.bondingRadius=a.bondingRadius;
}, 1);

Clazz.newMeth(C$, 'setElementSymbol$org_jmol_adapter_smarter_Atom$S',  function (a, sym) {
var name=a.atomName;
if (sym == null ) {
a.atomName=(a.atomName == null  ? "X" : a.atomName.substring$I(a.atomName.indexOf$I("_") + 1));
} else {
a.atomName=sym;
}a.getElementSymbol$();
a.atomName=name;
}, 1);

Clazz.newMeth(C$, 'applySymmetry$org_jmol_adapter_smarter_Atom$javajs_util_M4dA$I$javajs_util_T3d',  function (a, ops, op, t) {
if (op >= 0) {
if (op >= 1 || t.x != 0   || t.y != 0   || t.z != 0  ) {
if (op >= 1) ops[op].rotTrans$javajs_util_T3d(a);
a.add$javajs_util_T3d(t);
}}}, 1);

Clazz.newMeth(C$, 'getNetByID$S',  function (id) {
for (var i=this.nets.size$(); --i >= 0; ) {
var n=this.nets.get$I(i);
if (n.id.equalsIgnoreCase$S(id)) return n;
}
var n=Clazz.new_($I$(14,1).c$$I$S$S$S,[this, null, this.netCount++, id, "Net" + id, null]);
this.nets.addLast$O(n);
return n;
});

Clazz.newMeth(C$, 'getAtomFromName$S',  function (atomLabel) {
return (atomLabel == null  ? null : this.reader.asc.getAtomFromName$S(atomLabel));
});

Clazz.newMeth(C$, 'calculateDistance$javajs_util_P3d$javajs_util_P3d',  function (p1, p2) {
this.temp1.setT$javajs_util_T3d(p1);
this.temp2.setT$javajs_util_T3d(p2);
this.sym.toCartesian$javajs_util_T3d$Z(this.temp1, true);
this.sym.toCartesian$javajs_util_T3d$Z(this.temp2, true);
return this.temp1.distance$javajs_util_T3d(this.temp2);
});

Clazz.newMeth(C$, 'getNetFor$S$S$Z',  function (id, label, forceNew) {
var net=null;
if (id != null ) {
net=this.getNetByID$S(id);
if (net != null  && label != null   && forceNew ) net.label=label;
} else if (label != null ) {
for (var i=this.nets.size$(); --i >= 0; ) {
var n=this.nets.get$I(i);
if (n.label.equalsIgnoreCase$S(label)) {
net=n;
break;
}}
}if (net == null ) {
if (!forceNew) return null;
net=this.getNetByID$S(id == null  ? "1" : id);
}if (net != null  && label != null   && forceNew ) net.label=label;
return net;
});

Clazz.newMeth(C$, 'getAssociatedNodeByIdx$I',  function (idx) {
for (var i=this.nodes.size$(); --i >= 0; ) {
var n=this.nodes.get$I(i);
if (n.idx == idx) return n;
}
return null;
});

Clazz.newMeth(C$, 'getAssoiatedLinkByIdx$I',  function (idx) {
for (var i=this.links.size$(); --i >= 0; ) {
var l=this.links.get$I(i);
if (l.idx == idx) return l;
}
return null;
});

Clazz.newMeth(C$, 'findNode$S$I$javajs_util_P3d',  function (nodeID, op, trans) {
for (var i=this.nodes.size$(); --i >= 0; ) {
var n=this.nodes.get$I(i);
if (n.id.equals$O(nodeID) && (op < 0 && n.linkSymop == 0  && n.linkTrans.equals$O(C$.ZERO)  || n.linkSymop == op && n.linkTrans.equals$O(trans)  ) ) return n;
}
return null;
});

C$.$static$=function(){C$.$static$=0;
C$.linkTypes="?  SINDOUTRIQUAQUISEXSEPOCTAROPOLDELPI HBOVDW";
C$.ERROR_TOLERANCE=0.001;
C$.topolFields=Clazz.array(String, -1, ["_topol_net_id", "_topol_net_label", "_topol_net_special_details", "_topol_link_id", "_topol_link_net_id", "_topol_link_node_id_1", "_topol_link_node_id_2", "_topol_link_symop_id_1", "_topol_link_translation_1", "_topol_link_translation_1_x", "_topol_link_translation_1_y", "_topol_link_translation_1_z", "_topol_link_symop_id_2", "_topol_link_translation_2", "_topol_link_translation_2_x", "_topol_link_translation_2_y", "_topol_link_translation_2_z", "_topol_link_distance", "_topol_link_type", "_topol_link_multiplicity", "_topol_link_voronoi_solidangle", "_topol_link_order", "_topol_node_id", "_topol_node_net_id", "_topol_node_label", "_topol_node_symop_id", "_topol_node_translation", "_topol_node_translation_x", "_topol_node_translation_y", "_topol_node_translation_z", "_topol_node_fract_x", "_topol_node_fract_y", "_topol_node_fract_z", "_topol_atom_id", "_topol_atom_atom_label", "_topol_atom_node_id", "_topol_atom_link_id", "_topol_atom_symop_id", "_topol_atom_translation", "_topol_atom_translation_x", "_topol_atom_translation_y", "_topol_atom_translation_z", "_topol_atom_fract_x", "_topol_atom_fract_y", "_topol_atom_fract_z", "_topol_atom_element_symbol", "_topol_link_site_symmetry_symop_1", "_topol_link_site_symmetry_translation_1_x", "_topol_link_site_symmetry_translation_1_y", "_topol_link_site_symmetry_translation_1_z", "_topol_link_site_symmetry_symop_2", "_topol_link_site_symmetry_translation_2_x", "_topol_link_site_symmetry_translation_2_y", "_topol_link_site_symmetry_translation_2_z", "_topol_link_site_symmetry_translation_1", "_topol_link_site_symmetry_translation_2", "_topol_link_node_label_1", "_topol_link_node_label_2", "_topol_link_atom_label_1", "_topol_link_atom_label_2"]);
C$.ZERO=Clazz.new_($I$(1,1));
};
;
(function(){/*i*/var C$=Clazz.newInterface(P$.TopoCifParser, "TPoint", function(){
});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.TopoCifParser, "TNet", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['hasAtoms'],'I',['nLinks','nNodes','idx'],'S',['line','id','label','specialDetails']]]

Clazz.newMeth(C$, 'c$$I$S$S$S',  function (index, id, label, specialDetails) {
;C$.$init$.apply(this);
this.idx=index;
this.id=id;
this.label=label;
this.specialDetails=specialDetails;
}, 1);

Clazz.newMeth(C$, 'finalizeNet$',  function () {
if (this.id == null ) this.id="" + (this.idx + 1);
if (this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].selectedNet != null  && !this.label.equalsIgnoreCase$S(this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].selectedNet)  && !this.id.equalsIgnoreCase$S(this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].selectedNet) ) return;
var netKey="," + this.id + "," ;
if (this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].netNotes.indexOf$S(netKey) < 0) {
this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].reader.appendLoadNote$S("Net " + this.label + (this.specialDetails == null  ? "" : " '" + this.specialDetails + "'" ) + " created from " + this.nLinks + " links and " + this.nNodes + " nodes.\n" + "Use DISPLAY " + (this.hasAtoms ? this.label + "__* to display it without associated atoms\nUse DISPLAY " + this.label + "_* to display it with its associated atoms"  : this.label + "* to display it" + "" ) );
}});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.TopoCifParser, "TAtom", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'org.jmol.adapter.smarter.Atom', [['org.jmol.adapter.readers.cif.TopoCifParser','org.jmol.adapter.readers.cif.TopoCifParser.TPoint']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.symop=0;
this.trans=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['Z',['isFinalized'],'I',['symop','idx','idx1'],'S',['id','atomLabel','nodeID','linkID','line'],'O',['trans','javajs.util.P3d','net','org.jmol.adapter.readers.cif.TopoCifParser.TNet']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
var i=0;
}, 1);

Clazz.newMeth(C$, 'getTClone$',  function () {
try {
var ta=this.clone$();
ta.idx=this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].atomCount++;
return ta;
} catch (e) {
if (Clazz.exceptionOf(e,"CloneNotSupportedException")){
return null;
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'getNet$',  function () {
return this.net;
});

Clazz.newMeth(C$, 'setAtom$IA$S',  function (a, line) {
this.line=line;
if (Double.isNaN$D(this.x) != Double.isNaN$D(this.y)  || Double.isNaN$D(this.y) != Double.isNaN$D(this.z)  ) return false;
this.idx=this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].atomCount++;
if (Double.isNaN$D(this.x)) {
this.trans=$I$(1).new3$D$D$D(a[0], a[1], a[2]);
} else {
this.symop=0;
}this.atomName=this.atomLabel;
return true;
});

Clazz.newMeth(C$, 'finalizeAtom$',  function () {
if (this.isFinalized) return;
this.isFinalized=true;
var a=this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].getAtomFromName$S.apply(this.b$['org.jmol.adapter.readers.cif.TopoCifParser'], [this.atomLabel]);
$I$(2).setElementSymbol$org_jmol_adapter_smarter_Atom$S(this, this.elementSymbol);
if (a == null  && Double.isNaN$D(this.x) ) {
throw Clazz.new_(Clazz.load('Exception').c$$S,["_topol_atom: no atom " + this.atomLabel + " line=" + this.line ]);
}var node=null;
if (this.nodeID != null ) {
node=this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].findNode$S$I$javajs_util_P3d.apply(this.b$['org.jmol.adapter.readers.cif.TopoCifParser'], [this.nodeID, -1, null]);
}var link=null;
if (this.linkID != null ) {
link=p$1.getLinkById$S.apply(this, [this.linkID]);
}if (node == null  && link == null  ) {
System.out.println$S("TAtom " + this + " ignored" );
return;
}if (a != null  && Double.isNaN$D(this.x) ) {
$I$(2).setTAtom$org_jmol_adapter_smarter_Atom$org_jmol_adapter_smarter_Atom(a, this);
$I$(2).applySymmetry$org_jmol_adapter_smarter_Atom$javajs_util_M4dA$I$javajs_util_T3d(this, this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].ops, this.symop, this.trans);
}this.atomName=this.atomLabel;
if (node != null ) {
node.addAtom$org_jmol_adapter_readers_cif_TopoCifParser_TAtom(this);
}var ta=this;
if (link != null ) ta=link.addAtom$org_jmol_adapter_readers_cif_TopoCifParser_TAtom(this);
this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].reader.addCifAtom$org_jmol_adapter_smarter_Atom$S$S$S(this, this.atomName, null, null);
if (ta !== this ) this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].reader.addCifAtom$org_jmol_adapter_smarter_Atom$S$S$S(ta, this.atomName, null, null);
});

Clazz.newMeth(C$, 'getLinkById$S',  function (linkID) {
for (var i=this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].links.size$(); --i >= 0; ) {
var l=this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].links.get$I(i);
if (l.id.equalsIgnoreCase$S(linkID)) return l;
}
return null;
}, p$1);

Clazz.newMeth(C$, 'toString',  function () {
return this.line + " " + C$.superclazz.prototype.toString.apply(this, []) ;
});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.TopoCifParser, "TNode", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'org.jmol.adapter.smarter.Atom', [['org.jmol.adapter.readers.cif.TopoCifParser','org.jmol.adapter.readers.cif.TopoCifParser.TPoint']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.symop=0;
this.trans=Clazz.new_($I$(1,1));
this.bsAtoms=null;
this.linkSymop=0;
this.linkTrans=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['Z',['isFinalized'],'I',['symop','linkSymop','idx'],'S',['id','atomLabel','netID','label','line','mf'],'O',['trans','javajs.util.P3d','tatoms','javajs.util.Lst','bsAtoms','javajs.util.BS','linkTrans','javajs.util.P3d','net','org.jmol.adapter.readers.cif.TopoCifParser.TNet','atom','org.jmol.adapter.smarter.Atom']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
var i=0;
}, 1);

Clazz.newMeth(C$, 'c$$I$org_jmol_adapter_smarter_Atom$org_jmol_adapter_readers_cif_TopoCifParser_TNet$I$javajs_util_P3d',  function (idx, atom, net, op, trans) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
this.idx=idx;
this.atom=atom;
this.net=net;
this.linkSymop=op;
this.linkTrans=trans;
this.label=this.atomName=this.atomLabel=atom.atomName;
this.elementSymbol=atom.elementSymbol;
$I$(2).setTAtom$org_jmol_adapter_smarter_Atom$org_jmol_adapter_smarter_Atom(atom, this);
}, 1);

Clazz.newMeth(C$, 'getMolecularFormula$',  function () {
return (this.mf == null  ? (this.mf=$I$(2).getMF$javajs_util_Lst(this.tatoms)) : this.mf);
});

Clazz.newMeth(C$, 'getNet$',  function () {
return this.net;
});

Clazz.newMeth(C$, 'setNode$IA$S',  function (a, line) {
this.line=line;
if (this.tatoms == null ) {
if (Double.isNaN$D(this.x) != Double.isNaN$D(this.y)  || Double.isNaN$D(this.y) != Double.isNaN$D(this.z)  ) return false;
this.idx=this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].atomCount++;
if (Double.isNaN$D(this.x)) {
this.trans=$I$(1).new3$D$D$D(a[0], a[1], a[2]);
} else {
this.symop=0;
}}return true;
});

Clazz.newMeth(C$, 'addAtom$org_jmol_adapter_readers_cif_TopoCifParser_TAtom',  function (atom) {
if (this.tatoms == null ) this.tatoms=Clazz.new_($I$(3,1));
atom.atomName="Node_" + atom.nodeID + "_" + atom.atomLabel ;
this.tatoms.addLast$O(atom);
});

Clazz.newMeth(C$, 'finalizeNode$javajs_util_M4dA',  function (ops) {
if (this.isFinalized) return;
this.isFinalized=true;
if (this.net == null ) this.net=this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].getNetFor$S$S$Z.apply(this.b$['org.jmol.adapter.readers.cif.TopoCifParser'], [this.netID, null, true]);
var haveXYZ=!Double.isNaN$D(this.x);
var a;
if (this.tatoms == null ) {
a=null;
if (!haveXYZ) {
throw Clazz.new_(Clazz.load('Exception').c$$S,["_topol_node no atom " + this.atomLabel + " line=" + this.line ]);
}} else {
if (Double.isNaN$D(this.x)) p$2.setCentroid.apply(this, []);
if (this.tatoms.size$() == 1) {
var ta=this.tatoms.get$I(0);
this.elementSymbol=ta.elementSymbol;
this.atomLabel=ta.atomLabel;
this.formalCharge=ta.formalCharge;
this.tatoms=null;
} else {
this.net.hasAtoms=true;
this.elementSymbol="Xx";
for (var i=this.tatoms.size$(); --i >= 0; ) {
var ta=this.tatoms.get$I(i);
ta.idx1=this.idx + 1;
if (ta.atomName == null  || !ta.atomName.startsWith$S(this.net.label + "_") ) ta.atomName=this.net.label + "_" + ta.atomName ;
ta.net=this.net;
}
}a=this;
}if ((a != null  && a === this.atom  ) || !haveXYZ ) {
if (a !== this ) {
$I$(2).setTAtom$org_jmol_adapter_smarter_Atom$org_jmol_adapter_smarter_Atom(a, this);
}$I$(2).applySymmetry$org_jmol_adapter_smarter_Atom$javajs_util_M4dA$I$javajs_util_T3d(this, ops, this.symop, this.trans);
}this.atomName=this.net.label.replace$C$C(" ", "_") + "__";
if (this.label != null  && this.label.startsWith$S(this.atomName) ) {
this.atomName="";
}this.atomName+=(this.label != null  ? this.label : this.atomLabel != null  ? this.atomLabel : "Node_" + this.id);
p$2.addNode.apply(this, []);
});

Clazz.newMeth(C$, 'addNode',  function () {
this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].reader.addCifAtom$org_jmol_adapter_smarter_Atom$S$S$S(this, this.atomName, null, null);
++this.net.nNodes;
if (this.tatoms != null  && this.tatoms.size$() > 1 ) this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].reader.appendLoadNote$S("_topos_node " + this.id + " " + this.atomName + " has formula " + this.getMolecularFormula$() );
}, p$2);

Clazz.newMeth(C$, 'setCentroid',  function () {
this.x=this.y=this.z=0;
var n=this.tatoms.size$();
for (var i=n; --i >= 0; ) this.add$javajs_util_T3d(this.tatoms.get$I(i));

this.x/=n;
this.y/=n;
this.z/=n;
}, p$2);

Clazz.newMeth(C$, 'info$',  function () {
return "[node idx=" + this.idx + " id=" + this.id + " " + this.label + "/" + this.atomName + " " + C$.superclazz.prototype.toString.apply(this, []) + "]" ;
});

Clazz.newMeth(C$, 'toString',  function () {
return this.info$();
});

Clazz.newMeth(C$, 'copy$',  function () {
var node=this.clone$();
node.idx=this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].atomCount++;
if (node.isFinalized) p$2.addNode.apply(node, []);
if (this.tatoms != null ) {
node.tatoms=Clazz.new_($I$(3,1));
for (var i=0, n=this.tatoms.size$(); i < n; i++) {
var ta=this.tatoms.get$I(i).getTClone$();
node.tatoms.addLast$O(ta);
this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].reader.addCifAtom$org_jmol_adapter_smarter_Atom$S$S$S(ta, ta.atomName, null, null);
}
}return node;
});

Clazz.newMeth(C$, 'clone$',  function () {
try {
return Clazz.clone(this);
} catch (e) {
if (Clazz.exceptionOf(e,"CloneNotSupportedException")){
return null;
} else {
throw e;
}
}
});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.TopoCifParser, "TLink", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'org.jmol.adapter.smarter.Bond');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.nodeIds=Clazz.array(String, [2]);
this.nodeLabels=Clazz.array(String, [2]);
this.symops=Clazz.array(Integer.TYPE, [2]);
this.translations=Clazz.array($I$(1), [2]);
this.type="";
this.linkNodes=Clazz.array($I$(4), [2]);
},1);

C$.$fields$=[['Z',['finalized'],'D',['voronoiAngle','cartesianDistance'],'I',['multiplicity','topoOrder','idx','typeBondOrder'],'S',['id','netID','netLabel','type','line','mf'],'O',['nodeIds','String[]','+nodeLabels','symops','int[]','translations','javajs.util.P3d[]','net','org.jmol.adapter.readers.cif.TopoCifParser.TNet','linkNodes','org.jmol.adapter.readers.cif.TopoCifParser.TNode[]','tatoms','javajs.util.Lst','bsAtoms','javajs.util.BS','+bsBonds']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$I$I$I.apply(this,[0, 0, 0]);C$.$init$.apply(this);
var i=0;
}, 1);

Clazz.newMeth(C$, 'setLink$IA$IA$S',  function (t1, t2, line) {
this.line=line;
this.idx=this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].linkCount++;
if (this.nodeIds[1] == null ) this.nodeIds[1]=this.nodeIds[0];
this.typeBondOrder=$I$(2).getBondType$S$I(this.type, this.topoOrder);
this.translations[0]=$I$(1).new3$D$D$D(t1[0], t1[1], t1[2]);
this.translations[1]=$I$(1).new3$D$D$D(t2[0], t2[1], t2[2]);
System.out.println$S("TopoCifParser.setLink " + this);
return true;
});

Clazz.newMeth(C$, 'addAtom$org_jmol_adapter_readers_cif_TopoCifParser_TAtom',  function (atom) {
if (this.tatoms == null ) this.tatoms=Clazz.new_($I$(3,1));
if (atom.nodeID != null ) {
atom=atom.getTClone$();
atom.nodeID=null;
}atom.atomName="Link_" + atom.linkID + "_" + atom.atomLabel ;
this.tatoms.addLast$O(atom);
return atom;
});

Clazz.newMeth(C$, 'finalizeLink$',  function () {
this.netID=(this.nodeIds[0] == null  ? null : this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].findNode$S$I$javajs_util_P3d.apply(this.b$['org.jmol.adapter.readers.cif.TopoCifParser'], [this.nodeIds[0], -1, null]).netID);
if (this.netID == null  && this.netLabel == null  ) {
if (this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].nets.size$() > 0) this.net=this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].nets.get$I(0);
 else this.net=this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].getNetFor$S$S$Z.apply(this.b$['org.jmol.adapter.readers.cif.TopoCifParser'], [null, null, true]);
} else {
this.net=this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].getNetFor$S$S$Z.apply(this.b$['org.jmol.adapter.readers.cif.TopoCifParser'], [this.netID, this.netLabel, true]);
}this.netLabel=this.net.label;
++this.net.nLinks;
if (this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].selectedNet != null ) {
if (!this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].selectedNet.equalsIgnoreCase$S(this.net.label) && !this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].selectedNet.equalsIgnoreCase$S(this.net.id) ) {
return;
}}p$3.finalizeLinkNode$I.apply(this, [0]);
p$3.finalizeLinkNode$I.apply(this, [1]);
if (this.tatoms != null ) {
var n=this.tatoms.size$();
this.net.hasAtoms=true;
for (var i=n; --i >= 0; ) {
var a=this.tatoms.get$I(i);
a.idx1=-this.idx - 1;
a.atomName=this.netLabel + "_" + a.atomName ;
a.net=this.net;
}
if (n >= 0) {
this.mf=$I$(2).getMF$javajs_util_Lst(this.tatoms);
this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].reader.appendLoadNote$S("_topos_link " + this.id + " for net " + this.netLabel + " has formula " + this.mf );
}}this.order=16777216 + (this.idx << 4) + this.typeBondOrder ;
this.distance=this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].calculateDistance$javajs_util_P3d$javajs_util_P3d.apply(this.b$['org.jmol.adapter.readers.cif.TopoCifParser'], [this.linkNodes[0], this.linkNodes[1]]);
if (this.cartesianDistance != 0  && Math.abs(this.distance - this.cartesianDistance) >= $I$(2).ERROR_TOLERANCE  ) System.err.println$S("Distance error! distance=" + new Double(this.distance).toString() + " for " + this.line );
System.out.println$S("link d=" + new Double(this.distance).toString() + " " + this + this.linkNodes[0] + this.linkNodes[1] );
this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].reader.asc.addBond$org_jmol_adapter_smarter_Bond(this);
this.finalized=true;
});

Clazz.newMeth(C$, 'finalizeLinkNode$I',  function (index) {
var id=this.nodeIds[index];
var atomLabel=this.nodeLabels[index];
var op=this.symops[index];
var trans=this.translations[index];
var node=p$3.getNodeWithSym$S$S$I$javajs_util_P3d.apply(this, [id, atomLabel, op, trans]);
var node0=node;
if (node == null  && id != null  ) {
node=p$3.getNodeWithSym$S$S$I$javajs_util_P3d.apply(this, [id, null, -1, null]);
}var atom=(node == null  && atomLabel != null   ? this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].getAtomFromName$S.apply(this.b$['org.jmol.adapter.readers.cif.TopoCifParser'], [atomLabel]) : null);
if (atom != null ) {
node=Clazz.new_($I$(4,1).c$$I$org_jmol_adapter_smarter_Atom$org_jmol_adapter_readers_cif_TopoCifParser_TNet$I$javajs_util_P3d,[this, null, this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].atomCount++, atom, this.net, op, trans]);
} else if (node != null ) {
if (node0 == null ) node=node.copy$();
node.linkSymop=op;
node.linkTrans=trans;
this.nodeLabels[index]=node.atomName;
} else {
throw Clazz.new_(Clazz.load('Exception').c$$S,["_topol_link: no atom or node " + atomLabel + " line=" + this.line ]);
}this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].nodes.addLast$O(node);
this.linkNodes[index]=node;
if (index == 1 && node === this.linkNodes[0]  ) {
this.linkNodes[1]=node.copy$();
}node.finalizeNode$javajs_util_M4dA(this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].ops);
if (node0 == null ) $I$(2).applySymmetry$org_jmol_adapter_smarter_Atom$javajs_util_M4dA$I$javajs_util_T3d(node, this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].ops, op, trans);
if (index == 0) {
this.atomIndex1=node.index;
} else {
this.atomIndex2=node.index;
}}, p$3);

Clazz.newMeth(C$, 'getNodeWithSym$S$S$I$javajs_util_P3d',  function (nodeID, nodeLabel, op, trans) {
if (nodeID != null ) return this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].findNode$S$I$javajs_util_P3d.apply(this.b$['org.jmol.adapter.readers.cif.TopoCifParser'], [nodeID, op, trans]);
for (var i=this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].nodes.size$(); --i >= 0; ) {
var n=this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].nodes.get$I(i);
if (n.label.equals$O(nodeLabel) && (op == -1 && n.linkSymop == 0  && n.linkTrans.equals$O($I$(2).ZERO)  || op == n.linkSymop && trans.equals$O(n.linkTrans)  ) ) return n;
}
return null;
}, p$3);

Clazz.newMeth(C$, 'getLinkInfo$',  function () {
var info=Clazz.new_($I$(5,1));
info.put$O$O("index", Integer.valueOf$I(this.idx + 1));
if (this.id != null ) info.put$O$O("id", this.id);
info.put$O$O("netID", this.net.id);
info.put$O$O("netLabel", this.net.label);
if (this.nodeLabels[0] != null ) info.put$O$O("nodeLabel1", this.nodeLabels[0]);
if (this.nodeLabels[1] != null ) info.put$O$O("nodeLabel2", this.nodeLabels[1]);
if (this.nodeIds[0] != null ) info.put$O$O("nodeId1", this.nodeIds[0]);
if (this.nodeIds[1] != null ) info.put$O$O("nodeId2", this.nodeIds[1]);
info.put$O$O("distance", Double.valueOf$D(this.cartesianDistance));
if (!Double.isNaN$D(this.distance)) info.put$O$O("distance", Double.valueOf$D(this.distance));
info.put$O$O("symops1", Integer.valueOf$I(this.symops[0] + 1));
info.put$O$O("symops2", Integer.valueOf$I(this.symops[1] + 1));
info.put$O$O("translation1", this.translations[0]);
info.put$O$O("translation2", this.translations[1]);
info.put$O$O("multiplicity", Integer.valueOf$I(this.multiplicity));
if (this.type != null ) info.put$O$O("type", this.type);
info.put$O$O("voronoiSolidAngle", Double.valueOf$D(this.voronoiAngle));
info.put$O$O("atomIndex1", Integer.valueOf$I(this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].i0 + this.linkNodes[0].index));
info.put$O$O("atomIndex2", Integer.valueOf$I(this.b$['org.jmol.adapter.readers.cif.TopoCifParser'].i0 + this.linkNodes[1].index));
if (this.bsAtoms != null  && !this.bsAtoms.isEmpty$() ) info.put$O$O("representedAtoms", this.bsAtoms);
info.put$O$O("topoOrder", Integer.valueOf$I(this.topoOrder));
info.put$O$O("order", Integer.valueOf$I(this.typeBondOrder));
return info;
});

Clazz.newMeth(C$, 'info$',  function () {
return "[link " + this.line + " : " + new Double(this.distance).toString() + "]" ;
});

Clazz.newMeth(C$, 'toString',  function () {
return this.info$();
});
})()
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:31 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
