(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.quantum"),p$1={},I$=[[0,'javajs.util.PT','javajs.util.SB','org.jmol.adapter.readers.xtal.FSGOutputReader','javajs.util.P3d','org.jmol.symmetry.SymmetryOperation','javajs.util.M3d','javajs.util.M4d','org.jmol.util.Vibration']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FSGOutputReader", null, 'org.jmol.adapter.smarter.AtomSetCollectionReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['elementSymbols','String[]']]]

Clazz.newMeth(C$, 'initializeReader$',  function () {
C$.superclazz.prototype.initializeReader$.apply(this, []);
var symbols=this.getFilterWithCase$S("elements=");
if (symbols != null ) {
this.elementSymbols=$I$(1).split$S$S(symbols, " ");
}var sb=Clazz.new_($I$(2,1));
try {
while (this.rd$() != null )sb.append$S(this.line);

p$1.processJSON$java_util_Map.apply(this, [this.vwr.parseJSONMap$S(sb.toString())]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
this.continuing=false;
});

Clazz.newMeth(C$, 'processJSON$java_util_Map',  function (json) {
p$1.getHeaderInfo$java_util_Map.apply(this, [json]);
var info=$I$(3).getList$java_util_Map$S(json, "G0_std_Cell");
p$1.getCellInfo$javajs_util_Lst.apply(this, [p$1.getListItem$javajs_util_Lst$I.apply(this, [info, 0])]);
p$1.readAllOperators$javajs_util_Lst.apply(this, [$I$(3).getList$java_util_Map$S(json, "G0_std_operations")]);
p$1.readAtomsAndMoments$javajs_util_Lst.apply(this, [info]);
}, p$1);

Clazz.newMeth(C$, 'getListItem$javajs_util_Lst$I',  function (info, i) {
return info.get$I(i);
}, p$1);

Clazz.newMeth(C$, 'getList$java_util_Map$S',  function (json, key) {
return json.get$O(key);
}, 1);

Clazz.newMeth(C$, 'getHeaderInfo$java_util_Map',  function (json) {
this.setSpaceGroupName$S(json.get$O("FPG_symbol"));
this.appendUnitCellInfo$S("SSG_international_symbol=" + json.get$O("SSG_international_symbol"));
}, p$1);

Clazz.newMeth(C$, 'getCellInfo$javajs_util_Lst',  function (info) {
var list=p$1.getListItem$javajs_util_Lst$I.apply(this, [info, 0]);
for (var i=0; i < 3; i++) {
var v=$I$(3,"getPoint$javajs_util_Lst",[p$1.getListItem$javajs_util_Lst$I.apply(this, [list, i])]);
this.addExplicitLatticeVector$I$DA$I(i, Clazz.array(Double.TYPE, -1, [v.x, v.y, v.z]), 0);
}
}, p$1);

Clazz.newMeth(C$, 'getPoint$javajs_util_Lst',  function (item) {
return $I$(4,"new3$D$D$D",[$I$(3).getValue$javajs_util_Lst$I(item, 0), $I$(3).getValue$javajs_util_Lst$I(item, 1), $I$(3).getValue$javajs_util_Lst$I(item, 2)]);
}, 1);

Clazz.newMeth(C$, 'getValue$javajs_util_Lst$I',  function (item, i) {
return (item.get$I(i)).doubleValue$();
}, 1);

Clazz.newMeth(C$, 'readAllOperators$javajs_util_Lst',  function (info) {
for (var i=0, n=info.size$(); i < n; i++) {
var op=info.get$I(i);
var mspin=p$1.readMatrix$javajs_util_Lst$javajs_util_Lst.apply(this, [p$1.getListItem$javajs_util_Lst$I.apply(this, [op, 0]), null]);
var mop=p$1.readMatrix$javajs_util_Lst$javajs_util_Lst.apply(this, [p$1.getListItem$javajs_util_Lst$I.apply(this, [op, 1]), p$1.getListItem$javajs_util_Lst$I.apply(this, [op, 2])]);
var s=$I$(5).getXYZFromMatrixFrac$javajs_util_M4d$Z$Z$Z$Z$Z$S(mop, false, false, false, true, true, "xyz") + $I$(5).getSpinString$javajs_util_M4d$Z(mspin, true);
System.out.println$S("FSGOutput op[" + (i + 1) + "]=" + s );
this.setSymmetryOperator$S(s);
}
}, p$1);

Clazz.newMeth(C$, 'readMatrix$javajs_util_Lst$javajs_util_Lst',  function (rot, trans) {
var r=Clazz.new_($I$(6,1));
for (var i=0; i < 3; i++) {
r.setRowV$I$javajs_util_T3d(i, $I$(3,"getPoint$javajs_util_Lst",[p$1.getListItem$javajs_util_Lst$I.apply(this, [rot, i])]));
}
var t=(trans == null  ? Clazz.new_($I$(4,1)) : $I$(3).getPoint$javajs_util_Lst(trans));
return $I$(7).newMV$javajs_util_M3d$javajs_util_T3d(r, t);
}, p$1);

Clazz.newMeth(C$, 'readAtomsAndMoments$javajs_util_Lst',  function (info) {
this.setFractionalCoordinates$Z(true);
var atoms=p$1.getListItem$javajs_util_Lst$I.apply(this, [info, 1]);
var ids=p$1.getListItem$javajs_util_Lst$I.apply(this, [info, 2]);
var moments=p$1.getListItem$javajs_util_Lst$I.apply(this, [info, 3]);
for (var i=0, n=atoms.size$(); i < n; i++) {
var xyz=$I$(3,"getPoint$javajs_util_Lst",[p$1.getListItem$javajs_util_Lst$I.apply(this, [atoms, i])]);
var id=($I$(3).getValue$javajs_util_Lst$I(ids, i)|0);
var moment=$I$(3,"getPoint$javajs_util_Lst",[p$1.getListItem$javajs_util_Lst$I.apply(this, [moments, i])]);
var a=this.asc.addNewAtom$();
a.setT$javajs_util_T3d(xyz);
a.atomName="A" + id;
if (this.elementSymbols != null  && id <= this.elementSymbols.length ) {
a.elementSymbol=this.elementSymbols[id - 1];
}var v=Clazz.new_($I$(8,1));
v.set$D$D$D(moment.x, moment.y, moment.z);
v.magMoment=v.length$();
a.vib=v;
}
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-05-28 17:11:29 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
