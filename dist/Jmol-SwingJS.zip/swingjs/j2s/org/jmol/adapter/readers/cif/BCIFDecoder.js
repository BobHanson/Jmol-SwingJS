(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.cif"),p$1={},I$=[[0,'javajs.util.PT','javajs.util.BC','javajs.util.SB']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "BCIFDecoder");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.dataType=1;
this.origin=-2147483648;
},1);

C$.$fields$=[['Z',['unsigned','isDecoded'],'C',['kind'],'F',['factor'],'I',['dataType','btype','byteLen','srcType','mode','srcSize','rowCount','byteCount','origin','stringLen','packingSize'],'S',['type','key','catname','name','stringData','dtype'],'O',['encodings','Object[]','offsetDecoder','org.jmol.adapter.readers.cif.BCIFDecoder','+dataDecoder','+maskDecoder','data','java.util.Map','byteData','byte[]','floatDoubleData','double[]','intData','int[]','+indices','+mask','+offsets']]
,['O',['temp','int[]']]]

Clazz.newMeth(C$, 'c$$javajs_util_SB$S$java_util_Map',  function (sb, key, col) {
C$.c$$javajs_util_SB$S$java_util_Map$O$S.apply(this, [sb, key, col, null, null]);
}, 1);

Clazz.newMeth(C$, 'c$$javajs_util_SB$S$java_util_Map$O$S',  function (sb, key, map, byteData, ekey) {
;C$.$init$.apply(this);
this.key=key;
var data=(byteData == null  ? map.get$O("data") : byteData);
if (Clazz.instanceOf(data, "java.util.Map")) {
this.data=data;
data=this.data.get$O("data");
}if (Clazz.instanceOf(data, Clazz.array(Byte.TYPE, -1))) {
p$1.setByteData$O.apply(this, [data]);
}if (ekey == null ) {
if (this.data == null ) {
this.encodings=map.get$O("encoding");
} else {
this.name=map.get$O("name");
this.encodings=this.data.get$O("encoding");
var mask=map.get$O("mask");
if (mask != null ) {
this.maskDecoder=Clazz.new_(C$.c$$javajs_util_SB$S$java_util_Map$O,[sb, null, mask, null]);
this.maskDecoder.dtype="m";
}}} else {
this.encodings=map.get$O(ekey);
this.dtype=ekey.substring$I$I(0, 1);
}p$1.initializeEncodings$OA$javajs_util_SB.apply(this, [this.encodings, sb]);
if (sb != null ) {
this.type=p$1.debugGetDecoderType$OA.apply(this, [this.encodings]);
if (this.maskDecoder != null ) this.type+=".mask." + this.maskDecoder.toString();
sb.append$S(this + "\n");
} else {
}}, 1);

Clazz.newMeth(C$, 'setRowCount$I$S',  function (rowCount, catName) {
this.rowCount=rowCount;
this.catname=catName;
return this;
});

Clazz.newMeth(C$, 'setByteData$O',  function (data) {
this.byteData=data;
this.byteLen=this.byteData.length;
}, p$1);

Clazz.newMeth(C$, 'toString',  function () {
return this.type + (this.dtype == null  ? "" : this.dtype) + (this.btype == 0 ? "[" + this.byteLen + "]"  : "(srcSize/rowcount=" + this.srcSize + "/" + this.rowCount + " mode=" + this.mode + " bt=" + this.btype + " bl=" + this.byteLen + " sl=" + this.stringLen + ")" ) + (this.key == null  ? "" : ":" + this.key) ;
});

Clazz.newMeth(C$, 'getMapChar$java_util_Map$S',  function (ht, key) {
var s=ht.get$O(key);
return (s != null  && s.length$() > 0  ? s.charAt$I(0) : String.fromCharCode(0));
}, 1);

Clazz.newMeth(C$, 'geMapInt$O$S',  function (o, key) {
if (Clazz.instanceOf(o, "java.lang.String")) {
System.err.println$S("!BCIFDecoder found String type for " + key + "=" + o );
return $I$(1).parseInt$S(o);
}return (o == null  ? 0 : (o).intValue$());
}, 1);

Clazz.newMeth(C$, 'getMapBool$O',  function (o) {
return (o === Boolean.TRUE );
}, 1);

Clazz.newMeth(C$, 'initializeEncodings$OA$javajs_util_SB',  function (encodings, sb) {
var n=encodings.length;
for (var i=0; i < n; i++) {
var encoding=encodings[i];
var kind=C$.getMapChar$java_util_Map$S(encoding, "kind");
if (encoding.containsKey$O("min")) {
kind="Q";
this.dataType=0;
}if ((this.kind).$c() == 0 ) this.kind=kind;
switch (kind.$c()) {
case 70:
this.factor=C$.geMapInt$O$S(encoding.get$O("factor"), null);
this.dataType=2;
this.mode|=8;
break;
case 68:
this.origin=C$.geMapInt$O$S(encoding.get$O("origin"), this.key + " origin");
this.mode|=1;
break;
case 82:
this.mode|=2;
this.srcSize=C$.geMapInt$O$S(encoding.get$O("srcSize"), null);
break;
case 73:
this.mode|=4;
this.packingSize=C$.geMapInt$O$S(encoding.get$O("srcSize"), null);
if (this.srcSize == 0) this.srcSize=this.packingSize;
this.unsigned=C$.getMapBool$O(encoding.get$O("isUnsigned"));
continue;
case 66:
if (this.btype != 0) {
System.err.println$S("!BCIFDecoder skipping " + this.key + " duplicate bytearray encoding " + this.btype + " not " + encoding );
continue;
}this.btype=C$.geMapInt$O$S(encoding.get$O("type"), null);
this.byteCount=(this.btype == 33 ? 8 : this.btype == 32 ? 4 : 1 << (((this.btype - 1) % 3)));
if (this.btype >= 32) {
this.dataType=2;
}continue;
case 83:
this.dataType=3;
this.stringData=encoding.get$O("stringData");
this.stringLen=this.stringData.length$();
this.dataDecoder=Clazz.new_(C$.c$$javajs_util_SB$S$java_util_Map$O,[sb, "dataEncoding", encoding, this.byteData]);
this.offsetDecoder=Clazz.new_(C$.c$$javajs_util_SB$S$java_util_Map$O,[sb, "offsetEncoding", encoding, encoding.get$O("offsets")]);
continue;
}
if (this.srcType == 0) {
this.srcType=C$.geMapInt$O$S(encoding.get$O("srcType"), null);
}}
}, p$1);

Clazz.newMeth(C$, 'finalizeDecoding$javajs_util_SB',  function (sb) {
if (this.isDecoded) return this;
if (sb != null ) sb.append$S("finalizing " + this + "\n" );
this.isDecoded=true;
this.mask=(this.maskDecoder == null  ? null : this.maskDecoder.finalizeDecoding$javajs_util_SB(sb).intData);
if (this.mask != null  && !C$.haveCheckMask$IA(this.mask) ) {
if (sb != null ) sb.append$S("no valid data (mask completely \'.\' or \'?\'\n");
this.dataType=0;
return null;
}if (this.mask != null  && sb != null  ) sb.append$S("mask = " + C$.debugToStr$O(this.mask) + "\n" );
if (this.dataDecoder != null ) {
this.indices=this.dataDecoder.finalizeDecoding$javajs_util_SB(sb).intData;
this.offsets=this.offsetDecoder.finalizeDecoding$javajs_util_SB(sb).intData;
if (sb != null ) {
sb.append$S("stringData = " + C$.debugToStr$O(this.stringData) + "\n" );
sb.append$S("indices = " + C$.debugToStr$O(this.indices) + "\n" );
sb.append$S("offsets = " + C$.debugToStr$O(this.offsets) + "\n" );
}} else {
if (sb != null ) sb.append$S("bytes->int " + (this.byteData.length/this.byteCount|0) + " rc=" + this.rowCount + " ps=" + this.packingSize + "\n");
var run=null;
var len=this.srcSize;
if ((this.mode & 2) == 2) {
run=C$.getTemp$I(this.srcSize << 1);
len=this.srcSize;
}if ((this.mode & 4) == 4) {
this.intData=C$.unpackInts$BA$I$I$Z$I$IA(this.byteData, this.byteCount, len, this.unsigned, this.origin, run);
} else if (this.btype == 32 || this.btype == 33 ) {
this.floatDoubleData=p$1.bytesToFixedPt$BA$I.apply(this, [this.byteData, this.btype == 32 ? 4 : 8]);
} else {
this.intData=C$.bytesToInt$BA$I$I$Z$I$IA(this.byteData, this.byteCount, len, this.unsigned, this.origin, run);
}}return this;
});

Clazz.newMeth(C$, 'haveCheckMask$IA',  function (mask) {
for (var i=mask.length; --i >= 0; ) {
if (mask[i] == 0) return true;
}
return false;
}, 1);

Clazz.newMeth(C$, 'getStringValue$I',  function (row) {
if (this.dataType != 3 || this.mask != null  && this.mask[row] != 0  ) return "\u0000";
var pt=this.indices[row];
return this.stringData.substring$I$I(this.offsets[pt++], (pt == this.rowCount ? this.stringLen : this.offsets[pt]));
});

Clazz.newMeth(C$, 'getIntValue$I',  function (row) {
return (this.dataType != 1 || this.mask != null  && this.mask[row] != 0   ? -2147483648 : this.intData[row]);
});

Clazz.newMeth(C$, 'getFixedPtValue$I',  function (row) {
return (this.dataType != 2 || this.mask != null  && this.mask[row] != 0   ? NaN : this.floatDoubleData == null  ? this.intData[row] / this.factor : this.floatDoubleData[row]);
});

Clazz.newMeth(C$, 'bytesToFixedPt$BA$I',  function (b, byteLen) {
if (b == null ) return null;
var n=(b.length/byteLen|0);
var a=Clazz.array(Double.TYPE, [n]);
try {
switch (byteLen) {
case 4:
for (var i=0, j=0; i < n; i++, j+=4) {
a[i]=$I$(2).bytesToFloat$BA$I$Z(b, j, false);
}
break;
case 8:
for (var i=0, j=0; i < n; i++, j+=8) {
a[i]=$I$(2).bytesToDoubleToFloat$BA$I$Z(b, j, false);
}
break;
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
return a;
}, p$1);

Clazz.newMeth(C$, 'bytesToInt$BA$I$I$Z$I$IA',  function (b, byteLen, rowCount, unsigned, origin, run) {
if (b == null ) return null;
var n=(b.length/byteLen|0);
var ret=Clazz.array(Integer.TYPE, [rowCount == 0 ? n : rowCount]);
var a=(run == null  ? ret : run);
var ii;
switch (byteLen) {
case 1:
for (var i=0, j=0; i < n; i++, j++) {
ii=b[j] & 255;
a[i]=(unsigned ? ii : ii > 239 ? ii - 256 : ii);
}
break;
case 2:
for (var i=0, j=0; i < n; i++, j+=2) {
ii=$I$(2).bytesToShort$BA$I$Z(b, j, false);
a[i]=(unsigned ? ii & 65535 : ii);
}
break;
case 4:
for (var i=0, j=0; i < n; i++, j+=4) {
a[i]=$I$(2).bytesToInt$BA$I$Z(b, j, false);
}
break;
}
if (run != null ) {
for (var p=0, i=0; i < n; ) {
var val=a[i++];
for (var j=a[i++]; --j >= 0; ) ret[p++]=val;

}
}if (origin != -2147483648) {
for (var i=0; i < rowCount; i++) {
origin=ret[i]=origin + ret[i];
}
}return ret;
}, 1);

Clazz.newMeth(C$, 'unpackInts$BA$I$I$Z$I$IA',  function (b, byteLen, srcSize, unsigned, origin, run) {
if (b == null ) return null;
var ret=Clazz.array(Integer.TYPE, [srcSize]);
var a=(run == null  ? ret : run);
var max;
switch (byteLen) {
case 1:
max=(unsigned ? 255 : 127);
for (var i=0, pt=0, n=b.length, offset=0; pt < n; ) {
var val=b[pt++];
if (unsigned) val=val & max;
if (val == max || val == -128 ) {
offset+=val;
} else {
a[i++]=val + offset;
offset=0;
}}
break;
case 2:
max=(unsigned ? 65535 : 32767);
for (var i=0, pt=0, n=(b.length/2|0), offset=0; pt < n; ) {
var val=$I$(2,"bytesToShort$BA$I$Z",[b, (pt++) << 1, false]);
if (unsigned) val=val & max;
if (val == max || val == -32768 ) {
offset+=val;
} else {
a[i++]=val + offset;
offset=0;
}}
break;
}
if (run != null ) {
for (var p=0, i=0; p < srcSize; i++) {
var val=a[i];
for (var j=a[++i]; --j >= 0; ) ret[p++]=val;

}
}if (origin != -2147483648) {
for (var i=0; i < srcSize; i++) {
origin=ret[i]=origin + ret[i];
}
}return ret;
}, 1);

Clazz.newMeth(C$, 'getTemp$I',  function (n) {
if (C$.temp == null  || C$.temp.length < n ) C$.temp=Clazz.array(Integer.TYPE, [Math.max(n, 1000)]);
return C$.temp;
}, 1);

Clazz.newMeth(C$, 'clearTemp$',  function () {
C$.temp=null;
}, 1);

Clazz.newMeth(C$, 'debugToStr$O',  function (o) {
if (Clazz.instanceOf(o, Clazz.array(Integer.TYPE, -1))) return C$.debugToStrI$IA(o);
if (Clazz.instanceOf(o, Clazz.array(Byte.TYPE, -1))) return C$.debugToStrB$BA(o);
if (Clazz.instanceOf(o, Clazz.array(Double.TYPE, -1))) return C$.debugToStrD$DA(o);
if (Clazz.instanceOf(o, "java.lang.String")) {
var s=o;
return (s.length$() < 100 ? s : s.substring$I$I(0, 100) + "..." + s.length$() );
}return C$.debugToStrO$OA(o);
}, 1);

Clazz.newMeth(C$, 'debugToStrO$OA',  function (o) {
var sb=Clazz.new_($I$(3,1));
var sep="[";
var n=Math.min(o.length, 20);
for (var i=0; i < n; i++) {
sb.appendC$C(sep).appendO$O(o[i]);
sep=",";
}
if (n < o.length) sb.append$S("...").appendI$I(o.length);
sb.appendC$C("]");
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'debugToStrI$IA',  function (o) {
var sb=Clazz.new_($I$(3,1));
var sep="[";
var n=Math.min(o.length, 20);
for (var i=0; i < n; i++) {
sb.appendC$C(sep).appendI$I(o[i]);
sep=",";
}
if (n < o.length) sb.append$S("...").appendI$I(o.length);
sb.appendC$C("]");
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'debugToStrB$BA',  function (o) {
var sb=Clazz.new_($I$(3,1));
var sep="[";
var n=Math.min(o.length, 20);
for (var i=0; i < n; i++) {
sb.appendC$C(sep).appendI$I(o[i]);
sep=",";
}
if (n < o.length) sb.append$S("...").appendI$I(o.length);
sb.appendC$C("]");
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'debugToStrD$DA',  function (o) {
var sb=Clazz.new_($I$(3,1));
var sep="[";
var n=Math.min(o.length, 20);
for (var i=0; i < n; i++) {
sb.appendC$C(sep).appendD$D(o[i]);
sep=",";
}
if (n < o.length) sb.append$S("...").appendI$I(o.length);
sb.appendC$C("]");
return sb.toString();
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:36 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
