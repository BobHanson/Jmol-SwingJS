(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.cif"),p$1={},I$=[[0,'org.jmol.adapter.readers.cif.BCIFDataParser','javajs.util.MessagePackReader','org.jmol.adapter.readers.cif.BCIFDecoder']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "BCIFReader", null, 'org.jmol.adapter.readers.cif.MMCifReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['colCount'],'S',['version','catName'],'O',['bcifParser','org.jmol.adapter.readers.cif.BCIFDataParser']]
,['O',['temp','int[]']]]

Clazz.newMeth(C$, 'getCifDataParser$',  function () {
return this.cifParser=this.bcifParser=Clazz.new_($I$(1,1).c$$org_jmol_adapter_readers_cif_BCIFReader$Z,[this, this.debugging]);
});

Clazz.newMeth(C$, 'setup$S$java_util_Map$O',  function (fullPath, htParams, reader) {
this.isBinary=true;
this.setupASCR$S$java_util_Map$O(fullPath, htParams, reader);
});

Clazz.newMeth(C$, 'processBinaryDocument$',  function () {
var t=System.currentTimeMillis$();
this.binaryDoc.setBigEndian$Z(true);
var msgMap=(Clazz.new_($I$(2,1).c$$javajs_api_GenericBinaryDocumentReader$Z,[this.binaryDoc, false])).readMap$();
this.binaryDoc.close$();
var encoder=msgMap.get$O("encoder");
System.out.println$S("BCIFReader: BCIF encoder " + encoder);
this.version=msgMap.get$O("version");
System.out.println$S("BCIFReader: BCIF version " + this.version);
var dataBlock=(msgMap.get$O("dataBlocks"))[0];
System.out.println$S("BCIFReader processed MessagePack in " + (Long.$s(Long.$sub(System.currentTimeMillis$(),t))) + " ms" );
this.getCifDataParser$();
var categories=dataBlock.get$O("categories");
this.bcifParser.header=dataBlock.get$O("header");
for (var j=0; j < categories.length; j++) {
var cat=categories[j];
if (!cat.isEmpty$()) p$1.processCategory$java_util_Map.apply(this, [cat]);
}
System.out.println$S("BCIFReader processed binary file in " + (Long.$s(Long.$sub(System.currentTimeMillis$(),t))) + " ms" );
});

Clazz.newMeth(C$, 'finalizeSubclassReader$',  function () {
C$.superclazz.prototype.finalizeSubclassReader$.apply(this, []);
$I$(3).clearTemp$();
});

Clazz.newMeth(C$, 'processCategory$java_util_Map',  function (cat) {
var catName=(cat.get$O("name")).toLowerCase$();
if (!p$1.isCategoryOfInterest$S.apply(this, [catName])) return false;
this.bcifParser.initializeCategory$S$I$OA(catName, $I$(3,"geMapInt$O$S",[cat.get$O("rowCount"), null]), cat.get$O("columns"));
p$1.processCategoryName$S.apply(this, [catName]);
return false;
}, p$1);

Clazz.newMeth(C$, 'isCategoryOfInterest$S',  function (catName) {
switch (catName) {
case "_entry":
case "_atom_site":
case "_atom_type":
case "_atom_sites":
case "_cell":
case "_struct_ncs_oper":
case "_pdbx_struct_oper_list":
case "_pdbx_struct_assembly_gen":
case "_struct_ref_seq_dif":
case "_struct_site_gen":
case "_chem_comp":
case "_struct_conf":
case "_struct_sheet_range":
case "_chem_comp_bond":
case "_struct_conn":
return true;
}
return false;
}, p$1);

Clazz.newMeth(C$, 'processCategoryName$S',  function (catName) {
this.catName=catName;
switch (catName) {
case "_entry":
return p$1.processEntry.apply(this, []);
case "_atom_site":
return this.processAtomSiteLoopBlock$Z(false);
case "_atom_type":
return this.processAtomTypeLoopBlock$();
case "_atom_sites":
return p$1.processAtomSites.apply(this, []);
case "_cell":
return p$1.processCellBlock.apply(this, []);
}
switch (catName) {
case "_struct_ncs_oper":
case "_pdbx_struct_oper_list":
case "_pdbx_struct_assembly_gen":
case "_struct_ref_seq_dif":
case "_struct_site_gen":
case "_chem_comp":
case "_struct_conf":
case "_struct_sheet_range":
case "_chem_comp_bond":
case "_struct_conn":
this.key0=catName + ".";
return this.processSubclassLoopBlock$();
}
return false;
}, p$1);

Clazz.newMeth(C$, 'processEntry',  function () {
this.bcifParser.decodeAndGetData$I(0);
this.pdbID=this.bcifParser.fieldStr;
return true;
}, p$1);

Clazz.newMeth(C$, 'processAtomSites',  function () {
for (var i=0; i < this.colCount; i++) {
this.bcifParser.decodeAndGetData$I(i);
this.processUnitCellTransformMatrix$();
}
return true;
}, p$1);

Clazz.newMeth(C$, 'processCellBlock',  function () {
for (var i=0; i < this.colCount; i++) {
this.bcifParser.decodeAndGetData$I(i);
this.processCellParameter$();
}
return true;
}, p$1);

Clazz.newMeth(C$, 'parseLoopParameters$SA',  function (fields) {
this.bcifParser.parseDataBlockParameters$SA$S$S$IA$IA(fields, null, null, this.key2col, this.col2key);
});

Clazz.newMeth(C$, 'isFieldValid$',  function () {
if (this.bcifParser.fieldStr != null ) this.firstChar=this.bcifParser.fieldStr.charAt$I(0);
return this.bcifParser.isFieldValid$();
});

Clazz.newMeth(C$, 'parseIntField$',  function () {
return (this.bcifParser.ifield == -2147483648 ? C$.superclazz.prototype.parseIntField$.apply(this, []) : this.bcifParser.ifield);
});

Clazz.newMeth(C$, 'parseDoubleField$',  function () {
return this.bcifParser.dfield;
});

Clazz.newMeth(C$, 'parseCartesianField$',  function () {
return Math.round$D(this.bcifParser.dfield * 1000) / 1000.0;
});

Clazz.newMeth(C$, 'parseIntFieldTok$B',  function (tok) {
this.getFieldString$B(tok);
return this.bcifParser.ifield;
});

Clazz.newMeth(C$, 'getDoubleColumnData$I',  function (i) {
this.bcifParser.getColumnData$I(i);
return this.bcifParser.dfield;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-09-01 22:08:02 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
