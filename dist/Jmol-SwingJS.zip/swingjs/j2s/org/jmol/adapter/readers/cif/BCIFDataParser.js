(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.cif"),p$1={},I$=[[0,'org.jmol.adapter.readers.cif.BCIFDecoder','javajs.util.CifDataParser','javajs.util.BinaryDocument','java.io.BufferedInputStream','java.io.FileInputStream','javajs.util.MessagePackReader']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "BCIFDataParser", null, 'javajs.util.CifDataParser');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['fieldIsValid'],'D',['dfield'],'I',['rowCount','rowPt','ifield'],'S',['categoryName','fieldStr','header'],'O',['rdr','org.jmol.adapter.readers.cif.BCIFReader','columnMaps','Object[]','columnDecoders','org.jmol.adapter.readers.cif.BCIFDecoder[]','cifMap','java.util.Hashtable']]]

Clazz.newMeth(C$, 'c$$org_jmol_adapter_readers_cif_BCIFReader$Z',  function (bcifReader, debugging) {
Clazz.super_(C$, this);
this.rdr=bcifReader;
this.debugging=debugging;
}, 1);

Clazz.newMeth(C$, 'getDecoder$S$java_util_Map$I$S',  function (key, col, rowCount, catName) {
var sb=null;
var d=Clazz.new_($I$(1,1).c$$javajs_util_SB$S$java_util_Map,[sb, key, col]).setRowCount$I$S(rowCount, catName).finalizeDecoding$javajs_util_SB(sb);
return (d == null  || d.dataType == 0  ? null : d);
}, p$1);

Clazz.newMeth(C$, 'initializeCategory$S$I$OA',  function (catName, rowCount, columns) {
this.columnMaps=columns;
this.rowCount=rowCount;
this.categoryName=catName;
var n=this.columnCount=columns.length;
if (this.columnNames == null  || this.columnNames.length < n ) this.columnNames=Clazz.array(String, [n]);
for (var i=0; i < n; i++) {
this.columnNames[i]=(catName + "_" + (columns[i]).get$O("name") ).toLowerCase$();
}
});

Clazz.newMeth(C$, 'parseDataBlockParameters$SA$S$S$IA$IA',  function (fieldNames, key, data, key2col, col2key) {
this.haveData=false;
this.rowPt=-1;
for (var i=100; --i >= 0; ) {
col2key[i]=key2col[i]=-1;
}
if (!$I$(2).htFields.containsKey$O(fieldNames[0])) {
for (var i=fieldNames.length; --i >= 0; ) $I$(2).htFields.put$O$O(fieldNames[i], Integer.valueOf$I(i));

}this.columnDecoders=Clazz.array($I$(1), [this.columnCount]);
for (var pt=0; pt < this.columnCount; pt++) {
var s=this.columnNames[pt];
System.out.println$S(s);
var iField=$I$(2).htFields.get$O(s);
var keyIndex=col2key[pt]=(iField == null  ? -1 : iField.intValue$());
var d=(keyIndex == -1 ? null : p$1.getDecoder$S$java_util_Map$I$S.apply(this, [s, p$1.getDataColumn$I.apply(this, [pt]), this.rowCount, this.categoryName]));
if (d == null ) {
if (keyIndex >= 0) key2col[keyIndex]=-2;
} else {
this.columnDecoders[pt]=d;
key2col[keyIndex]=pt;
this.haveData=true;
}}
});

Clazz.newMeth(C$, 'decodeAndGetData$I',  function (icol) {
this.columnDecoders=Clazz.array($I$(1), -1, [p$1.getDecoder$S$java_util_Map$I$S.apply(this, [null, p$1.getDataColumn$I.apply(this, [icol]), this.rowCount, this.categoryName])]);
this.getColumnData$I(0);
this.columnDecoders=null;
});

Clazz.newMeth(C$, 'getData$',  function () {
++this.rowPt;
var done=this.rowPt >= this.rowCount;
if (done) {
for (var i=this.columnDecoders.length; --i >= 0; ) this.columnDecoders[i]=null;

}return !done;
});

Clazz.newMeth(C$, 'getColumnData$I',  function (colPt) {
this.rdr.key=this.getColumnName$I(colPt);
this.ifield=-2147483648;
this.dfield=NaN;
if (this.columnDecoders[colPt] == null ) {
this.fieldIsValid=false;
return this.fieldStr=$I$(2).nullString;
}switch (this.columnDecoders[colPt].dataType) {
case 1:
this.ifield=this.columnDecoders[colPt].getIntValue$I(this.rowPt);
this.fieldStr=(this.ifield == -2147483648 ? $I$(2).nullString : "" + this.ifield);
break;
case 2:
this.dfield=this.columnDecoders[colPt].getFixedPtValue$I(this.rowPt);
this.fieldStr=(Double.isNaN$D(this.dfield) ? $I$(2).nullString : "_" + new Double(this.dfield).toString());
break;
case 3:
this.fieldStr=this.columnDecoders[colPt].getStringValue$I(this.rowPt);
break;
}
this.fieldIsValid=(this.fieldStr != $I$(2).nullString);
return this.fieldStr;
});

Clazz.newMeth(C$, 'isFieldValid$',  function () {
return this.fieldIsValid;
});

Clazz.newMeth(C$, 'getDataColumn$I',  function (icol) {
return (icol >= 0 && icol < this.columnCount  ? this.columnMaps[icol] : null);
}, p$1);

Clazz.newMeth(C$, 'getAllCifData$',  function () {
return null;
});

Clazz.newMeth(C$, 'main$SA',  function (args) {
try {
var testFile=(args.length == 0 ? "c:/temp/1cbs.bcif" : args[0]);
var binaryDoc=Clazz.new_($I$(3,1));
var bis=Clazz.new_([Clazz.new_($I$(5,1).c$$S,[testFile])],$I$(4,1).c$$java_io_InputStream);
binaryDoc.setStream$java_io_BufferedInputStream$Z(bis, true);
var msgMap;
msgMap=(Clazz.new_($I$(6,1).c$$javajs_api_GenericBinaryDocumentReader$Z,[binaryDoc, false])).readMap$();
var parser=Clazz.new_(C$.c$$org_jmol_adapter_readers_cif_BCIFReader$Z,[null, true]);
parser.debugConstructCifMap$java_util_Map(msgMap);
binaryDoc.close$();
System.out.println$S("OK - DONE");
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:36 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
