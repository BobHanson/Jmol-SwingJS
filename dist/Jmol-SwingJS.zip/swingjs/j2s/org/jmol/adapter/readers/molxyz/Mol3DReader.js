(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.molxyz"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Mol3DReader", null, 'org.jmol.adapter.readers.molxyz.MolReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'initializeReader$',  function () {
this.allow2D=false;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:16:00 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
