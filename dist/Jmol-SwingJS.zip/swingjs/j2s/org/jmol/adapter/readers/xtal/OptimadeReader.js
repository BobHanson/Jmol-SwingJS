(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.xtal"),p$1={},I$=[[0,'javajs.util.SB','org.jmol.util.Logger','java.util.HashMap']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "OptimadeReader", null, 'org.jmol.adapter.smarter.AtomSetCollectionReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.xyz=Clazz.array(Double.TYPE, [3]);
},1);

C$.$fields$=[['Z',['iHaveDesiredModel','isPolymer','isSlab','noSlab'],'I',['modelNo','permutation'],'O',['xyz','double[]']]]

Clazz.newMeth(C$, 'initializeReader$',  function () {
C$.superclazz.prototype.initializeReader$.apply(this, []);
this.noSlab=this.checkFilterKey$S("NOSLAB");
try {
var strJSON=this.htParams.get$O("fileData");
if (strJSON == null ) {
var sb=Clazz.new_($I$(1,1));
while (this.rd$() != null )sb.append$S(this.line);

strJSON=sb.toString();
this.line=null;
}var aData=null;
if (strJSON.startsWith$S("[")) {
var data=this.vwr.parseJSONArray$S(strJSON);
for (var i=0; i < data.size$(); i++) {
if (Clazz.instanceOf(data.get$I(i), "java.util.Map")) {
aData=(data.get$I(i)).get$O("data");
if (aData != null ) {
break;
}}}
} else {
aData=this.vwr.parseJSONMap$S(strJSON).get$O("data");
}if (aData != null ) {
for (var i=0; !this.iHaveDesiredModel && i < aData.size$() ; i++) {
var data=aData.get$I(i);
if ("structures".equals$O(data.get$O("type"))) {
p$1.readModel$java_util_Map.apply(this, [data.get$O("attributes")]);
}}
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
this.continuing=false;
});

Clazz.newMeth(C$, 'readModel$java_util_Map',  function (map) {
if (!this.doGetModel$I$S(this.modelNumber=++this.modelNo, null)) return;
this.iHaveDesiredModel=this.isLastModel$I(this.modelNumber);
this.applySymmetryAndSetTrajectory$();
this.asc.newAtomSet$();
this.setFractionalCoordinates$Z(false);
var dimensionType=Clazz.array(Double.TYPE, [3]);
if (C$.toFloatArray$java_util_List$DA(map.get$O("dimension_types"), dimensionType)) {
p$1.checkDimensionType$DA.apply(this, [dimensionType]);
}if (!this.isMolecular) {
this.setSpaceGroupName$S("P1");
this.asc.setInfo$S$O("symmetryType", (this.isSlab ? "2D - SLAB" : this.isPolymer ? "1D - POLYMER" : "3D"));
}this.asc.setAtomSetName$S(map.get$O("chemical_formula_descriptive"));
this.doConvertToFractional=(!this.isMolecular && p$1.readLattice$java_util_List.apply(this, [map.get$O("lattice_vectors")]) );
p$1.readAtoms$java_util_List$java_util_List$java_util_List.apply(this, [map.get$O("species"), map.get$O("species_at_sites"), map.get$O("cartesian_site_positions")]);
}, p$1);

Clazz.newMeth(C$, 'checkDimensionType$DA',  function (dt) {
this.isPolymer=this.isSlab=this.isMolecular=false;
if (this.noSlab) return;
this.permutation=0;
switch (((dt[2] + dt[1] * 2 + dt[0] * 4)|0)) {
default:
case 0:
this.isMolecular=true;
break;
case 1:
this.isPolymer=true;
this.permutation=1;
break;
case 2:
this.isPolymer=true;
this.permutation=2;
break;
case 3:
this.isSlab=true;
this.permutation=2;
break;
case 5:
this.isSlab=true;
this.permutation=1;
break;
case 4:
this.isPolymer=true;
break;
case 6:
this.isSlab=true;
break;
case 7:
break;
}
}, p$1);

Clazz.newMeth(C$, 'readLattice$java_util_List',  function (lattice) {
if (lattice == null ) return false;
var abc=Clazz.array(Double.TYPE, [3]);
for (var i=0; i < 3; i++) {
if (!C$.toFloatArray$java_util_List$DA(lattice.get$I(i), this.xyz)) {
return false;
}this.unitCellParams[0]=NaN;
if (this.isSlab || this.isPolymer ) {
abc[i]=Math.sqrt(this.xyz[0] * this.xyz[0] + this.xyz[1] * this.xyz[1] + this.xyz[2] * this.xyz[2]);
if (abc[i] >= 500 ) {
this.xyz[0]/=abc[i];
this.xyz[1]/=abc[i];
this.xyz[2]/=abc[i];
}}if (this.isSlab || this.isPolymer ) this.unitCellParams[0]=0;
if (i == 2) {
if (this.isSlab || this.isPolymer ) {
this.unitCellParams[0]=abc[this.permutation];
if (this.isSlab) this.unitCellParams[1]=abc[(this.permutation + 1) % 3];
}}this.addExplicitLatticeVector$I$DA$I((i + this.permutation) % 3, this.xyz, 0);
}
this.doApplySymmetry=true;
return true;
}, p$1);

Clazz.newMeth(C$, 'readAtoms$java_util_List$java_util_List$java_util_List',  function (species, sites, coords) {
var natoms=sites.size$();
var speciesByName=null;
if (species == null ) {
$I$(2).error$S("OptimadeReader - no \'species\' key");
} else {
speciesByName=Clazz.new_($I$(3,1));
for (var i=species.size$(); --i >= 0; ) {
var s=species.get$I(i);
speciesByName.put$O$O(s.get$O("name"), s);
}
}for (var i=0; i < natoms; i++) {
var sname=sites.get$I(i);
C$.toFloatArray$java_util_List$DA(coords.get$I(i), this.xyz);
if (species == null ) {
p$1.addAtom$DA$S$S.apply(this, [this.xyz, sites.get$I(i), sname]);
} else {
var sp=speciesByName.get$O(sname);
var syms=sp.get$O("chemical_symbols");
var nOcc=syms.size$();
if (nOcc > 1) {
var conc=Clazz.array(Double.TYPE, [nOcc]);
if (C$.toFloatArray$java_util_List$DA(sp.get$O("concentration"), conc)) {
for (var j=0; j < conc.length; j++) {
var a=p$1.addAtom$DA$S$S.apply(this, [this.xyz, syms.get$I(j), sname]);
a.foccupancy=conc[j];
}
continue;
}}p$1.addAtom$DA$S$S.apply(this, [this.xyz, syms.get$I(0), sname]);
}}
}, p$1);

Clazz.newMeth(C$, 'addAtom$DA$S$S',  function (xyz, sym, name) {
var atom=this.asc.addNewAtom$();
if (sym != null ) atom.elementSymbol=sym;
if (name != null ) atom.atomName=name;
this.setAtomCoordXYZ$org_jmol_adapter_smarter_Atom$D$D$D(atom, xyz[0], xyz[1], xyz[2]);
return atom;
}, p$1);

Clazz.newMeth(C$, 'toFloatArray$java_util_List$DA',  function (list, a) {
if (list == null ) return false;
for (var i=a.length; --i >= 0; ) {
var d=list.get$I(i);
if (d == null ) return false;
a[i]=list.get$I(i).doubleValue$();
}
return true;
}, 1);

Clazz.newMeth(C$, 'finalizeSubclassSymmetry$Z',  function (haveSymmetry) {
C$.superclazz.prototype.finalizeSubclassSymmetry$Z.apply(this, [haveSymmetry]);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:34 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
