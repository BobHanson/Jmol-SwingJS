(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.xml"),I$=[[0,'java.io.BufferedReader']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "XmlNmrmlReader", null, 'org.jmol.adapter.readers.xml.XmlCmlReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'previewXML$java_io_BufferedReader',  function (reader) {
return ((P$.XmlNmrmlReader$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "XmlNmrmlReader$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.io.BufferedReader'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.checked=false;
},1);

C$.$fields$=[['Z',['checked']]]

Clazz.newMeth(C$, 'read$CA$I$I',  function (cbuf, off, len) {
var n=C$.superclazz.prototype.read$CA$I$I.apply(this, [cbuf, off, len]);
if (!this.checked && len > 1000 ) {
var i=200;
while (++i < 1000){
if (cbuf[i] == "<" && cbuf[i + 1] == "c"  && cbuf[i + 2] == "v" ) {
while (++i < 500){
if (cbuf[i] == ">" && cbuf[i - 1] == "\"" ) {
cbuf[i - 1]="/";
cbuf[i - 2]="\"";
break;
}}
break;
}}
if (i >= 500) i=200;
while (++i < 1000){
if (cbuf[i] == "<" && cbuf[i + 1] == "c"  && cbuf[i + 2] == "h" ) {
while (++i < 1000){
if (cbuf[i] == ">") break;
if (cbuf[i] == "<") {
cbuf[i - 1]=">";
break;
}}
break;
}}
this.checked=true;
}return n;
});
})()
), Clazz.new_($I$(1,1).c$$java_io_Reader,[this, null, reader],P$.XmlNmrmlReader$1));
});

Clazz.newMeth(C$, 'processStart2$S',  function (name) {
name=C$.toCML$S(name);
name=name.toLowerCase$();
switch (name) {
case "atom":
this.atts.put$O$O("x3", this.atts.remove$O("x"));
this.atts.put$O$O("y3", this.atts.remove$O("y"));
this.atts.put$O$O("z3", this.atts.remove$O("z"));
break;
case "bond":
this.atts.put$O$O("atomrefs2", this.atts.remove$O("atomrefs"));
break;
}
C$.superclazz.prototype.processStart2$S.apply(this, [name]);
});

Clazz.newMeth(C$, 'processEnd2$S',  function (name) {
C$.superclazz.prototype.processEnd2$S.apply(this, [C$.toCML$S(name)]);
});

Clazz.newMeth(C$, 'toCML$S',  function (name) {
name=name.toLowerCase$();
switch (name) {
case "structure":
name="molecule";
break;
case "atomlist":
name="atomarray";
break;
case "bondlist":
name="bondarray";
break;
}
return name;
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:40 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
