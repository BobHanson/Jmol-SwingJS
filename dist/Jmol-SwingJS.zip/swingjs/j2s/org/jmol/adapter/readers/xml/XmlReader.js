(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.xml"),p$1={},I$=[[0,'javajs.util.SB','java.util.Hashtable','org.jmol.adapter.smarter.AtomSetCollection','org.jmol.adapter.smarter.Resolver','org.jmol.api.Interface','org.jmol.util.Logger']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "XmlReader", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.jmol.adapter.smarter.AtomSetCollectionReader');
C$.$classes$=[['NVPair',2]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.parent=this;
this.thisReader=null;
this.chars=$I$(1).newN$I(2000);
this.domObj=Clazz.array(java.lang.Object, [1]);
},1);

C$.$fields$=[['Z',['keepChars'],'O',['thisAtom','org.jmol.adapter.smarter.Atom','parent','org.jmol.adapter.readers.xml.XmlReader','atts','java.util.Map','thisReader','org.jmol.adapter.readers.xml.XmlReader','chars','javajs.util.SB','domObj','Object[]','+attribs']]]

Clazz.newMeth(C$, 'initializeReader$',  function () {
this.atts=Clazz.new_($I$(2,1));
p$1.setMyError$S.apply(this, [p$1.parseXML.apply(this, [])]);
this.continuing=false;
});

Clazz.newMeth(C$, 'setMyError$S',  function (err) {
if (err != null  && (this.asc == null  || this.asc.errorMessage == null  ) ) {
this.asc=Clazz.new_($I$(3,1).c$$S$org_jmol_adapter_smarter_AtomSetCollectionReader$org_jmol_adapter_smarter_AtomSetCollectionA$javajs_util_Lst,["xml", this, null, null]);
this.asc.errorMessage=err;
}}, p$1);

Clazz.newMeth(C$, 'parseXML',  function () {
var saxReader=null;
{

}
return p$1.selectReaderAndGo$O.apply(this, [saxReader]);
}, p$1);

Clazz.newMeth(C$, 'selectReaderAndGo$O',  function (saxReader) {
var className=null;
var pt=this.readerName.indexOf$S("(");
var name=(pt < 0 ? this.readerName : this.readerName.substring$I$I(0, pt));
className=$I$(4).getReaderClassBase$S(name);
if (className.equals$O(this.getClass$().getName$())) {
this.thisReader=this.parent=this;
} else {
this.asc=Clazz.new_($I$(3,1).c$$S$org_jmol_adapter_smarter_AtomSetCollectionReader$org_jmol_adapter_smarter_AtomSetCollectionA$javajs_util_Lst,[this.readerName, this, null, null]);
if ((this.thisReader=this.getInterface$S(className)) == null ) return "File reader was not found: " + className;
}try {
this.thisReader.processXml$org_jmol_adapter_readers_xml_XmlReader$O(this, saxReader);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
return "Error reading XML: " + (e.getMessage$());
} else {
throw e;
}
}
return null;
}, p$1);

Clazz.newMeth(C$, 'processXml$org_jmol_adapter_readers_xml_XmlReader$O',  function (parent, saxReader) {
this.processXml2$org_jmol_adapter_readers_xml_XmlReader$O(parent, saxReader);
});

Clazz.newMeth(C$, 'processXml2$org_jmol_adapter_readers_xml_XmlReader$O',  function (parent, saxReader) {
this.parent=parent;
if (parent !== this ) {
this.asc=parent.asc;
this.reader=parent.reader;
this.atts=parent.atts;
}var rdr=this.previewXML$java_io_BufferedReader(this.reader);
if (saxReader == null ) {
this.attribs=Clazz.array(java.lang.Object, [1]);
this.domObj=Clazz.array(java.lang.Object, [1]);
var o="";
var data=null;
{
o = rdr.lock.lock;
if (o && o.$in) { data = o.$in.buf;
} else if ((o=rdr.$in.str) != null) { } else if (rdr.$in.$in.$in.fd) { // may need to adjust this;
o = rdr.$in.$in;
data = o.$in.fd._file.秘bytes;
} else { data = (o=rdr.$in.$in).$in.buf;
}
}
if (Clazz.instanceOf(o, "java.io.BufferedInputStream")) o= String.instantialize(data, "utf-8");
var isjs=false;
{
isjs = true;
}
if (isjs) {
this.domObj[0]=this.createDomNodeJS$S$O("xmlReader", o);
p$1.walkDOMTree.apply(this, []);
this.createDomNodeJS$S$O("xmlReader", null);
}} else {
($I$(5).getOption$S$org_jmol_viewer_Viewer$S("adapter.readers.xml.XmlHandler", this.vwr, "file")).parseXML$org_jmol_adapter_readers_xml_XmlReader$O$java_io_BufferedReader(this, saxReader, rdr);
}});

Clazz.newMeth(C$, 'previewXML$java_io_BufferedReader',  function (reader) {
return reader;
});

Clazz.newMeth(C$, 'createDomNodeJS$S$O',  function (id, data) {
var d=null;
{
if (!data) return null;
if (data.indexOf("<?") == 0) data = data.substring(data.indexOf("<", 1));
if (data.indexOf("/>") >= 0) { var D = data.split("/>");
for (var i = D.length - 1; --i >= 0;) { var s = D[i];
var pt = s.lastIndexOf("<") + 1;
var pt2 = pt;
var len = s.length;
var name = "";
while (++pt2 < len) { if (" \t\n\r".indexOf(s.charAt(pt2))>= 0) { var name = s.substring(pt, pt2);
D[i] = s + "></"+name+">";
break;
} } } data = D.join('');
} d = document.createElement("_xml");
d.innerHTML = data;
}
return d;
});

Clazz.newMeth(C$, 'applySymmetryAndSetTrajectory$',  function () {
try {
if (this.parent == null  || this.parent === this  ) this.applySymTrajASCR$();
 else this.parent.applySymmetryAndSetTrajectory$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
$I$(6).error$S("applySymmetry failed: " + e);
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'processDOM$O',  function (DOMNode) {
this.domObj=Clazz.array(java.lang.Object, -1, [DOMNode]);
p$1.setMyError$S.apply(this, [p$1.selectReaderAndGo$O.apply(this, [null])]);
});

Clazz.newMeth(C$, 'processStartElement$S$S',  function (localName, nodeName) {
});

Clazz.newMeth(C$, 'setKeepChars$Z',  function (TF) {
this.keepChars=TF;
this.chars.setLength$I(0);
});

Clazz.newMeth(C$, 'processEndElement$S',  function (localName) {
});

Clazz.newMeth(C$, 'walkDOMTree',  function () {
var localName;
{
localName = "nodeName";
}
var nodeName=(p$1.jsObjectGetMember$OA$S.apply(this, [this.domObj, localName]));
localName=p$1.fixLocal$S.apply(this, [nodeName]);
if (localName == null ) return;
if (localName.equals$O("#text")) {
if (this.keepChars) this.chars.append$S(p$1.jsObjectGetMember$OA$S.apply(this, [this.domObj, "data"]));
return;
}localName=localName.toLowerCase$();
nodeName=nodeName.toLowerCase$();
this.attribs[0]=p$1.jsObjectGetMember$OA$S.apply(this, [this.domObj, "attributes"]);
p$1.getDOMAttributesA$OA.apply(this, [this.attribs]);
this.processStartElement$S$S(localName, nodeName);
var haveChildren=false;
{
haveChildren = this.domObj[0].hasChildNodes;
}
if (haveChildren) {
var nextNode=p$1.jsObjectGetMember$OA$S.apply(this, [this.domObj, "firstChild"]);
while (nextNode != null ){
this.domObj[0]=nextNode;
p$1.walkDOMTree.apply(this, []);
this.domObj[0]=nextNode;
nextNode=p$1.jsObjectGetMember$OA$S.apply(this, [this.domObj, "nextSibling"]);
}
}this.processEndElement$S(localName);
}, p$1);

Clazz.newMeth(C$, 'fixLocal$S',  function (name) {
{
var pt = (name== null ? -1 : name.indexOf(":")); return (pt >= 0 ? name.substring(pt+1) : name);
}
}, p$1);

Clazz.newMeth(C$, 'getDOMAttributesA$OA',  function (attributes) {
this.atts.clear$();
if (attributes == null ) return;
var nodes=null;
{
nodes = attributes[0];
}
for (var i=nodes.length; --i >= 0; ) this.atts.put$O$O(p$1.fixLocal$S.apply(this, [nodes[i].name]).toLowerCase$(), nodes[i].value);

}, p$1);

Clazz.newMeth(C$, 'jsObjectGetMember$OA$S',  function (jsObject, name) {
{
return jsObject[0][name];
}
}, p$1);

Clazz.newMeth(C$, 'endDocument$',  function () {
});

Clazz.newMeth(C$, 'finalizeSubclassReader$',  function () {
if (this.thisReader != null  && this.thisReader !== this  ) this.thisReader.finalizeSubclassReader$();
this.thisReader=null;
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.XmlReader, "NVPair", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['name','value']]]

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:40 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
