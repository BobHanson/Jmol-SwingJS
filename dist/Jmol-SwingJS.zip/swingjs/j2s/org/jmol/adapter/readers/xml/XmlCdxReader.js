(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.xml"),I$=[[0,'org.jmol.adapter.readers.xml.CDXMLParser','org.jmol.util.Edge','org.jmol.adapter.smarter.Atom','org.jmol.adapter.smarter.AtomSetCollectionReader','org.jmol.adapter.smarter.Bond']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "XmlCdxReader", null, 'org.jmol.adapter.readers.xml.XmlReader', [['org.jmol.adapter.readers.xml.CDXMLParser','org.jmol.adapter.readers.xml.CDXMLParser.CDXReaderI']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['no3D','isCDX'],'O',['parser','org.jmol.adapter.readers.xml.CDXMLParser']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.parser=Clazz.new_($I$(1,1).c$$org_jmol_adapter_readers_xml_CDXMLParser_CDXReaderI,[this]);
}, 1);

Clazz.newMeth(C$, 'processXml$org_jmol_adapter_readers_xml_XmlReader$O',  function (parent, saxReader) {
this.is2D=true;
if (parent == null ) {
this.processXml2$org_jmol_adapter_readers_xml_XmlReader$O(this, saxReader);
parent=this;
} else {
this.no3D=parent.checkFilterKey$S("NO3D");
this.noHydrogens=parent.noHydrogens;
this.processXml2$org_jmol_adapter_readers_xml_XmlReader$O(parent, saxReader);
this.filter=parent.filter;
}});

Clazz.newMeth(C$, 'processStartElement$S$S',  function (localName, nodeName) {
this.parser.processStartElement$S$java_util_Map(localName, this.atts);
});

Clazz.newMeth(C$, 'processEndElement$S',  function (localName) {
this.parser.processEndElement$S$S(localName, this.chars.toString());
});

Clazz.newMeth(C$, 'setKeepChars$Z',  function (TF) {
C$.superclazz.prototype.setKeepChars$Z.apply(this, [TF]);
});

Clazz.newMeth(C$, 'finalizeSubclassReader$',  function () {
this.parser.finalizeParsing$();
this.createMolecule$();
});

Clazz.newMeth(C$, 'getBondOrder$S',  function (key) {
switch (key) {
case "1":
case "single":
return 1;
case "2":
case "double":
return 2;
case "3":
case "triple":
return 3;
case "up":
return 1025;
case "down":
return 1041;
case "either":
return 1057;
case "null":
return 131071;
case "delocalized":
return 515;
default:
case "partial":
return $I$(2).getBondOrderFromString$S(key);
}
});

Clazz.newMeth(C$, 'handleCoordinates$java_util_Map',  function (atts) {
var hasXYZ=(atts.containsKey$O("xyz"));
var hasXY=(atts.containsKey$O("p"));
if (hasXYZ && (!this.no3D || !hasXY ) ) {
this.is2D=false;
this.parser.setAtom$S$java_util_Map("xyz", atts);
} else if (atts.containsKey$O("p")) {
this.parser.setAtom$S$java_util_Map("p", atts);
}});

Clazz.newMeth(C$, 'createMolecule$',  function () {
var bs=this.parser.bsAtoms;
for (var i=bs.nextSetBit$I(0); i >= 0; i=bs.nextSetBit$I(i + 1)) {
var atom=this.parser.getAtom$I(i);
var a=Clazz.new_($I$(3,1));
a.set$D$D$D(atom.x, atom.y, atom.z);
a.atomSerial=atom.intID;
a.elementNumber=($s$[0] = atom.elementNumber, $s$[0]);
a.formalCharge=atom.formalCharge;
var element=$I$(4).getElementSymbol$I(atom.elementNumber);
if (atom.isotope != null ) element=atom.isotope + element;
this.setElementAndIsotope$org_jmol_adapter_smarter_Atom$S(a, element);
this.asc.addAtom$org_jmol_adapter_smarter_Atom(a);
}
bs=this.parser.bsBonds;
for (var i=bs.nextSetBit$I(0); i >= 0; i=bs.nextSetBit$I(i + 1)) {
var bond=this.parser.getBond$I(i);
var b=Clazz.new_($I$(5,1).c$$I$I$I,[bond.atomIndex1, bond.atomIndex2, bond.order]);
this.asc.addBondNoCheck$org_jmol_adapter_smarter_Bond(b);
}
this.parent.appendLoadNote$S((this.isCDX ? "CDX: " : "CDXML: ") + (this.is2D ? "2D" : "3D"));
this.asc.setInfo$S$O("minimize3D", Boolean.valueOf$Z(!this.is2D && !this.noHydrogens ));
this.asc.setInfo$S$O("is2D", Boolean.valueOf$Z(this.is2D));
if (this.is2D) {
this.optimize2D=!this.noHydrogens && !this.noMinimize ;
this.asc.setModelInfoForSet$S$O$I("dimension", "2D", this.asc.iSet);
this.set2D$();
}});

Clazz.newMeth(C$, 'warn$S',  function (warning) {
this.parent.appendLoadNote$S(warning);
});
var $s$ = new Int16Array(1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:40 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
