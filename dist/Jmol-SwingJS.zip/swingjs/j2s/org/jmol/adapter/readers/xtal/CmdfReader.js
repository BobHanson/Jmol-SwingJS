(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.xtal"),p$1={},I$=[[0,'org.jmol.adapter.smarter.Atom','org.jmol.api.JmolAdapter','javajs.util.BC']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CmdfReader", null, 'org.jmol.adapter.smarter.AtomSetCollectionReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.buf=Clazz.array(Byte.TYPE, [100]);
},1);

C$.$fields$=[['O',['buf','byte[]']]]

Clazz.newMeth(C$, 'initializeReader$',  function () {
this.setFractionalCoordinates$Z(true);
});

Clazz.newMeth(C$, 'processBinaryDocument$',  function () {
this.binaryDoc.setStream$java_io_BufferedInputStream$Z(null, false);
this.binaryDoc.seek$J(28);
var len=this.binaryDoc.readInt$();
System.out.println$S("file length: " + len + " " + Integer.toHexString$I(len) );
p$1.seek$S$I.apply(this, ["CELL", 32]);
var uc=Clazz.array(Double.TYPE, [6]);
for (var i=0; i < 6; i++) {
uc[i]=C$.fixDouble$D(this.binaryDoc.readFloat$());
}
this.setUnitCell$D$D$D$D$D$D(uc[0], uc[1], uc[2], uc[3], uc[4], uc[5]);
p$1.seek$S$I.apply(this, ["SYMM", -1]);
var sg=C$.fixSpaceGroup$S(this.binaryDoc.readString$I(20));
this.setSpaceGroupName$S(sg);
System.out.println$S("Space group is " + sg);
p$1.readAtoms.apply(this, []);
System.out.println$S("done");
});

Clazz.newMeth(C$, 'fixSpaceGroup$S',  function (sg) {
var pt=sg.indexOf$I("\u0000");
if (pt == 0) System.out.println$S("SYMM: empty;NO space group??");
return (pt < 0 ? sg : sg.substring$I$I(0, pt)).trim$();
}, 1);

Clazz.newMeth(C$, 'readAtoms',  function () {
p$1.seek$S$I.apply(this, ["AUN7", 32]);
var nSites=this.binaryDoc.readInt$();
System.out.println$S(nSites + " sites");
for (var i=0; i < nSites; i++) p$1.readSite.apply(this, []);

}, p$1);

Clazz.newMeth(C$, 'readSite',  function () {
var nOccupants=this.binaryDoc.readByte$();
var pt0=Long.$ival(this.binaryDoc.getPosition$());
var atoms=Clazz.array($I$(1), [nOccupants]);
for (var i=0; i < nOccupants; i++) {
var a=atoms[i]=Clazz.new_($I$(1,1));
var ch2=String.fromCharCode(this.binaryDoc.readByte$());
var ch1=String.fromCharCode(this.binaryDoc.readByte$());
a.elementSymbol=C$.getSymbol$S("" + ch1 + ch2 );
if ($I$(2).getElementNumber$S(a.elementSymbol) == 0) {
System.out.println$S("ELEMENT error " + a.elementSymbol + " " + this.fileName );
}a.foccupancy=C$.fixDouble$D(this.binaryDoc.readFloat$());
this.asc.addAtom$org_jmol_adapter_smarter_Atom(a);
}
var elementIndex=this.binaryDoc.readInt$();
var sym0=atoms[0].elementSymbol;
var name=p$1.readString.apply(this, []);
var valence=this.binaryDoc.readInt$();
for (var i=0; i < nOccupants; i++) {
atoms[i].atomName=(i == 0 || sym0.length$() > name.length$()  ? name : atoms[i].elementSymbol + name.substring$I(sym0.length$()));
}
var unk3s=this.binaryDoc.readShort$() & 65535;
var x=this.binaryDoc.readFloat$();
var y=this.binaryDoc.readFloat$();
var z=this.binaryDoc.readFloat$();
for (var i=0; i < nOccupants; i++) {
this.setAtomCoordXYZ$org_jmol_adapter_smarter_Atom$D$D$D(atoms[i], C$.fixDouble$D(x), C$.fixDouble$D(y), C$.fixDouble$D(z));
}
var index2=this.binaryDoc.readInt$() / 32.0;
var unk4b=this.binaryDoc.readByte$() & 255;
var siteNumber=this.binaryDoc.readShort$();
var unk5b=this.binaryDoc.readByte$() & 255;
var wyn=this.binaryDoc.readInt$();
var wyabc=this.binaryDoc.readByte$();
var wyckoff="" + wyn + String.fromCharCode((96 + wyabc)) ;
System.out.println$S("SITE " + siteNumber + " occ=" + nOccupants + " " + atoms[0].elementSymbol + " " + atoms[0].atomName + " " + wyckoff + " " + atoms[0] + (nOccupants > 1 ? atoms[1].atomName : "") + " valence=" + valence + " " + new Float(index2).toString() + " " + Integer.toHexString$I(unk3s) + " " + Integer.toHexString$I(unk4b) + " " + Integer.toHexString$I(unk5b) );
return;
}, p$1);

Clazz.newMeth(C$, 'readString',  function () {
var n=this.binaryDoc.readByte$();
this.binaryDoc.readByteArray$BA$I$I(this.buf, 0, n);
return  String.instantialize(this.buf, 0, n);
}, p$1);

Clazz.newMeth(C$, 'peek$I',  function (n) {
var p0=this.binaryDoc.getPosition$();
var p=Long.$ival(p0);
var bytes=Clazz.array(Byte.TYPE, [4]);
try {
for (var i=0; i < n; i++) {
this.binaryDoc.seek$J(p++);
this.binaryDoc.readByteArray$BA$I$I(bytes, 0, 4);
var ival=$I$(3).bytesToInt$BA$I$Z(bytes, 0, false);
var fval=$I$(3).bytesToFloat$BA$I$Z(bytes, 0, false);
System.out.println$S(p + " " + Integer.toHexString$I(bytes[0] < 0 ? 256 + bytes[0] : bytes[0]) + " " + (bytes[0] >= 48  && bytes[0] <= 122   ? Character.valueOf$C(String.fromCharCode(bytes[0])) : ".") + " " + Integer.toHexString$I(ival) + " " + new Float(fval).toString() );
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
this.binaryDoc.seek$J(p0);
}, p$1);

Clazz.newMeth(C$, 'fixDouble$D',  function (d) {
return Math.round$D(d * 1000.0) / 1000.0;
}, 1);

Clazz.newMeth(C$, 'seek$S$I',  function (label, where) {
var bytes=label.getBytes$();
if (where > 0) this.binaryDoc.seek$J(where);
var p=(where >= 0 ? where : Long.$ival(this.binaryDoc.getPosition$()));
System.out.println$S("looking for " + label + " @" + p );
var off=0;
var n=bytes.length;
var p0=p;
while (off < n){
var b=this.binaryDoc.readByte$();
++p;
if (b == bytes[off]) {
++off;
} else if (off > 0) {
this.binaryDoc.seek$J(p=p0=p0 + 1);
off=0;
}}
System.out.println$S(label + " found at " + (p - n) );
return p;
}, p$1);

Clazz.newMeth(C$, 'getSymbol$S',  function (sym) {
if (sym == null ) return "Xx";
var len=sym.length$();
if (len < 2) return sym;
var ch1=sym.charAt$I(1);
if (ch1 >= "a" && ch1 <= "z" ) return sym.substring$I$I(0, 2);
return "" + sym.charAt$I(0);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-09-01 22:08:06 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
