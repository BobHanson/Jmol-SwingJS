(function(){var P$=Clazz.newPackage("org.jmol.jvxl.readers"),p$1={},I$=[[0,'javajs.util.CifDataParser','javajs.util.SB']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CifsfReader", null, 'org.jmol.jvxl.readers.VolumeFileReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.vpt=0;
},1);

C$.$fields$=[['I',['h0','k0','l0','nh','nk','nl','vpt']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'init2$org_jmol_jvxl_readers_SurfaceGenerator$java_io_BufferedReader',  function (sg, br) {
p$1.readCIFData$java_io_BufferedReader.apply(this, [br]);
this.init2VFR$org_jmol_jvxl_readers_SurfaceGenerator$java_io_BufferedReader(sg, br);
this.nSurfaces=1;
});

Clazz.newMeth(C$, 'readCIFData$java_io_BufferedReader',  function (br) {
var parser=Clazz.new_($I$(1,1));
parser.set$javajs_api_GenericLineReader$java_io_BufferedReader$Z(null, br, false);
var map=parser.getAllCifDataType$SA(Clazz.array(String, -1, ["_refln", "_diffrn"]));
p$1.processMap$java_util_Map.apply(this, [map]);
}, p$1);

Clazz.newMeth(C$, 'processMap$java_util_Map',  function (map) {
var models=map.get$O("models");
if (models.size$() == 0) return;
var model=models.get$I(0);
this.h0=(C$.getValue$O(model.get$O("_diffrn_reflns_limit_h_min"))|0);
this.k0=(C$.getValue$O(model.get$O("_diffrn_reflns_limit_k_min"))|0);
this.l0=(C$.getValue$O(model.get$O("_diffrn_reflns_limit_l_min"))|0);
this.nh=((C$.getValue$O(model.get$O("_diffrn_reflns_limit_h_max")) - this.h0 + 1)|0);
this.nk=((C$.getValue$O(model.get$O("_diffrn_reflns_limit_k_max")) - this.k0 + 1)|0);
this.nl=((C$.getValue$O(model.get$O("_diffrn_reflns_limit_l_max")) - this.l0 + 1)|0);
this.jvxlFileHeaderBuffer=Clazz.new_($I$(2,1));
this.jvxlFileHeaderBuffer.append$S("CIF structure factor data\n");
this.jvxlFileHeaderBuffer.append$S("\n");
this.volumetricOrigin.set$D$D$D(this.h0, this.k0, this.l0);
this.voxelCounts[0]=this.nh;
this.voxelCounts[1]=this.nk;
this.voxelCounts[2]=this.nl;
this.volumetricVectors[0].set$D$D$D(this.nh - 1, 0, 0);
this.volumetricVectors[1].set$D$D$D(0, this.nk - 1, 0);
this.volumetricVectors[2].set$D$D$D(0, 0, this.nl - 1);
this.jvxlFileHeaderBuffer.append$S(this.nh + " 0 0 " + (this.nh - 1) + "\n" );
this.jvxlFileHeaderBuffer.append$S(this.nk + " 0 0 " + (this.nk - 1) + "\n" );
this.jvxlFileHeaderBuffer.append$S(this.nl + " 0 0 " + (this.nl - 1) + "\n" );
this.voxelData=Clazz.array(Double.TYPE, [this.nh, this.nk, this.nl]);
var hdata=p$1.getValueArray$java_util_Map$S.apply(this, [model, "_refln_index_h"]);
var kdata=p$1.getValueArray$java_util_Map$S.apply(this, [model, "_refln_index_k"]);
var ldata=p$1.getValueArray$java_util_Map$S.apply(this, [model, "_refln_index_l"]);
var m1data=p$1.getValueArray$java_util_Map$S.apply(this, [model, "_refln_index_m1"]);
var value=p$1.getValueArray$java_util_Map$S.apply(this, [model, "_refln_F_squared_meas"]);
if (m1data == null ) {
for (var i=0; i < hdata.length; i++) {
this.voxelData[(hdata[i]|0)][(kdata[i]|0)][(ldata[i]|0)]=value[i];
}
} else {
for (var i=0; i < m1data.length; i++) {
if (m1data[i] == 0 ) this.voxelData[(hdata[i]|0)][(kdata[i]|0)][(ldata[i]|0)]=value[i];
}
}System.out.println$S("OK");
}, p$1);

Clazz.newMeth(C$, 'getValueArray$java_util_Map$S',  function (model, key) {
var data=model.get$O(key);
if (data == null ) return null;
var d=Clazz.array(Double.TYPE, [data.size$()]);
for (var i=data.size$(); --i >= 0; ) d[i]=(data.get$I(i)).doubleValue$();

return d;
}, p$1);

Clazz.newMeth(C$, 'getValue$O',  function (v) {
return (v == null  ? NaN : (v).doubleValue$());
}, 1);

Clazz.newMeth(C$, 'readParameters$',  function () {
});

Clazz.newMeth(C$, 'nextVoxel$',  function () {
var l=this.vpt % this.nl;
var k=(((this.vpt - l)/this.nl|0)) % (this.nk * this.nl);
return 0;
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:46 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
