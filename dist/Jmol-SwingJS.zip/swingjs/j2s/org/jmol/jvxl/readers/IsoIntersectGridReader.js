(function(){var P$=Clazz.newPackage("org.jmol.jvxl.readers"),I$=[[0,'org.jmol.util.Logger']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "IsoIntersectGridReader", null, 'org.jmol.jvxl.readers.VolumeFileReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['readers','org.jmol.jvxl.readers.VolumeFileReader[]','factors','double[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'init$org_jmol_jvxl_readers_SurfaceGenerator',  function (sg) {
this.initSR$org_jmol_jvxl_readers_SurfaceGenerator(sg);
var data=sg.getReaderData$();
this.readers=data[0];
this.factors=data[1];
});

Clazz.newMeth(C$, 'readVolumeParameters$Z',  function (isMapData) {
for (var i=this.readers.length; --i >= 0; ) if (!this.readers[i].readVolumeParameters$Z(isMapData)) return false;

return true;
});

Clazz.newMeth(C$, 'getNextVoxelValue$',  function () {
var f=0;
for (var i=this.readers.length; --i >= 0; ) f+=this.factors[i] * this.readers[i].getNextVoxelValue$();

return f;
});

Clazz.newMeth(C$, 'closeReader$',  function () {
if (this.readerClosed) return;
this.readerClosed=true;
for (var i=this.readers.length; --i >= 0; ) this.readers[i].closeReaderSFR$();

if (this.nData == 0 || this.dataMax == -1.7976931348623157E308  ) return;
this.dataMean/=this.nData;
$I$(1,"info$S",["IsoIntersectFileReader closing file: " + this.nData + " points read \ndata min/max/mean = " + new Double(this.dataMin).toString() + "/" + new Double(this.dataMax).toString() + "/" + new Double(this.dataMean).toString() ]);
});

Clazz.newMeth(C$, 'readParameters$',  function () {
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-09-01 22:08:14 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
