(function(){var P$=Clazz.newPackage("org.jmol.jvxl.readers"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "DXReader", null, 'org.jmol.jvxl.readers.ApbsReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'init2$org_jmol_jvxl_readers_SurfaceGenerator$java_io_BufferedReader',  function (sg, br) {
this.init2VFR$org_jmol_jvxl_readers_SurfaceGenerator$java_io_BufferedReader(sg, br);
this.isAngstroms=true;
this.nSurfaces=1;
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:46 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
