(function(){var P$=Clazz.newPackage("org.jmol.appletjs"),I$=[[0,'java.util.Hashtable','org.jmol.util.GenericApplet']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Jmol", null, 'org.jmol.util.GenericApplet');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$java_util_Map',  function (vwrOptions) {
Clazz.super_(C$, this);
this.htParams=Clazz.new_($I$(1,1));
if (vwrOptions == null ) vwrOptions=Clazz.new_($I$(1,1));
this.vwrOptions=vwrOptions;
for (var entry, $entry = vwrOptions.entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) this.htParams.put$O$O(entry.getKey$().toLowerCase$(), entry.getValue$());

this.documentBase="" + vwrOptions.get$O("documentBase");
this.codeBase="" + vwrOptions.get$O("codePath");
$I$(2).isJS=true;
this.init$O(this);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:43 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
