(function(){var P$=Clazz.newPackage("org.jmol.inchi"),p$1={},I$=[[0,'javajs.util.PT','org.iupac.InchiUtils']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InChIJS", null, 'org.jmol.inchi.InchiJmol');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['json'],'O',['atoms','java.util.List','+bonds','+stereo0d','thisAtom','java.util.Map','+thisBond','+thisStereo']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'getInchi$org_jmol_viewer_Viewer$javajs_util_BS$O$S',  function (vwr, atoms, molData, options) {
var ret="";
try {
if (options.equals$O("version")) {
{
return (Jmol.modelFromInchi ? Jmol.modelFromInchi('').ver : "");
}
}options=this.setParameters$S$O$javajs_util_BS$org_jmol_viewer_Viewer(options, molData, atoms, vwr);
if (options == null ) return "";
options=$I$(1,"rep$S$S$S",[$I$(1,"rep$S$S$S",[options.replace$C$C("-", " "), "  ", " "]).trim$(), " ", " -"]).toLowerCase$();
if (options.length$() > 0) options="-" + options;
if (molData == null ) molData=vwr.getModelExtract$O$Z$Z$S(atoms, false, false, "MOL");
if (this.inputInChI) {
if (this.doGetSmiles || this.getInchiModel ) {
{
this.json = (Jmol.modelFromInchi ? Jmol.modelFromInchi(molData).model : "");
if (this.json && !this.getInchiModel) { this.json = JSON.parse(this.json);
}
}
return (this.doGetSmiles ? this.getSmiles$org_jmol_viewer_Viewer$S(vwr, this.smilesOptions) : this.json);
}{
ret = (Jmol.inchikeyFromInchi ? Jmol.inchikeyFromInchi(molData).inchikey : "");
}
} else {
var haveKey=(options.indexOf$S("key") >= 0);
if (haveKey) {
options=options.replace$CharSequence$CharSequence("inchikey", "key");
}{
ret = (Jmol.inchiFromMolfile ? Jmol.inchiFromMolfile(molData, options).inchi : "");
}
}} catch (e) {
{
e = (e.getMessage$ ? e.getMessage$() : e);
}
System.err.println$S("InChIJS exception: " + e);
}
return ret;
});

Clazz.newMeth(C$, 'initializeModelForSmiles$',  function () {
{
this.atoms = this.json.atoms;
this.bonds = this.json.bonds;
this.stereo0d = this.json.stereo0d || [];
}
});

Clazz.newMeth(C$, 'getNumAtoms$',  function () {
{
return this.atoms.length;
}
});

Clazz.newMeth(C$, 'setAtom$I',  function (i) {
{
this.thisAtom = this.atoms[i];
}
return this;
});

Clazz.newMeth(C$, 'getElementType$',  function () {
return p$1.getString$java_util_Map$S$S.apply(this, [this.thisAtom, "elname", ""]);
});

Clazz.newMeth(C$, 'getX$',  function () {
return p$1.getDouble$java_util_Map$S$D.apply(this, [this.thisAtom, "x", 0]);
});

Clazz.newMeth(C$, 'getY$',  function () {
return p$1.getDouble$java_util_Map$S$D.apply(this, [this.thisAtom, "y", 0]);
});

Clazz.newMeth(C$, 'getZ$',  function () {
return p$1.getDouble$java_util_Map$S$D.apply(this, [this.thisAtom, "z", 0]);
});

Clazz.newMeth(C$, 'getCharge$',  function () {
return p$1.getInt$java_util_Map$S$I.apply(this, [this.thisAtom, "charge", 0]);
});

Clazz.newMeth(C$, 'getImplicitH$',  function () {
return p$1.getInt$java_util_Map$S$I.apply(this, [this.thisAtom, "implicitH", 0]);
});

Clazz.newMeth(C$, 'getIsotopicMass$',  function () {
var sym=this.getElementType$();
var mass=0;
{
mass = this.thisAtom["isotopicMass"] || 0;
}
return $I$(2).getActualMass$S$I(sym, mass);
});

Clazz.newMeth(C$, 'getNumBonds$',  function () {
{
return this.bonds.length;
}
});

Clazz.newMeth(C$, 'setBond$I',  function (i) {
{
this.thisBond = this.bonds[i];
}
return this;
});

Clazz.newMeth(C$, 'getIndexOriginAtom$',  function () {
return p$1.getInt$java_util_Map$S$I.apply(this, [this.thisBond, "originAtom", 0]);
});

Clazz.newMeth(C$, 'getIndexTargetAtom$',  function () {
return p$1.getInt$java_util_Map$S$I.apply(this, [this.thisBond, "targetAtom", 0]);
});

Clazz.newMeth(C$, 'getInchiBondType$',  function () {
return p$1.getString$java_util_Map$S$S.apply(this, [this.thisBond, "type", ""]);
});

Clazz.newMeth(C$, 'getNumStereo0D$',  function () {
{
return this.stereo0d.length;
}
});

Clazz.newMeth(C$, 'setStereo0D$I',  function (i) {
{
this.thisStereo = this.stereo0d[i];
}
return this;
});

Clazz.newMeth(C$, 'getParity$',  function () {
return p$1.getString$java_util_Map$S$S.apply(this, [this.thisStereo, "parity", ""]);
});

Clazz.newMeth(C$, 'getStereoType$',  function () {
return p$1.getString$java_util_Map$S$S.apply(this, [this.thisStereo, "type", ""]);
});

Clazz.newMeth(C$, 'getCenterAtom$',  function () {
return p$1.getInt$java_util_Map$S$I.apply(this, [this.thisStereo, "centralAtom", -1]);
});

Clazz.newMeth(C$, 'getNeighbors$',  function () {
{
return this.thisStereo.neighbors;
}
});

Clazz.newMeth(C$, 'getInt$java_util_Map$S$I',  function (map, name, defaultValue) {
{
var val = map[name]; if (val || val == 0) return val;
}
return defaultValue;
}, p$1);

Clazz.newMeth(C$, 'getDouble$java_util_Map$S$D',  function (map, name, defaultValue) {
{
var val = map[name]; if (val || val == 0) return val;
}
return defaultValue;
}, p$1);

Clazz.newMeth(C$, 'getString$java_util_Map$S$S',  function (map, name, defaultValue) {
{
var val = map[name]; if (val || val == "") return val;
}
return defaultValue;
}, p$1);

C$.$static$=function(){C$.$static$=0;
{
try {
{
var j2sPath = J2S._applets.master._j2sPath;
J2S.inchiPath = j2sPath + "/_ES6";
$.getScript(J2S.inchiPath +   "/inchi-web-SwingJS.js");
}
} catch (t) {
}
};
};
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-09-01 22:08:12 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
