(function(){var P$=Clazz.newPackage("org.jmol.inchi"),p$1={},I$=[[0,'java.util.Hashtable','net.sf.jniinchi.JniInchiWrapper','net.sf.jniinchi.JniInchiInput','net.sf.jniinchi.JniInchiInputInchi','org.jmol.inchi.InchiToSmilesConverter','net.sf.jniinchi.JniInchiStructure','net.sf.jniinchi.JniInchiAtom','net.sf.jniinchi.JniInchiBond','org.jmol.util.Elements','net.sf.jniinchi.INCHI_BOND_STEREO','net.sf.jniinchi.INCHI_BOND_TYPE','java.util.HashMap','org.iupac.InchiUtils']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InChIJNI", null, 'org.jmol.inchi.InchiJmol', 'org.iupac.InChIStructureProvider');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.map=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['O',['inchiModel','net.sf.jniinchi.JniInchiOutputStructure','map','java.util.Map','thisAtom','net.sf.jniinchi.JniInchiAtom','thisBond','net.sf.jniinchi.JniInchiBond','thisStereo','net.sf.jniinchi.JniInchiStereo0D']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
System.out.println$S("InChiJNI loaded");
}, 1);

Clazz.newMeth(C$, 'getInchi$org_jmol_viewer_Viewer$javajs_util_BS$O$S',  function (vwr, atoms, molData, options) {
try {
options=this.setParameters$S$O$javajs_util_BS$org_jmol_viewer_Viewer(options, molData, atoms, vwr);
if (options == null ) return "";
if (this.inputInChI) {
options="inch";
this.inchi=$I$(2).getInchiFromInchiString$S$S(this.inchi, options).getInchi$();
} else if (!this.optionalFixedH) {
var $in=Clazz.new_($I$(3,1).c$$S,[this.doGetSmiles ? "fixedh" : options]);
var inchiInputModel;
if (atoms == null ) {
$in.setStructure$net_sf_jniinchi_JniInchiStructure(inchiInputModel=C$.newJniInchiStructure$org_jmol_viewer_Viewer$O(vwr, molData));
} else {
$in.setStructure$net_sf_jniinchi_JniInchiStructure(inchiInputModel=C$.newJniInchiStructureBS$org_jmol_viewer_Viewer$javajs_util_BS(vwr, atoms));
}if (this.getInchiModel) {
return C$.toJSON$net_sf_jniinchi_JniInchiStructure(inchiInputModel);
}var out=$I$(2).getInchi$net_sf_jniinchi_JniInchiInput($in);
var msg=out.getMessage$();
if (msg != null ) System.err.println$S(msg);
this.inchi=out.getInchi$();
}if (this.doGetSmiles || this.getInchiModel ) {
this.inchiModel=$I$(2,"getStructureFromInchi$net_sf_jniinchi_JniInchiInputInchi",[Clazz.new_($I$(4,1).c$$S,[this.inchi])]);
return (this.doGetSmiles ? p$1.getSmiles$org_jmol_viewer_Viewer$S.apply(this, [vwr, this.smilesOptions]) : C$.toJSON$net_sf_jniinchi_JniInchiStructure(this.inchiModel));
}return (this.getKey ? $I$(2).getInchiKey$S(this.inchi).getKey$() : this.inchi);
} catch (e) {
System.out.println$O(e);
if (e.getMessage$().indexOf$S("ption") >= 0) System.out.println$S(e.getMessage$() + ": " + options.toLowerCase$() + "\n See https://www.inchi-trust.org/download/104/inchi-faq.pdf for valid options" );
 else e.printStackTrace$();
return "";
}
});

Clazz.newMeth(C$, 'getSmiles$org_jmol_viewer_Viewer$S',  function (vwr, smilesOptions) {
return Clazz.new_($I$(5,1).c$$org_iupac_InChIStructureProvider,[this]).getSmiles$org_jmol_viewer_Viewer$S(vwr, smilesOptions);
}, p$1);

Clazz.newMeth(C$, 'newJniInchiStructureBS$org_jmol_viewer_Viewer$javajs_util_BS',  function (vwr, bsAtoms) {
var mol=Clazz.new_($I$(6,1));
var atoms=Clazz.array($I$(7), [bsAtoms.cardinality$()]);
var map=Clazz.array(Integer.TYPE, [bsAtoms.length$()]);
var bsBonds=vwr.ms.getBondsForSelectedAtoms$javajs_util_BS$Z(bsAtoms, false);
for (var pt=0, i=bsAtoms.nextSetBit$I(0); i >= 0; i=bsAtoms.nextSetBit$I(i + 1)) {
var a=vwr.ms.at[i];
var sym=a.getElementSymbolIso$Z(false);
var iso=a.getIsotopeNumber$();
if (a.getElementNumber$() == 1) {
sym="H";
}mol.addAtom$net_sf_jniinchi_JniInchiAtom(atoms[pt]=Clazz.new_($I$(7,1).c$$D$D$D$S,[a.x, a.y, a.z, sym]));
atoms[pt].setCharge$I(a.getFormalCharge$());
if (iso > 0) atoms[pt].setIsotopicMass$I(iso);
map[i]=pt++;
}
var bonds=vwr.ms.bo;
for (var i=bsBonds.nextSetBit$I(0); i >= 0; i=bsBonds.nextSetBit$I(i + 1)) {
var bond=bonds[i];
if (bond == null ) continue;
var order=C$.getOrder$I(Math.max(bond.isPartial$() ? 1 : 0, bond.getCovalentOrder$()));
if (order != null ) {
var atom1=bond.getAtomIndex1$();
var atom2=bond.getAtomIndex2$();
var stereo=C$.getInChIStereo$I(bond.getBondType$());
mol.addBond$net_sf_jniinchi_JniInchiBond(Clazz.new_($I$(8,1).c$$net_sf_jniinchi_JniInchiAtom$net_sf_jniinchi_JniInchiAtom$net_sf_jniinchi_INCHI_BOND_TYPE$net_sf_jniinchi_INCHI_BOND_STEREO,[atoms[map[atom1]], atoms[map[atom2]], order, stereo]));
}}
return mol;
}, 1);

Clazz.newMeth(C$, 'newJniInchiStructure$org_jmol_viewer_Viewer$O',  function (vwr, molData) {
try {
var mol=Clazz.new_($I$(6,1));
var adapter=vwr.getModelAdapter$();
System.out.println$S("InChIJNI using MOL file data\n" + molData);
var o=adapter.getAtomSetCollectionInline$O$java_util_Map(molData, null);
if (o == null  || Clazz.instanceOf(o, "java.lang.String") ) {
System.err.println$S("InChIJNI could not read molData " + o);
return null;
}var asc=o;
var ai=adapter.getAtomIterator$O(asc);
var bi=adapter.getBondIterator$O(asc);
var atoms=Clazz.array($I$(7), [asc.getAtomSetAtomCount$I(0)]);
var n=0;
var atomMap=Clazz.new_($I$(1,1));
while (ai.hasNext$() && n < atoms.length ){
var p=ai.getXYZ$();
var atno=ai.getElementNumber$();
if (atno <= 0) {
System.err.println$S("InChIJNI atom " + p + " index " + ai.getUniqueID$() + " is not a valid element" );
return null;
}var isotopeMass=$I$(9).getIsotopeNumber$I(atno);
atno=$I$(9).getElementNumber$I(atno);
var sym=$I$(9).elementSymbolFromNumber$I(atno);
var a=Clazz.new_($I$(7,1).c$$D$D$D$S,[p.x, p.y, p.z, sym]);
a.setIsotopicMass$I(isotopeMass);
a.setCharge$I(ai.getFormalCharge$());
mol.addAtom$net_sf_jniinchi_JniInchiAtom(a);
atomMap.put$O$O(ai.getUniqueID$(), Integer.valueOf$I(n));
atoms[n++]=a;
}
var nb=0;
while (bi.hasNext$()){
var jmolOrder=bi.getEncodedOrder$();
var order=C$.getOrder$I(jmolOrder);
if (order != null ) {
var id1=atomMap.get$O(bi.getAtomUniqueID1$());
var id2=atomMap.get$O(bi.getAtomUniqueID2$());
if (id1 == null  || id2 == null  ) {
System.err.println$S("InChIJNI bond " + nb + "has null atom " + (id1 == null  ? bi.getAtomUniqueID1$() : "") + " " + (id2 == null  ? bi.getAtomUniqueID2$() : "") );
return null;
}var a=atoms[id1.intValue$()];
var b=atoms[id2.intValue$()];
if (a == null  || b == null  ) {
System.err.println$S("InChIJNI bond " + nb + "has null atom: " + a + "/" + b + " for ids " + id1 + " " + id2 + " and " + n + " atoms" );
return null;
}mol.addBond$net_sf_jniinchi_JniInchiBond(Clazz.new_([a, b, order, C$.getInChIStereo$I(jmolOrder)],$I$(8,1).c$$net_sf_jniinchi_JniInchiAtom$net_sf_jniinchi_JniInchiAtom$net_sf_jniinchi_INCHI_BOND_TYPE$net_sf_jniinchi_INCHI_BOND_STEREO));
++nb;
}}
return mol;
} catch (t) {
t.printStackTrace$();
System.err.println$S(t.toString());
}
return null;
}, 1);

Clazz.newMeth(C$, 'getInChIStereo$I',  function (jmolOrder) {
switch (jmolOrder) {
case 1041:
return $I$(10).SINGLE_1DOWN;
case 1025:
return $I$(10).SINGLE_1UP;
case 1057:
return $I$(10).SINGLE_1EITHER;
default:
return $I$(10).NONE;
}
}, 1);

Clazz.newMeth(C$, 'getOrder$I',  function (jmolOrder) {
switch (jmolOrder) {
case 1057:
case 1041:
case 1025:
case 1:
return $I$(11).SINGLE;
case 2:
return $I$(11).DOUBLE;
case 3:
return $I$(11).TRIPLE;
default:
return null;
}
}, 1);

Clazz.newMeth(C$, 'toJSON$net_sf_jniinchi_JniInchiStructure',  function (mol) {
var na=mol.getNumAtoms$();
var nb=mol.getNumBonds$();
var ns=mol.getNumStereo0D$();
var mapAtoms=Clazz.new_($I$(12,1));
var haveXYZ=false;
for (var i=0; i < na; i++) {
var a=mol.getAtom$I(i);
if (a.getX$() != 0  || a.getY$() != 0   || a.getZ$() != 0  ) {
haveXYZ=true;
break;
}}
var s="{";
s+="\n\"atomCount\":" + na + ",\n" ;
s+="\"atoms\":[\n";
for (var i=0; i < na; i++) {
var a=mol.getAtom$I(i);
mapAtoms.put$O$O(a, Integer.valueOf$I(i));
if (i > 0) s+=",\n";
s+="{";
s+=C$.toJSONInt$S$I$S("index", (Integer.valueOf$I(i)).$c(), "");
s+=C$.toJSONNotNone$S$O$S("elname", a.getElementType$(), ",");
if (haveXYZ) {
s+=C$.toJSONDouble$S$D$S("x", a.getX$(), ",");
s+=C$.toJSONDouble$S$D$S("y", a.getY$(), ",");
s+=C$.toJSONDouble$S$D$S("z", a.getZ$(), ",");
}s+=C$.toJSONNonZero$S$I$S("isotopeMass", a.getIsotopicMass$(), ",");
s+=C$.toJSONNonZero$S$I$S("charge", a.getCharge$(), ",");
s+=C$.toJSONNotNone$S$O$S("radical", a.getRadical$(), ",");
if (a.getImplicitH$() > 0) s+=C$.toJSONNonZero$S$I$S("implicitH", a.getImplicitH$(), ",");
s+=C$.toJSONNonZero$S$I$S("implicitDeuterium", a.getImplicitDeuterium$(), ",");
s+=C$.toJSONNonZero$S$I$S("implicitProtium", a.getImplicitProtium$(), ",");
s+=C$.toJSONNonZero$S$I$S("implicitTritium", a.getImplicitTritium$(), ",");
s+="}";
}
s+="\n],";
s+="\n\"bondCount\":" + nb + ",\n" ;
s+="\n\"bonds\":[\n";
for (var i=0; i < nb; i++) {
if (i > 0) s+=",\n";
s+="{";
var b=mol.getBond$I(i);
s+=C$.toJSONInt$S$I$S("originAtom", mapAtoms.get$O(b.getOriginAtom$()).intValue$(), "");
s+=C$.toJSONInt$S$I$S("targetAtom", mapAtoms.get$O(b.getTargetAtom$()).intValue$(), ",");
var bt=b.getBondType$().toString();
if (!bt.equals$O("SINGLE")) s+=C$.toJSONString$S$S$S("type", bt, ",");
s+=C$.toJSONNotNone$S$O$S("stereo", b.getBondStereo$(), ",");
s+="}";
}
s+="\n]";
if (ns > 0) {
s+=",\n\"stereoCount\":" + ns + ",\n" ;
s+="\"stereo\":[\n";
for (var i=0; i < ns; i++) {
if (i > 0) s+=",\n";
s+="{";
var d=mol.getStereo0D$I(i);
s+=C$.toJSONNotNone$S$O$S("type", d.getStereoType$(), "");
s+=C$.toJSONNotNone$S$O$S("parity", d.getParity$(), ",");
var an=d.getNeighbors$();
var nbs=Clazz.array(Integer.TYPE, [an.length]);
for (var j=0; j < an.length; j++) {
nbs[j]=mapAtoms.get$O(d.getNeighbor$I(j)).intValue$();
}
s+=C$.toJSONArray$S$IA$S("neighbors", nbs, ",");
var a=d.getCentralAtom$();
if (a != null ) s+=C$.toJSONInt$S$I$S("centralAtom", mapAtoms.get$O(a).intValue$(), ",");
s+="}";
}
s+="\n]";
}s+="}";
System.out.println$S(s);
return s;
}, 1);

Clazz.newMeth(C$, 'toJSONArray$S$IA$S',  function (key, val, term) {
var s=term + "\"" + key + "\":[" + val[0] ;
for (var i=1; i < val.length; i++) {
s+="," + val[i];
}
return s + "]";
}, 1);

Clazz.newMeth(C$, 'toJSONNonZero$S$I$S',  function (key, val, term) {
return (val == 0 ? "" : C$.toJSONInt$S$I$S(key, val, term));
}, 1);

Clazz.newMeth(C$, 'toJSONInt$S$I$S',  function (key, val, term) {
return term + "\"" + key + "\":" + val ;
}, 1);

Clazz.newMeth(C$, 'toJSONDouble$S$D$S',  function (key, val, term) {
var s;
if (val == 0 ) {
s="0";
} else {
s="" + (new Double(val + (val > 0  ? 1.0E-8 : -1.0E-8)).toString());
s=s.substring$I$I(0, s.indexOf$S(".") + 5);
var n=s.length$();
while (s.charAt$I(--n) == "0"){
}
s=s.substring$I$I(0, n + 1);
}return term + "\"" + key + "\":" + s ;
}, 1);

Clazz.newMeth(C$, 'toJSONString$S$S$S',  function (key, val, term) {
return term + "\"" + key + "\":\"" + val + "\"" ;
}, 1);

Clazz.newMeth(C$, 'toJSONNotNone$S$O$S',  function (key, val, term) {
var s=val.toString();
return ("NONE".equals$O(s) ? "" : term + "\"" + key + "\":\"" + s + "\"" );
}, 1);

Clazz.newMeth(C$, 'initializeModelForSmiles$',  function () {
for (var i=this.getNumAtoms$(); --i >= 0; ) this.map.put$O$O(this.inchiModel.getAtom$I(i), Integer.valueOf$I(i));

});

Clazz.newMeth(C$, 'getNumAtoms$',  function () {
return this.inchiModel.getNumAtoms$();
});

Clazz.newMeth(C$, 'setAtom$I',  function (i) {
this.thisAtom=this.inchiModel.getAtom$I(i);
return this;
});

Clazz.newMeth(C$, 'getElementType$',  function () {
return this.thisAtom.getElementType$();
});

Clazz.newMeth(C$, 'getX$',  function () {
return this.thisAtom.getX$();
});

Clazz.newMeth(C$, 'getY$',  function () {
return this.thisAtom.getY$();
});

Clazz.newMeth(C$, 'getZ$',  function () {
return this.thisAtom.getZ$();
});

Clazz.newMeth(C$, 'getCharge$',  function () {
return this.thisAtom.getCharge$();
});

Clazz.newMeth(C$, 'getIsotopicMass$',  function () {
return $I$(13,"getActualMass$S$I",[this.getElementType$(), this.thisAtom.getIsotopicMass$()]);
});

Clazz.newMeth(C$, 'getImplicitH$',  function () {
return this.thisAtom.getImplicitH$();
});

Clazz.newMeth(C$, 'getNumBonds$',  function () {
return this.inchiModel.getNumBonds$();
});

Clazz.newMeth(C$, 'setBond$I',  function (i) {
this.thisBond=this.inchiModel.getBond$I(i);
return this;
});

Clazz.newMeth(C$, 'getIndexOriginAtom$',  function () {
return this.map.get$O(this.thisBond.getOriginAtom$()).intValue$();
});

Clazz.newMeth(C$, 'getIndexTargetAtom$',  function () {
return this.map.get$O(this.thisBond.getTargetAtom$()).intValue$();
});

Clazz.newMeth(C$, 'getInchiBondType$',  function () {
var type=this.thisBond.getBondType$();
return type.name$();
});

Clazz.newMeth(C$, 'getNumStereo0D$',  function () {
return this.inchiModel.getNumStereo0D$();
});

Clazz.newMeth(C$, 'setStereo0D$I',  function (i) {
this.thisStereo=this.inchiModel.getStereo0D$I(i);
return this;
});

Clazz.newMeth(C$, 'getNeighbors$',  function () {
var an=this.thisStereo.getNeighbors$();
var n=an.length;
var a=Clazz.array(Integer.TYPE, [n]);
for (var i=0; i < n; i++) {
a[i]=this.map.get$O(an[i]).intValue$();
}
return a;
});

Clazz.newMeth(C$, 'getCenterAtom$',  function () {
var ca=this.thisStereo.getCentralAtom$();
return (ca == null  ? -1 : this.map.get$O(ca).intValue$());
});

Clazz.newMeth(C$, 'getStereoType$',  function () {
return this.thisStereo.getStereoType$().toString();
});

Clazz.newMeth(C$, 'getParity$',  function () {
return this.thisStereo.getParity$().toString();
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-05 22:28:51 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
