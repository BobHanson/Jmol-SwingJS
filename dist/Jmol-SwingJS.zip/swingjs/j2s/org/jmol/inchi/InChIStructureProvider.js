(function(){var P$=Clazz.newPackage("org.jmol.inchi"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "InChIStructureProvider");
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-28 11:29:14 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
