(function(){var P$=Clazz.newPackage("org.jmol.inchi"),p$1={},I$=[[0,'javajs.util.Lst','javajs.util.BS','java.util.Hashtable','org.jmol.smiles.SmilesAtom','org.jmol.smiles.SmilesBond','org.jmol.util.BSUtil','org.jmol.util.Logger']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InchiToSmilesConverter");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.listSmiles=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['O',['mapTet','java.util.Map','+mapPlanar','listSmiles','javajs.util.Lst','provider','org.iupac.InChIStructureProvider']]]

Clazz.newMeth(C$, 'c$$org_iupac_InChIStructureProvider',  function (provider) {
;C$.$init$.apply(this);
this.provider=provider;
provider.initializeModelForSmiles$();
}, 1);

Clazz.newMeth(C$, 'getSmiles$org_jmol_viewer_Viewer$S',  function (vwr, smilesOptions) {
var hackImine=(smilesOptions.indexOf$S("imine") >= 0);
var bsImplicitH=(smilesOptions.indexOf$S("amide") >= 0 ? Clazz.new_($I$(2,1)) : null);
var nAtoms=this.provider.getNumAtoms$();
var nBonds=this.provider.getNumBonds$();
var nh=0;
for (var i=0; i < nAtoms; i++) {
nh+=this.provider.setAtom$I(i).getImplicitH$();
}
var atoms=Clazz.new_($I$(1,1));
this.mapTet=Clazz.new_($I$(3,1));
this.mapPlanar=Clazz.new_($I$(3,1));
var nb=0;
var na=0;
for (var i=0; i < nAtoms; i++) {
this.provider.setAtom$I(i);
var n=((P$.InchiToSmilesConverter$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "InchiToSmilesConverter$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('org.jmol.smiles.SmilesAtom'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'definesStereo$',  function () {
return true;
});

Clazz.newMeth(C$, 'getStereoAtAt$org_jmol_util_SimpleNodeA',  function (nodes) {
return this.b$['org.jmol.inchi.InchiToSmilesConverter'].decodeInchiStereo$org_jmol_util_SimpleNodeA.apply(this.b$['org.jmol.inchi.InchiToSmilesConverter'], [nodes]);
});

Clazz.newMeth(C$, 'isStereoOpposite$I$I$I',  function (i2, iA, iB) {
return this.b$['org.jmol.inchi.InchiToSmilesConverter'].isInchiOpposite$I$I$I$I.apply(this.b$['org.jmol.inchi.InchiToSmilesConverter'], [this.getIndex$(), i2, iA, iB]);
});
})()
), Clazz.new_($I$(4,1),[this, null],P$.InchiToSmilesConverter$1));
atoms.addLast$O(n);
n.set$D$D$D(this.provider.getX$(), this.provider.getY$(), this.provider.getZ$());
n.setIndex$I(na++);
n.setCharge$I(this.provider.getCharge$());
n.setSymbol$S(this.provider.getElementType$());
var m=this.provider.getIsotopicMass$();
if (m > 0) n.setAtomicMass$I(m);
nh=this.provider.getImplicitH$();
if (nh > 0 && bsImplicitH != null  ) bsImplicitH.set$I(na - 1);
for (var j=0; j < nh; j++) {
p$1.addH$javajs_util_Lst$org_jmol_smiles_SmilesAtom$I.apply(this, [atoms, n, nb++]);
++na;
}
this.listSmiles.addLast$O(n);
}
for (var i=0; i < nBonds; i++) {
this.provider.setBond$I(i);
var bt=C$.getJmolBondType$S(this.provider.getInchiBondType$());
var sa1=this.listSmiles.get$I(this.provider.getIndexOriginAtom$());
var sa2=this.listSmiles.get$I(this.provider.getIndexTargetAtom$());
var sb=Clazz.new_($I$(5,1).c$$org_jmol_smiles_SmilesAtom$org_jmol_smiles_SmilesAtom$I$Z,[sa1, sa2, bt, false]);
sb.index=nb++;
}
nb=p$1.checkSpecial$javajs_util_Lst$I$Z$javajs_util_BS.apply(this, [atoms, nb, hackImine, bsImplicitH]);
na=atoms.size$();
var aatoms=Clazz.array($I$(4), [na]);
atoms.toArray$OA(aatoms);
for (var i=0; i < na; i++) {
aatoms[i].setBondArray$();
}
var iA=-1;
var iB=-1;
for (var i=this.provider.getNumStereo0D$(); --i >= 0; ) {
this.provider.setStereo0D$I(i);
var neighbors=this.provider.getNeighbors$();
if (neighbors.length != 4) continue;
var centerAtom=this.provider.getCenterAtom$();
var i0=this.listSmiles.get$I(neighbors[0]).getIndex$();
var i1=this.listSmiles.get$I(neighbors[1]).getIndex$();
var i2=this.listSmiles.get$I(neighbors[2]).getIndex$();
var i3=this.listSmiles.get$I(neighbors[3]).getIndex$();
var isEven=(this.provider.getParity$().equals$O("EVEN"));
var type=this.provider.getStereoType$();
switch (type) {
case "ALLENE":
case "DOUBLEBOND":
iA=i1;
iB=i2;
i1=C$.getOtherEneAtom$org_jmol_smiles_SmilesAtomA$I$I(aatoms, i1, i0);
i2=C$.getOtherEneAtom$org_jmol_smiles_SmilesAtomA$I$I(aatoms, i2, i3);
break;
case "NONE":
continue;
case "TETRAHEDRAL":
break;
}
if (centerAtom == -1) {
p$1.setPlanarKey$I$I$I$I$Boolean.apply(this, [i0, i3, iA, iB, Boolean.valueOf$Z(isEven)]);
p$1.setPlanarKey$I$I$I$I$Boolean.apply(this, [i0, i2, iA, iB, Boolean.valueOf$Z(!isEven)]);
p$1.setPlanarKey$I$I$I$I$Boolean.apply(this, [i1, i2, iA, iB, Boolean.valueOf$Z(isEven)]);
p$1.setPlanarKey$I$I$I$I$Boolean.apply(this, [i1, i3, iA, iB, Boolean.valueOf$Z(!isEven)]);
p$1.setPlanarKey$I$I$I$I$Boolean.apply(this, [i0, i1, iA, iB, Boolean.TRUE]);
p$1.setPlanarKey$I$I$I$I$Boolean.apply(this, [i2, i3, iA, iB, Boolean.TRUE]);
} else {
var list=Clazz.array(Integer.TYPE, -1, [isEven ? i0 : i1, isEven ? i1 : i0, i2, i3]);
this.mapTet.put$O$O(C$.orderList$IA(list), list);
}}
try {
var m=vwr.getSmilesMatcher$();
var smiles=m.getSmiles$org_jmol_util_NodeA$I$javajs_util_BS$S$I(aatoms, na, $I$(6).newBitSet2$I$I(0, na), smilesOptions, 1);
$I$(7).info$S("InchiToSmiles: " + smiles);
return smiles;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
return "";
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'setPlanarKey$I$I$I$I$Boolean',  function (i0, i3, iA, iB, v) {
this.mapPlanar.put$O$O(C$.getIntKey$I$I$I(i0, iA, i3), v);
this.mapPlanar.put$O$O(C$.getIntKey$I$I$I(i0, iB, i3), v);
}, p$1);

Clazz.newMeth(C$, 'addH$javajs_util_Lst$org_jmol_smiles_SmilesAtom$I',  function (atoms, n, nb) {
var h=Clazz.new_($I$(4,1));
h.setIndex$I(atoms.size$());
h.setSymbol$S("H");
atoms.addLast$O(h);
var sb=Clazz.new_($I$(5,1).c$$org_jmol_smiles_SmilesAtom$org_jmol_smiles_SmilesAtom$I$Z,[n, h, 1, false]);
sb.index=nb;
return h;
}, p$1);

Clazz.newMeth(C$, 'checkSpecial$javajs_util_Lst$I$Z$javajs_util_BS',  function (atoms, nb, hackImine, bsImplicitH) {
for (var i=atoms.size$(); --i >= 0; ) {
var a=atoms.get$I(i);
var val=a.getValence$();
var nbonds=a.getCovalentBondCount$();
var nbtot=a.getBondCount$();
var ano=a.getElementNumber$();
var formalCharge=a.getCharge$();
var b1=null;
var b2=null;
switch (val * 10 + nbonds) {
case 32:
if (ano == 7) {
if (hackImine) {
a.setSymbol$S("C");
a.setAtomicMass$I(17);
var h=p$1.addH$javajs_util_Lst$org_jmol_smiles_SmilesAtom$I.apply(this, [atoms, a, nb++]);
h.setAtomicMass$I(5);
} else if (bsImplicitH != null ) {
var c=p$1.getOther$javajs_util_Lst$org_jmol_smiles_SmilesAtom$I$I.apply(this, [atoms, a, 2, 6]);
if (c != null  && c.getElementNumber$() == 6 ) {
var o=p$1.getOther$javajs_util_Lst$org_jmol_smiles_SmilesAtom$I$I.apply(this, [atoms, c, 1, 8]);
if (o != null  && bsImplicitH.get$I(o.getIndex$()) ) {
var h=p$1.getOther$javajs_util_Lst$org_jmol_smiles_SmilesAtom$I$I.apply(this, [atoms, o, 1, 1]);
var nc=p$1.getBond$org_jmol_smiles_SmilesAtom$org_jmol_smiles_SmilesAtom.apply(this, [a, c]);
var co=p$1.getBond$org_jmol_smiles_SmilesAtom$org_jmol_smiles_SmilesAtom.apply(this, [o, c]);
var oh=h.getBond$I(0);
co.set2$I$Z(2, false);
nc.set2$I$Z(1, false);
oh.set2$I$Z(4096, false);
var b=Clazz.new_($I$(5,1).c$$org_jmol_smiles_SmilesAtom$org_jmol_smiles_SmilesAtom$I$Z,[h, a, 1, false]);
b.index=oh.index;
}}}}break;
case 53:
if (ano == 7 && formalCharge == 0 ) {
for (var j=0; j < nbtot; j++) {
var b=a.getBond$I(j);
if (b.getCovalentOrder$() == 2) {
if (b1 == null ) {
b1=b;
} else {
b2=b;
break;
}}}
}break;
case 54:
break;
}
if (b2 != null ) {
var a2=b2.getOtherAtom$org_jmol_smiles_SmilesAtom(a);
a2.setCharge$I(-1);
a.setCharge$I(1);
b2.set2$I$Z(1, false);
}}
return nb;
}, p$1);

Clazz.newMeth(C$, 'getBond$org_jmol_smiles_SmilesAtom$org_jmol_smiles_SmilesAtom',  function (a, c) {
for (var i=a.getBondCount$(); --i >= 0; ) {
var b=a.getBond$I(i);
if (b.getOtherAtom$org_jmol_smiles_SmilesAtom(a) === c ) return b;
}
return null;
}, p$1);

Clazz.newMeth(C$, 'getOther$javajs_util_Lst$org_jmol_smiles_SmilesAtom$I$I',  function (atoms, a, bondType, elemNo) {
for (var i=a.getBondCount$(); --i >= 0; ) {
var a2;
if (a.getBond$I(i).getCovalentOrder$() == bondType && (a2=atoms.get$I(a.getBondedAtomIndex$I(i))).getElementNumber$() == elemNo ) {
return a2;
}}
return null;
}, p$1);

Clazz.newMeth(C$, 'isInchiOpposite$I$I$I$I',  function (i1, i2, iA, iB) {
var b=this.mapPlanar.get$O(C$.getIntKey$I$I$I(i1, Math.max(iA, iB), i2));
return b;
});

Clazz.newMeth(C$, 'decodeInchiStereo$org_jmol_util_SimpleNodeA',  function (nodes) {
var list=Clazz.array(Integer.TYPE, -1, [C$.getNodeIndex$org_jmol_util_SimpleNode(nodes[0]), C$.getNodeIndex$org_jmol_util_SimpleNode(nodes[1]), C$.getNodeIndex$org_jmol_util_SimpleNode(nodes[2]), C$.getNodeIndex$org_jmol_util_SimpleNode(nodes[3])]);
var list2=this.mapTet.get$O(C$.orderList$IA(list));
return (list2 == null  ? null : C$.isPermutation$IA$IA(list, list2) ? "@@" : "@");
});

Clazz.newMeth(C$, 'getNodeIndex$org_jmol_util_SimpleNode',  function (node) {
return (node == null  ? -1 : node.getIndex$());
}, 1);

Clazz.newMeth(C$, 'getIntKey$I$I$I',  function (i, iA, j) {
var v=Integer.valueOf$I((Math.min(i, j) << 24) + (iA << 12) + Math.max(i, j) );
return v;
}, 1);

Clazz.newMeth(C$, 'orderList$IA',  function (list) {
var bs=Clazz.new_($I$(2,1));
for (var i=0; i < list.length; i++) bs.set$I(list[i]);

return bs;
}, 1);

Clazz.newMeth(C$, 'isPermutation$IA$IA',  function (list, list2) {
var ok=true;
for (var i=0; i < 3; i++) {
var l1=list[i];
for (var j=i + 1; j < 4; j++) {
var l2=list2[j];
if (l2 == l1) {
if (j != i) {
list2[j]=list2[i];
list2[i]=l2;
ok=!ok;
}}}
}
return ok;
}, 1);

Clazz.newMeth(C$, 'getOtherEneAtom$org_jmol_smiles_SmilesAtomA$I$I',  function (atoms, i0, i1) {
var a=atoms[i0];
for (var i=a.getBondCount$(); --i >= 0; ) {
if (a.getBond$I(i).getBondType$() == 1) {
var i2=a.getBondedAtomIndex$I(i);
if (i2 != i1) {
return i2;
}}}
return -1;
}, 1);

Clazz.newMeth(C$, 'getJmolBondType$S',  function (type) {
switch (type) {
case "NONE":
return 0;
case "ALTERN":
return 515;
case "DOUBLE":
return 2;
case "TRIPLE":
return 3;
case "SINGLE":
default:
return 1;
}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-09-01 22:08:12 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
