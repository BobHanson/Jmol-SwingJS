(function(){var P$=Clazz.newPackage("org.jmol.inchi"),I$=[[0,'javajs.util.PT','org.jmol.inchi.InchiToSmilesConverter']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InchiJmol", null, null, ['org.jmol.api.JmolInChI', 'org.iupac.InChIStructureProvider']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['inputInChI','doGetSmiles','getInchiModel','getKey','optionalFixedH'],'S',['inchi','smilesOptions']]]

Clazz.newMeth(C$, 'setParameters$S$O$javajs_util_BS$org_jmol_viewer_Viewer',  function (options, molData, atoms, vwr) {
if (atoms == null  ? molData == null  : atoms.isEmpty$()) return null;
if (options == null ) options="";
var inchi=null;
var lc=options.toLowerCase$().trim$();
var getSmiles=(lc.indexOf$S("smiles") == 0);
var getInchiModel=(lc.indexOf$S("model") == 0);
var getKey=(lc.indexOf$S("key") >= 0);
var smilesOptions=(getSmiles ? options : null);
if (lc.startsWith$S("model/")) {
inchi=options.substring$I(10);
options=lc="";
} else if (getInchiModel) {
lc=lc.substring$I(5);
}var optionalFixedH=(options.indexOf$S("fixedh?") >= 0);
var inputInChI=(Clazz.instanceOf(molData, "java.lang.String") && (molData).startsWith$S("InChI=") );
if (inputInChI) {
inchi=molData;
} else {
options=lc;
if (getKey) {
options=options.replace$CharSequence$CharSequence("inchikey", "");
options=options.replace$CharSequence$CharSequence("key", "");
}if (optionalFixedH) {
var fxd=this.getInchi$org_jmol_viewer_Viewer$javajs_util_BS$O$S(vwr, atoms, molData, options.replace$C$C("?", " "));
options=$I$(1).rep$S$S$S(options, "fixedh?", "");
var std=this.getInchi$org_jmol_viewer_Viewer$javajs_util_BS$O$S(vwr, atoms, molData, options);
inchi=(fxd != null  && fxd.length$() <= std.length$()  ? std : fxd);
}}this.optionalFixedH=optionalFixedH;
this.inputInChI=inputInChI;
this.doGetSmiles=getSmiles;
this.inchi=inchi;
this.getKey=getKey;
this.smilesOptions=smilesOptions;
this.getInchiModel=getInchiModel;
return options;
});

Clazz.newMeth(C$, 'getSmiles$org_jmol_viewer_Viewer$S',  function (vwr, smilesOptions) {
return Clazz.new_($I$(2,1).c$$org_iupac_InChIStructureProvider,[this]).getSmiles$org_jmol_viewer_Viewer$S(vwr, smilesOptions);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:45 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
