(function(){var P$=Clazz.newPackage("org.jmol.inchi"),I$=[[0,'java.util.Hashtable','io.github.dan2097.jnainchi.JnaInchi',['io.github.dan2097.jnainchi.InchiOptions','.InchiOptionsBuilder'],'java.util.StringTokenizer','io.github.dan2097.jnainchi.InchiFlag','io.github.dan2097.jnainchi.InchiInput','io.github.dan2097.jnainchi.InchiAtom','io.github.dan2097.jnainchi.InchiBond','io.github.dan2097.jnainchi.InchiBondStereo','io.github.dan2097.jnainchi.InchiBondType','java.util.HashMap','org.iupac.InchiUtils','io.github.dan2097.jnainchi.inchi.InchiLibrary','com.sun.jna.Native','java.io.FileInputStream']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InChIJNA", null, 'org.jmol.inchi.InchiJmol');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.map=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['O',['inchiModel','io.github.dan2097.jnainchi.InchiInput','map','java.util.Map','thisAtom','io.github.dan2097.jnainchi.InchiAtom','thisBond','io.github.dan2097.jnainchi.InchiBond','thisStereo','io.github.dan2097.jnainchi.InchiStereo']]
,['S',['inchiVersionInternal']]]

Clazz.newMeth(C$, 'getInchi$org_jmol_viewer_Viewer$javajs_util_BS$O$S',  function (vwr, atoms, molData, options) {
if ("version".equals$O(options)) return C$.getInternalInchiVersion$();
try {
options=this.setParameters$S$O$javajs_util_BS$org_jmol_viewer_Viewer(options, molData, atoms, vwr);
if (options == null ) return "";
var ops=C$.getOptions$S(options.toLowerCase$());
var out=null;
var $in;
if (this.inputInChI) {
out=$I$(2).inchiToInchi$S$io_github_dan2097_jnainchi_InchiOptions(molData, ops);
} else if (!this.optionalFixedH) {
if (atoms == null ) {
out=$I$(2).molToInchi$S$io_github_dan2097_jnainchi_InchiOptions(molData, ops);
} else {
$in=C$.newInchiStructureBS$org_jmol_viewer_Viewer$javajs_util_BS(vwr, atoms);
out=$I$(2,"toInchi$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_InchiOptions",[$in, C$.getOptions$S(this.doGetSmiles ? "fixedh" : options)]);
}}if (out != null ) {
var msg=out.getMessage$();
if (msg != null ) System.err.println$S(msg);
this.inchi=out.getInchi$();
}if (this.doGetSmiles || this.getInchiModel ) {
this.inchiModel=$I$(2).getInchiInputFromInchi$S(this.inchi).getInchiInput$();
return (this.doGetSmiles ? this.getSmiles$org_jmol_viewer_Viewer$S(vwr, this.smilesOptions) : C$.toJSON$io_github_dan2097_jnainchi_InchiInput(this.inchiModel));
}return (this.getKey ? $I$(2).inchiToInchiKey$S(this.inchi).getInchiKey$() : this.inchi);
} catch (e) {
System.out.println$O(e);
if (e.getMessage$() != null  && e.getMessage$().indexOf$S("ption") >= 0 ) System.out.println$S(e.getMessage$() + ": " + options.toLowerCase$() + "\n See https://www.inchi-trust.org/download/104/inchi-faq.pdf for valid options" );
 else e.printStackTrace$();
return "";
}
});

Clazz.newMeth(C$, 'getOptions$S',  function (options) {
var builder=Clazz.new_($I$(3,1));
var t=Clazz.new_($I$(4,1).c$$S,[options]);
while (t.hasMoreElements$()){
var o=t.nextToken$();
switch (o) {
case "smiles":
case "amide":
case "imine":
continue;
}
var f=$I$(5).getFlagFromName$S(o);
if (f == null ) {
System.err.println$S("InChIJNA InChI option " + o + " not recognized -- ignored" );
} else {
builder.withFlag$io_github_dan2097_jnainchi_InchiFlagA(Clazz.array($I$(5), -1, [f]));
}}
return builder.build$();
}, 1);

Clazz.newMeth(C$, 'newInchiStructureBS$org_jmol_viewer_Viewer$javajs_util_BS',  function (vwr, bsAtoms) {
var mol=Clazz.new_($I$(6,1));
var atoms=Clazz.array($I$(7), [bsAtoms.cardinality$()]);
var map=Clazz.array(Integer.TYPE, [bsAtoms.length$()]);
var bsBonds=vwr.ms.getBondsForSelectedAtoms$javajs_util_BS$Z(bsAtoms, false);
for (var pt=0, i=bsAtoms.nextSetBit$I(0); i >= 0; i=bsAtoms.nextSetBit$I(i + 1)) {
var a=vwr.ms.at[i];
var sym=a.getElementSymbolIso$Z(false);
var iso=a.getIsotopeNumber$();
if (a.getElementNumber$() == 1) {
sym="H";
}mol.addAtom$io_github_dan2097_jnainchi_InchiAtom(atoms[pt]=Clazz.new_($I$(7,1).c$$S$D$D$D,[sym, a.x, a.y, a.z]));
atoms[pt].setCharge$I(a.getFormalCharge$());
if (iso > 0) atoms[pt].setIsotopicMass$I(iso);
map[i]=pt++;
}
var bonds=vwr.ms.bo;
for (var i=bsBonds.nextSetBit$I(0); i >= 0; i=bsBonds.nextSetBit$I(i + 1)) {
var bond=bonds[i];
if (bond == null ) continue;
var order=C$.getOrder$I(Math.max(bond.isPartial$() ? 1 : 0, bond.getCovalentOrder$()));
if (order != null ) {
var atom1=bond.getAtomIndex1$();
var atom2=bond.getAtomIndex2$();
var stereo=C$.getInChIStereo$I(bond.getBondType$());
mol.addBond$io_github_dan2097_jnainchi_InchiBond(Clazz.new_($I$(8,1).c$$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType$io_github_dan2097_jnainchi_InchiBondStereo,[atoms[map[atom1]], atoms[map[atom2]], order, stereo]));
}}
return mol;
}, 1);

Clazz.newMeth(C$, 'getInChIStereo$I',  function (jmolOrder) {
switch (jmolOrder) {
case 1041:
return $I$(9).SINGLE_1DOWN;
case 1025:
return $I$(9).SINGLE_1UP;
case 1057:
return $I$(9).SINGLE_1EITHER;
default:
return $I$(9).NONE;
}
}, 1);

Clazz.newMeth(C$, 'getOrder$I',  function (jmolOrder) {
switch (jmolOrder) {
case 1057:
case 1041:
case 1025:
case 1:
return $I$(10).SINGLE;
case 2:
return $I$(10).DOUBLE;
case 3:
return $I$(10).TRIPLE;
default:
return null;
}
}, 1);

Clazz.newMeth(C$, 'toJSON$io_github_dan2097_jnainchi_InchiInput',  function (mol) {
var na=C$.sizeof$java_util_List(mol.getAtoms$());
var nb=C$.sizeof$java_util_List(mol.getBonds$());
var ns=C$.sizeof$java_util_List(mol.getStereos$());
var mapAtoms=Clazz.new_($I$(11,1));
var haveXYZ=false;
for (var i=0; i < na; i++) {
var a=mol.getAtom$I(i);
if (a.getX$() != 0  || a.getY$() != 0   || a.getZ$() != 0  ) {
haveXYZ=true;
break;
}}
var s="{";
s+="\n\"atomCount\":" + na + ",\n" ;
s+="\"atoms\":[\n";
for (var i=0; i < na; i++) {
var a=mol.getAtom$I(i);
mapAtoms.put$O$O(a, Integer.valueOf$I(i));
if (i > 0) s+=",\n";
s+="{";
s+=C$.toJSONInt$S$I$S("index", (Integer.valueOf$I(i)).$c(), "");
s+=C$.toJSONNotNone$S$O$S("elname", a.getElName$(), ",");
if (haveXYZ) {
s+=C$.toJSONDouble$S$D$S("x", a.getX$(), ",");
s+=C$.toJSONDouble$S$D$S("y", a.getY$(), ",");
s+=C$.toJSONDouble$S$D$S("z", a.getZ$(), ",");
}s+=C$.toJSONNonZero$S$I$S("isotopeMass", a.getIsotopicMass$(), ",");
s+=C$.toJSONNonZero$S$I$S("charge", a.getCharge$(), ",");
s+=C$.toJSONNotNone$S$O$S("radical", a.getRadical$(), ",");
if (a.getImplicitHydrogen$() > 0) s+=C$.toJSONNonZero$S$I$S("implicitH", a.getImplicitHydrogen$(), ",");
s+=C$.toJSONNonZero$S$I$S("implicitDeuterium", a.getImplicitDeuterium$(), ",");
s+=C$.toJSONNonZero$S$I$S("implicitProtium", a.getImplicitProtium$(), ",");
s+=C$.toJSONNonZero$S$I$S("implicitTritium", a.getImplicitTritium$(), ",");
s+="}";
}
s+="\n],";
s+="\n\"bondCount\":" + nb + ",\n" ;
s+="\n\"bonds\":[\n";
for (var i=0; i < nb; i++) {
if (i > 0) s+=",\n";
s+="{";
var b=mol.getBond$I(i);
s+=C$.toJSONInt$S$I$S("originAtom", mapAtoms.get$O(b.getStart$()).intValue$(), "");
s+=C$.toJSONInt$S$I$S("targetAtom", mapAtoms.get$O(b.getEnd$()).intValue$(), ",");
var bt=C$.uc$O(b.getType$());
if (!bt.equals$O("SINGLE")) s+=C$.toJSONString$S$S$S("type", bt, ",");
s+=C$.toJSONNotNone$S$O$S("stereo", C$.uc$O(b.getStereo$()), ",");
s+="}";
}
s+="\n]";
if (ns > 0) {
s+=",\n\"stereoCount\":" + ns + ",\n" ;
s+="\"stereo\":[\n";
for (var i=0; i < ns; i++) {
if (i > 0) s+=",\n";
s+="{";
var d=mol.getStereos$().get$I(i);
s+=C$.toJSONNotNone$S$O$S("type", C$.uc$O(d.getType$()), "");
s+=C$.toJSONNotNone$S$O$S("parity", C$.uc$O(d.getParity$()), ",");
var an=d.getAtoms$();
var nbs=Clazz.array(Integer.TYPE, [an.length]);
for (var j=0; j < an.length; j++) {
nbs[j]=mapAtoms.get$O(an[j]).intValue$();
}
s+=C$.toJSONArray$S$IA$S("neighbors", nbs, ",");
var a=d.getCentralAtom$();
if (a != null ) s+=C$.toJSONInt$S$I$S("centralAtom", mapAtoms.get$O(a).intValue$(), ",");
s+="}";
}
s+="\n]";
}s+="}";
System.out.println$S(s);
return s;
}, 1);

Clazz.newMeth(C$, 'sizeof$java_util_List',  function (list) {
return (list == null  ? 0 : list.size$());
}, 1);

Clazz.newMeth(C$, 'toJSONArray$S$IA$S',  function (key, val, term) {
var s=term + "\"" + key + "\":[" + val[0] ;
for (var i=1; i < val.length; i++) {
s+="," + val[i];
}
return s + "]";
}, 1);

Clazz.newMeth(C$, 'toJSONNonZero$S$I$S',  function (key, val, term) {
return (val == 0 ? "" : C$.toJSONInt$S$I$S(key, val, term));
}, 1);

Clazz.newMeth(C$, 'toJSONInt$S$I$S',  function (key, val, term) {
return term + "\"" + key + "\":" + val ;
}, 1);

Clazz.newMeth(C$, 'toJSONDouble$S$D$S',  function (key, val, term) {
var s;
if (val == 0 ) {
s="0";
} else {
s="" + (new Double(val + (val > 0  ? 1.0E-8 : -1.0E-8)).toString());
s=s.substring$I$I(0, s.indexOf$S(".") + 5);
var n=s.length$();
while (s.charAt$I(--n) == "0"){
}
s=s.substring$I$I(0, n + 1);
}return term + "\"" + key + "\":" + s ;
}, 1);

Clazz.newMeth(C$, 'toJSONString$S$S$S',  function (key, val, term) {
return term + "\"" + key + "\":\"" + val + "\"" ;
}, 1);

Clazz.newMeth(C$, 'toJSONNotNone$S$O$S',  function (key, val, term) {
var s=val.toString();
return ("NONE".equals$O(s) ? "" : term + "\"" + key + "\":\"" + s + "\"" );
}, 1);

Clazz.newMeth(C$, 'initializeModelForSmiles$',  function () {
for (var i=this.getNumAtoms$(); --i >= 0; ) this.map.put$O$O(this.inchiModel.getAtom$I(i), Integer.valueOf$I(i));

});

Clazz.newMeth(C$, 'getNumAtoms$',  function () {
return C$.sizeof$java_util_List(this.inchiModel.getAtoms$());
});

Clazz.newMeth(C$, 'setAtom$I',  function (i) {
this.thisAtom=this.inchiModel.getAtom$I(i);
return this;
});

Clazz.newMeth(C$, 'getElementType$',  function () {
return this.thisAtom.getElName$();
});

Clazz.newMeth(C$, 'getX$',  function () {
return this.thisAtom.getX$();
});

Clazz.newMeth(C$, 'getY$',  function () {
return this.thisAtom.getY$();
});

Clazz.newMeth(C$, 'getZ$',  function () {
return this.thisAtom.getZ$();
});

Clazz.newMeth(C$, 'getCharge$',  function () {
return this.thisAtom.getCharge$();
});

Clazz.newMeth(C$, 'getIsotopicMass$',  function () {
return $I$(12,"getActualMass$S$I",[this.getElementType$(), this.thisAtom.getIsotopicMass$()]);
});

Clazz.newMeth(C$, 'getImplicitH$',  function () {
return this.thisAtom.getImplicitHydrogen$();
});

Clazz.newMeth(C$, 'getNumBonds$',  function () {
return C$.sizeof$java_util_List(this.inchiModel.getBonds$());
});

Clazz.newMeth(C$, 'setBond$I',  function (i) {
this.thisBond=this.inchiModel.getBond$I(i);
return this;
});

Clazz.newMeth(C$, 'getIndexOriginAtom$',  function () {
return this.map.get$O(this.thisBond.getStart$()).intValue$();
});

Clazz.newMeth(C$, 'getIndexTargetAtom$',  function () {
return this.map.get$O(this.thisBond.getEnd$()).intValue$();
});

Clazz.newMeth(C$, 'getInchiBondType$',  function () {
var type=this.thisBond.getType$();
return type.name$();
});

Clazz.newMeth(C$, 'getNumStereo0D$',  function () {
return C$.sizeof$java_util_List(this.inchiModel.getStereos$());
});

Clazz.newMeth(C$, 'setStereo0D$I',  function (i) {
this.thisStereo=this.inchiModel.getStereos$().get$I(i);
return this;
});

Clazz.newMeth(C$, 'getNeighbors$',  function () {
var an=this.thisStereo.getAtoms$();
var n=an.length;
var a=Clazz.array(Integer.TYPE, [n]);
for (var i=0; i < n; i++) {
a[i]=this.map.get$O(an[i]).intValue$();
}
return a;
});

Clazz.newMeth(C$, 'getCenterAtom$',  function () {
var ca=this.thisStereo.getCentralAtom$();
return (ca == null  ? -1 : this.map.get$O(ca).intValue$());
});

Clazz.newMeth(C$, 'getStereoType$',  function () {
return C$.uc$O(this.thisStereo.getType$());
});

Clazz.newMeth(C$, 'getParity$',  function () {
return C$.uc$O(this.thisStereo.getParity$());
});

Clazz.newMeth(C$, 'uc$O',  function (o) {
return o.toString().toUpperCase$();
}, 1);

Clazz.newMeth(C$, 'getInternalInchiVersion$',  function () {
if (C$.inchiVersionInternal == null ) {
var f=$I$(13).JNA_NATIVE_LIB.getFile$();
C$.inchiVersionInternal=C$.extractInchiVersionInternal$java_io_File(f);
if (C$.inchiVersionInternal == null ) {
try {
f=$I$(14,"extractFromResourcePath$S",[$I$(13).JNA_NATIVE_LIB.getName$()]);
C$.inchiVersionInternal=C$.extractInchiVersionInternal$java_io_File(f);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}if (C$.inchiVersionInternal == null ) C$.inchiVersionInternal="unknown";
}return C$.inchiVersionInternal;
}, 1);

Clazz.newMeth(C$, 'extractInchiVersionInternal$java_io_File',  function (f) {
var s=null;
try {
var fis=Clazz.new_($I$(15,1).c$$java_io_File,[f]);
try {
var b=Clazz.array(Byte.TYPE, [Long.$ival(f.length$())]);
fis.read$BA(b);
s= String.instantialize(b);
var pt=s.indexOf$S("InChI version");
if (pt < 0) {
s=null;
} else {
s=s.substring$I$I(pt, s.indexOf$I$I("\u0000", pt));
}fis.close$();
f.delete$();

}finally{/*res*/fis&&fis.close$&&fis.close$();}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
return s;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-09-01 22:08:12 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
