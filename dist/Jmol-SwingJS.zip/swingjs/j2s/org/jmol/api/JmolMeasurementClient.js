(function(){var P$=Clazz.newPackage("org.jmol.api"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "JmolMeasurementClient");
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:16:09 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
