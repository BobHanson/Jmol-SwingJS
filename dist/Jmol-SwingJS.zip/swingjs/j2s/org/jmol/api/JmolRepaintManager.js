(function(){var P$=Clazz.newPackage("org.jmol.api"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "JmolRepaintManager");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-05 13:39:42 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
