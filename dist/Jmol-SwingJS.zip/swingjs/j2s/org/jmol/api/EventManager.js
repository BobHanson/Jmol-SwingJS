(function(){var P$=Clazz.newPackage("org.jmol.api"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "EventManager");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-09-01 22:08:08 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
