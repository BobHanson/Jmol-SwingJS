(function(){var P$=Clazz.newPackage("org.jmol.api"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "JmolRendererInterface", null, null, 'org.jmol.api.JmolGraphicsInterface');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:15 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
