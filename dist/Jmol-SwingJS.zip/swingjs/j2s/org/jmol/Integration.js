(function(){var P$=Clazz.newPackage("org.jmol"),I$=[[0,'java.awt.Dimension','org.jmol.api.JmolViewer','org.jmol.adapter.smarter.SmarterJmolAdapter','javax.swing.JFrame',['org.jmol.Integration','.ApplicationCloser'],'java.awt.BorderLayout',['org.jmol.Integration','.JmolPanel'],'javax.swing.JPanel','org.openscience.jmol.app.jmolpanel.console.AppConsole','org.jmol.util.Logger']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Integration", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['ApplicationCloser',8],['JmolPanel',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'main$SA',  function (argv) {
var frame=Clazz.new_($I$(4,1).c$$S,["Hello"]);
frame.addWindowListener$java_awt_event_WindowListener(Clazz.new_($I$(5,1)));
var contentPane=frame.getContentPane$();
contentPane.setLayout$java_awt_LayoutManager(Clazz.new_($I$(6,1)));
var jmolPanel=Clazz.new_($I$(7,1));
jmolPanel.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(1,1).c$$I$I,[400, 400]));
var panel2=Clazz.new_($I$(8,1));
panel2.setLayout$java_awt_LayoutManager(Clazz.new_($I$(6,1)));
panel2.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(1,1).c$$I$I,[400, 200]));
var console=Clazz.new_($I$(9,1).c$$org_jmol_api_JmolViewer$java_awt_Container$S,[jmolPanel.viewer, panel2, "History State Clear"]);
jmolPanel.viewer.setJmolCallbackListener$org_jmol_api_JmolCallbackListener(console);
contentPane.add$java_awt_Component$O(jmolPanel, "Center");
contentPane.add$java_awt_Component$O(panel2, "South");
frame.pack$();
frame.setVisible$Z(true);
var strError=jmolPanel.viewer.openFile$S("https://chemapps.stolaf.edu/jmol/docs/examples-11/data/caffeine.xyz");
if (strError == null ) C$.runExampleScript$org_jmol_api_JmolViewer(jmolPanel.viewer);
 else $I$(10).error$S(strError);
}, 1);

Clazz.newMeth(C$, 'runExampleScript$org_jmol_api_JmolViewer',  function (viewer) {
viewer.scriptWait$S("delay; move 360 0 0 0 0 0 0 0 4;");
C$.test$O(viewer.evaluateExpressionAsVariable$O("quaternion()"));
}, 1);

Clazz.newMeth(C$, 'test$O',  function (x) {
if (Clazz.instanceOf(x, "org.jmol.script.SV")) {
x=(x).value;
}System.out.println$S(x + " " + x.getClass$().getName$() );
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.Integration, "ApplicationCloser", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'java.awt.event.WindowAdapter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'windowClosing$java_awt_event_WindowEvent',  function (e) {
System.exit$I(0);
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.Integration, "JmolPanel", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'javax.swing.JPanel');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.currentSize=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['O',['viewer','org.jmol.api.JmolViewer','currentSize','java.awt.Dimension']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.viewer=$I$(2,"allocateViewer$O$org_jmol_api_JmolAdapter$S$java_net_URL$java_net_URL$S$org_jmol_api_JmolStatusListener",[this, Clazz.new_($I$(3,1)), null, null, null, null, null]);
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics',  function (g) {
this.getSize$java_awt_Dimension(this.currentSize);
this.viewer.renderScreenImage$O$I$I(g, this.currentSize.width, this.currentSize.height);
});
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-09-01 22:08:43 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
