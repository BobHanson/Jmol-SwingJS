(function(){var P$=Clazz.newPackage("org.jmol.g3d"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "PrecisionRenderer");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['isOrthographic'],'D',['a','b']]]

Clazz.newMeth(C$, 'getZCurrent$D$D$I',  function (a, b, x) {
return Long.$ival(Math.round$D(a == 4.9E-324  ? b : this.isOrthographic ? a * x + b : a / (b - x)));
});

Clazz.newMeth(C$, 'setRastABFloat$D$D$D$D',  function (xa, za, xb, zb) {
var zdif=(zb - za);
var xdif=(xb - xa);
if (zdif == 0  || xdif == 0  ) {
this.a=4.9E-324;
this.b=za;
return;
}if (this.isOrthographic) {
this.a=zdif / xdif;
this.b=za - this.a * xa;
} else {
this.a=xdif * za * (zb / zdif) ;
this.b=(xb * zb - xa * za) / zdif;
}});

Clazz.newMeth(C$, 'setRastAB$I$I$I$I',  function (xa, za, xb, zb) {
var zdif=(zb - za);
var xdif=(xb - xa);
if (xa == 4.9E-324  || zdif == 0   || xdif == 0  ) {
this.a=4.9E-324;
this.b=zb;
return;
}if (this.isOrthographic) {
this.a=zdif / xdif;
this.b=za - this.a * xa;
} else {
this.a=xdif * za * (zb / zdif) ;
this.b=(xb * zb - xa * za) / zdif;
}});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-09-01 22:08:12 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
