(function(){var P$=Clazz.newPackage("javajs.util"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "P3d", null, 'javajs.util.T3d');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['unlikely','javajs.util.P3d']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'newP$javajs_util_T3d',  function (t) {
var p=Clazz.new_(C$);
p.x=t.x;
p.y=t.y;
p.z=t.z;
return p;
}, 1);

Clazz.newMeth(C$, 'getUnlikely$',  function () {
return (C$.unlikely == null  ? C$.unlikely=C$.new3$D$D$D(3.141592653589793, 2.718281828459045, (8.539734222673566)) : C$.unlikely);
}, 1);

Clazz.newMeth(C$, 'new3$D$D$D',  function (x, y, z) {
var p=Clazz.new_(C$);
p.x=x;
p.y=y;
p.z=z;
return p;
}, 1);

Clazz.newMeth(C$, 'newA$DA',  function (a) {
return C$.new3$D$D$D(a[0], a[1], a[2]);
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:54 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
