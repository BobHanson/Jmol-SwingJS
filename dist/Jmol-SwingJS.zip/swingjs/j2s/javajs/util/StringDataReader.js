(function(){var P$=Clazz.newPackage("javajs.util"),I$=[[0,'java.io.StringReader']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "StringDataReader", null, 'javajs.util.DataReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S',  function (data) {
;C$.superclazz.c$$java_io_Reader.apply(this,[Clazz.new_($I$(1,1).c$$S,[data])]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'setData$O',  function (data) {
return Clazz.new_(C$.c$$S,[data]);
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:54 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
