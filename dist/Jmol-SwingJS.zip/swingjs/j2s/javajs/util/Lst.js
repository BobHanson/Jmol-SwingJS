(function(){var P$=Clazz.newPackage("javajs.util"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Lst", null, 'java.util.ArrayList');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'addLast$O',  function (v) {
C$.superclazz.prototype.add$O.apply(this, [v]);
});

Clazz.newMeth(C$, 'removeItemAt$I',  function (location) {
return C$.superclazz.prototype.remove$I.apply(this, [location]);
});

Clazz.newMeth(C$, 'removeObj$O',  function (v) {
return C$.superclazz.prototype.remove$O.apply(this, [v]);
});
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:27 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
