(function(){var P$=Clazz.newPackage("javajs.api"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "GenericZipTools");
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:53 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
