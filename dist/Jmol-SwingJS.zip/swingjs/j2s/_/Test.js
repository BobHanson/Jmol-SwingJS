(function(){var P$=Clazz.newPackage("_"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Test");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-02-10 15:26:40 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
