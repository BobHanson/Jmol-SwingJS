methods for classes in this folder will not be qualified -- that is, 
they will not have $ in their names. This allows them to be regular
JavaScript methods such as apply() and call(), rather than apply$() and call$(). 

See .j2s  

j2s.compiler.nonqualified.classes=jme.js;