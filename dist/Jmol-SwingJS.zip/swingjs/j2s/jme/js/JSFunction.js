(function(){var P$=Clazz.newPackage("jme.js"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "JSFunction");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
