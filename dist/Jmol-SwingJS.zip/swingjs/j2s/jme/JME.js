(function(){var P$=Clazz.newPackage("jme"),p$1={},p$2={},I$=[[0,['jme.io.JMEWriter','.SupportedOutputFileFormat'],'jme.canvas.ColorManager','Thread','java.awt.Color',['jme.JME','.Options'],['jme.JME','.Touched'],'jme.canvas.ReactionArrow','jme.event.JMEevent',['jme.core.JMECore','.Parameters'],'java.awt.Dimension','jme.JMEmolList','java.util.ArrayList','jme.io.SDFstack','jme.io.TextTransfer',['jme.JME','.StringWrapper'],'javax.swing.JTextField','jme.JMEmol','jme.event.InspectorEvent','jme.io.FileDropper','java.awt.dnd.DragSource','jme.gui.GUI','jme.util.ChangeManager','jme.gui.Actions','javax.swing.JPopupMenu',['jme.JME','.CopyPasteAction'],'javax.swing.JMenuItem','jme.io.JMEWriter','jme.io.JMEReader','jme.gui.JMEBuilder','jme.canvas.Graphical2DObject','jme.canvas.Graphical2DObjectGroup',['jme.io.JMEWriter','.MolFileOrRxnParameters'],['jme.io.JMEReader','.SupportedInputFileFormat'],'jme.util.JMEUtil','jme.ocl.OclAdapter',['jme.JMEmol','.ReactionRole'],['jme.util.Box','.Axis'],['java.awt.geom.Rectangle2D','.Double'],'jme.canvas.PreciseImage','jme.core.Atom','java.awt.image.BufferedImage','java.awt.Point','java.awt.RenderingHints','java.awt.BasicStroke','java.awt.Toolkit','javax.swing.SwingUtilities','jme.gui.AlertBox','jme.gui.MultiBox','jme.gui.QueryBox',['java.awt.geom.Point2D','.Double'],['jme.JME','.SavedState'],'java.awt.event.MouseEvent',['jme.JMEmolList','.EnsembleAtom'],'jme.core.AtomBondCommon',['jme.JMEmolList','.EnsembleBond'],'java.io.ByteArrayOutputStream','java.net.URL','java.io.FileInputStream','java.awt.datatransfer.DataFlavor','javax.swing.JFrame','java.awt.event.WindowAdapter']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JME", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'javax.swing.JPanel', ['java.awt.event.ActionListener', 'java.awt.event.MouseWheelListener', 'java.awt.event.MouseListener', 'java.awt.event.KeyListener', 'java.awt.event.MouseMotionListener', 'java.beans.PropertyChangeListener', 'java.awt.dnd.DragGestureListener', 'jme.event.JMEStatusListener']);
C$.$classes$=[['HTML5Applet',9],['SavedState',8],['Touched',0],['CopyPasteAction',25],['StringWrapper',1],['Options',1]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.options=Clazz.new_($I$(5,1),[this, null]);
this.lastTouched=Clazz.new_($I$(6,1),[this, null]);
this.newTouched=Clazz.new_($I$(6,1),[this, null]);
this.keyTouched=Clazz.new_($I$(6,1),[this, null]);
this.active_an=3;
this.infoText=null;
this.customDefaultInfoText="";
this.arrowWidth=48;
this.reactionArrow=Clazz.new_($I$(7,1).c$$D,[72]);
this.smallerIconsForDepictMode=0.6;
this.bgColor=$I$(4).lightGray;
this.brightColor=this.bgColor.brighter$();
this.leftMenuAtomColor=null;
this.clipboardFormat=$I$(1).MOL;
this.afterStructureChangeEvent=Clazz.new_($I$(8,1));
this.isFullScreen=false;
this.fullScreenEnterOrExit=false;
this.appletHasBeenResized=false;
this.previousScaledScreenArea=null;
this.molecularAreaLineWidth=1.0;
this.molecularAreaAntiAlias=true;
this.depict=false;
this.params=Clazz.new_($I$(9,1));
this.pasteFromSDFstack=false;
this.jmeh=false;
this.canvasBg=$I$(4).white;
this.activeMarkerColorIndex=1;
this.atomBgColors=null;
this.molecularAreaScalePixelsPerCoord=1.0;
this.minmolecularAreaScale=0.3;
this.maxMolecularAreaScale=10;
this.menuScale=1.0;
this.minMenuScale=0.7;
this.maxMenuScale=2;
this.nocenter=false;
this.showAtomNumbers=false;
this.allowFullScreenToggle=true;
this.molecularArea=Clazz.new_($I$(10,1));
this.notifyStructuralChangeJSfunction=null;
this.notifyAtomHighLightJSfunction=null;
this.prePasteJSfunction=null;
this.pasteJLabel=null;
this.mouseWasOverAction=0;
this.colorManager=Clazz.new_($I$(2,1));
this.lastAction=0;
this.nonFullScreenSize=Clazz.new_($I$(10,1));
this.newMolecule=false;
this.afterClear=false;
this.mouseShift=false;
this.smilesBox=null;
this.atomxBox=null;
this.aboutBox=null;
this.movingAtom=false;
this.molText=null;
this.saved=0;
this.moleculePartsList=Clazz.new_($I$(11,1));
this.canMultipleUndo=true;
this.molStack=Clazz.new_($I$(12,1));
this.sdfStack=Clazz.new_($I$(13,1));
this.stackPointer=-1;
this.revertStereo=false;
this.resetExtendAtomMark=true;
this.keyboradInputMark=-100;
this.markFromKeyboardInput=false;
this.clipBoardManager=Clazz.new_($I$(14,1));
this.functionalGroups=Clazz.array(String, -1, ["-C(=O)OH", "-C(=O)OMe", "-OC(=O)Me", "-C(=O)N", "-NC=O", "-CMe3", "-CF3", "-CCl3", "-NO2", "-SO2-NH2", "-NH-SO2-Me", "-NMe2", "-C#N", "-C#CH", "-C#C-Me"]);
this.bondRubberBanding=false;
this.saveCurrentState=false;
this.searchInchiKeyMenuJLabel="Search chemical structure (through InChIKey)";
this.isPostInitialized=false;
this.menuXShortcuts=null;
this.sdfPastedMessage=Clazz.new_($I$(15,1),[this, null]);
this.previousTouchedAtomForHighlight=0;
this.previousTouchedBondForHighlight=0;
this.previousActualMoleculePartIndex=0;
this.lastValidColorIndex=1;
this.atomicSymbol=Clazz.new_($I$(16,1).c$$S$I,["H", 8]);
},1);

C$.$fields$=[['Z',['isFullScreen','fullScreenEnterOrExit','appletHasBeenResized','molecularAreaAntiAlias','depict','pasteFromSDFstack','jmeh','nocenter','showAtomNumbers','allowFullScreenToggle','movePossible','newMolecule','afterClear','mouseShift','movingAtom','canMultipleUndo','revertStereo','resetExtendAtomMark','markFromKeyboardInput','bondRubberBanding','mouseDownWasUsed','saveCurrentState','alignMoleculesHasBeenPerformedByReadingStructure','application','embedded','isPostInitialized','headless','structureChangedByAction'],'D',['smallerIconsForDepictMode','molecularAreaScalePixelsPerCoord','minmolecularAreaScale','maxMolecularAreaScale','menuScale','minMenuScale','maxMenuScale','nonFullScreenMenuScale','nonFullFrameMolecularAreaScalePixelsPerCoord'],'F',['molecularAreaLineWidth'],'I',['action','active_an','arrowWidth','activeMarkerColorIndex','mouseWasOverAction','lastAction','mouseX','mouseY','saved','stackPointer','keyboradInputMark','previousTouchedAtomForHighlight','previousTouchedBondForHighlight','previousActualMoleculePartIndex','lastValidColorIndex'],'J',['lastRotation'],'S',['infoText','customDefaultInfoText','atomBgColors','pasteJLabel','molText','searchInchiKeyMenuJLabel','menuXShortcuts'],'O',['options','jme.JME.Options','lastTouched','jme.JME.Touched','+newTouched','+keyTouched','reactionParts','int[][]','reactionArrow','jme.canvas.ReactionArrow','bgColor','java.awt.Color','+brightColor','+leftMenuAtomColor','clipboardFormat','jme.io.JMEWriter.SupportedOutputFileFormat','afterStructureChangeEvent','jme.event.JMEevent','previousScaledScreenArea','java.awt.geom.Rectangle2D.Double','params','jme.core.JMECore.Parameters','canvasBg','java.awt.Color','dimension','java.awt.Dimension','molecularAreaImage','jme.canvas.PreciseImage','molecularArea','java.awt.Dimension','topMenuImage','jme.canvas.PreciseImage','+leftMenuImage','+infoAreaImage','+rightBorderImage','notifyStructuralChangeJSfunction','jme.js.JSFunction','+notifyAtomHighLightJSfunction','+prePasteJSfunction','colorManager','jme.canvas.ColorManager','nonFullScreenSize','java.awt.Dimension','actions','jme.gui.Actions','builder','jme.gui.JMEBuilder','nonFullFrameSize','java.awt.Dimension','nonFullFrameLocation','java.awt.Point','smilesBox','jme.gui.MultiBox','+atomxBox','+aboutBox','queryBox','jme.gui.QueryBox','activeMol','jme.JMEmol','activeGraphicalObject','jme.canvas.Graphical2DObject','inspectorEvent','jme.event.InspectorEvent','moleculePartsList','jme.JMEmolList','smol','jme.JMEmol','molChangeManager','jme.util.ChangeManager','molStack','java.util.List','sdfStack','jme.io.SDFstack','apointx','int[]','+apointy','+bpointx','+bpointy','clipBoardManager','jme.io.TextTransfer','copyPasteJPopupMenuMol','javax.swing.JPopupMenu','+copyPasteJPopupMenuReaction','+touchedMolPopuMenu','functionalGroups','String[]','pasteAction','jme.io.TextTransfer.PasteAction','myFrame','javax.swing.JFrame','sdfPastedMessage','jme.JME.StringWrapper','atomicSymbol','javax.swing.JTextField','gui','jme.gui.GUI']]
,['Z',['isStandAloneApplication','isJavaScript'],'D',['precision'],'S',['programName','parserImpl','changeAtomChargeAction','changeAtomMapAction','changeAtomMarkAction'],'O',['copyright','String[]','color','java.awt.Color[]','oclAdapter','jme.ocl.OclAdapter']]]

Clazz.newMeth(C$, 'setLastAction$I',  function (a) {
this.lastAction=a;
});

Clazz.newMeth(C$, 'c$',  function () {
C$.c$$javax_swing_JFrame$Z$SA.apply(this, [null, false, null]);
}, 1);

Clazz.newMeth(C$, 'c$$javax_swing_JFrame',  function (frame) {
C$.c$$javax_swing_JFrame$Z$SA.apply(this, [frame, false, null]);
}, 1);

Clazz.newMeth(C$, 'c$$javax_swing_JFrame$Z$SA',  function (frame, embedded, args) {
Clazz.super_(C$, this);
this.embedded=embedded;
this.activeMol=Clazz.new_($I$(17,1).c$$jme_JME$jme_core_JMECore_Parameters,[this, this.params]);
this.lastTouched.mol=this.activeMol;
this.newTouched.mol=this.activeMol;
this.moleculePartsList.add$O(this.activeMol);
this.inspectorEvent=Clazz.new_($I$(18,1).c$$jme_JME,[this]);
this.setFrame$javax_swing_JFrame(frame);
var doInit=true;
if (args.length > 0 && !args[0].startsWith$S("-") ) {
if (args[0].indexOf$S("$NOINIT$") >= 0) {
doInit=false;
}}if (doInit) this.initialize$SA(args);
}, 1);

Clazz.newMeth(C$, 'setFrame$javax_swing_JFrame',  function (frame) {
if (frame == null ) return;
this.myFrame=frame;
C$.isStandAloneApplication=true;
frame.setName$S("JME");
frame.add$S$java_awt_Component("Center", this);
frame.addKeyListener$java_awt_event_KeyListener(this);
this.addKeyListener$java_awt_event_KeyListener(this);
this.addMouseListener$java_awt_event_MouseListener(this);
this.addMouseMotionListener$java_awt_event_MouseMotionListener(this);
System.out.println$S("JME frame " + frame);
Clazz.new_($I$(19,1).c$$java_beans_PropertyChangeListener,[this]);
this.application=true;
System.out.println$S("JME frame OK " + frame);
});

Clazz.newMeth(C$, 'initialize$SA',  function (args) {
this.params.keepSameCoordinatesForOutput=false;
this.params.internalBondScalingForInput=true;
this.params.showAtomMapNumberWithBackgroundColor=false;
this.options.registerJS$jme_JME(this);
if (args.length > 0 && !args[0].startsWith$S("-") ) {
this.options$S(args[0]);
}var ds=Clazz.new_($I$(20,1));
ds.createDefaultDragGestureRecognizer$java_awt_Component$I$java_awt_dnd_DragGestureListener(this, 1, this);
var parent=this.getParent$();
if (parent != null ) {
parent.addMouseWheelListener$java_awt_event_MouseWheelListener(this);
}this.dimension=this.getSize$();
this.setLayout$java_awt_LayoutManager(null);
this.options.getAppletOptions$jme_JME$SA(this, args);
this.gui=Clazz.new_($I$(21,1).c$$jme_JME,[this]);
this.action=202;
this.validate$();
System.out.println$S("JME.init dim " + this.getSize$());
this.mustRedrawEverything$();
if (this.myFrame != null ) {
this.myFrame.setResizable$Z(true);
this.myFrame.setVisible$Z(true);
}if (this.canMultipleUndo) {
this.molChangeManager=Clazz.new_($I$(22,1));
this.postSave$();
}this.info$S(C$.programName + " " + "Molecular Editor by Peter Ertl and Bruno Bienfait" );
});

Clazz.newMeth(C$, 'start$',  function () {
this.start$SA(Clazz.array(String, [0]));
});

Clazz.newMeth(C$, 'start$SA',  function (args) {
this.actions=Clazz.new_($I$(23,1).c$$jme_JME,[this]);
this.actions.setActions$();
var pt=0;
if (args.length > 0 && !args[0].startsWith$S("-") ) ++pt;
this.dimension=this.getSize$();
System.out.println$S("JME start " + this.dimension);
var repaint=true;
if (this.options.jmeString != null ) {
this.readMolecule$S$Z(this.options.jmeString, repaint);
if (this.atomBgColors != null  && this.activeMol != null  ) this.activeMol.setAtomColors$S$I(this.atomBgColors, 0);
this.postSave$();
} else if (this.options.molString != null ) {
this.readMolFile$S$Z(this.options.molString, repaint);
this.postSave$();
} else if (this.options.genericChemicalInputFromInit != null  && this.options.useOpenChemLib ) {
this.setMustRedrawMolecularArea$Z(false);
this.handleReadGenericInput$S$jme_js_AsyncCallback$Z$Z(this.options.genericChemicalInputFromInit, null, repaint, true);
}this.process$SA$I(args, pt);
this.repaint$();
});

Clazz.newMeth(C$, 'process$SA$I',  function (args, i) {
if (i < 0 || i >= args.length ) return;
for (; i < args.length; i++) {
if (args[i].startsWith$S("-f")) {
this.readDroppedTextFile$S(args[++i]);
} else if (args[i].startsWith$S("-o")) {
this.options$S(args[++i]);
} else if (args[i].startsWith$S("-c")) {
this.options.callback$O$O(args[++i], args[++i]);
}}
});

Clazz.newMeth(C$, 'makeErrorMessage$Exception',  function (e) {
var errorMsg=null;
if (Clazz.instanceOf(e, "java.lang.NumberFormatException")) {
errorMsg="Number parsing";
} else if (Clazz.instanceOf(e, "java.util.NoSuchElementException")) {
errorMsg="Not enough data";
}if (errorMsg == null ) {
errorMsg=e.toString();
} else if (e.getMessage$() != null ) {
errorMsg+=":" + e.getMessage$();
}return errorMsg;
}, 1);

Clazz.newMeth(C$, 'getMolecularAreaLineWidth$',  function () {
return this.molecularAreaLineWidth;
});

Clazz.newMeth(C$, 'setMolecularAreaLineWidth$F',  function (molecularAreaLineWidth) {
this.molecularAreaLineWidth=molecularAreaLineWidth;
this.drawMolecularAreaRightNow$();
});

Clazz.newMeth(C$, 'isMolecularAreaAntiAlias$',  function () {
return this.molecularAreaAntiAlias;
});

Clazz.newMeth(C$, 'setMolecularAreaAntiAlias$Z',  function (molecularAreaAntiAlias) {
this.molecularAreaAntiAlias=molecularAreaAntiAlias;
this.drawMolecularAreaRightNow$();
});

Clazz.newMeth(C$, 'setDirectSizeForTesting$I$I',  function (width, height) {
this.setDimension$I$I(width, height);
this.updateMyMolecularAreaSize$();
});

Clazz.newMeth(C$, 'setDimension$I$I',  function (width, height) {
if (this.dimension == null ) {
this.dimension=Clazz.new_($I$(10,1));
}this.dimension.setSize$I$I(width, height);
return this;
});

Clazz.newMeth(C$, 'getPasteJLabel$',  function () {
return this.pasteJLabel;
});

Clazz.newMeth(C$, 'setPasteJLabel$S',  function (pasteJLabel) {
this.pasteJLabel=pasteJLabel;
this.copyPasteJPopupMenuMol=this.createCopyPasteJPopupMenu$Z(false);
});

Clazz.newMeth(C$, 'mapActionToAtomNumberXorR$I',  function (action) {
var result=$I$(23).mapActionToAtomNumberX$I(action);
return (result == 32 && !this.options.xButton  && this.options.rButton  ? 33 : result);
});

Clazz.newMeth(C$, 'getLeftMenuCellCount$',  function () {
return 9 + (this.options.rButton ? 1 : 0) + (this.options.xButton ? 1 : 0) ;
});

Clazz.newMeth(C$, 'numberOfMolecules$',  function () {
return this.moleculePartsList.size$();
});

Clazz.newMeth(C$, 'getMolecularAreaScale$',  function () {
return this.molecularAreaScalePixelsPerCoord;
});

Clazz.newMeth(C$, 'setMolecularAreaScale$D',  function (newScale) {
if (newScale != this.molecularAreaScalePixelsPerCoord ) {
var dim1=this.getMolecularAreaCoordBoundingBox$();
this.molecularAreaScalePixelsPerCoord=newScale;
var dim2=this.getMolecularAreaCoordBoundingBox$();
this.recenterMoleculesAfterMolecularAreaChange$java_awt_geom_Rectangle2D_Double$java_awt_geom_Rectangle2D_Double(dim1, dim2);
this.redrawMolecularAreaOnly$();
}});

Clazz.newMeth(C$, 'recenterMoleculesAfterMolecularAreaChange$java_awt_geom_Rectangle2D_Double$java_awt_geom_Rectangle2D_Double',  function (before, after) {
var moveX=after.getCenterX$() - before.getCenterX$();
var moveY=after.getCenterY$() - before.getCenterY$();
this.graphicalObjectList$().moveXY$D$D(moveX, moveY);
});

Clazz.newMeth(C$, 'getMenuScale$',  function () {
return this.menuScale;
});

Clazz.newMeth(C$, 'setMenuScale$D',  function (menuScale) {
if (menuScale != this.menuScale ) {
;this.menuScale=menuScale;
this.resetAllGraphics$();
this.repaint$();
}});

Clazz.newMeth(C$, 'setNewJButtonStatus$Z',  function (newStatus) {
this.newMolecule=newStatus;
this.gui.mustReDrawTopMenu=true;
this.repaint$();
});

Clazz.newMeth(C$, 'getNewJButtonStatus$',  function () {
return this.newMolecule;
});

Clazz.newMeth(C$, 'moveXY$jme_JMEmol$I$I$I',  function (mol, atomIndex, x, y) {
mol.moveXY$I$D$D(atomIndex, this.screenToDrawingX$D(x), this.screenToDrawingY$D(y));
});

Clazz.newMeth(C$, 'createCopyPasteJPopupMenu$Z',  function (isReaction) {
var popup=Clazz.new_($I$(24,1));
var smilesOrSmirks="SMILES";
var molOrReaction="MOL";
var molOrReactionForPasting="MOL or SDF";
var hasAtom=Boolean.valueOf$Z((!((this.isMolecularAreEmpty$()).$c())));
if (isReaction) {
smilesOrSmirks="SMIRKS";
molOrReaction="RXN";
molOrReactionForPasting=molOrReaction;
}if (this.options.useOpenChemLib) {
molOrReactionForPasting+=" or " + smilesOrSmirks;
if (!isReaction && this.options.useOclIdCode ) {
molOrReactionForPasting+=" or OCL ID code";
}}this.addMenuItem$javax_swing_JPopupMenu$Z$S$O(popup, (hasAtom).valueOf(), "Copy " + "as " + smilesOrSmirks , $I$(25).SMILES);
this.addMenuItem$javax_swing_JPopupMenu$Z$S$O(popup, (hasAtom).valueOf(), "Copy " + "as " + molOrReaction , $I$(25).MOL);
if (!isReaction) {
this.addMenuItem$javax_swing_JPopupMenu$Z$S$O(popup, (hasAtom).valueOf(), "Copy as MOL V3000", $I$(25).MOL_V3000);
this.addMenuItem$javax_swing_JPopupMenu$Z$S$O(popup, (hasAtom).valueOf(), "Copy as InChI (standard)", $I$(25).STANDARD_INCHI);
this.addMenuItem$javax_swing_JPopupMenu$Z$S$O(popup, (hasAtom).valueOf(), "Copy as InChI (fixedH)", $I$(25).FIXED_H_INCHI);
this.addMenuItem$javax_swing_JPopupMenu$Z$S$O(popup, (hasAtom).valueOf(), "Copy as InChIKey (standard)", $I$(25).STANDARD_INCHI_KEY);
this.addMenuItem$javax_swing_JPopupMenu$Z$S$O(popup, (hasAtom).valueOf(), "Copy as InChIKey (fixedH)", $I$(25).FIXED_H_INCHI_KEY);
this.addMenuItem$javax_swing_JPopupMenu$Z$S$O(popup, (hasAtom).valueOf(), "Copy as InChI auxinfo", $I$(25).INCHI_AUXINFO);
this.addMenuItem$javax_swing_JPopupMenu$Z$S$O(popup, (hasAtom).valueOf(), "Copy InChI model (JSON)", $I$(25).INCHI_MODEL_JSON);
this.addMenuItem$javax_swing_JPopupMenu$Z$S$O(popup, (hasAtom).valueOf(), this.searchInchiKeyMenuJLabel, $I$(25).SEARCH_INCHI_KEY);
}this.addMenuItem$javax_swing_JPopupMenu$Z$S$O(popup, (hasAtom).valueOf(), "Copy as JME", $I$(25).JME);
if (this.options.useOpenChemLib && this.options.exportSVG && !isReaction  ) {
this.addMenuItem$javax_swing_JPopupMenu$Z$S$O(popup, (hasAtom).valueOf(), "Copy as OCL Scalar Vector Graphics", $I$(25).SVG);
}if (C$.isJavaScript && this.options.exportSVG ) {
this.addMenuItem$javax_swing_JPopupMenu$Z$S$O(popup, (hasAtom).valueOf(), "Copy as raw Scalar Vector Graphics", $I$(25).RAW_STRING_GRAPHIC);
}if (this.options.useOpenChemLib && this.options.useOclIdCode && !isReaction  ) {
this.addMenuItem$javax_swing_JPopupMenu$Z$S$O(popup, (hasAtom).valueOf(), "Copy as OCL ID code", $I$(25).OCLCODE);
}this.subclassAddToCopyMenu$javax_swing_JPopupMenu$Z(popup, (hasAtom).valueOf());
if (this.options.paste) {
popup.addSeparator$();
var localPasteJLabel=this.getPasteJLabel$();
if (localPasteJLabel == null ) {
localPasteJLabel="Paste " + molOrReactionForPasting;
}this.addMenuItem$javax_swing_JPopupMenu$Z$S$O(popup, true, localPasteJLabel, $I$(25).PASTE);
}this.add$java_awt_Component(popup);
return popup;
});

Clazz.newMeth(C$, 'addMenuItem$javax_swing_JPopupMenu$Z$S$O',  function (popup, enabled, text, cmd) {
var mi=Clazz.new_($I$(26,1).c$$S,[text]);
mi.setActionCommand$S(cmd.toString());
mi.addActionListener$java_awt_event_ActionListener(this);
mi.setEnabled$Z(!enabled);
popup.add$javax_swing_JMenuItem(mi);
});

Clazz.newMeth(C$, 'subclassAddToCopyMenu$javax_swing_JPopupMenu$Z',  function (popup, hasAtom) {
});

Clazz.newMeth(C$, 'activeMolIndex$',  function () {
return this.moleculePartsList.indexOf$O(this.activeMol);
});

Clazz.newMeth(C$, 'createMolJPopupMenu$I$I',  function (eventX, eventY) {
var mol=this.activeMol;
var popup=Clazz.new_($I$(24,1));
var item=Clazz.new_([mol.getChiralFlag$().booleanValue$() ? "Unset molecule chiral flag" : "Set molecule chiral flag"],$I$(26,1).c$$S);
item.setEnabled$Z(mol.canBeChiral$());
popup.add$javax_swing_JMenuItem(item);
item.addActionListener$java_awt_event_ActionListener(this);
if (mol.touchedAtom > 0) {
this.inspectorEvent.reset$();
this.inspectorEvent.atomIndex=mol.touchedAtom;
this.inspectorEvent.mol=mol;
this.inspectorEvent.x=eventX;
this.inspectorEvent.y=eventY;
this.inspectorEvent.molIndex=this.activeMolIndex$();
}var showAtomMappingToolsInMenu=this.params.number || this.options.autonumber || this.options.reaction  ;
if (showAtomMappingToolsInMenu && mol.touchedAtom > 0 ) {
item=Clazz.new_($I$(26,1).c$$S,[this.params.mark ? C$.changeAtomMarkAction : C$.changeAtomMapAction]);
item.addActionListener$java_awt_event_ActionListener(this.inspectorEvent);
popup.add$javax_swing_JMenuItem(item);
}if (mol.touchedAtom > 0) {
item=Clazz.new_($I$(26,1).c$$S,[C$.changeAtomChargeAction]);
item.addActionListener$java_awt_event_ActionListener(this.inspectorEvent);
popup.add$javax_swing_JMenuItem(item);
}if (this.options.useOpenChemLib && !mol.has2Dcoordinates$() ) {
item=Clazz.new_($I$(26,1).c$$S,["Compute 2D coordinates"]);
popup.add$javax_swing_JMenuItem(item);
item.addActionListener$java_awt_event_ActionListener(this);
}item=Clazz.new_($I$(26,1).c$$S,["Delete hydrogens"]);
item.setEnabled$Z(mol.hasHydrogen$());
popup.add$javax_swing_JMenuItem(item);
item.addActionListener$java_awt_event_ActionListener(this);
if (showAtomMappingToolsInMenu) {
item=Clazz.new_($I$(26,1).c$$S,["Auto atom map molecule"]);
item.addActionListener$java_awt_event_ActionListener(this);
popup.add$javax_swing_JMenuItem(item);
item=Clazz.new_($I$(26,1).c$$S,["Delete all atom map molecule"]);
item.addActionListener$java_awt_event_ActionListener(this);
popup.add$javax_swing_JMenuItem(item);
item.setEnabled$Z(mol.getMaxAtomMap$() > 0);
}item=Clazz.new_($I$(26,1));
var label="Set coordination bond";
item.setEnabled$Z(false);
if (mol.touchedBond > 0) {
var bond=mol.bonds[mol.touchedBond];
if (bond.isSingle$() || bond.isCoordination$() ) {
label=bond.isCoordination$() ? "Unset coordination bond" : "Set coordination bond";
this.inspectorEvent.reset$();
this.inspectorEvent.bondIndex=mol.touchedBond;
this.inspectorEvent.mol=mol;
this.inspectorEvent.x=eventX;
this.inspectorEvent.y=eventY;
this.inspectorEvent.molIndex=this.activeMolIndex$();
item.setEnabled$Z(true);
item.addActionListener$java_awt_event_ActionListener(this);
}}item.setText$S(label);
popup.add$javax_swing_JMenuItem(item);
return popup;
});

Clazz.newMeth(C$, 'mustRedrawNothing$',  function () {
this.mustRedrawImages$Z(false);
});

Clazz.newMeth(C$, 'mustRedrawEverything$',  function () {
this.mustRedrawImages$Z(true);
});

Clazz.newMeth(C$, 'mustRedrawImages$Z',  function (yesOrNo) {
if (this.gui == null ) return;
this.gui.mustReDrawLeftMenu=yesOrNo;
this.gui.mustReDrawTopMenu=yesOrNo;
this.setMustRedrawMolecularArea$Z(yesOrNo);
this.gui.mustReDrawInfo=yesOrNo;
this.gui.mustReDrawRightBorderImage=yesOrNo;
});

Clazz.newMeth(C$, 'mustReDrawMolecularArea$',  function () {
this.setMustRedrawMolecularArea$Z(true);
});

Clazz.newMeth(C$, 'redrawEverything$',  function () {
this.mustRedrawEverything$();
this.repaint$();
});

Clazz.newMeth(C$, 'getColor$',  function () {
return this.bgColor;
});

Clazz.newMeth(C$, 'activateQuery$',  function () {
if (this.action != 107) {
this.action=107;
this.repaint$();
}});

Clazz.newMeth(C$, 'handleAdditionalParameters$',  function () {
});

Clazz.newMeth(C$, 'getCopyToClipboardFormat$',  function () {
return this.clipboardFormat;
});

Clazz.newMeth(C$, 'setCopyToClipboardFormat$S',  function (format) {
this.clipboardFormat=$I$(1).valueOf$S(format);
});

Clazz.newMeth(C$, 'postInitializeIfNeeded$',  function () {
if (!this.isPostInitialized) {
this.isPostInitialized=true;
this.postInitialize$();
}});

Clazz.newMeth(C$, 'postInitialize$',  function () {
});

Clazz.newMeth(C$, 'stop$',  function () {
if (this.smilesBox != null ) this.smilesBox.dispose$();
if (this.atomxBox != null ) this.atomxBox.dispose$();
if (this.aboutBox != null ) this.aboutBox.dispose$();
if (this.queryBox != null ) this.queryBox.dispose$();
if (this.actions != null ) this.actions.dispose$();
if (this.gui != null ) this.gui.dispose$();
this.builder=null;
});

Clazz.newMeth(C$, 'ping$',  function () {
});

Clazz.newMeth(C$, 'smiles$',  function () {
var smiles;
try {
smiles=this.getSmiles$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.info$S(e.getMessage$());
return null;
} else {
throw e;
}
}
return smiles;
});

Clazz.newMeth(C$, 'updateReactionRoles$',  function () {
this.moleculePartsList.isReaction=this.options.reaction;
var firstChangedIndex=-1;
if (this.options.reaction) {
for (var mol, $mol = this.moleculePartsList.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
var previousRole=mol.getReactionRole$();
var newRole=this.computeReactionRole$jme_JMEmol(mol);
mol.setReactionRole$I(newRole);
if (firstChangedIndex == -1 && newRole != previousRole ) {
firstChangedIndex=this.moleculePartsList.indexOf$O(mol);
}}
}return firstChangedIndex;
});

Clazz.newMeth(C$, 'computeReactionRole$jme_JMEmol',  function (mol) {
if (mol.nAtoms$() == 0) {
return 0;
}var bbox=mol.computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(null);
var reactionArrowBox=this.reactionArrow.updateBoundingBox$();
if (bbox.getCenterX$() < reactionArrowBox.x ) return 1;
 else if (bbox.getCenterX$() > reactionArrowBox.x + reactionArrowBox.width ) return 3;
 else return 2;
});

Clazz.newMeth(C$, 'nonisomericSmiles$',  function () {
var originalStereo=this.options.stereo;
this.options.stereo=false;
var smiles=this.getSmiles$();
this.options.stereo=originalStereo;
return smiles;
});

Clazz.newMeth(C$, 'getSmiles$',  function () {
return this.getSmiles$jme_core_JMECore_Parameters(null);
});

Clazz.newMeth(C$, 'getSmiles$jme_core_JMECore_Parameters',  function (params) {
this.updateReactionRoles$();
return $I$(27,"generateSmilesOrSmirks$jme_core_JMECore_Parameters$jme_JMEmolList",[params == null  ? this.params : params, this.moleculePartsList]);
});

Clazz.newMeth(C$, 'reset$Z',  function (repaint) {
this.action=202;
this.newMolecule=false;
this.clearMyMolecularContent$();
this.clearInfo$();
this.molText=null;
this.resetMolecularAreaScale$();
this.recordAfterStructureChangedEvent$S("reset");
if (repaint) this.repaint$();
});

Clazz.newMeth(C$, 'repaint$',  function () {
if (!this.headless && this.gui != null  ) C$.superclazz.prototype.repaint$.apply(this, []);
});

Clazz.newMeth(C$, 'reset$',  function () {
this.reset$Z(true);
});

Clazz.newMeth(C$, 'resetMolecularAreaScale$',  function () {
if (this.isFullScreen$()) {
this.molecularAreaScalePixelsPerCoord=3.0;
} else {
this.molecularAreaScalePixelsPerCoord=1.0;
}});

Clazz.newMeth(C$, 'clearMyMolecularContent$',  function () {
this.activeMol=Clazz.new_($I$(17,1).c$$jme_JME$jme_core_JMECore_Parameters,[this, this.params]);
this.moleculePartsList.removeAll$();
this.moleculePartsList.add$O(this.activeMol);
this.molText=null;
this.mustReDrawMolecularArea$();
});

Clazz.newMeth(C$, 'clear$',  function () {
this.clear$Z(true);
});

Clazz.newMeth(C$, 'clear$Z',  function (recordEvent) {
this.action=202;
this.newMolecule=false;
this.clearInfo$();
if (this.moleculePartsList.size$() == 0) return;
this.moleculePartsList.remove$O(this.activeMol);
if (this.moleculePartsList.size$() > 0) {
this.activeMol=this.findClosestMol$I$I(this.scaleDrawingToScreen$D(this.activeMol.centerX$()), this.scaleDrawingToScreen$D(this.activeMol.centerY$()));
} else {
this.activeMol=Clazz.new_($I$(17,1).c$$jme_JME$jme_core_JMECore_Parameters,[this, this.params]);
this.moleculePartsList.add$O(this.activeMol);
}this.setMustRedrawMolecularArea$Z(true);
this.afterClear=true;
if (recordEvent) {
this.recordAfterStructureChangedEvent$S("clear");
}});

Clazz.newMeth(C$, 'jmeFile$',  function () {
this.updateReactionRoles$();
return $I$(27,"generateJMEstring$Z$java_awt_geom_Rectangle2D_Double$jme_JMEmolList",[false, this.computeMoleculeEnsembleCoordinate2DboundingBox$(), this.moleculePartsList]);
});

Clazz.newMeth(C$, 'findMaxAtomMapOfMoleculeParts$jme_JMEmolList$I',  function (moleculeParts, reactionRole) {
this.updateReactionRoles$();
return moleculeParts.findMaxAtomMap$I(reactionRole);
});

Clazz.newMeth(C$, 'readMolecule$S$Z',  function (molecule, repaint) {
var success;
try {
if (success=this.handleReadMolecule$S$Z(molecule, repaint)) {
} else {
this.repaint$();
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
success=false;
this.repaint$();
} else {
throw e;
}
}
return success;
});

Clazz.newMeth(C$, 'readMolecule$S',  function (molecule) {
this.readMolecule$S$Z(molecule, true);
});

Clazz.newMeth(C$, 'handleReadMolecule$S$Z',  function (molecule, repaint) {
var inputMolList=$I$(28).readJMEstringInput$S$jme_core_JMECore_Parameters(molecule, this.params);
if (inputMolList.isReallyEmpty$()) {
var err=inputMolList.getErrorMessage$();
if (err != null ) this.log$S(err);
return false;
}this.processIncomingMolecules$jme_JMEmolList$Z(inputMolList, repaint);
return true;
});

Clazz.newMeth(C$, 'showError$S',  function (errorMessage) {
this.showInfo$S("ERROR - " + errorMessage);
});

Clazz.newMeth(C$, 'getBuilder$jme_JMEmol',  function (mol) {
return p$2.getBuilder$jme_JMEmol$I.apply(this, [mol, this.action]);
}, p$2);

Clazz.newMeth(C$, 'getBuilder$jme_JMEmol$I',  function (mol, action) {
if (this.builder == null ) this.builder=Clazz.new_($I$(29,1).c$$jme_JME,[this]);
return this.builder.set$jme_JMEmol$I$Z(mol, action, this.mouseShift);
}, p$2);

Clazz.newMeth(C$, 'setTemplate$S$S',  function (t, name) {
this.afterClear=false;
try {
var err=p$2.getBuilder$jme_JMEmol.apply(this, [this.activeMol]).setTemplate$S(t);
if (err == null ) {
this.info$S(name);
this.action=2053;
} else {
this.showError$S(err);
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.info$S(e.getMessage$());
return;
} else {
throw e;
}
}
this.repaint$();
});

Clazz.newMeth(C$, 'setUserInterfaceBackgroundColor$java_awt_Color',  function (bgColor) {
this.bgColor=bgColor;
this.brightColor=this.bgColor.brighter$();
this.redrawEverything$();
});

Clazz.newMeth(C$, 'setLeftMenuAtomColor$java_awt_Color',  function (color) {
this.leftMenuAtomColor=color;
this.redrawEverything$();
});

Clazz.newMeth(C$, 'setUserInterfaceBackgroundColor$S',  function (hexColor) {
this.setUserInterfaceBackgroundColor$java_awt_Color($I$(2).parseHexColor$S(hexColor));
});

Clazz.newMeth(C$, 'setLeftMenuAtomColor$S',  function (hexColor) {
if (C$.color != null  && C$.color.length > 5 ) this.setLeftMenuAtomColor$java_awt_Color($I$(2).parseHexColor$S(hexColor));
 else this.setLeftMenuAtomColor$java_awt_Color(null);
});

Clazz.newMeth(C$, 'scaleAndCenterForDepictMode$jme_canvas_Graphical2DObjectGroup',  function (graphicalObjecList) {
var scaleToFit=this.molecularAreaScalePixelsPerCoord;
var margin=25.0;
var cdbb=C$.getChemicalDrawingPixelBoundingBox$jme_canvas_Graphical2DObjectGroup(graphicalObjecList);
var mabb=this.getMolecularAreaPixelDimensions$();
if (cdbb.isEmpty$() || mabb == null   || mabb.getWidth$() == 0   || mabb.getHeight$() == 0  ) {
return scaleToFit;
}var ratioWidth=mabb.getWidth$() / (cdbb.getWidth$() + margin);
var ratioHeight=mabb.getHeight$() / (cdbb.getHeight$() + margin);
if (ratioWidth == 0  || ratioHeight == 0  ) {
return scaleToFit;
}if (ratioWidth <= 1  || ratioHeight <= 1  ) {
scaleToFit=Math.min(ratioWidth, ratioHeight);
} else {
scaleToFit=this.molecularAreaScalePixelsPerCoord;
}this.centerAllMoleculesAsAgroup$jme_canvas_Graphical2DObjectGroup$D(graphicalObjecList, scaleToFit);
return scaleToFit;
});

Clazz.newMeth(C$, 'alignAndDistributeMolecules$I$I$I',  function (m1, m2, reactionRole) {
var nm=m2 - m1 + 1;
if (nm <= 0 || m1 >= this.moleculePartsList.size$()  || m2 >= this.moleculePartsList.size$() ) return;
var spaceBetweenMolecules=25.0;
var lastMove=0;
for (var i=m1; i <= m2; i++) {
var mol=this.moleculePartsList.get$I(i);
var moleculeBox=mol.computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(null);
var dx=moleculeBox.x * -1;
var dy=moleculeBox.y * -1;
if (reactionRole != 2) {
dx-=moleculeBox.getWidth$() / 2;
dy+=lastMove;
lastMove+=moleculeBox.getHeight$();
} else {
dy-=moleculeBox.getHeight$() / 2;
dx+=lastMove;
lastMove+=moleculeBox.getWidth$();
}mol.moveXY$D$D(dx, dy);
lastMove+=spaceBetweenMolecules;
}
});

Clazz.newMeth(C$, 'alignMolecules$I$I$I',  function (m1, m2, reactionRole) {
this.alignMolecules$I$I$I$Z(m1, m2, reactionRole, false);
});

Clazz.newMeth(C$, 'alignMolecules$I$I$I$Z',  function (m1, m2, reactionRole, donotAlignJustScale) {
if (this.nocenter) return;
var nm=m2 - m1 + 1;
if (nm <= 0 || m1 >= this.moleculePartsList.size$()  || m2 >= this.moleculePartsList.size$() ) return;
var RBOND=25.0;
var share=Clazz.array(Double.TYPE, [99]);
var sumx=0.0;
var sumy=0.0;
var maxy=0.0;
for (var i=m1; i <= m2; i++) {
if (this.moleculePartsList.get$I(i).nAtoms$() == 0) continue;
var moleculeBox=this.moleculePartsList.get$I(i).computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(null);
sumx+=moleculeBox.getWidth$();
sumy+=moleculeBox.getHeight$();
maxy=Math.max(maxy, moleculeBox.getHeight$());
share[i]=moleculeBox.getWidth$();
if (reactionRole == 2) share[i]=moleculeBox.getHeight$();
}
if (this.isDepict$()) {
sumx+=RBOND * (nm + 1);
sumy+=RBOND * (nm + 1);
maxy+=RBOND;
}var scalex=1.0;
var scaley=1.0;
var widthAndHeight;
if (this.isDepict$()) widthAndHeight=this.getMolecularAreaPixelBoundingBox$();
 else widthAndHeight=this.getMolecularAreaCoordBoundingBox$();
var xsize=(widthAndHeight.width|0);
var ysize=(widthAndHeight.height|0);
if (reactionRole == 1 || reactionRole == 3 ) xsize=((xsize - this.arrowWidth)/2|0);
 else if (reactionRole == 2) ysize=(ysize/2|0);
if (sumx >= xsize ) scalex=(xsize) / sumx;
if (maxy >= ysize ) scaley=(ysize) / maxy;
var space=0.0;
if (this.isDepict$()) {
this.molecularAreaScalePixelsPerCoord=Math.min(scalex, scaley);
space=RBOND * xsize / sumx;
if (reactionRole == 2) space=RBOND * ysize / sumy;
}for (var i=m1; i <= m2; i++) {
if (reactionRole == 2) share[i]=share[i] * ysize / sumy;
 else share[i]=share[i] * xsize / sumx;
}
var shiftx=-xsize / 2.0;
var shifty=0.0;
if (reactionRole == 1) shiftx=-xsize - this.arrowWidth / 2.0;
 else if (reactionRole == 3) shiftx=this.arrowWidth / 2.0;
 else if (reactionRole == 2) {
shiftx=0.0;
shifty=-ysize;
}for (var i=m1; i <= m2; i++) {
if (this.isDepict$()) {
if (!true) {
this.moleculePartsList.get$I(i).scaleXY$D(this.molecularAreaScalePixelsPerCoord);
}this.moleculePartsList.get$I(i).center$();
}if (reactionRole == 2) shifty+=(share[i] / 2.0 + space);
 else shiftx+=(share[i] / 2.0 + space);
if (!donotAlignJustScale) {
this.moleculePartsList.get$I(i).moveXY$D$D(shiftx, shifty);
}if (reactionRole == 2) shifty+=share[i] / 2.0;
 else shiftx+=share[i] / 2.0;
}
});

Clazz.newMeth(C$, 'getChemicalDrawingPixelBoundingBox$jme_canvas_Graphical2DObjectGroup',  function (graphicalObjecList) {
var margin=12.5;
var boundingBox=$I$(30).newBoundingBox$jme_canvas_Graphical2DObject(graphicalObjecList);
if (boundingBox != null  && !boundingBox.isEmpty$() ) {
boundingBox.x-=margin;
boundingBox.y-=margin;
boundingBox.width+=margin * 2;
boundingBox.height+=margin * 2;
}return boundingBox;
}, 1);

Clazz.newMeth(C$, 'computeMoleculeEnsembleCoordinate2DboundingBox$',  function () {
return this.moleculePartsList.computeCoordinate2DboundingBox$();
});

Clazz.newMeth(C$, 'isMolecularAreEmpty$',  function () {
for (var mol, $mol = this.moleculePartsList.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
if (mol.natoms > 0) return Boolean.valueOf$Z(true);
}
return Boolean.valueOf$Z(false);
});

Clazz.newMeth(C$, 'hasMarkedAtom$',  function () {
return this.moleculePartsList.hasMarkedAtom$();
});

Clazz.newMeth(C$, 'maximumScaleDisplayArea$',  function () {
var boundingBox=C$.getChemicalDrawingPixelBoundingBox$jme_canvas_Graphical2DObjectGroup(this.graphicalObjectList$());
if (boundingBox == null ) return -1;
var box=this.getMolecularAreaPixelDimensions$();
var maxScale=Math.min(box.width / boundingBox.width, box.height / boundingBox.height);
return maxScale;
});

Clazz.newMeth(C$, 'graphicalObjectList$jme_JMEmolList',  function (molList) {
var results=Clazz.new_($I$(31,1));
for (var mol, $mol = molList.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
results.add$jme_canvas_Graphical2DObject(mol);
}
if (this.options.reaction) {
results.add$jme_canvas_Graphical2DObject(this.reactionArrow);
}return results;
});

Clazz.newMeth(C$, 'graphicalObjectList$',  function () {
return this.graphicalObjectList$jme_JMEmolList(this.moleculePartsList);
});

Clazz.newMeth(C$, 'molFile$',  function () {
return this.molFile$Z(false);
});

Clazz.newMeth(C$, 'molFile$Z',  function (isV3000) {
return this.molFileOrRxn$S$Z$Z$Z(null, true, isV3000, this.options.exportRXNmergeOption);
});

Clazz.newMeth(C$, 'molFile$jme_io_JMEWriter_MolFileOrRxnParameters',  function (pars) {
if (pars.debugDoNotUpdateReactionRole) {
this.moleculePartsList.isReaction=true;
} else {
this.updateReactionRoles$();
}return $I$(27).generateMolFileOrRxn$jme_io_JMEWriter_MolFileOrRxnParameters$jme_JMEmolList(pars, this.moleculePartsList);
});

Clazz.newMeth(C$, 'molFileOrRxn$S$Z$Z$Z',  function (header_, stampDate_, isV3000_, mergeReationComponents) {
var pars=Clazz.new_($I$(32,1));
pars.header=header_;
pars.stampDate=stampDate_;
pars.isV3000=isV3000_;
pars.mergeReationComponents=this.options.exportRXNmergeOption;
return this.molFile$jme_io_JMEWriter_MolFileOrRxnParameters(pars);
});

Clazz.newMeth(C$, 'readMolFile$S',  function (molecule) {
this.readMolFile$S$Z(molecule, true);
});

Clazz.newMeth(C$, 'readMolFile$S$Z',  function (molecule, repaint) {
try {
if (this.handleReadMolFileRXN$S$Z(molecule, repaint)) {
} else {
this.repaint$();
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.repaint$();
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'handleReadMolFile$S',  function (s) {
return this.handleReadMolFileRXN$S$Z(s, true);
});

Clazz.newMeth(C$, 'handleReadGenericInput$S$jme_js_AsyncCallback',  function (s, callback) {
this.handleReadGenericInput$S$jme_js_AsyncCallback$Z$Z(s, callback, true, true);
});

Clazz.newMeth(C$, 'handleReadGenericInput$S$jme_js_AsyncCallback$Z$Z',  function (s, callback, repaint, recordEvent) {
if (s == null  || s.trim$().length$() == 0 ) {
return;
}this.afterStructureChangeEvent.setOrigin_API$();
this.clearInfo$();
var runAsync=this.options.useOpenChemLib;
var jmeReader=Clazz.new_($I$(28,1).c$$O,[s]);
jmeReader.readMoleculeData$jme_JME$Z$jme_js_AsyncCallback$Z$Z(this, runAsync, callback, repaint, recordEvent);
if (runAsync) return;
this.processFileRead$jme_js_AsyncCallback$jme_io_JMEReader_SupportedInputFileFormat$S$Z(callback, recordEvent ? jmeReader.getFileTypeRead$() : null, jmeReader.getError$(), repaint);
});

Clazz.newMeth(C$, 'processFileRead$jme_js_AsyncCallback$jme_io_JMEReader_SupportedInputFileFormat$S$Z',  function (callback, fileTypeRead, error, repaint) {
if (error == null  && fileTypeRead != null  ) {
this.recordAfterStructureChangedEvent$S(p$2.getEventNameFromFormatRead$jme_io_JMEReader_SupportedInputFileFormat.apply(this, [fileTypeRead]));
}this.setMustRedrawMolecularArea$Z(error == null );
if (callback != null ) {
if (error == null ) {
callback.onSuccess(fileTypeRead);
} else {
callback.onFailure(Clazz.new_(Clazz.load('Exception').c$$S,[error]));
}} else if (error != null ) {
this.showError$S(error);
}if (repaint) {
this.repaint$();
}});

Clazz.newMeth(C$, 'getEventNameFromFormatRead$jme_io_JMEReader_SupportedInputFileFormat',  function (f) {
switch (f) {
case $I$(33).CDX:
return "readCDX";
case $I$(33).CDXML:
return "readCDXML";
case $I$(33).INCHI:
return "readInChI";
case $I$(33).INCHIKEY:
return "readInChIKey";
case $I$(33).JME:
return "readJME";
case $I$(33).MOL:
case $I$(33).MOL_V3000:
return "readMolFile";
case $I$(33).RXN:
return "readRXNFile";
case $I$(33).OCLCODE:
return "readOCLCode";
case $I$(33).SMILES:
return "readSMILES";
case $I$(33).SMARTS:
return "readSMARTS";
case $I$(33).SMIRKS:
return "readSMIRKS";
}
return null;
}, p$2);

Clazz.newMeth(C$, 'getMolecularAreaGraphicsString$',  function () {
return null;
});

Clazz.newMeth(C$, 'readGenericMolecularInput$S',  function (s) {
this.readGenericMolecularInput$S$Z(s, true);
});

Clazz.newMeth(C$, 'readGenericMolecularInput$S$Z',  function (s, recordEvent) {
this.handleReadGenericInput$S$jme_js_AsyncCallback$Z$Z(s, null, true, recordEvent);
});

Clazz.newMeth(C$, 'getOclCode$',  function () {
var molFile=this.molFileOrRxn$S$Z$Z$Z(null, false, true, false);
return C$.getOclAdapter$().getOclCode$S(molFile);
});

Clazz.newMeth(C$, 'getOclSVG$',  function () {
var molFile=this.molFileOrRxn$S$Z$Z$Z(null, false, true, false);
return C$.getOclAdapter$().getOclSVG$S(molFile);
});

Clazz.newMeth(C$, 'oclCodeToMOL$S',  function (oclCode) {
return C$.getOclAdapter$().OclCodeToMOL$S(oclCode);
});

Clazz.newMeth(C$, 'cdxToMOL$BA',  function (data) {
return C$.getOclAdapter$().cdxToMOL$BA(data);
});

Clazz.newMeth(C$, 'getInchiVersion$',  function () {
return C$.getOclAdapter$().getInchiVersion$();
});

Clazz.newMeth(C$, 'molToInChI$S$S',  function (molFileData, options) {
return C$.getOclAdapter$().molToInChI$S$S(molFileData, options);
});

Clazz.newMeth(C$, 'molToInChIKey$S$S',  function (molFileData, options) {
return C$.getOclAdapter$().molToInChIKey$S$S(molFileData, options);
});

Clazz.newMeth(C$, 'cdxmlToMOL$S',  function (xml) {
return C$.getOclAdapter$().cdxmlToMOL$S(xml);
});

Clazz.newMeth(C$, 'inchiToMOL$S',  function (inchi) {
return C$.getOclAdapter$().inchiToMOL$S(inchi);
});

Clazz.newMeth(C$, 'inchikeyToMOL$S',  function (inchikey) {
return C$.getOclAdapter$().inchikeyToMOL$S(inchikey);
});

Clazz.newMeth(C$, 'SMILEStoMOL$S',  function (smiles) {
return C$.getOclAdapter$().SMILEStoMOL$S(smiles);
});

Clazz.newMeth(C$, 'SMIRKStoRXN$S',  function (smirks) {
var parts=smirks.split$S(">");
Clazz.assert(C$, this, function(){return parts.length >= 1 && parts.length <= 3 });
var hasProducts=parts.length >= 3 && parts[2].length$() > 0 ;
var hasAgents=parts.length >= 2 && parts[1].length$() > 0 ;
var reactants=this.SMILEStoMOL$S(parts[0]);
var products=hasProducts ? this.SMILEStoMOL$S(parts[2]) : this.SMILEStoMOL$S("");
var agents=hasAgents ? this.SMILEStoMOL$S(parts[1]) : this.SMILEStoMOL$S("");
var s="";
s+="$RXN\n\n\nJME Molecular Editor\n";
s+=$I$(34).iformat$I$I(1, 3) + $I$(34).iformat$I$I(1, 3);
if (hasAgents) s+=$I$(34).iformat$I$I(1, 3);
s+="\n";
s+="$MOL" + "\n" + reactants ;
s+="$MOL" + "\n" + products ;
if (hasAgents) s+="$MOL" + "\n" + agents ;
return s;
});

Clazz.newMeth(C$, 'readSmirks$S',  function (smirks) {
var convertedmolFile=this.SMILESorSMIRKStoMolOrRXN$S(smirks);
this.handleReadMolFileRXN$S$Z(convertedmolFile, false);
return true;
});

Clazz.newMeth(C$, 'getOclAdapter$',  function () {
return (C$.oclAdapter == null  ? (C$.oclAdapter=Clazz.new_($I$(35,1))) : C$.oclAdapter);
}, 1);

Clazz.newMeth(C$, 'getInterface$S',  function (name) {
try {
var x=Clazz.forName(name);
return (x == null  ? null : x.newInstance$());
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$S("Interface.getInterface Error creating instance for " + C$.parserImpl + ": \n" + e );
return null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'SMILESorSMIRKStoMolOrRXN$S',  function (smilesOrsmirks) {
if (smilesOrsmirks.contains$CharSequence(">")) {
return this.SMIRKStoRXN$S(smilesOrsmirks);
} else {
return this.SMILEStoMOL$S(smilesOrsmirks);
}});

Clazz.newMeth(C$, 'readMolFileOrRXN$S',  function (s) {
return this.handleReadMolFileRXN$S$Z(s, false);
});

Clazz.newMeth(C$, 'canBeAddedToExistingMultipartOrReaction$',  function () {
return ((this.options.reaction || this.options.multipart ) && this.options.addNewPart ) || this.newMolecule ;
});

Clazz.newMeth(C$, 'processIncomingMolecules$jme_JMEmolList$Z',  function (newMolecules, repaint) {
if (this.params.internalBondScalingForInput) {
newMolecules.internalBondLengthScaling$();
}this.activeMol=this.processIncomingMolecules$jme_JMEmolList(newMolecules);
if (this.newMolecule) {
this.newMolecule=false;
this.gui.mustReDrawTopMenu=true;
}if (repaint && !this.headless ) {
this.drawMolecularAreaRightNow$();
if (this.gui.mustReDrawTopMenu) {
this.gui.drawTopMenu$java_awt_Graphics(this.getGraphics$());
}}});

Clazz.newMeth(C$, 'processIncomingMolecules$jme_JMEmolList',  function (newMolecules) {
if (newMolecules.isReallyEmpty$()) {
return this.activeMol;
}for (var i=0; i < newMolecules.size$(); i++) {
var mol=newMolecules.get$I(i);
mol.jme=this;
mol=mol.reComputeBondOrderIfAromaticBondType$();
if (mol != null ) {
newMolecules.set$I$O(i, mol);
}mol=mol.compute2DcoordinatesIfMissing$();
if (mol != null ) {
newMolecules.set$I$O(i, mol);
}}
newMolecules.scaleInternalBondMolList$();
if (newMolecules.isReaction$()) {
p$2.processIncomingReaction$jme_JMEmolList.apply(this, [newMolecules]);
} else {
p$2.processIncomingMoleculeGroup$jme_JMEmolList.apply(this, [newMolecules]);
}this.moleculePartsList.setAtomBackGroundColors$S(this.atomBgColors);
Clazz.assert(C$, this, function(){return (this.moleculePartsList.size$() > 0)});
return newMolecules.first$();
});

Clazz.newMeth(C$, 'processIncomingMoleculeGroup$jme_JMEmolList',  function (newMolecules) {
if (this.isDepict$() || this.pasteFromSDFstack ) {
this.options.reaction=false;
}var addedToExistingMultipartOrReaction=this.canBeAddedToExistingMultipartOrReaction$();
if (!addedToExistingMultipartOrReaction) {
this.moleculePartsList.removeAll$();
this.resetMolecularAreaScale$();
}var scale=this.isDepict$() ? 1.0 : this.molecularAreaScalePixelsPerCoord;
this.centerAllMoleculesAsAgroup$jme_canvas_Graphical2DObjectGroup$D(this.graphicalObjectList$jme_JMEmolList(newMolecules), scale);
if (!this.isDepict$()) {
newMolecules.splitFragments$Z(true);
}this.moleculePartsList.addAll$java_util_Collection(newMolecules);
if (this.isDepict$()) {
this.molecularAreaScalePixelsPerCoord=this.scaleAndCenterForDepictMode$jme_canvas_Graphical2DObjectGroup(this.graphicalObjectList$jme_JMEmolList(this.moleculePartsList));
}}, p$2);

Clazz.newMeth(C$, 'processIncomingReaction$jme_JMEmolList',  function (newMolecules) {
this.options.reaction=true;
this.options.multipart=true;
var spacing=25.0;
var groups=Clazz.new_($I$(31,1));
var agentGroup=null;
for (var role, $role = 0, $$role = $I$(36).all; $role<$$role.length&&((role=($$role[$role])),1);$role++) {
var mols=newMolecules.reactionParts$I(role);
var group=Clazz.new_($I$(31,1));
group.addAll$jme_canvas_Graphical2DObjectGroup(mols.asGroup$());
if (role != 2) {
group.distributePositions$jme_util_Box_Axis$D$Z($I$(37).X, spacing, true);
group.alignCenter$jme_util_Box_Axis($I$(37).Y);
} else {
var pos=(((0.5 * group.size$()) + 0.5)|0);
group.add$I$jme_canvas_Graphical2DObject(pos, this.reactionArrow);
group.distributePositions$jme_util_Box_Axis$D$Z($I$(37).Y, spacing, false);
group.alignCenter$jme_util_Box_Axis($I$(37).X);
agentGroup=group;
}groups.add$jme_canvas_Graphical2DObject(group);
}
groups.distributePositions$jme_util_Box_Axis$D$Z($I$(37).X, spacing, false);
groups.alignCenter$jme_util_Box_Axis($I$(37).Y);
Clazz.assert(C$, this, function(){return (agentGroup != null  && agentGroup.size$() >= 1 )});
$I$(30,"move$jme_canvas_Graphical2DObject$jme_util_Box_Axis$D",[agentGroup, $I$(37).Y, agentGroup.centerY$() - this.reactionArrow.centerY$()]);
newMolecules.splitFragments$Z(true);
this.moleculePartsList.removeAll$();
this.moleculePartsList.addAll$java_util_Collection(newMolecules);
this.molecularAreaScalePixelsPerCoord=this.scaleAndCenterForDepictMode$jme_canvas_Graphical2DObjectGroup(this.graphicalObjectList$jme_JMEmolList(this.moleculePartsList));
}, p$2);

Clazz.newMeth(C$, 'handleReadMolFileRXN$S$Z',  function (s, repaint) {
var inputMolList=$I$(28).readMDLstringInput$S$jme_core_JMECore_Parameters(s, this.params);
if (inputMolList == null  || inputMolList.isReallyEmpty$() ) return false;
this.processIncomingMolecules$jme_JMEmolList$Z(inputMolList, repaint);
return true;
});

Clazz.newMeth(C$, 'findMaxAtomMapAmongAllMolecules$',  function () {
return this.moleculePartsList.findMaxAtomMap$();
});

Clazz.newMeth(C$, 'isActionEnabled$I',  function (action) {
switch (action) {
case 1301:
return this.options.rButton;
case 107:
return this.options.query;
case 201:
return this.options.stereo;
case 103:
return this.options.multipart;
case 105:
if (!(this.params.number || this.options.autonumber )) return false;
return !this.options.starNothing && this.params.mark ;
case 109:
return this.options.reaction;
case 113:
return this.options.showAtomMoveJButton;
}
return true;
});

Clazz.newMeth(C$, 'dialogActionX$',  function () {
if (this.action != 1201) {
this.action=1201;
this.active_an=32;
}});

Clazz.newMeth(C$, 'isMouseDownActionAllowed$I',  function (action) {
switch (action) {
default:
return true;
case 1201:
return this.options.xButton;
case 107:
return this.options.query;
case 201:
return this.options.stereo;
case 103:
return this.options.multipart;
case 105:
return (this.params.number || this.options.autonumber );
case 109:
return this.options.reaction;
}
}, p$2);

Clazz.newMeth(C$, 'setSubstituent$S',  function (s) {
if (s.equals$O("Select substituent")) {
this.action=202;
s="";
} else if (s.equals$O("-C(=O)OH")) this.action=2035;
 else if (s.equals$O("-C(=O)OMe")) this.action=2040;
 else if (s.equals$O("-C(=O)N")) this.action=2060;
 else if (s.equals$O("-NC=O")) this.action=2061;
 else if (s.equals$O("-OC(=O)Me")) this.action=2041;
 else if (s.equals$O("-CMe3")) this.action=2033;
 else if (s.equals$O("-CF3")) this.action=2036;
 else if (s.equals$O("-CCl3")) this.action=2037;
 else if (s.equals$O("-NO2")) this.action=2034;
 else if (s.equals$O("-NMe2")) this.action=2043;
 else if (s.equals$O("-SO2-NH2")) this.action=2052;
 else if (s.equals$O("-NH-SO2-Me")) this.action=2044;
 else if (s.equals$O("-SO3H")) this.action=2039;
 else if (s.equals$O("-PO3H2")) this.action=2051;
 else if (s.equals$O("-C#N")) this.action=2042;
 else if (s.equals$O("-C#C-Me")) this.action=2045;
 else if (s.equals$O("-C#CH")) this.action=2038;
if (this.action > 0) {
this.processMenuAction$I$Z(this.action, false);
} else s="Not known group!";
this.info$S(s);
this.repaint$();
});

Clazz.newMeth(C$, 'setRemoveHsC$',  function () {
this.params.hydrogenParams.removeHs=true;
this.params.hydrogenParams.removeOnlyCHs=true;
});

Clazz.newMeth(C$, 'log$S',  function (string) {
System.err.println$S(string);
});

Clazz.newMeth(C$, 'resetAllGraphics$',  function () {
this.mustRedrawEverything$();
this.molecularAreaImage=null;
this.topMenuImage=null;
this.leftMenuImage=null;
this.infoAreaImage=null;
this.rightBorderImage=null;
});

Clazz.newMeth(C$, 'resetJPopupMenu$',  function () {
this.copyPasteJPopupMenuMol=null;
this.copyPasteJPopupMenuReaction=null;
});

Clazz.newMeth(C$, 'ignoreBonds$',  function () {
return this.action == 105 && (this.options.starNothing || this.options.starAtomOnly )  || this.action == 113  || this.action == 205  || this.action == 112  || this.action == 108  || (this.action >= 2033 && this.action <= 1310  || (this.action == 105 && !this.params.mark ) ) ;
});

Clazz.newMeth(C$, 'ignoreAtoms$',  function () {
return (((this.options.starNothing || this.options.starBondOnly ) && this.action == 105 ));
});

Clazz.newMeth(C$, 'setText$S',  function (text) {
this.molText=text;
this.repaint$();
});

Clazz.newMeth(C$, 'showAtomNumbers$',  function () {
if (this.activeMol != null ) this.activeMol.numberAtomsSequentially$();
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics',  function (g) {
if (this.gui == null  || this.dimension.width == 0 ) return;
this.update$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'isOutsideDrawingArea$I$I',  function (screenX, screenY) {
screenX-=this.leftMenuWidth$();
screenY-=this.topMenuHeight$();
return (screenX < 0 || screenX > this.molecularArea.width  || screenY < 0  || screenY > this.molecularArea.height );
});

Clazz.newMeth(C$, 'isInMolecularArea$I$I',  function (x, y) {
return (this.isDepict$() || x >= this.leftMenuWidth$() && x <= this.dimension.width - this.rightBorder$()  && y >= this.topMenuHeight$()  && y <= this.dimension.height - this.infoAreaHeight$()  );
});

Clazz.newMeth(C$, 'updateMyMolecularAreaSize$',  function () {
if (this.dimension == null ) {
this.dimension=this.getSize$();
}this.molecularArea=this.getMolecularAreaPixelDimensions$();
});

Clazz.newMeth(C$, 'getMolecularAreaPixelDimensions$',  function () {
return Clazz.new_([this.dimension.width - ((this.isDepict$() ? 0 : this.leftMenuWidth$D(this.menuScale) + this.rightBorder$D(this.menuScale))|0), this.dimension.height - ((this.isDepict$() ? 0 : this.topMenuHeight$D(this.menuScale) + this.infoAreaHeight$D(this.menuScale))|0)],$I$(10,1).c$$I$I);
});

Clazz.newMeth(C$, 'getMolecularAreaPixelBoundingBox$',  function () {
var d=this.getMolecularAreaPixelDimensions$();
return Clazz.new_([this.isDepict$() ? 0 : this.leftMenuWidth$D(this.menuScale), this.isDepict$() ? 0 : this.topMenuHeight$D(this.menuScale), d.width, d.height],$I$(38,1).c$$D$D$D$D);
});

Clazz.newMeth(C$, 'getMolecularAreaBoundingBoxCoordinate$D',  function (pixelsPerCoord) {
var bbox=this.getMolecularAreaPixelBoundingBox$();
Clazz.assert(C$, this, function(){return (pixelsPerCoord > 0 )});
bbox.x=0;
bbox.y=0;
bbox.width/=pixelsPerCoord;
bbox.height/=pixelsPerCoord;
return bbox;
});

Clazz.newMeth(C$, 'getMolecularAreaCoordBoundingBox$',  function () {
return this.getMolecularAreaBoundingBoxCoordinate$D(this.molecularAreaScalePixelsPerCoord);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics',  function (g2d) {
var initOrResize;
this.appletHasBeenResized=false;
Clazz.assert(C$, this, function(){return (this.dimension != null )});
if (this.molecularAreaImage == null ) {
initOrResize=true;
} else {
var newDimension=this.getSize$();
initOrResize=(newDimension.width != this.dimension.width) || (newDimension.height != this.dimension.height) ;
if (initOrResize) {
this.dimension=newDimension;
this.appletHasBeenResized=true;
}}if (initOrResize) {
this.mustRedrawEverything$();
this.updateMyMolecularAreaSize$();
this.molecularAreaImage=this.createOrResizePreciseImage$jme_canvas_PreciseImage$D$D(this.molecularAreaImage, this.molecularArea.width, this.molecularArea.height);
if (this.isDepict$()) {
var oldMolecularAreaScale=this.molecularAreaScalePixelsPerCoord;
this.molecularAreaScalePixelsPerCoord=this.scaleAndCenterForDepictMode$jme_canvas_Graphical2DObjectGroup(this.graphicalObjectList$());
this.log$S("update() in depict mode: oldMolecularAreaScale = " + new Double(oldMolecularAreaScale).toString() + " new   molecularAreaScale = " + new Double(this.molecularAreaScalePixelsPerCoord).toString() );
Clazz.assert(C$, this, function(){return this.topMenuImage == null });
Clazz.assert(C$, this, function(){return this.leftMenuImage == null });
Clazz.assert(C$, this, function(){return this.infoAreaImage == null });
Clazz.assert(C$, this, function(){return this.rightBorderImage == null });
} else {
this.topMenuImage=this.createOrResizePreciseImage$jme_canvas_PreciseImage$D$D(this.topMenuImage, this.dimension.width, this.topMenuHeight$());
var imageh=this.dimension.height - this.topMenuHeight$();
if (imageh < 1 ) imageh=1;
this.leftMenuImage=this.createOrResizePreciseImage$jme_canvas_PreciseImage$D$D(this.leftMenuImage, this.leftMenuWidth$(), imageh);
this.infoAreaImage=this.createOrResizePreciseImage$jme_canvas_PreciseImage$D$D(this.infoAreaImage, this.molecularArea.width + this.rightBorder$(), this.infoAreaHeight$());
this.rightBorderImage=this.createOrResizePreciseImage$jme_canvas_PreciseImage$D$D(this.rightBorderImage, this.rightBorder$(), this.molecularArea.height);
}}this.drawMolecularArea$java_awt_Graphics$java_awt_Point(g2d, null);
if (!this.isDepict$()) {
this.gui.draw$java_awt_Graphics(g2d);
}this.postInitializeIfNeeded$();
});

Clazz.newMeth(C$, 'createOrResizeImage$java_awt_Image$I$I',  function (img, width, height) {
return this.createImage$I$I(width, height);
});

Clazz.newMeth(C$, 'createOrResizePreciseImage$jme_canvas_PreciseImage$D$D',  function (img, width, d) {
return Clazz.new_([this.createOrResizeImage$java_awt_Image$I$I(img == null  ? null : img.getImage$(), Long.$ival((Math.round$D(width))), Long.$ival((Math.round$D(d))))],$I$(39,1).c$$java_awt_Image);
});

Clazz.newMeth(C$, 'atomicData$',  function () {
for (var i=14; i <= 42; i++) {
if ($I$(40).chargedMetalType$I(i) > 0) {
C$.color[i]=$I$(4).darkGray;
} else {
C$.color[i]=$I$(4).orange;
}}
C$.color[1]=$I$(4).darkGray;
C$.color[2]=$I$(4).orange;
C$.color[3]=$I$(4).darkGray;
C$.color[4]=$I$(4).blue;
C$.color[5]=$I$(4).red;
C$.color[9]=$I$(4).magenta;
C$.color[10]=$I$(4).magenta;
C$.color[11]=$I$(4).magenta;
C$.color[12]=$I$(4).magenta;
C$.color[8]=$I$(4).yellow.darker$();
C$.color[7]=$I$(4).orange;
C$.color[6]=$I$(4).darkGray;
C$.color[13]=$I$(4).darkGray;
C$.color[32]=$I$(4).darkGray;
}, 1);

Clazz.newMeth(C$, 'drawMolecularAreaRightNow$',  function () {
this.setMustRedrawMolecularArea$Z(true);
if (this.molecularAreaImage != null ) {
var g=this.getGraphics$().create$();
this.drawMolecularArea$java_awt_Graphics$java_awt_Point(g, null);
g.dispose$();
this.setMustRedrawMolecularArea$Z(false);
} else {
this.repaint$();
}});

Clazz.newMeth(C$, 'drawMolecularArea$java_awt_Graphics$java_awt_Point',  function (g, margins) {
var img=null;
var coordOffset=null;
var needRecenter=this.activeMol.needRecentering;
if (g == null ) {
var coordBox=null;
for (var i=this.moleculePartsList.size$(); --i >= 0; ) {
var m=this.moleculePartsList.get$I(i);
coordBox=m.computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(coordBox);
m.needRecentering=false;
}
var f=this.molecularAreaScalePixelsPerCoord;
img=Clazz.new_([((coordBox.getWidth$() * f)|0) + margins.x * 2, ((coordBox.getHeight$() * f)|0) + margins.y * 2, 2],$I$(41,1).c$$I$I$I);
coordOffset=Clazz.new_([((margins.x / f - coordBox.x)|0), ((margins.y / f - coordBox.y)|0)],$I$(42,1).c$$I$I);
} else if (g != null  && !this.gui.mustReDrawMolecularArea ) {
return null;
}if (this.params.computeValenceState) {
if (this.afterStructureChangeEvent != null  && this.afterStructureChangeEvent.action != null  ) {
if (this.afterStructureChangeEvent.action != "undo" && this.afterStructureChangeEvent.action != "redo" ) {
for (var mol, $mol = this.moleculePartsList.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
mol.cleanAfterChanged$Z(this.options.polarnitro);
}
}}}var imgWidth=(img != null  ? img.getWidth$() : this.molecularArea.width);
var imgHeight=(img != null  ? img.getHeight$() : this.molecularArea.height);
var molecularScreenArea=Clazz.new_([this.leftMenuWidth$(), this.topMenuHeight$(), imgWidth, imgHeight],$I$(38,1).c$$D$D$D$D);
var og=$I$(21,"getScaledGraphicsOfPreciseImage$jme_canvas_PreciseImage$D$java_awt_geom_Rectangle2D_Double",[(img == null  ? this.molecularAreaImage : Clazz.new_($I$(39,1).c$$java_awt_Image,[img])), this.molecularAreaScalePixelsPerCoord, molecularScreenArea]);
og.setColor$java_awt_Color(this.canvasBg);
var coordWidth=imgWidth / this.molecularAreaScalePixelsPerCoord;
var coordHeight=imgHeight / this.molecularAreaScalePixelsPerCoord;
og.fillRect$D$D$D$D(0, 0, coordWidth, coordHeight);
if (coordOffset != null ) {
og.translate$D$D(coordOffset.x, coordOffset.y);
}var valueAntiAlias=this.molecularAreaAntiAlias ? $I$(43).VALUE_ANTIALIAS_ON : $I$(43).VALUE_ANTIALIAS_OFF;
og.setRenderingHint$java_awt_RenderingHints_Key$O($I$(43).KEY_ANTIALIASING, valueAntiAlias);
og.setStroke$java_awt_BasicStroke(Clazz.new_($I$(44,1).c$$F,[this.molecularAreaLineWidth]));
if (img == null  && (this.fullScreenEnterOrExit || (this.appletHasBeenResized && this.previousScaledScreenArea != null  ) ) ) {
var graphicalObjecList=this.graphicalObjectList$();
this.centerAllMoleculesAsAgroup$jme_canvas_Graphical2DObjectGroup$D(graphicalObjecList, this.molecularAreaScalePixelsPerCoord);
this.fullScreenEnterOrExit=false;
}for (var mol, $mol = this.moleculePartsList.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
mol.draw$jme_canvas_PreciseGraphicsAWT(og);
}
if (img != null ) {
this.activeMol.needRecentering=needRecenter;
return img;
}if (this.previousScaledScreenArea == null ) this.previousScaledScreenArea=Clazz.new_($I$(38,1));
this.previousScaledScreenArea.width=coordWidth;
this.previousScaledScreenArea.height=coordHeight;
if (this.options.reaction) {
if (!this.reactionArrow.hasBeenPlaced) {
this.reactionArrow.XY$D$D(imgWidth / 2, imgHeight / 2);
}this.reactionArrow.draw$jme_canvas_PreciseGraphicsAWT(og);
}if (this.isDepict$()) {
if (this.molText != null ) {
var w=$I$(21).menuCellFontMet.stringWidth$S(this.molText);
var xstart=(imgWidth - w) / 2.0;
var ystart=imgHeight - 13;
og.setColor$java_awt_Color($I$(4).black);
og.setFont$java_awt_Font($I$(21).menuCellFont);
og.drawString$S$D$D(this.molText, xstart, ystart);
}if (this.options.showDragAndDropIconInDepictMode) this.gui.drawDragAndDropIcon$jme_canvas_PreciseGraphicsAWT$D(og, this.smallerIconsForDepictMode / this.molecularAreaScalePixelsPerCoord);
 else this.gui.dragAndDropIcon=null;
}g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.molecularAreaImage.getImage$(), og.screenX$(), og.screenY$(), this);
this.setMustRedrawMolecularArea$Z(false);
if (this.saveCurrentState) {
this.postSave$();
this.saveCurrentState=false;
}if (this.afterStructureChangeEvent != null  && this.afterStructureChangeEvent.action != null  ) {
this.notifyStructuralChange$S("draw");
if (this.newMolecule == true ) {
this.newMolecule=false;
this.gui.mustReDrawTopMenu=true;
this.repaint$();
}}return null;
});

Clazz.newMeth(C$, 'centerAllMoleculesAsAgroup$jme_canvas_Graphical2DObjectGroup$D',  function (graphicalObjecList, molecularAreaScalePixelsPerCoord) {
if (this.dimension == null ) return;
var chemicalDrawingBoundingBox=C$.getChemicalDrawingPixelBoundingBox$jme_canvas_Graphical2DObjectGroup(graphicalObjecList);
if (chemicalDrawingBoundingBox == null ) return;
var appletMolBoundingBox=this.getMolecularAreaBoundingBoxCoordinate$D(molecularAreaScalePixelsPerCoord);
var dx=appletMolBoundingBox.getCenterX$() - chemicalDrawingBoundingBox.getCenterX$();
var dy=appletMolBoundingBox.getCenterY$() - chemicalDrawingBoundingBox.getCenterY$();
for (var each, $each = graphicalObjecList.group.iterator$(); $each.hasNext$()&&((each=($each.next$())),1);) {
each.moveXY$D$D(dx, dy);
}
});

Clazz.newMeth(C$, 'isFullScreenSupported$',  function () {
return true;
}, 1);

Clazz.newMeth(C$, 'toggleFullScreen$',  function () {
this.mustRedrawEverything$();
var newDim;
var frameSize=(this.myFrame == null  ? null : this.myFrame.getSize$());
if (!this.isFullScreen && this.myFrame != null   && this.myFrame.getExtendedState$() == 6 ) return;
if (this.isFullScreen) {
this.molecularAreaScalePixelsPerCoord=this.nonFullFrameMolecularAreaScalePixelsPerCoord;
this.menuScale=this.nonFullScreenMenuScale;
newDim=this.nonFullScreenSize;
if (this.myFrame != null ) {
this.myFrame.setResizable$Z(true);
this.myFrame.setVisible$Z(false);
this.myFrame.setSize$java_awt_Dimension(this.nonFullFrameSize);
this.myFrame.setLocation$java_awt_Point(this.nonFullFrameLocation);
this.myFrame.setVisible$Z(true);
}} else {
this.nonFullScreenMenuScale=this.menuScale;
this.nonFullScreenSize.setSize$I$I(this.dimension.width, this.dimension.height);
this.nonFullFrameMolecularAreaScalePixelsPerCoord=this.molecularAreaScalePixelsPerCoord;
if (this.myFrame != null ) {
this.nonFullFrameSize=frameSize;
this.nonFullFrameLocation=this.myFrame.getLocation$();
this.myFrame.setExtendedState$I(6);
this.myFrame.setResizable$Z(false);
newDim=this.myFrame.getContentPane$().getSize$();
} else {
newDim=$I$(45).getDefaultToolkit$().getScreenSize$();
}this.molecularAreaScalePixelsPerCoord=Math.min(this.molecularAreaScalePixelsPerCoord * 3.0, 10.0);
this.menuScale=Math.min(this.menuScale * 3.0, 2.0);
}this.isFullScreen=!this.isFullScreen;
this.setSize$java_awt_Dimension(newDim);
});

Clazz.newMeth(C$, 'processMenuAction$I$Z',  function (thisAction, isMouse) {
if (thisAction == 0) return false;
this.mustRedrawNothing$();
var actionOld=this.action;
this.action=thisAction;
var structureChangePerformed=(thisAction < 301 ? p$2.topMenuAction$I.apply(this, [actionOld]) : thisAction < 2000 ? p$2.leftMenuAction$Z.apply(this, [isMouse]) : false);
if (!structureChangePerformed && (this.activeMol.touchedAtom > 0 || this.activeMol.touchedBond > 0 ) ) {
structureChangePerformed=p$2.bondRingAction.apply(this, []);
}if (structureChangePerformed) {
this.action=actionOld;
}p$2.postAction$Z.apply(this, [structureChangePerformed]);
return true;
});

Clazz.newMeth(C$, 'postAction$Z',  function (changed) {
if (changed) {
this.setMustRedrawMolecularArea$Z(true);
this.activeMol.setBondCenters$();
}if (this.gui.mustReDrawMolecularArea) {
this.drawMolecularAreaRightNow$();
}this.repaint$();
}, p$2);

Clazz.newMeth(C$, 'topMenuAction$I',  function (actionOld) {
this.gui.mustReDrawTopMenu=true;
this.gui.mustReDrawLeftMenu=true;
this.clearInfo$();
switch (this.action) {
case 102:
this.clear$();
p$2.handleMouseLeaveActionMenu$I.apply(this, [102]);
p$2.handleMouseEnterActionMenu$I.apply(this, [102]);
return true;
case 110:
this.action=actionOld;
return this.doUndoRedo$I(-1);
case 111:
this.action=actionOld;
return this.doUndoRedo$I(1);
case 101:
this.handleSmilesBox$();
this.action=actionOld;
return false;
case 107:
this.handleQueryBox$();
return false;
case 114:
this.handleAboutBox$();
this.action=actionOld;
return false;
case 103:
this.newMolecule=true;
this.action=actionOld;
return false;
case 105:
if (this.options.markerMenu) {
this.action=actionOld;
this.showJPopupMenuRealtiveToScaledMainMenu$javax_swing_JPopupMenu$I$I(this.gui.createFBackgroundColorPopumemu$(), this.gui.markerJPopupMenuPosition.x, this.gui.markerJPopupMenuPosition.y);
return false;
}if (this.options.autonumber && this.mouseShift ) {
this.mouseShift=false;
this.activeMol.numberAtomsSequentially$();
this.setMustRedrawMolecularArea$Z(true);
this.recordAfterStructureChangedEvent$S("autonumber");
this.action=actionOld;
return true;
}this.keyboradInputMark=1;
return false;
case 109:
this.action=actionOld;
this.updateReactionRoles$();
if (this.activeMol.getReactionRole$() == 2) {
this.info$S("Copying the agent not possible !");
return false;
}var cad=this.activeMol.computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(null);
if (cad == null ) return false;
this.setMustRedrawMolecularArea$Z(true);
this.activeMol=Clazz.new_($I$(17,1).c$$jme_JMEmol,[this.activeMol]);
var molArea=this.getMolecularAreaCoordBoundingBox$();
var dx=molArea.getCenterX$() - cad.getCenterX$();
this.activeMol.moveXY$D$D(dx * 2, 0);
this.moleculePartsList.add$O(this.activeMol);
this.recordAfterStructureChangedEvent$S("reactionCopy");
p$2.handleMouseLeaveActionMenu$I.apply(this, [109]);
p$2.handleMouseEnterActionMenu$I.apply(this, [109]);
return true;
case 104:
if (this.activeMol.touchedAtom == 0 && this.activeMol.touchedBond == 0 ) return false;
p$2.doDeleteAtomOrBond.apply(this, []);
return true;
case 108:
if (this.activeMol.touchedAtom == 0) return false;
if (!p$2.doChangeCharge.apply(this, [])) return false;
return true;
case 112:
p$2.getBuilder$jme_JMEmol.apply(this, [null]).spiroAdding=true;
this.info$S("Next ring will be added as spiro");
this.repaint$();
return true;
case 113:
if (this.options.showAtomMoveJButton) {
this.info$S("Move one atom");
this.repaint$();
}return false;
case 106:
return false;
case 213:
this.action=actionOld;
this.showJPopupMenuRealtiveToScaledMainMenu$javax_swing_JPopupMenu$I$I(this.gui.getFunctionalGroupPopumemu$(), this.gui.functionalGroupJPopupMenuPosition.x, this.gui.functionalGroupJPopupMenuPosition.y);
return false;
case 214:
this.handleCopyPasteJPopupMenu$java_awt_event_MouseEvent$I$I(null, this.gui.fixedCopyPasteJPopupMenuPosition.x, this.gui.fixedCopyPasteJPopupMenuPosition.y);
this.action=actionOld;
return false;
}
return false;
}, p$2);

Clazz.newMeth(C$, 'doUndoRedo$I',  function (direction) {
switch (direction) {
case -1:
return p$2.undo.apply(this, []);
default:
case 1:
return p$2.redo.apply(this, []);
}
});

Clazz.newMeth(C$, 'undo',  function () {
this.setMustRedrawMolecularArea$Z(true);
if (!this.molChangeManager.canUndo$()) {
this.info$S("No more undo");
} else if (this.afterClear) {
this.activeMol=this.moleculePartsList.last$();
this.afterClear=false;
}if (!this.molChangeManager.canUndo$()) return false;
this.restoreState$jme_JME_SavedState(this.molChangeManager.undo$());
this.recordAfterStructureChangedEvent$S("undo");
this.willPostSave$Z(false);
this.setMustRedrawMolecularArea$Z(true);
return false;
}, p$2);

Clazz.newMeth(C$, 'redo',  function () {
if (!this.canMultipleUndo) {
this.alert$S("The redo feature is not implemented yet");
return false;
}if (!this.molChangeManager.canRedo$()) {
this.info$S("No more redo");
return false;
}if (this.afterClear) {
this.activeMol=this.moleculePartsList.last$();
this.afterClear=false;
}if (!this.molChangeManager.canRedo$()) return false;
this.restoreState$jme_JME_SavedState(this.molChangeManager.redo$());
this.recordAfterStructureChangedEvent$S("redo");
this.willPostSave$Z(false);
this.setMustRedrawMolecularArea$Z(true);
return false;
}, p$2);

Clazz.newMeth(C$, 'doChangeCharge',  function () {
p$2.getBuilder$jme_JMEmol.apply(this, [this.activeMol]).checkAtomOrBondAction$();
return true;
}, p$2);

Clazz.newMeth(C$, 'doDeleteAtomOrBond',  function () {
p$2.getBuilder$jme_JMEmol.apply(this, [this.activeMol]).checkAtomOrBondAction$();
}, p$2);

Clazz.newMeth(C$, 'handleMouseLeaveActionMenu$I',  function (action) {
return this.gui.handleMouseLeaveActionMenu$I(action);
}, p$2);

Clazz.newMeth(C$, 'handleMouseEnterActionMenu$I',  function (action) {
return this.gui.handleMouseEnterActionMenu$I$jme_JMEmol(action, this.activeMol);
}, p$2);

Clazz.newMeth(C$, 'bondRingAction',  function () {
switch (this.action) {
case 202:
case 203:
case 204:
if (this.activeMol.touchedAtom > 0) {
this.lastAction=0;
p$2.getBuilder$jme_JMEmol.apply(this, [this.activeMol]).addBond$();
this.recordBondEvent$S("addBond");
return true;
}var bond=this.activeMol.bonds[this.activeMol.touchedBond];
var bondType=1;
var eventType="setBondSingle";
var changed;
switch (this.action) {
case 203:
bondType=2;
eventType="setBondDouble";
break;
case 204:
bondType=3;
eventType="setBondTriple";
break;
}
changed=(bondType != bond.bondType);
if (changed) {
this.activeMol.setBondType$I$I(this.activeMol.touchedBond, bondType);
this.recordBondEvent$S(eventType);
bond.stereo=0;
return true;
}if (bondType == 2) {
this.activeMol.toggleDoubleBondStereo$jme_core_Bond(bond);
return true;
}return false;
default:
if (this.action < 206 || this.action > 229 ) return false;
this.setLastAction$I(2);
p$2.getBuilder$jme_JMEmol.apply(this, [this.activeMol]).addRing$();
this.recordBondEvent$S("addRingBond");
return true;
}
}, p$2);

Clazz.newMeth(C$, 'leftMenuAction$Z',  function (isMouse) {
var active_an=this.active_an;
active_an=this.mapActionToAtomNumberXorR$I(this.action);
this.clearInfo$();
if (active_an == 32) {
this.handleAtomXbox$();
}if (this.action >= 1301 && this.action <= 1310 ) {
active_an=33 + (this.action - 1301);
}if (isMouse) {
this.gui.mustReDrawLeftMenu=true;
this.gui.mustReDrawTopMenu=true;
this.active_an=active_an;
}return (this.activeMol.touchedAtom != 0 && p$2.getBuilder$jme_JMEmol.apply(this, [this.activeMol]).setAtom$I(active_an) );
}, p$2);

Clazz.newMeth(C$, 'updatePartsList$',  function () {
if (this.moleculePartsList.isEmpty$()) {
this.moleculePartsList.add$O(Clazz.new_($I$(17,1)));
}this.activeMol=this.moleculePartsList.get$I(0);
this.moleculePartsList.splitFragments$Z(true);
if (this.moleculePartsList.isEmpty$()) {
this.moleculePartsList.add$O(Clazz.new_($I$(17,1)));
}});

Clazz.newMeth(C$, 'alert$S',  function (message) {
$I$(46,"invokeLater$Runnable",[((P$.JME$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "JME$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'run$',  function () /*block*/{
Clazz.new_($I$(47,1).c$$S$java_awt_Component$java_awt_Color,[this.$finals$.message, this.b$['jme.JME'], this.b$['jme.JME'].bgColor]).setVisible$Z.apply(Clazz.new_($I$(47,1).c$$S$java_awt_Component$java_awt_Color,[this.$finals$.message, this.b$['jme.JME'], this.b$['jme.JME'].bgColor]), [true]);
});
})()
), Clazz.new_(P$.JME$lambda1.$init$,[this, {message:message}]))]);
});

Clazz.newMeth(C$, 'handleAboutBox$',  function () {
$I$(46,"invokeLater$Runnable",[((P$.JME$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "JME$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'run$',  function () /*block*/{
if (this.b$['jme.JME'].aboutBox != null ) {
this.b$['jme.JME'].aboutBox.disposeIfShowing$.apply(this.b$['jme.JME'].aboutBox, []);
}this.b$['jme.JME'].aboutBox=Clazz.new_($I$(48,1).c$$I$jme_JME,[0, this.b$['jme.JME']]);
});
})()
), Clazz.new_(P$.JME$lambda2.$init$,[this, null]))]);
});

Clazz.newMeth(C$, 'handleQueryBox$',  function () {
$I$(46,"invokeLater$Runnable",[((P$.JME$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "JME$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'run$',  function () /*block*/{
if (this.b$['jme.JME'].queryBox == null ) {
this.b$['jme.JME'].queryBox=Clazz.new_($I$(49,1).c$$jme_JME,[this.b$['jme.JME']]);
} else {
if (this.b$['jme.JME'].queryBox.isShowing$.apply(this.b$['jme.JME'].queryBox, [])) {
this.b$['jme.JME'].queryBox.toFront$.apply(this.b$['jme.JME'].queryBox, []);
} else {
this.b$['jme.JME'].queryBox.setVisible$Z.apply(this.b$['jme.JME'].queryBox, [true]);
}}});
})()
), Clazz.new_(P$.JME$lambda3.$init$,[this, null]))]);
});

Clazz.newMeth(C$, 'handleSmilesBox$',  function () {
$I$(46,"invokeLater$Runnable",[((P$.JME$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "JME$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'run$',  function () /*block*/{
if (this.b$['jme.JME'].smilesBox != null ) {
this.b$['jme.JME'].smilesBox.disposeIfShowing$.apply(this.b$['jme.JME'].smilesBox, []);
}this.b$['jme.JME'].smilesBox=Clazz.new_($I$(48,1).c$$I$jme_JME,[1, this.b$['jme.JME']]);
});
})()
), Clazz.new_(P$.JME$lambda4.$init$,[this, null]))]);
});

Clazz.newMeth(C$, 'handleAtomXbox$',  function () {
if (!false) {
$I$(46,"invokeLater$Runnable",[((P$.JME$lambda5||
(function(){/*m*/var C$=Clazz.newClass(P$, "JME$lambda5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'run$',  function () /*block*/{
if (this.b$['jme.JME'].atomxBox != null ) {
this.b$['jme.JME'].atomxBox.disposeIfShowing$.apply(this.b$['jme.JME'].atomxBox, []);
this.b$['jme.JME'].atomxBox=null;
}if (this.b$['jme.JME'].activeMol.touchedAtom == 0) this.b$['jme.JME'].atomxBox=Clazz.new_($I$(48,1).c$$I$jme_JME,[2, this.b$['jme.JME']]);
});
})()
), Clazz.new_(P$.JME$lambda5.$init$,[this, null]))]);
}});

Clazz.newMeth(C$, 'isFullScreen$',  function () {
return this.isFullScreen;
});

Clazz.newMeth(C$, 'clearInfo$',  function () {
this.info$S(this.customDefaultInfoText);
});

Clazz.newMeth(C$, 'info$S',  function (text) {
if (text == null ) text=this.customDefaultInfoText;
var dolog=(this.infoText != text && text !== ""  );
this.gui.mustReDrawInfo=true;
this.infoText=text;
if (dolog) this.log$S("info: " + text);
});

Clazz.newMeth(C$, 'infoNoLog$S',  function (text) {
if (text == null ) text=this.customDefaultInfoText;
this.gui.mustReDrawInfo=true;
this.infoText=text;
});

Clazz.newMeth(C$, 'showInfo$S',  function (text) {
this.info$S(text);
this.repaint$();
});

Clazz.newMeth(C$, 'setCustomDefaultInfoText$S',  function (text) {
this.showInfo$S(text);
this.customDefaultInfoText=text;
});

Clazz.newMeth(C$, 'setAction$I',  function (action) {
this.action=action;
});

Clazz.newMeth(C$, 'setMolecularAreaScale$D$I$I',  function (scale, x, y) {
var previousAreaSize=this.getMolecularAreaCoordBoundingBox$();
this.molecularAreaScalePixelsPerCoord=scale;
var newAreaSize=this.getMolecularAreaCoordBoundingBox$();
var touchedMol=Clazz.new_($I$(6,1),[this, null]);
this.findMolAndAtomOrBondWithinRadius$I$I$I$jme_JME_Touched(x, y, 2147483647, touchedMol);
var shiftXY=C$.getTranslationToCenterAfterScaling$jme_JME_Touched$java_awt_geom_Rectangle2D_Double$java_awt_geom_Rectangle2D_Double(touchedMol, previousAreaSize, newAreaSize);
if (shiftXY != null ) {
$I$(30,"move$jme_canvas_Graphical2DObject$java_awt_geom_Point2D_Double",[this.graphicalObjectList$(), shiftXY]);
}this.setMustRedrawMolecularArea$Z(true);
});

Clazz.newMeth(C$, 'getTranslationToCenterAfterScaling$jme_JME_Touched$java_awt_geom_Rectangle2D_Double$java_awt_geom_Rectangle2D_Double',  function (mol, previousAreaSize, newAreaSize) {
var result=Clazz.new_($I$(50,1));
var closestMolecule=mol.mol;
if (closestMolecule == null  || closestMolecule.nAtoms$() == 0 ) {
return result;
}Clazz.assert(C$, this, function(){return previousAreaSize.width > 0 });
Clazz.assert(C$, this, function(){return previousAreaSize.height > 0 });
var x;
var y;
if (mol.atomIndex > 0) {
x=closestMolecule.atoms[mol.atomIndex].x;
y=closestMolecule.atoms[mol.atomIndex].y;
} else {
x=closestMolecule.bonds[mol.bondIndex].centerX;
y=closestMolecule.bonds[mol.bondIndex].centerY;
}var newX=x / previousAreaSize.width * newAreaSize.width;
var newY=y / previousAreaSize.height * newAreaSize.height;
var shiftX=newX - x;
var shiftY=newY - y;
result.setLocation$D$D(shiftX, shiftY);
return result;
}, 1);

Clazz.newMeth(C$, 'canDoAtomOrBondAction$I',  function (action) {
return (!this.isDepict$() || (this.isDepict$() && action == 105 ) );
});

Clazz.newMeth(C$, 'mouseEntered$java_awt_event_MouseEvent',  function (e) {
this.requestFocusInWindow$();
});

Clazz.newMeth(C$, 'mouseExited$java_awt_event_MouseEvent',  function (e) {
});

Clazz.newMeth(C$, 'mouseClicked$java_awt_event_MouseEvent',  function (e) {
});

Clazz.newMeth(C$, 'keyTyped$java_awt_event_KeyEvent',  function (e) {
});

Clazz.newMeth(C$, 'keyReleased$java_awt_event_KeyEvent',  function (e) {
});

Clazz.newMeth(C$, 'keyPressed$java_awt_event_KeyEvent',  function (e) {
if (this.keyDown$java_awt_event_KeyEvent$I(e, e.getKeyCode$())) {
e.consume$();
}});

Clazz.newMeth(C$, 'mouseMoved$java_awt_event_MouseEvent',  function (e) {
if (this.isDepict$() && !((this.canHandleAtomHighLightCallBack$()).$c() || (this.canHandleBondHighLightCallBack$()).$c() || this.options.depictActionEnabled  ) ) return;
if (C$.isEventContextMenu$java_awt_event_MouseEvent(e)) {
return;
}this.moveTo$I$I$I(e.getX$(), e.getY$(), 0);
});

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent',  function (e) {
if (this.mouseDown$java_awt_event_MouseEvent$I$I(e, e.getX$(), e.getY$())) {
}});

Clazz.newMeth(C$, 'mouseDragged$java_awt_event_MouseEvent',  function (e) {
if (this.mouseDrag$java_awt_event_MouseEvent$I$I(e, e.getX$(), e.getY$())) {
}});

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent',  function (e) {
if (this.mouseUp$java_awt_event_MouseEvent$I$I(e, e.getX$(), e.getY$())) {
}});

Clazz.newMeth(C$, 'mouseWheelMoved$java_awt_event_MouseWheelEvent',  function (e) {
var newScale;
if (!this.options.allowZooming) return;
var notches=e.getPreciseWheelRotation$() * 10.0;
if (notches == 0 ) return;
notches*=-1;
var x=e.getX$();
var y=e.getY$();
var sizeChange=(100.0 + 2 * notches) / 100;
if (this.isInMolecularArea$I$I(x, y)) {
newScale=this.molecularAreaScalePixelsPerCoord * sizeChange;
if ((newScale > this.molecularAreaScalePixelsPerCoord  && newScale <= 10.0  ) || (newScale < this.molecularAreaScalePixelsPerCoord  && newScale >= 0.3  ) ) {
this.lastAction=8;
if (this.options.reaction) {
this.setMolecularAreaScale$D(newScale);
} else {
this.setMolecularAreaScale$D$I$I(newScale, x, y);
this.repaint$();
}}} else {
if (this.options.allowGUIzooming) {
newScale=this.menuScale * sizeChange;
if (newScale >= 0.7  && newScale <= 2.0  ) {
this.setMenuScale$D(newScale);
}}}});

Clazz.newMeth(C$, 'mouseDown$java_awt_event_MouseEvent$I$I',  function (e, x, y) {
this.mouseDownWasUsed=false;
if (this.options.contextMenuEnabledOption && this.handleCopyPasteJPopupMenu$java_awt_event_MouseEvent$I$I(e, x, y) ) {
this.mouseDownWasUsed=true;
this.movePossible=false;
return true;
}var eventNotUsed=false;
this.clearInfo$();
this.mouseX=x;
this.mouseY=y;
this.mouseShift=e.isShiftDown$();
this.movePossible=false;
if (!this.isDepict$() && (y > this.dimension.height - this.infoAreaHeight$()) ) {
return eventNotUsed;
}if (!this.isInMolecularArea$I$I(x, y)) {
var action=this.gui.determineMenuAction$D$D$Z(x, y, true);
return (action == 0 || p$2.isMouseDownActionAllowed$I.apply(this, [action]) && (this.mouseDownWasUsed=this.processMenuAction$I$Z(action, true))  );
}this.activeGraphicalObject=this.findClosestGraphicalObject$I$I(this.mouseX, this.mouseY);
this.activeMol=this.findClosestMol$I$I(this.mouseX, this.mouseY);
this.activeMol.clearRotation$();
if (this.activeGraphicalObject === this.reactionArrow ) {
this.activeMol.touchedAtom=0;
this.activeMol.touchedBond=0;
}if ((this.canHandleAtomClickedCallBack$()).valueOf()) {
if (this.activeMol.touchedAtom > 0) {
this.handleAtomClickedCallBack$I$I(this.activeMolIndex$(), this.activeMol.touchedAtom);
if (this.isDepict$() && !this.options.depictActionEnabled ) {
return true;
}}if (this.activeMol.touchedBond > 0) {
this.handleBondClickedCallBack$I$I(this.activeMolIndex$(), this.activeMol.touchedBond);
if (this.isDepict$() && !this.options.depictActionEnabled ) {
return true;
}}}this.movePossible=true;
var returnStatus;
if (this.activeMol.touchedAtom > 0 && this.canDoAtomOrBondAction$I(this.action) ) {
var an=this.activeMol.an$I(this.activeMol.touchedAtom);
this.actions.setAtomVariableAction$Z$I(an >= 33 && an <= 42 , this.action);
p$2.processAtomPicked$I.apply(this, [this.action]);
returnStatus=true;
} else if (this.activeMol.touchedBond > 0 && this.canDoAtomOrBondAction$I(this.action) ) {
p$2.processBondPicked$I.apply(this, [0]);
returnStatus=true;
} else if ((this.moleculePartsList.isReallyEmpty$() || this.newMolecule == true  ) && !this.isDepict$() ) {
if (this.action <= 201) return true;
this.moleculePartsList.removeEmptyMolecules$();
this.activeMol=Clazz.new_($I$(17,1).c$$jme_JME$jme_core_JMECore_Parameters,[this, this.params]);
this.moleculePartsList.add$O(this.activeMol);
this.lastTouched.mol=this.activeMol;
this.smol=null;
p$2.getBuilder$jme_JMEmol.apply(this, [this.activeMol]).newMolecule$D$D(this.screenToDrawingX$D(x), this.screenToDrawingY$D(y));
this.activeMol.setBondCenters$();
returnStatus=true;
} else {
returnStatus=false;
}if (returnStatus) {
this.setMustRedrawMolecularArea$Z(true);
this.repaint$();
}this.mouseDownWasUsed=returnStatus;
return returnStatus;
});

Clazz.newMeth(C$, 'processAtomPicked$I',  function (action) {
if (this.activeMol.touchedAtom == 0) return false;
this.lastTouched.mol=this.activeMol;
if (action == 107) {
if (this.queryBox.isBondQuery$()) return true;
this.activeMol.setAtom$I$S(this.activeMol.touchedAtom, this.queryBox.getSmarts$());
this.activeMol.isQuery=true;
this.recordAtomEvent$S("addAtomQuery");
} else if (action == 105) {
var marked;
if (!this.options.pseudoMark && !this.options.starNothing ) {
var newMap=-1;
if (this.markFromKeyboardInput) {
newMap=this.keyboradInputMark;
this.resetExtendAtomMark=true;
this.markFromKeyboardInput=false;
this.clearInfo$();
if (this.params.mark) {
this.activateMarkerColor$I(newMap);
}}if (this.params.mark) {
marked=this.activeMol.markAtom$I(newMap > 0 ? newMap : this.activeMarkerColorIndex);
} else {
if (newMap == -1) {
if (this.options.reaction) {
var reactionRole=this.activeMol.getReactionRole$();
newMap=this.findMaxAtomMapOfMoleculeParts$jme_JMEmolList$I(this.moleculePartsList, reactionRole);
} else {
newMap=this.activeMol.getMaxAtomMap$();
}if (!this.mouseShift || newMap == 0 ) ++newMap;
}marked=this.activeMol.markAtom$I(newMap);
}} else {
marked=true;
}this.recordAtomEvent$S(marked ? "markAtom" : "unMarkAtom");
if (this.options.pseudoMark) {
this.willPostSave$Z(false);
}} else if (action == 113) {
} else {
p$2.getBuilder$jme_JMEmol$I.apply(this, [this.activeMol, action]).checkAtomAction$();
this.activeMol.setBondCenters$();
return true;
}return true;
}, p$2);

Clazz.newMeth(C$, 'processBondPicked$I',  function (action) {
if (this.activeMol.touchedBond == 0) return false;
var actionOld=0;
if (action == 0) {
action=this.action;
} else {
actionOld=this.action;
this.action=action;
}this.lastTouched.mol=this.activeMol;
if (action == 107) {
if (!this.queryBox.isBondQuery$()) return (Boolean.TRUE).valueOf();
var bondQuery=this.queryBox.getSmarts$();
this.activeMol.bonds[this.activeMol.touchedBond].bondType=9;
this.activeMol.bonds[this.activeMol.touchedBond].btag=bondQuery;
this.recordBondEvent$S("setQueryBond");
} else if (action == 105) {
var marked=(this.options.pseudoMark || this.activeMol.markBond$I(this.activeMarkerColorIndex) );
this.recordBondEvent$S(marked ? "markBond" : "unMarkBond");
if (this.options.pseudoMark) {
this.willPostSave$Z(false);
}} else {
p$2.getBuilder$jme_JMEmol.apply(this, [this.activeMol]).checkBondAction$();
this.activeMol.setBondCenters$();
return true;
}if (actionOld != 0) this.action=actionOld;
this.repaint$();
return true;
}, p$2);

Clazz.newMeth(C$, 'getAtomSymbolForX$',  function () {
var xx=this.atomicSymbol.getText$();
return (xx.length$() == 0 ? "X" : xx);
});

Clazz.newMeth(C$, 'mouseUp$java_awt_event_MouseEvent$I$I',  function (e, x, y) {
var eventUsed=false;
if (this.movingAtom) {
this.movingAtom=false;
this.willPostSave$Z(true);
eventUsed=true;
}this.gui.mustReDrawInfo=false;
this.lastRotation=0;
if (this.lastAction == 1) {
if (this.action == 205) {
this.activeMol.checkChain$();
this.recordBondEvent$S("addChain");
this.willPostSave$Z(true);
} else {
if (this.lastTouched.mol != null  && this.activeMol !== this.lastTouched.mol  ) {
this.activeMol=this.mergeMols$jme_JME_Touched$jme_JMEmol(this.lastTouched, this.activeMol);
} else {
this.activeMol.checkBond$();
this.activeMol.setBondCenters$();
}}if (this.bondRubberBanding) {
if (this.action != 205) {
this.molChangeManager.removeLast$();
this.recordBondEvent$S("addBond");
}this.bondRubberBanding=false;
}eventUsed=true;
} else if (this.lastAction == 5) {
this.willPostSave$Z(true);
eventUsed=true;
}if (this.lastAction > 0) {
if (this.lastAction != 5 && this.lastAction != 7 ) {
}if (this.lastAction == 5 && this.options.reaction ) {
var changedPart=this.updateReactionRoles$();
++changedPart;
if (changedPart != 0) {
this.recordMoleculePartEvent$S$I("changeReactionRole", changedPart);
}}this.redrawMolecularAreaOnly$();
this.lastAction=0;
this.afterClear=false;
eventUsed=true;
}if ($I$(21).isTouchSupported$() && (this.activeMol.touchedBond != 0 || this.activeMol.touchedAtom != 0 ) ) {
this.activeMol.touchedBond=0;
this.activeMol.touchedAtom=0;
this.redrawMolecularAreaOnly$();
eventUsed=true;
}if (!eventUsed && this.gui.fullScreenIcon != null   && this.gui.fullScreenIcon.contains$I$I(x, y) ) {
eventUsed=true;
this.toggleFullScreen$();
} else if (!eventUsed && !this.mouseDownWasUsed && this.options.toggleDepictEdit  ) {
p$2.toggleDepict.apply(this, []);
eventUsed=true;
}this.mouseShift=false;
return eventUsed;
});

Clazz.newMeth(C$, 'toggleDepict',  function () {
if (this.isDepict$()) {
this.options$S("nodepict");
this.centerAllMoleculesAsAgroup$jme_canvas_Graphical2DObjectGroup$D(this.graphicalObjectList$(), this.molecularAreaScalePixelsPerCoord);
this.redrawMolecularAreaOnly$();
} else {
this.options$S("depict");
}this.handleAfterAfterDepictEditToggleEvent$();
}, p$2);

Clazz.newMeth(C$, 'mouseDrag$java_awt_event_MouseEvent$I$I',  function (e, x, y) {
if (!this.movePossible || e.isMetaDown$() ) return true;
this.gui.mustReDrawInfo=false;
var drawingAreaMoveX=this.scaleScreenToDrawing$D(x - this.mouseX);
var drawingAreaMoveY=this.scaleScreenToDrawing$D(y - this.mouseY);
var drawingAreaX=this.screenToDrawingX$D(x);
var drawingAreaY=this.screenToDrawingY$D(y);
if (this.lastAction == 2 || this.lastAction == 3  || this.lastAction == 9 ) {
return true;
}if (this.lastAction == 1) {
var done=false;
if (this.lastTouched.mol != null ) this.lastTouched.mol.touchedAtom=0;
--this.activeMol.natoms;
this.findMolAndAtomOrBondInDrawingArea$I$I$jme_JME_Touched(x, y, this.newTouched);
++this.activeMol.natoms;
if (this.newTouched.mol != null  && this.newTouched.atomIndex > 0 ) {
var touched_JMEmol=this.newTouched.mol;
touched_JMEmol.touchedAtom=this.newTouched.atomIndex;
if (touched_JMEmol !== this.activeMol  || this.newTouched.atomIndex != this.activeMol.touched_org ) {
this.activeMol.XY$I$D$D(this.activeMol.natoms, touched_JMEmol.x$I(this.newTouched.atomIndex), touched_JMEmol.y$I(this.newTouched.atomIndex));
touched_JMEmol.touchedAtom=this.newTouched.atomIndex;
done=true;
this.lastTouched.initMyselfWith$jme_JME_Touched(this.newTouched);
}}if (!done) {
this.activeMol.rubberBanding$D$D(drawingAreaX, drawingAreaY);
}this.bondRubberBanding=true;
} else if (this.action == 113 && this.activeMol.touchedAtom > 0 ) {
this.movingAtom=true;
this.activeMol.XY$I$D$D(this.activeMol.touchedAtom, drawingAreaX, drawingAreaY);
this.activeMol.setBondCenters$();
} else if (e.isShiftDown$() || e.isMetaDown$() ) {
this.activeMol.rotate$D(drawingAreaMoveX);
this.lastAction=5;
} else if (this.activeMol.touchedAtom == 0 && this.activeMol.touchedBond == 0 ) {
if (!this.isOutsideDrawingArea$I$I(x, y)) {
var boundingBox=this.getMolecularAreaCoordBoundingBox$();
$I$(30).move$jme_canvas_Graphical2DObject$D$D$java_awt_geom_Rectangle2D_Double(this.activeGraphicalObject, drawingAreaMoveX, drawingAreaMoveY, boundingBox);
this.lastAction=5;
}}this.redrawMolecularAreaOnly$();
this.mouseX=x;
this.mouseY=y;
return true;
});

Clazz.newMeth(C$, 'moveTo$I$I$I',  function (screenX, screenY, newAtom) {
this.mustRedrawNothing$();
var repaintFlag=false;
if (newAtom != 0) {
this.keyTouched.mol=this.newTouched.mol=this.activeMol;
this.keyTouched.atomIndex=this.newTouched.atomIndex=(newAtom > 0 ? newAtom : 0);
this.keyTouched.bondIndex=this.newTouched.bondIndex=(newAtom < 0 ? -newAtom : 0);
} else if (this.isInMolecularArea$I$I(screenX, screenY)) {
this.findMolAndAtomOrBondInDrawingArea$I$I$jme_JME_Touched(screenX, screenY, this.newTouched);
} else {
var action=this.gui.determineMenuAction$D$D$Z(screenX, screenY, true);
if (action > 0 && this.isActionEnabled$I(action) ) {
if (action != this.mouseWasOverAction) {
repaintFlag=p$2.handleMouseLeaveActionMenu$I.apply(this, [this.mouseWasOverAction]);
repaintFlag=p$2.handleMouseEnterActionMenu$I.apply(this, [action]) || repaintFlag ;
this.mouseWasOverAction=action;
}}}if ((this.newTouched.isTouched$() || this.lastTouched.isTouched$() ) && !this.newTouched.equals$jme_JME_Touched(this.lastTouched) ) {
repaintFlag=p$2.setTouched.apply(this, []);
}if (repaintFlag) {
this.setMustRedrawMolecularArea$Z(true);
this.repaint$();
}return repaintFlag;
});

Clazz.newMeth(C$, 'setTouched',  function () {
if (this.lastTouched.mol != null ) {
this.lastTouched.mol.touchedAtom=0;
this.lastTouched.mol.touchedBond=0;
}if (this.newTouched.mol != null ) {
this.newTouched.mol.touchedAtom=this.newTouched.atomIndex;
this.newTouched.mol.touchedBond=this.newTouched.bondIndex;
this.activeMol=this.newTouched.mol;
}this.notifyAtomHighLightJSfunction$I(this.newTouched.atomIndex);
this.notifyBondHighLightJSfunction$I(this.newTouched.bondIndex);
this.lastTouched.initMyselfWith$jme_JME_Touched(this.newTouched);
Clazz.assert(C$, this, function(){return this.lastTouched.equals$jme_JME_Touched(this.newTouched)});
return true;
}, p$2);

Clazz.newMeth(C$, 'keyDown$java_awt_event_KeyEvent$I',  function (e, key) {
if (this.gui == null ) return false;
switch (key) {
case 16:
this.activeMol.clearRotation$();
return false;
case 17:
case 157:
case 18:
return false;
}
this.gui.mustReDrawInfo=false;
var ch=e.getKeyChar$();
var allowModify=false;
if (key >= 96 && key <= 105 ) {
allowModify=true;
key=key - 96 + 48;
} else if (Character.isAlphabetic$I(key)) {
allowModify=true;
} else if (ch != "\uffff") {
key=0 + ch.$c();
}if (this.isDepict$() && !this.options.depictActionEnabled ) return false;
this.clearInfo$();
var modifiers=e.getModifiers$();
var meta=e.isMetaDown$() || e.isControlDown$() ;
var shift=(allowModify && modifiers == 1 );
if (this.activeMol.touchedAtom > 0) {
this.actions.setAtomVariableAction$Z$I(false, this.action);
} else if (this.activeMol.touchedBond > 0) {
this.actions.setBondVariableAction$Z(true);
}if (meta) {
return this.actions.doAction$O$I(this.actions.getKeyStroke$I$I(key, 2), 0);
}var action=0;
if (modifiers == 0) {
action=p$2.checkKeyPressLeftMenu$I.apply(this, [key]);
}if (action == 0) action=p$2.checkKeyBinding$I$Z.apply(this, [key, shift]);
if (action == -1) return true;
if (action == 0 && this.menuXShortcuts != null   && this.menuXShortcuts.length$() > 0 ) {
action=p$2.checkKeyPressMenuX$I$Z.apply(this, [key, shift]);
}return (action != 0 && this.processMenuAction$I$Z(action, false) );
});

Clazz.newMeth(C$, 'checkKeyBinding$I$Z',  function (key, shift) {
if (this.actions.doAction$O$I(this.actions.getKeyStroke$I$I(key, (shift ? 1 : 0)), 0)) {
return -1;
}return 0;
}, p$2);

Clazz.newMeth(C$, 'doPage$I',  function (action) {
var sdf=null;
switch (action) {
case 152:
sdf=this.sdfStack.previous$();
break;
case 151:
sdf=this.sdfStack.next$();
break;
case 154:
sdf=this.sdfStack.last$();
break;
case 153:
sdf=this.sdfStack.first$();
break;
default:
Clazz.assert(C$, this, function(){return (false)});
}
if (sdf == null ) {
this.info$S("No more molecules in SDF buffer");
return;
}this.clearMyMolecularContent$();
this.pasteFromSDFstack=true;
this.handleReadGenericInput$S$jme_js_AsyncCallback$Z$Z(sdf, null, false, false);
this.pasteFromSDFstack=false;
if (this.infoText.equals$O("")) {
this.info$S("MOL n. " + this.sdfStack.getCurrentDisplayIndex$() + " of " + this.sdfStack.size$() );
this.recordAfterStructureChangedEvent$S("SDFstack");
this.willPostSave$Z(false);
}});

Clazz.newMeth(C$, 'doAtomBond$I',  function (action) {
p$2.getBuilder$jme_JMEmol$I.apply(this, [this.activeMol, action == -1 ? p$2.updateLeftMenuActions.apply(this, []) : action]).checkAtomOrBondAction$();
this.structureChangedByAction=true;
});

Clazz.newMeth(C$, 'updateLeftMenuActions',  function () {
switch (this.action) {
case 701:
this.info$S("-F");
return 2054;
case 801:
this.info$S("-Cl");
return 2055;
case 901:
this.info$S("-Br");
return 2056;
case 1001:
this.info$S("-I");
return 2057;
case 501:
this.info$S("-OH");
return 2059;
case 401:
this.info$S("-NH2");
return 2058;
default:
return 202;
}
}, p$2);

Clazz.newMeth(C$, 'doAtomG$',  function () {
if (this.activeMol.touchedAtom > 0) {
this.atomicSymbol.setText$S("*");
this.options.xButton=true;
this.doAtomX$();
}});

Clazz.newMeth(C$, 'doAtomX$',  function () {
if (this.activeMol.touchedAtom > 0 && this.options.xButton ) {
this.info$S(this.atomicSymbol.getText$());
this.active_an=32;
p$2.getBuilder$jme_JMEmol$I.apply(this, [this.activeMol, 1201]).checkAtomAction$();
}});

Clazz.newMeth(C$, 'doNavigate$I',  function (key) {
var dir=0;
switch (key) {
case 38:
dir=1;
break;
case 40:
dir=2;
break;
case 39:
dir=4;
break;
case 37:
dir=3;
break;
default:
return;
}
var aorb=(this.activeMol.touchedAtom > 0 ? this.activeMol.touchedAtom : -this.activeMol.touchedBond);
var isMove=(aorb != 0);
if (!isMove) {
aorb=(this.keyTouched.mol !== this.activeMol  ? 0 : this.keyTouched.atomIndex > 0 ? this.keyTouched.atomIndex : -this.keyTouched.bondIndex);
}if (aorb == 0) {
isMove=true;
aorb=-1;
}var a=(!isMove ? aorb : this.activeMol.navigateBonds$I$I(aorb, dir));
if (a != 0) {
this.moveTo$I$I$I(0, 0, a);
}});

Clazz.newMeth(C$, 'getMenuXShortcuts$',  function () {
return this.menuXShortcuts;
});

Clazz.newMeth(C$, 'setMenuXShortcuts$S',  function (shortcuts) {
this.menuXShortcuts=shortcuts;
});

Clazz.newMeth(C$, 'checkKeyPressMenuX$I$Z',  function (key, shift) {
var shortcut=(shift ? Character.toUpperCase$C(String.fromCharCode(key)) : Character.toLowerCase$C(String.fromCharCode(key)));
if (this.menuXShortcuts.indexOf$I(shortcut) < 0) return 0;
this.atomicSymbol.setText$S(Character.toString$C(shortcut));
this.options.xButton=true;
this.info$S(this.atomicSymbol.getText$());
this.active_an=32;
return 1201;
}, p$2);

Clazz.newMeth(C$, 'checkKeyPressLeftMenu$I',  function (key) {
switch (key) {
case 67:
return 301;
case 78:
return 401;
case 79:
return 501;
case 83:
return 601;
case 80:
return 1101;
case 70:
return 701;
case 76:
return 801;
case 66:
return 901;
case 73:
return 1001;
case 72:
this.info$S("H");
return 1300;
case 82:
this.info$S("-R");
return 1301;
}
return 0;
}, p$2);

Clazz.newMeth(C$, 'mergeMols$jme_JME_Touched$jme_JMEmol',  function (last, active) {
active.deleteAtom$I(active.natoms);
var atom1=active.touched_org;
var atom2=last.atomIndex + active.natoms;
Clazz.assert(C$, this, function(){return atom1 != active.natoms + 1});
var otherMol=last.mol;
var merged=Clazz.new_([this, Clazz.array($I$(17), -1, [active, otherMol])],$I$(17,1).c$$jme_JME$jme_JMEmolA);
merged.atoms[0]=Clazz.new_($I$(40,1));
merged.createAndAddNewBond$I$I$I(atom1, atom2, 1);
this.moleculePartsList.remove$O(otherMol);
this.moleculePartsList.replace$jme_JMEmol$jme_JMEmol(active, merged);
last.reset$();
return merged;
});

Clazz.newMeth(C$, 'willPostSave$Z',  function (b) {
this.saveCurrentState=b;
});

Clazz.newMeth(C$, 'scaleScreenToDrawing$D',  function (pos) {
return pos / this.molecularAreaScalePixelsPerCoord;
});

Clazz.newMeth(C$, 'scaleDrawingToScreen$D',  function (coord) {
return Long.$ival(Math.round$D(coord * this.molecularAreaScalePixelsPerCoord));
});

Clazz.newMeth(C$, 'screenToDrawingX$D',  function (appletPixelPositionX) {
return this.scaleScreenToDrawing$D(appletPixelPositionX - this.leftMenuWidth$());
});

Clazz.newMeth(C$, 'screenToDrawingY$D',  function (appletPixelPositionY) {
return this.scaleScreenToDrawing$D(appletPixelPositionY - this.topMenuHeight$());
});

Clazz.newMeth(C$, 'drawingToScreenX$D',  function (xCoord) {
var screenX=this.scaleDrawingToScreen$D(xCoord);
screenX+=this.leftMenuWidth$();
return screenX;
});

Clazz.newMeth(C$, 'drawingToScreenY$D',  function (yCoord) {
var screenY=this.scaleDrawingToScreen$D(yCoord);
screenY+=this.topMenuHeight$();
return screenY;
});

Clazz.newMeth(C$, 'findClosestMol$I$I',  function (x, y) {
var found=null;
if (this.moleculePartsList.size$() == 1) return this.moleculePartsList.first$();
var xCoord=this.screenToDrawingX$D(x);
var yCoord=this.screenToDrawingY$D(y);
var min=1.7976931348623157E308;
for (var mol, $mol = this.moleculePartsList.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
var d=mol.closestDistance$D$D(xCoord, yCoord);
if (d < min ) {
min=d;
found=mol;
}}
return found;
});

Clazz.newMeth(C$, 'findClosestGraphicalObject$I$I',  function (x, y) {
var found=null;
var xCoord=this.screenToDrawingX$D(x);
var yCoord=this.screenToDrawingY$D(y);
var min=1.7976931348623157E308;
if (this.options.reaction) {
min=this.reactionArrow.closestDistance$D$D(xCoord, yCoord);
found=this.reactionArrow;
}for (var mol, $mol = this.moleculePartsList.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
var d=mol.closestDistance$D$D(xCoord, yCoord);
if (d < min ) {
min=d;
found=mol;
}}
return found;
});

Clazz.newMeth(C$, 'findMolAndAtomOrBondInDrawingArea$I$I$jme_JME_Touched',  function (x, y, result) {
if (this.isOutsideDrawingArea$I$I(x, y)) {
result.reset$();
return;
}this.findMolAndAtomOrBondWithinRadius$I$I$I$jme_JME_Touched(x, y, $I$(21).getHumanInteractionTouchRadius$(), result);
});

Clazz.newMeth(C$, 'findMolAndAtomOrBondWithinRadius$I$I$I$jme_JME_Touched',  function (screenX, screenY, radius, result) {
result.reset$();
var xCoord=this.screenToDrawingX$D(screenX);
var yCoord=this.screenToDrawingY$D(screenY);
var minDistance=radius;
var retMin=Clazz.array(Double.TYPE, [1]);
var ignoreAtoms=this.ignoreAtoms$();
var ignoreBonds=this.ignoreBonds$();
for (var eachMol, $eachMol = this.moleculePartsList.iterator$(); $eachMol.hasNext$()&&((eachMol=($eachMol.next$())),1);) {
retMin[0]=radius;
var a_or_b=eachMol.testAtomAndBondTouch$D$D$Z$Z$DA(xCoord, yCoord, ignoreAtoms, ignoreBonds, retMin);
if (retMin[0] < minDistance ) {
minDistance=retMin[0];
result.reset$();
result.mol=eachMol;
result.distance=minDistance;
if (a_or_b > 0) result.atomIndex=a_or_b;
 else result.bondIndex=-a_or_b;
}}
});

Clazz.newMeth(C$, 'isMacintosh$',  function () {
return false;
});

Clazz.newMeth(C$, 'updateMark$I',  function (n) {
if (this.options.autonumber) {
if (n == 0) {
this.keyboradInputMark=0;
this.showInfo$S("click marked atom to delete map");
this.markFromKeyboardInput=true;
return;
}}if (this.resetExtendAtomMark) {
this.keyboradInputMark=n;
this.resetExtendAtomMark=false;
} else {
if (this.keyboradInputMark > -1 && this.keyboradInputMark < 100 ) this.keyboradInputMark=this.keyboradInputMark * 10 + n;
 else {
this.keyboradInputMark=n;
this.resetExtendAtomMark=false;
}}var action_type="map";
var target="atom";
var reset_action="delete map";
if (this.params.mark) {
reset_action="remove background color";
action_type="color index";
if (this.options.starAtomOnly) {
} else if (this.options.starBondOnly) {
target="bond";
} else {
target="atom or bond";
}if (this.keyboradInputMark <= 0) {
this.keyboradInputMark=1;
}}if (this.keyboradInputMark == 0) {
this.keyboradInputMark=0;
this.showInfo$S("click marked " + target + " to " + reset_action );
} else {
if (this.params.mark) {
this.activateMarkerColor$I(this.keyboradInputMark);
}this.showInfo$S("Click " + target + " to set " + action_type + " to " + this.keyboradInputMark );
}this.markFromKeyboardInput=true;
});

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (evt) {
this.mustRedrawNothing$();
var cmd=evt.getActionCommand$();
if (this.subclassHandleMenuAction$S(cmd)) {
return;
}var colorInfo=this.colorManager.getColorInfoOfColorHash$S(cmd);
if (colorInfo != null ) {
var colorIndex=colorInfo.index;
this.activateMarkerColor$I(colorIndex);
this.showInfo$S(colorInfo.name);
return;
}var cpa=$I$(25).getFromName$S(cmd);
if (cpa != null ) {
switch (cpa) {
case $I$(25).FIXED_H_INCHI:
case $I$(25).FIXED_H_INCHI_KEY:
case $I$(25).INCHI_AUXINFO:
case $I$(25).STANDARD_INCHI:
case $I$(25).STANDARD_INCHI_KEY:
case $I$(25).INCHI_MODEL_JSON:
this.copyInchiToClipboard$jme_JME_CopyPasteAction(cpa);
break;
case $I$(25).JME:
this.copyJmeStringToClipboard$();
break;
case $I$(25).MOL:
this.copyMolFileToClipboard$Z(false);
break;
case $I$(25).MOL_V3000:
this.copyMolFileToClipboard$Z(true);
break;
case $I$(25).OCLCODE:
this.copyOclCodetoClipboard$();
break;
case $I$(25).PASTE:
if (this.options.paste) this.pasteMolFileFromClipboard$();
break;
case $I$(25).RAW_STRING_GRAPHIC:
if (C$.isJavaScript) this.copyRawGraphicToClipboard$();
break;
case $I$(25).SEARCH_INCHI_KEY:
this.searchChemicalStructureUsingInchiKey$();
break;
case $I$(25).SMILES:
this.clipBoardManager.setClipboardContents$S(this.smiles$());
break;
case $I$(25).SVG:
this.copySVGToClipboard$();
break;
default:
break;
}
return;
}var changed=false;
switch (cmd) {
case "rotation":
if (this.lastAction != 7) {
this.lastRotation=0;
}var rotation=evt.getWhen$();
(rotation=Long.$mul(rotation,(-1)));
var deltaRotation=Long.$sub(rotation,this.lastRotation);
if (Long.$lt(Math.abs$J(deltaRotation),10 )) {
this.activeMol.clearRotation$();
this.activeMol.rotate$D(Long.$ival(deltaRotation));
}this.setMustRedrawMolecularArea$Z(true);
this.lastAction=7;
this.lastRotation=rotation;
break;
case "Unset molecule chiral flag":
case "Set molecule chiral flag":
changed=this.activeMol.setChiralFlag$Boolean(Boolean.valueOf$Z(cmd == "Set molecule chiral flag"));
if (changed) {
var n=this.moleculePartsList.size$();
var additional="";
if (n > 1) {
var index=this.moleculePartsList.indexOf$O(this.activeMol);
++index;
additional=" for molecule " + index;
}if ((this.activeMol.chiralFlag).valueOf()) {
this.info$S("Chiral flag is set" + additional);
} else {
this.info$S("No Chiral flag" + additional);
}this.recordMoleculePartEvent$S$I("changeChiral", this.activeMolIndex$());
this.setMustRedrawMolecularArea$Z(true);
}break;
case "Auto atom map molecule":
var max=this.findMaxAtomMapAmongAllMolecules$();
for (var at=1; at <= this.activeMol.natoms; at++) {
var atom=this.activeMol.atoms[at];
if (!atom.hasBeenMapped$()) {
++max;
atom.setMap$I(max);
changed=true;
}}
if (changed) {
this.setMustRedrawMolecularArea$Z(true);
this.recordMoleculePartEvent$S$I("changeManyAtomMap", this.activeMolIndex$());
}break;
case "Delete all atom map molecule":
if ((this.setMustRedrawMolecularArea$Z(this.activeMol.resetAtomMaps$()))) {
this.recordMoleculePartEvent$S$I("deleteAtomMaps", this.activeMolIndex$());
}break;
case "Set coordination bond":
case "Unset coordination bond":
this.setMustRedrawMolecularArea$Z(true);
var bondIndex=this.inspectorEvent.bondIndex;
Clazz.assert(C$, this, function(){return (bondIndex > 0)});
var isCoordination=Boolean.valueOf$Z(this.inspectorEvent.mol.getBond$I(bondIndex).toggleCoordination$().isCoordination$());
this.recordBondEvent$S(isCoordination.booleanValue$() ? "setBondCoordination" : "unSetBondCoordination");
break;
case "Delete hydrogens":
var options=Clazz.new_($I$(9,1)).hydrogenParams;
options.removeHs=true;
options.removeOnlyCHs=false;
this.setMustRedrawMolecularArea$Z(this.activeMol.deleteHydrogens$jme_core_JMECore_Parameters_HydrogenParams(options));
if (this.gui.mustReDrawMolecularArea) {
this.recordMoleculePartEvent$S$I("deleteHydrogens", this.activeMolIndex$());
}break;
case "Compute 2D coordinates":
$I$(46,"invokeLater$Runnable",[((P$.JME$lambda6||
(function(){/*m*/var C$=Clazz.newClass(P$, "JME$lambda6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'run$',  function () /*block*/{
this.b$['jme.JME'].compute2DSuccess$.apply(this.b$['jme.JME'], []);
});
})()
), Clazz.new_(P$.JME$lambda6.$init$,[this, null]))]);
return;
case "scale100":
break;
case "end_gesture":
this.willPostSave$Z(true);
break;
default:
this.setSubstituent$S(cmd);
break;
}
if (this.gui.mustReDrawMolecularArea || this.gui.mustReDrawInfo ) {
this.repaint$();
}});

Clazz.newMeth(C$, 'subclassHandleMenuAction$S',  function (cmd) {
return false;
});

Clazz.newMeth(C$, 'compute2DSuccess$',  function () {
if (this.activeMol.nAtoms$() == 0) return;
var index=this.activeMolIndex$();
var centerX=this.activeMol.centerX$();
var centerY=this.activeMol.centerY$();
var newActiveMol=this.activeMol.compute2DcoordinatesIfMissing$();
if (newActiveMol != null ) {
var dx=centerX - newActiveMol.centerX$();
var dy=centerY - newActiveMol.centerY$();
newActiveMol.moveXY$D$D(dx, dy);
this.moleculePartsList.set$I$O(index, newActiveMol);
this.recordMoleculePartEvent$S$I("compute2D", index);
this.setMustRedrawMolecularArea$Z(true);
this.info$S("2D coordinates provided by OpenChemLib");
this.repaint$();
} else {
this.info$S("2D coordinates computation failed");
}});

Clazz.newMeth(C$, 'copyFileToClipboard$',  function () {
switch (this.clipboardFormat) {
case $I$(1).MOL:
this.copyMolFileToClipboard$Z(false);
break;
case $I$(1).MOL_V3000:
this.copyMolFileToClipboard$Z(true);
break;
case $I$(1).JME:
this.copyJmeStringToClipboard$();
break;
case $I$(1).SVG:
this.copySVGToClipboard$();
break;
case $I$(1).RAW_STRING_GRAPHIC:
this.copyRawGraphicToClipboard$();
break;
case $I$(1).SMILES:
this.clipBoardManager.setClipboardContents$S(this.smiles$());
break;
case $I$(1).STANDARD_INCHI:
this.copyInchiToClipboard$jme_JME_CopyPasteAction($I$(25).STANDARD_INCHI);
break;
case $I$(1).INCHI_AUXINFO:
this.copyInchiToClipboard$jme_JME_CopyPasteAction($I$(25).INCHI_AUXINFO);
break;
case $I$(1).STANDARD_INCHI_KEY:
this.copyInchiToClipboard$jme_JME_CopyPasteAction($I$(25).STANDARD_INCHI_KEY);
break;
case $I$(1).OCLCODE:
this.copyOclCodetoClipboard$();
break;
default:
this.clipBoardManager.setClipboardContents$S("incorrect or unsupported export format");
}
});

Clazz.newMeth(C$, 'generateOutputFile$jme_js_AsyncCallback',  function (callBack) {
p$2.generateOuttputFile$jme_io_JMEWriter_SupportedOutputFileFormat$jme_js_AsyncCallback.apply(this, [this.clipboardFormat, callBack]);
});

Clazz.newMeth(C$, 'generateOuttputFile$jme_io_JMEWriter_SupportedOutputFileFormat$jme_js_AsyncCallback',  function (format, callBack) {
var output=null;
switch (format) {
case $I$(1).MOL:
output=this.molFile$Z(false);
break;
case $I$(1).MOL_V3000:
output=this.molFile$Z(true);
break;
case $I$(1).JME:
output=this.jmeFile$();
break;
case $I$(1).SVG:
$I$(46,"invokeLater$Runnable",[((P$.JME$lambda7||
(function(){/*m*/var C$=Clazz.newClass(P$, "JME$lambda7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'run$',  function () /*block*/{
this.$finals$.callBack.onSuccess.apply(this.$finals$.callBack, [this.b$['jme.JME'].getOclSVG$.apply(this.b$['jme.JME'], [])]);
});
})()
), Clazz.new_(P$.JME$lambda7.$init$,[this, {callBack:callBack}]))]);
break;
case $I$(1).RAW_STRING_GRAPHIC:
output=this.getMolecularAreaGraphicsString$();
break;
case $I$(1).SMILES:
output=this.smiles$();
break;
case $I$(1).STANDARD_INCHI:
case $I$(1).INCHI_AUXINFO:
case $I$(1).STANDARD_INCHI_KEY:
case $I$(1).INCHI_MODEL_JSON:
this.computeInchi$jme_io_JMEWriter_SupportedOutputFileFormat$jme_js_AsyncCallback(format, callBack);
break;
case $I$(1).OCLCODE:
$I$(46,"invokeLater$Runnable",[((P$.JME$lambda8||
(function(){/*m*/var C$=Clazz.newClass(P$, "JME$lambda8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'run$',  function () /*block*/{
this.$finals$.callBack.onSuccess.apply(this.$finals$.callBack, [this.b$['jme.JME'].getOclCode$.apply(this.b$['jme.JME'], [])]);
});
})()
), Clazz.new_(P$.JME$lambda8.$init$,[this, {callBack:callBack}]))]);
return;
default:
var error=Clazz.new_(Throwable.c$$S,["incorrect or unsupported export format"]);
callBack.onFailure(error);
}
if (output != null ) {
callBack.onSuccess(output);
}}, p$2);

Clazz.newMeth(C$, 'computeInchi$jme_io_JMEWriter_SupportedOutputFileFormat$jme_js_AsyncCallback',  function (format, callBack) {
switch (format) {
case $I$(1).STANDARD_INCHI:
break;
case $I$(1).INCHI_AUXINFO:
break;
case $I$(1).INCHI_MODEL_JSON:
break;
case $I$(1).STANDARD_INCHI_KEY:
break;
case $I$(1).JME:
break;
case $I$(1).MOL:
break;
case $I$(1).MOL_V3000:
break;
case $I$(1).OCLCODE:
break;
case $I$(1).RAW_STRING_GRAPHIC:
break;
case $I$(1).SMILES:
break;
case $I$(1).SVG:
break;
default:
break;
}
});

Clazz.newMeth(C$, 'copyMolFileToClipboard$Z',  function (isV3000) {
this.clipBoardManager.setClipboardContents$S(this.molFile$Z(isV3000));
});

Clazz.newMeth(C$, 'copyJmeStringToClipboard$',  function () {
this.clipBoardManager.setClipboardContents$S(this.jmeFile$());
});

Clazz.newMeth(C$, 'copyOclCodetoClipboard$',  function () {
$I$(46,"invokeLater$Runnable",[((P$.JME$lambda9||
(function(){/*m*/var C$=Clazz.newClass(P$, "JME$lambda9", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'run$',  function () /*block*/{
this.b$['jme.JME'].clipBoardManager.setClipboardContents$S.apply(this.b$['jme.JME'].clipBoardManager, [this.b$['jme.JME'].getOclCode$.apply(this.b$['jme.JME'], [])]);
});
})()
), Clazz.new_(P$.JME$lambda9.$init$,[this, null]))]);
});

Clazz.newMeth(C$, 'copySVGToClipboard$',  function () {
$I$(46,"invokeLater$Runnable",[((P$.JME$lambda10||
(function(){/*m*/var C$=Clazz.newClass(P$, "JME$lambda10", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'run$',  function () /*block*/{
this.b$['jme.JME'].clipBoardManager.setClipboardContents$S.apply(this.b$['jme.JME'].clipBoardManager, [this.b$['jme.JME'].getOclSVG$.apply(this.b$['jme.JME'], [])]);
});
})()
), Clazz.new_(P$.JME$lambda10.$init$,[this, null]))]);
});

Clazz.newMeth(C$, 'copyRawGraphicToClipboard$',  function () {
var result=this.getMolecularAreaGraphicsString$();
if (result != null ) {
this.clipBoardManager.setClipboardContents$S(result);
}});

Clazz.newMeth(C$, 'copyInchiToClipboard$jme_JME_CopyPasteAction',  function (cpa) {
var option=null;
var isKey=false;
switch (cpa) {
case $I$(25).FIXED_H_INCHI:
option="fixedH";
break;
case $I$(25).STANDARD_INCHI:
option="standard";
break;
case $I$(25).INCHI_MODEL_JSON:
option="model";
case $I$(25).INCHI_AUXINFO:
option="auxinfo";
break;
case $I$(25).FIXED_H_INCHI_KEY:
option="fixedH";
isKey=true;
break;
case $I$(25).STANDARD_INCHI_KEY:
option="standard";
isKey=true;
break;
default:
break;
}
if (option != null ) {
var s=this.molFile$Z(true);
if (isKey) {
s=this.molToInChIKey$S$S(s, option);
} else {
s=this.molToInChI$S$S(s, option);
}System.out.println$S(s);
this.clipBoardManager.setClipboardContents$S(s);
}});

Clazz.newMeth(C$, 'searchChemicalStructureUsingInchiKey$',  function () {
});

Clazz.newMeth(C$, 'pasteMolFileFromClipboard$',  function () {
this.afterStructureChangeEvent.setOrigin_PASTE$();
this.clipBoardManager.getAsyncClipboardContents$jme_io_TextTransfer_PasteAction(this.getPasteAction$());
});

Clazz.newMeth(C$, 'pasteDirect$S$Z',  function (molString, originIsDrop) {
if (!this.options.paste) {
return;
}if (molString != null  && molString.length$() > 0 ) {
if (originIsDrop) this.afterStructureChangeEvent.setOrigin_DROP$();
 else this.afterStructureChangeEvent.setOrigin_PASTE$();
this.getPasteAction$().paste$S(molString);
} else {
this.showError$S("empty or null structure");
}});

Clazz.newMeth(C$, 'getPasteAction$',  function () {
return this.createPasteActionInstanceIfNeeded$();
});

Clazz.newMeth(C$, 'createPasteActionInstanceIfNeeded$',  function () {
if (this.pasteAction == null ) {
this.pasteAction=((P$.JME$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "JME$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, [['jme.io.TextTransfer','jme.io.TextTransfer.PasteAction']], 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'paste$S',  function (clipboardContent) {
if (clipboardContent != null ) {
this.b$['jme.JME'].handleClipboardPasteAction$S.apply(this.b$['jme.JME'], [clipboardContent]);
}});
})()
), Clazz.new_(P$.JME$1.$init$,[this, null]));
}return this.pasteAction;
});

Clazz.newMeth(C$, 'handleClipboardPasteAction$S',  function (clipboardContent) {
if (this.getPrePasteJSfunction$() != null ) {
this.getPrePasteJSfunction$().apply(this, Clazz.array(String, -1, [clipboardContent]));
return;
}if (this.handleBeforePasteEvent$S(clipboardContent)) {
return;
}this.pasteGenericInput$S$Z$jme_js_AsyncCallback(clipboardContent, true, ((P$.JME$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "JME$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'jme.js.AsyncCallback', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['onFailure$Throwable','onFailure'],  function (reason) {
});

Clazz.newMeth(C$, ['onSuccess$O','onSuccess'],  function (o) {
this.b$['jme.JME'].handleAfterPasteEvent$S.apply(this.b$['jme.JME'], [this.$finals$.clipboardContent]);
});
})()
), Clazz.new_(P$.JME$2.$init$,[this, {clipboardContent:clipboardContent}])));
});

Clazz.newMeth(C$, 'pasteGenericInput$S$Z$jme_js_AsyncCallback',  function (chemicalString, recordEvent, sucessAndFailureHandle) {
this.sdfPastedMessage.innerString="";
this.afterStructureChangeEvent.setOrigin_API$();
var countSDF=this.sdfStack.addEntries$S(chemicalString);
if (countSDF > 0) {
this.sdfPastedMessage.innerString=" Use Page Up/Down for SDF access (" + countSDF + ")" ;
this.afterStructureChangeEvent.setAction$S("readMultiSDF");
this.notifyStructuralChange$S("paste");
}var localSucessAndFailureHandle=((P$.JME$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "JME$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'jme.js.AsyncCallback', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['onFailure$Throwable','onFailure'],  function (reason) {
this.b$['jme.JME'].info$S.apply(this.b$['jme.JME'], ["ERROR: " + reason.getMessage$()]);
this.b$['jme.JME'].alert$S.apply(this.b$['jme.JME'], [this.b$['jme.JME'].infoText]);
this.b$['jme.JME'].reset$.apply(this.b$['jme.JME'], []);
this.b$['jme.JME'].repaint$.apply(this.b$['jme.JME'], []);
});

Clazz.newMeth(C$, ['onSuccess$O','onSuccess'],  function (o) {
this.b$['jme.JME'].info$S.apply(this.b$['jme.JME'], ["Structure pasted. " + this.b$['jme.JME'].sdfPastedMessage.innerString]);
this.b$['jme.JME'].setMustRedrawMolecularArea$Z.apply(this.b$['jme.JME'], [true]);
this.b$['jme.JME'].repaint$.apply(this.b$['jme.JME'], []);
this.$finals$.sucessAndFailureHandle.onSuccess(o);
});
})()
), Clazz.new_(P$.JME$3.$init$,[this, {sucessAndFailureHandle:sucessAndFailureHandle}]));
try {
this.handleReadGenericInput$S$jme_js_AsyncCallback$Z$Z(chemicalString, localSucessAndFailureHandle, false, recordEvent);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
localSucessAndFailureHandle.onFailure(e);
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'cutSelectedMoleculeForSystemClipBoard$',  function () {
if (this.activeMol.natoms == 0) {
return "";
}this.activeMol.forceUniColor$java_awt_Color($I$(4).RED);
var s=this.activeMol.createMolFile$S("");
this.redrawMolecularAreaOnly$();
this.clear$();
this.redrawMolecularAreaOnly$();
return s;
});

Clazz.newMeth(C$, 'cutSelectedMoleculeForSystemClipBoard$jme_js_AsyncCallback',  function (callBack) {
if (this.activeMol.natoms == 0) {
return;
}this.generateOutputFile$jme_js_AsyncCallback(callBack);
this.clear$();
this.redrawMolecularAreaOnly$();
});

Clazz.newMeth(C$, 'postSave$',  function () {
if (!true) {
return;
}var state=this.createState$();
this.molChangeManager.insertItem$O(state);
System.err.println$S("JME.postSave saving state");
});

Clazz.newMeth(C$, 'createState$',  function () {
while (this.moleculePartsList.isReallyEmpty$() && this.moleculePartsList.size$() > 1 ){
this.moleculePartsList.remove$I(0);
}
var state=Clazz.new_($I$(51,1));
state.moleculePartsList=this.moleculePartsList.deepCopy$();
state.reaction=this.options.reaction;
state.multipart=this.options.multipart;
state.depictScale=this.molecularAreaScalePixelsPerCoord;
state.lastAction=this.lastAction;
return state;
});

Clazz.newMeth(C$, 'restoreState$jme_JME_SavedState',  function (state) {
this.basicRetoreState$jme_JME_SavedState(state);
switch (state.lastAction) {
case 5:
case 7:
case 9:
break;
default:
this.notifyStructuralChange$S("restore");
}
});

Clazz.newMeth(C$, 'basicRetoreState$jme_JME_SavedState',  function (state) {
if (state == null ) {
do {
this.clear$Z(false);
} while (!this.moleculePartsList.isReallyEmpty$());
return;
}this.moleculePartsList=state.moleculePartsList.deepCopy$();
if (state.activeMol != null ) {
this.activeMol=state.activeMol;
} else {
this.activeMol=Clazz.new_($I$(17,1).c$$jme_JME$jme_core_JMECore_Parameters,[this, this.params]);
}this.options.reaction=state.reaction;
this.options.multipart=state.multipart;
this.molecularAreaScalePixelsPerCoord=state.depictScale;
});

Clazz.newMeth(C$, 'getCopyPasteJPopupMenuMol$',  function () {
this.copyPasteJPopupMenuMol=this.createCopyPasteJPopupMenu$Z(false);
return this.copyPasteJPopupMenuMol;
});

Clazz.newMeth(C$, 'getCopyPasteJPopupMenuReaction$',  function () {
this.copyPasteJPopupMenuReaction=this.createCopyPasteJPopupMenu$Z(true);
return this.copyPasteJPopupMenuReaction;
});

Clazz.newMeth(C$, 'handleCopyPasteJPopupMenu$java_awt_event_MouseEvent$I$I',  function (e, x, y) {
if (e == null  || C$.isEventContextMenu$java_awt_event_MouseEvent(e) ) {
var isTouched=this.activeMol.touchedAtom > 0 || this.activeMol.touchedBond > 0 ;
if (isTouched && (this.action == 104 || this.action == 106 ) ) {
return true;
}if (isTouched && !this.isDepict$() ) {
if (this.touchedMolPopuMenu != null ) {
this.remove$java_awt_Component(this.touchedMolPopuMenu);
}this.touchedMolPopuMenu=this.createMolJPopupMenu$I$I(x, y);
this.add$java_awt_Component(this.touchedMolPopuMenu);
this.touchedMolPopuMenu.show$java_awt_Component$I$I(this, x, y);
} else {
{
var pm;
if (this.options.reaction) {
pm=this.getCopyPasteJPopupMenuReaction$();
} else {
pm=this.getCopyPasteJPopupMenuMol$();
}if (C$.isEventContextMenu$java_awt_event_MouseEvent(e)) {
pm.show$java_awt_Component$I$I(this, x, y);
} else {
this.showJPopupMenuRealtiveToScaledMainMenu$javax_swing_JPopupMenu$I$I(pm, x, y);
}}}this.processMouseMotionEvent$java_awt_event_MouseEvent(Clazz.new_($I$(52,1).c$$java_awt_Component$I$J$I$I$I$I$Z$I,[this, 503, 0, 0, 1000000, 100000, 0, false, 0]));
return true;
}return false;
});

Clazz.newMeth(C$, 'showJPopupMenuRealtiveToScaledMainMenu$javax_swing_JPopupMenu$I$I',  function (pm, x, y) {
pm.show$java_awt_Component$I$I(this, ((x * this.menuScale + 0.5)|0), ((y * this.menuScale + 0.5)|0));
});

Clazz.newMeth(C$, 'isEventContextMenu$java_awt_event_MouseEvent',  function (e) {
return (e != null  && (e.isMetaDown$() || e.isControlDown$() ) );
}, 1);

Clazz.newMeth(C$, 'getNotifyAtomHighLightJSfunction$',  function () {
return this.notifyAtomHighLightJSfunction;
});

Clazz.newMeth(C$, 'setNotifyAtomHighLightChangeJSfunction$jme_js_JSFunction',  function (notifyAtomHighLightJSfunction) {
this.notifyAtomHighLightJSfunction=notifyAtomHighLightJSfunction;
});

Clazz.newMeth(C$, 'notifyAtomOrBondHighLightJSfunction$I$I',  function (touchedAtomOrBond, previousTouchedAtomOrBondForHighlight) {
if (touchedAtomOrBond <= 0 && previousTouchedAtomOrBondForHighlight == 0 ) {
return -1;
}if (touchedAtomOrBond == previousTouchedAtomOrBondForHighlight && this.activeMolIndex$() == this.previousActualMoleculePartIndex ) {
return -1;
}if (touchedAtomOrBond <= 0 && previousTouchedAtomOrBondForHighlight > 0 ) {
touchedAtomOrBond=0;
}this.previousActualMoleculePartIndex=this.activeMolIndex$();
return touchedAtomOrBond;
});

Clazz.newMeth(C$, 'notifyAtomHighLightJSfunction$I',  function (touchedAtom) {
if ((this.canHandleAtomHighLightCallBack$()).valueOf()) {
touchedAtom=this.notifyAtomOrBondHighLightJSfunction$I$I(touchedAtom, this.previousTouchedAtomForHighlight);
if (touchedAtom == -1) return;
this.previousTouchedAtomForHighlight=touchedAtom;
if (this.notifyAtomHighLightJSfunction != null ) {
this.notifyAtomHighLightJSfunction.apply(this, Clazz.array(Integer.TYPE, -1, [this.activeMolIndex$(), touchedAtom]));
}this.handleAtomHighLightCallBack$I$I(this.activeMolIndex$(), touchedAtom);
}});

Clazz.newMeth(C$, 'notifyBondHighLightJSfunction$I',  function (touchedBond) {
if ((this.canHandleBondHighLightCallBack$()).valueOf()) {
touchedBond=this.notifyAtomOrBondHighLightJSfunction$I$I(touchedBond, this.previousTouchedBondForHighlight);
if (touchedBond == -1) return;
this.previousTouchedBondForHighlight=touchedBond;
this.handleBondHighLightCallBack$I$I(this.activeMolIndex$(), touchedBond);
}});

Clazz.newMeth(C$, 'canHandleAtomHighLightCallBack$',  function () {
return Boolean.valueOf$Z(true);
});

Clazz.newMeth(C$, 'canHandleBondHighLightCallBack$',  function () {
return Boolean.valueOf$Z(true);
});

Clazz.newMeth(C$, 'canHandleAtomClickedCallBack$',  function () {
return Boolean.valueOf$Z(true);
});

Clazz.newMeth(C$, 'canHandleBondClickedCallBack$',  function () {
return Boolean.valueOf$Z(true);
});

Clazz.newMeth(C$, 'handleAtomClickedCallBack$I$I',  function (actualMoleculePartIndex, clickedAtom) {
this.notifyEvent$S$O("JME_AtomClickedEvent", Clazz.array(Integer.TYPE, -1, [actualMoleculePartIndex, clickedAtom]));
});

Clazz.newMeth(C$, 'handleBondClickedCallBack$I$I',  function (actualMoleculePartIndex, clickedBond) {
this.notifyEvent$S$O("JME_BondClickedEvent", Clazz.array(Integer.TYPE, -1, [actualMoleculePartIndex, clickedBond]));
});

Clazz.newMeth(C$, 'handleBeforePasteEvent$S',  function (molecule) {
return false;
});

Clazz.newMeth(C$, 'handleAfterPasteEvent$S',  function (pasteContent) {
this.notifyEvent$S$O("JME_PasteEvent", pasteContent);
});

Clazz.newMeth(C$, 'handleAfterAfterDepictEditToggleEvent$',  function () {
this.notifyEvent$S$O("JME_DepictEditToggleEvent", Boolean.valueOf$Z(this.depict));
});

Clazz.newMeth(C$, 'handleAftertructureModifiedEvent$S',  function (cause) {
this.notifyEvent$S$O("JME_StructureModifiedEvent", this.afterStructureChangeEvent);
this.updateReactionRoles$();
});

Clazz.newMeth(C$, 'notifyEvent$S$O',  function (name, value) {
this.firePropertyChange$S$O$O(name, Clazz.array(java.lang.Object, -1, [this.options.getApplet$Z(false)]), value);
});

Clazz.newMeth(C$, 'handleAtomHighLightCallBack$I$I',  function (actualMoleculePartIndex, touchedAtom) {
this.notifyEvent$S$O("JME_AtomHighlightEvent", Clazz.array(Integer.TYPE, -1, [actualMoleculePartIndex, touchedAtom]));
});

Clazz.newMeth(C$, 'handleBondHighLightCallBack$I$I',  function (actualMoleculePartIndex, touchedBond) {
this.notifyEvent$S$O("JME_BondHighlightEvent", Clazz.array(Integer.TYPE, -1, [actualMoleculePartIndex, touchedBond]));
});

Clazz.newMeth(C$, 'setAtomToHighLight$I$I',  function (molIndex, atomIndex) {
this.moleculePartsList.resetTouchedAtomAndBond$();
if (atomIndex != 0) {
var ea=this.getEnsembleAtom$I$I(molIndex, atomIndex);
if (ea == null ) {
this.showError$S("invalid atom index or molecule index");
return;
}ea.mol.touchedAtom=ea.atomIndex;
}this.redrawMolecularAreaOnly$();
});

Clazz.newMeth(C$, 'setBondToHighLight$I$I',  function (molIndex, bondIndex) {
this.moleculePartsList.resetTouchedAtomAndBond$();
if (bondIndex != 0) {
var ea=this.getEnsembleBond$I$I(molIndex, bondIndex);
if (ea == null ) {
this.showError$S("invalid bond index or molecule index");
return;
}ea.mol.touchedBond=ea.bondIndex;
}this.redrawMolecularAreaOnly$();
});

Clazz.newMeth(C$, 'changeAtomMap$I$I$I',  function (molIndex, atomIndex, newMap) {
var mol=this.selectMolIfValidOrShowError$I(molIndex);
this.changeAtomMap$jme_JMEmol$I$I(mol, atomIndex, newMap);
});

Clazz.newMeth(C$, 'changeAtomMap$jme_JMEmol$I$I',  function (mol, atomIndex, newMap) {
var at=mol.getAtom$I(atomIndex);
if (newMap <= 0) {
at.resetObjectMark$();
} else {
at.setMapOrMark$I$Z(newMap, !this.params.mark);
}this.recordAtomEvent$S$I("changeAtomMap", atomIndex);
this.redrawMolecularAreaOnly$();
});

Clazz.newMeth(C$, 'changeAtomCharge$jme_JMEmol$I$I',  function (mol, atomIndex, newCharge) {
var at=mol.getAtom$I(atomIndex);
at.Q$I(newCharge);
this.recordAtomEvent$S$I("chargeAtom0", atomIndex);
this.redrawMolecularAreaOnly$();
});

Clazz.newMeth(C$, 'getNotifyStructuralChangeJSfunction$',  function () {
return this.notifyStructuralChangeJSfunction;
});

Clazz.newMeth(C$, 'setNotifyStructuralChangeJSfunction$jme_js_JSFunction',  function (notifyStructuralChangeJSfunction) {
this.notifyStructuralChangeJSfunction=notifyStructuralChangeJSfunction;
});

Clazz.newMeth(C$, 'notifyStructuralChange$S',  function (cause) {
if (this.afterStructureChangeEvent != null  && this.afterStructureChangeEvent.action != null  ) {
++this.afterStructureChangeEvent.stackLevel;
var MAX_RECURSIVE_LOOP=1;
if (this.afterStructureChangeEvent.stackLevel <= MAX_RECURSIVE_LOOP) {
this.handleAftertructureModifiedEvent$S(cause);
try {
if (this.notifyStructuralChangeJSfunction != null ) {
this.notifyStructuralChangeJSfunction.apply(this, null);
}} catch (t) {
t.printStackTrace$();
}
}--this.afterStructureChangeEvent.stackLevel;
if (this.afterStructureChangeEvent.stackLevel <= 0) {
this.afterStructureChangeEvent.reset$();
}}});

Clazz.newMeth(C$, 'getPrePasteJSfunction$',  function () {
return this.prePasteJSfunction;
});

Clazz.newMeth(C$, 'setPrePasteJSfunction$jme_js_JSFunction',  function (prePasteJSfunction) {
this.prePasteJSfunction=prePasteJSfunction;
});

Clazz.newMeth(C$, 'topMenuHeight$',  function () {
return Long.$ival(Math.round$D(this.topMenuHeight$D(this.menuScale)));
});

Clazz.newMeth(C$, 'topMenuHeight$D',  function (scale) {
return this.isDepict$() ? 0.0 : (this.gui.menuCellSize * 2 + this.gui.menuCellBorder$()) * scale;
});

Clazz.newMeth(C$, 'leftMenuWidth$',  function () {
return Long.$ival(Math.round$D(this.leftMenuWidth$D(this.menuScale)));
});

Clazz.newMeth(C$, 'leftMenuWidth$D',  function (scale) {
if (this.gui == null ) System.out.println$S("???");
return this.isDepict$() ? 0.0 : (this.gui.menuCellSize * 1 + this.gui.menuCellBorder$()) * scale;
});

Clazz.newMeth(C$, 'infoAreaHeight$',  function () {
return Long.$ival(Math.round$D(this.infoAreaHeight$D(this.menuScale)));
});

Clazz.newMeth(C$, 'infoAreaHeight$D',  function (scale) {
return this.isDepict$() ? 0.0 : this.gui.menuCellSize * scale;
});

Clazz.newMeth(C$, 'rightBorder$',  function () {
return Long.$ival(Math.round$D(this.rightBorder$D(this.menuScale)));
});

Clazz.newMeth(C$, 'rightBorder$D',  function (scale) {
return this.isDepict$() ? 0.0 : (this.options.newLook ? 1.0 : 3.0) * scale;
});

Clazz.newMeth(C$, 'redrawMolecularAreaOnly$',  function () {
this.mustRedrawNothing$();
this.setMustRedrawMolecularArea$Z(true);
this.repaint$();
});

Clazz.newMeth(C$, 'setMustRedrawMolecularArea$Z',  function (b) {
return true;
});

Clazz.newMeth(C$, 'redrawMolecularAreaOnylForGettingSVG$',  function () {
var savedTouchedAtom=this.activeMol.touchedAtom;
var savedTouchedBond=this.activeMol.touchedBond;
this.activeMol.touchedAtom=0;
this.activeMol.touchedBond=0;
this.afterStructureChangeEvent.reset$();
this.redrawMolecularAreaOnly$();
this.activeMol.touchedAtom=savedTouchedAtom;
this.activeMol.touchedBond=savedTouchedBond;
});

Clazz.newMeth(C$, 'setAtomColors$I$S',  function (molIndex, atomAndColorCSV) {
if (molIndex == 0) {
var cumulAtomCount=0;
for (var i=1; i <= this.moleculePartsList.size$(); i++) {
var mol=this.selectMolIfValidOrShowError$I(i);
mol.setAtomColors$S$I(atomAndColorCSV, cumulAtomCount);
cumulAtomCount+=mol.nAtoms$();
}
} else {
var molToHighLight=this.selectMolIfValidOrShowError$I(molIndex);
if (molToHighLight == null ) {
return;
}molToHighLight.setAtomColors$S$I(atomAndColorCSV, 0);
}this.redrawMolecularAreaOnly$();
});

Clazz.newMeth(C$, 'getEnsembleAtom$I$I',  function (molIndex, atomIndex) {
if (molIndex < 0 || atomIndex < 0 ) {
$I$(34,"log$S",["Invalid index for getEnsembleAtom()"]);
return null;
}return Clazz.new_($I$(53,1).c$$jme_JMEmolList$I$I,[this.moleculePartsList, molIndex, atomIndex]);
});

Clazz.newMeth(C$, 'getMolecule$I',  function (molIndex) {
if (molIndex < 0 || molIndex >= this.moleculePartsList.size$() ) {
$I$(34,"log$S",["Invalid index for getMolecule()"]);
return null;
}return this.moleculePartsList.get$I(molIndex);
});

Clazz.newMeth(C$, 'activateMarkerColor$I',  function (colorIndex) {
if (colorIndex < 1 || colorIndex > this.colorManager.numberOfBackgroundColors$() ) {
this.alert$S("Invalid color index: " + colorIndex);
this.resetExtendAtomMark=true;
this.markFromKeyboardInput=false;
this.activeMarkerColorIndex=this.lastValidColorIndex;
this.clearInfo$();
this.repaint$();
} else {
this.lastValidColorIndex=this.activeMarkerColorIndex=colorIndex;
this.setAction$I(105);
this.options$S("marker");
this.gui.mustReDrawTopMenu=true;
this.repaint$();
}});

Clazz.newMeth(C$, 'setStarColor$S',  function (hexColor) {
this.alert$S("methods setStarColor and setMarkerColor have been replaced by activateMarkerColor");
});

Clazz.newMeth(C$, 'getAtomE$I',  function (atomE) {
return this.getEnsembleAtom$I$I(0, atomE).atom;
});

Clazz.newMeth(C$, 'totalNumberOfAtoms$',  function () {
return this.moleculePartsList.totalNumberOfAtoms$();
});

Clazz.newMeth(C$, 'replaceAtom$jme_core_AtomBondCommon$jme_core_Atom',  function (oldAtom, newAtom) {
for (var i=1; i <= this.moleculePartsList.size$(); i++) {
var mol=this.selectMolIfValidOrShowError$I(i);
for (var at=0; at < mol.atoms.length; at++) {
if (mol.atoms[at] === oldAtom ) {
mol.atoms[at]=newAtom;
return;
}}
}
});

Clazz.newMeth(C$, 'resetAtomColors$I',  function (molIndex) {
if (molIndex == 0) {
for (var i=1; i <= this.moleculePartsList.size$(); i++) {
this.resetAtomColors$I(i);
}
return;
} else {
var selectedMol=this.selectMolIfValidOrShowError$I(molIndex);
if (selectedMol == null ) {
return;
}$I$(54).resetChemicalObjectColors$jme_core_AtomBondCommonA(selectedMol.atoms);
}this.redrawMolecularAreaOnly$();
});

Clazz.newMeth(C$, 'resetBondColors$I',  function (molIndex) {
if (molIndex == 0) {
this.atomBgColors="";
for (var i=1; i <= this.moleculePartsList.size$(); i++) {
this.resetBondColors$I(i);
}
return;
} else {
var selectedMol=this.selectMolIfValidOrShowError$I(molIndex);
if (selectedMol == null ) {
return;
}$I$(54).resetChemicalObjectColors$jme_core_AtomBondCommonA(selectedMol.bonds);
}this.redrawMolecularAreaOnly$();
});

Clazz.newMeth(C$, 'totalNumberOfBonds$',  function () {
return this.moleculePartsList.totalNumberOfBonds$();
});

Clazz.newMeth(C$, 'getEnsembleBond$I$I',  function (molIndex, bondIndex) {
if (molIndex < 0 || bondIndex < 0 ) {
$I$(34,"log$S",["Invalid index for getEnsembleBond()"]);
return null;
}return Clazz.new_($I$(55,1).c$$jme_JMEmolList$I$I,[this.moleculePartsList, molIndex, bondIndex]);
});

Clazz.newMeth(C$, 'getBondE$I',  function (bondE) {
return this.getEnsembleBond$I$I(0, bondE).bond;
});

Clazz.newMeth(C$, 'replaceBond$jme_core_AtomBondCommon$jme_core_Bond',  function (oldBond, newBond) {
for (var mol, $mol = this.moleculePartsList.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
for (var b=0; b < mol.bonds.length; b++) {
if (mol.bonds[b] === oldBond ) {
mol.bonds[b]=newBond;
return;
}}
}
});

Clazz.newMeth(C$, 'setBondColors$I$S',  function (molIndex, bondAndColorCSV) {
if (molIndex == 0) {
var cumulBondCount=0;
for (var mol, $mol = this.moleculePartsList.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
mol.setBondColors$S$I(bondAndColorCSV, cumulBondCount);
cumulBondCount+=mol.nBonds$();
}
} else {
var molToHighLight=this.selectMolIfValidOrShowError$I(molIndex);
if (molToHighLight == null ) {
return;
}molToHighLight.setBondColors$S$I(bondAndColorCSV, 0);
}this.redrawMolecularAreaOnly$();
});

Clazz.newMeth(C$, 'getMultiSDFstack$',  function () {
return this.sdfStack.getMultiSDFstack$();
});

Clazz.newMeth(C$, 'selectMolIfValidOrShowError$I',  function (molIndex) {
this.clearInfo$();
if (molIndex < 1 || molIndex > this.moleculePartsList.size$() ) {
this.showError$S("invalid mol index: " + molIndex);
return null;
}return this.moleculePartsList.get$I(molIndex - 1);
});

Clazz.newMeth(C$, 'recordAfterStructureChangedEvent$S$I$I$I',  function (action, moleculePartIndex, atomIndex, bondIndex) {
this.recordAfterStructureChangedEvent$S$I$I$I$Z(action, moleculePartIndex, atomIndex, bondIndex, true);
});

Clazz.newMeth(C$, 'recordAfterStructureChangedEvent$S$I$I$I$Z',  function (action, moleculePartIndex, atomIndex, bondIndex, willSaveOnUndoStack) {
if (this.afterStructureChangeEvent != null ) {
this.updateReactionRoles$();
this.afterStructureChangeEvent.setAction$S(action).setAtomAndBondAndMol$jme_JMEmolList$I$I$I(this.moleculePartsList, atomIndex, bondIndex, moleculePartIndex);
}this.willPostSave$Z(willSaveOnUndoStack);
});

Clazz.newMeth(C$, 'recordMoleculePartEvent$S$I',  function (action, moleculePartIndex) {
this.recordAfterStructureChangedEvent$S$I$I$I(action, moleculePartIndex, 0, 0);
});

Clazz.newMeth(C$, 'recordAtomEvent$S',  function (action) {
this.recordAtomEvent$S$I(action, this.activeMol.touchedAtom);
});

Clazz.newMeth(C$, 'recordAtomEvent$S$I',  function (action, atom) {
this.recordAfterStructureChangedEvent$S$I$I$I(action, this.activeMolIndex$(), atom, 0);
});

Clazz.newMeth(C$, 'recordBondEvent$S',  function (action) {
this.recordBondEvent$S$I(action, this.activeMol.touchedBond);
});

Clazz.newMeth(C$, 'recordBondEvent$S$I',  function (action, bond) {
this.recordAfterStructureChangedEvent$S$I$I$I(action, this.activeMolIndex$(), 0, bond);
});

Clazz.newMeth(C$, 'recordAfterStructureChangedEvent$S',  function (action) {
this.recordAfterStructureChangedEvent$S$I$I$I(action, 0, 0, 0);
});

Clazz.newMeth(C$, 'isDepictMode$',  function () {
return this.isDepict$();
});

Clazz.newMeth(C$, 'isDepict$',  function () {
return this.depict;
});

Clazz.newMeth(C$, 'setDepict$Z',  function (depict) {
this.depict=depict;
});

Clazz.newMeth(C$, 'isEmpty$',  function () {
return this.moleculePartsList.isReallyEmpty$();
});

Clazz.newMeth(C$, 'propertyChange$java_beans_PropertyChangeEvent',  function (evt) {
var name=evt.getPropertyName$();
try {
switch (name) {
case "FileDropper.file":
this.readDroppedTextFile$S(evt.getNewValue$());
break;
case "FileDropper.inline":
this.readDroppedData$O(evt.getNewValue$());
break;
default:
break;
}
} catch (t) {
System.err.println$S("JME couldn't load data for drop " + name);
}
});

Clazz.newMeth(C$, 'readDroppedData$O',  function (stringOrBytes) {
Clazz.new_($I$(28,1).c$$O,[stringOrBytes]).readMoleculeData$jme_JME$Z$jme_js_AsyncCallback$Z$Z(this, false, null, true, true);
});

Clazz.newMeth(C$, 'readSmiles$S',  function (data) {
try {
this.readMolFile$S(C$.getOclAdapter$().SMILEStoMOL$S(data));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'readDroppedTextFile$S',  function (fileName) {
var bos=Clazz.new_($I$(56,1));
var fis=null;
try {
fis=(fileName.indexOf$S("://") >= 0 ? Clazz.new_($I$(57,1).c$$S,[fileName]).openStream$() : Clazz.new_($I$(58,1).c$$S,[fileName]));
var bytes=Clazz.array(Byte.TYPE, [4096]);
var n;
while ((n=fis.read$BA(bytes)) > 0){
bos.write$BA$I$I(bytes, 0, n);
}
fis.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("JME error reading file " + fileName);
} else {
throw e;
}
}
this.readDroppedData$O(bos.toByteArray$());
});

Clazz.newMeth(C$, 'options$S',  function (parameters) {
this.options.set$S(parameters);
this.mustRedrawEverything$();
this.repaint$();
});

Clazz.newMeth(C$, 'handleAdditionalOptions$S',  function (options) {
});

Clazz.newMeth(C$, 'dragGestureRecognized$java_awt_dnd_DragGestureEvent',  function (dge) {
try {
var e=dge.getTriggerEvent$();
if (e.getID$() != 501) return;
var x=e.getX$();
var y=e.getY$();
if (!this.gui.dragAndDropIcon.contains$I$I(x, y)) return;
var cursor=null;
System.out.println$I(dge.getDragAction$());
if (dge.getDragAction$() == 1) {
cursor=$I$(20).DefaultCopyDrop;
dge.startDrag$java_awt_Cursor$java_awt_datatransfer_Transferable(cursor, ((P$.JME$4||
(function(){/*a*/var C$=Clazz.newClass(P$, "JME$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.datatransfer.Transferable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getTransferDataFlavors$',  function () {
return Clazz.array($I$(59), -1, [$I$(59).stringFlavor]);
});

Clazz.newMeth(C$, 'isDataFlavorSupported$java_awt_datatransfer_DataFlavor',  function (flavor) {
return flavor === $I$(59).stringFlavor ;
});

Clazz.newMeth(C$, 'getTransferData$java_awt_datatransfer_DataFlavor',  function (flavor) {
if (flavor === $I$(59).stringFlavor ) {
return this.b$['jme.JME'].molFile$.apply(this.b$['jme.JME'], []);
}return null;
});
})()
), Clazz.new_(P$.JME$4.$init$,[this, null])));
}} catch (t) {
System.out.println$S("hmm");
}
});

Clazz.newMeth(C$, 'main$SA',  function (args) {
var frame=Clazz.new_($I$(60,1).c$$S,["JME Molecular Editor"]);
frame.addWindowListener$java_awt_event_WindowListener(((P$.JME$5||
(function(){/*a*/var C$=Clazz.newClass(P$, "JME$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.WindowAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'windowClosing$java_awt_event_WindowEvent',  function (evt) {
System.exit$I(0);
});
})()
), Clazz.new_($I$(61,1),[this, null],P$.JME$5)));
frame.setBounds$I$I$I$I(300, 200, 432, 384);
var jme=Clazz.new_(C$.c$$javax_swing_JFrame$Z$SA,[frame, false, args]);
$I$(46,"invokeLater$Runnable",[((P$.JME$lambda11||
(function(){/*m*/var C$=Clazz.newClass(P$, "JME$lambda11", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'run$',  function () /*block*/{
this.$finals$.frame.setVisible$Z.apply(this.$finals$.frame, [true]);
this.$finals$.jme.start$SA.apply(this.$finals$.jme, [this.$finals$.args]);
});
})()
), Clazz.new_(P$.JME$lambda11.$init$,[this, {args:args,jme:jme,frame:frame}]))]);

return jme;
}, 1);

Clazz.newMeth(C$, 'doDrawChiralText$',  function () {
return (this.activeMol != null  && this.moleculePartsList.hasOneMoleculeWithChiralFlag$() );
});

Clazz.newMeth(C$, 'startKeyboardAction$',  function () {
this.structureChangedByAction=false;
});

Clazz.newMeth(C$, 'endKeyboardAction$',  function () {
p$2.postAction$Z.apply(this, [this.structureChangedByAction]);
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
C$.copyright=Clazz.array(String, -1, ["Copyright (c) 2014-2023, Peter Ertl, Bruno Bienfait, and Robert Hanson.", "All rights reserved."]);
C$.parserImpl="jme.ocl.OclAdapter";
C$.isStandAloneApplication=false;
C$.color=Clazz.array($I$(4), [43]);
C$.isJavaScript=System.getProperty$S("java.vm.name").equals$O("JavaScript");
{
if (C$.isJavaScript) {
C$.programName="JSME";
C$.precision=30;
} else {
C$.programName="JME";
C$.precision=1.0;
}};
C$.changeAtomChargeAction="Change atom charge";
C$.changeAtomMapAction="Change atom map";
C$.changeAtomMarkAction="Change atom mark value";
{
C$.atomicData$();
};
};
;
(function(){/*i*/var C$=Clazz.newInterface(P$.JME, "HTML5Applet", function(){
});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.JME, "SavedState", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.moleculePartsList=null;
this.activeMol=null;
this.depictScale=1.0;
},1);

C$.$fields$=[['Z',['reaction','multipart'],'D',['depictScale'],'I',['lastAction'],'O',['moleculePartsList','jme.JMEmolList','activeMol','jme.JMEmol']]]

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.JME, "Touched", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['distance'],'I',['atomIndex','bondIndex'],'O',['mol','jme.JMEmol']]]

Clazz.newMeth(C$, 'equals$jme_JME_Touched',  function (other) {
return this.mol === other.mol  && this.atomIndex == other.atomIndex  && this.bondIndex == other.bondIndex ;
});

Clazz.newMeth(C$, 'reset$',  function () {
this.mol=null;
this.atomIndex=0;
this.bondIndex=0;
});

Clazz.newMeth(C$, 'initMyselfWith$jme_JME_Touched',  function (other) {
this.mol=other.mol;
this.atomIndex=other.atomIndex;
this.bondIndex=other.bondIndex;
});

Clazz.newMeth(C$, 'isTouched$',  function () {
return this.mol != null  && (this.atomIndex > 0 || this.bondIndex > 0 ) ;
});

Clazz.newMeth(C$, 'toString',  function () {
return ("[TOUCH " + this.atomIndex + " " + this.bondIndex + "]" );
});

Clazz.newMeth(C$);
})()
;
(function(){/*e*/var C$=Clazz.newClass(P$.JME, "CopyPasteAction", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getFromName$S',  function (name) {
for (var item, $item = 0, $$item = C$.values$(); $item<$$item.length&&((item=($$item[$item])),1);$item++) if (item.toString().equalsIgnoreCase$S(name)) return item;

return null;
}, 1);

Clazz.newMeth(C$, 'getFormat$',  function () {
return $I$(1,"valueOf$S",[this.toString()]);
});

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "JME", 0, []);
Clazz.newEnumConst($vals, C$.c$, "SMILES", 1, []);
Clazz.newEnumConst($vals, C$.c$, "MOL", 2, []);
Clazz.newEnumConst($vals, C$.c$, "MOL_V3000", 3, []);
Clazz.newEnumConst($vals, C$.c$, "FIXED_H_INCHI", 4, []);
Clazz.newEnumConst($vals, C$.c$, "FIXED_H_INCHI_KEY", 5, []);
Clazz.newEnumConst($vals, C$.c$, "STANDARD_INCHI", 6, []);
Clazz.newEnumConst($vals, C$.c$, "STANDARD_INCHI_KEY", 7, []);
Clazz.newEnumConst($vals, C$.c$, "INCHI_AUXINFO", 8, []);
Clazz.newEnumConst($vals, C$.c$, "INCHI_MODEL_JSON", 9, []);
Clazz.newEnumConst($vals, C$.c$, "OCLCODE", 10, []);
Clazz.newEnumConst($vals, C$.c$, "SVG", 11, []);
Clazz.newEnumConst($vals, C$.c$, "RAW_STRING_GRAPHIC", 12, []);
Clazz.newEnumConst($vals, C$.c$, "SEARCH_INCHI_KEY", 13, []);
Clazz.newEnumConst($vals, C$.c$, "PASTE", 14, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.JME, "StringWrapper", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['innerString']]]

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.JME, "Options", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.addNewPart=false;
this.allowGUIzooming=true;
this.allowZooming=true;
this.autonumber=false;
this.contextMenuEnabledOption=true;
this.depictActionEnabled=false;
this.depictBorder=false;
this.exportInchi=true;
this.exportInchiAuxInfo=true;
this.exportInchiKey=true;
this.exportRXNmergeOption=false;
this.exportSVG=true;
this.fgMenuOption=true;
this.fullScreenIconOption=false;
this.markerMenu=false;
this.markOnly1=false;
this.newLook=false;
this.paste=true;
this.polarnitro=false;
this.pseudoMark=false;
this.rButton=false;
this.searchInchiKey=true;
this.showAtomMoveJButton=true;
this.showDragAndDropIconInDepictMode=true;
this.showFullScreenIconInDepictMode=true;
this.starAtomOnly=false;
this.starBondOnly=false;
this.starNothing=false;
this.stereo=true;
this.toggleDepictEdit=false;
this.useOclIdCode=false;
this.useOpenChemLib=true;
this.boldAtomLabels=true;
this.multipart=true;
this.query=false;
this.reaction=false;
this.xButton=true;
this.jmeString=null;
this.molString=null;
this.genericChemicalInputFromInit=null;
this.atomBGcircleRelativeSize=0.8;
this.bondBGrectRelativeSize=0.5;
this.runsmi=true;
},1);

C$.$fields$=[['Z',['addNewPart','allowGUIzooming','allowZooming','autonumber','contextMenuEnabledOption','depictActionEnabled','depictBorder','exportInchi','exportInchiAuxInfo','exportInchiKey','exportRXNmergeOption','exportSVG','fgMenuOption','fullScreenIconOption','markerMenu','markOnly1','newLook','paste','polarnitro','pseudoMark','rButton','searchInchiKey','showAtomMoveJButton','showDragAndDropIconInDepictMode','showFullScreenIconInDepictMode','starAtomOnly','starBondOnly','starNothing','stereo','toggleDepictEdit','useOclIdCode','useOpenChemLib','boldAtomLabels','multipart','query','reaction','xButton','runsmi'],'D',['atomBGcircleRelativeSize','bondBGrectRelativeSize'],'S',['jmeString','molString','genericChemicalInputFromInit','options'],'O',['args','String[]']]]

Clazz.newMeth(C$, 'parseOption$S',  function (option) {
return p$1.parseOption$S$S.apply(this, [option, "no"]);
}, p$1);

Clazz.newMeth(C$, 'registerJS$jme_JME',  function (jme) {
var a=this.getApplet$Z(false);
if (a == null ) return;
{
}});

Clazz.newMeth(C$, 'getAppletOptions$jme_JME$SA',  function (jme, args) {
try {
this.args=args;
var options=this.getParameter$S("options");
if (options != null ) this.set$S(options);
var p;
if ((p=this.getParameter$S("jme")) != null ) this.jmeString=p;
if ((p=this.getParameter$S("mol")) != null ) this.molString=p;
if ((p=this.getParameter$S("chem")) != null ) this.genericChemicalInputFromInit=p;
if ((p=this.getParameter$S("smiles")) != null ) this.genericChemicalInputFromInit=p;
if ((p=this.getParameter$S("text")) != null ) this.b$['jme.JME'].molText=p;
this.b$['jme.JME'].atomBgColors=this.getParameter$S("atombg");
if ((p=this.getParameter$S("depictbg")) != null ) this.b$['jme.JME'].canvasBg=$I$(2).parseHexColor$S(p);
if ((p=this.getParameter$S("guicolor")) != null ) this.b$['jme.JME'].setUserInterfaceBackgroundColor$S.apply(this.b$['jme.JME'], [p]);
if ((p=this.getParameter$S("guiAtomColor")) != null ) this.b$['jme.JME'].setLeftMenuAtomColor$S.apply(this.b$['jme.JME'], [p]);
if ((p=this.getParameter$S("atombgsize")) != null ) {
var d=(Double.valueOf$S(p)).valueOf();
this.atomBGcircleRelativeSize=(d < 0  ? 0.8 : d);
}if ((p=this.getParameter$S("bondbgsize")) != null ) {
var d=(Double.valueOf$S(p)).valueOf();
this.bondBGrectRelativeSize=(d < 0  ? 0.5 : d);
}if (this.b$['jme.JME'].showAtomNumbers) this.b$['jme.JME'].showAtomNumbers$.apply(this.b$['jme.JME'], []);
var f=this.getParameter$S("notify_structural_change_js_function");
if (f != null ) this.b$['jme.JME'].setNotifyStructuralChangeJSfunction$jme_js_JSFunction.apply(this.b$['jme.JME'], [f]);
this.b$['jme.JME'].handleAdditionalParameters$.apply(this.b$['jme.JME'], []);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("JME:  parameters error");
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'getApplet$Z',  function (asJApplet) {
var g=$I$(3).currentThread$().getThreadGroup$();
{
var a = g.getHtmlApplet$(); return (asJApplet ? a._applet : a);
}
});

Clazz.newMeth(C$, 'callback$O$O',  function (f, args) {
var jme=this.b$['jme.JME'];

f.apply(jme, args);
});

Clazz.newMeth(C$, 'getParameter$S',  function (p) {
var applet=this.getApplet$Z(true);
if (applet == null  && this.args != null  ) {
for (var i=1; i < this.args.length; i+=2) {
if (p.equals$O(this.args[i - 1])) {
return this.args[i];
}}
return null;
}return (applet == null  ? null : applet.getParameter$S(p));
});

Clazz.newMeth(C$, 'parseOption$S$S',  function (option, negativePrefix) {
var pos=(this.options.indexOf$S(";" + option + ";" ) >= 0);
var neg=(this.options.indexOf$S(";" + negativePrefix + option ) >= 0);
if (pos && neg ) {
this.b$['jme.JME'].log$S.apply(this.b$['jme.JME'], ["check option " + option]);
return null;
}return (pos ? Boolean.TRUE : neg ? Boolean.FALSE : null);
}, p$1);

Clazz.newMeth(C$, 'parseSynonymOptions$S$SA',  function (parameters, options) {
for (var eachOption, $eachOption = 0, $$eachOption = options; $eachOption<$$eachOption.length&&((eachOption=($$eachOption[$eachOption])),1);$eachOption++) {
var found=p$1.parseOption$S.apply(this, [eachOption]);
if (found != null ) {
return found;
}}
return null;
}, p$1);

Clazz.newMeth(C$, 'set$S',  function (parameters) {
var o;
var p0=parameters;
parameters=parameters.replaceAll$S$S("[^_0-9a-zA-Z]", ";");
var one=(p0.equals$O(parameters));
this.options=";" + parameters.toLowerCase$() + ";" ;
if ((o=p$1.parseOption$S.apply(this, ["depict"])) != null ) {
p$1.setDepictOption$Z.apply(this, [o.booleanValue$()]);
if (one) return;
}if ((o=p$1.parseSynonymOptions$S$SA.apply(this, [parameters, Clazz.array(String, -1, ["star", "marker"])])) != null ) {
if (this.b$['jme.JME'].params.mark != (o).$c() ) {
this.b$['jme.JME'].params.number=this.b$['jme.JME'].params.mark=(o).valueOf();
this.b$['jme.JME'].mustRedrawEverything$.apply(this.b$['jme.JME'], []);
if ((!((o).$c()))) this.markOnly1=false;
}if (one) return;
}if ((o=p$1.parseOption$S.apply(this, ["headless"])) != null ) {
this.b$['jme.JME'].headless=true;
}if ((o=p$1.parseOption$S.apply(this, ["boldatomlabels"])) != null ) {
this.boldAtomLabels=(o).valueOf();
}if ((o=p$1.parseOption$S.apply(this, ["rbutton"])) != null ) {
this.rButton=(o).valueOf();
this.b$['jme.JME'].gui.mustReDrawLeftMenu=true;
}if ((o=p$1.parseOption$S.apply(this, ["hydrogens"])) != null ) {
if (this.b$['jme.JME'].params.hydrogenParams.showHs != (o).$c() ) {
this.b$['jme.JME'].params.hydrogenParams.showHs=(o).valueOf();
this.b$['jme.JME'].mustReDrawMolecularArea$.apply(this.b$['jme.JME'], []);
}}if ((o=p$1.parseOption$S.apply(this, ["valencestate"])) != null ) {
if (this.b$['jme.JME'].params.computeValenceState != (o).$c() ) {
this.b$['jme.JME'].params.computeValenceState=(o).valueOf();
this.b$['jme.JME'].mustReDrawMolecularArea$.apply(this.b$['jme.JME'], []);
}}if (parameters.indexOf$S("keephs") > -1) {
this.b$['jme.JME'].params.hydrogenParams.removeHs=false;
}if (parameters.indexOf$S("removehs") > -1) {
this.b$['jme.JME'].params.hydrogenParams.removeHs=true;
this.b$['jme.JME'].params.hydrogenParams.removeOnlyCHs=false;
}if (parameters.indexOf$S("removehsc") > -1) {
this.b$['jme.JME'].setRemoveHsC$.apply(this.b$['jme.JME'], []);
}if ((o=p$1.parseOption$S.apply(this, ["query"])) != null ) if (this.query != (o).$c() ) {
this.query=(o).valueOf();
}if ((o=p$1.parseOption$S.apply(this, ["reaction"])) != null ) {
if (this.reaction != (o).$c() ) {
this.b$['jme.JME'].setMustRedrawMolecularArea$Z.apply(this.b$['jme.JME'], [true]);
}if (!this.reaction) {
this.b$['jme.JME'].reactionArrow.hasBeenPlaced=false;
}this.reaction=(o).valueOf();
}if ((o=p$1.parseOption$S.apply(this, ["polarnitro"])) != null ) {
this.polarnitro=this.b$['jme.JME'].params.smilesParams.polarnitro=(o).valueOf();
}if ((o=p$1.parseOption$S.apply(this, ["smarts"])) != null  || (o=p$1.parseOption$S.apply(this, ["search"])) != null  ) {
this.b$['jme.JME'].params.smilesParams.smarts=(o).valueOf();
}if ((o=p$1.parseOption$S.apply(this, ["stereo"])) != null ) this.stereo=this.b$['jme.JME'].params.smilesParams.stereo=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["autoez"])) != null ) this.b$['jme.JME'].params.smilesParams.autoez=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["smilesaromatic"])) != null ) this.b$['jme.JME'].params.smilesParams.allowaromatic=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["canonize"])) != null ) this.b$['jme.JME'].params.smilesParams.canonize=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["multipart"])) != null ) if (this.multipart != (o).$c() ) {
this.multipart=(o).valueOf();
}if ((o=Boolean.valueOf$Z(p$1.parseOption$S.apply(this, ["autonumber"]) != null )).valueOf()) {
if (this.autonumber != (o).$c() ) {
this.autonumber=(o).valueOf();
if (this.autonumber) {
p$1.setNumber$Z.apply(this, [true]);
}}}if ((o=Boolean.valueOf$Z(p$1.parseOption$S.apply(this, ["number"]) != null )).valueOf()) {
p$1.setNumber$Z.apply(this, [o.booleanValue$()]);
}if ((o=Boolean.valueOf$Z(p$1.parseOption$S.apply(this, ["showatommapnumberwithbackgroundcolor"]) != null )).valueOf()) {
this.b$['jme.JME'].params.showAtomMapNumberWithBackgroundColor=(o).valueOf();
}if ((o=p$1.parseOption$S.apply(this, ["newlook"])) != null ) {
this.newLook=(o).valueOf();
this.b$['jme.JME'].resetAllGraphics$.apply(this.b$['jme.JME'], []);
}if ((o=p$1.parseOption$S.apply(this, ["oldlook"])) != null ) {
this.newLook=(!((o).$c()));
this.b$['jme.JME'].resetAllGraphics$.apply(this.b$['jme.JME'], []);
}if ((o=p$1.parseSynonymOptions$S$SA.apply(this, [parameters, Clazz.array(String, -1, ["star1", "marker1"])])) != null ) {
if (this.markOnly1 != (o).$c() ) {
this.markOnly1=(o).valueOf();
if ((o).valueOf()) {
this.b$['jme.JME'].params.number=this.b$['jme.JME'].params.mark=(o).valueOf();
} else {
}this.b$['jme.JME'].mustRedrawEverything$.apply(this.b$['jme.JME'], []);
}}if ((o=p$1.parseOption$S.apply(this, ["markermenu"])) != null ) {
this.markerMenu=(o).valueOf();
}if ((o=p$1.parseOption$S.apply(this, ["pseudomark"])) != null ) {
this.pseudoMark=(o).valueOf();
}if ((o=p$1.parseOption$S.apply(this, ["markatomonly"])) != null ) {
this.starAtomOnly=(o).valueOf();
if (this.starAtomOnly) {
this.starBondOnly=false;
if (this.starNothing) {
}this.starNothing=false;
}}if ((o=p$1.parseOption$S.apply(this, ["markbondonly"])) != null ) {
this.starBondOnly=(o).valueOf();
if (this.starBondOnly) {
this.starAtomOnly=false;
if (this.starNothing) {
}this.starNothing=false;
}}if ((o=p$1.parseOption$S.apply(this, ["marknothing"])) != null ) {
if (this.starNothing != (o).$c() ) {
this.starNothing=(o).valueOf();
}}if ((o=p$1.parseOption$S.apply(this, ["fgmenu"])) != null ) {
this.fgMenuOption=(o).valueOf();
this.b$['jme.JME'].gui.mustReDrawTopMenu=true;
}if ((o=p$1.parseOption$S.apply(this, ["toggle"])) != null ) this.toggleDepictEdit=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["depictaction"])) != null ) {
this.depictActionEnabled=(o).valueOf();
if (this.depictActionEnabled) {
p$1.setDepictOption$Z.apply(this, [true]);
}}if ((o=p$1.parseOption$S.apply(this, ["showdraganddropoiconindepictmode"])) != null ) this.showDragAndDropIconInDepictMode=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["showdraganddropsymbolindepictmode"])) != null ) this.showDragAndDropIconInDepictMode=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["addnewpart"])) != null ) this.addNewPart=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["exportinchi"])) != null ) this.exportInchi=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["exportinchikey"])) != null ) this.exportInchiKey=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["exportinchiauxinfo"])) != null ) this.exportInchiAuxInfo=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["searchinchikey"])) != null ) this.searchInchiKey=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["exportsvg"])) != null ) this.exportSVG=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["exportrxnmerge"])) != null ) this.exportRXNmergeOption=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["contextmenu"])) != null ) this.contextMenuEnabledOption=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["fullscreenicon"])) != null ) this.fullScreenIconOption=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["showfullscreeniconindepictmode"])) != null ) this.showFullScreenIconInDepictMode=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["useoclidcode"])) != null ) this.useOclIdCode=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["xbutton"])) != null ) {
if (this.xButton != (o).$c() ) {
this.xButton=(o).valueOf();
}}if ((o=p$1.parseOption$S.apply(this, ["paste"])) != null ) if (this.paste != (o).$c() ) {
this.paste=(o).valueOf();
}if ((o=p$1.parseOption$S.apply(this, ["border"])) != null ) if (this.depictBorder != (o).$c() ) {
this.depictBorder=(o).valueOf();
this.b$['jme.JME'].mustRedrawEverything$.apply(this.b$['jme.JME'], []);
}if (parameters.indexOf$S("nocenter") > -1) this.b$['jme.JME'].nocenter=true;
if (parameters.indexOf$S("jmeh") > -1) this.b$['jme.JME'].jmeh=true;
if (parameters.indexOf$S("showan") > -1) this.b$['jme.JME'].showAtomNumbers=true;
if ((o=p$1.parseOption$S.apply(this, ["atommovebutton"])) != null ) this.showAtomMoveJButton=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["useopenchemlib"])) != null ) this.useOpenChemLib=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["zoom"])) != null ) this.allowGUIzooming=this.allowZooming=(o).valueOf();
if ((o=p$1.parseOption$S.apply(this, ["zoomgui"])) != null ) this.allowGUIzooming=(o).$c() && this.allowZooming ;
if (this.reaction) {
this.autonumber=true;
this.multipart=true;
}if (!this.b$['jme.JME'].isDepict$.apply(this.b$['jme.JME'], [])) this.depictBorder=false;
this.b$['jme.JME'].handleAdditionalOptions$S.apply(this.b$['jme.JME'], [this.options]);
this.b$['jme.JME'].resetJPopupMenu$.apply(this.b$['jme.JME'], []);
if (this.b$['jme.JME'].action == 105 && (this.b$['jme.JME'].params.mark == false  || this.starNothing ) ) {
this.b$['jme.JME'].action=202;
}});

Clazz.newMeth(C$, 'setDepictOption$Z',  function (tf) {
var depicting=this.b$['jme.JME'].isDepict$.apply(this.b$['jme.JME'], []);
if (tf != depicting ) {
if (depicting) {
this.b$['jme.JME'].setDepict$Z.apply(this.b$['jme.JME'], [false]);
this.b$['jme.JME'].resetMolecularAreaScale$.apply(this.b$['jme.JME'], []);
this.b$['jme.JME'].gui.menuCellSize=24.0;
this.paste=true;
this.b$['jme.JME'].resetAllGraphics$.apply(this.b$['jme.JME'], []);
} else {
this.b$['jme.JME'].setDepict$Z.apply(this.b$['jme.JME'], [true]);
this.b$['jme.JME'].gui.menuCellSize=0;
this.b$['jme.JME'].molecularAreaImage=null;
this.paste=false;
if (this.b$['jme.JME'].moleculePartsList.size$() > 0) {
this.b$['jme.JME'].molecularAreaScalePixelsPerCoord=this.b$['jme.JME'].scaleAndCenterForDepictMode$jme_canvas_Graphical2DObjectGroup.apply(this.b$['jme.JME'], [this.b$['jme.JME'].graphicalObjectList$.apply(this.b$['jme.JME'], [])]);
}this.b$['jme.JME'].resetAllGraphics$.apply(this.b$['jme.JME'], []);
}}}, p$1);

Clazz.newMeth(C$, 'setNumber$Z',  function (tf) {
if (this.b$['jme.JME'].params.number != tf ) this.b$['jme.JME'].gui.mustReDrawTopMenu=true;
this.b$['jme.JME'].params.number=tf;
if (!this.b$['jme.JME'].params.number) this.autonumber=false;
 else {
if (this.b$['jme.JME'].params.mark) this.b$['jme.JME'].mustRedrawEverything$.apply(this.b$['jme.JME'], []);
this.b$['jme.JME'].params.mark=false;
}}, p$1);

Clazz.newMeth(C$, 'getInfo$S',  function (param) {
var html5applet=this.getApplet$Z(false);
{
return (param == null ? html5applet.__Info : html5applet.__Info[param]);
}
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:53 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
