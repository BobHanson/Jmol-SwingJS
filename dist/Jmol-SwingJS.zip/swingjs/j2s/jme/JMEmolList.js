(function(){var P$=Clazz.newPackage("jme"),I$=[[0,'jme.JME','jme.util.JMEUtil',['jme.JMEmolList','.EnsembleAtom'],['jme.JMEmolList','.EnsembleBond'],'jme.JMEmol','jme.util.Box',['java.awt.geom.Rectangle2D','.Double'],['jme.util.Box','.Axis'],'jme.canvas.Graphical2DObjectGroup','jme.canvas.Graphical2DObject']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JMEmolList", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'java.util.ArrayList');
C$.$classes$=[['EnsembleAtom',9],['EnsembleBond',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.isReaction=false;
this.errorMsg=null;
this.warnng=null;
this.error=null;
},1);

C$.$fields$=[['Z',['isReaction'],'S',['errorMsg','warnng'],'O',['error','Exception']]]

Clazz.newMeth(C$, 'removeAll$',  function () {
C$.superclazz.prototype.clear$.apply(this, []);
});

Clazz.newMeth(C$, 'getErrorMessage$',  function () {
if (this.errorMsg != null ) return this.errorMsg;
if (this.error != null ) return $I$(1).makeErrorMessage$Exception(this.error);
return null;
});

Clazz.newMeth(C$, 'setErrorMsg$S',  function (msg) {
this.errorMsg=msg;
this.removeAll$();
return this;
});

Clazz.newMeth(C$, 'isReaction$',  function () {
return this.isReaction;
});

Clazz.newMeth(C$, 'getEnsembleAtom$I$I',  function (mol, atom) {
if (mol < 0 || atom < 0 ) {
$I$(2,"log$S",["Invalid index for getEnsembleAtom()"]);
return null;
}return Clazz.new_($I$(3,1).c$$jme_JMEmolList$I$I,[this, mol, atom]);
});

Clazz.newMeth(C$, 'getEnsembleBond$I$I',  function (mol, bond) {
if (mol < 0 || bond < 0 ) {
$I$(2,"log$S",["Invalid index for getEnsembleBond()"]);
return null;
}return Clazz.new_($I$(4,1).c$$jme_JMEmolList$I$I,[this, mol, bond]);
});

Clazz.newMeth(C$, 'computeAtomEnsembleIndex$I$I',  function (mol, atom) {
return this.getEnsembleAtom$I$I(mol, atom).atomEnsembleIndex;
});

Clazz.newMeth(C$, 'computeBondEnsembleIndex$I$I',  function (mol, bond) {
return this.getEnsembleBond$I$I(mol, bond).bondEnsembleIndex;
});

Clazz.newMeth(C$, 'reComputeAtomLabels$',  function () {
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
mol.computeAtomLabels$();
}
});

Clazz.newMeth(C$, 'splitFragments$Z',  function (removeEmpty) {
var fragmentList=Clazz.new_(C$);
var changed=false;
for (var each, $each = this.iterator$(); $each.hasNext$()&&((each=($each.next$())),1);) {
var nparts=each.computeMultiPartIndices$();
var jme=each.jme;
if (nparts == 1) {
fragmentList.add$O(each);
} else if (nparts == 0) {
if (removeEmpty) {
changed=true;
} else fragmentList.add$O(each);
} else {
for (var p=1; p <= nparts; p++) {
var newFragment=Clazz.new_($I$(5,1).c$$jme_JME$jme_JMEmol$I$O,[jme, each, p, null]);
newFragment.setReactionRole$I(each.getReactionRole$());
fragmentList.add$O(newFragment);
}
changed=true;
}}
if (changed) {
this.removeAll$();
for (var each, $each = fragmentList.iterator$(); $each.hasNext$()&&((each=($each.next$())),1);) {
this.add$O(each);
}
}return changed;
});

Clazz.newMeth(C$, 'reactionParts$I',  function (reactionRole) {
return this.reactionParts$I$Z(reactionRole, false);
});

Clazz.newMeth(C$, 'reactionParts$I$Z',  function (reactionRole, mergeMolecules) {
var reactionParts=Clazz.new_(C$);
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
if (mol.nAtoms$() > 0 && mol.getReactionRole$() == reactionRole ) reactionParts.add$O(mol);
}
if (mergeMolecules && reactionParts.size$() > 1 ) {
var merged=$I$(5).mergeMols$java_util_ArrayList(reactionParts);
merged.setReactionRole$I(reactionRole);
reactionParts=Clazz.new_(C$);
reactionParts.add$O(merged);
}return reactionParts;
});

Clazz.newMeth(C$, 'last$',  function () {
return this.get$I(this.size$() - 1);
});

Clazz.newMeth(C$, 'first$',  function () {
return this.get$I(0);
});

Clazz.newMeth(C$, 'overlap$',  function () {
var closeContactDist=2.5;
var results=Clazz.array(Integer.TYPE, [this.size$() * (this.size$() - 1)]);
var rpos=0;
for (var m1=0; m1 < this.size$() - 1; m1++) {
var mol1=this.get$I(m1);
for (var m2=m1 + 1; m2 < this.size$() - 1; m1++) {
var mol2=this.get$I(m1);
if (mol1.hasCloseContactWith$jme_core_JMECore$D(mol2, closeContactDist)) {
results[rpos++]=m1;
results[rpos++]=m2;
}}
}
return results;
});

Clazz.newMeth(C$, 'hasCloseContact$D',  function (closeContactDist) {
for (var m1=0; m1 < this.size$() - 1; m1++) {
var mol1=this.get$I(m1);
for (var m2=m1 + 1; m2 < this.size$() - 1; m2++) {
var mol2=this.get$I(m2);
if (mol1.hasCloseContactWith$jme_core_JMECore$D(mol2, closeContactDist)) {
return true;
}}
}
return false;
});

Clazz.newMeth(C$, 'removeEmptyMolecules$',  function () {
var emptyList=Clazz.new_(C$);
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
if (mol.nAtoms$() == 0) {
emptyList.add$O(mol);
}}
for (var mol, $mol = emptyList.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
this.remove$O(mol);
}
return emptyList.size$() > 0;
});

Clazz.newMeth(C$, 'computeCoordinate2DboundingBox$',  function () {
var boundingBox=null;
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
var moleculeBox=mol.computeCoordinate2DboundingBox$();
if (moleculeBox != null ) boundingBox=(boundingBox == null  ? moleculeBox : $I$(6).createUnion$java_awt_geom_Rectangle2D_Double$java_awt_geom_Rectangle2D_Double$java_awt_geom_Rectangle2D_Double(boundingBox, moleculeBox, boundingBox));
}
return boundingBox;
});

Clazz.newMeth(C$, 'computeBoundingBoxWithAtomLabels$',  function () {
var boundingBox=null;
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
boundingBox=mol.computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(boundingBox);
}
return boundingBox;
});

Clazz.newMeth(C$, 'safeComputeBoundingBoxWithAtomLabels$D$D',  function (minWidth, minHeight) {
var boundingBox=this.computeBoundingBoxWithAtomLabels$();
if (boundingBox == null ) {
boundingBox=Clazz.new_($I$(7,1));
}boundingBox.width=Math.max(boundingBox.width, minWidth);
boundingBox.height=Math.max(boundingBox.height, minHeight);
return boundingBox;
});

Clazz.newMeth(C$, 'distributeAndCenterPositionsHorizontally$D',  function (margin) {
this.distributePositions$jme_util_Box_Axis$D($I$(8).X, margin);
this.alignCenter$jme_util_Box_Axis($I$(8).Y);
});

Clazz.newMeth(C$, 'distributeAndCenterPositionsVertically$D',  function (margin) {
this.distributePositions$jme_util_Box_Axis$D($I$(8).Y, margin);
this.alignCenter$jme_util_Box_Axis($I$(8).X);
});

Clazz.newMeth(C$, 'distributePositions$jme_util_Box_Axis$D',  function (xOrY, margin) {
var distributer=Clazz.new_($I$(9,1));
distributer.addAll$java_util_ArrayList(this);
distributer.distributePositions$jme_util_Box_Axis$D(xOrY, margin);
});

Clazz.newMeth(C$, 'alignCenterY$',  function () {
this.alignCenter$jme_util_Box_Axis($I$(8).Y);
});

Clazz.newMeth(C$, 'alignCenter$jme_util_Box_Axis',  function (xOrY) {
var aligner=Clazz.new_($I$(9,1).c$$java_util_ArrayList,[this]);
aligner.alignCenter$jme_util_Box_Axis(xOrY);
});

Clazz.newMeth(C$, 'replace$jme_JMEmol$jme_JMEmol',  function (mol, newMol) {
var index=this.indexOf$O(mol);
if (index >= 0) this.set$I$O(index, newMol);
return index;
});

Clazz.newMeth(C$, 'jmeIndex$jme_JMEmol',  function (mol) {
return this.indexOf$O(mol) + 1;
});

Clazz.newMeth(C$, 'findMaxAtomMap$I',  function (reactionRole) {
var max=-2147483648;
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
if (reactionRole == -1 || mol.getReactionRole$() == reactionRole ) {
var m=mol.getMaxAtomMap$();
if (m > max) max=m;
}}
return max;
});

Clazz.newMeth(C$, 'findMaxAtomMap$',  function () {
return this.findMaxAtomMap$I(-1);
});

Clazz.newMeth(C$, 'hasMarkedAtom$',  function () {
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
if (mol.hasMarkedAtom$()) {
return true;
}}
return false;
});

Clazz.newMeth(C$, 'hasOneMoleculeWithChiralFlag$',  function () {
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
if ((mol.getChiralFlag$()).valueOf()) {
return true;
}}
return false;
});

Clazz.newMeth(C$, 'deepCopy$',  function () {
var copy=Clazz.new_(C$);
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
copy.add$O(mol.deepCopy$());
}
return copy;
});

Clazz.newMeth(C$, 'isReallyEmpty$',  function () {
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
if (mol.nAtoms$() > 0) {
return false;
}}
return true;
});

Clazz.newMeth(C$, 'scaleXY$D',  function (scale) {
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
mol.scaleXY$D(scale);
}
});

Clazz.newMeth(C$, 'moveXY$D$D',  function (dx, dy) {
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
mol.moveXY$D$D(dx, dy);
}
});

Clazz.newMeth(C$, 'move$jme_util_Box_Axis$D',  function (xOrY, dist) {
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
$I$(10).move$jme_canvas_Graphical2DObject$jme_util_Box_Axis$D(mol, xOrY, dist);
}
});

Clazz.newMeth(C$, 'setAtomBackGroundColors$S',  function (s) {
if (s != null ) for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
mol.setAtomColors$S$I(s, 0);
}
return this;
});

Clazz.newMeth(C$, 'internalBondLengthScaling$',  function () {
var referenceBondLength=0;
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
referenceBondLength=mol.internalBondLengthScaling$();
}
return referenceBondLength;
});

Clazz.newMeth(C$, 'scaleInternalBondMolList$',  function () {
var sumlen=0;
var scale=0;
var bondCount=0;
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
var n=mol.nbonds;
for (var i=1; i <= n; i++) {
sumlen+=mol.bondDistance$I(i);
}
bondCount+=n;
}
if (bondCount > 0) {
sumlen=sumlen / bondCount;
scale=25.0 / sumlen;
} else {
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
if (mol.nAtoms$() > 1) {
scale=75.0 / mol.distance$I$I(1, 2);
break;
}}
}if (scale > 0 ) {
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
mol.scaleXY$D(scale);
}
}});

Clazz.newMeth(C$, 'totalNumberOfAtoms$',  function () {
var cumulAtomCount=0;
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
cumulAtomCount+=mol.nAtoms$();
}
return cumulAtomCount;
});

Clazz.newMeth(C$, 'totalNumberOfBonds$',  function () {
var cumulBOndCount=0;
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
cumulBOndCount+=mol.nBonds$();
}
return cumulBOndCount;
});

Clazz.newMeth(C$, 'resetTouchedAtomAndBond$',  function () {
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
mol.touchedAtom=mol.touchedBond=0;
}
});

Clazz.newMeth(C$, 'asGroup$',  function () {
var newGroup=Clazz.new_($I$(9,1));
for (var mol, $mol = this.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
newGroup.add$jme_canvas_Graphical2DObject(mol);
}
return newGroup;
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.JMEmolList, "EnsembleAtom", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['molIndex','atomIndex','atomEnsembleIndex'],'O',['mol','jme.JMEmol','atom','jme.core.Atom']]]

Clazz.newMeth(C$, 'c$$jme_JMEmolList$I$I',  function (moleculeParts, molIndex, atomIndex) {
;C$.$init$.apply(this);
Clazz.assert(C$, this, function(){return atomIndex >= 0 && molIndex >= 0 });
var cumulAtomCount=0;
var molCount=0;
for (var mol, $mol = moleculeParts.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
++molCount;
molIndex=molCount;
mol=mol;
if (atomIndex > cumulAtomCount + mol.nAtoms$()) {
this.atomEnsembleIndex=atomIndex;
atomIndex=this.atomEnsembleIndex - cumulAtomCount;
break;
}if (molIndex > 0 && molIndex == molCount ) {
this.atomEnsembleIndex=atomIndex + cumulAtomCount;
atomIndex=atomIndex;
break;
}cumulAtomCount+=mol.nAtoms$();
}
if (this.mol != null ) {
this.atom=this.mol.getAtom$I(atomIndex);
if (this.atom == null ) System.out.println$S("DETLETED >>>");
}}, 1);

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.JMEmolList, "EnsembleBond", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['molIndex','bondIndex','bondEnsembleIndex'],'O',['mol','jme.JMEmol','bond','jme.core.Bond']]]

Clazz.newMeth(C$, 'c$$jme_JMEmolList$I$I',  function (molList, molIndex, bondIndex) {
;C$.$init$.apply(this);
var cumulBondCount=0;
var molCount=0;
for (var mol, $mol = molList.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
++molCount;
molIndex=molCount;
mol=mol;
if (bondIndex > cumulBondCount + mol.nBonds$()) {
this.bondEnsembleIndex=bondIndex;
bondIndex=this.bondEnsembleIndex - cumulBondCount;
break;
}if (molIndex > 0 && molIndex == molCount ) {
this.bondEnsembleIndex=bondIndex + cumulBondCount;
bondIndex=bondIndex;
break;
}cumulBondCount+=mol.nBonds$();
}
if (this.mol != null ) {
this.bond=this.mol.getBond$I(bondIndex);
}}, 1);

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:53 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
