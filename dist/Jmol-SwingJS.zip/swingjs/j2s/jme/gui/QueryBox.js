(function(){var P$=Clazz.newPackage("jme.gui"),p$1={},I$=[[0,'jme.gui.QueryBox','java.awt.Color','java.awt.Point','jme.gui.FrameWithLocation','java.awt.GridLayout','javax.swing.JPanel','java.awt.FlowLayout','javax.swing.JLabel','javax.swing.JComboBox','javax.swing.JTextField','javax.swing.JButton']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "QueryBox", null, 'jme.gui.FrameWithLocation');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.isBondQuery=false;
this.customAction=((P$.QueryBox$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "QueryBox$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]]

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
var b=e.getSource$();
if (b === this.b$['jme.gui.QueryBox'].resetButton ) {
p$1.resetAll.apply(this.b$['jme.gui.QueryBox'], []);
p$1.changeColor$javax_swing_JButton.apply(this.b$['jme.gui.QueryBox'], [$I$(1).any]);
p$1.doSmarts.apply(this.b$['jme.gui.QueryBox'], []);
} else if (Clazz.instanceOf(b, "javax.swing.JButton")) {
p$1.resetBondType.apply(this.b$['jme.gui.QueryBox'], []);
if (b === $I$(1).any ) {
p$1.resetAtomList.apply(this.b$['jme.gui.QueryBox'], []);
p$1.resetAtomType.apply(this.b$['jme.gui.QueryBox'], []);
} else if (b === $I$(1).anyec ) {
p$1.resetAtomList.apply(this.b$['jme.gui.QueryBox'], []);
p$1.resetAtomType.apply(this.b$['jme.gui.QueryBox'], []);
} else if (b === $I$(1).halogen ) {
p$1.resetAtomList.apply(this.b$['jme.gui.QueryBox'], []);
p$1.resetAtomType.apply(this.b$['jme.gui.QueryBox'], []);
} else if (b === $I$(1).ring ) {
$I$(1).nonring.setBackground$java_awt_Color(this.b$['jme.gui.QueryBox'].bgc);
} else if (b === $I$(1).nonring ) {
$I$(1).ring.setBackground$java_awt_Color(this.b$['jme.gui.QueryBox'].bgc);
$I$(1).aromatic.setBackground$java_awt_Color(this.b$['jme.gui.QueryBox'].bgc);
} else if (b === $I$(1).aromatic ) {
$I$(1).nonaromatic.setBackground$java_awt_Color(this.b$['jme.gui.QueryBox'].bgc);
$I$(1).nonring.setBackground$java_awt_Color(this.b$['jme.gui.QueryBox'].bgc);
} else if (b === $I$(1).nonaromatic ) {
$I$(1).aromatic.setBackground$java_awt_Color(this.b$['jme.gui.QueryBox'].bgc);
} else if (b === $I$(1).anyBond  || b === $I$(1).aromaticBond   || b === $I$(1).ringBond   || b === $I$(1).nonringBond  ) {
p$1.resetAll.apply(this.b$['jme.gui.QueryBox'], []);
this.b$['jme.gui.QueryBox'].isBondQuery=true;
} else {
p$1.resetAtomType.apply(this.b$['jme.gui.QueryBox'], []);
}p$1.changeColor$javax_swing_JButton.apply(this.b$['jme.gui.QueryBox'], [(b)]);
p$1.doSmarts.apply(this.b$['jme.gui.QueryBox'], []);
} else if (Clazz.instanceOf(b, "javax.swing.JComboBox")) {
p$1.resetBondType.apply(this.b$['jme.gui.QueryBox'], []);
var choice=b;
if (choice.getSelectedIndex$() == 0) choice.setBackground$java_awt_Color(this.b$['jme.gui.QueryBox'].bgc);
 else choice.setBackground$java_awt_Color($I$(2).orange);
p$1.doSmarts.apply(this.b$['jme.gui.QueryBox'], []);
}if (this.b$['jme.gui.QueryBox'].jme.action != 107) {
this.b$['jme.gui.QueryBox'].jme.action=107;
this.b$['jme.gui.QueryBox'].jme.repaint$();
}});
})()
), Clazz.new_(P$.QueryBox$1.$init$,[this, null]));
},1);

C$.$fields$=[['Z',['isBondQuery'],'O',['myLocation','java.awt.Point','text','javax.swing.JTextField','bgc','java.awt.Color','jme','jme.JME','resetButton','javax.swing.JButton','customAction','java.awt.event.ActionListener']]
,['O',['c','javax.swing.JButton','+n','+o','+s','+p','+f','+cl','+br','+i','+any','+anyec','+halogen','+aromatic','+nonaromatic','+ring','+nonring','+anyBond','+aromaticBond','+ringBond','+nonringBond','+sdBond','choiced','javax.swing.JComboBox','+choiceh']]]

Clazz.newMeth(C$, 'c$$jme_JME',  function (jme) {
;C$.superclazz.c$$S.apply(this,["Atom/Bond Query"]);C$.$init$.apply(this);
this.jme=jme;
this.bgc=jme.bgColor;
if (this.myLocation == null ) {
var jmeLocation=jme.getLocationOnScreen$();
this.myLocation=Clazz.new_($I$(3,1).c$$java_awt_Point,[jmeLocation]);
$I$(4).safeTranslate$java_awt_Point$I$I(this.myLocation, -150, 10);
}this.lastLocation=this.myLocation;
this.setLayout$java_awt_LayoutManager(Clazz.new_($I$(5,1).c$$I$I,[0, 1]));
this.setBackground$java_awt_Color(this.bgc);
var p1=Clazz.new_($I$(6,1));
p1.setLayout$java_awt_LayoutManager(Clazz.new_($I$(7,1).c$$I$I$I,[0, 3, 1]));
p1.add$java_awt_Component(Clazz.new_($I$(8,1).c$$S,["Atom type :"]));
var first=true;
if (first) {
C$.any=p$1.newJButton$S.apply(this, ["Any"]);
C$.anyec=p$1.newJButton$S.apply(this, ["Any except C"]);
C$.halogen=p$1.newJButton$S.apply(this, ["Halogen"]);
}p1.add$java_awt_Component(C$.any);
p1.add$java_awt_Component(C$.anyec);
p1.add$java_awt_Component(C$.halogen);
this.add$java_awt_Component(p1);
var p2=Clazz.new_($I$(6,1));
p2.setLayout$java_awt_LayoutManager(Clazz.new_($I$(7,1).c$$I$I$I,[0, 3, 1]));
p2.add$java_awt_Component(Clazz.new_($I$(8,1).c$$S$I,["Or select one or more from the list :", 2]));
this.add$java_awt_Component(p2);
var p3=Clazz.new_($I$(6,1));
p3.setLayout$java_awt_LayoutManager(Clazz.new_($I$(7,1).c$$I$I$I,[0, 3, 1]));
if (first) {
C$.c=p$1.newJButton$S.apply(this, ["C"]);
C$.n=p$1.newJButton$S.apply(this, ["N"]);
C$.o=p$1.newJButton$S.apply(this, ["O"]);
C$.s=p$1.newJButton$S.apply(this, ["S"]);
C$.p=p$1.newJButton$S.apply(this, ["P"]);
C$.f=p$1.newJButton$S.apply(this, ["F"]);
C$.cl=p$1.newJButton$S.apply(this, ["Cl"]);
C$.br=p$1.newJButton$S.apply(this, ["Br"]);
C$.i=p$1.newJButton$S.apply(this, ["I"]);
}p3.add$java_awt_Component(C$.c);
p3.add$java_awt_Component(C$.n);
p3.add$java_awt_Component(C$.o);
p3.add$java_awt_Component(C$.s);
p3.add$java_awt_Component(C$.p);
p3.add$java_awt_Component(C$.f);
p3.add$java_awt_Component(C$.cl);
p3.add$java_awt_Component(C$.br);
p3.add$java_awt_Component(C$.i);
this.add$java_awt_Component(p3);
var p4=Clazz.new_($I$(6,1));
p4.setLayout$java_awt_LayoutManager(Clazz.new_($I$(7,1).c$$I$I$I,[0, 3, 1]));
if (first) {
C$.choiceh=Clazz.new_($I$(9,1));
C$.choiceh.addItem$O("Any");
C$.choiceh.addItem$O("0");
C$.choiceh.addItem$O("1");
C$.choiceh.addItem$O("2");
C$.choiceh.addItem$O("3");
C$.choiceh.addActionListener$java_awt_event_ActionListener(this.customAction);
}p4.add$java_awt_Component(Clazz.new_($I$(8,1).c$$S,["Number of hydrogens :  "]));
p4.add$java_awt_Component(C$.choiceh);
this.add$java_awt_Component(p4);
var p5=Clazz.new_($I$(6,1));
p5.setLayout$java_awt_LayoutManager(Clazz.new_($I$(7,1).c$$I$I$I,[0, 3, 1]));
if (first) {
C$.choiced=Clazz.new_($I$(9,1));
C$.choiced.addItem$O("Any");
C$.choiced.addItem$O("0");
C$.choiced.addItem$O("1");
C$.choiced.addItem$O("2");
C$.choiced.addItem$O("3");
C$.choiced.addItem$O("4");
C$.choiced.addItem$O("5");
C$.choiced.addItem$O("6");
C$.choiced.addActionListener$java_awt_event_ActionListener(this.customAction);
}p5.add$java_awt_Component(Clazz.new_($I$(8,1).c$$S$I,["Number of connections :", 2]));
p5.add$java_awt_Component(C$.choiced);
p5.add$java_awt_Component(Clazz.new_([" (H\'s don\'t count.)", 2],$I$(8,1).c$$S$I));
this.add$java_awt_Component(p5);
var p6=Clazz.new_($I$(6,1));
p6.setLayout$java_awt_LayoutManager(Clazz.new_($I$(7,1).c$$I$I$I,[0, 3, 1]));
p6.add$java_awt_Component(Clazz.new_($I$(8,1).c$$S,["Atom is :"]));
if (first) C$.aromatic=p$1.newJButton$S.apply(this, ["Aromatic"]);
p6.add$java_awt_Component(C$.aromatic);
if (first) C$.nonaromatic=p$1.newJButton$S.apply(this, ["Nonaromatic"]);
p6.add$java_awt_Component(C$.nonaromatic);
if (first) C$.ring=p$1.newJButton$S.apply(this, ["Ring"]);
p6.add$java_awt_Component(C$.ring);
if (first) C$.nonring=p$1.newJButton$S.apply(this, ["Nonring"]);
p6.add$java_awt_Component(C$.nonring);
this.add$java_awt_Component(p6);
var p9=Clazz.new_($I$(6,1));
p9.setBackground$java_awt_Color(this.getBackground$().darker$());
p9.setLayout$java_awt_LayoutManager(Clazz.new_($I$(7,1).c$$I$I$I,[0, 3, 1]));
p9.add$java_awt_Component(Clazz.new_($I$(8,1).c$$S,["Bond is :"]));
if (first) C$.anyBond=p$1.newJButton$S.apply(this, ["Any"]);
p9.add$java_awt_Component(C$.anyBond);
if (first) C$.aromaticBond=p$1.newJButton$S.apply(this, ["Aromatic"]);
p9.add$java_awt_Component(C$.aromaticBond);
if (first) C$.ringBond=p$1.newJButton$S.apply(this, ["Ring"]);
p9.add$java_awt_Component(C$.ringBond);
if (first) C$.nonringBond=p$1.newJButton$S.apply(this, ["Nonring"]);
p9.add$java_awt_Component(C$.nonringBond);
this.add$java_awt_Component(p9);
var p8=Clazz.new_($I$(6,1));
p8.setLayout$java_awt_LayoutManager(Clazz.new_($I$(7,1).c$$I$I$I,[1, 3, 1]));
if (first) this.text=Clazz.new_($I$(10,1).c$$S$I,["*", 20]);
p8.add$java_awt_Component(this.text);
this.resetButton=p$1.newJButton$S.apply(this, ["Reset"]);
p8.add$java_awt_Component(this.resetButton);
this.resetButton.addActionListener$java_awt_event_ActionListener(this.customAction);
p8.add$java_awt_Component(this.closeJButton);
this.add$java_awt_Component(p8);
this.setResizable$Z(false);
if (first) {
p$1.resetAtomList.apply(this, []);
p$1.resetAtomType.apply(this, []);
p$1.resetBondType.apply(this, []);
C$.aromatic.setBackground$java_awt_Color(this.bgc);
C$.nonaromatic.setBackground$java_awt_Color(this.bgc);
C$.ring.setBackground$java_awt_Color(this.bgc);
C$.nonring.setBackground$java_awt_Color(this.bgc);
C$.choiceh.setBackground$java_awt_Color(this.bgc);
C$.choiced.setBackground$java_awt_Color(this.bgc);
p$1.changeColor$javax_swing_JButton.apply(this, [C$.any]);
}this.pack$();
this.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$, 'newJButton$S',  function (text) {
var b=Clazz.new_($I$(11,1).c$$S,[text]);
b.addActionListener$java_awt_event_ActionListener(this.customAction);
return b;
}, p$1);

Clazz.newMeth(C$, 'resetAll',  function () {
p$1.resetAtomList.apply(this, []);
p$1.resetAtomType.apply(this, []);
C$.choiceh.setSelectedIndex$I(0);
C$.choiced.setSelectedIndex$I(0);
C$.aromatic.setBackground$java_awt_Color(this.bgc);
C$.nonaromatic.setBackground$java_awt_Color(this.bgc);
C$.ring.setBackground$java_awt_Color(this.bgc);
C$.nonring.setBackground$java_awt_Color(this.bgc);
C$.choiceh.setBackground$java_awt_Color(this.bgc);
C$.choiced.setBackground$java_awt_Color(this.bgc);
p$1.resetBondType.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'resetAtomList',  function () {
C$.c.setBackground$java_awt_Color(this.bgc);
C$.n.setBackground$java_awt_Color(this.bgc);
C$.o.setBackground$java_awt_Color(this.bgc);
C$.s.setBackground$java_awt_Color(this.bgc);
C$.p.setBackground$java_awt_Color(this.bgc);
C$.f.setBackground$java_awt_Color(this.bgc);
C$.cl.setBackground$java_awt_Color(this.bgc);
C$.br.setBackground$java_awt_Color(this.bgc);
C$.i.setBackground$java_awt_Color(this.bgc);
}, p$1);

Clazz.newMeth(C$, 'resetAtomType',  function () {
C$.any.setBackground$java_awt_Color(this.bgc);
C$.anyec.setBackground$java_awt_Color(this.bgc);
C$.halogen.setBackground$java_awt_Color(this.bgc);
}, p$1);

Clazz.newMeth(C$, 'resetBondType',  function () {
C$.anyBond.setBackground$java_awt_Color(this.bgc);
C$.aromaticBond.setBackground$java_awt_Color(this.bgc);
C$.ringBond.setBackground$java_awt_Color(this.bgc);
C$.nonringBond.setBackground$java_awt_Color(this.bgc);
this.isBondQuery=false;
}, p$1);

Clazz.newMeth(C$, 'changeColor$javax_swing_JButton',  function (b) {
if (b.getBackground$() === this.bgc ) b.setBackground$java_awt_Color($I$(2).orange);
 else b.setBackground$java_awt_Color(this.bgc);
}, p$1);

Clazz.newMeth(C$, 'doSmarts',  function () {
var smarts="";
var showaA=false;
if (C$.any.getBackground$() !== this.bgc ) {
smarts="*";
showaA=true;
} else if (C$.anyec.getBackground$() !== this.bgc ) {
smarts="!#6";
showaA=true;
} else if (C$.halogen.getBackground$() !== this.bgc ) {
C$.f.setBackground$java_awt_Color($I$(2).orange);
C$.cl.setBackground$java_awt_Color($I$(2).orange);
C$.br.setBackground$java_awt_Color($I$(2).orange);
C$.i.setBackground$java_awt_Color($I$(2).orange);
smarts="F,Cl,Br,I";
} else {
var ar=C$.aromatic.getBackground$() !== this.bgc ;
var nar=C$.nonaromatic.getBackground$() !== this.bgc ;
if (C$.c.getBackground$() !== this.bgc ) {
if (ar) smarts+="c,";
 else if (nar) smarts+="C,";
 else smarts+="#6,";
}if (C$.n.getBackground$() !== this.bgc ) {
if (ar) smarts+="n,";
 else if (nar) smarts+="N,";
 else smarts+="#7,";
}if (C$.o.getBackground$() !== this.bgc ) {
if (ar) smarts+="o,";
 else if (nar) smarts+="O,";
 else smarts+="#8,";
}if (C$.s.getBackground$() !== this.bgc ) {
if (ar) smarts+="s,";
 else if (nar) smarts+="S,";
 else smarts+="#16,";
}if (C$.p.getBackground$() !== this.bgc ) {
if (ar) smarts+="p,";
 else if (nar) smarts+="P,";
 else smarts+="#15,";
}if (C$.f.getBackground$() !== this.bgc ) smarts+="F,";
if (C$.cl.getBackground$() !== this.bgc ) smarts+="Cl,";
if (C$.br.getBackground$() !== this.bgc ) smarts+="Br,";
if (C$.i.getBackground$() !== this.bgc ) smarts+="I,";
if (smarts.endsWith$S(",")) smarts=smarts.substring$I$I(0, smarts.length$() - 1);
if (smarts.length$() < 1 && !this.isBondQuery ) {
if (ar) smarts="a";
 else if (nar) smarts="A";
 else {
C$.any.setBackground$java_awt_Color($I$(2).orange);
smarts="*";
}}}var ap="";
if (showaA && C$.aromatic.getBackground$() !== this.bgc  ) ap+=";a";
if (showaA && C$.nonaromatic.getBackground$() !== this.bgc  ) ap+=";A";
if (C$.ring.getBackground$() !== this.bgc ) ap+=";R";
if (C$.nonring.getBackground$() !== this.bgc ) ap+=";!R";
if (C$.any.getBackground$() !== this.bgc  && ap.length$() > 0 ) smarts=ap.substring$I$I(1, ap.length$());
 else smarts+=ap;
var nh=C$.choiceh.getSelectedIndex$();
if (nh > 0) {
--nh;
smarts+=";H" + nh;
}var nd=C$.choiced.getSelectedIndex$();
if (nd > 0) {
--nd;
smarts+=";D" + nd;
}if (C$.anyBond.getBackground$() !== this.bgc ) smarts="~";
if (C$.aromaticBond.getBackground$() !== this.bgc ) smarts=":";
if (C$.ringBond.getBackground$() !== this.bgc ) smarts="@";
if (C$.nonringBond.getBackground$() !== this.bgc ) smarts="!@";
this.text.setText$S(smarts);
}, p$1);

Clazz.newMeth(C$, 'isBondQuery$',  function () {
return this.isBondQuery;
});

Clazz.newMeth(C$, 'getSmarts$',  function () {
return this.text.getText$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
