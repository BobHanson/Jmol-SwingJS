(function(){var P$=Clazz.newPackage("jme.gui"),p$1={},I$=[[0,'java.util.BitSet','java.util.ArrayList','jme.JME','jme.gui.GUI',['jme.gui.GUI','.RingComparator'],'java.awt.Font','java.awt.FontMetrics','java.awt.Color','jme.core.Atom','java.awt.Point',['jme.gui.GUI','.Icon'],['java.awt.geom.Rectangle2D','.Double'],'javax.swing.JPopupMenu','javax.swing.JMenuItem','jme.canvas.ColorManager']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "GUI", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['Icon',9],['RingComparator',9],['Ring',9],['RingInfo',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.mustReDrawLeftMenu=true;
this.mustReDrawTopMenu=true;
this.mustReDrawMolecularArea=true;
this.mustReDrawInfo=true;
this.mustReDrawRightBorderImage=true;
this.menuCellSize=24.0;
this.uniColorMolecule=null;
},1);

C$.$fields$=[['Z',['mustReDrawLeftMenu','mustReDrawTopMenu','mustReDrawMolecularArea','mustReDrawInfo','mustReDrawRightBorderImage'],'D',['menuCellSize','ioArrowWidth'],'I',['ioMargin'],'O',['jme','jme.JME','atomDrawingAreaFont','java.awt.Font','atomDrawingAreaFontMet','java.awt.FontMetrics','atomMapDrawingAreaFont','java.awt.Font','atomMapDrawingAreaFontMet','java.awt.FontMetrics','functionalGroupPopumemu','javax.swing.JPopupMenu','functionalGroupJPopupMenuPosition','java.awt.Point','+markerJPopupMenuPosition','+fixedCopyPasteJPopupMenuPosition','dragAndDropIcon','jme.gui.GUI.Icon','+fullScreenIcon','uniColorMolecule','jme.JMEmol']]
,['Z',['isSwingJS'],'O',['touchSupported','Boolean','copyRigthSmallTextFont','java.awt.Font','+menuCellFont','+menuCellFontBold','+menuCellFontSmaller','menuCellFontMet','java.awt.FontMetrics','+menuCellFontBoldMet','+menuCellFontSmallerMet','atomDrawingAreaFontCache','java.awt.Font[]','atomDrawingAreaFontMetCache','java.awt.FontMetrics[]','atomMapDrawingAreaFontCache','java.awt.Font[]','atomMapDrawingAreaFontMetCache','java.awt.FontMetrics[]','ringComparator','jme.gui.GUI.RingComparator']]]

Clazz.newMeth(C$, 'isTouchSupported$',  function () {
if (C$.touchSupported == null ) {
var supported;
{
supported = !J2S._haveMouse;
}
C$.touchSupported=Boolean.valueOf$Z(supported);
}return C$.touchSupported.booleanValue$();
}, 1);

Clazz.newMeth(C$, 'c$$jme_JME',  function (jme) {
;C$.$init$.apply(this);
this.jme=jme;
C$.menuCellFontMet=jme.getFontMetrics$java_awt_Font(C$.menuCellFont);
C$.menuCellFontBoldMet=jme.getFontMetrics$java_awt_Font(C$.menuCellFontBold);
C$.menuCellFontSmallerMet=jme.getFontMetrics$java_awt_Font(C$.menuCellFontSmaller);
var realFs=13.0;
var fs=Math.round(realFs);
if (C$.atomDrawingAreaFontCache[fs] == null ) {
C$.atomDrawingAreaFontCache[fs]=Clazz.new_($I$(6,1).c$$S$I$I,["Helvetica", jme.options.boldAtomLabels ? 1 : 0, fs]);
}if (C$.atomDrawingAreaFontMetCache[fs] == null ) {
C$.atomDrawingAreaFontMetCache[fs]=jme.getFontMetrics$java_awt_Font(C$.atomDrawingAreaFontCache[fs]);
}this.atomDrawingAreaFont=C$.atomDrawingAreaFontCache[fs];
this.atomDrawingAreaFontMet=C$.atomDrawingAreaFontMetCache[fs];
fs=Long.$ival(Math.round$D(realFs * 0.8));
if (C$.atomMapDrawingAreaFontCache[fs] == null ) {
C$.atomMapDrawingAreaFontCache[fs]=Clazz.new_($I$(6,1).c$$S$I$I,["Helvetica", 0, fs]);
}if (C$.atomMapDrawingAreaFontMetCache[fs] == null ) {
C$.atomMapDrawingAreaFontMetCache[fs]=jme.getFontMetrics$java_awt_Font(C$.atomMapDrawingAreaFontCache[fs]);
}this.atomMapDrawingAreaFont=C$.atomMapDrawingAreaFontCache[fs];
this.atomMapDrawingAreaFontMet=C$.atomMapDrawingAreaFontMetCache[fs];
}, 1);

Clazz.newMeth(C$, 'stringHeight$java_awt_FontMetrics',  function (fm) {
return fm.getAscent$() - fm.getDescent$();
}, 1);

Clazz.newMeth(C$, 'getHumanInteractionTouchRadius$',  function () {
return 50 + (C$.isTouchSupported$() ? 300 : 120);
}, 1);

Clazz.newMeth(C$, 'createSquare$jme_canvas_PreciseGraphicsAWT$I$I',  function (g, xpos, ypos) {
var square=ypos * 100 + xpos;
var xstart=(xpos - 1) * (this.menuCellSize + this.menuCellBorder$());
var ystart=(ypos - 1) * (this.menuCellSize + this.menuCellBorder$());
if (xpos == 1 && ypos > 2 ) ystart-=(2 * this.menuCellSize);
g.setColor$java_awt_Color(this.jme.bgColor);
if (this.jme.options.newLook) {
if (square == this.jme.action) {
g.setColor$java_awt_Color(this.jme.bgColor.darker$());
}g.fillRect$D$D$D$D(xstart, ystart, this.menuCellSize, this.menuCellSize);
g.setColor$java_awt_Color($I$(8).darkGray);
g.drawRect$D$D$D$D(xstart, ystart, this.menuCellSize - 1, this.menuCellSize - 1);
} else {
if (square == this.jme.action) g.fill3DRect$D$D$D$D$Z(xstart + 1, ystart + 1, this.menuCellSize, this.menuCellSize, false);
 else g.fill3DRect$D$D$D$D$Z(xstart, ystart, this.menuCellSize, this.menuCellSize, true);
}if (!this.jme.isActionEnabled$I(square)) {
return;
}var marginFromCellBorder=this.menuCellSize / 4;
if (ypos >= 3) {
var dan=this.jme.mapActionToAtomNumberXorR$I(square);
if (dan != -1) {
var label=$I$(9).zlabel[dan];
var atomSymbolColor=this.jme.leftMenuAtomColor == null  ? $I$(3).color[dan] : this.jme.leftMenuAtomColor;
this.squareTextBold$jme_canvas_PreciseGraphicsAWT$D$D$java_awt_Color$S(g, xstart, ystart, atomSymbolColor, label);
}return;
}g.setColor$java_awt_Color($I$(8).black);
switch (square) {
case 101:
if (true) {
g.setColor$java_awt_Color($I$(8).yellow);
g.fillOval$D$D$D$D(xstart + 3, ystart + 3, this.menuCellSize - 6, this.menuCellSize - 6);
g.setColor$java_awt_Color($I$(8).black);
}g.drawOval$D$D$D$D(xstart + 3, ystart + 3, this.menuCellSize - 6, this.menuCellSize - 6);
g.drawArc$D$D$D$D$D$D(xstart + 6, ystart + 6, this.menuCellSize - 12, this.menuCellSize - 12, -35, -110);
g.fillRect$D$D$D$D(xstart + 9, ystart + 9, 2, 4);
g.fillRect$D$D$D$D(xstart + this.menuCellSize - 10, ystart + 9, 2, 4);
if (Math.random() < 0.04 ) {
g.setColor$java_awt_Color($I$(8).red);
g.fillRect$D$D$D$D(xstart + 10, ystart + 18, 4, 4);
}if (Math.random() > 0.96 ) {
g.setColor$java_awt_Color($I$(8).yellow);
g.fillRect$D$D$D$D(xstart + this.menuCellSize - 10, ystart + 8, 2, 3);
}break;
case 112:
var xFarLeft=xstart + marginFromCellBorder;
var xFarRight=xstart + this.menuCellSize - marginFromCellBorder;
var xMiddle=xstart + this.menuCellSize / 2;
g.drawLine$D$D$D$D(xFarLeft, ystart + this.menuCellSize - marginFromCellBorder, xMiddle, ystart + this.menuCellSize / 2);
g.drawLine$D$D$D$D(xstart + this.menuCellSize / 2, ystart + this.menuCellSize / 2, xFarRight, ystart + this.menuCellSize - marginFromCellBorder);
var y=ystart + this.menuCellSize - marginFromCellBorder;
var dotLength=this.menuCellSize / 24.0;
g.drawLine$D$D$D$D(xMiddle - dotLength, y, xMiddle - 2 * dotLength, y);
g.drawLine$D$D$D$D(xMiddle + dotLength, y, xMiddle + 2 * dotLength, y);
g.setColor$java_awt_Color($I$(8).magenta);
g.drawLine$D$D$D$D(xFarLeft, ystart + marginFromCellBorder, xMiddle, ystart + this.menuCellSize / 2);
g.drawLine$D$D$D$D(xstart + this.menuCellSize / 2, ystart + this.menuCellSize / 2, xFarRight, ystart + marginFromCellBorder);
y=ystart + marginFromCellBorder;
g.drawLine$D$D$D$D(xMiddle - dotLength, y, xMiddle - 2 * dotLength, y);
g.drawLine$D$D$D$D(xMiddle + dotLength, y, xMiddle + 2 * dotLength, y);
g.setColor$java_awt_Color($I$(8).black);
break;
case 107:
g.setColor$java_awt_Color($I$(8).orange);
g.fillRect$D$D$D$D(xstart + 4, ystart + 4, this.menuCellSize - 8, this.menuCellSize - 8);
g.setColor$java_awt_Color($I$(8).black);
g.drawRect$D$D$D$D(xstart + 4, ystart + 4, this.menuCellSize - 8, this.menuCellSize - 8);
g.drawArc$D$D$D$D$D$D(xstart + 6, ystart + 6, this.menuCellSize - 11, this.menuCellSize - 12, -35, -110);
g.fillRect$D$D$D$D(xstart + 9, ystart + 9, 2, 4);
g.fillRect$D$D$D$D(xstart + this.menuCellSize - 10, ystart + 9, 2, 4);
break;
case 108:
var padding=this.menuCellSize / 4;
g.drawLine$D$D$D$D(xstart + padding, ystart + this.menuCellSize - padding, xstart + this.menuCellSize - padding, ystart + padding);
var symbolSize=this.menuCellSize / 2 - padding;
var minusY=ystart + this.menuCellSize * 2 / 3;
var minusStartX=xstart + this.menuCellSize / 2;
var minusEndX=minusStartX + symbolSize;
g.drawLine$D$D$D$D(minusStartX, minusY, minusEndX, minusY);
var hY=ystart + this.menuCellSize * 1 / 3;
var hEndX=minusStartX;
var hStartX=minusStartX - symbolSize;
g.drawLine$D$D$D$D(hStartX, hY, hEndX, hY);
var vX=(hStartX + hEndX) / 2;
var vStartY=hY - symbolSize / 2;
var vEndY=vStartY + symbolSize;
g.drawLine$D$D$D$D(vX, vStartY, vX, vEndY);
break;
case 113:
if (this.jme.options.showAtomMoveJButton) {
var reduction=marginFromCellBorder / 2;
var squareSize=this.menuCellSize - 2 * marginFromCellBorder - 2 * reduction;
var brx=xstart + reduction + marginFromCellBorder ;
var bry=ystart + (brx - xstart);
g.setColor$java_awt_Color($I$(8).BLUE);
g.drawRect$D$D$D$D(brx, bry, squareSize, squareSize);
g.setColor$java_awt_Color($I$(8).BLACK);
var middleX=xstart + this.menuCellSize / 2;
var middleY=ystart + this.menuCellSize / 2;
var arrowMarginFromCellBorder=reduction;
var arrowHeight=reduction;
var arrowWidth=squareSize;
Clazz.assert(C$, this, function(){return arrowHeight > 0 });
var xLeft=brx;
var xRight=brx + arrowWidth;
var yTop=ystart + arrowMarginFromCellBorder;
var yBottom=yTop + arrowHeight;
g.drawLine$D$D$D$D(xLeft, yBottom, middleX, yTop);
g.drawLine$D$D$D$D(middleX, yTop, xRight, yBottom);
yBottom=bry + squareSize + reduction ;
yTop=yBottom + arrowHeight;
g.drawLine$D$D$D$D(xLeft, yBottom, middleX, yTop);
g.drawLine$D$D$D$D(middleX, yTop, xRight, yBottom);
xLeft=xstart + reduction;
xRight=xLeft + arrowHeight;
yTop=bry;
yBottom=yTop + arrowWidth;
g.drawLine$D$D$D$D(xRight, yTop, xLeft, middleY);
g.drawLine$D$D$D$D(xLeft, middleY, xRight, yBottom);
xLeft=brx + squareSize + reduction ;
xRight=xLeft + arrowHeight;
g.drawLine$D$D$D$D(xLeft, yTop, xRight, middleY);
g.drawLine$D$D$D$D(xRight, middleY, xLeft, yBottom);
}break;
case 110:
C$.drawUndoOrRedoArrowMenuCell$jme_canvas_PreciseGraphicsAWT$D$D$D$Z(g, xstart, ystart, this.menuCellSize, true);
break;
case 111:
C$.drawUndoOrRedoArrowMenuCell$jme_canvas_PreciseGraphicsAWT$D$D$D$Z(g, xstart, ystart, this.menuCellSize, false);
break;
case 214:
this.drawInputOutputArrowsMenuCell$jme_canvas_PreciseGraphicsAWT$D$D$D(g, xstart, ystart, this.menuCellSize);
this.fixedCopyPasteJPopupMenuPosition=Clazz.new_([(xstart|0), (ystart|0)],$I$(10,1).c$$I$I);
break;
case 109:
g.drawLine$D$D$D$D(xstart + marginFromCellBorder, ystart + this.menuCellSize / 2, xstart + this.menuCellSize - marginFromCellBorder, ystart + this.menuCellSize / 2);
g.drawLine$D$D$D$D(xstart + this.menuCellSize - marginFromCellBorder, ystart + this.menuCellSize / 2, xstart + this.menuCellSize - marginFromCellBorder * 3 / 2, ystart + this.menuCellSize / 2 + marginFromCellBorder / 2);
g.drawLine$D$D$D$D(xstart + this.menuCellSize - marginFromCellBorder, ystart + this.menuCellSize / 2, xstart + this.menuCellSize - marginFromCellBorder * 3 / 2, ystart + this.menuCellSize / 2 - marginFromCellBorder / 2);
break;
case 102:
g.setColor$java_awt_Color($I$(8).white);
g.fillRect$D$D$D$D(xstart + 1, ystart + 2, this.menuCellSize - 2, this.menuCellSize - 3);
g.setColor$java_awt_Color($I$(8).black);
this.squareText$jme_canvas_PreciseGraphicsAWT$D$D$S(g, xstart, ystart, "CLR");
break;
case 103:
g.setColor$java_awt_Color(this.jme.bgColor);
if (this.jme.newMolecule) g.fill3DRect$D$D$D$D$Z(xstart + 1, ystart + 1, this.menuCellSize, this.menuCellSize, false);
g.setColor$java_awt_Color($I$(8).black);
this.squareText$jme_canvas_PreciseGraphicsAWT$D$D$S(g, xstart, ystart, "NEW");
break;
case 106:
g.setColor$java_awt_Color($I$(8).red);
g.drawLine$D$D$D$D(xstart + 7, ystart + 7, xstart + this.menuCellSize - 7, ystart + this.menuCellSize - 7);
g.drawLine$D$D$D$D(xstart + 7, ystart + this.menuCellSize - 7, xstart + this.menuCellSize - 7, ystart + 7);
g.setColor$java_awt_Color($I$(8).black);
g.drawLine$D$D$D$D(xstart + marginFromCellBorder, ystart + this.menuCellSize / 2, xstart + 12, ystart + this.menuCellSize / 2);
this.squareText$jme_canvas_PreciseGraphicsAWT$D$D$S(g, xstart + 6, ystart, "R");
break;
case 104:
g.setColor$java_awt_Color($I$(8).red);
g.drawLine$D$D$D$D(xstart + 7, ystart + 7, xstart + this.menuCellSize - 7, ystart + this.menuCellSize - 7);
g.drawLine$D$D$D$D(xstart + 7, ystart + this.menuCellSize - 7, xstart + this.menuCellSize - 7, ystart + 7);
g.setColor$java_awt_Color($I$(8).black);
break;
case 105:
if (!this.jme.options.starNothing) {
if (this.jme.params.mark) {
var pseudoRadius=9;
var color=this.jme.colorManager.getColor$I(this.jme.activeMarkerColorIndex);
if (color != null ) {
g.setColor$java_awt_Color(color);
g.fillOval$D$D$D$D(xstart + pseudoRadius / 2, ystart + pseudoRadius / 2, this.menuCellSize - pseudoRadius, this.menuCellSize - pseudoRadius);
g.setColor$java_awt_Color($I$(8).black);
} else {
this.jme.showInfo$S("invalid color index:" + this.jme.activeMarkerColorIndex);
Clazz.assert(C$, this, function(){return (false)});
}} else {
this.squareText$jme_canvas_PreciseGraphicsAWT$D$D$S(g, xstart, ystart, "123");
}this.markerJPopupMenuPosition=Clazz.new_([(xstart|0), (ystart|0)],$I$(10,1).c$$I$I);
}break;
case 114:
g.setColor$java_awt_Color($I$(8).blue);
var coloredRectSize=this.menuCellSize - 8;
var coloredRectSizeX=xstart + (this.menuCellSize - coloredRectSize) / 2;
var coloredRectSizeY=ystart + (this.menuCellSize - coloredRectSize) / 2;
g.fillRect$D$D$D$D(coloredRectSizeX, coloredRectSizeY, coloredRectSize, coloredRectSize);
g.setColor$java_awt_Color($I$(8).black);
this.squareTextBold$jme_canvas_PreciseGraphicsAWT$D$D$java_awt_Color$S(g, xstart, ystart, $I$(8).white, "i");
break;
case 201:
g.drawLine$D$D$D$D(xstart + marginFromCellBorder, ystart + this.menuCellSize / 2, xstart + this.menuCellSize - marginFromCellBorder, ystart + this.menuCellSize / 2 + 2);
g.drawLine$D$D$D$D(xstart + marginFromCellBorder, ystart + this.menuCellSize / 2, xstart + this.menuCellSize - marginFromCellBorder, ystart + this.menuCellSize / 2 - 2);
g.drawLine$D$D$D$D(xstart + this.menuCellSize - marginFromCellBorder, ystart + this.menuCellSize / 2 + 2, xstart + this.menuCellSize - marginFromCellBorder, ystart + this.menuCellSize / 2 - 2);
break;
case 202:
g.drawLine$D$D$D$D(xstart + marginFromCellBorder, ystart + this.menuCellSize / 2, xstart + this.menuCellSize - marginFromCellBorder, ystart + this.menuCellSize / 2);
break;
case 203:
g.drawLine$D$D$D$D(xstart + marginFromCellBorder, ystart + this.menuCellSize / 2 - 2, xstart + this.menuCellSize - marginFromCellBorder, ystart + this.menuCellSize / 2 - 2);
g.drawLine$D$D$D$D(xstart + marginFromCellBorder, ystart + this.menuCellSize / 2 + 2, xstart + this.menuCellSize - marginFromCellBorder, ystart + this.menuCellSize / 2 + 2);
break;
case 204:
g.drawLine$D$D$D$D(xstart + marginFromCellBorder, ystart + this.menuCellSize / 2, xstart + this.menuCellSize - marginFromCellBorder, ystart + this.menuCellSize / 2);
g.drawLine$D$D$D$D(xstart + marginFromCellBorder, ystart + this.menuCellSize / 2 - 3, xstart + this.menuCellSize - marginFromCellBorder, ystart + this.menuCellSize / 2 - 3);
g.drawLine$D$D$D$D(xstart + marginFromCellBorder, ystart + this.menuCellSize / 2 + 3, xstart + this.menuCellSize - marginFromCellBorder, ystart + this.menuCellSize / 2 + 3);
break;
case 205:
g.drawLine$D$D$D$D(xstart + marginFromCellBorder / 2, ystart + marginFromCellBorder * 2 + marginFromCellBorder / 3, xstart + marginFromCellBorder / 2 * 3, ystart + marginFromCellBorder * 2 - marginFromCellBorder / 3);
g.drawLine$D$D$D$D(xstart + marginFromCellBorder / 2 * 3, ystart + marginFromCellBorder * 2 - marginFromCellBorder / 3, xstart + marginFromCellBorder / 2 * 5, ystart + marginFromCellBorder * 2 + marginFromCellBorder / 3);
g.drawLine$D$D$D$D(xstart + marginFromCellBorder / 2 * 5, ystart + marginFromCellBorder * 2 + marginFromCellBorder / 3, xstart + marginFromCellBorder / 2 * 7, ystart + marginFromCellBorder * 2 - marginFromCellBorder / 3);
break;
case 206:
this.drawRingIcon$jme_canvas_PreciseGraphicsAWT$D$D$I(g, xstart, ystart + 2, 3);
break;
case 207:
this.drawRingIcon$jme_canvas_PreciseGraphicsAWT$D$D$I(g, xstart, ystart, 4);
break;
case 208:
this.drawRingIcon$jme_canvas_PreciseGraphicsAWT$D$D$I(g, xstart, ystart, 5);
break;
case 209:
this.drawRingIcon$jme_canvas_PreciseGraphicsAWT$D$D$I(g, xstart, ystart, 1);
break;
case 210:
this.drawRingIcon$jme_canvas_PreciseGraphicsAWT$D$D$I(g, xstart, ystart, 6);
break;
case 211:
this.drawRingIcon$jme_canvas_PreciseGraphicsAWT$D$D$I(g, xstart, ystart, 7);
break;
case 212:
this.drawRingIcon$jme_canvas_PreciseGraphicsAWT$D$D$I(g, xstart, ystart, 8);
break;
case 213:
if (this.jme.options.fgMenuOption) {
this.squareText$jme_canvas_PreciseGraphicsAWT$D$D$S(g, xstart, ystart, "FG");
this.functionalGroupJPopupMenuPosition=Clazz.new_([(xstart|0), (ystart|0)],$I$(10,1).c$$I$I);
}break;
}
});

Clazz.newMeth(C$, 'drawUndoOrRedoArrowMenuCell$jme_canvas_PreciseGraphicsAWT$D$D$D$Z',  function (g, xstart, ystart, cellSize, undo) {
var arrowWidth=(cellSize / 4.0);
var arrowHeight=arrowWidth;
var margin=2;
ystart-=1;
var xStartArrowLine=margin;
var xArrowTip=xStartArrowLine + arrowWidth / 2.0;
var xEndArrowLine=xStartArrowLine + arrowWidth;
var yStartArrowLine=ystart + (10.0 * cellSize / 24.0);
var yArrowTip=yStartArrowLine + arrowHeight;
var xEnd=xstart + cellSize;
var absoluteXArrowTip=0;
var absoluteXstartArrowLine=0;
var absoluteXEndArrowLine=0;
if (undo) {
absoluteXstartArrowLine=xStartArrowLine + xstart;
absoluteXArrowTip=xArrowTip + xstart;
absoluteXEndArrowLine=xEndArrowLine + xstart;
} else {
absoluteXArrowTip=xEnd - xArrowTip;
absoluteXstartArrowLine=xEnd - xStartArrowLine;
absoluteXEndArrowLine=xEnd - xEndArrowLine;
}g.drawLine$D$D$D$D(absoluteXstartArrowLine, yStartArrowLine, absoluteXArrowTip, yArrowTip);
g.drawLine$D$D$D$D(absoluteXEndArrowLine, yStartArrowLine, absoluteXArrowTip, yArrowTip);
var yArrowCenterCorrection=arrowHeight / 3 - 0.5;
g.drawLine$D$D$D$D(absoluteXArrowTip, yStartArrowLine + yArrowCenterCorrection, absoluteXArrowTip, yArrowTip);
var xStartArcBoxTopLeft=xArrowTip;
var yStartArcBoxTopLeft=ystart + xStartArcBoxTopLeft;
var arcBoxWidth=cellSize - xStartArcBoxTopLeft - 2 * margin ;
var arcBoxHeight=cellSize - 2 * margin;
yStartArcBoxTopLeft-=yArrowCenterCorrection;
arcBoxHeight-=yArrowCenterCorrection;
arcBoxHeight-=1;
var arcSpan=270;
var startAngle=0;
var absoluteXxtartArcBoxTopLeft=0;
if (undo) {
absoluteXxtartArcBoxTopLeft=xstart + xStartArcBoxTopLeft;
startAngle=270;
} else {
absoluteXxtartArcBoxTopLeft=xEnd - arcBoxWidth - xStartArcBoxTopLeft ;
arcSpan*=-1;
startAngle=-90;
}g.drawArc$D$D$D$D$D$D(absoluteXxtartArcBoxTopLeft, yStartArcBoxTopLeft, arcBoxWidth, arcBoxHeight, startAngle, arcSpan);
}, 1);

Clazz.newMeth(C$, 'drawInputOutputArrowsMenuCell$jme_canvas_PreciseGraphicsAWT$D$D$D',  function (g, xstart, ystart, cellSize) {
var arrowWidth=this.ioArrowWidth;
var arrowHeight=arrowWidth;
var margin=this.ioMargin;
var xStartArrowLine=margin + xstart;
var xArrowTip=xStartArrowLine + arrowWidth / 2.0;
var xEndArrowLine=xStartArrowLine + arrowWidth;
var yStartArrowLine=ystart + margin;
var yArrowTip=yStartArrowLine + arrowHeight;
g.setColor$java_awt_Color($I$(8).BLUE);
g.fillPolygon$DA$DA$I(Clazz.array(Double.TYPE, -1, [xStartArrowLine, xArrowTip, xEndArrowLine]), Clazz.array(Double.TYPE, -1, [yStartArrowLine, yArrowTip, yStartArrowLine]), 3);
xStartArrowLine=xArrowTip;
xArrowTip=xStartArrowLine + arrowWidth / 2.0;
xEndArrowLine=xStartArrowLine + arrowWidth;
yArrowTip=yStartArrowLine + arrowHeight / 2.0;
yStartArrowLine=yArrowTip + arrowHeight;
g.fillPolygon$DA$DA$I(Clazz.array(Double.TYPE, -1, [xStartArrowLine, xArrowTip, xEndArrowLine]), Clazz.array(Double.TYPE, -1, [yStartArrowLine, yArrowTip, yStartArrowLine]), 3);
});

Clazz.newMeth(C$, 'drawDragAndDropIcon$jme_canvas_PreciseGraphicsAWT$D',  function (g, iconScale) {
var graphicsContainerWidth=g.getWidth$();
var graphicsContainerHeight=g.getHeight$();
var margin=this.ioMargin * iconScale;
var arrowWidth=this.ioArrowWidth * iconScale;
var arrowHeight=arrowWidth;
if (this.dragAndDropIcon == null ) this.dragAndDropIcon=Clazz.new_($I$(11,1).c$$jme_canvas_PreciseGraphicsAWT,[g]);
 else this.dragAndDropIcon.pg=g;
if (this.jme.isDepict$()) {
margin=0;
}var xStartArrowLine=graphicsContainerWidth - margin - arrowWidth ;
var xArrowTip=xStartArrowLine + arrowWidth;
var yArrowBottom;
var yArrowTop;
var yArrowMiddle;
if (!this.jme.isDepict$()) {
yArrowMiddle=graphicsContainerHeight / 2;
yArrowBottom=yArrowMiddle + arrowHeight / 2;
yArrowTop=yArrowMiddle - arrowHeight / 2;
} else {
yArrowBottom=graphicsContainerHeight;
yArrowTop=yArrowBottom - arrowHeight;
yArrowMiddle=(yArrowTop + yArrowBottom) / 2;
}g.setColor$java_awt_Color($I$(8).BLUE);
g.fillPolygon$DA$DA$I(Clazz.array(Double.TYPE, -1, [xStartArrowLine, xArrowTip, xStartArrowLine]), Clazz.array(Double.TYPE, -1, [yArrowTop, yArrowMiddle, yArrowBottom]), 3);
this.dragAndDropIcon.setRect$D$D$D$D(xStartArrowLine, yArrowTop, arrowWidth, arrowHeight);
});

Clazz.newMeth(C$, 'drawRightBorderImage$java_awt_Graphics',  function (g) {
if (!this.mustReDrawRightBorderImage) return;
var screenArea=Clazz.new_([this.jme.dimension.width - this.jme.rightBorder$(), this.jme.topMenuHeight$(), this.jme.rightBorder$(), this.jme.molecularArea.height],$I$(12,1).c$$D$D$D$D);
var og=C$.getScaledGraphicsOfPreciseImage$jme_canvas_PreciseImage$D$java_awt_geom_Rectangle2D_Double(this.jme.rightBorderImage, this.jme.menuScale, screenArea);
var imgWidth=this.jme.rightBorder$D(1);
var imgHeight=screenArea.height / this.jme.menuScale;
if (this.jme.options.newLook) {
og.setColor$java_awt_Color($I$(8).darkGray);
og.fillRect$D$D$D$D(0, 0, imgWidth, imgHeight);
} else {
og.setColor$java_awt_Color(this.jme.bgColor.darker$());
og.drawLine$D$D$D$D(imgWidth - 1, 0, imgWidth - 1, imgHeight);
og.setColor$java_awt_Color(this.jme.bgColor);
og.drawLine$D$D$D$D(imgWidth - 2, 0, imgWidth - 2, imgHeight);
og.setColor$java_awt_Color(this.jme.brightColor);
og.drawLine$D$D$D$D(imgWidth - 3, 0, imgWidth - 3, imgHeight);
}g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.jme.rightBorderImage.getImage$(), (screenArea.x|0), (screenArea.y|0), this.jme);
});

Clazz.newMeth(C$, 'drawTopMenu$java_awt_Graphics',  function (g) {
if (this.jme.topMenuImage == null ) return;
var action=this.jme.action;
var screenArea=Clazz.new_([0, 0, this.jme.dimension.width, this.jme.topMenuHeight$()],$I$(12,1).c$$D$D$D$D);
var og=C$.getScaledGraphicsOfPreciseImage$jme_canvas_PreciseImage$D$java_awt_geom_Rectangle2D_Double(this.jme.topMenuImage, this.jme.menuScale, screenArea);
var imgWidth=this.jme.dimension.width / this.jme.menuScale;
var imgHeight=this.jme.topMenuHeight$D(1.0);
og.setColor$java_awt_Color(this.jme.bgColor);
og.fillRect$D$D$D$D(0, 0, imgWidth, imgHeight);
if (this.jme.options.newLook) {
og.setColor$java_awt_Color(this.jme.bgColor.darker$());
var s=(this.menuCellSize + this.menuCellBorder$()) * 14;
og.drawRect$D$D$D$D(s, 0, imgWidth - s - 1 , imgHeight - 1);
} else {
og.setColor$java_awt_Color(this.jme.bgColor.darker$());
og.drawLine$D$D$D$D(imgWidth - 1, 0, imgWidth - 1, imgHeight - 1);
og.drawLine$D$D$D$D(0, imgHeight - 1, imgWidth - 1, imgHeight - 1);
og.setColor$java_awt_Color(this.jme.brightColor);
og.drawLine$D$D$D$D(0, 0, imgWidth - 1, 0);
}var savedAction=action;
if (2033 <= action && action <= 2062 ) {
action=213;
}for (var i=1; i <= 14; i++) {
this.createSquare$jme_canvas_PreciseGraphicsAWT$I$I(og, i, 1);
this.createSquare$jme_canvas_PreciseGraphicsAWT$I$I(og, i, 2);
}
action=savedAction;
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.jme.topMenuImage.getImage$(), 0, 0, this.jme);
});

Clazz.newMeth(C$, 'drawLeftMenu$java_awt_Graphics',  function (g) {
var screenArea=Clazz.new_([0, this.jme.topMenuHeight$(), this.jme.leftMenuWidth$(), this.jme.dimension.height - this.jme.topMenuHeight$()],$I$(12,1).c$$D$D$D$D);
var og=C$.getScaledGraphicsOfPreciseImage$jme_canvas_PreciseImage$D$java_awt_geom_Rectangle2D_Double(this.jme.leftMenuImage, this.jme.menuScale, screenArea);
var imgWidth=this.jme.leftMenuWidth$D(1);
var imgHeight=(this.jme.dimension.height - this.jme.topMenuHeight$()) / this.jme.menuScale;
og.setColor$java_awt_Color(this.jme.bgColor);
og.fillRect$D$D$D$D(0, 0, imgWidth, imgHeight);
var yInfoArea=imgHeight - this.jme.infoAreaHeight$D(1);
var leftMenuCellCount=this.jme.getLeftMenuCellCount$();
if (this.jme.options.newLook) {
og.setColor$java_awt_Color($I$(8).darkGray);
var y=leftMenuCellCount * (this.menuCellSize + this.menuCellBorder$()) + 3;
if (yInfoArea > y ) {
og.drawLine$D$D$D$D(0, y, this.menuCellSize - 1, y);
og.drawLine$D$D$D$D(0, y, 0, imgHeight - 1);
og.drawLine$D$D$D$D(this.menuCellSize - 1, y, this.menuCellSize - 1, yInfoArea);
og.drawLine$D$D$D$D(this.menuCellSize - 1, yInfoArea, imgWidth, yInfoArea);
}og.drawLine$D$D$D$D(0, imgHeight - 1, imgWidth, imgHeight - 1);
} else {
og.setColor$java_awt_Color(this.jme.brightColor);
og.drawLine$D$D$D$D(0, 0, 0, imgHeight - 1);
og.drawLine$D$D$D$D(0, leftMenuCellCount * this.menuCellSize, imgHeight - 1, leftMenuCellCount * this.menuCellSize);
og.setColor$java_awt_Color(this.jme.bgColor.darker$());
og.drawLine$D$D$D$D(imgWidth - 1, 0, imgWidth - 1, yInfoArea + 1);
og.drawLine$D$D$D$D(0, imgHeight - 1, imgWidth - 0, imgHeight - 1);
}for (var i=3; i <= leftMenuCellCount + 2; i++) {
this.createSquare$jme_canvas_PreciseGraphicsAWT$I$I(og, 1, i);
}
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.jme.leftMenuImage.getImage$(), (screenArea.x|0), (screenArea.y|0), this.jme);
});

Clazz.newMeth(C$, 'drawInfo$java_awt_Graphics',  function (g) {
var text=(this.jme.infoText == null  ? "" : this.jme.infoText);
var textYPosition=15;
var screenArea=Clazz.new_([this.jme.leftMenuWidth$(), this.jme.dimension.height - this.jme.infoAreaHeight$(), this.jme.dimension.width - this.jme.leftMenuWidth$(), this.jme.infoAreaHeight$()],$I$(12,1).c$$D$D$D$D);
var og=C$.getScaledGraphicsOfPreciseImage$jme_canvas_PreciseImage$D$java_awt_geom_Rectangle2D_Double(this.jme.infoAreaImage, this.jme.menuScale, screenArea);
var imgWidth=screenArea.width / this.jme.menuScale;
var imgHeight=this.jme.infoAreaHeight$D(1);
og.setColor$java_awt_Color(this.jme.bgColor);
og.fillRect$D$D$D$D(0, 0, imgWidth, imgHeight);
if (this.jme.options.newLook) {
og.setColor$java_awt_Color($I$(8).darkGray);
og.drawRect$D$D$D$D(-10, 0, imgWidth - 1 + 10, imgHeight - 1);
} else {
og.setColor$java_awt_Color(this.jme.brightColor);
og.drawLine$D$D$D$D(0, 0, imgWidth - this.jme.rightBorder$D(1) + 1, 0);
og.setColor$java_awt_Color(this.jme.bgColor.darker$());
og.drawLine$D$D$D$D(0, imgHeight - 1, imgWidth - 1, imgHeight - 1);
og.drawLine$D$D$D$D(imgWidth - 1, 0, imgWidth - 1, imgHeight - 1);
}og.setFont$java_awt_Font(C$.menuCellFontSmaller);
og.setColor$java_awt_Color($I$(8).black);
if (text.toLowerCase$().contains$CharSequence("error")) og.setColor$java_awt_Color($I$(8).red);
og.drawString$S$D$D(text, 10, textYPosition);
if (!this.jme.isDepict$()) {
this.drawDragAndDropIcon$jme_canvas_PreciseGraphicsAWT$D(og, 1.0);
if (this.jme.options.fullScreenIconOption && $I$(3).isFullScreenSupported$() ) this.drawFullScreenIcon$jme_canvas_PreciseGraphicsAWT$D$jme_gui_GUI_Icon(og, 1.0, this.dragAndDropIcon);
 else this.fullScreenIcon=null;
}if (imgWidth > 100  && this.jme.doDrawChiralText$() ) {
var chiralText="Chiral";
og.setColor$java_awt_Color($I$(8).black);
og.drawString$S$D$D(chiralText, imgWidth - 100, textYPosition);
}g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.jme.infoAreaImage.getImage$(), (screenArea.x|0), (screenArea.y|0), this.jme);
});

Clazz.newMeth(C$, 'draw$java_awt_Graphics',  function (g2d) {
this.ioMargin=3;
this.ioArrowWidth=(this.menuCellSize - 2 * this.ioMargin) / 1.5;
this.drawInfo$java_awt_Graphics(g2d);
this.drawTopMenu$java_awt_Graphics(g2d);
this.drawLeftMenu$java_awt_Graphics(g2d);
this.drawRightBorderImage$java_awt_Graphics(g2d);
});

Clazz.newMeth(C$, 'squareText$jme_canvas_PreciseGraphicsAWT$D$D$S',  function (g, xstart, ystart, text) {
var fm=C$.menuCellFontMet;
var w=fm.stringWidth$S(text);
if (w >= this.menuCellSize - 3 ) {
var font=fm.getFont$();
var size=font.getSize$();
while (w >= this.menuCellSize - 3  && size > 1 ){
--size;
var smallerFont=Clazz.new_([fm.getFont$().getName$(), fm.getFont$().getStyle$(), size],$I$(6,1).c$$S$I$I);
fm=this.jme.getFontMetrics$java_awt_Font(smallerFont);
w=fm.stringWidth$S(text);
g.setFont$java_awt_Font(smallerFont);
}
} else {
g.setFont$java_awt_Font(C$.menuCellFont);
}var h=C$.stringHeight$java_awt_FontMetrics(fm);
g.drawString$S$D$D(text, xstart + (this.menuCellSize - w) / 2, ystart + (this.menuCellSize - h) / 2 + h);
});

Clazz.newMeth(C$, 'squareTextBold$jme_canvas_PreciseGraphicsAWT$D$D$java_awt_Color$S',  function (g, xstart, ystart, col, text) {
var h=C$.stringHeight$java_awt_FontMetrics(C$.menuCellFontBoldMet);
var w=C$.menuCellFontBoldMet.stringWidth$S(text);
g.setFont$java_awt_Font(C$.menuCellFontBold);
g.setColor$java_awt_Color(col);
g.drawString$S$D$D(text, xstart + (this.menuCellSize - w) / 2, ystart + (this.menuCellSize - h) / 2 + h);
});

Clazz.newMeth(C$, 'drawRingIcon$jme_canvas_PreciseGraphicsAWT$D$D$I',  function (g, xstart, d, n) {
var m=this.menuCellSize / 4;
var ph=false;
var xp=Clazz.array(Double.TYPE, [9]);
var yp=Clazz.array(Double.TYPE, [9]);
var xcenter=xstart + this.menuCellSize / 2;
var ycenter=d + this.menuCellSize / 2;
var rc=this.menuCellSize / 2 - m / 2;
if (n == 1) {
n=6;
ph=true;
}for (var i=0; i <= n; i++) {
var uhol=6.283185307179586 / n * (i - 0.5);
xp[i]=xcenter + rc * Math.sin(uhol);
yp[i]=ycenter + rc * Math.cos(uhol);
}
g.drawPolygon$DA$DA$I(xp, yp, n + 1);
if (ph) {
for (var i=0; i <= n; i++) {
var uhol=6.283185307179586 / n * (i - 0.5);
xp[i]=xcenter + (rc - 3) * Math.sin(uhol);
yp[i]=ycenter + (rc - 3) * Math.cos(uhol);
}
g.drawLine$D$D$D$D(xp[0], yp[0], xp[1], yp[1]);
g.drawLine$D$D$D$D(xp[2], yp[2], xp[3], yp[3]);
g.drawLine$D$D$D$D(xp[4], yp[4], xp[5], yp[5]);
}});

Clazz.newMeth(C$, 'drawFullScreenIcon$jme_canvas_PreciseGraphicsAWT$D$jme_gui_GUI_Icon',  function (g, iconScale, rightIcon) {
var expand=!this.jme.isFullScreen$();
if (this.fullScreenIcon == null ) {
this.fullScreenIcon=Clazz.new_($I$(11,1).c$$jme_canvas_PreciseGraphicsAWT,[g]);
} else {
this.fullScreenIcon.pg=g;
}var margin=this.ioMargin * iconScale;
var iconHeight=this.ioArrowWidth * iconScale;
var rightX=g.getWidth$();
var graphicsContainerHeight=g.getHeight$();
if (rightIcon != null ) {
rightX=rightIcon.x;
iconHeight=rightIcon.height;
rightX-=2 * margin;
}var rectangleWidth=iconHeight * 16 / 9;
var startSize=1.0;
var endSize=0.3;
var startColor=0;
var endColor=1.0;
var steps=20;
var firstLoop=true;
for (var relativeSize=startSize; relativeSize >= endSize ; relativeSize-=(startSize - endSize) / steps) {
var c=((startSize - relativeSize) * (endColor - startColor) / (startSize - endSize));
if (!expand) {
c=endColor - c;
}var color=Clazz.new_($I$(8,1).c$$F$F$F,[c, c, 1.0]);
g.setColor$java_awt_Color(color);
var h=iconHeight * relativeSize;
var w=h / iconHeight * rectangleWidth;
var x=rightX - rectangleWidth + (rectangleWidth - w) / 2;
var y;
if (!this.jme.isDepict$()) {
y=graphicsContainerHeight / 2 - h / 2;
} else {
y=graphicsContainerHeight - iconHeight / 2 - h / 2;
}g.fillRect$D$D$D$D(x, y, w, h);
if (firstLoop) {
firstLoop=false;
this.fullScreenIcon.setRect$D$D$D$D(x, y, w, h);
}}
});

Clazz.newMeth(C$, 'menuCellBorder$',  function () {
return (this.jme.options.newLook ? 1 : 0);
});

Clazz.newMeth(C$, 'getFunctionalGroupPopumemu$',  function () {
if (this.functionalGroupPopumemu == null ) {
this.functionalGroupPopumemu=this.createFunctionalGroupPopumemu$();
}return this.functionalGroupPopumemu;
});

Clazz.newMeth(C$, 'createFunctionalGroupPopumemu$',  function () {
var popup=Clazz.new_($I$(13,1));
for (var eachFG, $eachFG = 0, $$eachFG = this.jme.functionalGroups; $eachFG<$$eachFG.length&&((eachFG=($$eachFG[$eachFG])),1);$eachFG++) {
var mi=Clazz.new_($I$(14,1).c$$S,[eachFG]);
popup.add$javax_swing_JMenuItem(mi);
mi.setActionCommand$S(eachFG);
mi.addActionListener$java_awt_event_ActionListener(this.jme);
}
this.jme.add$java_awt_Component(popup);
return popup;
});

Clazz.newMeth(C$, 'createFBackgroundColorPopumemu$',  function () {
var popup=Clazz.new_($I$(13,1));
for (var i=1; i < this.jme.colorManager.psColor.length; i++) {
var ci=this.jme.colorManager.getColorInfo$I(i);
var color=ci.color;
var label=ci.name;
var colorrHash=ci.hash;
;var mi=Clazz.new_([label + "\t" + $I$(15).makeHexColor$java_awt_Color(color) ],$I$(14,1).c$$S);
popup.add$javax_swing_JMenuItem(mi);
mi.setActionCommand$S(colorrHash);
mi.addActionListener$java_awt_event_ActionListener(this.jme);
}
this.jme.add$java_awt_Component(popup);
return popup;
});

Clazz.newMeth(C$, 'mustRedrawNSomething$',  function () {
return this.mustReDrawLeftMenu || this.mustReDrawTopMenu || this.mustReDrawMolecularArea || this.mustReDrawInfo || this.mustReDrawRightBorderImage  ;
});

Clazz.newMeth(C$, 'getScaledGraphicsOfPreciseImage$jme_canvas_PreciseImage$D$java_awt_geom_Rectangle2D_Double',  function (pi, scale, screenArea) {
var og=pi.getGraphics$D(true ? scale : 1);
og.setDrawOnScreenCoordinates$java_awt_geom_Rectangle2D_Double(screenArea);
return og;
}, 1);

Clazz.newMeth(C$, 'getAtomDrawingFont$',  function () {
return this.atomDrawingAreaFont;
});

Clazz.newMeth(C$, 'getAtomDrawingFontMetrics$',  function () {
return this.atomDrawingAreaFontMet;
});

Clazz.newMeth(C$, 'determineMenuAction$D$D$Z',  function (x, y, ignoreDisabledActions) {
var action=0;
x=Long.$ival(Math.round$D(x / this.jme.menuScale));
y=Long.$ival(Math.round$D(y / this.jme.menuScale));
if (x < this.jme.leftMenuWidth$D(1.0)  || y < this.jme.topMenuHeight$D(1.0)  ) {
var xbutton=0;
for (var i=1; i <= 14; i++) if (x < i * (this.menuCellSize + this.menuCellBorder$()) ) {
xbutton=i;
break;
}
var ybutton=0;
var n=this.jme.getLeftMenuCellCount$();
var h=this.menuCellSize + this.menuCellBorder$();
for (var i=1; i <= n + 2; i++) {
if (y < i * h ) {
ybutton=i;
break;
}}
if (xbutton > 0 && ybutton > 0 ) {
action=ybutton * 100 + xbutton;
}}if (ignoreDisabledActions) {
switch (action) {
case 109:
if (!this.jme.options.reaction) action=0;
break;
case 213:
if (!this.jme.options.fgMenuOption) action=0;
break;
case 105:
if (this.jme.options.starNothing) {
action=0;
}break;
}
}return action;
});

Clazz.newMeth(C$, 'handleMouseEnterActionMenu$I$jme_JMEmol',  function (action, mol) {
var note=null;
switch (action) {
case 103:
note="Add new molecule";
break;
case 113:
note="Move atom";
break;
case 213:
note="Add a functional group";
break;
case 112:
note="Activate spiro ring";
break;
case 201:
note="Stereo bond single or double";
break;
case 205:
note="Create alkyl chain";
break;
case 104:
note="Delete atom or bond";
break;
case 106:
note="Click bond to delete smallest fragment";
break;
case 101:
note="Show " + (this.jme.params.smilesParams.smarts ? "SMARTS" : "SMILES or SMIRKS");
break;
case 107:
note="Open query box for SMARTS";
break;
case 1201:
note="Select other atom type (" + this.jme.getAtomSymbolForX$() + ")" ;
break;
case 1301:
note="Select R group";
break;
}
if (note != null ) this.jme.infoNoLog$S(note);
if (mol == null  || mol.natoms == 0 ) {
return false;
}switch (action) {
case 102:
note=(this.jme.moleculePartsList.size$() > 1 ? "Delete selected molecule (red)" : "Clear canvas");
mol.forceUniColor$java_awt_Color($I$(8).RED);
this.uniColorMolecule=mol;
break;
case 109:
note="Copy selected (blue) molecule to the other side of the reaction";
mol.forceUniColor$java_awt_Color($I$(8).BLUE);
this.uniColorMolecule=mol;
}
if (note == null ) {
this.jme.setMustRedrawMolecularArea$Z(false);
this.mustReDrawTopMenu=false;
} else {
this.jme.info$S(note);
this.jme.setMustRedrawMolecularArea$Z(true);
this.mustReDrawTopMenu=true;
}return note != null ;
});

Clazz.newMeth(C$, 'handleMouseLeaveActionMenu$I',  function (action) {
switch (action) {
case 213:
case 103:
case 113:
case 112:
case 101:
case 107:
case 1201:
case 1301:
case 201:
case 205:
case 106:
case 104:
this.jme.clearInfo$();
return true;
}
if (this.uniColorMolecule != null  && (action == 102 || (this.jme.options.reaction && action == 109 ) ) ) {
this.uniColorMolecule.resetForceUniColor$();
this.uniColorMolecule=null;
for (var mol, $mol = this.jme.moleculePartsList.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
mol.resetForceUniColor$();
}
this.jme.clearInfo$();
this.jme.setMustRedrawMolecularArea$Z(true);
this.mustReDrawTopMenu=true;
} else {
this.jme.setMustRedrawMolecularArea$Z(false);
this.mustReDrawTopMenu=false;
}return this.mustReDrawMolecularArea;
});

Clazz.newMeth(C$, 'dispose$',  function () {
this.jme=null;
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
C$.isSwingJS=true ||false;
C$.copyRigthSmallTextFont=Clazz.new_($I$(6,1).c$$S$I$I,[null, 0, 8]);
C$.menuCellFont=Clazz.new_($I$(6,1).c$$S$I$I,["Helvetica", 0, 13]);
C$.menuCellFontBold=Clazz.new_($I$(6,1).c$$S$I$I,["Helvetica", 1, 13]);
C$.menuCellFontSmaller=Clazz.new_($I$(6,1).c$$S$I$I,["Helvetica", 0, 11]);
C$.atomDrawingAreaFontCache=Clazz.array($I$(6), [100]);
C$.atomDrawingAreaFontMetCache=Clazz.array($I$(7), [100]);
C$.atomMapDrawingAreaFontCache=Clazz.array($I$(6), [100]);
C$.atomMapDrawingAreaFontMetCache=Clazz.array($I$(7), [100]);
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.GUI, "Icon", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, ['java.awt.geom.Rectangle2D','.Double']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['pg','jme.canvas.PreciseGraphicsAWT']]]

Clazz.newMeth(C$, 'c$$jme_canvas_PreciseGraphicsAWT',  function (pg) {
Clazz.super_(C$, this);
this.pg=pg;
}, 1);

Clazz.newMeth(C$, 'contains$I$I',  function (screenX, screenY) {
return this.contains$D$D(this.pg.screenToCoordX$I(screenX), this.pg.screenToCoordY$I(screenY));
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.GUI, "RingComparator", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'java.util.Comparator');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.phase=0;
},1);

C$.$fields$=[['I',['phase']]]

Clazz.newMeth(C$, ['compare$jme_gui_GUI_Ring$jme_gui_GUI_Ring','compare$O$O'],  function (a, b) {
if (a.isAromatic != b.isAromatic ) {
return (a.isAromatic ? -1 : 1);
}if (a.bondCount != b.bondCount) {
return (a.bondCount > b.bondCount ? -1 : 1);
}if (a.size != b.size) {
return (a.size > b.size ? -1 : 1);
}if (a.isHetero != b.isHetero ) {
return (a.isHetero ? 1 : -1);
}return 0;
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.GUI, "Ring", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.bsBonds=Clazz.new_($I$(1,1));
this.bsAtoms=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['Z',['isAromatic','isHetero'],'D',['cx','cy'],'I',['bondCount','size'],'O',['bsBonds','java.util.BitSet','+bsAtoms']]]

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.GUI, "RingInfo", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.bsAromaticRings=Clazz.new_($I$(1,1));
this.bsAromaticBonds=Clazz.new_($I$(1,1));
this.rings=Clazz.new_($I$(2,1));
this.bsRingBonds=Clazz.new_($I$(1,1));
this.bsRingAtoms=Clazz.new_($I$(1,1));
this.bsAromaticAtoms=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['O',['bsAromaticRings','java.util.BitSet','+bsAromaticBonds','rings','java.util.List','bsRingBonds','java.util.BitSet','+bsRingAtoms','+bsAromaticAtoms']]]

Clazz.newMeth(C$, 'c$$jme_core_JMECore',  function (mol) {
;C$.$init$.apply(this);
var bsDouble=Clazz.new_($I$(1,1));
for (var i=1; i <= mol.nbonds; i++) {
var b=mol.bonds[i];
if (b.bondType == 2) {
bsDouble.set$I(i);
}b.guideX=NaN;
}
$I$(3).getOclAdapter$().getRingInfo$jme_gui_GUI_RingInfo$jme_core_JMECore(this, mol);
if (this.rings.size$() > 0) {
for (var i=0, n=this.rings.size$(); i < n; i++) {
var r=this.rings.get$I(i);
r.bsBonds.and$java_util_BitSet(bsDouble);
r.bondCount=r.bsBonds.cardinality$();
}
if ($I$(4).ringComparator == null ) $I$(4).ringComparator=Clazz.new_($I$(5,1));
this.rings.sort$java_util_Comparator($I$(4).ringComparator);
var bsBonds=Clazz.new_($I$(1,1));
var bsToDo=Clazz.new_($I$(1,1));
bsToDo.set$I$I(0, this.rings.size$());
p$1.removeDuplicates$java_util_BitSet$I$java_util_BitSet$Z.apply(this, [bsToDo, 3, bsBonds, true]);
p$1.removeDuplicates$java_util_BitSet$I$java_util_BitSet$Z.apply(this, [bsToDo, 2, bsBonds, true]);
p$1.removeDuplicates$java_util_BitSet$I$java_util_BitSet$Z.apply(this, [bsToDo, 1, bsBonds, true]);
p$1.removeDuplicates$java_util_BitSet$I$java_util_BitSet$Z.apply(this, [bsToDo, 3, bsBonds, false]);
p$1.removeDuplicates$java_util_BitSet$I$java_util_BitSet$Z.apply(this, [bsToDo, 2, bsBonds, false]);
p$1.removeDuplicates$java_util_BitSet$I$java_util_BitSet$Z.apply(this, [bsToDo, 1, bsBonds, false]);
for (var i=0, n=this.rings.size$(); i < n; i++) {
var r=this.rings.get$I(i);
r.bondCount=r.bsBonds.cardinality$();
}
for (var i=0, n=this.rings.size$(); i < n; i++) {
var r=this.rings.get$I(i);
var cx=0;
var cy=0;
for (var j=r.bsAtoms.nextSetBit$I(0); j >= 0; j=r.bsAtoms.nextSetBit$I(j + 1)) {
cx+=mol.atoms[j].x;
cy+=mol.atoms[j].y;
}
cx/=r.size;
cy/=r.size;
r.cx=cx;
r.cy=cy;
for (var j=r.bsBonds.nextSetBit$I(0); j >= 0; j=r.bsBonds.nextSetBit$I(j + 1)) {
mol.bonds[j].guideX=cx;
mol.bonds[j].guideY=cy;
}
}
}for (var i=1; i <= mol.nbonds; i++) {
var b=mol.bonds[i];
var type=b.bondType;
if (this.bsRingBonds.get$I(i)) {
b.smallRing=true;
if (type == 3) b.bondType=1;
} else {
b.smallRing=false;
}if (type == 2) {
if (!Double.isNaN$D(b.guideX)) {
continue;
}var a1=mol.atoms[b.va];
var a2=mol.atoms[b.vb];
if (a1.nv == 3 && a2.nv == 3 ) {
continue;
}if (a1.an != 3 || a2.an != 3 ) {
continue;
}if (a1.nv == 3 && a2.nv == 1  || a1.nv == 1 && a2.nv == 3  ) {
b.guideY=NaN;
}var ia1s1=mol.getSp2Other$I$I$Z(b.va, b.vb, true);
var ia2s1=mol.getSp2Other$I$I$Z(b.vb, b.va, true);
var ia1s2=(a1.nv == 2 ? 0 : mol.getSp2Other$I$I$Z(b.va, b.vb, false));
var ia2s2=(a2.nv == 2 ? 0 : mol.getSp2Other$I$I$Z(b.vb, b.va, false));
if (ia1s1 == 0 || ia2s1 == 0 ) {
continue;
}var n1=(ia1s2 == 0 ? 1 : 2);
var n2=(ia2s2 == 0 ? 1 : 2);
var gx=mol.atoms[ia1s1].x + mol.atoms[ia2s1].x + (n1 == 2 ? mol.atoms[ia1s2].x : 0) + (n2 == 2 ? mol.atoms[ia2s2].x : 0) ;
var gy=mol.atoms[ia1s1].y + mol.atoms[ia2s1].y + (n1 == 2 ? mol.atoms[ia1s2].y : 0) + (n2 == 2 ? mol.atoms[ia2s2].y : 0) ;
b.guideX=gx / (n1 + n2);
b.guideY=gy / (n1 + n2);
}}
}, 1);

Clazz.newMeth(C$, 'removeDuplicates$java_util_BitSet$I$java_util_BitSet$Z',  function (bsToDo, nBonds, bsBonds, checkIntersect) {
for (var i=bsToDo.nextSetBit$I(0); i >= 0; i=bsToDo.nextSetBit$I(i + 1)) {
var r=this.rings.get$I(i);
if (r.bondCount < nBonds) continue;
if (checkIntersect && r.bsBonds.intersects$java_util_BitSet(bsBonds) ) continue;
bsToDo.clear$I(i);
r.bsBonds.andNot$java_util_BitSet(bsBonds);
r.bondCount=r.bsBonds.cardinality$();
bsBonds.or$java_util_BitSet(r.bsBonds);
}
}, p$1);

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
