(function(){var P$=Clazz.newPackage("jme.gui"),I$=[[0,'javax.swing.JButton','java.awt.Point','jme.gui.FrameWithLocation','jme.JME','javax.swing.Box','javax.swing.border.EmptyBorder','javax.swing.JLabel','java.awt.Dimension','jme.gui.GUI','javax.swing.JPanel','java.net.URL','jme.gui.MultiBox','java.awt.BorderLayout','javax.swing.JTextField','java.awt.Desktop',['java.awt.Desktop','.Action']]],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MultiBox", null, 'jme.gui.FrameWithLocation');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.helpJButton=Clazz.new_($I$(1,1).c$$S,["Help"]);
this.homeJButton=Clazz.new_($I$(1,1).c$$S,["JSME home"]);
},1);

C$.$fields$=[['O',['aboutBoxPoint','java.awt.Point','+smilesBoxPoint','+atomxBoxPoint','helpJButton','javax.swing.JButton','+homeJButton','smilesText','javax.swing.JTextField','jme','jme.JME']]]

Clazz.newMeth(C$, 'c$$I$jme_JME',  function (box, jme) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
this.jme=jme;
this.setBackground$java_awt_Color(jme.bgColor);
this.setResizable$Z(false);
var jmeLocation=jme.getLocationOnScreen$();
switch (box) {
case 1:
if (this.smilesBoxPoint == null ) {
this.smilesBoxPoint=Clazz.new_($I$(2,1).c$$java_awt_Point,[jmeLocation]);
$I$(3).safeTranslate$java_awt_Point$I$I(this.smilesBoxPoint, -30, 0);
}this.lastLocation=this.smilesBoxPoint;
this.initSmilesBox$S(jme.getSmiles$());
break;
case 2:
if (this.atomxBoxPoint == null ) {
this.atomxBoxPoint=Clazz.new_($I$(2,1).c$$java_awt_Point,[jmeLocation]);
$I$(3,"safeTranslate$java_awt_Point$I$I",[this.atomxBoxPoint, -50, (jme.gui.menuCellSize|0) * 13 - 80]);
}this.lastLocation=this.atomxBoxPoint;
this.initAtomxBox$();
break;
case 0:
if (this.aboutBoxPoint == null ) {
this.aboutBoxPoint=Clazz.new_($I$(2,1).c$$java_awt_Point,[jmeLocation]);
$I$(3,"safeTranslate$java_awt_Point$I$I",[this.aboutBoxPoint, (jme.gui.menuCellSize|0) * 5, 0]);
}this.initAboutBox$();
this.lastLocation=this.aboutBoxPoint;
break;
}
this.pack$();
this.setVisible$Z(true);
switch (box) {
case 1:
this.smilesText.select$I$I(0, 1000);
break;
case 2:
jme.atomicSymbol.select$I$I(0, 1000);
break;
case 0:
break;
}
}, 1);

Clazz.newMeth(C$, 'initAboutBox$',  function () {
this.setTitle$S("About " + $I$(4).programName);
this.setBackground$java_awt_Color(this.jme.bgColor);
var pane=this.getContentPane$();
var b=Clazz.new_($I$(5,1).c$$I,[1]);
b.setBorder$javax_swing_border_Border(Clazz.new_($I$(6,1).c$$I$I$I$I,[10, 10, 10, 10]));
b.add$java_awt_Component(Clazz.new_([$I$(4).programName + " Molecular Editor" + " v" + "2024-12-13" ],$I$(7,1).c$$S));
b.add$java_awt_Component(Clazz.new_($I$(7,1).c$$S,["Peter Ertl, Bruno Bienfait"]));
b.add$java_awt_Component(Clazz.new_($I$(7,1).c$$S,["and Robert Hanson"]));
b.add$java_awt_Component($I$(5,"createRigidArea$java_awt_Dimension",[Clazz.new_($I$(8,1).c$$I$I,[10, 10])]));
for (var cl, $cl = 0, $$cl = $I$(4).copyright; $cl<$$cl.length&&((cl=($$cl[$cl])),1);$cl++) {
var l=Clazz.new_($I$(7,1).c$$S,[cl]);
l.setFont$java_awt_Font($I$(9).copyRigthSmallTextFont);
b.add$java_awt_Component(l);
}
for (var i=0; i < b.getComponentCount$(); i++) (b.getComponent$I(i)).setAlignmentX$F(0.5);

pane.add$S$java_awt_Component("Center", b);
var p=Clazz.new_($I$(10,1));
p.add$java_awt_Component(this.helpJButton);
p.add$java_awt_Component(this.homeJButton);
this.helpJButton.addActionListener$java_awt_event_ActionListener(((P$.MultiBox$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "MultiBox$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
try {
var u=Clazz.new_($I$(11,1).c$$S,["https://jsme-editor.github.io/help.html"]);
$I$(12).showURL$java_net_URL(u);
} catch (urlException) {
if (Clazz.exceptionOf(urlException,"Exception")){
System.out.println$S(urlException.getMessage$());
this.b$['jme.gui.MultiBox'].jme.showError$S(urlException.getMessage$());
} else {
throw urlException;
}
}
});
})()
), Clazz.new_(P$.MultiBox$1.$init$,[this, null])));
this.homeJButton.addActionListener$java_awt_event_ActionListener(((P$.MultiBox$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "MultiBox$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
try {
var u=Clazz.new_($I$(11,1).c$$S,["https://jsme-editor.github.io/"]);
$I$(12).showURL$java_net_URL(u);
} catch (urlException) {
if (Clazz.exceptionOf(urlException,"Exception")){
System.out.println$S(urlException.getMessage$());
this.b$['jme.gui.MultiBox'].jme.showError$S(urlException.getMessage$());
} else {
throw urlException;
}
}
});
})()
), Clazz.new_(P$.MultiBox$2.$init$,[this, null])));
p.add$java_awt_Component(this.closeJButton);
pane.add$S$java_awt_Component("South", p);
});

Clazz.newMeth(C$, 'initSmilesBox$S',  function (smiles) {
this.setTitle$S("SMILES");
this.setLayout$java_awt_LayoutManager(Clazz.new_($I$(13,1).c$$I$I,[2, 0]));
this.smilesText=Clazz.new_($I$(14,1).c$$S,[smiles + "     "]);
if (!this.jme.options.runsmi) {
}this.add$S$java_awt_Component("Center", this.smilesText);
var p=Clazz.new_($I$(10,1));
p.add$java_awt_Component(this.closeJButton);
if (this.jme.options.runsmi) {
var b=Clazz.new_($I$(1,1).c$$S,["Submit"]);
p.add$java_awt_Component(b);
b.addActionListener$java_awt_event_ActionListener(((P$.MultiBox$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "MultiBox$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.gui.MultiBox'].submitSmiles$S.apply(this.b$['jme.gui.MultiBox'], [this.b$['jme.gui.MultiBox'].smilesText.getText$()]);
});
})()
), Clazz.new_(P$.MultiBox$3.$init$,[this, null])));
}this.add$S$java_awt_Component("South", p);
this.smilesText.setText$S(this.smilesText.getText$().trim$());
this.setResizable$Z(true);
});

Clazz.newMeth(C$, 'submitSmiles$S',  function (smiles) {
try {
this.jme.readMolFile$S(this.jme.SMILEStoMOL$S(smiles));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'setSmiles$S',  function (smiles) {
var d=this.getSize$();
var l=$I$(9).menuCellFontSmallerMet.stringWidth$S(smiles) + 50;
if (l < 150) l=150;
if (l > 400) l=400;
this.validate$();
this.setSize$I$I(l, d.height);
this.smilesText.setText$S(smiles);
});

Clazz.newMeth(C$, 'initAtomxBox$',  function () {
this.setTitle$S("Nonstandard atom");
this.setLayout$java_awt_LayoutManager(Clazz.new_($I$(13,1).c$$I$I,[2, 0]));
var p=Clazz.new_($I$(10,1));
p.add$java_awt_Component(Clazz.new_($I$(7,1).c$$S$I,["atomic SMILES", 0]));
this.add$S$java_awt_Component("North", p);
this.add$S$java_awt_Component("Center", this.jme.atomicSymbol);
p=Clazz.new_($I$(10,1));
p.add$java_awt_Component(this.closeJButton);
this.add$S$java_awt_Component("South", p);
});

Clazz.newMeth(C$, 'keyDown$java_awt_event_KeyEvent$I',  function (e, key) {
this.jme.dialogActionX$();
return false;
});

Clazz.newMeth(C$, 'showURL$java_net_URL',  function (url) {
var desktop=$I$(15).isDesktopSupported$() ? $I$(15).getDesktop$() : null;
if (desktop != null  && desktop.isSupported$java_awt_Desktop_Action($I$(16).BROWSE) ) {
desktop.browse$java_net_URI(url.toURI$());
}}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
