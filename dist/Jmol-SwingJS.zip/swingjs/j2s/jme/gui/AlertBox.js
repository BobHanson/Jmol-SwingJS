(function(){var P$=Clazz.newPackage("jme.gui"),I$=[[0,'java.awt.GridLayout','javax.swing.JLabel','javax.swing.JPanel','jme.gui.FrameWithLocation']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AlertBox", null, 'jme.gui.FrameWithLocation');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$S$java_awt_Component$java_awt_Color',  function (msg, source, backgroundColor) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
this.setResizable$Z(false);
this.setLayout$java_awt_LayoutManager(Clazz.new_($I$(1,1).c$$I$I$I$I,[0, 1, 0, 0]));
var label=Clazz.new_($I$(2,1).c$$S$I,[msg, 0]);
this.add$java_awt_Component(label);
var p=Clazz.new_($I$(3,1));
p.add$java_awt_Component(this.closeJButton);
this.add$java_awt_Component(p);
if (source != null ) {
this.lastLocation=source.getLocationOnScreen$();
this.pack$();
$I$(4,"safeTranslate$java_awt_Point$I$I",[this.lastLocation, (source.getWidth$()/2|0) - (this.getWidth$()/2|0), (source.getHeight$()/2|0) - (this.getHeight$()/2|0)]);
}if (backgroundColor != null ) {
this.setBackground$java_awt_Color(backgroundColor);
}}, 1);

Clazz.newMeth(C$, 'closeJButtonJLabel$',  function () {
return "OK";
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
