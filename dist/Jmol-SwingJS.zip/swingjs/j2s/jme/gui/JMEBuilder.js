(function(){var P$=Clazz.newPackage("jme.gui"),p$1={},p$2={},I$=[[0,'jme.core.JMECore',['jme.gui.JMEBuilder','.GroupTemplateBondDirection'],['jme.core.JMECore','.Parameters'],'jme.JMEmol',['jme.io.JMEReader','.SupportedInputFileFormat']]],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JMEBuilder", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['GroupTemplateBondDirection',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.spiroAdding=false;
},1);

C$.$fields$=[['Z',['spiroAdding','spiroMode','linearAdding'],'I',['touchedAtom','touchedBond','action'],'S',['templateString'],'O',['jme','jme.JME','mol','jme.JMEmol','atoms','jme.core.Atom[]','bonds','jme.core.Bond[]','templateMolecule','jme.JMEmol']]]

Clazz.newMeth(C$, 'c$$jme_JME',  function (jme) {
;C$.$init$.apply(this);
this.jme=jme;
}, 1);

Clazz.newMeth(C$, 'set$jme_JMEmol$I$Z',  function (mol, action, spiroMode) {
if (mol != null ) {
this.mol=mol;
this.atoms=mol.atoms;
this.bonds=mol.bonds;
this.touchedAtom=mol.touchedAtom;
this.touchedBond=mol.touchedBond;
this.action=action;
this.spiroMode=spiroMode;
}return this;
});

Clazz.newMeth(C$, 'addBond$',  function () {
this.mol.addBondToAtom$I$I$I$Z(this.action, this.touchedAtom, 0, false);
this.bonds=this.mol.bonds;
});

Clazz.newMeth(C$, 'addRing$',  function () {
var atom1;
var atom2;
var atom3;
var dx;
var dy;
var rx;
var sina;
var cosa;
var xx;
var yy;
var diel;
var rc;
var uhol;
var xstart;
var ystart;
var returnTouch=-1;
var nmembered=6;
switch (this.action) {
case 206:
nmembered=3;
break;
case 207:
nmembered=4;
break;
case 208:
case 221:
case 223:
nmembered=5;
break;
case 210:
case 209:
nmembered=6;
break;
case 211:
nmembered=7;
break;
case 212:
nmembered=8;
break;
case 229:
nmembered=9;
break;
}
diel=6.283185307179586 / nmembered;
rc=Math.sqrt(625.0 / 2.0 / (1.0 - Math.cos(diel)));
var a=this.atoms[this.touchedAtom];
var b=this.bonds[this.touchedBond];
if (this.touchedAtom > 0) {
if (a.nv < 2) {
this.addRingToBond$I$D$D(nmembered, diel, rc);
} else if (this.spiroMode || this.spiroAdding ) {
this.spiroAdding=false;
if (this.action == 209 || this.action == 221  || this.action == 223 ) {
this.mol.failed$S("ERROR - cannot add aromatic spiro ring !");
return;
}for (var i=1; i <= a.nv; i++) {
var bo=this.mol.getBond$I$I(this.touchedAtom, a.v[i]).bondType;
if (i > 2 || bo != 1 ) {
this.mol.failed$S("ERROR - spiro ring not possible here !");
return;
}}
var newPoint=Clazz.array(Double.TYPE, [2]);
this.mol.getNewPoint$I$D$DA(this.touchedAtom, rc, newPoint);
dx=a.x - newPoint[0];
dy=a.y - newPoint[1];
rx=Math.sqrt(dx * dx + dy * dy);
if (rx < 0.001 ) rx=0.001;
sina=dy / rx;
cosa=dx / rx;
for (var i=1; i <= nmembered; i++) {
var newAtom=p$2.createAtom.apply(this, []);
uhol=diel * i + 1.5707963267948966;
$I$(1,"XY$jme_core_Atom$D$D",[newAtom, newPoint[0] + rc * (Math.sin(uhol) * cosa - Math.cos(uhol) * sina), newPoint[1] + rc * (Math.cos(uhol) * cosa + Math.sin(uhol) * sina)]);
}
} else {
returnTouch=this.touchedAtom;
this.jme.setLastAction$I(2);
this.addBond$();
this.touchedAtom=this.mol.natoms;
this.addRingToBond$I$D$D(nmembered, diel, rc);
}} else if (this.touchedBond > 0) {
var revert;
atom1=b.va;
atom2=b.vb;
var a1=this.atoms[atom1];
var a2=this.atoms[atom2];
atom3=0;
if (a1.nv == 2) {
if (a1.v[1] != atom2) atom3=a1.v[1];
 else atom3=a1.v[2];
} else if (a2.nv == 2) {
if (a2.v[1] != atom1) atom3=a2.v[1];
 else atom3=a2.v[2];
revert=atom1;
atom1=atom2;
atom2=revert;
}if (atom3 == 0) if (a1.v[1] != atom2) atom3=a1.v[1];
 else atom3=a1.v[2];
dx=a2.x - a1.x;
dy=a2.y - a1.y;
rx=Math.sqrt(dx * dx + dy * dy);
if (rx < 0.001 ) rx=0.001;
sina=dy / rx;
cosa=dx / rx;
xx=rx / 2.0;
yy=rc * Math.sin((3.141592653589793 - diel) * 0.5);
revert=1;
var a3=this.atoms[atom3];
if (((a3.y - a1.y) * cosa - (a3.x - a1.x) * sina) > 0.0 ) {
yy=-yy;
revert=0;
}xstart=a1.x + xx * cosa - yy * sina;
ystart=a1.y + yy * cosa + xx * sina;
for (var i=1; i <= nmembered; i++) {
var newAtom=p$2.createAtom.apply(this, []);
uhol=diel * (i + 0.5) + 3.141592653589793 * revert;
$I$(1,"XY$jme_core_Atom$D$D",[newAtom, xstart + rc * (Math.sin(uhol) * cosa - Math.cos(uhol) * sina), ystart + rc * (Math.cos(uhol) * cosa + Math.sin(uhol) * sina)]);
if (revert == 1) {
if (i == nmembered) {
$I$(1).XY$jme_core_Atom$D$D(newAtom, a1.x, a1.y);
}if (i == nmembered - 1) {
$I$(1).XY$jme_core_Atom$D$D(newAtom, a2.x, a2.y);
}} else {
if (i == nmembered - 1) {
$I$(1).XY$jme_core_Atom$D$D(newAtom, a1.x, a1.y);
}if (i == nmembered) {
$I$(1).XY$jme_core_Atom$D$D(newAtom, a2.x, a2.y);
}}}
} else {
var helpv=0.5;
if (nmembered == 6) helpv=0.0;
for (var i=1; i <= nmembered; i++) {
var newAtom=p$2.createAtom.apply(this, []);
uhol=diel * (i - helpv);
$I$(1,"XY$jme_core_Atom$D$D",[newAtom, this.mol.xorg + rc * Math.sin(uhol), this.mol.yorg + rc * Math.cos(uhol)]);
}
}this.completeRing$I(nmembered);
p$2.checkRing$I.apply(this, [nmembered]);
this.mol.setBondCenters$();
if (returnTouch > -1) this.touchedAtom=returnTouch;
});

Clazz.newMeth(C$, 'addRingToBond$I$D$D',  function (nmembered, diel, rc) {
var sina;
var cosa;
var dx;
var dy;
var rx;
var uhol;
var atom1=0;
var a=this.atoms[this.touchedAtom];
if (a.nv == 0) {
sina=0.0;
cosa=1.0;
} else {
atom1=a.v[1];
dx=a.x - this.mol.x$I(atom1);
dy=a.y - this.mol.y$I(atom1);
rx=Math.sqrt(dx * dx + dy * dy);
if (rx < 0.001 ) rx=0.001;
sina=dy / rx;
cosa=dx / rx;
}var xstart=a.x + rc * cosa;
var ystart=a.y + rc * sina;
for (var i=1; i <= nmembered; i++) {
var newAtom=p$2.createAtom.apply(this, []);
uhol=diel * i - 1.5707963267948966;
newAtom.XY$D$D(xstart + rc * (Math.sin(uhol) * cosa - Math.cos(uhol) * sina), ystart + rc * (Math.cos(uhol) * cosa + Math.sin(uhol) * sina));
}
});

Clazz.newMeth(C$, 'completeRing$I',  function (nmembered) {
var atom=0;
var atom3;
var b=null;
for (var i=1; i <= nmembered; i++) {
b=p$2.createAndAddNewBond.apply(this, []);
atom=this.mol.natoms - nmembered + i;
this.mol.NV$I$I(atom, 2);
b.va=atom;
b.vb=atom + 1;
}
b.vb=this.mol.natoms - nmembered + 1;
b=this.bonds[this.touchedBond];
if (this.action == 209) {
if (this.touchedBond > 0) {
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [2, 1, 2, 1, 2])]);
if (b.isSingle$()) {
atom3=0;
if (this.mol.nv$I(b.va) > 1) {
atom3=this.mol.v$I(b.va)[1];
atom=b.va;
if (atom3 == b.vb) atom3=this.mol.v$I(b.va)[2];
}if (atom3 == 0 && this.mol.nv$I(b.vb) > 1 ) {
atom3=this.mol.v$I(b.vb)[1];
atom=b.vb;
if (atom3 == b.vb) atom3=this.mol.v$I(b.vb)[2];
}if (atom3 > 0) {
for (var i=1; i <= this.mol.nbonds; i++) {
if (this.bonds[i].isAB$I$I(atom, atom3)) {
if (!this.bonds[i].isSingle$()) {
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [2, 1, 2, 1, 3, 1])]);
}break;
}}
}} else {
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [2, 1, 2, 1, 2, 1])]);
}} else {
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [2, 1, 2, 1, 2])]);
}} else if (this.action == 221 || this.action == 223 ) {
if (this.touchedBond > 0) {
if (b.bondType == 1) {
var va=this.atoms[b.va];
var vb=this.atoms[b.vb];
var isConjugated=false;
for (var i=1; i <= va.nv; i++) {
if (this.mol.getBond$I$I(b.va, va.v[i]).bondType > 1) {
isConjugated=true;
break;
}}
for (var i=1; i <= this.mol.nv$I(b.vb); i++) {
var ax=vb.v[i];
if (this.mol.getBond$I$I(b.vb, ax).bondType > 1) {
isConjugated=true;
break;
}}
if (!isConjugated) b.bondType=2;
}this.bonds[this.mol.nbonds - 4].bondType=2;
this.mol.AN$I$I(this.mol.natoms - 2, 5);
} else if (this.touchedAtom > 0) {
if (this.action == 221) {
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [1, 2, 1, 1, 2])]);
this.mol.AN$I$I(this.mol.natoms - 1, 5);
} else {
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [2, 1, 1, 2, 1])]);
this.mol.AN$I$I(this.mol.natoms - 2, 5);
}} else {
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [2, 1, 1, 2, 1])]);
this.mol.AN$I$I(this.mol.natoms - 2, 5);
}}});

Clazz.newMeth(C$, 'createAndAddNewBond$I$I$I',  function (a, b, bondType) {
var bond=this.mol.createAndAddNewBond$I$I$I(a, b, bondType);
this.bonds=this.mol.bonds;
return bond;
}, p$2);

Clazz.newMeth(C$, 'createAndAddNewBond',  function () {
var b=this.mol.createAndAddBondFromOther$jme_core_Bond(null);
this.bonds=this.mol.bonds;
return b;
}, p$2);

Clazz.newMeth(C$, 'createAtom',  function () {
var a=this.mol.createAtom$();
this.atoms=this.mol.atoms;
return a;
}, p$2);

Clazz.newMeth(C$, 'createAtom$D$D',  function (x, y) {
p$2.createAtom.apply(this, []);
this.mol.nbonds=0;
this.mol.XY$I$D$D(1, x, y);
this.touchedAtom=this.mol.touchedAtom=1;
this.mol.touched_org=1;
}, p$2);

Clazz.newMeth(C$, 'checkRing$I',  function (nmembered) {
var parent=Clazz.array(Integer.TYPE, [this.mol.natoms + 1]);
for (var i=1; i <= nmembered; i++) {
var ratom=this.mol.natoms - nmembered + i;
var rbond=this.mol.nbonds - nmembered + i;
this.atoms[ratom].v[1]=ratom - 1;
this.atoms[ratom].v[2]=ratom + 1;
this.mol.setBondCenter$jme_core_Bond(this.bonds[rbond]);
}
var n=this.mol.natoms;
this.mol.v$I(n - nmembered + 1)[1]=n;
this.mol.v$I(n)[2]=n - nmembered + 1;
for (var i=this.mol.natoms - nmembered + 1; i <= this.mol.natoms; i++) {
parent[i]=0;
var a=this.atoms[i];
var min=51;
var tooCloseAtom=0;
for (var j=1; j <= this.mol.natoms - nmembered; j++) {
var b=this.atoms[j];
var dx=a.x - b.x;
var dy=a.y - b.y;
var rx=dx * dx + dy * dy;
if (rx < 50 ) if (rx < min ) {
min=rx;
tooCloseAtom=j;
}}
if (tooCloseAtom > 0) if (this.touchedAtom == 0 || tooCloseAtom == this.touchedAtom ) parent[i]=tooCloseAtom;
}
var noldbonds=this.mol.nbonds - nmembered;
 bloop : for (var i=noldbonds + 1; i <= noldbonds + nmembered; i++) {
var atom1=this.bonds[i].va;
var atom2=this.bonds[i].vb;
var p1=parent[atom1];
var p2=parent[atom2];
if (p1 > 0 && p2 > 0 ) {
for (var k=1; k <= noldbonds; k++) {
if (this.bonds[k].isAB$I$I(p1, p2)) continue bloop;
}
p$2.createAndAddNewBond$I$I$I.apply(this, [p1, p2, this.bonds[i].bondType]);
} else if (p1 > 0) {
p$2.createAndAddNewBond$I$I$I.apply(this, [p1, atom2, this.bonds[i].bondType]);
} else if (p2 > 0) {
p$2.createAndAddNewBond$I$I$I.apply(this, [p2, atom1, this.bonds[i].bondType]);
}}
var noldatoms=this.mol.natoms - nmembered;
for (var i=this.mol.natoms; i > noldatoms; i--) {
var pi=parent[i];
if (pi > 0) {
this.mol.deleteAtom$I(i);
if (this.atoms[pi].an == 3) {
var sum=0;
for (var j=1; j <= this.atoms[pi].nv; j++) {
var aj=this.atoms[pi].v[j];
for (var k=1; k <= this.mol.nbonds; k++) {
var b=this.bonds[k];
if (b.isAB$I$I(pi, aj)) sum+=b.bondType;
}
}
if (sum > 4) {
for (var k=noldbonds + 1; k <= noldbonds + nmembered; k++) this.bonds[k].bondType=1;

}}}}
if (this.touchedAtom > 0) this.mol.avoidTouch$I(nmembered);
}, p$2);

Clazz.newMeth(C$, 'addGroupTemplate$Z',  function (emptyCanvas) {
var tmol=this.templateMolecule;
if (tmol == null  || tmol.natoms == 0 ) return 0;
var mark1=0;
mark1=tmol.findFirstMappdedOrMarkedAtom$();
if (mark1 == 0) {
mark1=1;
}var nn=this.mol.natoms;
var source=this.touchedAtom;
var bd=Clazz.new_($I$(2,1));
var hasTwoPossibleAddAngle=bd.initBondCreate$jme_JMEmol$I$I(this.mol, source, 1);
var alternativeBD=null;
if (hasTwoPossibleAddAngle) {
alternativeBD=Clazz.new_($I$(2,1));
alternativeBD.initBondCreate$jme_JMEmol$I$I(this.mol, source, -1);
}var templateBD=Clazz.new_($I$(2,1));
templateBD.initBondCreate$jme_JMEmol$I$I(tmol, mark1, 0);
this.mol.addOtherMolToMe$jme_JMEmol(tmol);
this.mol.complete$Z(this.mol.parameters.computeValenceState);
this.atoms[nn + mark1].resetMap$();
if (!emptyCanvas) {
templateBD.moveAndRotateFragment$jme_JMEmol$I$I$I$jme_gui_JMEBuilder_GroupTemplateBondDirection(this.mol, nn + 1, this.mol.natoms, source, bd);
if (hasTwoPossibleAddAngle) {
var closeContactFactor=bd.sumAtomTooCloseContactsOfAddedFragment$I$I(nn + 1, this.mol.natoms);
for (var ta=1; ta <= tmol.natoms; ta++) {
this.mol.XY$I$D$D(nn + ta, tmol.x$I(ta), tmol.y$I(ta));
}
templateBD.moveAndRotateFragment$jme_JMEmol$I$I$I$jme_gui_JMEBuilder_GroupTemplateBondDirection(this.mol, nn + 1, this.mol.natoms, source, alternativeBD);
var alternativecloseContactFactor=bd.sumAtomTooCloseContactsOfAddedFragment$I$I(nn + 1, this.mol.natoms);
if (alternativecloseContactFactor <= closeContactFactor ) {
} else {
for (var ta=1; ta <= tmol.natoms; ta++) {
this.mol.XY$I$D$D(nn + ta, tmol.x$I(ta), tmol.y$I(ta));
}
templateBD.moveAndRotateFragment$jme_JMEmol$I$I$I$jme_gui_JMEBuilder_GroupTemplateBondDirection(this.mol, nn + 1, this.mol.natoms, source, bd);
}}}p$2.createAndAddNewBond.apply(this, []);
this.bonds[this.mol.nbonds].va=source;
this.bonds[this.mol.nbonds].vb=mark1 + nn;
if (emptyCanvas) {
this.mol.deleteAtom$I(source);
this.mol.center$();
}this.mol.complete$Z(this.mol.parameters.computeValenceState);
return tmol.natoms;
});

Clazz.newMeth(C$, 'addGroup$Z',  function (emptyCanvas) {
this.mol.touched_org=this.touchedAtom;
var nadded=0;
switch (this.action) {
case 2033:
case 2037:
case 2036:
case 2039:
case 2051:
case 2052:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom, 2147483647, 0, -2147483648, -1, -2])]);
switch (this.action) {
case 2037:
p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [10, 10, 10])]);
break;
case 2036:
p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [9, 9, 9])]);
break;
case 2039:
p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [8, 5, 5, 5])]);
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [1, 1, 2, 2])]);
break;
case 2052:
p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [8, 4, 5, 5])]);
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [1, 1, 2, 2])]);
break;
case 2051:
p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [7, 5, 5, 5])]);
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [1, 1, 1, 2])]);
break;
}
nadded=4;
break;
case 2044:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom, 0, 2147483647, 0, -2147483648, -1, -2])]);
nadded=p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [4, 8, 3, 5, 5])]);
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [1, 1, 1, 2, 2])]);
break;
case 2034:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom, 0, -1])]);
nadded=p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [4, 5, 5])]);
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [1, 2, this.jme.options.polarnitro ? 1 : 2])]);
if (this.jme.options.polarnitro) {
p$2.setCharges$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [-1])]);
}break;
case 2035:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom, 0, -1])]);
nadded=p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [3, 5, 5])]);
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [1, 1, 2])]);
break;
case 2040:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom, 0, 0, -2])]);
nadded=p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [3, 5, 3, 5])]);
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [2])]);
break;
case 2060:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom, 0, -1])]);
nadded=p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [3, 4, 5])]);
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [2])]);
break;
case 2061:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom, 0, 0])]);
nadded=p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [4, 3, 5])]);
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [2])]);
break;
case 2041:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom, 0, 0, -1])]);
nadded=p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [5, 3, 3, 5])]);
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [2])]);
break;
case 2043:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom, 0, -1])]);
nadded=p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [4, 3, 3])]);
break;
case 2038:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom, 2147483647, 0, -2147483648])]);
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [3])]);
nadded=2;
break;
case 2049:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom, 0])]);
nadded=p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [3, 5])]);
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [2])]);
break;
case 2050:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom])]);
nadded=p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [5])]);
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [2])]);
break;
case 2045:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom, 2147483647, 0, 0, -2147483648])]);
nadded=p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [3, 3, 3])]);
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [3, 1])]);
break;
case 2042:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom, 2147483647, 0, -2147483648])]);
nadded=p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [3, 4])]);
p$2.setBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [3])]);
break;
case 2054:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom])]);
nadded=p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [9])]);
break;
case 2055:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom])]);
nadded=p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [10])]);
break;
case 2056:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom])]);
nadded=p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [11])]);
break;
case 2057:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom])]);
nadded=p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [12])]);
break;
case 2058:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom])]);
nadded=p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [4])]);
break;
case 2059:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom])]);
nadded=p$2.setAtoms$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [5])]);
break;
case 2046:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom, 0])]);
break;
case 2047:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom, 0, 0])]);
break;
case 2048:
p$2.addBonds$IA.apply(this, [Clazz.array(Integer.TYPE, -1, [this.touchedAtom, 0, 0, 0])]);
break;
case 2053:
nadded=this.addGroupTemplate$Z(emptyCanvas);
break;
}
this.mol.avoidTouch$I(nadded);
if (emptyCanvas) this.mol.touchedAtom=0;
});

Clazz.newMeth(C$, 'addBonds$IA',  function (b) {
for (var i=0; i < b.length; i++) {
var mode=b[i];
switch (mode) {
case 2147483647:
this.linearAdding=true;
break;
case -2147483648:
this.linearAdding=false;
break;
default:
this.mol.addBondToAtom$I$I$I$Z(0, mode > 0 ? mode : this.mol.natoms + mode, 0, this.linearAdding);
this.bonds=this.mol.bonds;
break;
}
}
}, p$2);

Clazz.newMeth(C$, 'setBonds$IA',  function (bo) {
for (var i=0, pt=this.mol.nbonds - bo.length + 1; i < bo.length; i++) {
this.mol.bonds[pt++].bondType=bo[i];
}
}, p$2);

Clazz.newMeth(C$, 'setAtoms$IA',  function (an) {
var n=an.length;
for (var i=0, pt=this.mol.natoms - n + 1; i < n; i++) {
this.mol.atoms[pt++].an=an[i];
}
return n;
}, p$2);

Clazz.newMeth(C$, 'setCharges$IA',  function (ch) {
for (var i=0, pt=this.mol.natoms - ch.length + 1; i < ch.length; i++) {
this.mol.atoms[pt++].q=ch[i];
}
}, p$2);

Clazz.newMeth(C$, 'setTemplate$S',  function (t) {
this.templateString=t;
var pars=Clazz.new_($I$(3,1));
pars.mark=true;
this.templateMolecule=Clazz.new_([this.jme, t, $I$(5).JME, pars],$I$(4,1).c$$jme_JME$O$jme_io_JMEReader_SupportedInputFileFormat$jme_core_JMECore_Parameters);
this.templateMolecule.internalBondLengthScaling$();
if (!this.templateMolecule.hasMappedOrMarkedAtom$()) {
return "template molecule has no mapped atom";
}return null;
});

Clazz.newMeth(C$, 'getTemplateString$',  function () {
return this.templateString;
});

Clazz.newMeth(C$, 'checkBondAction$',  function () {
var event=null;
var cleanPolar=false;
var b=this.mol.bonds[this.mol.touchedBond];
switch (this.action) {
case 104:
this.deleteAtomOrBond$();
this.jme.updatePartsList$();
break;
case 106:
this.mol.deleteAtomGroup$();
cleanPolar=true;
this.mol.touchedBond=0;
event="delBondGroup";
break;
case 201:
this.mol.toggleBondStereo$I(this.mol.touchedBond);
event="setBondStereo";
break;
case 202:
case 205:
if (b.bondType == 1 && b.stereo == 0 ) {
b.bondType=2;
event="setBondDouble";
} else {
b.bondType=1;
b.stereo=0;
event="setBondSingle";
}b.stereo=0;
break;
case 203:
var differentBondOrder=b.bondType != 2;
b.bondType=2;
if (!differentBondOrder) {
this.mol.toggleDoubleBondStereo$jme_core_Bond(b);
} else {
b.stereo=0;
}cleanPolar=true;
event="setBondDouble";
break;
case 204:
if (!b.smallRing) {
b.bondType=3;
b.stereo=0;
cleanPolar=true;
event="setBondTriple";
}break;
default:
if (this.action >= 206 && this.action <= 229 ) {
this.jme.setLastAction$I(2);
this.addRing$();
cleanPolar=true;
event="addRingBond";
}break;
}
if (cleanPolar) this.mol.cleanAfterChanged$Z(this.jme.options.polarnitro);
if (event != null ) this.jme.recordBondEvent$S$I(event, this.mol.touchedBond);
});

Clazz.newMeth(C$, 'checkAtomOrBondAction$',  function () {
if (this.touchedAtom > 0) this.checkAtomAction$();
 else if (this.touchedBond > 0) this.checkBondAction$();
});

Clazz.newMeth(C$, 'checkAtomAction$',  function () {
var event=null;
if (this.action == 104) {
this.deleteAtomOrBond$();
this.jme.updatePartsList$();
} else if (this.action == 106) {
return;
} else if (this.action == 108) {
if (this.mol.changeCharge$I$I(this.mol.touchedAtom, 0)) event="chargeAtom0";
} else if (this.action == 202 || this.action == 203  || this.action == 204  || this.action == 201  || this.action == 205 ) {
this.jme.setLastAction$I(1);
this.addBond$();
this.mol.touched_org=this.mol.touchedAtom;
if (this.action == 205) {
this.mol.nchain=1;
this.mol.chain[1]=this.mol.natoms;
this.mol.chain[0]=this.mol.touchedAtom;
this.mol.touchedBond=0;
this.jme.willPostSave$Z(false);
} else {
this.jme.recordBondEvent$S("addBond");
event=null;
}} else if (this.action >= 206 && this.action <= 229 ) {
this.jme.setLastAction$I(2);
this.addRing$();
event="addRing";
} else if (this.action == 2030) {
this.jme.setLastAction$I(3);
event="addTemplate";
} else if (this.action >= 2033 && this.action < 2062 ) {
this.addGroup$Z(false);
event="addGroup";
this.jme.setLastAction$I(3);
} else if (this.action > 300) {
if (this.jme.active_an != this.mol.an$I(this.mol.touchedAtom) || this.jme.active_an == 32 ) {
this.mol.AN$I$I(this.mol.touchedAtom, this.jme.active_an);
this.mol.Q$I$I(this.mol.touchedAtom, 0);
this.mol.atoms[this.mol.touchedAtom].iso=0;
this.mol.atoms[this.mol.touchedAtom].nh=0;
if (this.jme.active_an == 32) {
this.mol.setAtom$I$S(this.mol.touchedAtom, this.jme.getAtomSymbolForX$());
}event="setAtom";
}}if (event != null ) this.jme.recordAtomEvent$S$I(event, this.mol.touchedAtom);
});

Clazz.newMeth(C$, 'deleteAtomOrBond$',  function () {
if (this.mol.touchedAtom > 0) {
this.mol.deleteAtom$I(this.mol.touchedAtom);
this.jme.recordAtomEvent$S("delAtom");
this.mol.touchedAtom=0;
} else if (this.mol.touchedBond > 0) {
var b=this.mol.bonds[this.mol.touchedBond];
var deletableAtoms=this.mol.deleteBond$I$Z(this.mol.touchedBond, false);
this.jme.recordBondEvent$S("delBond");
switch (deletableAtoms) {
case 0:
break;
case 3:
case 1:
this.mol.deleteAtom$I(b.va);
this.jme.recordAtomEvent$S("delAtom");
if (deletableAtoms == 1) break;
case 2:
this.mol.deleteAtom$I(b.vb);
this.jme.recordAtomEvent$S("delAtom");
break;
}
this.mol.touchedBond=0;
} else {
}this.mol.cleanAfterChanged$Z(this.jme.options.polarnitro);
});

Clazz.newMeth(C$, 'newMolecule$D$D',  function (x, y) {
if (this.action >= 202 && this.action <= 204  || this.action == 205 ) {
p$2.createAtom$D$D.apply(this, [x, y]);
this.jme.setLastAction$I(1);
this.addBond$();
if (this.action == 205) {
this.mol.XY$I$D$D(2, x + 21.65, y - 12.5);
this.mol.chain[0]=1;
this.mol.chain[1]=2;
this.mol.nchain=1;
this.jme.recordBondEvent$S("addChain");
} else {
this.jme.recordBondEvent$S("addBond");
}return;
}if (this.action >= 206 && this.action <= 229 ) {
this.mol.xorg=x;
this.mol.yorg=y;
this.jme.setLastAction$I(2);
this.addRing$();
this.jme.recordAfterStructureChangedEvent$S("addRing");
return;
}if (this.action == 2030) {
this.jme.recordAfterStructureChangedEvent$S("addTemplate");
return;
}if (this.action >= 2033 && this.action < 2062 ) {
p$2.createAtom$D$D.apply(this, [x, y]);
this.addGroup$Z(true);
this.jme.recordAfterStructureChangedEvent$S("addGroup");
return;
}if (this.action >= 301) {
p$2.createAtom$D$D.apply(this, [x, y]);
if (this.jme.active_an == 32) {
this.mol.setAtom$I$S(1, this.jme.getAtomSymbolForX$());
} else {
this.mol.AN$I$I(1, this.jme.active_an);
}this.jme.recordAtomEvent$S("addAtom");
return;
}System.err.println$S("error -report fall through bug Builder.newMolecule! " + this.action);
});

Clazz.newMeth(C$, 'setAtom$I',  function (active_an) {
if (active_an != this.mol.an$I(this.mol.touchedAtom) && active_an != 32 ) {
this.mol.AN$I$I(this.mol.touchedAtom, active_an);
this.mol.Q$I$I(this.mol.touchedAtom, 0);
this.mol.atoms[this.mol.touchedAtom].iso=0;
this.mol.atoms[this.mol.touchedAtom].nh=0;
} else if (active_an == 32) {
var xx=this.jme.atomicSymbol.getText$();
this.mol.setAtom$I$S(this.mol.touchedAtom, xx);
} else {
return false;
}this.jme.recordAtomEvent$S("setAtom");
return true;
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.JMEBuilder, "GroupTemplateBondDirection", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['sin','cos','x','y'],'O',['mol','jme.JMEmol']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'init$jme_JMEmol$I$I',  function (mol, sourceAtom, destAtom) {
this.x=mol.x$I(destAtom);
this.y=mol.y$I(destAtom);
var dx=mol.x$I(sourceAtom) - this.x;
var dy=mol.y$I(sourceAtom) - this.y;
var r=Math.sqrt(dx * dx + dy * dy);
this.sin=dy / r;
this.cos=dx / r;
});

Clazz.newMeth(C$, 'initBondCreate$jme_JMEmol$I$I',  function (mol, sourceAtom, addBondArgument) {
this.mol=mol;
var nh=mol.atoms[sourceAtom].nh;
var nv=mol.atoms[sourceAtom].nv;
var q=mol.atoms[sourceAtom].q;
var b=Boolean.valueOf$Z(mol.addBondToAtom$I$I$I$Z(0, sourceAtom, addBondArgument, false));
var hasTwoPossibleAddAngle=(b === Boolean.TRUE );
var destAtom=mol.natoms;
this.init$jme_JMEmol$I$I(mol, sourceAtom, destAtom);
mol.deleteAtom$I(destAtom);
mol.atoms[sourceAtom].nh=nh;
mol.atoms[sourceAtom].nv=nv;
mol.atoms[sourceAtom].q=q;
return hasTwoPossibleAddAngle;
});

Clazz.newMeth(C$, 'moveAndRotateFragment$jme_JMEmol$I$I$I$jme_gui_JMEBuilder_GroupTemplateBondDirection',  function (mol, ffirst, flast, sourceAt, sourceBD) {
for (var i=ffirst; i <= flast; i++) {
var atom=mol.atoms[i];
atom.moveXY$D$D(-this.x, -this.y);
var xx=atom.x * this.cos + atom.y * this.sin;
var yy=atom.y * this.cos - atom.x * this.sin;
atom.XY$D$D(xx, yy);
xx=-atom.x * sourceBD.cos + atom.y * sourceBD.sin;
yy=-atom.y * sourceBD.cos - atom.x * sourceBD.sin;
atom.XY$D$D(xx, yy);
atom.moveXY$D$D(mol.atoms[sourceAt].x, mol.atoms[sourceAt].y);
}
});

Clazz.newMeth(C$, 'sumAtomTooCloseContactsOfAddedFragment$I$I',  function (fragmentFirstAtom, fragmentLastAtom) {
var result=0;
for (var at=1; at <= this.mol.natoms; at++) {
if (at < fragmentFirstAtom || at > fragmentLastAtom ) result+=p$1.sumAtomTooCloseContacts$I$I$I.apply(this, [at, fragmentFirstAtom, fragmentLastAtom]);
}
return result;
});

Clazz.newMeth(C$, 'sumAtomTooCloseContacts$I$I$I',  function (atom, firstAtom, lastAtom) {
var dx;
var dy;
var rx;
var min=100;
var sum=0;
var x=this.mol.atoms[atom].x;
var y=this.mol.atoms[atom].y;
for (var i=firstAtom; i <= lastAtom; i++) {
if (atom == i) continue;
dx=x - this.mol.atoms[i].x;
dy=y - this.mol.atoms[i].y;
rx=dx * dx + dy * dy;
if (rx < min ) {
if (rx == 0 ) {
rx=1.0E-4;
}sum+=1 / rx;
}}
return sum;
}, p$1);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
