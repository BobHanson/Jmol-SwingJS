(function(){var P$=Clazz.newPackage("jme.gui"),I$=[[0,'javax.swing.JButton','javax.swing.JTextField','javax.swing.JDialog','java.awt.FlowLayout','javax.swing.JLabel','java.awt.BorderLayout','javax.swing.JPanel','java.awt.event.WindowAdapter','java.awt.Dimension']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AtomInspector");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['modalDialog','javax.swing.JDialog','window','javax.swing.JFrame','actionListener','java.awt.event.ActionListener','atomicMapField','javax.swing.JTextField','change','jme.event.ChangeAtomPropertyCallback']]]

Clazz.newMeth(C$, 'c$$jme_event_ChangeAtomPropertyCallback',  function (change) {
;C$.$init$.apply(this);
var ok=Clazz.new_($I$(1,1).c$$S,["OK"]);
var cancel=Clazz.new_($I$(1,1).c$$S,["Cancel"]);
this.atomicMapField=Clazz.new_($I$(2,1).c$$S$I,["0", 4]);
this.change=change;
this.actionListener=((P$.AtomInspector$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "AtomInspector$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.gui.AtomInspector'].modalDialog.setVisible$Z(false);
if (e.getSource$() === this.$finals$.ok ) {
var newInputValue=this.b$['jme.gui.AtomInspector'].atomicMapField.getText$().trim$();
try {
var newValue=Integer.parseInt$S(newInputValue);
this.$finals$.change.setAtomValue$I(newValue);
} catch (exception) {
if (Clazz.exceptionOf(exception,"NumberFormatException")){
this.$finals$.change.reportError$S("invalid atom " + this.b$['jme.gui.AtomInspector'].change.actionType$() + ": " + newInputValue );
} else {
throw exception;
}
}
}});
})()
), Clazz.new_(P$.AtomInspector$1.$init$,[this, {ok:ok,change:change}]));
this.modalDialog=Clazz.new_($I$(3,1));
this.modalDialog.setModal$Z(true);
this.modalDialog.setLayout$java_awt_LayoutManager(Clazz.new_($I$(4,1)));
ok.addActionListener$java_awt_event_ActionListener(this.actionListener);
cancel.addActionListener$java_awt_event_ActionListener(this.actionListener);
var label="New atom " + change.actionType$();
this.modalDialog.add$java_awt_Component(Clazz.new_($I$(5,1).c$$S,[label]));
this.modalDialog.add$java_awt_Component(ok);
this.modalDialog.add$java_awt_Component(cancel);
this.modalDialog.setLayout$java_awt_LayoutManager(Clazz.new_($I$(6,1).c$$I$I,[2, 0]));
var p=Clazz.new_($I$(7,1));
p.add$java_awt_Component(Clazz.new_(["new atom " + change.actionType$(), 0],$I$(5,1).c$$S$I));
p.add$java_awt_Component(this.atomicMapField);
this.modalDialog.add$S$java_awt_Component("North", p);
p=Clazz.new_($I$(7,1));
p.add$java_awt_Component(ok);
p.add$java_awt_Component(cancel);
this.modalDialog.add$S$java_awt_Component("South", p);
this.modalDialog.addWindowListener$java_awt_event_WindowListener(((P$.AtomInspector$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "AtomInspector$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.WindowAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'windowClosing$java_awt_event_WindowEvent',  function (evt) {
this.b$['jme.gui.AtomInspector'].modalDialog.setVisible$Z(false);
});
})()
), Clazz.new_($I$(8,1),[this, null],P$.AtomInspector$2)));
}, 1);

Clazz.newMeth(C$, 'action$jme_event_InspectorEvent',  function (event) {
if (event.atomIndex > 0) {
var title="Change " + this.change.actionType$() + " of atom  " + this.change.atomSymbol + " #" + event.atomIndex ;
this.modalDialog.setTitle$S(title);
this.atomicMapField.setText$S("" + this.change.getAtomValue$());
this.modalDialog.setMinimumSize$java_awt_Dimension(Clazz.new_($I$(9,1).c$$I$I,[250, 100]));
this.modalDialog.pack$();
var loc=event.jme.getLocationOnScreen$();
this.modalDialog.setLocation$I$I(loc.x + event.x + 30 , loc.y + event.y);
this.modalDialog.setVisible$Z(true);
this.atomicMapField.requestFocusInWindow$();
this.atomicMapField.select$I$I(0, 1000);
}});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
