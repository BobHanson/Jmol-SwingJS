(function(){var P$=Clazz.newPackage("jme.gui"),I$=[[0,'java.util.BitSet',['java.awt.geom.Rectangle2D','.Double'],'jme.gui.GUI']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AtomDisplayLabel");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.smallAtomWidthLabel=0;
this.boundingBoxpadding=2;
},1);

C$.$fields$=[['Z',['noLabelAtom'],'D',['smallAtomWidthLabel','fullAtomWidthLabel','labelX','labelY','atomMapY','atomMapX'],'I',['alignment','boundingBoxpadding'],'S',['str','mapString'],'O',['drawBox','java.awt.geom.Rectangle2D.Double','+fillSupBox','+fillBox','subscripts','java.util.BitSet','+superscripts','+bsSS']]]

Clazz.newMeth(C$, 'create$jme_core_Atom$I$java_awt_FontMetrics$D$Z$Z',  function (atom, alignment, fm, h, showHs, showMap) {
return Clazz.new_(C$.c$$jme_core_Atom$I$java_awt_FontMetrics$D$Z$Z,[atom, alignment, fm, h, showHs, showMap]);
}, 1);

Clazz.newMeth(C$, 'c$$jme_core_Atom$I$java_awt_FontMetrics$D$Z$Z',  function (a, alignment, fm, h, showHs, showMap) {
;C$.$init$.apply(this);
var map=(showMap && a.hasBeenMapped$()  ? a.getMap$() : -1);
var z=a.getLabel$();
if (z == null  || z.length$() < 1 ) {
z="*";
System.err.println$S("Z error!");
}this.alignment=alignment;
var padding=2;
this.noLabelAtom=(a.an == 3 && a.q == 0  && a.iso == 0  && a.nv > 0  && (a.nv != 2 || a.sbo != 4 ) );
var hydrogenSymbols="";
if (showHs && !this.noLabelAtom ) {
if (a.nh > 0) {
hydrogenSymbols+="H";
if (a.nh > 1) {
hydrogenSymbols+=a.nh;
}}}var isoSymbol=(a.iso == 0 ? "" : "[" + a.iso + "]" );
var chargeSymbols=(a.q == 0 ? "" : (Math.abs(a.q) > 1 ? "" + Math.abs(a.q) : "") + (a.q > 0 ? "+" : "-"));
var stringForWidth=z;
if (alignment == 2) {
z=chargeSymbols + hydrogenSymbols + isoSymbol + z ;
} else {
z=isoSymbol + z + hydrogenSymbols + chargeSymbols ;
}this.str=z;
if (alignment == 1) {
stringForWidth=z;
}if (hydrogenSymbols.length$() > 1) {
var pos=z.indexOf$S(hydrogenSymbols);
if (this.subscripts == null ) this.subscripts=Clazz.new_($I$(1,1));
this.subscripts.set$I$I(pos + 1, pos + hydrogenSymbols.length$());
}if (chargeSymbols.length$() > 0) {
var pos=z.indexOf$S(chargeSymbols);
if (this.superscripts == null ) this.superscripts=Clazz.new_($I$(1,1));
this.superscripts.set$I$I(pos, pos + chargeSymbols.length$());
}if (isoSymbol.length$() > 0) {
var pos=z.indexOf$S(isoSymbol);
if (this.superscripts == null ) this.superscripts=Clazz.new_($I$(1,1));
this.superscripts.set$I$I(pos, pos + isoSymbol.length$());
}var nsub=(this.subscripts == null  ? 0 : this.subscripts.cardinality$());
var nsup=(this.superscripts == null  ? 0 : this.superscripts.cardinality$());
var xAdj1=0;
var xAdj2=0;
var yAdj1=0;
var yAdj2=0;
var ssCharWidth=fm.charWidth$C("2");
if (nsub != 0 || nsup != 0 ) {
this.bsSS=Clazz.new_($I$(1,1));
if (nsub > 0) {
this.bsSS.or$java_util_BitSet(this.subscripts);
yAdj1=1;
}if (nsup > 0) {
this.bsSS.or$java_util_BitSet(this.superscripts);
yAdj2=1;
}xAdj2=nsup * ssCharWidth * 0.4 ;
xAdj1=nsub * ssCharWidth * 0.4 ;
}var smallWidth=fm.stringWidth$S(stringForWidth);
var fullWidth=fm.stringWidth$S(z) - xAdj1 - xAdj2 ;
this.smallAtomWidthLabel=smallWidth;
this.fullAtomWidthLabel=fullWidth;
var lineThickness=1;
var x=a.x;
var y=a.y;
var xstart=x - smallWidth / 2.0;
switch (alignment) {
case 2:
xstart-=(fullWidth - smallWidth);
xstart+=nsup * ssCharWidth * 0.6 ;
break;
case 1:
xstart+=nsup * ssCharWidth * 0.6 ;
break;
case 0:
break;
}
var ystart=y - h / 2;
xstart-=lineThickness;
fullWidth+=lineThickness;
this.fillBox=Clazz.new_($I$(2,1).c$$D$D$D$D,[xstart - padding, ystart - padding, fullWidth + 2 * padding - nsup * ssCharWidth * 0.6 , h + 2 * padding]);
this.fillSupBox=(nsup == 0 ? null : Clazz.new_($I$(2,1).c$$D$D$D$D,[xstart - padding + fullWidth - nsup * ssCharWidth * 0.6 , ystart - padding, nsup * ssCharWidth, h / 2]));
var box=this.drawBox=Clazz.new_([xstart - padding, ystart - padding - yAdj2 * h / 3 , fullWidth + 2 * padding, h + 2 * padding + (yAdj1 + yAdj2) * h / 3],$I$(2,1).c$$D$D$D$D);
this.mapString=null;
this.labelX=xstart + 1;
this.labelY=ystart + h;
if (map < 0) return;
this.mapString=" " + map;
var superscriptMove=h * 0.3;
if (this.noLabelAtom) {
this.atomMapX=x + smallWidth / 4;
this.atomMapY=y - (h + yAdj2 * 0.6) * 0.1;
} else {
var atomMapStringWidth=fm.stringWidth$S(this.mapString);
if (alignment == 0) {
this.atomMapX=x - smallWidth / 2.0 + fullWidth;
} else {
box.x-=atomMapStringWidth;
this.atomMapX=x + smallWidth / 2 - fullWidth - atomMapStringWidth;
}this.atomMapY=y - superscriptMove;
box.y-=superscriptMove;
box.height+=superscriptMove;
box.width+=atomMapStringWidth;
}}, 1);

Clazz.newMeth(C$, 'draw$jme_canvas_PreciseGraphicsAWT$java_awt_Color$D$java_awt_FontMetrics',  function (og, strokeColor, h, fm) {
var strokeWidth=h / 20;
if (this.bsSS == null ) {
og.drawStringWithStroke$S$D$D$java_awt_Color$D(this.str, this.labelX, this.labelY, strokeColor, strokeWidth);
return;
}var normalFont=og.baseGraphics.getFont$();
var subFont=normalFont.deriveFont$F((h * 0.8));
var x=this.labelX;
var y=this.labelY;
var subOffset=h / 3;
var superOffset=-2 * subOffset;
var yoff;
for (var i=0; i < this.str.length$(); ) {
var pt0=i;
var pt1=this.bsSS.nextSetBit$I(i);
if (pt1 == pt0) {
if (this.subscripts != null  && this.subscripts.get$I(i) ) {
pt1=this.subscripts.nextClearBit$I(i + 1);
yoff=subOffset;
} else {
pt1=this.superscripts.nextClearBit$I(i + 1);
yoff=superOffset;
}} else {
if (pt1 < 0) pt1=this.str.length$();
yoff=0;
}var s=this.str.substring$I$I(pt0, pt1);
if (yoff != 0 ) og.setFont$java_awt_Font(subFont);
og.drawStringWithStroke$S$D$D$java_awt_Color$D(s, x, y + yoff, strokeColor, strokeWidth);
if (yoff != 0 ) og.setFont$java_awt_Font(normalFont);
x+=fm.stringWidth$S(s) * (yoff == 0  ? 1 : 0.6);
i=pt1;
}
});

Clazz.newMeth(C$, 'createLabels$jme_JMEmol$D$java_awt_FontMetrics$Z$Z$jme_gui_AtomDisplayLabelA',  function (mol, rb, fm, showHs, showMap, labels) {
var natoms=mol.natoms;
var bonds=mol.bonds;
var atoms=mol.atoms;
if (labels == null  || labels.length < natoms + 1 ) {
labels=Clazz.array(C$, [natoms + 1]);
}var neighborXSum=Clazz.array(Double.TYPE, [natoms + 1]);
var neighborCount=Clazz.array(Integer.TYPE, [natoms + 1]);
for (var i=1, n=mol.nbonds; i <= n; i++) {
var atom1=bonds[i].va;
var atom2=bonds[i].vb;
neighborXSum[atom1]+=atoms[atom2].x;
neighborXSum[atom2]+=atoms[atom1].x;
++neighborCount[atom1];
++neighborCount[atom2];
}
var h=$I$(3).stringHeight$java_awt_FontMetrics(fm);
for (var i=1; i <= natoms; i++) {
var n=neighborCount[i];
var diff=neighborXSum[i] / n - atoms[i].x;
var alignment;
if (n > 2 || n == 0  || n == 2 && Math.abs(diff) < rb / 3   ) {
alignment=1;
} else if (n == 1 && Math.abs(diff) < rb / 10  ) {
alignment=0;
} else {
alignment=(diff < 0  ? 0 : 2);
}labels[i]=C$.create$jme_core_Atom$I$java_awt_FontMetrics$D$Z$Z(atoms[i], alignment, fm, h, showHs, showMap);
}
return labels;
}, 1);

Clazz.newMeth(C$, 'fill$jme_canvas_PreciseGraphicsAWT',  function (og) {
C$.fillBox$jme_canvas_PreciseGraphicsAWT$java_awt_geom_Rectangle2D_Double(og, this.fillBox);
if (this.fillSupBox != null ) C$.fillBox$jme_canvas_PreciseGraphicsAWT$java_awt_geom_Rectangle2D_Double(og, this.fillSupBox);
});

Clazz.newMeth(C$, 'fillBox$jme_canvas_PreciseGraphicsAWT$java_awt_geom_Rectangle2D_Double',  function (og, r) {
var h=r.height;
og.fillRoundRect$D$D$D$D$D$D(r.x, r.y, r.width, h, h / 2, h / 2);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
