(function(){var P$=Clazz.newPackage("jme.gui"),I$=[[0,'java.awt.event.ActionEvent','java.util.HashMap','javax.swing.KeyStroke',['jme.gui.Actions','.WrappedAction'],'javax.swing.AbstractAction']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Actions", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['WrappedAction',10]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.actions=Clazz.new_($I$(2,1));
this.actions0_9=0;
this.actionsBond=0;
},1);

C$.$fields$=[['I',['actions0_9','actionsBond'],'O',['jme','jme.JME','actions','java.util.Map','actionAtomBond','javax.swing.AbstractAction']]
,['O',['actionToAtomNumberArray','int[]']]]

Clazz.newMeth(C$, 'c$$jme_JME',  function (jme) {
;C$.$init$.apply(this);
this.jme=jme;
this.setActions$();
}, 1);

Clazz.newMeth(C$, 'mapActionToAtomNumberX$I',  function (action) {
if (action >= 1301 && action <= 1310 ) {
var delta=action - 1301;
return 33 + delta;
}for (var i=0; i < C$.actionToAtomNumberArray.length; i+=2) {
if (C$.actionToAtomNumberArray[i] == action) {
return C$.actionToAtomNumberArray[i + 1];
}}
return -1;
}, 1);

Clazz.newMeth(C$, 'getKeyStroke$I$I',  function (key, modifiers) {
if (modifiers == 4) {
modifiers=2;
}if (key < 127) return $I$(3,"getKeyStroke$Character$I",[Character.valueOf$C(String.fromCharCode(key)), modifiers]);
return $I$(3).getKeyStroke$I$I(key, modifiers);
});

Clazz.newMeth(C$, 'addAction$S$I$I$I$javax_swing_AbstractAction',  function (name, id, key, modifiers, a) {
a.putValue$S$O("Name", name);
if (id == 0) id=key;
if (id != 0) {
a=Clazz.new_($I$(4,1).c$$S$I$javax_swing_AbstractAction,[name, id, a]);
}this.actions.put$O$O(name, a);
if (key != 0) {
var shortcut=this.getKeyStroke$I$I(key, modifiers);
a.putValue$S$O("AcceleratorKey", shortcut);
this.actions.put$O$O(shortcut, a);
}});

Clazz.newMeth(C$, 'doAction$O$I',  function (key, id) {
var a=this.actions.get$O(key);
if (a == null ) return false;
var actionCommand=key.toString();
if (Clazz.instanceOf(a, "jme.gui.Actions.WrappedAction")) {
if (id == 0) id=(a).id;
a=(a).a;
}this.jme.startKeyboardAction$();
a.actionPerformed$java_awt_event_ActionEvent(Clazz.new_($I$(1,1).c$$O$I$S,[a, id, actionCommand]));
this.jme.endKeyboardAction$();
return true;
});

Clazz.newMeth(C$, 'setActions$',  function () {
this.addAction$S$I$I$I$javax_swing_AbstractAction("copy", 0, 67, 2, ((P$.Actions$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "Actions$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.AbstractAction'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.gui.Actions'].jme.copyFileToClipboard$();
});
})()
), Clazz.new_($I$(5,1),[this, null],P$.Actions$1)));
this.addAction$S$I$I$I$javax_swing_AbstractAction("cut", 0, 88, 2, ((P$.Actions$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "Actions$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.AbstractAction'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.gui.Actions'].jme.cutSelectedMoleculeForSystemClipBoard$();
});
})()
), Clazz.new_($I$(5,1),[this, null],P$.Actions$2)));
this.addAction$S$I$I$I$javax_swing_AbstractAction("paste", 0, 86, 2, ((P$.Actions$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "Actions$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.AbstractAction'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
if (this.b$['jme.gui.Actions'].jme.options.paste) this.b$['jme.gui.Actions'].jme.pasteMolFileFromClipboard$();
});
})()
), Clazz.new_($I$(5,1),[this, null],P$.Actions$3)));
var a=((P$.Actions$4||
(function(){/*a*/var C$=Clazz.newClass(P$, "Actions$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.AbstractAction'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.gui.Actions'].jme.doUndoRedo$I(e.getID$());
});
})()
), Clazz.new_($I$(5,1),[this, null],P$.Actions$4));
this.addAction$S$I$I$I$javax_swing_AbstractAction("redo", 1, "Y".$c(), 2, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("undo", -1, "U".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("undo", -1, "Z".$c(), 2, a);
a=((P$.Actions$5||
(function(){/*a*/var C$=Clazz.newClass(P$, "Actions$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.AbstractAction'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.gui.Actions'].jme.doNavigate$I(e.getID$());
});
})()
), Clazz.new_($I$(5,1),[this, null],P$.Actions$5));
this.addAction$S$I$I$I$javax_swing_AbstractAction("navigate", 0, 38, 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("navigate", 0, 40, 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("navigate", 0, 37, 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("navigate", 0, 39, 0, a);
a=((P$.Actions$6||
(function(){/*a*/var C$=Clazz.newClass(P$, "Actions$6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.AbstractAction'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.gui.Actions'].jme.doAtomG$();
});
})()
), Clazz.new_($I$(5,1),[this, null],P$.Actions$6));
this.addAction$S$I$I$I$javax_swing_AbstractAction("atomG", 0, 106, 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atomG", 0, 151, 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atomG", 0, 71, 0, a);
a=((P$.Actions$7||
(function(){/*a*/var C$=Clazz.newClass(P$, "Actions$7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.AbstractAction'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.gui.Actions'].jme.doAtomX$();
});
})()
), Clazz.new_($I$(5,1),[this, null],P$.Actions$7));
this.addAction$S$I$I$I$javax_swing_AbstractAction("atomX", 0, 88, 0, a);
a=this.actionAtomBond=((P$.Actions$8||
(function(){/*a*/var C$=Clazz.newClass(P$, "Actions$8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.AbstractAction'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.gui.Actions'].jme.doAtomBond$I(e.getID$());
});
})()
), Clazz.new_($I$(5,1),[this, null],P$.Actions$8));
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 104, 68, 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 104, 8, 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 104, 127, 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 202, 27, 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 209, "P".$c(), 1, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 2034, "Y".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 2039, "Z".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 2035, "A".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 2038, "E".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 2058, "Q".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 223, "0".$c(), 8, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 223, "0".$c(), 1, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 205, " ".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 204, "#".$c(), 0, a);
a=((P$.Actions$9||
(function(){/*a*/var C$=Clazz.newClass(P$, "Actions$9", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.AbstractAction'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.gui.Actions'].jme.doPage$I(e.getID$());
});
})()
), Clazz.new_($I$(5,1),[this, null],P$.Actions$9));
this.addAction$S$I$I$I$javax_swing_AbstractAction("page", 151, "M".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("page", 151, 33, 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("page", 152, "W".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("page", 152, 34, 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("page", 153, 36, 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("page", 154, 35, 0, a);
});

Clazz.newMeth(C$, 'setBondVariableAction$Z',  function (isBond) {
var newActions=(isBond ? 202 : 301);
var a=this.actionAtomBond;
if (this.actionsBond != newActions) {
this.actionsBond=newActions;
if (newActions == 202) {
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 202, "-".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 201, "+".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 201, 107, 0, a);
} else {
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 108, "+".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 108, 107, 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", -1, "-".$c(), 0, a);
}}});

Clazz.newMeth(C$, 'setAtomVariableAction$Z$I',  function (isR, action) {
this.setBondVariableAction$Z(false);
var a=this.actionAtomBond;
switch (action) {
case 701:
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 2036, "T".$c(), 0, a);
break;
case 801:
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 2037, "T".$c(), 0, a);
break;
default:
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 2033, "T".$c(), 0, a);
break;
}
var newActions=(isR ? 1301 : 2053);
if (action == 105 && this.actions0_9 != 105 ) {
this.actions0_9=105;
for (var i=0; i <= 9; ) this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 105, "0".$c(), 0, a);

return;
}if (this.actions0_9 == newActions) {
return;
}this.actions0_9=newActions;
if (isR) {
for (var i=0; i <= 9; i++) this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 1301 + i, String.fromCharCode((48 + i)).$c(), 0, a);

} else {
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 221, "0".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 202, "1".$c(), 0, a);
var id=(action == 501 ? 2050 : 203);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", id, "2".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", id, "=".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 206, "3".$c(), 1, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 204, "3".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 207, "4".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 208, "5".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 210, "6".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 211, "7".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 212, "8".$c(), 0, a);
this.addAction$S$I$I$I$javax_swing_AbstractAction("atombond", 229, "9".$c(), 0, a);
}});

Clazz.newMeth(C$, 'dispose$',  function () {
this.jme=null;
this.actions=null;
});

C$.$static$=function(){C$.$static$=0;
C$.actionToAtomNumberArray=Clazz.array(Integer.TYPE, -1, [301, 3, 401, 4, 501, 5, 701, 9, 801, 10, 901, 11, 1001, 12, 601, 8, 1101, 7, 1300, 1, 1201, 32, 1301, 33]);
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.Actions, "WrappedAction", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'javax.swing.AbstractAction');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['id'],'S',['name'],'O',['a','javax.swing.AbstractAction']]]

Clazz.newMeth(C$, 'c$$S$I$javax_swing_AbstractAction',  function (name, id, a) {
;C$.superclazz.c$$S.apply(this,[name]);C$.$init$.apply(this);
this.id=id;
this.name=name;
this.a=a;
}, 1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
var id=e.getID$();
if (this.id != 0) {
id=this.id;
e=Clazz.new_([e.getSource$(), id, this.name],$I$(1,1).c$$O$I$S);
}this.a.actionPerformed$java_awt_event_ActionEvent(e);
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
