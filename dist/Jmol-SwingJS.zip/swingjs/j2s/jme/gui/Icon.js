(function(){var P$=Clazz.newPackage("jme.gui"),I$=[[0,'java.awt.Rectangle']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Icon", null, ['java.awt.geom.Rectangle2D','.Double']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['pg','jme.canvas.PreciseGraphicsAWT']]]

Clazz.newMeth(C$, 'c$$jme_canvas_PreciseGraphicsAWT',  function (pg) {
Clazz.super_(C$, this);
this.pg=pg;
}, 1);

Clazz.newMeth(C$, 'contains$I$I',  function (screenX, screenY) {
var result=this.contains$D$D(this.pg.screenToCoordX$I(screenX), this.pg.screenToCoordY$I(screenY));
return result;
});

Clazz.newMeth(C$, 'onScreenFrame$',  function () {
var frame=Clazz.new_($I$(1,1));
frame.x=this.pg.screenX$() + this.pg.coordToScreen$D(this.x);
frame.y=this.pg.screenY$() + this.pg.coordToScreen$D(this.y);
frame.width=this.pg.coordToScreen$D(this.width);
frame.height=this.pg.coordToScreen$D(this.height);
return frame;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
