(function(){var P$=Clazz.newPackage("jme.gui"),I$=[[0,'javax.swing.JButton','java.awt.event.WindowAdapter']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FrameWithLocation", null, 'javax.swing.JFrame');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['lastLocation','java.awt.Point','closeJButton','javax.swing.JButton']]]

Clazz.newMeth(C$, 'c$$S',  function (title) {
;C$.superclazz.c$$S.apply(this,[title]);C$.$init$.apply(this);
this.initialize$();
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
this.initialize$();
}, 1);

Clazz.newMeth(C$, 'closeJButtonJLabel$',  function () {
return "Close";
});

Clazz.newMeth(C$, 'initialize$',  function () {
this.closeJButton=Clazz.new_([this.closeJButtonJLabel$()],$I$(1,1).c$$S);
this.closeJButton.addActionListener$java_awt_event_ActionListener(((P$.FrameWithLocation$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "FrameWithLocation$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.gui.FrameWithLocation'].setVisible$Z.apply(this.b$['jme.gui.FrameWithLocation'], [false]);
});
})()
), Clazz.new_(P$.FrameWithLocation$1.$init$,[this, null])));
this.addWindowListener$java_awt_event_WindowListener(((P$.FrameWithLocation$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "FrameWithLocation$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.WindowAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'windowClosing$java_awt_event_WindowEvent',  function (evt) {
this.b$['jme.gui.FrameWithLocation'].setVisible$Z.apply(this.b$['jme.gui.FrameWithLocation'], [false]);
});
})()
), Clazz.new_($I$(2,1),[this, null],P$.FrameWithLocation$2)));
});

Clazz.newMeth(C$, 'setVisible$Z',  function (tf) {
if (tf) {
this.setLocation$java_awt_Point(this.lastLocation);
} else {
if (this.isShowing$()) {
var currentLocation=this.getLocationOnScreen$();
this.lastLocation.setLocation$java_awt_Point(currentLocation);
}}C$.superclazz.prototype.setVisible$Z.apply(this, [tf]);
});

Clazz.newMeth(C$, 'disposeIfShowing$',  function () {
if (this.isShowing$()) {
this.dispose$();
}});

Clazz.newMeth(C$, 'safeTranslate$java_awt_Point$I$I',  function (location, deltaX, deltaY) {
location.translate$I$I(deltaX, deltaY);
location.x=location.x < 0 ? 0 : location.x;
location.y=location.y < 0 ? 0 : location.y;
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
