(function(){var P$=Clazz.newPackage("jme.canvas"),I$=[[0,['jme.canvas.ColorManager','.ColorInfo'],'java.awt.Color',['jme.canvas.ColorManager','.ColorSpec']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ColorManager", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['ColorSpec',9],['ColorInfo',1]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['psColor','jme.canvas.ColorManager.ColorInfo[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'initDefaultBackGroundColorPaletteIfNeeded$',  function () {
if (this.psColor == null ) {
this.psColor=Clazz.array($I$(1), [8]);
this.psColor[0]=Clazz.new_([this, null, $I$(2).gray, null, 0],$I$(1,1).c$$java_awt_Color$S$I);
this.psColor[1]=Clazz.new_([this, null, $I$(2).cyan, "1", 1],$I$(1,1).c$$java_awt_Color$S$I);
this.psColor[2]=Clazz.new_([this, null, Clazz.new_($I$(2,1).c$$I$I$I,[255, 204, 102]), "2", 2],$I$(1,1).c$$java_awt_Color$S$I);
this.psColor[3]=Clazz.new_([this, null, Clazz.new_($I$(2,1).c$$I$I$I,[255, 255, 0]), "3", 3],$I$(1,1).c$$java_awt_Color$S$I);
this.psColor[4]=Clazz.new_([this, null, Clazz.new_($I$(2,1).c$$I$I$I,[255, 153, 153]), "4", 4],$I$(1,1).c$$java_awt_Color$S$I);
this.psColor[5]=Clazz.new_([this, null, Clazz.new_($I$(2,1).c$$I$I$I,[51, 204, 255]), "5", 5],$I$(1,1).c$$java_awt_Color$S$I);
this.psColor[6]=Clazz.new_([this, null, Clazz.new_($I$(2,1).c$$I$I$I,[255, 153, 255]), "6", 6],$I$(1,1).c$$java_awt_Color$S$I);
this.psColor[7]=Clazz.new_([this, null, Clazz.new_($I$(2,1).c$$I$I$I,[102, 255, 102]), "7", 7],$I$(1,1).c$$java_awt_Color$S$I);
}});

Clazz.newMeth(C$, 'numberOfBackgroundColors$',  function () {
this.initDefaultBackGroundColorPaletteIfNeeded$();
return this.psColor.length - 1;
});

Clazz.newMeth(C$, 'getBackGroundColorPaletteAsInteger$',  function () {
this.initDefaultBackGroundColorPaletteIfNeeded$();
var result=Clazz.array(Integer.TYPE, [this.psColor.length - 1, 3]);
for (var i=1; i < this.psColor.length; i++) {
var c=this.getColor$I(i);
result[i - 1][0]=c.getRed$();
result[i - 1][1]=c.getGreen$();
result[i - 1][2]=c.getBlue$();
}
return result;
});

Clazz.newMeth(C$, 'getBackGroundColorPalette$',  function () {
this.initDefaultBackGroundColorPaletteIfNeeded$();
var result=Clazz.array(String, [this.psColor.length - 1]);
for (var i=1; i < this.psColor.length; i++) {
result[i - 1]=C$.makeHexColor$java_awt_Color(this.psColor[i].color);
}
return result;
});

Clazz.newMeth(C$, 'getColorInfo$I',  function (index) {
this.initDefaultBackGroundColorPaletteIfNeeded$();
if (index >= 0 && index < this.psColor.length ) {
return this.psColor[index];
}return null;
});

Clazz.newMeth(C$, 'getColorInfoOfColorHash$S',  function (hash) {
this.initDefaultBackGroundColorPaletteIfNeeded$();
for (var each, $each = 0, $$each = this.psColor; $each<$$each.length&&((each=($$each[$each])),1);$each++) {
if (each.hash == hash) {
return each;
}}
return null;
});

Clazz.newMeth(C$, 'getColor$I',  function (index) {
this.initDefaultBackGroundColorPaletteIfNeeded$();
if (index >= 0 && index < this.psColor.length ) {
return this.psColor[index].color;
}return null;
});

Clazz.newMeth(C$, 'getColorAssociatedLabel$I',  function (index) {
this.initDefaultBackGroundColorPaletteIfNeeded$();
if (index >= 0 && index < this.psColor.length ) {
return this.psColor[index].name;
}return null;
});

Clazz.newMeth(C$, 'getColorAssociatedHash$I',  function (index) {
this.initDefaultBackGroundColorPaletteIfNeeded$();
if (index >= 0 && index < this.psColor.length ) {
return this.psColor[index].hash;
}return null;
});

Clazz.newMeth(C$, 'setBackGroundColorPalette$SA',  function (palette) {
var n=palette.length;
var colorSpecPalette=Clazz.array($I$(3), [n]);
for (var i=0; i < n; i++) {
var color=palette[i];
var label="" + (i + 1);
colorSpecPalette[i]=Clazz.new_($I$(3,1).c$$S$S,[color, label]);
}
this.setMarkerMenuBackGroundColorPalette$jme_canvas_ColorManager_ColorSpecA(colorSpecPalette);
});

Clazz.newMeth(C$, 'setMarkerMenuBackGroundColorPalette$jme_canvas_ColorManager_ColorSpecA',  function (palette) {
this.initDefaultBackGroundColorPaletteIfNeeded$();
var firstColor=this.psColor[0];
this.psColor=Clazz.array($I$(1), [palette.length + 1]);
this.psColor[0]=firstColor;
for (var i=0; i < palette.length; i++) {
this.psColor[i + 1]=Clazz.new_([this, null, C$.parseHexColor$S(palette[i].color), palette[i].label, i + 1],$I$(1,1).c$$java_awt_Color$S$I);
}
});

Clazz.newMeth(C$, 'averageColor$IA',  function (colorCodes) {
this.initDefaultBackGroundColorPaletteIfNeeded$();
var singleColorIndex=-1;
if (colorCodes != null  && colorCodes.length >= 1 ) {
var red=0;
var green=0;
var blue=0;
var count=0;
for (var colorIndex, $colorIndex = 0, $$colorIndex = colorCodes; $colorIndex<$$colorIndex.length&&((colorIndex=($$colorIndex[$colorIndex])),1);$colorIndex++) {
if (colorIndex >= 0 && colorIndex < this.psColor.length ) {
var color=this.psColor[colorIndex].color;
red+=color.getRed$();
green+=color.getGreen$();
blue+=color.getBlue$();
++count;
singleColorIndex=colorIndex;
}}
if (count > 0) {
if (count == 1) {
if (singleColorIndex >= 0) {
return this.psColor[singleColorIndex].color;
}} else {
var color=Clazz.new_([(red/count|0), (green/count|0), (blue/count|0)],$I$(2,1).c$$I$I$I);
return color;
}}}return null;
});

Clazz.newMeth(C$, 'parseHexColor$S',  function (hex) {
var c=$I$(2).white;
try {
if (!hex.startsWith$S("#")) throw Clazz.new_(Clazz.load('Exception').c$$S,["bad hex encoding"]);
var r=Integer.parseInt$S$I(hex.substring$I$I(1, 3), 16);
var g=Integer.parseInt$S$I(hex.substring$I$I(3, 5), 16);
var b=Integer.parseInt$S$I(hex.substring$I$I(5, 7), 16);
c=Clazz.new_($I$(2,1).c$$I$I$I,[r, g, b]);
return c;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("Problems in parsing background color " + hex);
return c;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'makeHexColor$java_awt_Color',  function (c) {
var hex="#" + C$.byteToHexString$I(c.getRed$()) + C$.byteToHexString$I(c.getGreen$()) + C$.byteToHexString$I(c.getBlue$()) ;
return hex;
}, 1);

Clazz.newMeth(C$, 'byteToHexString$I',  function (c) {
var hex=Integer.toHexString$I(c);
if (hex.length$() == 1) {
hex="0" + hex;
}return hex;
}, 1);

Clazz.newMeth(C$, 'brightness$java_awt_Color',  function (c) {
var result=c.getRed$() * 299.0 + c.getGreen$() * 587.0 + c.getBlue$() * 114;
result/=1000.0;
return result;
}, 1);

Clazz.newMeth(C$, 'contrast$java_awt_Color',  function (c) {
var result=C$.brightness$java_awt_Color(c) > 123  ? $I$(2).BLACK : $I$(2).WHITE;
return result;
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.ColorManager, "ColorSpec", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['color','label']]]

Clazz.newMeth(C$, 'c$$S$S',  function (hexColor, label) {
;C$.$init$.apply(this);
this.color=hexColor;
this.label=label;
}, 1);

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.ColorManager, "ColorInfo", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['index'],'S',['name','hash'],'O',['color','java.awt.Color']]]

Clazz.newMeth(C$, 'c$$java_awt_Color$S$I',  function (color, name, index) {
;C$.$init$.apply(this);
this.color=color;
this.name=name;
this.hash="COLOR_HASH" + "\t" + index ;
this.index=index;
}, 1);

Clazz.newMeth(C$, 'getName$',  function () {
return this.name;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:53 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
