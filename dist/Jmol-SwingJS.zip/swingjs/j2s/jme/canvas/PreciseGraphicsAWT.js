(function(){var P$=Clazz.newPackage("jme.canvas"),I$=[[0,'java.awt.BasicStroke',['java.awt.geom.Rectangle2D','.Double'],'jme.JME',['jme.canvas.PreciseGraphicsAWT','.ExtendedGraphics2D']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PreciseGraphicsAWT", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['ExtendedGraphics2D',1]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.scale=1.0;
this.colorOverride=null;
this.defaultBackGroundColor=null;
this.savedColor=null;
this.screenArea=Clazz.new_($I$(2,1));
},1);

C$.$fields$=[['D',['scale'],'O',['baseGraphics','java.awt.Graphics2D','extendedBaseGraphics','jme.canvas.PreciseGraphicsAWT.ExtendedGraphics2D','unscaledFont','java.awt.Font','+enlargeddFont','unscaledStroke','java.awt.BasicStroke','+enlargedStroke','colorOverride','java.awt.Color','+defaultBackGroundColor','+savedColor','screenArea','java.awt.geom.Rectangle2D.Double']]
,['O',['defaultStroke','java.awt.BasicStroke']]]

Clazz.newMeth(C$, 'getWidth$',  function () {
return this.screenArea.width / this.scale;
});

Clazz.newMeth(C$, 'getHeight$',  function () {
return this.screenArea.height / this.scale;
});

Clazz.newMeth(C$, 'setDrawOnScreenCoordinates$I$I',  function (x, y) {
this.screenArea.x=x;
this.screenArea.y=y;
});

Clazz.newMeth(C$, 'setDrawOnScreenCoordinates$java_awt_geom_Rectangle2D_Double',  function (screenArea) {
this.screenArea.x=screenArea.x;
this.screenArea.y=screenArea.y;
this.screenArea.height=screenArea.height;
this.screenArea.width=screenArea.width;
});

Clazz.newMeth(C$, 'setDrawOnScreenCoordinates$I$I$I$I',  function (x, y, width, height) {
this.screenArea.x=x;
this.screenArea.y=y;
this.screenArea.height=height;
this.screenArea.width=width;
});

Clazz.newMeth(C$, 'screenX$',  function () {
return (this.screenArea.x|0);
});

Clazz.newMeth(C$, 'screenY$',  function () {
return (this.screenArea.y|0);
});

Clazz.newMeth(C$, 'screenToCoord$I',  function (pixel) {
return pixel / this.scale;
});

Clazz.newMeth(C$, 'coordToScreen$D',  function (coord) {
return ((coord * this.scale + 0.5)|0);
});

Clazz.newMeth(C$, 'screenToCoordX$I',  function (x) {
return this.screenToCoord$I(x - (this.screenArea.x|0));
});

Clazz.newMeth(C$, 'screenToCoordY$I',  function (y) {
return this.screenToCoord$I(y - (this.screenArea.y|0));
});

Clazz.newMeth(C$, 'currentZoomFactor$',  function () {
return this.scale;
});

Clazz.newMeth(C$, 'c$$java_awt_Graphics',  function (graphics) {
;C$.$init$.apply(this);
this.baseGraphics=graphics;
if ($I$(3).precision > 1.0 ) {
this.setStroke$java_awt_BasicStroke(C$.defaultStroke);
}this.extendedBaseGraphics=Clazz.new_($I$(4,1),[this, null]);
}, 1);

Clazz.newMeth(C$, 'initPrecisionScale$',  function () {
this.initPrecisionScale$D(1.0);
});

Clazz.newMeth(C$, 'initPrecisionScale$D',  function (absoluteScale) {
if (absoluteScale != this.scale ) {
var transformScale=absoluteScale / this.scale;
this.baseGraphics.scale$D$D(transformScale / $I$(3).precision, transformScale / $I$(3).precision);
this.scale=absoluteScale;
}});

Clazz.newMeth(C$, 'getGraphics$',  function () {
return this.baseGraphics;
});

Clazz.newMeth(C$, 'getDefaultBackGroundColor$',  function () {
return this.defaultBackGroundColor;
});

Clazz.newMeth(C$, 'setDefaultBackGroundColor$java_awt_Color',  function (backGroundColor) {
this.defaultBackGroundColor=backGroundColor;
});

Clazz.newMeth(C$, 'setBackGroundColor$',  function () {
this.setColor$java_awt_Color(this.defaultBackGroundColor);
});

Clazz.newMeth(C$, 'overrideColor$java_awt_Color',  function (color) {
this.colorOverride=color;
this.savedColor=this.baseGraphics.getColor$();
this.baseGraphics.setColor$java_awt_Color(color);
});

Clazz.newMeth(C$, 'resetOverrideColor$',  function () {
this.colorOverride=null;
this.baseGraphics.setColor$java_awt_Color(this.savedColor);
});

Clazz.newMeth(C$, 'setColor$java_awt_Color',  function (color) {
if (this.colorOverride == null ) this.baseGraphics.setColor$java_awt_Color(color);
 else {
if (color === this.defaultBackGroundColor  || color.equals$O(this.defaultBackGroundColor) ) {
this.baseGraphics.setColor$java_awt_Color(this.defaultBackGroundColor);
} else {
this.baseGraphics.setColor$java_awt_Color(this.colorOverride);
}}});

Clazz.newMeth(C$, 'fillRect$D$D$D$D',  function (x, y, width, height) {
this.baseGraphics.fillRect$I$I$I$I(this.r$D(x), this.r$D(y), this.r$D(width), this.r$D(height));
});

Clazz.newMeth(C$, 'fillRoundRect$D$D$D$D$D$D',  function (x, y, width, height, arcWidth, arcHeight) {
this.baseGraphics.fillRoundRect$I$I$I$I$I$I(this.r$D(x), this.r$D(y), this.r$D(width), this.r$D(height), this.r$D(arcWidth), this.r$D(arcHeight));
});

Clazz.newMeth(C$, 'fill3DRect$D$D$D$D$Z',  function (x, y, width, height, raised) {
var savedPaint=this.baseGraphics.getPaint$();
var color=this.baseGraphics.getColor$();
var colorUp;
var colorDown;
if (raised) {
colorUp=color.brighter$();
colorDown=color.darker$();
this.baseGraphics.setColor$java_awt_Color(color);
} else {
colorUp=color.darker$();
colorDown=color.brighter$();
this.baseGraphics.setColor$java_awt_Color(colorUp);
}var border=this.r$D(1.0);
var widthInt=this.r$D(width);
var heightInt=this.r$D(height);
var xInt=this.r$D(x);
var yInt=this.r$D(y);
widthInt-=border;
heightInt-=border;
this.baseGraphics.fillRect$I$I$I$I(xInt + border, yInt + border, widthInt - border, heightInt - border);
this.baseGraphics.setColor$java_awt_Color(colorUp);
this.baseGraphics.fillRect$I$I$I$I(xInt, yInt, widthInt, border);
this.baseGraphics.fillRect$I$I$I$I(xInt, yInt + border, border, heightInt);
this.baseGraphics.setColor$java_awt_Color(colorDown);
this.baseGraphics.fillRect$I$I$I$I(xInt + widthInt, yInt, border, heightInt + border);
this.baseGraphics.fillRect$I$I$I$I(xInt + 1, yInt + heightInt, widthInt, border);
this.baseGraphics.setPaint$java_awt_Paint(savedPaint);
});

Clazz.newMeth(C$, 'drawRect$D$D$D$D',  function (x, y, width, height) {
this.baseGraphics.drawRect$I$I$I$I(this.r$D(x), this.r$D(y), this.r$D(width), this.r$D(height));
});

Clazz.newMeth(C$, 'drawLine$D$D$D$D',  function (x1, y1, x2, y2) {
this.baseGraphics.drawLine$I$I$I$I(this.r$D(x1), this.r$D(y1), this.r$D(x2), this.r$D(y2));
});

Clazz.newMeth(C$, 'setFont$java_awt_Font',  function (font) {
if (this.unscaledFont === font ) return;
this.unscaledFont=font;
this.enlargeddFont=font.deriveFont$F((font.getSize$() * $I$(3).precision));
this.baseGraphics.setFont$java_awt_Font(this.enlargeddFont);
});

Clazz.newMeth(C$, 'drawString$S$D$D',  function (str, x, y) {
this.baseGraphics.drawString$S$I$I(str, this.r$D(x), this.r$D(y));
});

Clazz.newMeth(C$, 'drawStringWithStroke$S$D$D$java_awt_Color$D',  function (str, x, y, strokeColor, strokeWidth) {
this.extendedBaseGraphics.drawStringWithStroke$S$I$I$java_awt_Color$I(str, this.r$D(x), this.r$D(y), strokeColor, this.r$D(strokeWidth));
});

Clazz.newMeth(C$, 'drawStringWithStrokeAndBaselineShifts$S$D$D$java_awt_Color$D$IAA$IAA',  function (str, x, y, strokeColor, strokeWidth, subscripts, superscript) {
this.extendedBaseGraphics.drawStringWithStrokeAndBaselineShifts$S$I$I$java_awt_Color$I$IAA$IAA(str, this.r$D(x), this.r$D(y), strokeColor, this.r$D(strokeWidth), subscripts, superscript);
});

Clazz.newMeth(C$, 'r$D',  function (v) {
return Long.$ival(Math.round$D(v * $I$(3).precision));
});

Clazz.newMeth(C$, 'ir$I',  function (v) {
return v / $I$(3).precision;
});

Clazz.newMeth(C$, 'fillOval$D$D$D$D',  function (x, y, width, height) {
this.baseGraphics.fillOval$I$I$I$I(this.r$D(x), this.r$D(y), this.r$D(width), this.r$D(height));
});

Clazz.newMeth(C$, 'drawOval$D$D$D$D',  function (x, y, width, height) {
this.baseGraphics.drawOval$I$I$I$I(this.r$D(x), this.r$D(y), this.r$D(width), this.r$D(height));
});

Clazz.newMeth(C$, 'drawArc$D$D$D$D$D$D',  function (x, y, width, height, startAngle, arcAngle) {
this.baseGraphics.drawArc$I$I$I$I$I$I(this.r$D(x), this.r$D(y), this.r$D(width), this.r$D(height), Long.$ival(Math.round$D(startAngle)), Long.$ival(Math.round$D(arcAngle)));
});

Clazz.newMeth(C$, 'translate$D$D',  function (x, y) {
this.baseGraphics.translate$I$I(this.r$D(x), this.r$D(y));
});

Clazz.newMeth(C$, 'drawPolygon$DA$DA$I',  function (xPoints, yPoints, nPoints) {
var xPointsInt=Clazz.array(Integer.TYPE, [nPoints]);
var yPointsInt=Clazz.array(Integer.TYPE, [nPoints]);
for (var i=0; i < nPoints; i++) {
xPointsInt[i]=this.r$D(xPoints[i]);
yPointsInt[i]=this.r$D(yPoints[i]);
}
this.baseGraphics.drawPolygon$IA$IA$I(xPointsInt, yPointsInt, nPoints);
});

Clazz.newMeth(C$, 'fillPolygon$DA$DA$I',  function (xPoints, yPoints, nPoints) {
var xPointsInt=Clazz.array(Integer.TYPE, [nPoints]);
var yPointsInt=Clazz.array(Integer.TYPE, [nPoints]);
for (var i=0; i < nPoints; i++) {
xPointsInt[i]=this.r$D(xPoints[i]);
yPointsInt[i]=this.r$D(yPoints[i]);
}
this.baseGraphics.fillPolygon$IA$IA$I(xPointsInt, yPointsInt, nPoints);
});

Clazz.newMeth(C$, 'setRenderingHint$java_awt_RenderingHints_Key$O',  function (hintKey, hintValue) {
this.baseGraphics.setRenderingHint$java_awt_RenderingHints_Key$O(hintKey, hintValue);
});

Clazz.newMeth(C$, 'setStroke$java_awt_BasicStroke',  function (basicStroke) {
this.unscaledStroke=basicStroke;
this.enlargedStroke=Clazz.new_([($I$(3).precision * basicStroke.getLineWidth$())],$I$(1,1).c$$F);
this.baseGraphics.setStroke$java_awt_Stroke(this.enlargedStroke);
});

C$.$static$=function(){C$.$static$=0;
C$.defaultStroke=Clazz.new_($I$(1,1).c$$F,[1.0]);
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.PreciseGraphicsAWT, "ExtendedGraphics2D", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'drawStringWithStroke$S$I$I$java_awt_Color$I',  function (str, x, y, strokeColor, strokeWidth) {
this.b$['jme.canvas.PreciseGraphicsAWT'].baseGraphics.drawString$S$I$I(str, x, y);
});

Clazz.newMeth(C$, 'drawStringWithStrokeAndBaselineShifts$S$I$I$java_awt_Color$I$IAA$IAA',  function (str, x, y, strokeColor, strokeWidth, subscripts, superscript) {
this.b$['jme.canvas.PreciseGraphicsAWT'].baseGraphics.drawString$S$I$I(str, x, y);
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:53 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
