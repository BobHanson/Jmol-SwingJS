(function(){var P$=Clazz.newPackage("jme.canvas"),I$=[[0,['jme.util.Box','.Axis'],['java.awt.geom.Rectangle2D','.Double']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*i*/var C$=Clazz.newInterface(P$, "Graphical2DObject");

Clazz.newMeth(C$, 'move$jme_canvas_Graphical2DObject$jme_util_Box_Axis$D',  function (o, xOrY, d) {
if (xOrY === $I$(1).X ) o.moveXY$D$D(d, 0);
 else o.moveXY$D$D(0, d);
}, 1);

Clazz.newMeth(C$, 'center$jme_canvas_Graphical2DObject$jme_util_Box_Axis',  function (o, xOrY) {
return (xOrY === $I$(1).X  ? o.centerX$() : o.centerY$());
}, 1);

Clazz.newMeth(C$, 'move$jme_canvas_Graphical2DObject$D$D$java_awt_geom_Rectangle2D_Double',  function (o, movex, movey, boundingBoxLimits) {
if (o.isEmpty$()) return;
var bbox=o.computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(null);
var centerx=bbox.getCenterX$();
var centery=bbox.getCenterY$();
if ((movex < 0  && centerx < boundingBoxLimits.x  ) || (movex > 0  && centerx > boundingBoxLimits.width  ) || (movey < 0  && centery < boundingBoxLimits.y  ) || (movey > 0  && centery > boundingBoxLimits.height  )  ) return;
o.moveXY$D$D(movex, movey);
}, 1);

Clazz.newMeth(C$, 'move$jme_canvas_Graphical2DObject$java_awt_geom_Point2D_Double',  function (o, shiftXY) {
o.moveXY$D$D(shiftXY.x, shiftXY.y);
}, 1);

Clazz.newMeth(C$, 'newBoundingBox$jme_canvas_Graphical2DObject',  function (o) {
var box=o.computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(null);
return (box == null  ? Clazz.new_($I$(2,1)) : box);
}, 1);

Clazz.newMeth(C$, 'shortestDistance$D$D$D$D$D$D',  function (x1, y1, x2, y2, x3, y3) {
var px=x2 - x1;
var py=y2 - y1;
var temp=(px * px) + (py * py);
var dist;
var dx;
var dy;
if (temp == 0 ) {
dx=x2 - x3;
dy=y2 - y3;
} else {
var u=((x3 - x1) * px + (y3 - y1) * py) / (temp);
if (u > 1 ) {
u=1;
} else if (u < 0 ) {
u=0;
}var x=x1 + u * px;
var y=y1 + u * py;
dx=x - x3;
dy=y - y3;
}dist=Math.sqrt(dx * dx + dy * dy);
return dist;
}, 1);

Clazz.newMeth(C$, 'closestDistancePointToLine$D$D$java_awt_geom_Line2D_Double',  function (x0, y0, line) {
return C$.shortestDistance$D$D$D$D$D$D(line.x1, line.y1, line.x2, line.y2, x0, y0);
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:53 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
