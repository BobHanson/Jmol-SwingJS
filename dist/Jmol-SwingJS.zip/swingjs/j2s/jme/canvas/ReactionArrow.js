(function(){var P$=Clazz.newPackage("jme.canvas"),I$=[[0,['java.awt.geom.Line2D','.Double'],['java.awt.geom.Rectangle2D','.Double'],'java.awt.Color','jme.util.Box','jme.canvas.Graphical2DObject']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ReactionArrow", null, null, 'jme.canvas.Graphical2DObject');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.arrowWidth=48;
this.centerX=0;
this.centerY=0;
this.hasBeenPlaced=false;
this.horizontalLine=Clazz.new_($I$(1,1));
this.topTipLine=Clazz.new_($I$(1,1));
this.bottomTipLine=Clazz.new_($I$(1,1));
this.lines=Clazz.array($I$(1), -1, [this.horizontalLine, this.topTipLine, this.bottomTipLine]);
},1);

C$.$fields$=[['Z',['hasBeenPlaced'],'D',['arrowWidth','centerX','centerY'],'O',['boundingBox','java.awt.geom.Rectangle2D.Double','horizontalLine','java.awt.geom.Line2D.Double','+topTipLine','+bottomTipLine','lines','java.awt.geom.Line2D.Double[]']]]

Clazz.newMeth(C$, 'c$$D',  function (size) {
;C$.$init$.apply(this);
this.boundingBox=Clazz.new_($I$(2,1));
this.arrowWidth=size;
}, 1);

Clazz.newMeth(C$, 'width$',  function () {
return this.arrowWidth;
});

Clazz.newMeth(C$, 'draw$jme_canvas_PreciseGraphicsAWT',  function (og) {
var m=this.arrowHeigth$() / 2;
og.setColor$java_awt_Color($I$(3).magenta);
var xLeft=this.centerX - this.arrowWidth / 2;
var xRight=this.centerX + this.arrowWidth / 2;
this.horizontalLine.setLine$D$D$D$D(xLeft, this.centerY, xRight, this.centerY);
this.topTipLine.setLine$D$D$D$D(xRight, this.centerY, xRight - m, this.centerY + m);
this.bottomTipLine.setLine$D$D$D$D(xRight, this.centerY, xRight - m, this.centerY - m);
for (var eachLine, $eachLine = 0, $$eachLine = this.lines; $eachLine<$$eachLine.length&&((eachLine=($$eachLine[$eachLine])),1);$eachLine++) {
og.drawLine$D$D$D$D(eachLine.x1, eachLine.y1, eachLine.x2, eachLine.y2);
}
});

Clazz.newMeth(C$, 'arrowHeigth$',  function () {
return this.arrowWidth / 4;
});

Clazz.newMeth(C$, 'XY$D$D',  function (x, y) {
this.hasBeenPlaced=true;
this.centerX=x;
this.centerY=y;
});

Clazz.newMeth(C$, 'moveXY$D$D',  function (moveX, moveY) {
this.hasBeenPlaced=true;
this.centerX+=moveX;
this.centerY+=moveY;
});

Clazz.newMeth(C$, 'updateBoundingBox$',  function () {
this.boundingBox.setRect$D$D$D$D(this.centerX - this.arrowWidth / 2, this.centerY$() + this.arrowHeigth$() / 2, this.arrowWidth, this.arrowHeigth$());
return this.boundingBox;
});

Clazz.newMeth(C$, 'computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double',  function (union) {
this.updateBoundingBox$();
if (union != null ) return $I$(4).createUnion$java_awt_geom_Rectangle2D_Double$java_awt_geom_Rectangle2D_Double$java_awt_geom_Rectangle2D_Double(this.boundingBox, union, union);
union=Clazz.new_($I$(2,1));
union.setFrame$java_awt_geom_Rectangle2D(this.boundingBox);
return union;
});

Clazz.newMeth(C$, 'centerX$',  function () {
return this.centerX;
});

Clazz.newMeth(C$, 'centerY$',  function () {
return this.centerY;
});

Clazz.newMeth(C$, 'closestDistance$D$D',  function (x, y) {
var min=1.7976931348623157E308;
for (var eachLine, $eachLine = 0, $$eachLine = this.lines; $eachLine<$$eachLine.length&&((eachLine=($$eachLine[$eachLine])),1);$eachLine++) {
var d=$I$(5).closestDistancePointToLine$D$D$java_awt_geom_Line2D_Double(x, y, eachLine);
min=Math.min(d, min);
}
return min;
});

Clazz.newMeth(C$, 'isEmpty$',  function () {
return false;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
