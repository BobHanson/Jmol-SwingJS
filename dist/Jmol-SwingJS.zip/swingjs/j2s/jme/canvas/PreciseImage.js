(function(){var P$=Clazz.newPackage("jme.canvas"),I$=[[0,'jme.canvas.PreciseGraphicsAWT']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PreciseImage");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['implImage','java.awt.Image','preciseGraphics','jme.canvas.PreciseGraphicsAWT']]]

Clazz.newMeth(C$, 'getImage$',  function () {
return this.implImage;
});

Clazz.newMeth(C$, 'c$$java_awt_Image',  function (src) {
;C$.$init$.apply(this);
this.implImage=src;
this.preciseGraphics=Clazz.new_([src.getGraphics$()],$I$(1,1).c$$java_awt_Graphics);
}, 1);

Clazz.newMeth(C$, 'getGraphics$',  function () {
return this.getGraphics$D(1.0);
});

Clazz.newMeth(C$, 'getGraphics$D',  function (scale) {
this.preciseGraphics.initPrecisionScale$D(scale);
return this.preciseGraphics;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:53 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
