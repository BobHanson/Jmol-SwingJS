(function(){var P$=Clazz.newPackage("jme.canvas"),I$=[[0,'java.util.ArrayList','jme.canvas.Graphical2DObject','java.util.Collections','jme.util.Box']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Graphical2DObjectGroup", null, null, 'jme.canvas.Graphical2DObject');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['group','java.util.ArrayList']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.group=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'c$$java_util_ArrayList',  function (initGroup) {
;C$.$init$.apply(this);
this.group=Clazz.new_($I$(1,1).c$$java_util_Collection,[initGroup]);
}, 1);

Clazz.newMeth(C$, 'draw$jme_canvas_PreciseGraphicsAWT',  function (og) {
for (var go, $go = this.group.iterator$(); $go.hasNext$()&&((go=($go.next$())),1);) {
go.draw$jme_canvas_PreciseGraphicsAWT(og);
}
});

Clazz.newMeth(C$, 'moveXY$D$D',  function (movex, movey) {
for (var go, $go = this.group.iterator$(); $go.hasNext$()&&((go=($go.next$())),1);) {
go.moveXY$D$D(movex, movey);
}
});

Clazz.newMeth(C$, 'computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double',  function (union) {
for (var go, $go = this.group.iterator$(); $go.hasNext$()&&((go=($go.next$())),1);) {
union=go.computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(union);
}
return union;
});

Clazz.newMeth(C$, 'centerX$',  function () {
var center=0;
for (var go, $go = this.group.iterator$(); $go.hasNext$()&&((go=($go.next$())),1);) {
center+=go.centerX$();
}
if (this.group.size$() > 0) {
center/=this.group.size$();
}return center;
});

Clazz.newMeth(C$, 'centerY$',  function () {
var center=0;
for (var go, $go = this.group.iterator$(); $go.hasNext$()&&((go=($go.next$())),1);) {
center+=go.centerY$();
}
if (this.group.size$() > 0) {
center/=this.group.size$();
}return center;
});

Clazz.newMeth(C$, 'alignCenter$jme_util_Box_Axis',  function (xOrY) {
var groupCenter=$I$(2).center$jme_canvas_Graphical2DObject$jme_util_Box_Axis(this, xOrY);
for (var go, $go = this.group.iterator$(); $go.hasNext$()&&((go=($go.next$())),1);) {
var delta=groupCenter - $I$(2).center$jme_canvas_Graphical2DObject$jme_util_Box_Axis(go, xOrY);
$I$(2).move$jme_canvas_Graphical2DObject$jme_util_Box_Axis$D(go, xOrY, delta);
}
});

Clazz.newMeth(C$, 'closestDistance$D$D',  function (x, y) {
var min=1.7976931348623157E308;
for (var go, $go = this.group.iterator$(); $go.hasNext$()&&((go=($go.next$())),1);) {
min=Math.min(min, go.closestDistance$D$D(x, y));
}
return min;
});

Clazz.newMeth(C$, 'add$jme_canvas_Graphical2DObject',  function (element) {
this.group.add$O(element);
});

Clazz.newMeth(C$, 'add$I$jme_canvas_Graphical2DObject',  function (pos, element) {
this.group.add$I$O(pos, element);
});

Clazz.newMeth(C$, 'size$',  function () {
return this.group.size$();
});

Clazz.newMeth(C$, 'isEmpty$',  function () {
return this.size$() == 0;
});

Clazz.newMeth(C$, 'distributePositions$jme_util_Box_Axis$D',  function (xOrY, margin) {
this.distributePositions$jme_util_Box_Axis$D$Z(xOrY, margin, true);
});

Clazz.newMeth(C$, 'distributePositions$jme_util_Box_Axis$D$Z',  function (xOrY, margin, keepXorYorder) {
if (this.size$() <= 1) {
return;
}var sorted=Clazz.new_(C$);
sorted.addAll$jme_canvas_Graphical2DObjectGroup(this);
sorted.removeNoSizeObjects$();
if (sorted.size$() <= 1) {
return;
}var beforeAlignCenter=$I$(2).center$jme_canvas_Graphical2DObject$jme_util_Box_Axis(sorted, xOrY);
if (keepXorYorder) {
$I$(3,"sort$java_util_List$java_util_Comparator",[sorted.group, ((P$.Graphical2DObjectGroup$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "Graphical2DObjectGroup$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$jme_canvas_Graphical2DObject$jme_canvas_Graphical2DObject','compare$O$O'],  function (m1, m2) {
var x2=$I$(4,"get$java_awt_geom_Rectangle2D_Double$jme_util_Box_Axis",[m1.computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(null), this.$finals$.xOrY]);
var x1=$I$(4,"get$java_awt_geom_Rectangle2D_Double$jme_util_Box_Axis",[m2.computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(null), this.$finals$.xOrY]);
return x1 > x2  ? -1 : (x2 < x1 ) ? 1 : 0;
});
})()
), Clazz.new_(P$.Graphical2DObjectGroup$1.$init$,[this, {xOrY:xOrY}]))]);
}var sumMove=0;
for (var mol, $mol = sorted.group.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
var moleculeBox=mol.computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(null);
var move=sumMove - $I$(4).get$java_awt_geom_Rectangle2D_Double$jme_util_Box_Axis(moleculeBox, xOrY);
$I$(2).move$jme_canvas_Graphical2DObject$jme_util_Box_Axis$D(mol, xOrY, move);
sumMove+=$I$(4).getDim$java_awt_geom_Rectangle2D_Double$jme_util_Box_Axis(moleculeBox, xOrY) + margin;
}
var afterAlignCenter=$I$(2).center$jme_canvas_Graphical2DObject$jme_util_Box_Axis(sorted, xOrY);
$I$(2).move$jme_canvas_Graphical2DObject$jme_util_Box_Axis$D(sorted, xOrY, beforeAlignCenter - afterAlignCenter);
Clazz.assert(C$, this, function(){return (Math.abs(beforeAlignCenter - $I$(2).center$jme_canvas_Graphical2DObject$jme_util_Box_Axis(sorted, xOrY)) < 0.001 )});
});

Clazz.newMeth(C$, 'removeNoSizeObjects$',  function () {
var emptyList=Clazz.new_(C$);
for (var mol, $mol = this.group.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
var moleculeBox=mol.computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(null);
if (moleculeBox == null  || moleculeBox.isEmpty$() ) {
emptyList.add$jme_canvas_Graphical2DObject(mol);
}}
for (var mol, $mol = emptyList.group.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
this.group.remove$O(mol);
}
return emptyList.size$() > 0;
});

Clazz.newMeth(C$, 'addAll$jme_canvas_Graphical2DObjectGroup',  function (graphical2dObjectGroup) {
this.addAll$java_util_ArrayList(graphical2dObjectGroup.group);
});

Clazz.newMeth(C$, 'addAll$java_util_ArrayList',  function (graphical2dObjectList) {
this.group.addAll$java_util_Collection(graphical2dObjectList);
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:53 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
