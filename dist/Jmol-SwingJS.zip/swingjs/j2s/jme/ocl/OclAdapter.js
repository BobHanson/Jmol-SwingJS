(function(){var P$=Clazz.newPackage("jme.ocl"),I$=[[0,'com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.MolfileParser','jme.io.JMESVGWriter','com.actelion.research.gui.generic.GenericRectangle','com.actelion.research.chem.IDCodeParser','com.actelion.research.chem.MolfileCreator','jme.JMEmol','com.actelion.research.chem.SmilesParser','com.actelion.research.chem.moreparsers.InChIParser','com.actelion.research.chem.inchi.InChIOCL','com.actelion.research.chem.moreparsers.InChIKeyResolver','com.actelion.research.chem.moreparsers.CDXParser','com.actelion.research.chem.coords.CoordinateInventor',['jme.io.JMEReader','.SupportedInputFileFormat'],'com.actelion.research.chem.AromaticityResolver',['jme.gui.GUI','.Ring']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "OclAdapter");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getInchiVersion$',  function () {
return "unknown";
});

Clazz.newMeth(C$, 'getOclCode$S',  function (molFile) {
var result=null;
var mol=Clazz.new_($I$(1,1));
if (Clazz.new_($I$(2,1)).parse$com_actelion_research_chem_StereoMolecule$S(mol, molFile)) {
result=mol.getIDCode$();
}return result;
});

Clazz.newMeth(C$, 'getOclSVG$S',  function (molFile) {
var width=400;
var height=300;
var mol=Clazz.new_($I$(1,1));
if (Clazz.new_($I$(2,1)).parse$com_actelion_research_chem_StereoMolecule$S(mol, molFile)) {
var svgd=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule$S,[mol, molFile]);
svgd.setLegacyMode$Z(false);
svgd.validateView$O$com_actelion_research_gui_generic_GenericRectangle$I(null, Clazz.new_($I$(4,1).c$$D$D$D$D,[0, 0, width, height]), 131072);
svgd.paint$O(null);
return svgd.toString();
}return null;
});

Clazz.newMeth(C$, 'OclCodeToMOL$S',  function (oclCode) {
var mol=Clazz.new_($I$(5,1)).getCompactMolecule$S(oclCode.trim$());
var mfc=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_ExtendedMolecule,[mol]);
return mfc.getMolfile$();
});

Clazz.newMeth(C$, 'SMILEStoMOL$S',  function (smiles) {
if (smiles == null  || smiles.length$() == 0  || smiles.trim$().length$() == 0 ) return Clazz.new_($I$(7,1)).createMolFile$S("");
var mol=Clazz.new_($I$(1,1));
Clazz.new_($I$(8,1)).parse$com_actelion_research_chem_StereoMolecule$S(mol, smiles.trim$());
var mfc=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_ExtendedMolecule,[mol]);
return mfc.getMolfile$();
});

Clazz.newMeth(C$, 'v3000toV2000MOL$S',  function (v3000Mol) {
var mol=Clazz.new_($I$(1,1));
var success=Clazz.new_($I$(2,1)).parse$com_actelion_research_chem_StereoMolecule$S(mol, v3000Mol);
if (success) {
var mfc=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_ExtendedMolecule,[mol]);
return mfc.getMolfile$();
}return null;
});

Clazz.newMeth(C$, 'inchiToMOL$S',  function (inchi) {
var mol=Clazz.new_($I$(1,1));
var success=Clazz.new_($I$(9,1)).parse$com_actelion_research_chem_StereoMolecule$S(mol, inchi);
if (success) {
var mfc=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_ExtendedMolecule,[mol]);
return mfc.getMolfile$();
}return null;
});

Clazz.newMeth(C$, 'molToInChI$S$S',  function (molFileData, options) {
var mol=Clazz.new_($I$(1,1));
Clazz.new_($I$(2,1)).parse$com_actelion_research_chem_StereoMolecule$S(mol, molFileData);
return $I$(10).getInChI$S$S(molFileData, options);
});

Clazz.newMeth(C$, 'molToInChIKey$S$S',  function (molFileData, options) {
var mol=Clazz.new_($I$(1,1));
Clazz.new_($I$(2,1)).parse$com_actelion_research_chem_StereoMolecule$S(mol, molFileData);
return $I$(10).getInChIKey$S$S(molFileData, options);
});

Clazz.newMeth(C$, 'inchikeyToMOL$S',  function (inchikey) {
var mol=Clazz.new_($I$(1,1));
var success=Clazz.new_($I$(11,1)).resolve$com_actelion_research_chem_StereoMolecule$S(mol, inchikey);
if (success) {
var mfc=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_ExtendedMolecule,[mol]);
return mfc.getMolfile$();
}return null;
});

Clazz.newMeth(C$, 'cdxmlToMOL$S',  function (xml) {
var mol=Clazz.new_($I$(1,1));
var success=Clazz.new_($I$(12,1)).parse$com_actelion_research_chem_StereoMolecule$S(mol, xml);
if (success) {
var mfc=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_ExtendedMolecule,[mol]);
return mfc.getMolfile$();
}return null;
});

Clazz.newMeth(C$, 'cdxToMOL$BA',  function (bytes) {
var mol=Clazz.new_($I$(1,1));
var success=Clazz.new_($I$(12,1)).parse$com_actelion_research_chem_StereoMolecule$BA(mol, bytes);
if (success) {
var mfc=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_ExtendedMolecule,[mol]);
return mfc.getMolfile$();
}return null;
});

Clazz.newMeth(C$, 'compute2Dcoordinates$jme_JMEmol',  function (mol) {
var result=mol;
var molCopy=mol;
var hasExplicitHydrogens=mol.hasHydrogen$();
if (hasExplicitHydrogens) {
molCopy=mol.deepCopy$();
for (var i=1; i <= molCopy.natoms; i++) {
var atom=molCopy.getAtom$I(i);
if (atom.an == 1) {
atom.an=32;
atom.iso=0;
atom.label="A" + i;
}}
}var molFile=molCopy.createMolFile$S("");
var oclMol=Clazz.new_($I$(1,1));
if (Clazz.new_($I$(2,1)).parse$com_actelion_research_chem_StereoMolecule$S(oclMol, molFile)) {
var computed2D=true;
try {
Clazz.new_($I$(13,1).c$$I,[0]).invent$com_actelion_research_chem_StereoMolecule(oclMol);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
computed2D=false;
result=null;
} else {
throw e;
}
}
if (computed2D) {
if (oclMol.getAllAtoms$() == mol.nAtoms$()) {
for (var i=0; i < oclMol.getAllAtoms$(); i++) {
mol.XY$I$D$D(i + 1, oclMol.getAtomX$I(i), oclMol.getAtomY$I(i));
}
mol.internalBondLengthScaling$();
} else {
var mfc=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_ExtendedMolecule,[oclMol]);
try {
result=Clazz.new_([mol.jme, mfc.getMolfile$(), $I$(14).MOL, mol.parameters],$I$(7,1).c$$jme_JME$O$jme_io_JMEReader_SupportedInputFileFormat$jme_core_JMECore_Parameters);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
result.chiralFlag=mol.chiralFlag;
result.internalBondLengthScaling$();
}}}return result;
}, 1);

Clazz.newMeth(C$, 'reComputeBondOrderIfAromaticBondType$jme_JMEmol',  function (mol) {
if (!mol.hasAromaticBondType$()) {
return mol;
}var molFile=mol.createMolFile$S("");
var result=mol.deepCopy$();
var oclMol=Clazz.new_($I$(1,1));
if (!Clazz.new_($I$(2,1)).parse$com_actelion_research_chem_StereoMolecule$S(oclMol, molFile)) {
return mol;
}if (!(oclMol.getAllAtoms$() == mol.nAtoms$() && oclMol.getAllBonds$() == mol.nBonds$() )) {
return null;
}var computeBondOrder=true;
try {
var bondFixer=Clazz.new_($I$(15,1).c$$com_actelion_research_chem_ExtendedMolecule,[oclMol]);
bondFixer.locateDelocalizedDoubleBonds$ZA(null);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
computeBondOrder=false;
result=null;
} else {
throw e;
}
}
if (computeBondOrder) {
for (var b=0; b < oclMol.getAllBonds$(); b++) {
var bo=oclMol.getBondOrder$I(b);
var at1=oclMol.getBondAtom$I$I(0, b);
var at2=oclMol.getBondAtom$I$I(1, b);
var charge1=oclMol.getAtomCharge$I(at1++);
var charge2=oclMol.getAtomCharge$I(at2++);
if (mol.q$I(at1) != charge1 || mol.q$I(at2) != charge2 ) {
return null;
}var bond=result.bonds[b + 1];
if ((at1 == bond.va && at2 == bond.vb ) || (at2 == bond.va && at1 == bond.vb ) ) {
bond.bondType=bo;
} else {
return null;
}}
}return result;
}, 1);

Clazz.newMeth(C$, 'getRingInfo$jme_gui_GUI_RingInfo$jme_core_JMECore',  function (info, mol) {
var m=Clazz.new_($I$(1,1));
for (var i=1; i <= mol.natoms; i++) {
var a=mol.atoms[i];
var an=6;
switch (a.an) {
case 2:
an=5;
break;
case 4:
an=7;
break;
case 5:
an=8;
case 7:
an=15;
break;
case 8:
an=16;
case 13:
an=34;
break;
case 6:
an=14;
break;
case 9:
case 10:
case 11:
case 12:
an=9;
break;
case 1:
an=1;
break;
}
m.setAtomicNo$I$I(m.addAtom$D$D(a.x, a.y), an);
}
for (var i=1; i <= mol.nbonds; i++) {
var b=mol.bonds[i];
var type=b.bondType;
switch (b.bondType) {
case 1:
case 2:
type=b.bondType;
break;
case 3:
type=4;
break;
default:
type=1;
break;
}
m.setBondType$I$I(m.addBond$I$I(b.va - 1, b.vb - 1), type);
}
try {
var sys=m.getRingSet$();
for (var i=sys.getSize$(); --i >= 0; ) {
var isAromatic=sys.isAromatic$I(i);
if (isAromatic) info.bsAromaticRings.set$I(i);
var r=Clazz.new_($I$(16,1));
info.rings.add$O(r);
var bonds=sys.getRingBonds$I(i);
for (var j=bonds.length; --j >= 0; ) {
var pt=bonds[j] + 1;
r.bsBonds.set$I(pt);
var a1=mol.bonds[pt].va;
var a2=mol.bonds[pt].vb;
r.bsAtoms.set$I(a1);
r.bsAtoms.set$I(a2);
r.isAromatic=isAromatic;
if (mol.atoms[a1].an != 3) r.isHetero=true;
}
r.size=r.bsAtoms.cardinality$();
r.bondCount=r.bsBonds.cardinality$();
info.bsRingAtoms.or$java_util_BitSet(r.bsAtoms);
info.bsRingBonds.or$java_util_BitSet(r.bsBonds);
if (isAromatic) info.bsAromaticAtoms.or$java_util_BitSet(r.bsAtoms);
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$O(e);
} else {
throw e;
}
}
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
