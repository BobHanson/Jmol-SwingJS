(function(){var P$=Clazz.newPackage("jme.io"),I$=[[0,'java.awt.Toolkit','java.awt.datatransfer.DataFlavor']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TextTransfer", function(){
Clazz.newInstance(this, arguments,0,C$);
}, null, ['java.awt.datatransfer.ClipboardOwner', 'java.awt.event.ActionListener']);
C$.$classes$=[['PasteAction',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['pasteAction','jme.io.TextTransfer.PasteAction']]]

Clazz.newMeth(C$, 'test$',  function () {
var textTransfer=Clazz.new_(C$);
System.out.println$S("Clipboard contains:" + textTransfer.getClipboardContents$());
textTransfer.setClipboardContents$S("blah, blah, blah");
System.out.println$S("Clipboard contains:" + textTransfer.getClipboardContents$());
});

Clazz.newMeth(C$, 'lostOwnership$java_awt_datatransfer_Clipboard$java_awt_datatransfer_Transferable',  function (aClipboard, aContents) {
});

Clazz.newMeth(C$, 'setClipboardContents$S',  function (aString) {
{
navigator.clipboard.writeText(aString);
}
});

Clazz.newMeth(C$, 'getClipboardContents$',  function () {
var result=null;
var clipboard=$I$(1).getDefaultToolkit$().getSystemClipboard$();
var contents=clipboard.getContents$O(this);
var hasTransferableText=(contents != null ) && contents.isDataFlavorSupported$java_awt_datatransfer_DataFlavor($I$(2).stringFlavor) ;
if (hasTransferableText) {
try {
result=contents.getTransferData$java_awt_datatransfer_DataFlavor($I$(2).stringFlavor);
} catch (e$$) {
if (Clazz.exceptionOf(e$$,"java.awt.datatransfer.UnsupportedFlavorException")){
var ex = e$$;
{
System.out.println$O(ex);
ex.printStackTrace$();
}
} else if (Clazz.exceptionOf(e$$,"java.io.IOException")){
var ex = e$$;
{
System.out.println$O(ex);
ex.printStackTrace$();
}
} else {
throw e$$;
}
}
}return result;
});

Clazz.newMeth(C$, 'getAsyncClipboardContents$jme_io_TextTransfer_PasteAction',  function (pasteAction) {
this.pasteAction=pasteAction;
var content=this.getClipboardContents$();
if (content != null ) {
pasteAction.paste$S(content);
} else {
}});

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.pasteAction.paste$S(e.getActionCommand$());
});
;
(function(){/*i*/var C$=Clazz.newInterface(P$.TextTransfer, "PasteAction", function(){
});
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
