(function(){var P$=Clazz.newPackage("jme.io"),I$=[[0,'jme.util.JMEUtil']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ChemicalMimeType");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['S',['typeName','url','molfile']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'molfile$S',  function (separator) {
return C$.typeName + separator + C$.molfile ;
}, 1);

Clazz.newMeth(C$, 'chemicalMimeTag$',  function () {
return C$.molfile$S(":");
}, 1);

Clazz.newMeth(C$, 'extractEmbeddedChemicalString$S',  function (svg) {
var result=null;
var tag=C$.chemicalMimeTag$();
var tagStart=svg.indexOf$S(tag);
if (tagStart > 0) {
var molStart=svg.indexOf$S$I(">", tagStart) + 1;
var molEnd=svg.indexOf$S$I("</" + tag, molStart);
if (molEnd - molStart > 20) {
result=svg.substring$I$I(molStart, molEnd);
}}if (result == null ) return null;
if (result.indexOf$I("\n") < 0) result=result.replaceAll$S$S("\\\n", "\n");
return $I$(1).unwrapCData$S(result);
}, 1);

Clazz.newMeth(C$, 'additionalNameSpaces$S',  function (post) {
return "xmlns:" + C$.typeName + "=\"" + C$.url + "\"" + post ;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.typeName="chemical";
C$.url="http://www.ch.ic.ac.uk/chemime/";
C$.molfile="x-mdl-molfile";
};
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
