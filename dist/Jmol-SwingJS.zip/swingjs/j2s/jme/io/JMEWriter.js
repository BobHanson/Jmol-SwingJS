(function(){var P$=Clazz.newPackage("jme.io"),I$=[[0,'jme.util.JMEUtil','jme.util.Isotopes','jme.core.Atom','java.util.ArrayList','jme.JMEmol']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JMEWriter", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'jme.core.JMECore');
C$.$classes$=[['MolFileOrRxnParameters',9],['SupportedOutputFileFormat',25]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'createJMEString$jme_core_JMECore$Z$java_awt_geom_Rectangle2D_Double',  function (mol, addHydrogens, box) {
return Clazz.new_(C$.c$$jme_core_JMECore,[mol]).createJME$Z$java_awt_geom_Rectangle2D_Double(addHydrogens, box);
}, 1);

Clazz.newMeth(C$, 'createMolFile$jme_core_JMECore$S$Z$java_awt_geom_Rectangle2D_Double',  function (mol, header, stampDate, box) {
return Clazz.new_(C$.c$$jme_core_JMECore,[mol]).createMolFile$S$Z$java_awt_geom_Rectangle2D_Double(header, stampDate, box);
}, 1);

Clazz.newMeth(C$, 'createExtendedMolFile$jme_core_JMECore$S$Z$java_awt_geom_Rectangle2D_Double',  function (mol, header, stampDate, box) {
return Clazz.new_(C$.c$$jme_core_JMECore,[mol]).createExtendedMolFile$S$Z$java_awt_geom_Rectangle2D_Double(header, stampDate, box);
}, 1);

Clazz.newMeth(C$, 'c$$jme_core_JMECore',  function (mol) {
;C$.superclazz.c$$jme_core_JMECore.apply(this,[mol]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'transformAtomCoordinatesForOutput$java_awt_geom_Rectangle2D_Double',  function (boundingBox) {
var scale=0.055999999999999994;
if (boundingBox == null ) boundingBox=this.computeCoordinate2DboundingBox$();
if (boundingBox == null ) {
return;
}var ymax=boundingBox.y + boundingBox.height;
var xmin=boundingBox.x;
if (this.parameters.keepSameCoordinatesForOutput) {
xmin=0.0;
ymax=0.0;
scale=1.0;
}for (var i=1; i <= this.natoms; i++) {
var atom=this.atoms[i];
atom.x=(atom.x - xmin) * scale;
atom.y=(ymax - atom.y) * scale;
}
});

Clazz.newMeth(C$, 'createJME$Z$java_awt_geom_Rectangle2D_Double',  function (addHydrogens, box) {
var s="" + this.natoms + " " + this.nbonds ;
this.transformAtomCoordinatesForOutput$java_awt_geom_Rectangle2D_Double(box);
for (var i=1; i <= this.natoms; i++) {
var atom=this.atoms[i];
var iso=atom.iso;
var sa="";
if (iso != 0) {
sa+=iso;
}sa+=atom.getLabel$();
if ((addHydrogens || this.getValenceForMolOutput$I(i) > 0 ) && atom.nh > 0 ) {
sa+="H";
if (atom.nh > 1) sa+=atom.nh;
}if (atom.q != 0) {
if (atom.q > 0) sa+="+";
 else sa+="-";
if (Math.abs(atom.q) > 1) sa+=Math.abs(atom.q);
}var map=this.findAtomMapForOutput$I(i);
if (map != 0) sa+=":" + map;
s+=" " + sa + " " + $I$(1).fformat$D$I$I(atom.x, 0, 2) + " " + $I$(1).fformat$D$I$I(atom.y, 0, 2) ;
}
var d;
for (var i=1; i <= this.nbonds; i++) {
var a1=this.bonds[i].va;
var a2=this.bonds[i].vb;
var nas=this.bonds[i].bondType;
var stereo=this.bonds[i].stereo;
if (this.bonds[i].bondType == 9) {
nas=stereo;
} else {
switch (stereo) {
case 1:
nas=-1;
break;
case 2:
nas=-2;
break;
case 3:
case 4:
nas=(stereo == 3 ? -1 : -2);
d=a1;
a1=a2;
a2=d;
break;
case 10:
nas=-5;
break;
}
}s+=" " + a1 + " " + a2 + " " + nas ;
}
return s;
});

Clazz.newMeth(C$, 'createMolFile$S$Z$java_awt_geom_Rectangle2D_Double',  function (header, stampDate, box) {
var s=this.mdlHeaderLines$S$Z$Z(header, stampDate, false);
this.transformAtomCoordinatesForOutput$java_awt_geom_Rectangle2D_Double(box);
for (var i=1; i <= this.natoms; i++) {
var atom=this.atoms[i];
s+=$I$(1).fformat$D$I$I(atom.x, 10, 4) + $I$(1).fformat$D$I$I(atom.y, 10, 4) + $I$(1).fformat$D$I$I(0.0, 10, 4) ;
var z=this.getAtomLabel$I(i);
if (z.length$() == 1) z+="  ";
 else if (z.length$() == 2) z+=" ";
 else if (z.length$() > 3) z="Q  ";
s+=" " + z;
var charge=0;
if (this.q$I(i) > 0 && this.q$I(i) < 4 ) charge=4 - this.q$I(i);
 else if (this.q$I(i) < 0 && this.q$I(i) > -4 ) charge=4 - this.q$I(i);
var deltaIsotop=0;
if (atom.iso != 0) {
var delta=$I$(2,"getDeltaIsotopicMassOfElement$S$I",[this.getAtomLabel$I(i), this.atoms[i].iso]);
if (delta >= -3 && delta <= 4 ) {
deltaIsotop=delta;
}}var vv=0;
vv=this.getValenceForMolOutput$I(i);
z=$I$(1).iformat$I$I(deltaIsotop, 2) + $I$(1).iformat$I$I(charge, 3) + "  0" + $I$(1).iformat$I$I(vv, 3) + "  0  0  0  0  0" ;
var map=this.findAtomMapForOutput$I(i);
z+=$I$(1).iformat$I$I(map, 3);
s+=z + "  0  0" + "\n" ;
}
for (var i=1; i <= this.nbonds; i++) {
s+=C$.getMOLStereoBond$jme_core_Bond$Z(this.bonds[i], false) + "\n";
;}
for (var i=1; i <= this.natoms; i++) {
if (this.q$I(i) != 0) {
s+="M  CHG  1" + $I$(1).iformat$I$I(i, 4) + $I$(1,"iformat$I$I",[this.q$I(i), 4]) + "\n" ;
}if (this.atoms[i].iso != 0) {
s+="M  ISO  1" + $I$(1).iformat$I$I(i, 4) + $I$(1).iformat$I$I(this.atoms[i].iso, 4) + "\n" ;
}}
s+="M  END\n";
return s;
});

Clazz.newMeth(C$, 'getValenceForMolOutput$I',  function (at) {
var val=0;
var atom=this.atoms[at];
if (atom.nh > 0 && $I$(3).chargedMetalType$I(atom.an) != 0 ) {
val=atom.nh + atom.nv;
}return val;
});

Clazz.newMeth(C$, 'createExtendedMolFile2$S',  function (smiles) {
return this.createExtendedMolFile$S$Z$java_awt_geom_Rectangle2D_Double(smiles, true, null);
});

Clazz.newMeth(C$, 'createExtendedMolFile$S$Z$java_awt_geom_Rectangle2D_Double',  function (header, stampDate, box) {
var s=this.mdlHeaderLines$S$Z$Z(header, stampDate, true);
var mv30="M  V30 ";
s+=mv30 + "BEGIN CTAB" + "\n" ;
s+=mv30 + "COUNTS " + this.natoms + " " + this.nbonds + " 0 0 " + this.mdlChiralFlag$() + "\n" ;
s+=mv30 + "BEGIN ATOM" + "\n" ;
this.transformAtomCoordinatesForOutput$java_awt_geom_Rectangle2D_Double(box);
for (var i=1; i <= this.natoms; i++) {
var atom=this.atoms[i];
s+=mv30;
s+=i + " " + this.getAtomLabel$I(i) ;
var m=this.findAtomMapForOutput$I(i);
s+=" " + $I$(1).fformat$D$I$I(atom.x, 0, 4) + " " + $I$(1).fformat$D$I$I(atom.y, 0, 4) + " " + $I$(1).fformat$D$I$I(0.0, 0, 4) + " " + m ;
if (atom.q != 0) s+=" CHG=" + atom.q;
if (atom.iso > 0) {
s+=" MASS=" + atom.iso;
}var val=this.getValenceForMolOutput$I(i);
if (val != 0) s+=" VAL=" + val;
s+="\n";
}
s+=mv30 + "END ATOM" + "\n" ;
s+=mv30 + "BEGIN BOND" + "\n" ;
for (var i=1; i <= this.nbonds; i++) {
s+=mv30 + i + " " + C$.getMOLStereoBond$jme_core_Bond$Z(this.bonds[i], true) + "\n" ;
}
s+=mv30 + "END BOND" + "\n" ;
var abs=Clazz.new_($I$(4,1));
var orlists=Clazz.new_($I$(4,1));
var mixlists=Clazz.new_($I$(4,1));
for (var i=0; i < 10; i++) {
orlists.add$O(null);
mixlists.add$O(null);
}
for (var i=1; i <= this.natoms; i++) {
var atag=this.atoms[i].atag;
if (atag == null  || atag.length$() == 0 ) continue;
if (atag.equals$O("abs")) abs.add$O( new Integer(i));
 else if (atag.startsWith$S("mix")) {
var n=Integer.parseInt$S(atag.substring$I(3));
var o=(mixlists.size$() > n ? mixlists.get$I(n) : null);
var l=(o == null  ? Clazz.new_($I$(4,1)) : o);
l.add$O( new Integer(i));
mixlists.set$I$O(n, l);
} else if (atag.startsWith$S("or")) {
var n=Integer.parseInt$S(atag.substring$I(2));
var o=(orlists.size$() > n ? orlists.get$I(n) : null);
var l=(o == null  ? Clazz.new_($I$(4,1)) : o);
l.add$O( new Integer(i));
orlists.set$I$O(n, l);
}}
s+=C$.appendMOLCollection$S$java_util_ArrayList$S("MDLV30/STEABS", abs, mv30);
if (orlists.size$() > 0) for (var i=1; i < orlists.size$(); i++) s+=C$.appendMOLCollection$S$java_util_ArrayList$S("MDLV30/STEREL" + i, orlists.get$I(i), mv30);

if (mixlists.size$() > 0) for (var i=1; i < mixlists.size$(); i++) s+=C$.appendMOLCollection$S$java_util_ArrayList$S("MDLV30/STERAC" + i, mixlists.get$I(i), mv30);

s+=mv30 + "END CTAB" + "\n" ;
s+="M  END\n";
return s;
});

Clazz.newMeth(C$, 'appendMOLCollection$S$java_util_ArrayList$S',  function (name, list, mv30) {
if (list == null  || list.size$() == 0 ) return "";
var s="";
s+=mv30 + "BEGIN COLLECTION" + "\n" ;
s+=mv30 + name + " [ATOMS=(" + list.size$() ;
for (var i=list.iterator$(); i.hasNext$(); ) s+=" " + i.next$();

s+=")]\n";
s+=mv30 + "END COLLECTION" + "\n" ;
return s;
}, 1);

Clazz.newMeth(C$, 'mdlHeaderLines$S$Z$Z',  function (header, stampDate, isV3000) {
var writeChiralFlag=isV3000 ? 0 : this.mdlChiralFlag$();
var s=(header != null  && (header=header.trim$()).length$() > 0  ? header : "_");
if (s.length$() > 79) s=s.substring$I$I(0, 76) + "...";
s+="\n";
var versiondate="JME" + "2024-12-13" + " " + Clazz.new_(java.util.Date) ;
s+=C$.getSDFDateLine$S("JME2024-12-13") + "\n";
s+=versiondate + "\n";
s+=$I$(1).iformat$I$I(isV3000 ? 0 : this.natoms, 3) + $I$(1).iformat$I$I(isV3000 ? 0 : this.nbonds, 3);
s+="  0  0" + $I$(1).iformat$I$I(writeChiralFlag, 3) + "  0  0  0  0  0999 " + (isV3000 ? "V3000" : "V2000") + "\n" ;
return s;
});

Clazz.newMeth(C$, 'getMOLStereoBond$jme_core_Bond$Z',  function (bond, isV3000) {
var bondType=bond.bondType;
var a1=bond.va;
var a2=bond.vb;
var stereo=0;
if (bondType == 1 || bondType == 0 ) {
switch (bond.stereo) {
case 1:
case 3:
stereo=1;
break;
case 2:
case 4:
stereo=6;
break;
case 5:
case 6:
stereo=4;
}
switch (bond.stereo) {
case 3:
case 4:
case 6:
var t=a1;
a1=a2;
a2=t;
}
}if (bondType == 2 && bond.stereo == 10 ) {
stereo=3;
}if (isV3000) {
switch (stereo) {
case 6:
stereo=3;
break;
case 4:
case 3:
stereo=2;
}
}if (bondType == 0) {
bondType=8;
} else if (bondType == 9 || bondType == 5 ) {
bondType=4;
}var bonds;
if (isV3000) {
bonds=bondType + " " + a1 + " " + a2 ;
if (stereo != 0) bonds+=" CFG=" + stereo;
} else {
bonds=$I$(1).iformat$I$I(a1, 3) + $I$(1).iformat$I$I(a2, 3) + $I$(1).iformat$I$I(bondType, 3) + $I$(1).iformat$I$I(stereo, 3) + "  0  0  0" ;
}return bonds;
}, 1);

Clazz.newMeth(C$, 'mdlChiralFlag$',  function () {
return (this.getChiralFlag$()).$c() && this.canBeChiral$()  ? 1 : 0;
});

Clazz.newMeth(C$, 'createMolfile$jme_JMEmol$jme_io_JMEWriter_MolFileOrRxnParameters',  function (mol, arg) {
return (arg.isV3000 ? C$.createExtendedMolFile$jme_core_JMECore$S$Z$java_awt_geom_Rectangle2D_Double(mol, arg.header, arg.stampDate, null) : C$.createMolFile$jme_core_JMECore$S$Z$java_awt_geom_Rectangle2D_Double(mol, arg.header, arg.stampDate, null));
}, 1);

Clazz.newMeth(C$, 'generateMolFileOrRxn$jme_io_JMEWriter_MolFileOrRxnParameters$jme_JMEmolList',  function (pars, molList) {
if (!molList.isReaction) {
return C$.createMolfile$jme_JMEmol$jme_io_JMEWriter_MolFileOrRxnParameters(molList.size$() > 1 ? $I$(5).mergeMols$java_util_ArrayList(molList) : molList.get$I(0), pars);
}var s="";
var roles;
if (molList.reactionParts$I(2).size$() > 0) {
roles=Clazz.array(Integer.TYPE, -1, [1, 3, 2]);
} else {
roles=Clazz.array(Integer.TYPE, -1, [1, 3]);
}s+="$RXN\n\n\nJME Molecular Editor\n";
for (var r, $r = 0, $$r = roles; $r<$$r.length&&((r=($$r[$r])),1);$r++) {
var n=pars.mergeReationComponents ? 1 : molList.reactionParts$I(r).size$();
s+=$I$(1).iformat$I$I(n, 3);
}
s+="\n";
for (var r, $r = 0, $$r = roles; $r<$$r.length&&((r=($$r[$r])),1);$r++) {
var mols=molList.reactionParts$I$Z(r, pars.mergeReationComponents);
for (var mol, $mol = mols.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
s+="$MOL\n";
s+=C$.createMolfile$jme_JMEmol$jme_io_JMEWriter_MolFileOrRxnParameters(mol, pars);
}
}
return s;
}, 1);

Clazz.newMeth(C$, 'generateSmilesOrSmirks$jme_core_JMECore_Parameters$jme_JMEmolList',  function (pars, molList) {
if (molList.isReaction) {
return C$.generateSmilesOrSmirks$jme_core_JMECore_Parameters$jme_JMEmolList(pars, molList.reactionParts$I(1)) + ">" + C$.generateSmilesOrSmirks$jme_core_JMECore_Parameters$jme_JMEmolList(pars, molList.reactionParts$I(2)) + ">" + C$.generateSmilesOrSmirks$jme_core_JMECore_Parameters$jme_JMEmolList(pars, molList.reactionParts$I(3)) ;
}var result="";
for (var mol, $mol = molList.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
var smiles=mol.createSmiles$jme_core_JMECore_Parameters(pars);
if (smiles.length$() > 0) {
if (result.length$() > 0) result+=".";
result+=smiles;
}}
return result;
}, 1);

Clazz.newMeth(C$, 'generateJMEstring$Z$java_awt_geom_Rectangle2D_Double$jme_JMEmolList',  function (showImplicitHydrogens, boundingBox, molList) {
if (molList.isReaction) {
return C$.generateJMEstring$Z$java_awt_geom_Rectangle2D_Double$jme_JMEmolList(showImplicitHydrogens, boundingBox, molList) + ">" + C$.generateJMEstring$Z$java_awt_geom_Rectangle2D_Double$jme_JMEmolList(showImplicitHydrogens, boundingBox, molList) + ">" + C$.generateJMEstring$Z$java_awt_geom_Rectangle2D_Double$jme_JMEmolList(showImplicitHydrogens, boundingBox, molList) ;
}var result="";
for (var mol, $mol = molList.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
var jme=C$.createJMEString$jme_core_JMECore$Z$java_awt_geom_Rectangle2D_Double(mol, showImplicitHydrogens, boundingBox);
if (jme.length$() > 0) {
if (result.length$() > 0) result+="|";
result+=jme;
}}
return result;
}, 1);

Clazz.newMeth(C$, 'getSDFDateLine$S',  function (version) {
var mol=(version + "         ").substring$I$I(0, 10);
var cMM;
var cDD;
var cYYYY;
var cHH;
var cmm;
{
var c = new Date(); cMM = c.getMonth(); cDD = c.getDate(); cYYYY = c.getFullYear(); cHH = c.getHours(); cmm = c.getMinutes();
}
mol+=$I$(1,"rightJustify$S$S",["00", "" + (1 + cMM)]);
mol+=$I$(1).rightJustify$S$S("00", "" + cDD);
mol+=("" + cYYYY).substring$I$I(2, 4);
mol+=$I$(1).rightJustify$S$S("00", "" + cHH);
mol+=$I$(1).rightJustify$S$S("00", "" + cmm);
mol+="2D 1   1.00000     0.00000     0";
return mol;
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.JMEWriter, "MolFileOrRxnParameters", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.header="";
this.stampDate=false;
this.isV3000=false;
this.mergeReationComponents=false;
this.debugDoNotUpdateReactionRole=false;
},1);

C$.$fields$=[['Z',['stampDate','isV3000','mergeReationComponents','debugDoNotUpdateReactionRole'],'S',['header']]]

Clazz.newMeth(C$);
})()
;
(function(){/*e*/var C$=Clazz.newClass(P$.JMEWriter, "SupportedOutputFileFormat", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "JME", 0, []);
Clazz.newEnumConst($vals, C$.c$, "SMILES", 1, []);
Clazz.newEnumConst($vals, C$.c$, "MOL", 2, []);
Clazz.newEnumConst($vals, C$.c$, "MOL_V3000", 3, []);
Clazz.newEnumConst($vals, C$.c$, "STANDARD_INCHI", 4, []);
Clazz.newEnumConst($vals, C$.c$, "STANDARD_INCHI_KEY", 5, []);
Clazz.newEnumConst($vals, C$.c$, "INCHI_AUXINFO", 6, []);
Clazz.newEnumConst($vals, C$.c$, "INCHI_MODEL_JSON", 7, []);
Clazz.newEnumConst($vals, C$.c$, "OCLCODE", 8, []);
Clazz.newEnumConst($vals, C$.c$, "SVG", 9, []);
Clazz.newEnumConst($vals, C$.c$, "RAW_STRING_GRAPHIC", 10, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
