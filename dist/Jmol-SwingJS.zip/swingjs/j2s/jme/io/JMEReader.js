(function(){var P$=Clazz.newPackage("jme.io"),p$1={},p$2={},I$=[[0,'java.util.regex.Pattern',['jme.io.JMEReader','.MajorChemicalFormat'],'jme.io.ChemicalMimeType',['jme.io.JMEReader','.MinorChemicalFormat'],'java.util.StringTokenizer',['jme.io.JMEReader','.OclCheck'],['jme.io.JMEReader','.Author'],'jme.JMEmolList','jme.JMEmol',['jme.io.JMEReader','.SupportedInputFileFormat'],'jme.JME',['jme.JMEmol','.ReactionRole'],'java.util.ArrayList','jme.util.JMEUtil','jme.util.Isotopes','javax.swing.SwingUtilities']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JMEReader", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['OclCheck',10],['MajorChemicalFormat',26],['MinorChemicalFormat',26],['Author',26],['SupportedInputFileFormat',25]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['isReaction','formatDetected'],'S',['chemicalString','error'],'O',['majorChemicalFormat','jme.io.JMEReader.MajorChemicalFormat','minorChemicalFormat','jme.io.JMEReader.MinorChemicalFormat','author','jme.io.JMEReader.Author','embeddedChemicalFormat','jme.io.JMEReader','fileTypeRead','jme.io.JMEReader.SupportedInputFileFormat','chemicalBytes','byte[]']]
,['O',['InchiKeyPattern','java.util.regex.Pattern','+Smiles6Pattern','+SmilesOrSmirksPattern','+NonSmilesPattern','+SpacePattern','+Smartspattern','+ExtendedSmartsExtraPattern','+SmartsExtraPattern','+CSRMlpattern','+URLpattern','cdxMagic','byte[]']]]

Clazz.newMeth(C$, 'getError$',  function () {
return this.error;
});

Clazz.newMeth(C$, 'getFileTypeRead$',  function () {
return this.fileTypeRead;
});

Clazz.newMeth(C$, 'wasFormatDetected$',  function () {
return this.formatDetected;
});

Clazz.newMeth(C$, 'c$$O',  function (chemicalStringOrBytes) {
;C$.$init$.apply(this);
this.formatDetected=p$2.detectFormat$O.apply(this, [chemicalStringOrBytes]);
}, 1);

Clazz.newMeth(C$, 'reset',  function () {
p$2.init$jme_io_JMEReader.apply(this, [null]);
}, p$2);

Clazz.newMeth(C$, 'isCDXML$S',  function (s) {
return (s.indexOf$S("<CDXML") >= 0);
}, 1);

Clazz.newMeth(C$, 'isCDX$BA',  function (b) {
return C$.bytesMatch$BA$I$BA(b, 0, C$.cdxMagic);
}, 1);

Clazz.newMeth(C$, 'bytesMatch$BA$I$BA',  function (a, pt, b) {
if (b.length > a.length - pt) return false;
for (var i=b.length; --i >= 0; ) {
if (a[pt + i] != b[i]) return false;
}
return true;
}, 1);

Clazz.newMeth(C$, 'detectFormat$O',  function (chemicalStringOrBytes) {
p$2.reset.apply(this, []);
var success=false;
if (Clazz.instanceOf(chemicalStringOrBytes, Clazz.array(Byte.TYPE, -1))) {
this.chemicalBytes=chemicalStringOrBytes;
if (C$.isCDX$BA(this.chemicalBytes)) {
this.majorChemicalFormat=$I$(2).CDX;
return true;
}chemicalStringOrBytes= String.instantialize(this.chemicalBytes);
this.chemicalBytes=null;
}this.chemicalString=chemicalStringOrBytes;
if (this.chemicalString == null  || C$.URLpattern.matcher$CharSequence(this.chemicalString).find$() ) {
return false;
}if (C$.isCDXML$S(this.chemicalString)) {
this.majorChemicalFormat=$I$(2).CDXML;
return true;
}var numberOfLines=C$.countLines$S$I(this.chemicalString, 5);
if (numberOfLines == 1) {
this.chemicalString=this.chemicalString.trim$();
}if (this.chemicalString.length$() == 0) {
return false;
}do {
if (C$.CSRMlpattern.matcher$CharSequence(this.chemicalString).find$()) {
this.majorChemicalFormat=$I$(2).CSRML;
break;
}if (numberOfLines > 4) {
if (this.chemicalString.startsWith$S("<")) {
if (this.chemicalString.toLowerCase$().startsWith$S("<svg")) {
var mol=$I$(3).extractEmbeddedChemicalString$S(this.chemicalString);
if (mol != null ) {
this.embeddedChemicalFormat=Clazz.new_(C$.c$$O,[mol]);
if (this.embeddedChemicalFormat.majorChemicalFormat != null ) {
this.majorChemicalFormat=$I$(2).SVG;
}}}break;
}if (this.chemicalString.contains$CharSequence("M  END") || (this.chemicalString.contains$CharSequence("M END") && (this.chemicalString.contains$CharSequence("V2000") || this.chemicalString.contains$CharSequence("V3000") ) ) ) {
this.majorChemicalFormat=$I$(2).MOL;
if (this.chemicalString.contains$CharSequence("V2000")) {
this.minorChemicalFormat=$I$(4).V2000;
}if (this.chemicalString.contains$CharSequence("V3000")) {
this.minorChemicalFormat=$I$(4).V3000;
}if (this.chemicalString.startsWith$S("$RXN")) {
this.majorChemicalFormat=$I$(2).RXN;
} else if (this.chemicalString.contains$CharSequence("$$$$")) {
this.majorChemicalFormat=$I$(2).SDF;
}break;
}}if (numberOfLines == 1) {
if (this.chemicalString.startsWith$S("InChI=") || this.chemicalString.startsWith$S("AuxInfo=") ) {
this.majorChemicalFormat=$I$(2).InChI;
break;
}if (this.chemicalString.length$() == 27) {
var m=C$.InchiKeyPattern.matcher$CharSequence(this.chemicalString);
if (m.find$()) {
this.majorChemicalFormat=$I$(2).InChIkey;
break;
}}if (this.chemicalString.length$() >= 1) {
var hasSpace=C$.SpacePattern.matcher$CharSequence(this.chemicalString).find$();
if (hasSpace) {
var st=Clazz.new_($I$(5,1).c$$S$S,[this.chemicalString, " |"]);
try {
var next;
next=st.nextToken$();
while (next.equals$O("|")){
next=st.nextToken$();
}
var natomsx=Integer.valueOf$S(next).intValue$();
var nbondsx=Integer.valueOf$S(st.nextToken$()).intValue$();
for (var i=0; i < 3 * (natomsx + nbondsx); i++) {
st.nextToken$();
}
this.isReaction=this.chemicalString.indexOf$S(">") > 0;
this.majorChemicalFormat=$I$(2).JME;
break;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
} else if ($I$(6).isOclIdCode$S(this.chemicalString)) {
this.majorChemicalFormat=$I$(2).OCLCODE;
break;
} else if (!C$.NonSmilesPattern.matcher$CharSequence(this.chemicalString).find$()) {
var isReaction=this.chemicalString.indexOf$S(">") > 0;
var isSmarts=C$.Smartspattern.matcher$CharSequence(this.chemicalString).find$();
var canBeExtendedSmarts=C$.ExtendedSmartsExtraPattern.matcher$CharSequence(this.chemicalString).find$();
var isSmiles=C$.SmilesOrSmirksPattern.matcher$CharSequence(this.chemicalString).find$() && !C$.SmartsExtraPattern.matcher$CharSequence(this.chemicalString).find$() && !canBeExtendedSmarts  ;
if (isSmiles) {
this.majorChemicalFormat=$I$(2).SMILES;
if (isReaction) {
this.majorChemicalFormat=$I$(2).SMIRKS;
this.isReaction=isReaction;
}} else if (isSmarts || canBeExtendedSmarts ) {
this.majorChemicalFormat=$I$(2).SMARTS;
if (canBeExtendedSmarts) {
this.minorChemicalFormat=$I$(4).extended;
}}break;
}}}} while (false);
if (this.majorChemicalFormat != null ) {
success=true;
p$2.setAuthor.apply(this, []);
}return success;
}, p$2);

Clazz.newMeth(C$, 'setAuthor',  function () {
switch (this.majorChemicalFormat) {
case $I$(2).InChIkey:
case $I$(2).InChI:
this.author=$I$(7).IUPAC;
break;
case $I$(2).SMILES:
case $I$(2).SMARTS:
case $I$(2).SMIRKS:
this.author=$I$(7).DAYLIGHT;
break;
case $I$(2).CSRML:
this.author=$I$(7).MolecularNetworks;
break;
case $I$(2).CDX:
case $I$(2).CDXML:
this.author=$I$(7).RevitySignals;
break;
case $I$(2).JME:
this.author=$I$(7).P_ERTL;
break;
case $I$(2).MOL:
case $I$(2).RXN:
case $I$(2).SDF:
this.author=$I$(7).MDL;
break;
case $I$(2).OCLCODE:
this.author=$I$(7).OPENCHEMLIB;
break;
case $I$(2).SVG:
break;
}
}, p$2);

Clazz.newMeth(C$, 'isReaction',  function () {
return this.isReaction || this.majorChemicalFormat === $I$(2).RXN   || this.majorChemicalFormat === $I$(2).SMIRKS  ;
}, p$2);

Clazz.newMeth(C$, 'countLines$S$I',  function (str, stop) {
if (str == null  || str.length$() == 0 ) return 0;
var lines=1;
var len=str.length$();
for (var pos=0; pos < len; pos++) {
if (stop > 0 && lines > stop ) return lines;
var c=str.charAt$I(pos);
if (c == "\r") {
++lines;
if (pos + 1 < len && str.charAt$I(pos + 1) == "\n" ) ++pos;
} else if (c == "\n") {
++lines;
}}
return lines;
}, 1);

Clazz.newMeth(C$, 'init$jme_io_JMEReader',  function (other) {
if (other == null ) {
this.author=null;
this.majorChemicalFormat=null;
this.minorChemicalFormat=null;
this.isReaction=false;
return;
}this.author=other.author;
this.majorChemicalFormat=other.majorChemicalFormat;
this.minorChemicalFormat=other.minorChemicalFormat;
this.isReaction=other.isReaction;
this.embeddedChemicalFormat=other.embeddedChemicalFormat;
this.chemicalString=other.chemicalString;
this.chemicalBytes=other.chemicalBytes;
}, p$2);

Clazz.newMeth(C$, 'readMDLstringInput$S$jme_core_JMECore_Parameters',  function (s, pars) {
var molList=Clazz.new_($I$(8,1));
try {
molList.isReaction=s.startsWith$S("$RXN");
if (molList.isReaction) {
molList.addAll$java_util_Collection(C$.readReactionMols$S$jme_core_JMECore_Parameters(s, pars));
} else {
molList.add$O(C$.readSingleMOL$S$jme_core_JMECore_Parameters(s, pars));
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
molList.error=e;
return null;
} else {
throw e;
}
}
return molList;
}, 1);

Clazz.newMeth(C$, 'readJMEstringInput$S$jme_core_JMECore_Parameters',  function (molecule, pars) {
var molList=Clazz.new_($I$(8,1));
var st=Clazz.new_($I$(5,1).c$$S$S$Z,[molecule, "|>", true]);
molList.isReaction=(molecule.indexOf$S(">") > -1);
var nt=st.countTokens$();
var roleIndex=0;
for (var i=1; i <= nt; i++) {
var s=st.nextToken$();
s.trim$();
if (s.equals$O("|")) continue;
if (s.equals$O(">")) {
++roleIndex;
continue;
}if (roleIndex > 3) {
return molList.setErrorMsg$S("too many \">\"");
}var mol=null;
try {
mol=Clazz.new_([null, s, $I$(10).JME, pars],$I$(9,1).c$$jme_JME$O$jme_io_JMEReader_SupportedInputFileFormat$jme_core_JMECore_Parameters);
if (mol.natoms == 0) {
return molList.setErrorMsg$S("0 atoms found in \"" + s + "\"" );
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return molList.setErrorMsg$S($I$(11).makeErrorMessage$Exception(e) + ": " + s );
} else {
throw e;
}
}
molList.add$O(mol);
if (molList.isReaction) {
mol.setReactionRole$I($I$(12).all[roleIndex]);
}}
return molList;
}, 1);

Clazz.newMeth(C$, 'readReactionMols$S$jme_core_JMECore_Parameters',  function (s, pars) {
var mols=Clazz.new_($I$(13,1));
var separator=$I$(14).findLineSeparator$S(s);
var st=Clazz.new_($I$(5,1).c$$S$S$Z,[s, separator, true]);
var line="";
for (var i=1; i <= 5; i++) {
line=$I$(14).nextData$java_util_StringTokenizer$S(st, separator);
}
var nr=Integer.valueOf$S(line.substring$I$I(0, 3).trim$()).intValue$();
var np=Integer.valueOf$S(line.substring$I$I(3, 6).trim$()).intValue$();
var na=0;
if (line.length$() >= 9) {
na=Integer.valueOf$S(line.substring$I$I(6, 9).trim$()).intValue$();
}$I$(14).nextData$java_util_StringTokenizer$S(st, separator);
for (var p=1; p <= nr + np + na ; p++) {
var m="";
while (true){
var ns=$I$(14).nextData$java_util_StringTokenizer$S(st, separator);
if (ns == null  || ns.equals$O("$MOL") ) break;
 else m+=ns + separator;
}
var mol=C$.readSingleMOL$S$jme_core_JMECore_Parameters(m, pars);
mols.add$O(mol);
if (p <= nr) {
mol.setReactionRole$I(1);
} else if (p > nr && p <= nr + np ) {
mol.setReactionRole$I(3);
} else {
mol.setReactionRole$I(2);
}}
return mols;
}, 1);

Clazz.newMeth(C$, 'readSingleMOL$S$jme_core_JMECore_Parameters',  function (s, pars) {
return Clazz.new_([null, s, $I$(10).MOL, pars],$I$(9,1).c$$jme_JME$O$jme_io_JMEReader_SupportedInputFileFormat$jme_core_JMECore_Parameters);
}, 1);

Clazz.newMeth(C$, 'createMolFromString$jme_core_JMECore$S',  function (mol, jmeString) {
if (jmeString.startsWith$S("\"")) jmeString=jmeString.substring$I$I(1, jmeString.length$());
if (jmeString.endsWith$S("\"")) jmeString=jmeString.substring$I$I(0, jmeString.length$() - 1);
if (jmeString.length$() < 1) {
mol.natoms=0;
return;
}try {
var st=Clazz.new_($I$(5,1).c$$S,[jmeString]);
var natomsx=Integer.valueOf$S(st.nextToken$()).intValue$();
var nbondsx=Integer.valueOf$S(st.nextToken$()).intValue$();
for (var i=1; i <= natomsx; i++) {
var symbol=st.nextToken$();
var atom=mol.createAtom$S(symbol);
atom.x=Double.valueOf$S(st.nextToken$()).doubleValue$();
atom.y=-Double.valueOf$S(st.nextToken$()).doubleValue$();
}
for (var i=1; i <= nbondsx; i++) {
var bond=mol.createAndAddBondFromOther$jme_core_Bond(null);
bond.va=Integer.valueOf$S(st.nextToken$()).intValue$();
bond.vb=Integer.valueOf$S(st.nextToken$()).intValue$();
var bondType=Integer.valueOf$S(st.nextToken$()).intValue$();
var stereob=0;
if (bondType == -1) {
bondType=1;
stereob=1;
} else if (bondType == -2) {
bondType=1;
stereob=2;
} else if (bondType == -5) {
bondType=2;
stereob=10;
} else if (bondType == 11 || bondType == 12  || bondType == 13  || bondType == 14 ) {
stereob=bondType;
bondType=9;
}bond.bondType=bondType;
bond.stereo=stereob;
}
mol.finalizeMolecule$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("read JSME string exception - " + e.getMessage$());
mol.natoms=0;
throw (e);
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'createMolFromMolData$jme_core_JMECore$S',  function (mol, molData) {
var line="";
var separator=$I$(14).findLineSeparator$S(molData);
if (separator == null ) {
return;
}var st=Clazz.new_($I$(5,1).c$$S$S$Z,[molData, separator, true]);
for (var i=1; i <= 4; i++) {
line=$I$(14).nextData$java_util_StringTokenizer$S(st, separator);
}
var natomsx=Integer.valueOf$S(line.substring$I$I(0, 3).trim$()).intValue$();
var nbondsx=Integer.valueOf$S(line.substring$I$I(3, 6).trim$()).intValue$();
var chiral=0;
try {
chiral=Integer.valueOf$S(line.substring$I$I(14, 15).trim$()).intValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
mol.setChiralFlag$Boolean(Boolean.valueOf$Z(chiral == 1));
var valences=Clazz.array(Integer.TYPE, [natomsx + 1]);
for (var i=1; i <= natomsx; i++) {
var atom=mol.createAtom$();
line=$I$(14).nextData$java_util_StringTokenizer$S(st, separator);
atom.x=Double.valueOf$S(line.substring$I$I(0, 10).trim$()).doubleValue$();
atom.y=-Double.valueOf$S(line.substring$I$I(10, 20).trim$()).doubleValue$();
atom.z=Double.valueOf$S(line.substring$I$I(20, 30).trim$()).doubleValue$();
var endsymbol=34;
if (line.length$() < 34) endsymbol=line.length$();
var symbol=line.substring$I$I(31, endsymbol).trim$();
mol.setAtom$I$S(i, symbol);
if (line.length$() >= 62) {
var s=line.substring$I$I(60, 63).trim$();
if (s.length$() > 0) {
var mark=Integer.valueOf$S(s).intValue$();
if (mark > 0) {
mol.setAtomMapFromInput$I$I(i, mark);
}}}if (line.length$() >= 36) {
var s=line.substring$I$I(34, 36).trim$();
if (s.length$() > 0) {
var delta=Integer.valueOf$S(s).intValue$();
if (delta != 0 && delta >= -3  && delta <= 4 ) {
var iso=$I$(15).getIsotopicMassOfElementDelta$S$I(symbol, delta);
if (iso < 0) iso=0;
mol.atoms[i].iso=iso;
}}}if (line.length$() >= 39) {
var s=line.substring$I$I(37, 39).trim$();
if (s.length$() > 0) {
var delta=Integer.valueOf$S(s).intValue$();
if (delta > 0 && delta <= 7 ) {
var charge=0;
switch (delta) {
case 1:
charge=3;
break;
case 2:
charge=2;
break;
case 3:
charge=1;
break;
case 4:
charge=0;
break;
case 5:
charge=-1;
break;
case 6:
charge=-2;
break;
case 7:
charge=-3;
break;
}
mol.Q$I$I(i, charge);
}}}if (line.length$() >= 45) {
var s=line.substring$I$I(43, 45).trim$();
if (s.length$() > 0) valences[i]=Integer.valueOf$S(s).intValue$();
}}
for (var i=1; i <= nbondsx; i++) {
var bond=mol.createAndAddBondFromOther$jme_core_Bond(null);
line=$I$(14).nextData$java_util_StringTokenizer$S(st, separator);
bond.va=Integer.valueOf$S(line.substring$I$I(0, 3).trim$()).intValue$();
bond.vb=Integer.valueOf$S(line.substring$I$I(3, 6).trim$()).intValue$();
var nasvx=Integer.valueOf$S(line.substring$I$I(6, 9).trim$()).intValue$();
var bondType;
if (nasvx == 1) bondType=1;
 else if (nasvx == 2) bondType=2;
 else if (nasvx == 3) bondType=3;
 else if (nasvx == 8) bondType=0;
 else bondType=9;
var stereoVal=0;
if (line.length$() > 11) stereoVal=Integer.valueOf$S(line.substring$I$I(9, 12).trim$()).intValue$();
if (bondType == 1 || bondType == 0 ) {
if (stereoVal == 1) {
bond.stereo=1;
} else if (stereoVal == 6) {
bond.stereo=2;
} else if (stereoVal == 4) {
bond.stereo=5;
}}if (nasvx == 2 && stereoVal == 3 ) {
bondType=2;
bond.stereo=10;
}bond.bondType=bondType;
}
while (st.hasMoreTokens$()){
if ((line=st.nextToken$()) == null ) break;
if (line.startsWith$S("M  END")) break;
if (line.startsWith$S("M  CHG")) {
var stq=Clazz.new_($I$(5,1).c$$S,[line]);
stq.nextToken$();
stq.nextToken$();
var ndata=Integer.valueOf$S(stq.nextToken$()).intValue$();
for (var i=1; i <= ndata; i++) {
var a=Integer.valueOf$S(stq.nextToken$()).intValue$();
mol.atoms[a].q=Integer.valueOf$S(stq.nextToken$()).intValue$();
}
}if (line.startsWith$S("M  ISO")) {
var stq=Clazz.new_($I$(5,1).c$$S,[line]);
stq.nextToken$();
stq.nextToken$();
var ndata=Integer.valueOf$S(stq.nextToken$()).intValue$();
for (var i=1; i <= ndata; i++) {
var a=Integer.valueOf$S(stq.nextToken$()).intValue$();
mol.atoms[a].iso=Integer.valueOf$S(stq.nextToken$()).intValue$();
}
}if (line.startsWith$S("M  APO")) {
var stq=Clazz.new_($I$(5,1).c$$S,[line]);
stq.nextToken$();
stq.nextToken$();
var ndata=Integer.valueOf$S(stq.nextToken$()).intValue$();
for (var i=1; i <= ndata; i++) {
var a=Integer.valueOf$S(stq.nextToken$()).intValue$();
var nr=Integer.valueOf$S(stq.nextToken$()).intValue$();
mol.addBondToAtom$I$I$I$Z$D(1, a, 0, false, 0);
mol.setAtom$I$S(mol.natoms, "R" + nr);
}
}}
for (var i=1; i <= natomsx; i++) {
if (valences[i] > 0) {
var nv=mol.atoms[i].nv;
if (valences[i] != 15) {
var nh=valences[i] - nv;
if (nh > 0) mol.atoms[i].nh=nh;
} else {
mol.atoms[i].nh=0;
}}}
mol.finalizeMolecule$();
}, 1);

Clazz.newMeth(C$, 'readMoleculeData$jme_JME$Z$jme_js_AsyncCallback$Z$Z',  function (jme, runAsync, callback, recordEvent, repaint) {
if (this.majorChemicalFormat === $I$(2).SVG  && this.embeddedChemicalFormat != null  ) {
p$2.init$jme_io_JMEReader.apply(this, [this.embeddedChemicalFormat]);
}if (this.author === $I$(7).MDL  && this.minorChemicalFormat !== $I$(4).V3000  ) {
if (jme.handleReadMolFileRXN$S$Z(this.chemicalString, false)) this.fileTypeRead=p$2.isReaction.apply(this, []) ? $I$(10).RXN : $I$(10).MOL;
 else {
this.error="Invalid V2000 molfile";
}return;
}if (this.author === $I$(7).P_ERTL ) {
if (jme.readMolecule$S$Z(this.chemicalString, false)) {
this.fileTypeRead=$I$(10).JME;
} else {
this.error="Invalid JME string";
}return;
}if (this.majorChemicalFormat === $I$(2).CSRML ) {
this.error="Reading " + this.majorChemicalFormat + " is not supported" ;
return;
}var r=((P$.JMEReader$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "JMEReader$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'run$',  function () /*block*/{
p$2.oclSuccess$jme_JME$jme_js_AsyncCallback$Z$Z.apply(this.b$['jme.io.JMEReader'], [this.$finals$.jme, this.$finals$.callback, this.$finals$.recordEvent, this.$finals$.repaint]);
});
})()
), Clazz.new_(P$.JMEReader$lambda1.$init$,[this, {recordEvent:recordEvent,callback:callback,repaint:repaint,jme:jme}]));
if (runAsync) {
$I$(16).invokeLater$Runnable(r);
} else {
r.run$();
}});

Clazz.newMeth(C$, 'oclSuccess$jme_JME$jme_js_AsyncCallback$Z$Z',  function (jme, callback, recordEvent, repaint) {
var error=null;
var convertedmolFile=null;
var fileTypeRead=null;
switch (this.majorChemicalFormat) {
case $I$(2).MOL:
if (this.minorChemicalFormat === $I$(4).V3000 ) {
try {
convertedmolFile=C$.v3000toV2000MOL$S(this.chemicalString);
if (convertedmolFile == null ) {
throw Clazz.new_(Clazz.load('Exception').c$$S,["V3000 read failed."]);
}fileTypeRead=$I$(10).MOL_V3000;
jme.sdfPastedMessage.innerString="V3000 conversion provided by OpenChemLib";
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
error=e.getMessage$();
} else {
throw e;
}
}
break;
}break;
case $I$(2).SMARTS:
case $I$(2).SMILES:
case $I$(2).SMIRKS:
try {
convertedmolFile=jme.SMILESorSMIRKStoMolOrRXN$S(this.chemicalString);
switch (this.majorChemicalFormat) {
case $I$(2).SMIRKS:
fileTypeRead=$I$(10).SMIRKS;
break;
case $I$(2).SMILES:
fileTypeRead=$I$(10).SMILES;
break;
case $I$(2).SMARTS:
fileTypeRead=$I$(10).SMARTS;
default:
break;
}
jme.sdfPastedMessage.innerString="SMILES conversion provided by OpenChemLib";
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
error="SMILES parsing error:" + e.getMessage$();
} else {
throw e;
}
}
break;
case $I$(2).OCLCODE:
try {
convertedmolFile=jme.oclCodeToMOL$S(this.chemicalString);
fileTypeRead=$I$(10).OCLCODE;
error=null;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
error="OCL parsing failed";
} else {
throw e;
}
}
break;
case $I$(2).CDX:
try {
convertedmolFile=jme.cdxToMOL$BA(this.chemicalBytes);
fileTypeRead=$I$(10).CDX;
error=null;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
error="CDX parsing failed";
} else {
throw e;
}
}
break;
case $I$(2).CDXML:
try {
convertedmolFile=jme.cdxmlToMOL$S(this.chemicalString);
fileTypeRead=$I$(10).CDXML;
error=null;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
error="CDXML parsing failed";
e.printStackTrace$();
} else {
throw e;
}
}
break;
case $I$(2).CSRML:
case $I$(2).InChI:
try {
convertedmolFile=jme.inchiToMOL$S(this.chemicalString);
fileTypeRead=$I$(10).INCHI;
error=null;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
error="InChI parsing failed";
} else {
throw e;
}
}
break;
case $I$(2).InChIkey:
try {
convertedmolFile=jme.inchikeyToMOL$S(this.chemicalString);
fileTypeRead=$I$(10).INCHIKEY;
error=null;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
error="InChIKey parsing failed";
} else {
throw e;
}
}
break;
case $I$(2).JME:
case $I$(2).RXN:
case $I$(2).SDF:
case $I$(2).SVG:
break;
}
if (convertedmolFile != null  && error == null  ) {
var success=false;
try {
success=jme.handleReadMolFileRXN$S$Z(convertedmolFile, false);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
if (!success) error="Invalid molfile data";
}jme.processFileRead$jme_js_AsyncCallback$jme_io_JMEReader_SupportedInputFileFormat$S$Z(callback, fileTypeRead, error, repaint);
}, p$2);

Clazz.newMeth(C$, 'v3000toV2000MOL$S',  function (v3000Mol) {
return $I$(11).getOclAdapter$().v3000toV2000MOL$S(v3000Mol);
}, 1);

Clazz.newMeth(C$, 'equals$O',  function (o) {
if (this === o ) return true;
if (o == null  || o.getClass$() !== this.getClass$()  ) return false;
var r=o;
return C$.equals$O$O(this.author, r.author) && C$.equals$O$O(this.majorChemicalFormat, r.majorChemicalFormat) && C$.equals$O$O(this.minorChemicalFormat, r.minorChemicalFormat) && C$.equals$O$O(Boolean.valueOf$Z(this.isReaction), Boolean.valueOf$Z(r.isReaction)) && C$.equals$O$O(this.embeddedChemicalFormat, r.embeddedChemicalFormat)  ;
});

Clazz.newMeth(C$, 'equals$O$O',  function (a, b) {
return (a === b ) || (a != null  && a.equals$O(b) ) ;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.InchiKeyPattern=$I$(1).compile$S("^[A-Z]{14}\\-[A-Z]{10}\\-[A-Z]$");
C$.Smiles6Pattern=$I$(1,"compile$S$I",["^[^J][a-z0-9@+\\-\\[\\]\\(\\)\\\\\\/%=#$:>]{6,}$", 2]);
C$.SmilesOrSmirksPattern=$I$(1,"compile$S$I",["^[a-z0-9@+\\-\\[\\]\\(\\)\\\\\\/%=#$:>\\\\.]+$", 2]);
C$.NonSmilesPattern=$I$(1).compile$S("j");
C$.SpacePattern=$I$(1).compile$S("\\s+");
C$.Smartspattern=$I$(1,"compile$S$I",["^[a-z0-9@+\\-\\[\\]\\(\\)\\\\\\/%=#$:\\\\.,;!&]+$", 2]);
C$.ExtendedSmartsExtraPattern=$I$(1).compile$S("[\\^]");
C$.SmartsExtraPattern=$I$(1).compile$S$I("[,;!&]", 2);
C$.CSRMlpattern=$I$(1,"compile$S$I",["\\s*^(<\\?xml\\s+[^>]+>)?\\s*<\\s*csrml\\b", 2]);
C$.URLpattern=$I$(1).compile$S("$\\w+:\\/\\/");
C$.cdxMagic=Clazz.array(Byte.TYPE, -1, [86, 106, 67, 68]);
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.JMEReader, "OclCheck", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.nAvail=6;
},1);

C$.$fields$=[['I',['nAvail','pt','mData','abits','bbits','nBytes'],'O',['idcode','byte[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'isOclIdCode$S',  function (s) {
return p$1.isIDCode$S.apply(Clazz.new_(C$), [s]);
}, 1);

Clazz.newMeth(C$, 'isIDCode$S',  function (s) {
this.nBytes=s.indexOf$I("!");
if (this.nBytes < 0) this.nBytes=s.indexOf$I("#");
if (this.nBytes < 0) this.nBytes=s.length$();
if (this.nBytes < 10 || this.nBytes > 1000 ) return false;
this.idcode=s.substring$I$I(0, this.nBytes).getBytes$();
this.mData=(this.idcode[0] & 63) << 11;
try {
if (this.idcode == null  || this.idcode.length == 0 ) return false;
this.abits=p$1.decodeBits$I.apply(this, [4]);
this.bbits=p$1.decodeBits$I.apply(this, [4]);
var version=8;
if (this.abits > 8) {
version=this.abits;
this.abits=this.bbits;
}if (version != 8 && version != 9 ) return false;
var allAtoms=p$1.decodeBits$I.apply(this, [this.abits]);
var allBonds=p$1.decodeBits$I.apply(this, [this.bbits]);
var closureBonds=1 + allBonds - allAtoms;
if (allAtoms == 0 || closureBonds < 0  || closureBonds > allAtoms - 2 ) return false;
var nitrogens=p$1.decodeBits$I.apply(this, [this.abits]);
var oxygens=p$1.decodeBits$I.apply(this, [this.abits]);
var otherAtoms=p$1.decodeBits$I.apply(this, [this.abits]);
var chargedAtoms=p$1.decodeBits$I.apply(this, [this.abits]);
p$1.checkBits$I.apply(this, [nitrogens]);
p$1.checkBits$I.apply(this, [oxygens]);
p$1.checkBits$I.apply(this, [otherAtoms]);
p$1.checkBits$I.apply(this, [chargedAtoms]);
return true;
} catch (e) {
return false;
}
}, p$1);

Clazz.newMeth(C$, 'checkBits$I',  function (n) {
if (n != 0) {
for (var i=0; i < n; i++) p$1.decodeBits$I.apply(this, [this.abits]);

}}, p$1);

Clazz.newMeth(C$, 'decodeBits$I',  function (bits) {
var allBits=bits;
var data=0;
while (bits != 0){
if (this.nAvail == 0) {
if (++this.pt >= this.idcode.length) throw Clazz.new_(Clazz.load('NullPointerException'));
this.mData=(this.idcode[this.pt] & 63) << 11;
this.nAvail=6;
}data|=((65536 & this.mData) >> (16 - allBits + bits));
this.mData<<=1;
--bits;
--this.nAvail;
}
return data;
}, p$1);
})()
;
(function(){/*e*/var C$=Clazz.newClass(P$.JMEReader, "MajorChemicalFormat", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "CDX", 0, []);
Clazz.newEnumConst($vals, C$.c$, "CDXML", 1, []);
Clazz.newEnumConst($vals, C$.c$, "MOL", 2, []);
Clazz.newEnumConst($vals, C$.c$, "RXN", 3, []);
Clazz.newEnumConst($vals, C$.c$, "SDF", 4, []);
Clazz.newEnumConst($vals, C$.c$, "SMILES", 5, []);
Clazz.newEnumConst($vals, C$.c$, "SMARTS", 6, []);
Clazz.newEnumConst($vals, C$.c$, "SMIRKS", 7, []);
Clazz.newEnumConst($vals, C$.c$, "InChI", 8, []);
Clazz.newEnumConst($vals, C$.c$, "InChIkey", 9, []);
Clazz.newEnumConst($vals, C$.c$, "OCLCODE", 10, []);
Clazz.newEnumConst($vals, C$.c$, "JME", 11, []);
Clazz.newEnumConst($vals, C$.c$, "SVG", 12, []);
Clazz.newEnumConst($vals, C$.c$, "CSRML", 13, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()
;
(function(){/*e*/var C$=Clazz.newClass(P$.JMEReader, "MinorChemicalFormat", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "V2000", 0, []);
Clazz.newEnumConst($vals, C$.c$, "V3000", 1, []);
Clazz.newEnumConst($vals, C$.c$, "extended", 2, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()
;
(function(){/*e*/var C$=Clazz.newClass(P$.JMEReader, "Author", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "MDL", 0, []);
Clazz.newEnumConst($vals, C$.c$, "DAYLIGHT", 1, []);
Clazz.newEnumConst($vals, C$.c$, "IUPAC", 2, []);
Clazz.newEnumConst($vals, C$.c$, "OPENCHEMLIB", 3, []);
Clazz.newEnumConst($vals, C$.c$, "P_ERTL", 4, []);
Clazz.newEnumConst($vals, C$.c$, "MolecularNetworks", 5, []);
Clazz.newEnumConst($vals, C$.c$, "RevitySignals", 6, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()
;
(function(){/*e*/var C$=Clazz.newClass(P$.JMEReader, "SupportedInputFileFormat", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "CDX", 0, []);
Clazz.newEnumConst($vals, C$.c$, "CDXML", 1, []);
Clazz.newEnumConst($vals, C$.c$, "INCHI", 2, []);
Clazz.newEnumConst($vals, C$.c$, "INCHIKEY", 3, []);
Clazz.newEnumConst($vals, C$.c$, "JME", 4, []);
Clazz.newEnumConst($vals, C$.c$, "SMARTS", 5, []);
Clazz.newEnumConst($vals, C$.c$, "SMILES", 6, []);
Clazz.newEnumConst($vals, C$.c$, "MOL", 7, []);
Clazz.newEnumConst($vals, C$.c$, "MOL_V3000", 8, []);
Clazz.newEnumConst($vals, C$.c$, "OCLCODE", 9, []);
Clazz.newEnumConst($vals, C$.c$, "RXN", 10, []);
Clazz.newEnumConst($vals, C$.c$, "SMIRKS", 11, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
