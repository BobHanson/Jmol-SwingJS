(function(){var P$=Clazz.newPackage("jme.io"),I$=[[0,'jme.util.JMEUtil','jme.io.ChemicalMimeType']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JMESVGWriter", null, 'com.actelion.research.chem.SVGDepictor');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['mdlMOL','tag']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$S',  function (mol, mdlMol) {
;C$.superclazz.c$$com_actelion_research_chem_StereoMolecule$S.apply(this,[mol, ""]);C$.$init$.apply(this);
if (mdlMol != null  && mdlMol.length$() > 0 ) this.mdlMOL=mdlMol;
var mode=224;
this.setDisplayMode$I(mode);
}, 1);

Clazz.newMeth(C$, 'additionalMetaInfo$S',  function (indent) {
var result="";
if (this.mdlMOL != null ) {
var molData=$I$(1).wrapCDATA$S(this.mdlMOL);
result=indent + "<" + $I$(2).chemicalMimeTag$() + ">" + molData + "</" + $I$(2).chemicalMimeTag$() + ">\n" ;
}return result;
});

Clazz.newMeth(C$, 'toString',  function () {
var svg=C$.superclazz.prototype.toString.apply(this, []);
if (this.mdlMOL != null ) {
var pt=svg.lastIndexOf$S("</");
if (pt > 0) {
svg=svg.substring$I$I(0, pt) + this.additionalMetaInfo$S("") + svg.substring$I(pt) ;
}pt=svg.indexOf$S("xmlns");
if (pt > 0) {
svg=svg.substring$I$I(0, pt) + $I$(2).additionalNameSpaces$S(" ") + svg.substring$I(pt) ;
}}return svg;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
