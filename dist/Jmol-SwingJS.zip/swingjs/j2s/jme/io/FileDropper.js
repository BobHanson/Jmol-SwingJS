(function(){var P$=Clazz.newPackage("jme.io"),p$1={},I$=[[0,'java.beans.PropertyChangeSupport','java.awt.dnd.DropTarget','java.awt.datatransfer.DataFlavor']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FileDropper", null, null, 'java.awt.dnd.DropTargetListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['fd_propSupport','java.beans.PropertyChangeSupport','pcl','java.beans.PropertyChangeListener']]
,['O',['uriDrop','java.awt.datatransfer.DataFlavor']]]

Clazz.newMeth(C$, 'c$$java_beans_PropertyChangeListener',  function (fileDropListener) {
;C$.$init$.apply(this);
this.fd_propSupport=Clazz.new_($I$(1,1).c$$O,[this]);
this.addPropertyChangeListener$java_beans_PropertyChangeListener(fileDropListener);
this.addPropertyChangeListener$java_beans_PropertyChangeListener((this.pcl=((P$.FileDropper$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "FileDropper$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.beans.PropertyChangeListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'propertyChange$java_beans_PropertyChangeEvent',  function (evt) {
if (evt.getPropertyName$().equals$O("inline")) p$1.loadInline$O.apply(this.b$['jme.io.FileDropper'], [evt.getNewValue$()]);
});
})()
), Clazz.new_(P$.FileDropper$1.$init$,[this, null]))));
var receiver=fileDropListener;
receiver.setDropTarget$java_awt_dnd_DropTarget(Clazz.new_($I$(2,1).c$$java_awt_Component$java_awt_dnd_DropTargetListener,[receiver, this]));
}, 1);

Clazz.newMeth(C$, 'dispose$',  function () {
this.removePropertyChangeListener$java_beans_PropertyChangeListener(this.pcl);
this.pcl=null;
this.fd_propSupport.removePropertyChangeListener$java_beans_PropertyChangeListener(null);
this.fd_propSupport=null;
});

Clazz.newMeth(C$, 'loadFile$S',  function (fname) {
this.fd_propSupport.firePropertyChange$S$O$O("FileDropper.file", null, fname);
}, p$1);

Clazz.newMeth(C$, 'loadInline$O',  function (content) {
this.fd_propSupport.firePropertyChange$S$O$O("FileDropper.inline", null, content);
}, p$1);

Clazz.newMeth(C$, 'addPropertyChangeListener$java_beans_PropertyChangeListener',  function (l) {
this.fd_propSupport.addPropertyChangeListener$java_beans_PropertyChangeListener(l);
});

Clazz.newMeth(C$, 'removePropertyChangeListener$java_beans_PropertyChangeListener',  function (l) {
this.fd_propSupport.removePropertyChangeListener$java_beans_PropertyChangeListener(l);
});

Clazz.newMeth(C$, 'dragOver$java_awt_dnd_DropTargetDragEvent',  function (dtde) {
});

Clazz.newMeth(C$, 'dragEnter$java_awt_dnd_DropTargetDragEvent',  function (dtde) {
dtde.acceptDrag$I(3);
});

Clazz.newMeth(C$, 'dragExit$java_awt_dnd_DropTargetEvent',  function (dtde) {
});

Clazz.newMeth(C$, 'dropActionChanged$java_awt_dnd_DropTargetDragEvent',  function (dtde) {
});

Clazz.newMeth(C$, 'drop$java_awt_dnd_DropTargetDropEvent',  function (dtde) {
System.out.println$S("FileDropper? " + dtde.getDropTargetContext$().getComponent$());
var t=dtde.getTransferable$();
var isAccepted=false;
if (C$.uriDrop != null  && t.isDataFlavorSupported$java_awt_datatransfer_DataFlavor(C$.uriDrop) ) {
if (p$1.doURIDrop$java_awt_datatransfer_Transferable$java_awt_dnd_DropTargetDropEvent$Z$java_awt_datatransfer_DataFlavor.apply(this, [t, dtde, isAccepted, C$.uriDrop])) return;
}if (t.isDataFlavorSupported$java_awt_datatransfer_DataFlavor($I$(3).javaFileListFlavor)) {
while (true){
var o=null;
try {
dtde.acceptDrop$I(3);
o=t.getTransferData$java_awt_datatransfer_DataFlavor($I$(3).javaFileListFlavor);
isAccepted=true;
if (Clazz.instanceOf(o, "java.util.List")) {
var fileList=o;
var length=fileList.size$();
if (length >= 1) {
var fileName=fileList.get$I(0).getAbsolutePath$().trim$();
if (fileName.endsWith$S(".URL")) {
break;
}dtde.getDropTargetContext$().dropComplete$Z(true);
p$1.loadFile$S.apply(this, [fileName]);
return;
}dtde.getDropTargetContext$().dropComplete$Z(true);
return;
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("jme.FileDropper failed " + e);
} else {
throw e;
}
}
break;
}
}var df=t.getTransferDataFlavors$();
if (df == null  || df.length == 0 ) return;
for (var i=0; i < df.length; ++i) {
var flavor=df[i];
var o=null;
var mimeType=flavor.getMimeType$();
if (mimeType.startsWith$S("text/uri-list") && flavor.getRepresentationClass$().getName$().equals$O("java.lang.String") ) {
C$.uriDrop=flavor;
if (p$1.doURIDrop$java_awt_datatransfer_Transferable$java_awt_dnd_DropTargetDropEvent$Z$java_awt_datatransfer_DataFlavor.apply(this, [t, dtde, isAccepted, flavor])) return;
} else if (mimeType.equals$O("application/x-java-serialized-object; class=java.lang.String") || mimeType.startsWith$S("text/plain;") ) {
try {
if (!isAccepted) dtde.acceptDrop$I(3);
isAccepted=true;
o=t.getTransferData$java_awt_datatransfer_DataFlavor(df[i]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("D.....");
} else {
throw e;
}
}
if (Clazz.instanceOf(o, "java.lang.String")) {
var content=o;
if (content.startsWith$S("file:/")) {
p$1.loadFile$S.apply(this, [content]);
} else {
p$1.loadInline$O.apply(this, [content]);
}dtde.getDropTargetContext$().dropComplete$Z(true);
return;
}}}
if (!isAccepted) dtde.rejectDrop$();
});

Clazz.newMeth(C$, 'doURIDrop$java_awt_datatransfer_Transferable$java_awt_dnd_DropTargetDropEvent$Z$java_awt_datatransfer_DataFlavor',  function (t, dtde, isAccepted, flavor) {
var o;
try {
if (!isAccepted) dtde.acceptDrop$I(3);
isAccepted=true;
o=t.getTransferData$java_awt_datatransfer_DataFlavor(flavor);
if (Clazz.instanceOf(o, "java.lang.String")) {
System.err.println$S("jme.FileDropper drop for " + o);
p$1.loadFile$S.apply(this, [o.toString()]);
dtde.getDropTargetContext$().dropComplete$Z(true);
return true;
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("jme.FileDropper failed drop for " + flavor);
} else {
throw e;
}
}
return false;
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
