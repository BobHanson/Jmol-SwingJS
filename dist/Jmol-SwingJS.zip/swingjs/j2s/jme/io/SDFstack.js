(function(){var P$=Clazz.newPackage("jme.io"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "SDFstack", null, 'java.util.ArrayList');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.currentIndex=-1;
},1);

C$.$fields$=[['I',['currentIndex']]]

Clazz.newMeth(C$, 'getCurrentDisplayIndex$',  function () {
return this.currentIndex + 1;
});

Clazz.newMeth(C$, 'addEntries$S',  function (sdfInput) {
if (sdfInput == null ) return 0;
var inputSDFentries=sdfInput.split$S("\\$\\$\\$\\$\r?\n?");
if (inputSDFentries.length <= 1) {
return 0;
}for (var sdf, $sdf = 0, $$sdf = inputSDFentries; $sdf<$$sdf.length&&((sdf=($$sdf[$sdf])),1);$sdf++) {
this.add$O(sdf);
}
return inputSDFentries.length;
});

Clazz.newMeth(C$, 'next$',  function () {
if (this.currentIndex < this.size$() - 1) {
++this.currentIndex;
return this.get$I(this.currentIndex);
} else {
return null;
}});

Clazz.newMeth(C$, 'previous$',  function () {
if (this.currentIndex > 0) {
--this.currentIndex;
return this.get$I(this.currentIndex);
} else {
return null;
}});

Clazz.newMeth(C$, 'first$',  function () {
this.currentIndex=-1;
return this.next$();
});

Clazz.newMeth(C$, 'last$',  function () {
this.currentIndex=this.size$();
return this.previous$();
});

Clazz.newMeth(C$, 'clear$',  function () {
this.currentIndex=-1;
C$.superclazz.prototype.clear$.apply(this, []);
});

Clazz.newMeth(C$, 'getMultiSDFstack$',  function () {
return this.toArray$OA(Clazz.array(String, [this.size$()]));
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
