(function(){var P$=Clazz.newPackage("jme"),p$1={},I$=[[0,'javax.swing.SwingUtilities','javax.swing.JFrame','javax.swing.JPanel','javax.swing.BoxLayout','javax.swing.JButton','java.awt.event.WindowAdapter','javax.swing.Box','javax.swing.JOptionPane','org.jmol.smiles.SmilesMatcher','java.awt.Dimension','javajs.util.Base64','java.io.ByteArrayOutputStream','javax.imageio.ImageIO','java.awt.Point','org.jmol.viewer.JC','javajs.util.PT','java.util.Hashtable','org.jmol.adapter.writers.CDXMLWriter','jme.JMEmolList','jme.JMEmol','jme.JME','org.jmol.util.Elements','org.jmol.api.JmolAdapter','java.net.URL','java.io.FileInputStream','java.io.File','java.io.BufferedInputStream','org.jmol.adapter.smarter.Resolver','Thread','org.jmol.viewer.Viewer']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JMEJmol", null, 'jme.JME', 'java.awt.event.WindowListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.allowClean=true;
this.args=Clazz.array(String, [0]);
this.cleaning=false;
},1);

C$.$fields$=[['Z',['allowClean','cleaning'],'S',['fileName'],'O',['vwr','org.jmol.viewer.Viewer','parentWindow','java.awt.Container','smilesMatcher','org.jmol.smiles.SmilesMatcher','args','String[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$javax_swing_JFrame$Z$SA.apply(this,[null, true, Clazz.array(String, [0])]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$SA',  function (args) {
;C$.superclazz.c$$javax_swing_JFrame$Z$SA.apply(this,[null, true, args]);C$.$init$.apply(this);
this.args=args;
this.setRemoveHsC$();
}, 1);

Clazz.newMeth(C$, 'setViewer$javax_swing_JFrame$org_jmol_viewer_Viewer$java_awt_Container$S',  function (frame, vwr, parent, frameType) {
this.parentWindow=parent;
this.vwr=vwr;
if (parent == null  && frame == null   && !"search".equals$O(frameType) ) this.headless=vwr.headless;
if (!this.headless) {
if (frame == null ) {
frame=p$1.getJmolFrame$S$Z.apply(this, [frameType, (parent == null )]);
}this.setFrame$javax_swing_JFrame(frame);
}this.initialize$SA(this.args);
if (parent != null ) {
if (vwr != null ) vwr.getInchi$javajs_util_BS$O$S(null, null, null);
$I$(1,"invokeLater$Runnable",[((P$.JMEJmol$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "JMEJmol$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'run$',  function () {
this.b$['jme.JME'].start$SA.apply(this.b$['jme.JME'], [Clazz.array(String, [0])]);
});
})()
), Clazz.new_(P$.JMEJmol$lambda1.$init$,[this, null]))]);
}});

Clazz.newMeth(C$, 'getJmolFrame$S$Z',  function (type, exit0) {
var frame=Clazz.new_([type === "search"  ? "Substructure search" : p$1.getTitle.apply(this, [])],$I$(2,1).c$$S);
var pp=Clazz.new_($I$(3,1));
var p=Clazz.new_($I$(3,1));
pp.add$S$java_awt_Component("Center", p);
p.setLayout$java_awt_LayoutManager(Clazz.new_($I$(4,1).c$$java_awt_Container$I,[p, 0]));
var b;
if ("search".equals$O(type)) {
p.add$java_awt_Component(b=Clazz.new_($I$(5,1).c$$S,["search"]));
b.addActionListener$java_awt_event_ActionListener(((P$.JMEJmol$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "JMEJmol$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
var smiles=this.b$['jme.JMEJmol'].smiles$.apply(this.b$['jme.JMEJmol'], []);
var f=this.b$['jme.JMEJmol'].options.getInfo$S("searchCallback");

f && f(smiles);
});
})()
), Clazz.new_(P$.JMEJmol$1.$init$,[this, null])));
} else {
if (exit0) {
frame.addWindowListener$java_awt_event_WindowListener(((P$.JMEJmol$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "JMEJmol$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.WindowAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'windowClosing$java_awt_event_WindowEvent',  function (evt) {
System.exit$I(0);
});
})()
), Clazz.new_($I$(6,1),[this, null],P$.JMEJmol$2)));
}p.add$java_awt_Component(b=Clazz.new_($I$(5,1).c$$S,["clean"]));
b.addActionListener$java_awt_event_ActionListener(((P$.JMEJmol$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "JMEJmol$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.JMEJmol'].doClean$.apply(this.b$['jme.JMEJmol'], []);
});
})()
), Clazz.new_(P$.JMEJmol$3.$init$,[this, null])));
p.add$java_awt_Component(b=Clazz.new_($I$(5,1).c$$S,["from 3D"]));
b.addActionListener$java_awt_event_ActionListener(((P$.JMEJmol$4||
(function(){/*a*/var C$=Clazz.newClass(P$, "JMEJmol$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.JMEJmol'].from3D$.apply(this.b$['jme.JMEJmol'], []);
});
})()
), Clazz.new_(P$.JMEJmol$4.$init$,[this, null])));
p.add$java_awt_Component($I$(7).createHorizontalStrut$I(5));
p.add$java_awt_Component(b=Clazz.new_($I$(5,1).c$$S,["replace 3D"]));
b.addActionListener$java_awt_event_ActionListener(((P$.JMEJmol$5||
(function(){/*a*/var C$=Clazz.newClass(P$, "JMEJmol$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.JMEJmol'].to3D$Z.apply(this.b$['jme.JMEJmol'], [false]);
});
})()
), Clazz.new_(P$.JMEJmol$5.$init$,[this, null])));
p.add$java_awt_Component(b=Clazz.new_($I$(5,1).c$$S,["add 3D"]));
b.addActionListener$java_awt_event_ActionListener(((P$.JMEJmol$6||
(function(){/*a*/var C$=Clazz.newClass(P$, "JMEJmol$6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.JMEJmol'].to3D$Z.apply(this.b$['jme.JMEJmol'], [true]);
});
})()
), Clazz.new_(P$.JMEJmol$6.$init$,[this, null])));
p.add$java_awt_Component($I$(7).createHorizontalStrut$I(5));
p.add$java_awt_Component(b=Clazz.new_($I$(5,1).c$$S,["to MOL"]));
b.addActionListener$java_awt_event_ActionListener(((P$.JMEJmol$7||
(function(){/*a*/var C$=Clazz.newClass(P$, "JMEJmol$7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.JMEJmol'].toMOL$S.apply(this.b$['jme.JMEJmol'], ["?jme.mol"]);
});
})()
), Clazz.new_(P$.JMEJmol$7.$init$,[this, null])));
p.add$java_awt_Component(b=Clazz.new_($I$(5,1).c$$S,["to CDXML"]));
b.addActionListener$java_awt_event_ActionListener(((P$.JMEJmol$8||
(function(){/*a*/var C$=Clazz.newClass(P$, "JMEJmol$8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.JMEJmol'].toCDXML$S.apply(this.b$['jme.JMEJmol'], ["?jme.cdxml"]);
});
})()
), Clazz.new_(P$.JMEJmol$8.$init$,[this, null])));
p.add$java_awt_Component(b=Clazz.new_($I$(5,1).c$$S,["to PNG"]));
b.addActionListener$java_awt_event_ActionListener(((P$.JMEJmol$9||
(function(){/*a*/var C$=Clazz.newClass(P$, "JMEJmol$9", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.JMEJmol'].toBorderedPNG$S$I$I.apply(this.b$['jme.JMEJmol'], ["?", 10, 10]);
});
})()
), Clazz.new_(P$.JMEJmol$9.$init$,[this, null])));
p.add$java_awt_Component(b=Clazz.new_($I$(5,1).c$$S,["InChI"]));
b.addActionListener$java_awt_event_ActionListener(((P$.JMEJmol$10||
(function(){/*a*/var C$=Clazz.newClass(P$, "JMEJmol$10", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.JMEJmol'].toInChI$.apply(this.b$['jme.JMEJmol'], []);
});
})()
), Clazz.new_(P$.JMEJmol$10.$init$,[this, null])));
}frame.add$S$java_awt_Component("South", pp);
frame.setBounds$I$I$I$I(300, 300, 700, 400);
frame.addWindowListener$java_awt_event_WindowListener(this);
return frame;
}, p$1);

Clazz.newMeth(C$, 'toInChI$',  function () {
var mol=this.molFile$();
var inchi=this.vwr.getInchi$javajs_util_BS$O$S(null, mol, null);
$I$(8).showInputDialog$java_awt_Component$O$S$I$javax_swing_Icon$OA$O(this, "Standard InChI", null, 1, null, null, inchi);
});

Clazz.newMeth(C$, 'hasStructure$S$Z',  function (pattern, isSmarts) {
var smiles=C$.superclazz.prototype.smiles$.apply(this, []);
return this.vwr.hasStructure$S$S$Z(pattern, smiles, isSmarts);
});

Clazz.newMeth(C$, 'findMatchingStructures$S$SA$Z',  function (smarts, smilesSet, isSmarts) {
try {
return this.vwr.getSmilesMatcher$().hasStructure$S$SA$I(smarts == null  ? this.smilesFromJmol$() : smarts, smilesSet, 0);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.say$S("there was a problem with matching the SMILES " + e);
e.printStackTrace$();
} else {
throw e;
}
}
return null;
});

Clazz.newMeth(C$, 'getSmilesMatcher$',  function () {
return (this.smilesMatcher == null  ? (this.smilesMatcher=Clazz.new_($I$(9,1))) : this.smilesMatcher);
});

Clazz.newMeth(C$, 'toPNG$S',  function (filename) {
return this.toBorderedPNG$S$I$I(filename, 10, 10);
});

Clazz.newMeth(C$, 'getImageSize$',  function () {
var coordBox=this.activeMol.computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(null);
var f=this.molecularAreaScalePixelsPerCoord;
return Clazz.new_([((coordBox.width * f)|0), ((coordBox.height * f)|0)],$I$(10,1).c$$I$I);
});

Clazz.newMeth(C$, 'toHtmlDataURI$',  function () {
return "data:image/png;base64," + $I$(11,"getBase64$BA",[this.toBorderedPNG$S$I$I(null, 10, 10)]);
});

Clazz.newMeth(C$, 'toBorderedPNG$S$I$I',  function (filename, marginX, marginY) {
try {
var img=this.getBufferedImage$I$I(marginX, marginY);
var bos=Clazz.new_($I$(12,1));
$I$(13).write$java_awt_image_RenderedImage$S$java_io_OutputStream(img, "PNG", bos);
if (filename == null ) return bos.toByteArray$();
p$1.toFile$S$O$S.apply(this, [this.headless && filename.indexOf$S("?") >= 0  ? "jmol.png" : filename, bos.toByteArray$(), "png"]);
} catch (e1) {
if (Clazz.exceptionOf(e1,"java.io.IOException")){
this.sorry$S("Something went wrong: " + e1);
} else {
throw e1;
}
}
return null;
});

Clazz.newMeth(C$, 'getBufferedImage$I$I',  function (marginX, marginY) {
return this.drawMolecularArea$java_awt_Graphics$java_awt_Point(null, Clazz.new_($I$(14,1).c$$I$I,[marginX, marginY]));
});

Clazz.newMeth(C$, 'from3D$',  function () {
if (this.vwr.getFrameAtoms$().isEmpty$()) return;
var info=this.vwr.getCurrentModelAuxInfo$();
if (info == null ) {
this.sorry$S("More than one model is visible in Jmol.");
return;
}var is2D="2D".equals$O(info.get$O("dimension"));
var mol=null;
try {
if (is2D) {
mol=this.vwr.getModelExtract$O$Z$Z$S("thisModel", false, false, "MOL");
} else {
var smiles=this.vwr.getSmiles$javajs_util_BS(this.vwr.getFrameAtoms$());
mol=p$1.getMolFromSmiles$S$Z.apply(this, [smiles, false]);
}if (mol == null ) {
this.sorry$S("Something went wrong.");
}this.clear$();
this.readMolFile$S(mol);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.sorry$S(e.toString());
e.printStackTrace$();
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'smiles$',  function () {
if (this.activeMol.natoms == 0) return "";
if (true ||false) {
return C$.superclazz.prototype.smiles$.apply(this, []);
}var mol=this.molFile$();
if (mol.length$() == 0) return "";
return this.vwr.getInchi$javajs_util_BS$O$S(null, mol, "smiles");
});

Clazz.newMeth(C$, 'smilesFromJmol$',  function () {
if (this.activeMol.natoms == 0) return "";
if (false) {
return this.getSmilesMatcher$().getSmilesFromJME$S(this.jmeFile$());
}var mol=this.molFile$();
if (mol.length$() == 0) return "";
return this.vwr.getInchi$javajs_util_BS$O$S(null, mol, "smiles");
});

Clazz.newMeth(C$, 'inchi$',  function () {
return this.inchi$S("standard");
});

Clazz.newMeth(C$, 'inchiFixedH$',  function () {
return this.inchi$S("fixedH");
});

Clazz.newMeth(C$, 'inchi$S',  function (options) {
return this.vwr.getInchi$javajs_util_BS$O$S(null, this.molFile$(), (options == null  ? "standard" : options));
});

Clazz.newMeth(C$, 'getMolFromSmiles$S$Z',  function (smiles, is3D) {
System.out.println$S("JmolJME using SMILES " + smiles);
var url=$I$(15,"resolveDataBase$S$S$S",["smiles" + (is3D ? "3D" : "2D"), $I$(16).escapeUrl$S(smiles), null]);
return this.vwr.getFileAsString$S(url);
}, p$1);

Clazz.newMeth(C$, 'sorry$S',  function (msg) {
System.err.println$S(msg);
if (!this.headless) $I$(8).showMessageDialog$java_awt_Component$O$S$I(this, msg, "Sorry, can\'t do that.", 1);
});

Clazz.newMeth(C$, 'say$S',  function (msg) {
System.out.println$S(msg);
this.infoText=msg;
});

Clazz.newMeth(C$, 'to3D$Z',  function (isAppend) {
var smiles=this.smiles$();
if (smiles == null  || smiles.length$() == 0 ) {
this.sorry$S("There was a problem generating the SMILES from the InChI");
return;
}System.out.println$S("using smiles from InChI: " + smiles);
var mol=p$1.getMolFromSmiles$S$Z.apply(this, [smiles, true]);
var htParams=Clazz.new_($I$(17,1));
this.vwr.openStringInlineParamsAppend$S$java_util_Map$Z(mol, htParams, isAppend);
if (!this.headless) {
this.parentWindow.requestFocus$();
this.vwr.refresh$I$S(1, "JmolJME");
}});

Clazz.newMeth(C$, 'setFrameVisible$Z',  function (b) {
if (this.myFrame != null ) this.myFrame.setVisible$Z(b);
});

Clazz.newMeth(C$, 'toMOL$S',  function (filename) {
var mol=this.molFile$();
if (filename == null ) return mol;
p$1.toFile$S$O$S.apply(this, [p$1.fixOutFilename$S.apply(this, [filename]), mol, "txt"]);
return null;
});

Clazz.newMeth(C$, 'fixOutFilename$S',  function (filename) {
return (!this.headless ? filename : filename.replace$C$C("?", "_"));
}, p$1);

Clazz.newMeth(C$, 'toSVG$S',  function (filename) {
var svg=C$.superclazz.prototype.getOclSVG$.apply(this, []);
if (filename == null ) return svg;
p$1.toFile$S$O$S.apply(this, [p$1.fixOutFilename$S.apply(this, [filename]), svg, "txt"]);
return null;
});

Clazz.newMeth(C$, 'toCDXML$S',  function (filename) {
var mol=this.molFile$();
var xml=$I$(18).fromString$org_jmol_viewer_Viewer$S$S(this.vwr, "Mol", mol);
if (filename == null ) return xml;
p$1.toFile$S$O$S.apply(this, [p$1.fixOutFilename$S.apply(this, [filename]), xml, "txt"]);
return null;
});

Clazz.newMeth(C$, 'setFileName$S',  function (fname) {
this.fileName=fname;
}, p$1);

Clazz.newMeth(C$, 'read2D$S$org_jmol_adapter_smarter_AtomSetCollection',  function (fname, asc) {
this.fileName=fname;
this.options.reaction=false;
var a=this.vwr.getModelAdapter$();
p$1.readAtomSet$org_jmol_api_JmolAdapterAtomIterator$org_jmol_api_JmolAdapterBondIterator.apply(this, [a.getAtomIterator$O(asc), a.getBondIterator$O(asc)]);
}, p$1);

Clazz.newMeth(C$, 'openMolByName$S',  function (name) {
try {
var mol=this.vwr.setLoadFormat$S$C$Z("$$" + name, "$", true);
mol=this.vwr.getFileAsString$S(mol);
this.readMolFile$S(mol);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'readAtomSet$org_jmol_api_JmolAdapterAtomIterator$org_jmol_api_JmolAdapterBondIterator',  function (atomIterator, bondIterator) {
var inputMolList=Clazz.new_($I$(19,1));
try {
var mol=Clazz.new_($I$(20,1).c$$jme_JME$jme_core_JMECore_Parameters,[null, this.params]);
C$.createJMEFromJmolAdapter$jme_core_JMECore$org_jmol_api_JmolAdapterAtomIterator$org_jmol_api_JmolAdapterBondIterator(mol, atomIterator, bondIterator);
inputMolList.add$O(mol);
if (!inputMolList.isReallyEmpty$()) {
this.processIncomingMolecules$jme_JMEmolList$Z(inputMolList, true);
}if (this.activeMol.checkNeedsCleaning$()) {
this.say$S("Close atoms found; cleaning");
this.doClean$();
this.repaint$();
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.info$S($I$(21).makeErrorMessage$Exception(e));
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'createJMEFromJmolAdapter$jme_core_JMECore$org_jmol_api_JmolAdapterAtomIterator$org_jmol_api_JmolAdapterBondIterator',  function (mol, atomIterator, bondIterator) {
var atomMap=Clazz.new_($I$(17,1));
while (atomIterator.hasNext$()){
var sym=$I$(22,"elementSymbolFromNumber$I",[atomIterator.getElementNumber$()]);
var a=mol.createAtom$S(sym);
atomMap.put$O$O(atomIterator.getUniqueID$(), Integer.valueOf$I(mol.natoms));
var pt=atomIterator.getXYZ$();
a.x=pt.x;
a.y=-pt.y;
a.q=atomIterator.getFormalCharge$();
mol.setAtom$I$S(mol.natoms, $I$(23,"getElementSymbol$I",[atomIterator.getElement$()]));
}
while (bondIterator.hasNext$()){
var b=mol.createAndAddBondFromOther$jme_core_Bond(null);
b.va=atomMap.get$O(bondIterator.getAtomUniqueID1$()).intValue$();
b.vb=atomMap.get$O(bondIterator.getAtomUniqueID2$()).intValue$();
var bo=bondIterator.getEncodedOrder$();
switch (bo) {
case 1025:
b.bondType=1;
b.stereo=1;
break;
case 1041:
b.bondType=1;
b.stereo=2;
break;
case 1:
case 513:
b.bondType=1;
break;
case 2:
case 514:
b.bondType=2;
break;
case 3:
b.bondType=3;
break;
case 515:
case 1057:
default:
if ((bo & 7) != 0) b.bondType=(bo & 7);
break;
}
}
mol.finalizeMolecule$();
}, 1);

Clazz.newMeth(C$, 'read3D$S',  function (fname) {
var mol=this.vwr.getFileAsString$S(fname);
p$1.loadSmilesCleanly$S.apply(this, [p$1.getSmiles$S.apply(this, [mol])]);
}, p$1);

Clazz.newMeth(C$, 'getSmiles$S',  function (mol) {
return this.vwr.getInchi$javajs_util_BS$O$S(null, mol, "smiles");
}, p$1);

Clazz.newMeth(C$, 'propertyChange$java_beans_PropertyChangeEvent',  function (evt) {
var name=evt.getPropertyName$();
var val=evt.getNewValue$();
if (val == null ) return;
try {
if (name == "FileDropper.file") {
this.readFile$S(val);
} else if (name == "FileDropper.inline") {
this.readDroppedData$O(val);
}} catch (t) {
System.err.println$S("JME couldn't load data for drop " + name);
}
});

Clazz.newMeth(C$, 'readDroppedData$O',  function (newValue) {
var data=newValue.toString();
var trimmed=data.trim$();
try {
if (trimmed.indexOf$S("\n") >= 0) this.readMolFile$S(data);
 else if (trimmed.indexOf$S(" ") >= 0) this.readMolecule$S(data);
 else this.readSmiles$S(trimmed);
this.activeMol.center$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("JME error reading data starting with " + data.substring$I(Math.min(data.length$(), 100)));
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'readSmiles$S',  function (data) {
try {
this.readMolFile$S($I$(21).getOclAdapter$().SMILEStoMOL$S(data));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'readDroppedTextFile$S',  function (fileName) {
var bos=Clazz.new_($I$(12,1));
var fis=null;
try {
fis=(fileName.indexOf$S("://") >= 0 ? Clazz.new_($I$(24,1).c$$S,[fileName]).openStream$() : Clazz.new_($I$(25,1).c$$S,[fileName]));
var bytes=Clazz.array(Byte.TYPE, [4096]);
var n;
while ((n=fis.read$BA(bytes)) > 0){
bos.write$BA$I$I(bytes, 0, n);
}
fis.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("JME error reading file " + fileName);
} else {
throw e;
}
}
this.readDroppedData$O( String.instantialize(bos.toByteArray$()));
});

Clazz.newMeth(C$, 'doClean$',  function () {
if (!this.allowClean) return;
var smiles=this.vwr.getInchi$javajs_util_BS$O$S(null, this.molFile$(), "smiles");
p$1.loadSmilesCleanly$S.apply(this, [smiles]);
});

Clazz.newMeth(C$, 'loadSmilesCleanly$S',  function (smiles) {
if (smiles == null  || smiles.length$() == 0  || this.cleaning ) return;
System.out.println$S("using smiles from InChI: " + smiles);
var mol=null;
try {
this.cleaning=true;
mol=p$1.getMolFromSmiles$S$Z.apply(this, [smiles, false]);
if (mol == null ) {
this.sorry$S("Something went wrong.");
} else {
this.readMolFile$S(mol);
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.sorry$S(e.toString());
e.printStackTrace$();
} else {
throw e;
}
} finally {
this.cleaning=false;
}
}, p$1);

Clazz.newMeth(C$, 'readFile$S',  function (fname) {
try {
p$1.setFileName$S.apply(this, [fname]);
var f=Clazz.new_($I$(26,1).c$$S,[fname]);
System.out.println$S("JmolJME reading file " + f.getAbsolutePath$());
var bis=Clazz.new_([Clazz.new_($I$(25,1).c$$S,[fname])],$I$(27,1).c$$java_io_InputStream);
var isBinary=($I$(28).getBinaryType$java_io_InputStream(bis) != null );
var type=this.vwr.getModelAdapter$().getFileTypeName$O(bis);
bis.close$();
if ("Jme".equals$O(type)) {
this.clear$();
this.readMolecule$S(this.vwr.getFileAsString$S(fname));
this.activeMol.center$();
return null;
}var htParams=Clazz.new_($I$(17,1));
htParams.put$O$O("filter", "NOH;NO3D;fileType=" + type);
htParams.put$O$O("binary", Boolean.valueOf$Z(isBinary));
this.vwr.setLoadParameters$java_util_Map$Z(htParams, false);
bis=Clazz.new_([Clazz.new_($I$(25,1).c$$S,[fname])],$I$(27,1).c$$java_io_InputStream);
var ret=this.vwr.getModelAdapter$().getAtomSetCollectionFromReader$S$O$java_util_Map(fname, bis, htParams);
if (Clazz.instanceOf(ret, "org.jmol.adapter.smarter.AtomSetCollection")) {
var asc=ret;
var info=asc.getAtomSetAuxiliaryInfo$I(0);
var is2D="2D".equals$O(info.get$O("dimension"));
this.clear$();
if (is2D) {
p$1.read2D$S$org_jmol_adapter_smarter_AtomSetCollection.apply(this, [fname, asc]);
} else {
p$1.read3D$S.apply(this, [fname]);
}} else {
this.sorry$S(ret.toString());
return ret.toString();
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.sorry$S(e.toString());
e.printStackTrace$();
return e;
} else {
throw e;
}
}
this.repaint$();
System.out.println$S("JJME " + fname);
return null;
});

Clazz.newMeth(C$, 'toFile$S$O$S',  function (name, bytesOrString, type) {
var useThread=(name.indexOf$S("?") >= 0);
if (useThread && this.headless ) {
this.sorry$S("Filenames must not contain \'?\' in headless mode - \'?\' replaced with \'_\'");
name=name.replace$C$C("?", "_");
useThread=false;
}var finalName=name;
var r=((P$.JMEJmol$11||
(function(){/*a*/var C$=Clazz.newClass(P$, "JMEJmol$11", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$',  function () {
System.out.println$S("JmolJME writing file " + this.$finals$.finalName);
var haveDialog=(this.$finals$.finalName.startsWith$S("?"));
var f=this.b$['jme.JMEJmol'].vwr.writeFile$S$O$S(this.$finals$.finalName, this.$finals$.bytesOrString, this.$finals$.type);
if (haveDialog && f != null   && f.indexOf$S("OK") == 0 ) {
var pt=f.indexOf$S$I(" ", 3);
f=f.substring$I(f.indexOf$S$I(" ", pt + 1)).trim$();
pt=f.lastIndexOf$S("/");
if (pt <= 0) return;
f=f.substring$I$I(0, pt + 1);
this.b$['jme.JMEJmol'].vwr.setStringProperty$S$S("currentLocalPath", f);
}System.out.println$S(f);
});
})()
), Clazz.new_(P$.JMEJmol$11.$init$,[this, {finalName:finalName,type:type,bytesOrString:bytesOrString}]));
if (useThread) {
Clazz.new_($I$(29,1).c$$Runnable,[r]).start$();
} else {
r.run$();
}}, p$1);

Clazz.newMeth(C$, 'subclassAddToCopyMenu$javax_swing_JPopupMenu$Z',  function (popup, hasAtom) {
this.addMenuItem$javax_swing_JPopupMenu$Z$S$O(popup, hasAtom, "Save as SVG graphic", "Jmol-saveSVG");
this.addMenuItem$javax_swing_JPopupMenu$Z$S$O(popup, hasAtom, "Save as PNG image", "Jmol-savePNG");
this.addMenuItem$javax_swing_JPopupMenu$Z$S$O(popup, hasAtom, "Save as MOL file", "Jmol-saveMOL");
this.addMenuItem$javax_swing_JPopupMenu$Z$S$O(popup, hasAtom, "Save as CDXML file", "Jmol-saveCDXML");
});

Clazz.newMeth(C$, 'subclassHandleMenuAction$S',  function (cmd) {
switch (cmd) {
case "Jmol-savePNG":
this.toBorderedPNG$S$I$I("?jme.png", 10, 10);
return true;
case "Jmol-saveSVG":
this.toSVG$S("?jme.svg");
return true;
case "Jmol-saveMOL":
this.toMOL$S("?jme.mol");
return true;
case "Jmol-saveCDXML":
this.toCDXML$S("?jme.cdxml");
return true;
}
return false;
});

Clazz.newMeth(C$, 'getTitle',  function () {
return "JME-SwingJS 2D Molecular Editor" + (this.fileName == null  ? "" : " " + this.fileName);
}, p$1);

Clazz.newMeth(C$, 'windowOpened$java_awt_event_WindowEvent',  function (e) {
});

Clazz.newMeth(C$, 'windowClosing$java_awt_event_WindowEvent',  function (e) {
});

Clazz.newMeth(C$, 'windowClosed$java_awt_event_WindowEvent',  function (e) {
if (this.myFrame != null ) this.myFrame.setVisible$Z(false);
});

Clazz.newMeth(C$, 'windowIconified$java_awt_event_WindowEvent',  function (e) {
});

Clazz.newMeth(C$, 'windowDeiconified$java_awt_event_WindowEvent',  function (e) {
});

Clazz.newMeth(C$, 'windowActivated$java_awt_event_WindowEvent',  function (e) {
});

Clazz.newMeth(C$, 'windowDeactivated$java_awt_event_WindowEvent',  function (e) {
});

Clazz.newMeth(C$, 'dispose$',  function () {
this.vwr=null;
if (this.myFrame != null ) this.myFrame.dispose$();
this.myFrame=null;
this.parentWindow=null;
});

Clazz.newMeth(C$, 'handleAdditionalParameters$',  function () {
});

Clazz.newMeth(C$, 'main$SA',  function (args) {
var frame=null;
var info=Clazz.new_($I$(17,1));
info.put$O$O("isApp", Boolean.TRUE);
info.put$O$O("headless", Boolean.TRUE);
info.put$O$O("noscripting", Boolean.TRUE);
info.put$O$O("noDisplay", Boolean.TRUE);
info.put$O$O("repaintManager", "NONE");
var vwr=Clazz.new_($I$(30,1).c$$java_util_Map,[info]);
var jjme=Clazz.new_(C$.c$$SA,[Clazz.array(String, -1, ["$NOINIT$"])]);
jjme.vwr=vwr;
var type=null;
var dostart=true;
if (args.length > 0) {
if (args[0].equals$O("headless")) {
jjme.initialize$SA(args);
jjme.options$S("headless");
dostart=false;
} else if (args[0].equals$O("search")) {
jjme.initialize$SA(args);
type="search";
} else if (args[0].equals$O("test")) {
switch (args[1]) {
case "headless":
jjme.initialize$SA(args);
C$.testJMEHeadless$jme_JMEJmol(jjme);
dostart=false;
break;
case "data":
jjme.initialize$SA(args);
C$.testJmolData$jme_JMEJmol$SA(jjme, args);
dostart=false;
break;
case "jmol":
type="jmol";
break;
}
}}if (dostart) C$.startJmolJME$javax_swing_JFrame$jme_JMEJmol$S(frame, jjme, type);

return jjme;
}, 1);

Clazz.newMeth(C$, 'startJmolJME$javax_swing_JFrame$jme_JMEJmol$S',  function (frame, jjme, type) {
var embeddingFrame=null;
if ("jmol".equals$O(type)) {
embeddingFrame=Clazz.new_($I$(2,1));
} else if ("search".equals$O(type)) {
} else if (frame == null ) {
frame=Clazz.new_($I$(2,1).c$$S,["JmolJME Molecular Editor"]);
frame.setName$S("JME");
frame.setBounds$I$I$I$I(300, 200, 432, 384);
frame.addWindowListener$java_awt_event_WindowListener(((P$.JMEJmol$12||
(function(){/*a*/var C$=Clazz.newClass(P$, "JMEJmol$12", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.WindowAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'windowClosing$java_awt_event_WindowEvent',  function (evt) {
System.exit$I(0);
});
})()
), Clazz.new_($I$(6,1),[this, null],P$.JMEJmol$12)));
}jjme.setViewer$javax_swing_JFrame$org_jmol_viewer_Viewer$java_awt_Container$S(frame, jjme.vwr, embeddingFrame, type);
jjme.vwr.getInchi$javajs_util_BS$O$S(null, null, null);
$I$(1,"invokeLater$Runnable",[((P$.JMEJmol$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "JMEJmol$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'run$',  function () {
this.$finals$.jjme.myFrame.setVisible$Z.apply(this.$finals$.jjme.myFrame, [true]);
this.$finals$.jjme.start$SA.apply(this.$finals$.jjme, [Clazz.array(String, [0])]);
});
})()
), Clazz.new_(P$.JMEJmol$lambda2.$init$,[this, {jjme:jjme}]))]);
}, 1);

Clazz.newMeth(C$, 'testJMEHeadless$jme_JMEJmol',  function (jjme) {
jjme.options$S("headless");
jjme.openMolByName$S("morphine");
jjme.toBorderedPNG$S$I$I("c:/temp/test.png", 10, 10);
}, 1);

Clazz.newMeth(C$, 'testJmolData$jme_JMEJmol$SA',  function (jjme, args) {
var frame=Clazz.new_($I$(2,1).c$$S,["JmolJME Molecular Editor"]);
frame.setName$S("JME");
frame.addWindowListener$java_awt_event_WindowListener(((P$.JMEJmol$13||
(function(){/*a*/var C$=Clazz.newClass(P$, "JMEJmol$13", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.WindowAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'windowClosing$java_awt_event_WindowEvent',  function (evt) {
System.exit$I(0);
});
})()
), Clazz.new_($I$(6,1),[this, null],P$.JMEJmol$13)));
frame.setBounds$I$I$I$I(300, 200, 432, 384);
jjme.vwr.getInchi$javajs_util_BS$O$S(null, null, null);
jjme.setViewer$javax_swing_JFrame$org_jmol_viewer_Viewer$java_awt_Container$S(frame, jjme.vwr, null, null);
$I$(1,"invokeLater$Runnable",[((P$.JMEJmol$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "JMEJmol$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'run$',  function () {
this.$finals$.jjme.start$SA.apply(this.$finals$.jjme, [this.$finals$.args]);
this.$finals$.jjme.readFile$S.apply(this.$finals$.jjme, ["data/3af.cdxml"]);
});
})()
), Clazz.new_(P$.JMEJmol$lambda3.$init$,[this, {jjme:jjme,args:args}]))]);
}, 1);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:03 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
