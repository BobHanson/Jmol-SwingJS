(function(){var P$=Clazz.newPackage("jme.util"),p$1={},I$=[[0,['jme.util.ChangeManager','.Node']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ChangeManager", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['Node',2]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.currentIndex=null;
this.parentNode=Clazz.new_($I$(1,1),[this, null]);
},1);

C$.$fields$=[['O',['currentIndex','jme.util.ChangeManager.Node','+parentNode']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.currentIndex=this.parentNode;
}, 1);

Clazz.newMeth(C$, 'c$$jme_util_ChangeManager',  function (manager) {
C$.c$.apply(this, []);
this.currentIndex=manager.currentIndex;
}, 1);

Clazz.newMeth(C$, 'clear$',  function () {
this.currentIndex=this.parentNode;
this.parentNode.right=null;
});

Clazz.newMeth(C$, 'insertItem$O',  function (item) {
if (item == null ) {
System.err.println$S("Null item");
}var node=Clazz.new_($I$(1,1).c$$O,[this, null, item]);
Clazz.assert(C$, this, function(){return (item != null )});
var savedRight=this.currentIndex.right;
this.currentIndex.right=node;
node.left=this.currentIndex;
if (savedRight != null ) {
node.right=savedRight;
savedRight.left=node;
}this.currentIndex=node;
});

Clazz.newMeth(C$, 'removeLast$',  function () {
if (!this.canUndo$()) {
return null;
}var savedRight=this.currentIndex.right;
var lastItem=this.currentIndex.item;
this.undo$();
;this.currentIndex.right=savedRight;
return lastItem;
});

Clazz.newMeth(C$, 'canUndo$',  function () {
return this.currentIndex !== this.parentNode  && this.currentIndex.left !== this.parentNode  ;
});

Clazz.newMeth(C$, 'canRedo$',  function () {
return this.currentIndex.right != null ;
});

Clazz.newMeth(C$, 'undo$',  function () {
if (!this.canUndo$()) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Cannot undo. Index is out of range."]);
}p$1.moveLeft.apply(this, []);
var item=this.currentIndex.item;
return item;
});

Clazz.newMeth(C$, 'moveLeft',  function () {
if (this.currentIndex.left == null ) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Internal index set to null."]);
}this.currentIndex=this.currentIndex.left;
}, p$1);

Clazz.newMeth(C$, 'moveRight',  function () {
if (this.currentIndex.right == null ) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Internal index set to null."]);
}this.currentIndex=this.currentIndex.right;
}, p$1);

Clazz.newMeth(C$, 'redo$',  function () {
if (!this.canRedo$()) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Cannot redo. Index is out of range."]);
}p$1.moveRight.apply(this, []);
var item=this.currentIndex.item;
return item;
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.ChangeManager, "Node", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.left=null;
this.right=null;
},1);

C$.$fields$=[['O',['left','jme.util.ChangeManager.Node','+right','item','<N>']]]

Clazz.newMeth(C$, 'c$$O',  function (c) {
;C$.$init$.apply(this);
this.item=c;
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.item=null;
}, 1);
})()
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
