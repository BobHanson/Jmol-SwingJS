(function(){var P$=Clazz.newPackage("jme.util"),I$=[[0,'java.util.Arrays']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DPoint");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'add$DA$DA',  function (a, b) {
a[0]+=b[0];
a[1]+=b[1];
a[2]+=b[2];
return a;
}, 1);

Clazz.newMeth(C$, 'sub2$DA$DA$DA',  function (a, b, ret) {
ret[0]=a[0] - b[0];
ret[1]=a[1] - b[1];
ret[2]=a[2] - b[2];
}, 1);

Clazz.newMeth(C$, 'distanceSquared$DA$DA',  function (a, b) {
return (a[0] - b[0]) * (a[0] - b[0]) + (a[1] - b[1]) * (a[1] - b[1]) + (a[2] - b[2]) * (a[2] - b[2]);
}, 1);

Clazz.newMeth(C$, 'scale$DA$D',  function (a, f) {
a[0]*=f;
a[1]*=f;
a[2]*=f;
}, 1);

Clazz.newMeth(C$, 'transform2$DAA$DA',  function (m, p) {
if (m != null ) {
var d0=m[0][0] * p[0] + m[0][1] * p[1] + m[0][2] * p[2];
var d1=m[1][0] * p[0] + m[1][1] * p[1] + m[1][2] * p[2];
p[2]=m[2][0] * p[0] + m[2][1] * p[1] + m[2][2] * p[2];
p[1]=d1;
p[0]=d0;
}return p;
}, 1);

Clazz.newMeth(C$, 'setQ$D$D$D$D',  function (x, y, z, w) {
var q=Clazz.array(Double.TYPE, [4]);
var factor=x * x + y * y + z * z + w * w;
if (factor == 0 ) {
q[0]=1;
return q;
}q[0]=w / factor;
q[1]=x / factor;
q[2]=y / factor;
q[3]=z / factor;
return q;
}, 1);

Clazz.newMeth(C$, 'qToM4$DA',  function (q) {
var mat=Clazz.array(Double.TYPE, [3, 3]);
mat[0][0]=q[0] * q[0] + q[1] * q[1] - q[2] * q[2] - q[3] * q[3];
mat[0][1]=2 * q[1] * q[2]  - 2 * q[0] * q[3] ;
mat[0][2]=2 * q[1] * q[3]  + 2 * q[0] * q[2] ;
mat[1][0]=2 * q[1] * q[2]  + 2 * q[0] * q[3] ;
mat[1][1]=q[0] * q[0] - q[1] * q[1] + q[2] * q[2] - q[3] * q[3];
mat[1][2]=2 * q[2] * q[3]  - 2 * q[0] * q[1] ;
mat[2][0]=2 * q[1] * q[3]  - 2 * q[0] * q[2] ;
mat[2][1]=2 * q[2] * q[3]  + 2 * q[0] * q[1] ;
mat[2][2]=q[0] * q[0] - q[1] * q[1] - q[2] * q[2] + q[3] * q[3];
return mat;
}, 1);

Clazz.newMeth(C$, 'toString$DAA',  function (m) {
var s="";
for (var i=0; i < m.length; i++) s+=$I$(1).toString$DA(m[i]) + "\n";

return s;
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
