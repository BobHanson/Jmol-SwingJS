(function(){var P$=Clazz.newPackage("jme.util"),I$=[[0,'jme.util.DPoint','jme.util.Eigen4','java.util.Arrays']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "StructureComparator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getCenterAndPoints$DAA',  function (vPts) {
var n=vPts.length;
var pts=Clazz.array(Double.TYPE, [n + 1, 3]);
pts[0]=Clazz.array(Double.TYPE, [3]);
if (n > 0) {
for (var i=0; i < n; i++) {
$I$(1,"add$DA$DA",[pts[0], pts[i + 1]=vPts[i]]);
}
$I$(1).scale$DA$D(pts[0], 1.0 / n);
}return pts;
}, 1);

Clazz.newMeth(C$, 'calculateQuaternionRotation$DAAA$DA$DAA',  function (centerAndPoints, retStddev, receiver) {
retStddev[1]=NaN;
var ptsA=centerAndPoints[0];
var ptsB=centerAndPoints[1];
var nPts=ptsA.length - 1;
if (nPts < 2 || ptsA.length != ptsB.length ) return null;
var Sxx=0;
var Sxy=0;
var Sxz=0;
var Syx=0;
var Syy=0;
var Syz=0;
var Szx=0;
var Szy=0;
var Szz=0;
var ptA=Clazz.array(Double.TYPE, [3]);
var ptB=Clazz.array(Double.TYPE, [3]);
var ptA0=ptsA[0];
var ptB0=ptsB[0];
for (var i=nPts + 1; --i >= 1; ) {
$I$(1).sub2$DA$DA$DA(ptsA[i], ptA0, ptA);
$I$(1).sub2$DA$DA$DA(ptsB[i], ptB0, ptB);
Sxx+=ptA[0] * ptB[0];
Sxy+=ptA[0] * ptB[1];
Sxz+=ptA[0] * ptB[2];
Syx+=ptA[1] * ptB[0];
Syy+=ptA[1] * ptB[1];
Syz+=ptA[1] * ptB[2];
Szx+=ptA[2] * ptB[0];
Szy+=ptA[2] * ptB[1];
Szz+=ptA[2] * ptB[2];
}
retStddev[0]=C$.getRmsd$DAAA$DAA$DAA(centerAndPoints, null, centerAndPoints.length == 2 ? null : centerAndPoints[2]);
var N=Clazz.array(Double.TYPE, [4, 4]);
N[0][0]=Sxx + Syy + Szz ;
N[0][1]=N[1][0]=Syz - Szy;
N[0][2]=N[2][0]=Szx - Sxz;
N[0][3]=N[3][0]=Sxy - Syx;
N[1][1]=Sxx - Syy - Szz ;
N[1][2]=N[2][1]=Sxy + Syx;
N[1][3]=N[3][1]=Szx + Sxz;
N[2][2]=-Sxx + Syy - Szz;
N[2][3]=N[3][2]=Syz + Szy;
N[3][3]=-Sxx - Syy + Szz;
var v=Clazz.new_($I$(2,1)).setM$DAA(N).getLargestEigenvector$();
var q=$I$(1).setQ$D$D$D$D(v[1], v[2], v[3], v[0]);
var mat4=$I$(1).qToM4$DA(q);
retStddev[1]=C$.getRmsd$DAAA$DAA$DAA(centerAndPoints, mat4, receiver);
return mat4;
}, 1);

Clazz.newMeth(C$, 'getRmsd$DAAA$DAA$DAA',  function (centerAndPoints, mat4, receiver) {
var sum2=0;
var ptsA=centerAndPoints[0];
var ptsB=centerAndPoints[1];
var cA=ptsA[0];
var cB=ptsB[0];
if (receiver != null ) {
receiver[0]=cB;
}var n=ptsA.length - 1;
var ptAnew=Clazz.array(Double.TYPE, [3]);
for (var i=n + 1; --i >= 1; ) {
$I$(1).sub2$DA$DA$DA(ptsA[i], cA, ptAnew);
$I$(1,"add$DA$DA",[$I$(1).transform2$DAA$DA(mat4, ptAnew), cB]);
sum2+=$I$(1).distanceSquared$DA$DA(ptAnew, ptsB[i]);
if (receiver != null ) {
receiver[i]=ptAnew;
ptAnew=Clazz.array(Double.TYPE, [3]);
}}
return Math.sqrt(sum2 / n);
}, 1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
C$.test$();
}, 1);

Clazz.newMeth(C$, 'test$',  function () {
var a=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [0, 0, 0]), Clazz.array(Double.TYPE, -1, [1, 0, 0]), Clazz.array(Double.TYPE, -1, [0, 2, 0])]);
var b=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [0, 0, 0]), Clazz.array(Double.TYPE, -1, [0, 1, 0]), Clazz.array(Double.TYPE, -1, [-2, 0, 0])]);
var ca=C$.getCenterAndPoints$DAA(a);
var cb=C$.getCenterAndPoints$DAA(b);
var receiver=Clazz.array(Double.TYPE, [ca.length, null]);
var rmsd=Clazz.array(Double.TYPE, [2]);
var m=C$.calculateQuaternionRotation$DAAA$DA$DAA(Clazz.array(Double.TYPE, -3, [ca, cb]), rmsd, receiver);
System.out.println$S($I$(3).toString$DA(rmsd));
System.out.println$S($I$(1).toString$DAA(m));
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
