(function(){var P$=Clazz.newPackage("jme.util"),I$=[[0,'java.util.StringTokenizer']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*i*/var C$=Clazz.newInterface(P$, "JMEUtil");

C$.$fields$=[[]
,['Z',['isSwingJS']]]

Clazz.newMeth(C$, 'isHighDPI$',  function () {
return false;
}, 1);

Clazz.newMeth(C$, 'nextData$java_util_StringTokenizer$S',  function (st, separator) {
while (st.hasMoreTokens$()){
var s=st.nextToken$();
if (s.equals$O(separator)) return " ";
 else {
if (!st.nextToken$().equals$O(separator)) {
System.err.println$S("mol file line separator problem!");
}while (true){
var c=s.charAt$I(s.length$() - 1);
if (c == "|" || c == "\n"  || c == "\r" ) {
s=s.substring$I$I(0, s.length$() - 1);
if (s.length$() == 0) return " ";
} else break;
}
return s;
}}
return null;
}, 1);

Clazz.newMeth(C$, 'findLineSeparator$S',  function (molFile) {
var st=Clazz.new_($I$(1,1).c$$S$S$Z,[molFile, "\n", true]);
if (st.countTokens$() > 4) return "\n";
 else {
st=Clazz.new_($I$(1,1).c$$S$S$Z,[molFile, "|", true]);
if (st.countTokens$() > 4) return "|";
 else System.err.println$S("Cannot process mol file, use | as line separator !");
}return null;
}, 1);

Clazz.newMeth(C$, 'iformat$I$I',  function (number, len) {
return C$.rightJustify$S$S("        ".substring$I$I(0, len), "" + number);
}, 1);

Clazz.newMeth(C$, 'rightJustify$S$S',  function (s1, s2) {
var n=s1.length$() - s2.length$();
return (n == 0 ? s2 : n > 0 ? s1.substring$I$I(0, n) + s2 : s1.substring$I$I(0, s1.length$() - 1) + "?");
}, 1);

Clazz.newMeth(C$, 'fformat$D$I$I',  function (number, len, dec) {
if (dec == 0) return C$.iformat$I$I((number|0), len);
if (Math.abs(number) < 9.0E-4 ) number=0.0;
var m=Math.pow(10, dec);
number=Long.$ival(Math.round$D(number * m)) / m;
var s= new Double(number).toString();
var dotpos=s.indexOf$I(".");
if (dotpos < 0) {
s+=".";
dotpos=s.indexOf$I(".");
}var slen=s.length$();
for (var i=1; i <= dec - slen + dotpos + 1; i++) s+="0";

return (len == 0 ? s : C$.rightJustify$S$S("          ".substring$I$I(0, len), s));
}, 1);

Clazz.newMeth(C$, 'log$S',  function (s) {
}, 1);

Clazz.newMeth(C$, 'isMacintosh$',  function () {
return false;
}, 1);

Clazz.newMeth(C$, 'wrapCDATA$S',  function (data) {
return "<![CDATA[" + data + "]]>" ;
}, 1);

Clazz.newMeth(C$, 'unwrapCData$S',  function (result) {
var pt=result.indexOf$S("<![CDATA[");
var pt1=result.indexOf$S("]]>");
return (pt >= 0 && pt1 > pt  ? result.substring$I$I(pt + 9, pt1) : result);
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.isSwingJS=true;
};
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
