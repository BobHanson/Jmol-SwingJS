(function(){var P$=Clazz.newPackage("jme.util"),I$=[[0,['jme.util.Box','.Axis'],['java.awt.geom.Rectangle2D','.Double'],'java.awt.geom.Rectangle2D']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*i*/var C$=Clazz.newInterface(P$, "Box", function(){
});
C$.$classes$=[['Axis',25]];

Clazz.newMeth(C$, 'get$java_awt_geom_Rectangle2D_Double$jme_util_Box_Axis',  function (box, xOrY) {
return (xOrY === $I$(1).X  ? box.getX$() : box.getY$());
}, 1);

Clazz.newMeth(C$, 'getDim$java_awt_geom_Rectangle2D_Double$jme_util_Box_Axis',  function (box, xOrY) {
return xOrY === $I$(1).X  ? box.getWidth$() : box.getHeight$();
}, 1);

Clazz.newMeth(C$, 'createUnion$java_awt_geom_Rectangle2D_Double$java_awt_geom_Rectangle2D_Double$java_awt_geom_Rectangle2D_Double',  function (box, r, union) {
if (union == null ) {
union=Clazz.new_($I$(2,1));
union.setFrame$java_awt_geom_Rectangle2D(box);
} else {
$I$(3).union$java_awt_geom_Rectangle2D$java_awt_geom_Rectangle2D$java_awt_geom_Rectangle2D(union, box, union);
}if (r != null  && r !== union  ) $I$(3).union$java_awt_geom_Rectangle2D$java_awt_geom_Rectangle2D$java_awt_geom_Rectangle2D(union, r, union);
return union;
}, 1);
;
(function(){/*e*/var C$=Clazz.newClass(P$.Box, "Axis", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "X", 0, []);
Clazz.newEnumConst($vals, C$.c$, "Y", 1, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
