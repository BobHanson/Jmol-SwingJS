(function(){var P$=Clazz.newPackage("jme"),p$1={},I$=[[0,['jme.io.JMEReader','.SupportedInputFileFormat'],'jme.io.JMEWriter','jme.io.JMEReader','java.awt.Color','jme.canvas.ColorManager','jme.gui.GUI','jme.JME','jme.gui.AtomDisplayLabel','jme.util.Box','java.util.StringTokenizer','jme.util.JMEUtil','jme.core.JMESmiles','jme.core.Atom','jme.ocl.OclAdapter',['jme.gui.GUI','.RingInfo']]],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JMEmol", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'jme.core.JMECore', 'jme.canvas.Graphical2DObject');
C$.$classes$=[['ReactionRole',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.chain=Clazz.array(Integer.TYPE, [101]);
this.touchedAtom=0;
this.touchedBond=0;
this.touched_org=0;
this.stopChain=false;
this.needRecentering=false;
this.isQuery=false;
this.uniColor=null;
this.reactionRole=0;
this.mixPastelBackGroundColors=true;
this.centerx=NaN;
},1);

C$.$fields$=[['Z',['stopChain','needRecentering','isQuery','mixPastelBackGroundColors','haveMultipleBonds'],'D',['xorg','yorg','centerx','centery'],'I',['touchedAtom','touchedBond','touched_org','nchain','reactionRole'],'O',['jme','jme.JME','chain','int[]','uniColor','java.awt.Color','atomLabels','jme.gui.AtomDisplayLabel[]','ringInfo','jme.gui.GUI.RingInfo']]]

Clazz.newMeth(C$, 'c$',  function () {
C$.c$$jme_JME$jme_core_JMECore_Parameters.apply(this, [null, null]);
}, 1);

Clazz.newMeth(C$, 'c$$jme_core_JMECore_Parameters',  function (pars) {
C$.c$$jme_JME$jme_core_JMECore_Parameters.apply(this, [null, pars]);
}, 1);

Clazz.newMeth(C$, 'c$$jme_JME$jme_core_JMECore_Parameters',  function (jme, pars) {
;C$.superclazz.c$$jme_event_JMEStatusListener$jme_core_JMECore_Parameters.apply(this,[jme, pars]);C$.$init$.apply(this);
this.jme=jme;
}, 1);

Clazz.newMeth(C$, 'c$$jme_JMEmol',  function (m) {
;C$.superclazz.c$$jme_core_JMECore.apply(this,[m]);C$.$init$.apply(this);
this.jme=m.jme;
this.haveMultipleBonds=m.haveMultipleBonds;
this.reactionRole=m.reactionRole;
this.ringInfo=m.ringInfo;
}, 1);

Clazz.newMeth(C$, 'c$$jme_JME$jme_JMEmolA',  function (jme, mols) {
;C$.superclazz.c$$jme_event_JMEStatusListener$jme_core_JMECoreA.apply(this,[jme, mols]);C$.$init$.apply(this);
this.jme=jme;
if (mols.length > 0) this.reactionRole=mols[0].reactionRole;
}, 1);

Clazz.newMeth(C$, 'c$$jme_JME$jme_JMEmol$I',  function (jme, m, part) {
;C$.superclazz.c$$jme_event_JMEStatusListener$jme_core_JMECore$I.apply(this,[jme, m, part]);C$.$init$.apply(this);
this.jme=jme;
this.reactionRole=m.reactionRole;
this.ringInfo=m.ringInfo;
}, 1);

Clazz.newMeth(C$, 'c$$jme_JME$jme_JMEmol$I$O',  function (jme, m, part, NOT_USED) {
C$.c$$jme_JME$jme_core_JMECore_Parameters.apply(this, [jme, m.parameters]);
this.setPart$jme_core_JMECore$I(m, part);
}, 1);

Clazz.newMeth(C$, 'c$$jme_JME$O$jme_io_JMEReader_SupportedInputFileFormat$jme_core_JMECore_Parameters',  function (jme, molecule, type, pars) {
C$.c$$jme_JME$jme_core_JMECore_Parameters.apply(this, [jme, pars]);
if (molecule == null ) return;
switch (type) {
case $I$(1).JME:
p$1.createFromJMEString$S.apply(this, [molecule]);
break;
case $I$(1).MOL:
p$1.createFromMOLString$S.apply(this, [molecule]);
break;
default:
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Unrecognized format"]);
}
}, 1);

Clazz.newMeth(C$, 'createJMEString$java_awt_geom_Rectangle2D_Double',  function (boundingBox) {
return $I$(2).createJMEString$jme_core_JMECore$Z$java_awt_geom_Rectangle2D_Double(this, false, boundingBox);
});

Clazz.newMeth(C$, 'createFromJMEString$S',  function (jmeString) {
$I$(3).createMolFromString$jme_core_JMECore$S(this, jmeString);
}, p$1);

Clazz.newMeth(C$, 'createFromMOLString$S',  function (molData) {
$I$(3).createMolFromMolData$jme_core_JMECore$S(this, molData);
}, p$1);

Clazz.newMeth(C$, 'mergeMols$java_util_ArrayList',  function (mols) {
return (mols.size$() == 0 ? Clazz.new_(C$) : Clazz.new_(C$.c$$jme_JME$jme_JMEmolA,[mols.get$I(0).jme, mols.toArray$OA(Clazz.array(C$, [mols.size$()]))]));
}, 1);

Clazz.newMeth(C$, 'setPresetPastelBackGroundColor$jme_canvas_PreciseGraphicsAWT$I$Z',  function (og, ab, isAtom) {
var colors=Clazz.array(Integer.TYPE, [1]);
var colorIsSet=false;
var showMappingNumbers=this.parameters.number;
var showColorMark=this.parameters.mark;
var showAtomMapNumberWithBackgroundColor=this.parameters.showAtomMapNumberWithBackgroundColor;
var atomOrBond=isAtom ? this.atoms[ab] : this.bonds[ab];
if (showMappingNumbers && showAtomMapNumberWithBackgroundColor && isAtom  ) {
var atom=this.atoms[ab];
if (atom.isMapped$()) {
var map=atom.getMap$();
var max_map=this.jme.colorManager.numberOfBackgroundColors$();
while (map > max_map){
map-=max_map;
}
colors[0]=map;
colorIsSet=true;
}}if (!colorIsSet && showColorMark && atomOrBond.isMarked$()  ) {
colors[0]=atomOrBond.getMark$();
colorIsSet=true;
}if (!colorIsSet) {
colors=isAtom ? this.getAtomBackgroundColors$I(ab) : this.getBondBackgroundColors$I(ab);
}var color=(colors != null  && colors.length > 0  ? this.jme.colorManager.averageColor$IA(colors) : null);
if (color != null ) {
og.setColor$java_awt_Color(color);
}return color;
});

Clazz.newMeth(C$, 'forceUniColor$java_awt_Color',  function (color) {
this.uniColor=color;
});

Clazz.newMeth(C$, 'resetForceUniColor$',  function () {
this.uniColor=null;
});

Clazz.newMeth(C$, 'getReactionRole$',  function () {
return this.reactionRole;
});

Clazz.newMeth(C$, 'setReactionRole$I',  function (reactionRole) {
this.reactionRole=reactionRole;
});

Clazz.newMeth(C$, 'center$',  function () {
this.center$D(1.0);
});

Clazz.newMeth(C$, 'center$D',  function (factor) {
if (this.natoms == 0) return;
var widthAndHeight=this.jme.getMolecularAreaCoordBoundingBox$();
var xpix=widthAndHeight.width;
var ypix=widthAndHeight.height;
if (xpix <= 0  || ypix <= 0  ) {
this.needRecentering=true;
return;
}var cad=this.computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(null);
var shiftx=xpix / 2 - cad.getCenterX$();
var shifty=ypix / 2 - cad.getCenterY$();
if (!this.jme.nocenter) this.moveXY$D$D(shiftx * factor, shifty * factor);
});

Clazz.newMeth(C$, 'closestDistance$D$D',  function (x, y) {
return this.closestAtomDistance$D$D(x, y);
});

Clazz.newMeth(C$, 'draw$jme_canvas_PreciseGraphicsAWT',  function (og) {
var offset2=2;
var offset3=3;
if (this.nAtoms$() == 0) return;
var markColorBackground=this.parameters.mark;
var atomTextStrokeColorArray=Clazz.array($I$(4), [this.nAtoms$() + 1]);
og.setDefaultBackGroundColor$java_awt_Color(this.jme.canvasBg);
if (this.jme.options.depictBorder) {
og.setColor$java_awt_Color($I$(4).black);
og.drawRect$D$D$D$D(0, 0, this.jme.dimension.width - 1, this.jme.dimension.height - 1);
}if (this.uniColor != null ) {
og.overrideColor$java_awt_Color(this.uniColor);
}if (this.needRecentering) {
this.center$();
this.jme.alignMolecules$I$I$I(1, this.jme.moleculePartsList.size$(), 0);
this.needRecentering=false;
}var rs=this.jme.options.bondBGrectRelativeSize;
if (rs > 0 ) {
for (var i=1; i <= this.nbonds; i++) {
if (this.setPresetPastelBackGroundColor$jme_canvas_PreciseGraphicsAWT$I$Z(og, i, false) != null ) {
var atom1=this.bonds[i].va;
var atom2=this.bonds[i].vb;
this.setCosSin$I$I(atom1, atom2);
var cos2=(9.0) * this.temp[0];
var sin2=(9.0) * this.temp[1];
sin2*=rs;
cos2*=rs;
var xr=Clazz.array(Double.TYPE, [4]);
var yr=Clazz.array(Double.TYPE, [4]);
xr[0]=this.x$I(atom1) + sin2;
yr[0]=this.y$I(atom1) - cos2;
xr[1]=this.x$I(atom2) + sin2;
yr[1]=this.y$I(atom2) - cos2;
xr[2]=this.x$I(atom2) - sin2;
yr[2]=this.y$I(atom2) + cos2;
xr[3]=this.x$I(atom1) - sin2;
yr[3]=this.y$I(atom1) + cos2;
og.fillPolygon$DA$DA$I(xr, yr, 4);
}}
}var cs=24.0;
rs=this.jme.options.atomBGcircleRelativeSize;
if (rs > 0 ) {
for (var i=1; i <= this.natoms; i++) {
var backgroundColor=this.setPresetPastelBackGroundColor$jme_canvas_PreciseGraphicsAWT$I$Z(og, i, true);
if (backgroundColor != null ) {
var scs=cs * rs;
og.fillOval$D$D$D$D(this.x$I(i) - scs / 2.0, this.y$I(i) - scs / 2.0, scs, scs);
if (og.currentZoomFactor$() >= 2 ) {
var contrastColor=$I$(5).contrast$java_awt_Color(backgroundColor);
atomTextStrokeColorArray[i]=contrastColor;
}}}
}if (this.ringInfo == null  && this.haveMultipleBonds ) {
p$1.setRingInfo.apply(this, []);
}this.computeAtomLabels$();
og.setFont$java_awt_Font(this.jme.gui.getAtomDrawingFont$());
var fm=this.jme.gui.getAtomDrawingFontMetrics$();
var h=$I$(6).stringHeight$java_awt_FontMetrics(fm);
for (var i=1; i <= this.nbonds; i++) {
var bond=this.bonds[i];
var atom1=bond.va;
var atom2=bond.vb;
og.setColor$java_awt_Color(bond.isCoordination$() ? $I$(4).LIGHT_GRAY : $I$(4).BLACK);
if (this.jme.action == 106 && this.touchedBond == i  && this.isRotatableBond$I(i) ) {
continue;
}if (bond.stereo == 3 || bond.stereo == 4  || bond.stereo == 6 ) {
var d=atom1;
atom1=atom2;
atom2=d;
}var xa=this.x$I(atom1);
var ya=this.y$I(atom1);
var xb=this.x$I(atom2);
var yb=this.y$I(atom2);
if (!(bond.isSingle$() || bond.isCoordination$() ) || bond.stereo != 0 ) {
this.setCosSin$I$I(atom1, atom2);
}switch (bond.bondType) {
case 2:
var cos2=2.0 * this.temp[0];
var sin2=2.0 * this.temp[1];
if (p$1.bondIsSidelined$jme_core_Bond.apply(this, [bond])) {
og.drawLine$D$D$D$D(xa, ya, xb, yb);
p$1.drawSideLine$jme_canvas_PreciseGraphicsAWT$jme_core_Bond$D$D$D$D$D$D.apply(this, [og, bond, xa, ya, xb, yb, cos2, sin2]);
} else if (bond.stereo == 10) {
og.drawLine$D$D$D$D(xa + sin2, ya - cos2, xb - sin2, yb + cos2);
og.drawLine$D$D$D$D(xa - sin2, ya + cos2, xb + sin2, yb - cos2);
} else {
og.drawLine$D$D$D$D(xa + sin2, ya - cos2, xb + sin2, yb - cos2);
og.drawLine$D$D$D$D(xa - sin2, ya + cos2, xb - sin2, yb + cos2);
}og.setColor$java_awt_Color($I$(4).black);
break;
case 3:
og.drawLine$D$D$D$D(xa, ya, xb, yb);
var cos3=3.0 * this.temp[0];
var sin3=3.0 * this.temp[1];
og.drawLine$D$D$D$D(xa + sin3, ya - cos3, xb + sin3, yb - cos3);
og.drawLine$D$D$D$D(xa - sin3, ya + cos3, xb - sin3, yb + cos3);
break;
case 9:
for (var k=0; k < 10; k++) {
var xax=xa - (xa - xb) / 10.0 * k;
var yax=ya - (ya - yb) / 10.0 * k;
og.drawLine$D$D$D$D(xax, yax, xax, yax);
}
var o=bond.btag;
var z="?";
if (o != null ) z=o;
var w=fm.stringWidth$S(z);
var xstart=(xa + xb) / 2.0 - w / 2.0;
var ystart=(ya + yb) / 2.0 + h / 2 - 1;
og.setColor$java_awt_Color($I$(4).magenta);
og.drawString$S$D$D(z, xstart, ystart);
og.setColor$java_awt_Color($I$(4).black);
break;
default:
switch (bond.stereo) {
default:
og.drawLine$D$D$D$D(xa, ya, xb, yb);
break;
case 1:
case 3:
cos2=3.0 * this.temp[0];
sin2=3.0 * this.temp[1];
var px=Clazz.array(Double.TYPE, [3]);
var py=Clazz.array(Double.TYPE, [3]);
px[0]=xb + sin2;
py[0]=yb - cos2;
px[1]=xa;
py[1]=ya;
px[2]=xb - sin2;
py[2]=yb + cos2;
og.fillPolygon$DA$DA$I(px, py, 3);
break;
case 2:
case 4:
cos2=3.0 * this.temp[0];
sin2=3.0 * this.temp[1];
for (var k=0; k < 10 ; k++) {
var xax=xa - (xa - xb) / 10.0 * k;
var yax=ya - (ya - yb) / 10.0 * k;
var sc=k / 10.0;
og.drawLine$D$D$D$D(xax + sin2 * sc, yax - cos2 * sc, xax - sin2 * sc, yax + cos2 * sc);
}
break;
case 5:
case 6:
var x1=0;
var x2=0;
var y1=0;
var y2=0;
cos2=3.0 * this.temp[0];
sin2=3.0 * this.temp[1];
var m=8;
for (var k=0; k < m + 1 ; k+=1) {
var xax=xa - (xa - xb) / m * k;
var yax=ya - (ya - yb) / m * k;
var sc=k / m;
x1=xax + sin2 * sc;
y1=yax - cos2 * sc;
if (k > 0 ) {
og.drawLine$D$D$D$D(x2, y2, x1, y1);
}x2=xax - sin2 * sc;
y2=yax + cos2 * sc;
og.drawLine$D$D$D$D(x1, y1, x2, y2);
}
break;
}
break;
}
if (false) {
var btag=bond.btag;
if (btag != null  && btag.length$() > 0 ) {
var w=fm.stringWidth$S(btag);
var xstart=(xa + xb) / 2.0 - w / 2.0;
var ystart=(ya + yb) / 2.0 + h / 2 - 1;
og.setColor$java_awt_Color($I$(4).red);
og.drawString$S$D$D(btag, xstart, ystart);
og.setColor$java_awt_Color($I$(4).black);
}}}
for (var i=1; i <= this.natoms; i++) {
if (this.atomLabels[i].noLabelAtom) {
continue;
}og.setBackGroundColor$();
this.setPresetPastelBackGroundColor$jme_canvas_PreciseGraphicsAWT$I$Z(og, i, true);
this.atomLabels[i].fill$jme_canvas_PreciseGraphicsAWT(og);
og.setColor$java_awt_Color($I$(7).color[this.an$I(i)]);
var strokeColor=atomTextStrokeColorArray[i];
this.atomLabels[i].draw$jme_canvas_PreciseGraphicsAWT$java_awt_Color$D$java_awt_FontMetrics(og, strokeColor, h, fm);
}
if (!markColorBackground) {
og.setFont$java_awt_Font(this.jme.gui.atomMapDrawingAreaFont);
for (var i=1; i <= this.natoms; i++) {
var al=this.atomLabels[i];
var mapString=al.mapString;
if (mapString == null ) continue;
var atomMapX=al.atomMapX;
var atomMapY=al.atomMapY;
og.setColor$java_awt_Color($I$(4).magenta);
var strokeColor=atomTextStrokeColorArray[i];
if (strokeColor == null ) {
og.drawString$S$D$D(mapString, atomMapX, atomMapY);
} else {
og.drawStringWithStroke$S$D$D$java_awt_Color$D(mapString, atomMapX, atomMapY, strokeColor, h / 20);
}}
}if (false) {
for (var i=1; i <= this.natoms; i++) {
var a=this.atoms[i];
if (a.atag == null  || a.atag.equals$O("") ) continue;
var al=this.atomLabels[i];
var smallWidth=al.smallAtomWidthLabel;
var fullWidth=al.fullAtomWidthLabel;
var xstart=a.x - smallWidth / 2.0;
var ystart=a.y + h / 2 - 1;
og.setColor$java_awt_Color($I$(4).red);
og.drawString$S$D$D(" " + a.atag, xstart + fullWidth, ystart);
}
}if ((this.touchedAtom > 0 || this.touchedBond > 0 ) && !false ) {
og.setColor$java_awt_Color(this.jme.action == 104 ? $I$(4).red : $I$(4).blue);
if (this.touchedAtom > 0 && this.jme.action != 106 ) {
var r=this.atomLabels[this.touchedAtom].drawBox;
og.drawRect$D$D$D$D(r.x, r.y, r.width, r.height);
}if (this.touchedBond > 0 && this.jme.action != 113 ) {
var b=this.bonds[this.touchedBond];
var atom1=b.va;
var atom2=b.vb;
this.setCosSin$I$I(atom1, atom2);
var cos2=(4.0) * this.temp[0];
var sin2=(4.0) * this.temp[1];
if (p$1.bondIsSidelined$jme_core_Bond.apply(this, [b])) {
cos2*=1.5;
sin2*=1.5;
}var px=Clazz.array(Double.TYPE, [5]);
var py=Clazz.array(Double.TYPE, [5]);
px[0]=this.x$I(atom1) + sin2;
px[1]=this.x$I(atom2) + sin2;
py[0]=this.y$I(atom1) - cos2;
py[1]=this.y$I(atom2) - cos2;
px[3]=this.x$I(atom1) - sin2;
px[2]=this.x$I(atom2) - sin2;
py[3]=this.y$I(atom1) + cos2;
py[2]=this.y$I(atom2) + cos2;
px[4]=px[0];
py[4]=py[0];
if (this.jme.action != 106) {
og.drawPolygon$DA$DA$I(px, py, 5);
} else if (this.isRotatableBond$I(this.touchedBond)) {
p$1.drawRotatableBond$jme_canvas_PreciseGraphicsAWT.apply(this, [og]);
}}}if (this.uniColor != null ) {
og.resetOverrideColor$();
}});

Clazz.newMeth(C$, 'bondIsSidelined$jme_core_Bond',  function (bond) {
return bond.bondType == 2 && bond.stereo != 10  && (!Double.isNaN$D(bond.guideX) || !Double.isNaN$D(bond.guideY) && this.atomLabels[bond.va].noLabelAtom && this.atomLabels[bond.vb].noLabelAtom   ) ;
}, p$1);

Clazz.newMeth(C$, 'drawRotatableBond$jme_canvas_PreciseGraphicsAWT',  function (og) {
var va=this.bonds[this.touchedBond].va;
var vb=this.bonds[this.touchedBond].vb;
this.computeMultiPartIndices$I(this.touchedBond);
var partA=this.atoms[va].partIndex;
var partB=this.atoms[vb].partIndex;
var sizeA=0;
var sizeB=0;
for (var i=1; i <= this.natoms; i++) {
var pi=this.atoms[i].partIndex;
if (pi == partA) {
++sizeA;
} else if (pi == partB) {
++sizeB;
}}
var partToDelete=sizeA > sizeB ? partB : partA;
og.setColor$java_awt_Color($I$(4).red);
for (var i=1; i <= this.natoms; i++) {
this.atoms[i].deleteFlag=false;
if (this.atoms[i].partIndex == partToDelete) {
this.atoms[i].deleteFlag=true;
var r=this.atomLabels[i].drawBox;
og.drawRect$D$D$D$D(r.x, r.y, r.width, r.height);
}}
}, p$1);

Clazz.newMeth(C$, 'drawSideLine$jme_canvas_PreciseGraphicsAWT$jme_core_Bond$D$D$D$D$D$D',  function (og, bond, xa, ya, xb, yb, cos2, sin2) {
var cx=bond.centerX;
var cy=bond.centerY;
var ox=cx + sin2 * 2;
var oy=cy - cos2 * 2;
var gx=bond.guideX;
var gy=bond.guideY;
var min=3;
if ((cx - gx) * (cx - gx) + (cy - gy) * (cy - gy) < min ) {
gx=NaN;
}var f=(Double.isNaN$D(gx) ? -2.0 : (ox - gx) * (ox - gx) + (oy - gy) * (oy - gy) > (cx - gx) * (cx - gx) + (cy - gy) * (cy - gy)  ? -2 : 2);
var g=0.1;
var dx=xb - xa;
var dy=yb - ya;
xa+=dx * g;
xb-=dx * g;
ya+=dy * g;
yb-=dy * g;
var x1=xa + sin2 * f;
var y1=ya - cos2 * f;
var x2=xb + sin2 * f;
var y2=yb - cos2 * f;
og.drawLine$D$D$D$D(x1, y1, x2, y2);
}, p$1);

Clazz.newMeth(C$, 'computeAtomLabels$',  function () {
var showHs=this.parameters.hydrogenParams.showHs;
var showMap=(!this.parameters.mark || this.parameters.showAtomMapNumberWithBackgroundColor );
var fm=this.jme.gui.getAtomDrawingFontMetrics$();
var rb=25.0;
this.atomLabels=$I$(8).createLabels$jme_JMEmol$D$java_awt_FontMetrics$Z$Z$jme_gui_AtomDisplayLabelA(this, rb, fm, showHs, showMap, this.atomLabels);
});

Clazz.newMeth(C$, 'computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double',  function (union) {
if (this.natoms == 0) return union;
this.computeAtomLabels$();
for (var i=1; i <= this.natoms; i++) union=$I$(9).createUnion$java_awt_geom_Rectangle2D_Double$java_awt_geom_Rectangle2D_Double$java_awt_geom_Rectangle2D_Double(this.atomLabels[i].drawBox, union, union);

return union;
});

Clazz.newMeth(C$, 'rubberBanding$D$D',  function (xnew, ynew) {
this.touchedAtom=0;
this.XY$I$D$D(0, xnew, ynew);
if (this.jme.action != 205) {
var atom=this.checkTouch$I$Z(0, true);
if (atom > 0) {
this.touchedAtom=atom;
if (atom == this.touched_org) {
this.XY$I$D$D(this.natoms, this.xorg, this.yorg);
} else {
this.XY$I$D$D(this.natoms, this.x$I(atom), this.y$I(atom));
}} else {
this.setCosSin$I$I(this.touched_org, 0);
this.XY$I$D$D(this.natoms, this.x$I(this.touched_org) + 25.0 * this.temp[0], this.y$I(this.touched_org) + 25.0 * this.temp[1]);
}return;
}this.touchedBond=0;
var last=this.chain[this.nchain];
var parent=this.chain[this.nchain - 1];
var dx=this.x$I(last) - this.x$I(parent);
var dy=this.y$I(last) - this.y$I(parent);
var rx=Math.sqrt(dx * dx + dy * dy);
if (rx < 1.0 ) rx=1.0;
var sina=dy / rx;
var cosa=dx / rx;
var vv=rx / 2.0 / Math.tan(0.5235987755982988) ;
var xx=xnew - this.x$I(parent);
var yy=ynew - this.y$I(parent);
var xm=-rx / 2.0 + xx * cosa + yy * sina;
var ym=yy * cosa - xx * sina;
if (xm < 0.0 ) {
if (this.nchain > 1) {
this.deleteAtom$I(this.natoms);
--this.nchain;
this.stopChain=false;
} else if (this.natoms == 2) {
if (this.y$I(2) - this.y$I(1) < 0  && ynew - this.y$I(1) > 0  ) this.atoms[2].y=this.y$I(1) + rx / 2.0;
 else if (this.y$I(2) - this.y$I(1) > 0  && ynew - this.y$I(1) < 0  ) this.atoms[2].y=this.y$I(1) - rx / 2.0;
if (this.x$I(2) - this.x$I(1) < 0  && xnew - this.x$I(1) > 0  ) this.atoms[2].x=this.x$I(1) + rx * 0.866;
 else if (this.x$I(2) - this.x$I(1) > 0  && xnew - this.x$I(1) < 0  ) this.atoms[2].x=this.x$I(1) - rx * 0.866;
} else {
if (this.nv$I(this.chain[0]) == 2) {
var ref=this.v$I(this.chain[0])[1];
if (ref == this.chain[1]) ref=this.v$I(this.chain[0])[2];
dx=this.x$I(this.chain[0]) - this.x$I(ref);
dy=this.y$I(this.chain[0]) - this.y$I(ref);
rx=Math.sqrt(dx * dx + dy * dy);
if (rx < 1.0 ) rx=1.0;
sina=dy / rx;
cosa=dx / rx;
xx=xnew - this.x$I(ref);
yy=ynew - this.y$I(ref);
var ymm=yy * cosa - xx * sina;
xx=this.x$I(this.chain[1]) - this.x$I(ref);
yy=this.y$I(this.chain[1]) - this.y$I(ref);
var yc1=yy * cosa - xx * sina;
if (ymm > 0.0  && yc1 < 0.0   || ymm < 0.0  && yc1 > 0.0   ) {
var bd=this.nbonds;
this.addBondToAtom$I$I$I$Z(0, this.chain[0], 0, false);
this.deleteBond$I$Z(bd, true);
if (this.checkTouch$I$Z(this.natoms, true) > 0) this.stopChain=true;
}}}} else {
if (this.stopChain) return;
var th=-1.0;
if (xm < rx * 1.5 ) th=(rx * 1.5 - xm) * vv / (rx * 1.5);
if (Math.abs(ym) > th ) {
++this.nchain;
if (this.nchain > 100) {
this.jme.showInfo$S("You are too focused on chains, enough of it for now !");
--this.nchain;
return;
}this.addBondToAtom$I$I$I$Z(1, this.natoms, Long.$ival(Math.round$D(ym)), false);
this.jme.willPostSave$Z(false);
this.chain[this.nchain]=this.natoms;
if (this.checkTouch$I$Z(this.natoms, true) > 0) this.stopChain=true;
}}this.touchedAtom=0;
});

Clazz.newMeth(C$, 'checkChain$',  function () {
if (this.stopChain) {
var n=this.checkTouch$I$Z(this.natoms, false);
if (this.nv$I(n) < 6) {
var parent=this.chain[this.nchain - 1];
this.createAndAddNewBond$I$I$I(n, parent, 1);
}this.deleteAtom$I(this.natoms);
}this.stopChain=false;
});

Clazz.newMeth(C$, 'checkTouch$I$Z',  function (atom, onlyOne) {
return this.checkTouchToAtom$I$I$I$D$Z(atom, 1, this.natoms, 50, onlyOne);
});

Clazz.newMeth(C$, 'countNumberOverlapAtomOfAddedFragment$I$I',  function (fragmentFirstAtom, fragmentLastAtom) {
var result=0;
for (var at=1; at <= this.natoms; at++) {
if (at < fragmentFirstAtom && at > fragmentLastAtom  && this.checkTouchToAtom$I$I$I$D$Z(at, fragmentFirstAtom, fragmentLastAtom, 50, true) != 0 ) {
++result;
}}
return result;
});

Clazz.newMeth(C$, 'avoidTouch$I',  function (from) {
if (from == 0) from=this.natoms;
for (var i=this.natoms; i > this.natoms - from; i--) {
if (this.checkTouch$I$Z(i, true) != 0) this.moveXY$I$D$D(i, 6, 6);
}
});

Clazz.newMeth(C$, 'checkBond$',  function () {
var atom=this.checkTouch$I$Z(this.natoms, false);
if (atom == 0) return;
--this.natoms;
var i=this.getBondIndex$I$I(atom, this.touched_org);
if (i > 0) {
--this.nbonds;
this.incrNV$I$I(this.touched_org, -1);
if (this.bonds[i].bondType < (this.bonds[i].smallRing ? 2 : 3)) {
++this.bonds[i].bondType;
this.bonds[i].stereo=0;
this.setBondCenter$jme_core_Bond(this.bonds[i]);
} else {
this.info$S("Maximum allowed bond order has been reached!");
}return;
} else if (this.nv$I(atom) == 6) {
--this.nbonds;
this.incrNV$I$I(this.touched_org, -1);
this.info$S("Not possible connection !");
return;
}this.bonds[this.nbonds].vb=atom;
this.incrNV$I$I(this.touched_org, -1);
this.addBothNeighbors$I$I(atom, this.touched_org);
this.setBondCenter$jme_core_Bond(this.bonds[this.nbonds]);
});

Clazz.newMeth(C$, 'addOtherMolToMe$jme_JMEmol',  function (otherMol) {
var nn=this.natoms;
for (var i=1; i <= otherMol.natoms; i++) {
this.createAtomFromOther$jme_core_Atom(otherMol.atoms[i]);
this.AN$I$I(this.natoms, otherMol.an$I(i));
}
for (var i=1; i <= otherMol.nbonds; i++) {
this.createAndAddBondFromOther$jme_core_Bond(otherMol.bonds[i]);
this.bonds[this.nbonds].va=otherMol.bonds[i].va + nn;
this.bonds[this.nbonds].vb=otherMol.bonds[i].vb + nn;
}
});

Clazz.newMeth(C$, 'createAtomFromOther$jme_core_Atom',  function (atomToDuplicate) {
this.atomLabels=null;
return C$.superclazz.prototype.createAtomFromOther$jme_core_Atom.apply(this, [atomToDuplicate]);
});

Clazz.newMeth(C$, 'setAtomOrBondColors$S$I$Z',  function (s, delta, isAtom) {
var st=Clazz.new_($I$(10,1).c$$S$S,[s, ","]);
try {
while (st.hasMoreTokens$()){
var atomOrBond=Integer.valueOf$S(st.nextToken$()).intValue$() - delta;
var color=Integer.valueOf$S(st.nextToken$()).intValue$();
if (isAtom) this.addAtomColor$I$I(atomOrBond, color);
 else {
this.addBondColor$I$I(atomOrBond, color);
}}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("Error in atom coloring");
$I$(11).log$S("Error in atom coloring");
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'setAtomColors$S$I',  function (s, delta) {
this.setAtomOrBondColors$S$I$Z(s, delta, true);
});

Clazz.newMeth(C$, 'setBondColors$S$I',  function (s, delta) {
this.setAtomOrBondColors$S$I$Z(s, delta, false);
});

Clazz.newMeth(C$, 'addAtomColor$I$I',  function (at, c) {
if (at > 0 && at <= this.natoms ) {
this.atoms[at].addBackgroundColor$I(c);
}});

Clazz.newMeth(C$, 'getAtomBackgroundColors$I',  function (at) {
return (at > 0 && at <= this.natoms  ? this.atoms[at].getBackgroundColors$() : null);
});

Clazz.newMeth(C$, 'addBondColor$I$I',  function (b, c) {
if (b > 0 && b <= this.nbonds ) {
this.bonds[b].addBackgroundColor$I(c);
}});

Clazz.newMeth(C$, 'getBondBackgroundColors$I',  function (b) {
return (b > 0 && b <= this.nbonds  ? this.bonds[b].getBackgroundColors$() : null);
});

Clazz.newMeth(C$, 'deepCopy$',  function () {
return Clazz.new_(C$.c$$jme_JMEmol,[this]);
});

Clazz.newMeth(C$, 'isRotatableBond$I$I',  function (a1, a2) {
return this.minimumRingSize$I$I(a1, a2) == 0;
});

Clazz.newMeth(C$, 'isRotatableBond$I',  function (b) {
return this.isRotatableBond$I$I(this.bonds[b].va, this.bonds[b].vb);
});

Clazz.newMeth(C$, 'createSmiles$',  function () {
return this.createSmiles$jme_core_JMECore_Parameters(this.parameters);
});

Clazz.newMeth(C$, 'createSmiles$jme_core_JMECore_Parameters',  function (pars) {
return $I$(12,"getSmiles$jme_core_JMECore$jme_core_JMECore_Parameters$Z",[this.deepCopy$(), pars, this.isQuery]);
});

Clazz.newMeth(C$, 'findAtomChargeForOutput$I',  function (atomIndex) {
var charge=0;
if (atomIndex > 0 && atomIndex <= this.nAtoms$() ) {
var atom=this.atoms[atomIndex];
charge=atom.q$();
}return charge;
});

Clazz.newMeth(C$, 'hasMarkedAtom$',  function () {
for (var at=1; at <= this.natoms; at++) {
if (this.findAtomMapForOutput$I(at) > 0) {
return true;
}}
return false;
});

Clazz.newMeth(C$, 'createMolFile$S',  function (header) {
return $I$(2,"createMolFile$jme_core_JMECore$S$Z$java_awt_geom_Rectangle2D_Double",[this, header, true, this.computeCoordinate2DboundingBox$()]);
});

Clazz.newMeth(C$, 'changeCharge$I$I',  function (atom, type) {
var np="Charge change not possible on ";
if (type == 1) {
this.incrQ$I$I(atom, 1);
return true;
} else if (type == -1) {
this.incrQ$I$I(atom, -1);
return true;
}var startCharge=this.q$I(atom);
var startNH=this.atoms[atom].nh;
var sbo=this.getSumOfBondOrder$I(atom);
if (sbo == -1) {
if (type == 0) {
if (this.q$I(atom) == 0) this.Q$I$I(atom, 1);
 else if (this.q$I(atom) == 1) this.Q$I$I(atom, -1);
 else if (this.q$I(atom) == -1) this.Q$I$I(atom, 0);
}}switch (this.an$I(atom)) {
case 1:
if (sbo == 0) {
if (this.q$I(atom) == 0) this.Q$I$I(atom, 1);
 else if (this.q$I(atom) == 1) this.Q$I$I(atom, -1);
 else {
this.Q$I$I(atom, 0);
}}break;
case 2:
if (sbo > 2) this.info$S(np + "this boron !");
if (this.q$I(atom) == 0) this.Q$I$I(atom, 1);
 else if (this.q$I(atom) == 1) this.Q$I$I(atom, 0);
break;
case 3:
if (sbo > 3) this.info$S(np + "this carbon !");
 else if (sbo < 4) {
if (this.q$I(atom) == 0) this.Q$I$I(atom, -1);
 else if (this.q$I(atom) == -1) this.Q$I$I(atom, 1);
 else if (this.q$I(atom) == 1) this.Q$I$I(atom, 0);
}break;
case 4:
case 7:
if (sbo > 3) this.info$S(np + "multibonded N or P !");
 else if (sbo == 3 && this.q$I(atom) == 0 ) this.Q$I$I(atom, 1);
 else if (sbo == 3 && this.q$I(atom) == 1 ) this.Q$I$I(atom, 0);
 else if (sbo < 3 && this.q$I(atom) == 0 ) this.Q$I$I(atom, 1);
 else if (sbo < 3 && this.q$I(atom) == 1 ) this.Q$I$I(atom, -1);
 else if (sbo < 3 && this.q$I(atom) == -1 ) this.Q$I$I(atom, 0);
break;
case 5:
case 8:
case 13:
if (sbo > 2) this.info$S(np + "multibonded " + $I$(13).zlabel[this.an$I(atom)] + " !" );
 else if (sbo == 2 && this.q$I(atom) == 0 ) this.Q$I$I(atom, 1);
 else if (sbo == 2 && this.q$I(atom) == 1 ) this.Q$I$I(atom, 0);
 else if (sbo < 2 && this.q$I(atom) == 0 ) this.Q$I$I(atom, -1);
 else if (sbo < 2 && this.q$I(atom) == -1 ) this.Q$I$I(atom, 1);
 else if (sbo < 2 && this.q$I(atom) == 1 ) this.Q$I$I(atom, 0);
break;
case 9:
case 10:
case 11:
case 12:
if (sbo == 0 && this.q$I(atom) == 0 ) this.Q$I$I(atom, -1);
 else if (sbo == 0 && this.q$I(atom) == -1 ) this.Q$I$I(atom, 0);
 else this.info$S(np + "the halogen !");
break;
case 32:
this.info$S("Use X button to change charge on the X atom !");
break;
}
if ($I$(13,"chargedMetalType$I",[this.an$I(atom)]) > 0) if (!this.toggleChargeAndHydrogenCountOfMetalAtom$jme_core_Atom$I(this.atoms[atom], sbo)) this.info$S(np + $I$(13).zlabel[this.an$I(atom)]);
return startCharge != this.q$I(atom) || startNH != this.atoms[atom].nh ;
});

Clazz.newMeth(C$, 'toggleChargeAndHydrogenCountOfMetalAtom$jme_core_Atom$I',  function (atom, sbo) {
var changed=false;
var maxMetalCharge=$I$(13).chargedMetalType$I(atom.an);
if (maxMetalCharge > 0) {
var maxChargeIncrease=maxMetalCharge - sbo;
if (maxChargeIncrease > 0) {
var q=atom.q;
var nh=atom.nh;
if (q + nh < maxChargeIncrease) {
q+=maxChargeIncrease - nh;
} else if (q + nh == maxChargeIncrease) {
if (q == maxChargeIncrease) {
q=0;
nh=maxChargeIncrease;
} else {
q=0;
nh=0;
if (sbo == 0) this.info$S("Metallic " + $I$(13).zlabel[atom.an]);
}}changed=(atom.q != q || atom.nh != nh );
atom.q=q;
atom.nh=nh;
}}return changed;
});

Clazz.newMeth(C$, 'markAtom$I',  function (newMark) {
if (this.parameters.mark) {
if (this.jme.options.markOnly1) {
for (var at=1; at <= this.natoms; at++) {
if (at != this.touchedAtom) {
this.atoms[at].resetMark$();
}}
}if (newMark != this.atoms[this.touchedAtom].getMark$()) {
this.atoms[this.touchedAtom].setMark$I(newMark);
return true;
} else {
this.atoms[this.touchedAtom].resetMark$();
return false;
}}var hasBeenMarked;
var touchedAtomObject=this.atoms[this.touchedAtom];
if (newMark <= 0) {
touchedAtomObject.resetMap$();
hasBeenMarked=false;
} else {
hasBeenMarked=newMark != touchedAtomObject.getMap$();
touchedAtomObject.setMap$I(newMark);
hasBeenMarked=true;
}return hasBeenMarked;
});

Clazz.newMeth(C$, 'markBond$I',  function (newMark) {
if (this.parameters.mark) {
if (this.jme.options.markOnly1) {
for (var at=1; at <= this.nbonds; at++) {
if (at != this.touchedBond) {
this.bonds[at].resetMark$();
}}
}if (newMark != this.bonds[this.touchedBond].getMark$()) {
this.bonds[this.touchedBond].setMark$I(newMark);
return true;
} else {
this.bonds[this.touchedBond].resetMark$();
return false;
}}return false;
});

Clazz.newMeth(C$, 'failed$S',  function (msg) {
this.info$S(msg);
this.jme.setLastAction$I(9);
});

Clazz.newMeth(C$, 'compute2DcoordinatesIfMissing$',  function () {
return (this.has2Dcoordinates$() ? null : $I$(14).compute2Dcoordinates$jme_JMEmol(this));
});

Clazz.newMeth(C$, 'clearRotation$',  function () {
this.centerx=this.centery=NaN;
});

Clazz.newMeth(C$, 'rotate$D',  function (movex) {
if (Double.isNaN$D(this.centerx)) {
var bbox=this.computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(null);
this.centerx=bbox.getCenterX$();
this.centery=bbox.getCenterY$();
}this.rotate$D$D$D(movex, this.centerx, this.centery);
});

Clazz.newMeth(C$, 'reComputeBondOrderIfAromaticBondType$',  function () {
return $I$(14).reComputeBondOrderIfAromaticBondType$jme_JMEmol(this);
});

Clazz.newMeth(C$, 'addBondToAtom$I$I$I$Z',  function (action, ia, up, forceLinear) {
var bondType=(action == 204 ? 3 : action == 203 ? 2 : 1);
var b=C$.superclazz.prototype.addBondToAtom$I$I$I$Z$D.apply(this, [bondType, ia, up, forceLinear, 50]);
if (b == null ) return false;
if (action == 201) this.toggleBondStereo$I(this.nbonds);
this.xorg=this.x$I(this.natoms);
this.yorg=this.y$I(this.natoms);
return b.booleanValue$();
});

Clazz.newMeth(C$, 'cleanAfterChanged$Z',  function (polarNitro) {
this.setValenceState$();
this.cleanPolarBonds$Z(polarNitro);
this.ringInfo=null;
});

Clazz.newMeth(C$, 'deleteAtomGroup$',  function () {
while (true){
var atd=0;
for (var i=this.natoms; i >= 1; i--) if (this.atoms[i].deleteFlag && i > atd ) {
atd=i;
}
if (atd == 0) break;
this.deleteAtom$I(atd);
this.atoms[atd].deleteFlag=false;
}
});

Clazz.newMeth(C$, 'deleteCoordinationBonds$',  function () {
var cbCount=0;
for (var b=this.nbonds + 1; --b >= 1; ) {
if (this.bonds[b].bondType == 0) {
this.deleteBond$I$Z(b, false);
++cbCount;
}}
return cbCount;
});

Clazz.newMeth(C$, 'toggleBondStereo$I',  function (bondIndex) {
var bond=this.bonds[bondIndex];
if (bond.bondType == 2) {
this.toggleDoubleBondStereo$jme_core_Bond(bond);
return;
}if (!bond.isSingle$() && !bond.isCoordination$() ) {
this.info$S("Stereomarking allowed only on single and double bonds!");
return;
}var atom1=this.bonds[bondIndex].va;
var atom2=this.bonds[bondIndex].vb;
if (this.nv$I(atom1) < 2 && this.nv$I(atom2) < 2 ) {
bond.stereo=0;
this.info$S("Stereomarking meaningless on this bond !");
return;
}switch (bond.stereo) {
case 0:
if (this.nv$I(atom2) <= this.nv$I(atom1)) bond.stereo=1;
 else bond.stereo=3;
break;
case 1:
bond.stereo=2;
break;
case 2:
bond.stereo=5;
break;
case 5:
if (this.nv$I(atom2) > 2) bond.stereo=3;
 else bond.stereo=1;
break;
case 3:
bond.stereo=4;
break;
case 4:
bond.stereo=6;
break;
case 6:
if (this.nv$I(atom1) > 2) bond.stereo=1;
 else bond.stereo=3;
break;
}
});

Clazz.newMeth(C$, 'numberAtomsSequentially$',  function () {
for (var i=1; i <= this.natoms; i++) {
this.atoms[i].setMap$I(i);
}
});

Clazz.newMeth(C$, 'setRingInfo',  function () {
this.ringInfo=Clazz.new_($I$(15,1).c$$jme_core_JMECore,[this]);
}, p$1);

Clazz.newMeth(C$, 'setBondCenters$',  function () {
this.ringInfo=null;
this.haveMultipleBonds=false;
C$.superclazz.prototype.setBondCenters$.apply(this, []);
});

Clazz.newMeth(C$, 'setBondCenter$jme_core_Bond',  function (b) {
C$.superclazz.prototype.setBondCenter$jme_core_Bond.apply(this, [b]);
if (b.bondType == 2 || b.bondType == 3 ) this.haveMultipleBonds=true;
this.ringInfo=null;
});

Clazz.newMeth(C$, 'navigateBonds$I$I',  function (from, dir) {
if (this.natoms == 0 || this.nbonds == 0 ) return 0;
if (from == 0 || from > this.natoms  || -from > this.nbonds ) from=-1;
var dirx=0;
var diry=0;
switch (dir) {
case 1:
diry=-1;
break;
case 2:
diry=1;
break;
case 3:
dirx=-1;
break;
case 4:
dirx=1;
break;
}
if (from < 0) {
var b=this.bonds[-from];
this.setCosSin$I$I(b.va, b.vb);
var dotprod=dirx * this.temp[0] + diry * this.temp[1];
return (dotprod < 0  ? b.va : b.vb);
}var a=this.atoms[from];
var max=-1;
var maxi=0;
for (var i=1; i <= a.nv; i++) {
this.setCosSin$I$I(from, a.v[i]);
var dotprod=dirx * this.temp[0] + diry * this.temp[1];
if (dotprod > max ) {
max=dotprod;
maxi=a.v[i];
}}
return -this.getBondIndex$I$I(from, maxi);
});

Clazz.newMeth(C$, 'toggleDoubleBondStereo$jme_core_Bond',  function (bond) {
this.ringInfo=null;
bond.toggleNormalCrossedDoubleBond$();
});

Clazz.newMeth(C$, 'setBondType$I$I',  function (b, type) {
this.bonds[b].bondType=type;
this.setBondCenter$jme_core_Bond(this.bonds[b]);
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.JMEmol, "ReactionRole", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['all','int[]']]]

C$.$static$=function(){C$.$static$=0;
C$.all=Clazz.array(Integer.TYPE, -1, [1, 2, 3]);
};

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:53 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
