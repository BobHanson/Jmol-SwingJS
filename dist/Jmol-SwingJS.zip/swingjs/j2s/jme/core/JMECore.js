(function(){var P$=Clazz.newPackage("jme.core"),I$=[[0,['jme.core.JMECore','.Parameters','.SmilesParams'],['jme.core.JMECore','.Parameters','.HydrogenParams'],['jme.core.JMECore','.Parameters'],'jme.core.Atom','jme.core.Bond',['java.awt.geom.Rectangle2D','.Double']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JMECore", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['Parameters',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.atoms=Clazz.array($I$(4), [10]);
this.bonds=Clazz.array($I$(5), [10]);
this.chiralFlag=Boolean.FALSE;
this.temp=Clazz.array(Double.TYPE, [2]);
},1);

C$.$fields$=[['I',['natoms','nbonds'],'O',['jmesl','jme.event.JMEStatusListener','atoms','jme.core.Atom[]','bonds','jme.core.Bond[]','chiralFlag','Boolean','parameters','jme.core.JMECore.Parameters','temp','double[]']]
,['O',['DefaultParameters','jme.core.JMECore.Parameters']]]

Clazz.newMeth(C$, 'c$$jme_core_JMECore$I',  function (mol, part) {
;C$.$init$.apply(this);
this.setPart$jme_core_JMECore$I(mol, part);
}, 1);

Clazz.newMeth(C$, 'c$$jme_event_JMEStatusListener$jme_core_JMECore_Parameters',  function (jmesl, pars) {
;C$.$init$.apply(this);
this.jmesl=jmesl;
this.parameters=(pars == null  ? Clazz.new_($I$(3,1)) : pars);
this.atoms[0]=Clazz.new_($I$(4,1));
this.natoms=0;
this.nbonds=0;
}, 1);

Clazz.newMeth(C$, 'c$$jme_core_JMECore',  function (m) {
;C$.$init$.apply(this);
this.parameters=m.parameters;
this.natoms=m.natoms;
this.nbonds=m.nbonds;
this.chiralFlag=m.chiralFlag;
this.atoms=Clazz.array($I$(4), [this.natoms + 1]);
for (var i=this.atoms.length; --i >= 0; ) {
if (m.atoms[i] != null ) {
this.atoms[i]=m.atoms[i].deepCopy$();
}}
this.bonds=Clazz.array($I$(5), [this.nbonds + 1]);
for (var i=this.bonds.length; --i >= 0; ) {
if (m.bonds[i] != null ) {
this.bonds[i]=m.bonds[i].deepCopy$();
}}
}, 1);

Clazz.newMeth(C$, 'c$$jme_event_JMEStatusListener$jme_core_JMECore$I',  function (jme, m, part) {
C$.c$$jme_event_JMEStatusListener$jme_core_JMECore_Parameters.apply(this, [jme, m.parameters]);
m.computeMultiPartIndices$();
var newn=Clazz.array(Integer.TYPE, [m.natoms + 1]);
for (var i=1, n=m.natoms; i <= n; i++) {
if (this.atoms[i].partIndex == part) newn[i]=this.natoms;
}
for (var i=1; i <= m.nbonds; i++) {
var atom1=m.bonds[i].va;
var atom2=m.bonds[i].vb;
var p1=this.atoms[atom1].partIndex;
var p2=this.atoms[atom2].partIndex;
if (p1 != part && p2 != part ) continue;
if (p1 != p2) {
System.err.println$S("MOL multipart inconsistency - report bug !");
continue;
}var newAddedBond=this.createAndAddBondFromOther$jme_core_Bond(m.bonds[i]);
newAddedBond.va=newn[atom1];
newAddedBond.vb=newn[atom2];
}
this.setNeighborsFromBonds$();
}, 1);

Clazz.newMeth(C$, 'c$$jme_event_JMEStatusListener$jme_core_JMECoreA',  function (jme, mols) {
C$.c$$jme_event_JMEStatusListener$jme_core_JMECore_Parameters.apply(this, [jme, null]);
if (mols.length > 0 && mols[0] != null  ) this.parameters=mols[0].parameters;
var nmols=mols.length;
for (var i=0; i < nmols; i++) {
this.natoms+=mols[i].natoms;
this.nbonds+=mols[i].nbonds;
if ((mols[i].getChiralFlag$()).valueOf()) this.setChiralFlag$Boolean(Boolean.valueOf$Z(true));
}
this.atoms=Clazz.array($I$(4), [this.natoms + 1]);
this.bonds=Clazz.array($I$(5), [this.nbonds + 1]);
var na=0;
var nb=0;
var nadd=0;
for (var i=0; i < nmols; i++) {
for (var j=1, ni=mols[i].natoms; j <= ni; j++) {
++na;
this.atoms[na]=mols[i].atoms[j].deepCopy$();
}
for (var j=1, ni=mols[i].nbonds; j <= ni; j++) {
++nb;
this.bonds[nb]=mols[i].bonds[j].deepCopy$();
this.bonds[nb].va+=nadd;
this.bonds[nb].vb+=nadd;
}
nadd=na;
}
this.setNeighborsFromBonds$();
}, 1);

Clazz.newMeth(C$, 'isEmpty$',  function () {
return (this.natoms == 0);
});

Clazz.newMeth(C$, 'reset$',  function () {
this.natoms=0;
this.nbonds=0;
});

Clazz.newMeth(C$, 'getAtomCount$',  function () {
return this.natoms;
});

Clazz.newMeth(C$, 'nAtoms$',  function () {
return this.natoms;
});

Clazz.newMeth(C$, 'getBondCount$',  function () {
return this.nbonds;
});

Clazz.newMeth(C$, 'nBonds$',  function () {
return this.nbonds;
});

Clazz.newMeth(C$, 'getBond$I',  function (bondIndex) {
return this.bonds[bondIndex];
});

Clazz.newMeth(C$, 'getAtomLabel$I',  function (i) {
return this.atoms[i].getLabel$();
});

Clazz.newMeth(C$, 'hasHydrogen$',  function () {
for (var i=this.natoms; i >= 1; i--) {
if (this.an$I(i) == 1) {
return true;
}}
return false;
});

Clazz.newMeth(C$, 'an$I',  function (i) {
return this.atoms[i].an;
});

Clazz.newMeth(C$, 'AN$I$I',  function (i, an) {
this.atoms[i].an=an;
});

Clazz.newMeth(C$, 'getAtom$I',  function (i) {
return this.atoms[i];
});

Clazz.newMeth(C$, 'x$I',  function (i) {
return this.atoms[i].x;
});

Clazz.newMeth(C$, 'y$I',  function (i) {
return this.atoms[i].y;
});

Clazz.newMeth(C$, 'z$I',  function (i) {
return this.atoms[i].z;
});

Clazz.newMeth(C$, 'XY$I$D$D',  function (i, x, y) {
this.atoms[i].x=x;
this.atoms[i].y=y;
});

Clazz.newMeth(C$, 'XY$jme_core_Atom$D$D',  function (atom, x, y) {
atom.x=x;
atom.y=y;
}, 1);

Clazz.newMeth(C$, 'moveXY$I$D$D',  function (i, x, y) {
this.atoms[i].moveXY$D$D(x, y);
});

Clazz.newMeth(C$, 'q$I',  function (i) {
return this.atoms[i].q;
});

Clazz.newMeth(C$, 'Q$I$I',  function (i, charge) {
this.atoms[i].q=charge;
});

Clazz.newMeth(C$, 'incrQ$I$I',  function (i, incr) {
this.atoms[i].q+=incr;
});

Clazz.newMeth(C$, 'getIso$I',  function (i) {
return this.atoms[i].iso;
});

Clazz.newMeth(C$, 'getSumOfBondOrder$I',  function (i) {
return this.atoms[i].sbo;
});

Clazz.newMeth(C$, 'atag$I',  function (i) {
return this.atoms[i].atag;
});

Clazz.newMeth(C$, 'v$I',  function (i) {
return this.atoms[i].v;
});

Clazz.newMeth(C$, 'nv$I',  function (i) {
return this.atoms[i].nv;
});

Clazz.newMeth(C$, 'NV$I$I',  function (i, nv) {
this.atoms[i].nv=nv;
});

Clazz.newMeth(C$, 'incrNV$I$I',  function (i, change) {
return this.atoms[i].nv+=change;
});

Clazz.newMeth(C$, 'getChiralFlag$',  function () {
return this.chiralFlag;
});

Clazz.newMeth(C$, 'canBeChiral$',  function () {
for (var i=1; i <= this.nbonds; i++) {
if (this.bonds[i].bondType == 1 && this.bonds[i].stereo > 0 ) {
return true;
}}
return false;
});

Clazz.newMeth(C$, 'setChiralFlag$Boolean',  function (chiralFlag) {
if (this.chiralFlag !== chiralFlag ) {
this.chiralFlag=chiralFlag;
return true;
}return false;
});

Clazz.newMeth(C$, 'setPart$jme_core_JMECore$I',  function (m, part) {
this.chiralFlag=m.chiralFlag;
var newAtomIndexMap=Clazz.array(Integer.TYPE, [m.natoms + 1]);
for (var i=1; i <= m.natoms; i++) {
if (m.atoms[i].partIndex != part) continue;
this.createAtomFromOther$jme_core_Atom(m.atoms[i]);
newAtomIndexMap[i]=this.natoms;
}
for (var i=1; i <= m.nbonds; i++) {
var bond=m.bonds[i];
if (bond.partIndex == part) {
var newAddedBond=this.createAndAddBondFromOther$jme_core_Bond(bond);
newAddedBond.va=newAtomIndexMap[bond.va];
newAddedBond.vb=newAtomIndexMap[bond.vb];
}}
this.setNeighborsFromBonds$();
});

Clazz.newMeth(C$, 'createAtomFromOther$jme_core_Atom',  function (atomToDuplicate) {
++this.natoms;
if (this.natoms > this.atoms.length - 1) {
var storage=this.atoms.length + 20;
var newAtoms=Clazz.array($I$(4), [storage]);
System.arraycopy$O$I$O$I$I(this.atoms, 0, newAtoms, 0, this.atoms.length);
this.atoms=newAtoms;
}return this.atoms[this.natoms]=(atomToDuplicate == null  ? Clazz.new_($I$(4,1)) : atomToDuplicate.deepCopy$());
});

Clazz.newMeth(C$, 'cleanPolarBonds$Z',  function (polarnitro) {
for (var i=1; i <= this.nbonds; i++) {
var bond=this.bonds[i];
var atom1=bond.va;
var atom2=bond.vb;
bond.checkSmallRing$();
var bondType=bond.bondType;
if ((this.q$I(atom1) == 1 && this.q$I(atom2) == -1 ) || (this.q$I(atom1) == -1 && this.q$I(atom2) == 1 ) ) {
if (bondType == 1 || bondType == 2 ) {
if (this.an$I(atom1) != 3 && this.an$I(atom2) != 3  && polarnitro ) continue;
if (this.an$I(atom1) == 1 || this.an$I(atom2) == 1 ) continue;
if (this.an$I(atom1) == 2 || this.an$I(atom2) == 2 ) continue;
if (this.an$I(atom1) == 9 || this.an$I(atom1) == 10  || this.an$I(atom1) == 11  || this.an$I(atom1) == 12  || this.an$I(atom2) == 9  || this.an$I(atom2) == 10  || this.an$I(atom2) == 11  || this.an$I(atom2) == 12 ) continue;
this.Q$I$I(atom1, 0);
this.Q$I$I(atom2, 0);
++bondType;
bond.bondType=bondType;
this.setValenceState$();
}}if (this.q$I(atom1) == 1 && this.q$I(atom2) == 1 ) {
if (bondType == 2) bondType=1;
 else if (bondType == 3) bondType=2;
bond.bondType=bondType;
this.setValenceState$();
}if (bondType == 4) bondType=1;
bond.bondType=bondType;
}
});

Clazz.newMeth(C$, 'setNeighborsFromBonds$',  function () {
for (var i=1; i <= this.natoms; i++) this.atoms[i].nv=0;

for (var i=1; i <= this.nbonds; i++) {
var atom1=this.bonds[i].va;
var atom2=this.bonds[i].vb;
this.addBothNeighbors$I$I(atom1, atom2);
}
});

Clazz.newMeth(C$, 'addBothNeighbors$I$I',  function (at1, at2) {
this.atoms[at1].addNeighbor$I(at2);
this.atoms[at2].addNeighbor$I(at1);
});

Clazz.newMeth(C$, 'setValenceState$',  function () {
for (var i=1; i <= this.natoms; i++) {
this.setAtomValenceState$I(i);
}
});

Clazz.newMeth(C$, 'setAtomValenceState$I',  function (i) {
var atom=this.atoms[i];
var sbo=atom.sbo=this.sumBondOrders$I(i);
if (sbo == -1) {
atom.nh=0;
return;
}switch (atom.an) {
case 1:
if (sbo == 2) this.Q$I$I(i, 1);
 else if (sbo >= 1) {
this.Q$I$I(i, 0);
} else {
}atom.nh=0;
break;
case 2:
if (sbo == 3 || sbo == 5 ) {
atom.nh=0;
this.Q$I$I(i, 0);
} else if (sbo < 3) {
atom.nh=3 - sbo - this.q$I(i) ;
} else if (sbo == 4) {
this.Q$I$I(i, -1);
atom.nh=0;
} else if (sbo > 5) {
this.Q$I$I(i, sbo - 5);
atom.nh=0;
}break;
case 3:
case 6:
if (sbo < 4) {
if (this.q$I(i) > 0) atom.nh=2 - sbo + this.q$I(i);
 else if (this.q$I(i) < 0) atom.nh=2 - sbo - this.q$I(i) ;
 else atom.nh=4 - sbo;
} else {
this.Q$I$I(i, sbo - 4);
atom.nh=4 - sbo + this.q$I(i);
}break;
case 4:
case 7:
if (sbo < 3) atom.nh=3 - sbo + this.q$I(i);
 else if (sbo == 3) {
if (this.q$I(i) < 0) {
this.Q$I$I(i, 0);
atom.nh=0;
} else if (this.q$I(i) > 0) atom.nh=this.q$I(i);
 else atom.nh=3 - sbo;
} else if (sbo == 4) {
this.Q$I$I(i, 1);
atom.nh=0;
} else if (sbo == 6) {
this.Q$I$I(i, -1);
atom.nh=0;
} else {
this.Q$I$I(i, sbo - 5);
;atom.nh=0;
}break;
case 5:
if (sbo == 2) {
if (this.q$I(i) < 0) {
this.Q$I$I(i, 0);
atom.nh=0;
} else if (this.q$I(i) > 0) atom.nh=this.q$I(i);
 else atom.nh=2 - sbo;
}if (sbo > 2) this.Q$I$I(i, sbo - 2);
atom.nh=2 - sbo + this.q$I(i);
break;
case 8:
case 13:
if (sbo < 2) atom.nh=2 - sbo + this.q$I(i);
 else if (sbo == 2) {
if (this.q$I(i) < 0) {
this.Q$I$I(i, 0);
atom.nh=0;
} else if (this.q$I(i) > 0) atom.nh=this.q$I(i);
 else atom.nh=2 - sbo;
} else if (sbo == 3) {
if (this.atoms[i].nv == 2) {
this.Q$I$I(i, 0);
atom.nh=1;
} else {
this.Q$I$I(i, 1);
atom.nh=0;
}} else if (sbo == 4) {
this.Q$I$I(i, 0);
atom.nh=0;
} else if (sbo == 5) {
this.Q$I$I(i, 0);
atom.nh=1;
} else {
this.Q$I$I(i, sbo - 6);
atom.nh=0;
}break;
case 9:
case 10:
case 11:
case 12:
if (sbo >= 1) this.Q$I$I(i, sbo - 1);
atom.nh=1 - sbo + this.q$I(i);
if (sbo > 2) {
this.Q$I$I(i, 0);
atom.nh=0;
}break;
case 33:
case 32:
atom.nh=0;
break;
}
var maxMetalCharge=$I$(4).chargedMetalType$I(atom.an);
if (maxMetalCharge > 0) {
while (atom.q + atom.nh + sbo  > maxMetalCharge){
if (atom.nh > 0) {
--atom.nh;
continue;
}if (atom.q > 0) {
--atom.q;
} else break;
}
}if (atom.nh < 0) atom.nh=0;
});

Clazz.newMeth(C$, 'sumBondOrders$I',  function (atom) {
var sbo=0;
for (var i=1; i <= this.nv$I(atom); i++) {
var bond=this.getBond$I$I(atom, this.v$I(atom)[i]);
if (bond == null ) {
System.out.println$S("??JMECore.sumBondOrders null after touching atom for aromatic");
}if (bond.isSingle$()) sbo+=1;
 else if (bond.isDouble$()) sbo+=2;
 else if (bond.bondType == 3) sbo+=3;
 else if (bond.bondType == 9) return -1;
}
return sbo;
});

Clazz.newMeth(C$, 'getBond$I$I',  function (atom1, atom2) {
return this.bonds[this.getBondIndex$I$I(atom1, atom2)];
});

Clazz.newMeth(C$, 'getBondIndex$I$I',  function (atom1, atom2) {
for (var i=1; i <= this.nbonds; i++) {
if (this.bonds[i].isAB$I$I(atom1, atom2)) {
return i;
}}
return 0;
});

Clazz.newMeth(C$, 'isSingle$I',  function (bond) {
return this.bonds[bond].isSingle$();
});

Clazz.newMeth(C$, 'isDouble$I',  function (bond) {
return this.bonds[bond].isDouble$();
});

Clazz.newMeth(C$, 'bondType$I',  function (bond) {
return this.bonds[bond].bondType;
});

Clazz.newMeth(C$, 'complete$Z',  function (computeValenceState) {
this.setNeighborsFromBonds$();
this.setBondCenters$();
if (computeValenceState) {
this.setValenceState$();
}});

Clazz.newMeth(C$, 'setBondCenters$',  function () {
for (var b=1; b <= this.nbonds; b++) {
this.setBondCenter$jme_core_Bond(this.bonds[b]);
}
});

Clazz.newMeth(C$, 'setBondCenter$jme_core_Bond',  function (b) {
b.centerX=(this.atoms[b.va].x + this.atoms[b.vb].x) / 2;
b.centerY=(this.atoms[b.va].y + this.atoms[b.vb].y) / 2;
});

Clazz.newMeth(C$, 'minimumRingSize$jme_core_Bond',  function (b) {
var a1=b.va;
var a2=b.vb;
return this.minimumRingSize$I$I(a1, a2);
});

Clazz.newMeth(C$, 'minimumRingSize$I$I',  function (a1, a2) {
var bondDist=Clazz.array(Integer.TYPE, [this.natoms + 1]);
var visited=Clazz.array(Integer.TYPE, [this.natoms + 1]);
var toVisit=Clazz.array(Integer.TYPE, [this.natoms + 1]);
bondDist[a1]=1;
toVisit[1]=a1;
 BOND_SPHERE_LOOP : while (true){
var visitCount=0;
for (var v=1; toVisit[v] != 0; v++) {
var at=toVisit[v];
 NEIGHBOR_LOOP : for (var n=1; n <= this.nv$I(at); n++) {
var neighbor=this.v$I(at)[n];
if (neighbor == a2 && at == a1 ) continue NEIGHBOR_LOOP;
if (bondDist[neighbor] == 0) {
bondDist[neighbor]=bondDist[at] + 1;
++visitCount;
visited[visitCount]=neighbor;
}}
if (bondDist[a2] > 2) break BOND_SPHERE_LOOP;
}
if (visitCount == 0) break BOND_SPHERE_LOOP;
visited[visitCount + 1]=0;
{
var tmp=toVisit;
toVisit=visited;
visited=tmp;
}}
return bondDist[a2];
});

Clazz.newMeth(C$, 'findAtomMapForOutput$I',  function (i) {
return (i > 0 && i <= this.natoms  ? this.atoms[i].getMapOrMark$Z(!this.parameters.mark) : 0);
});

Clazz.newMeth(C$, 'findFirstMappdedOrMarkedAtom$',  function () {
for (var i=1; i <= this.natoms; i++) {
var at=this.atoms[i];
if (at.isMappedOrMarked$()) {
return i;
}}
return 0;
});

Clazz.newMeth(C$, 'hasMappedOrMarkedAtom$',  function () {
return this.findFirstMappdedOrMarkedAtom$() > 0;
});

Clazz.newMeth(C$, 'haveQueryOrCoordBonds$',  function () {
for (var b=1; b <= this.nbonds; b++) {
switch (this.bonds[b].bondType) {
case 9:
case 0:
return true;
}
}
return false;
});

Clazz.newMeth(C$, 'deleteHydrogens$jme_core_JMECore_Parameters_HydrogenParams',  function (pars) {
var changed=false;
if (pars.removeHs == false ) {
return changed;
}this.setNeighborsFromBonds$();
 atom_loop : for (var i=this.natoms; i >= 1; i--) {
var a=this.atoms[i];
var parent=this.atoms[a.v[1]];
if (pars.removeOnlyCHs && parent.an != 3 ) {
continue;
}if (a.an == 1 && a.nv == 1  && a.q == 0  && parent.an != 1  && parent.an < 32 ) {
if (pars.keepIsotopicHs && a.iso != 0 ) {
continue atom_loop;
}if (pars.keepMappedHs && a.isMapped$() ) {
continue atom_loop;
}var b=this.getBond$I$I(i, a.v[1]);
if (b.bondType == 1) {
if (!(pars.keepStereoHs && b.stereo != 0 )) {
this.deleteAtom$I(i);
changed=true;
}}}}
return changed;
});

Clazz.newMeth(C$, 'info$S',  function (msg) {
if (this.jmesl != null ) this.jmesl.info$S(msg);
 else System.err.println$S(msg);
});

Clazz.newMeth(C$, 'hasAromaticBondType$',  function () {
if (this.nbonds < 1) {
return false;
}for (var b=1; b <= this.nbonds; b++) {
var bond=this.bonds[b];
if (bond.bondType == 4 || bond.bondType == 5  || bond.bondType == 9 ) {
return true;
}}
return false;
});

Clazz.newMeth(C$, 'distance$I$I',  function (atom1, atom2) {
var dx=this.atoms[atom2].x - this.atoms[atom1].x;
var dy=this.atoms[atom2].y - this.atoms[atom1].y;
return Math.sqrt(dx * dx + dy * dy);
});

Clazz.newMeth(C$, 'bondDistance$I',  function (i) {
return this.distance$I$I(this.bonds[i].va, this.bonds[i].vb);
});

Clazz.newMeth(C$, 'squareEuclideanDist$D$D$D$D',  function (x1, y1, x2, y2) {
var dx=x2 - x1;
var dy=y2 - y1;
return dx * dx + dy * dy;
}, 1);

Clazz.newMeth(C$, 'dotProduct$D$D$D$D',  function (x1, y1, x2, y2) {
return x1 * x2 + y1 * y2;
}, 1);

Clazz.newMeth(C$, 'setCosSin$I$I',  function (atom1, atom2) {
var dx=this.x$I(atom2) - this.x$I(atom1);
var dy=this.y$I(atom2) - this.y$I(atom1);
var rx=Math.sqrt(dx * dx + dy * dy);
if (rx < 0.001 ) rx=0.001;
this.temp[0]=dx / rx;
this.temp[1]=dy / rx;
});

Clazz.newMeth(C$, 'rotate$D$D$D',  function (movex, centerx, centery) {
if (this.natoms == 0) return;
this.moveXY$D$D(-centerx, -centery);
var sinu=Math.sin(movex * 3.141592653589793 / 180.0);
var cosu=Math.cos(movex * 3.141592653589793 / 180.0);
for (var i=1; i <= this.natoms; i++) {
var xx=this.x$I(i) * cosu + this.y$I(i) * sinu;
var yy=-this.x$I(i) * sinu + this.y$I(i) * cosu;
this.atoms[i].x=xx;
this.atoms[i].y=yy;
}
this.moveXY$D$D(centerx, centery);
});

Clazz.newMeth(C$, 'moveXY$D$D',  function (dx, dy) {
for (var at=1; at <= this.natoms; at++) {
this.atoms[at].moveXY$D$D(dx, dy);
}
this.setBondCenters$();
});

Clazz.newMeth(C$, 'computeMultiPartIndices$',  function () {
return this.computeMultiPartIndices$I(0);
});

Clazz.newMeth(C$, 'computeMultiPartIndices$I',  function (bondToBeIgnored) {
var nparts=0;
for (var at=1; at <= this.natoms; at++) {
this.atoms[at].partIndex=0;
}
for (var b=1; b <= this.nbonds; b++) {
this.bonds[b].partIndex=0;
}
while (true){
var newPartAssignedToAtom=false;
for (var at=1; at <= this.natoms; at++) {
var atom=this.atoms[at];
if (atom.partIndex == 0) {
atom.partIndex=++nparts;
newPartAssignedToAtom=true;
break;
}}
if (!newPartAssignedToAtom) break;
while (newPartAssignedToAtom){
newPartAssignedToAtom=false;
for (var b=1; b <= this.nbonds; b++) {
if (b == bondToBeIgnored) continue;
var bond=this.bonds[b];
if (bond.partIndex > 0) {
continue;
}var atom1=this.atoms[bond.va];
var atom2=this.atoms[bond.vb];
if (atom1.partIndex != atom2.partIndex) {
bond.partIndex=atom1.partIndex=atom2.partIndex=nparts;
newPartAssignedToAtom=true;
} else {
bond.partIndex=atom1.partIndex;
}}
}
}
return nparts;
});

Clazz.newMeth(C$, 'computeCoordinate2DboundingBox$',  function () {
var bbox=null;
if (this.natoms == 0) return bbox;
var minx=1.7976931348623157E308;
var maxx=4.9E-324;
var miny=1.7976931348623157E308;
var maxy=4.9E-324;
for (var i=1; i <= this.natoms; i++) {
var x=this.x$I(i);
var y=this.y$I(i);
if (x < minx ) minx=x;
maxx=Math.max(x, maxx);
if (y < miny ) miny=y;
maxy=Math.max(y, maxy);
}
bbox=Clazz.new_($I$(6,1));
bbox.x=minx;
bbox.y=miny;
bbox.width=maxx - minx;
bbox.height=maxy - miny;
return bbox;
});

Clazz.newMeth(C$, 'getNewPoint$I$D$DA',  function (pt, rbond, newPoint) {
var atom1=this.v$I(pt)[1];
var atom2=this.v$I(pt)[2];
var dx=this.x$I(atom2) - this.x$I(atom1);
var dy=-(this.y$I(atom2) - this.y$I(atom1));
var rx=Math.sqrt(dx * dx + dy * dy);
if (rx < 0.001 ) rx=0.001;
var sina=dy / rx;
var cosa=dx / rx;
var vzd=Math.abs((this.y$I(pt) - this.y$I(atom1)) * cosa + (this.x$I(pt) - this.x$I(atom1)) * sina);
if (vzd < 1.0 ) {
dx=this.x$I(pt) - this.x$I(atom1);
dy=this.y$I(pt) - this.y$I(atom1);
rx=Math.sqrt(dx * dx + dy * dy);
if (rx < 0.001 ) rx=0.001;
var xx=rx;
var yy=rbond;
sina=dy / rx;
cosa=dx / rx;
newPoint[0]=this.x$I(atom1) + xx * cosa - yy * sina;
newPoint[1]=this.y$I(atom1) + yy * cosa + xx * sina;
} else {
var xpoint=(this.x$I(atom1) + this.x$I(atom2)) / 2.0;
var ypoint=(this.y$I(atom1) + this.y$I(atom2)) / 2.0;
dx=this.x$I(pt) - xpoint;
dy=this.y$I(pt) - ypoint;
rx=Math.sqrt(dx * dx + dy * dy);
if (rx < 0.001 ) rx=0.001;
newPoint[0]=this.x$I(pt) + rbond * dx / rx;
newPoint[1]=this.y$I(pt) + rbond * dy / rx;
}});

Clazz.newMeth(C$, 'createAndAddBondFromOther$jme_core_Bond',  function (otherBond) {
++this.nbonds;
if (this.nbonds > this.bonds.length - 1) {
var storage=this.bonds.length + 10;
var newBonds=Clazz.array($I$(5), [storage]);
System.arraycopy$O$I$O$I$I(this.bonds, 0, newBonds, 0, this.bonds.length);
this.bonds=newBonds;
}return this.bonds[this.nbonds]=(otherBond == null  ? Clazz.new_($I$(5,1)) : otherBond.deepCopy$());
});

Clazz.newMeth(C$, 'deleteAtom$I',  function (delatom) {
var bondCount=0;
var deltaSBO=0;
for (var i=1; i <= this.nbonds; i++) {
var bondI=this.bonds[i];
var atom1=bondI.va;
var atom2=bondI.vb;
if (atom1 != delatom && atom2 != delatom ) {
++bondCount;
var bondJ=this.bonds[bondCount];
bondI.copyTo$jme_core_Bond(bondJ);
bondJ.va=atom1;
if (atom1 > delatom) --bondJ.va;
bondJ.vb=atom2;
if (atom2 > delatom) --bondJ.vb;
} else {
deltaSBO+=bondI.bondType;
}}
this.nbonds=bondCount;
for (var i=delatom; i < this.natoms; i++) {
this.atoms[i]=this.atoms[i + 1];
}
--this.natoms;
if (this.natoms == 0) {
return;
}for (var i=1; i <= this.natoms; i++) {
var a=this.atoms[i];
var nv=0;
for (var j=1, ni=a.nv; j <= ni; j++) {
var atom1=a.v[j];
if (atom1 == delatom) {
a.nh+=deltaSBO;
continue;
}if (atom1 > delatom) --atom1;
a.v[++nv]=atom1;
}
a.nv=nv;
}
});

Clazz.newMeth(C$, 'createAtom$',  function () {
return this.createAtomFromOther$jme_core_Atom(null);
});

Clazz.newMeth(C$, 'setAtom$I$S',  function (atom, symbol) {
if (symbol.startsWith$S("[") && symbol.endsWith$S("]") ) {
symbol=symbol.substring$I$I(1, symbol.length$() - 1);
this.AN$I$I(atom, 32);
this.atoms[atom].label=symbol;
this.atoms[atom].nh=0;
return;
}if (symbol.length$() < 1) System.err.println$S("Error - null atom !");
symbol=this.atoms[atom].parseAtomicSymbolPatternIsotopMappAndCharge$S$jme_core_JMECore_Parameters(symbol, this.parameters);
var isQuery=false;
if (symbol.indexOf$S(",") > -1) isQuery=true;
if (symbol.indexOf$S(";") > -1) isQuery=true;
if (symbol.indexOf$S("#") > -1) isQuery=true;
if (symbol.indexOf$S("!") > -1) isQuery=true;
var hpos=symbol.indexOf$S("H");
 atomProcessing : {
if (isQuery) {
this.atoms[atom].label=symbol;
this.AN$I$I(atom, 32);
this.atoms[atom].nh=0;
break atomProcessing;
}var as=symbol;
if (hpos > 0) as=symbol.substring$I$I(0, hpos);
this.AN$I$I(atom, $I$(4).checkAtomicSymbol$S(as));
if (this.an$I(atom) == 32) this.atoms[atom].label=as;
symbol+=" ";
var nhs=0;
if (hpos > 0) {
nhs=1;
var c=symbol.charAt$I(++hpos);
if (c >= "0" && c <= "9" ) nhs=c.$c() - 48;
}if (this.an$I(atom) == 32) {
this.atoms[atom].nh=nhs;
}}});

Clazz.newMeth(C$, 'createAndAddNewBond$I$I$I',  function (at1, at2, bondType) {
var newBond=this.createAndAddBondFromOther$jme_core_Bond(null);
this.addBothNeighbors$I$I(at1, at2);
newBond.va=at1;
newBond.vb=at2;
this.setBondCenter$jme_core_Bond(newBond);
newBond.bondType=bondType;
return newBond;
});

Clazz.newMeth(C$, 'deleteBond$I$Z',  function (delbond, deleteLonelyAtoms) {
var a1=this.bonds[delbond].va;
var atom1=this.atoms[a1];
var a2=this.bonds[delbond].vb;
var atom2=this.atoms[a2];
for (var i=delbond; i < this.nbonds; i++) {
this.bonds[i]=this.bonds[i + 1];
}
--this.nbonds;
var k=0;
var ni=atom1.nv;
for (var i=1; i <= ni; i++) if (atom1.v[i] != a2) atom1.v[++k]=atom1.v[i];

atom1.nv=k;
k=0;
ni=atom2.nv;
for (var i=1; i <= ni; i++) if (atom2.v[i] != a1) atom2.v[++k]=atom2.v[i];

atom2.nv=k;
var deletedAtoms=0;
if (deleteLonelyAtoms && a1 < a2 ) {
k=a1;
a1=a2;
a2=k;
}if (this.atoms[a1].nv == 0) {
if (deleteLonelyAtoms) {
this.deleteAtom$I(a1);
}deletedAtoms+=1;
}if (this.atoms[a2].nv == 0) {
if (deleteLonelyAtoms) {
this.deleteAtom$I(a2);
}deletedAtoms+=2;
}this.setBondCenters$();
return deletedAtoms;
});

Clazz.newMeth(C$, 'addBondToAtom$I$I$I$Z$D',  function (bondType, ia, up, forceLinear, limit) {
var upWasUsed=false;
var atom=this.atoms[ia];
if (atom.nv > 5) {
return null;
}this.createAtomFromOther$jme_core_Atom(null);
switch (atom.nv) {
case 0:
this.XY$I$D$D(this.natoms, atom.x + 21.65, atom.y + 12.5);
break;
case 1:
var ia1=atom.v[1];
var atom1=this.atoms[ia1];
var atom3=(atom1.nv != 2 ? null : atom1.v[1] == ia ? this.atoms[atom1.v[2]] : this.atoms[atom1.v[1]]);
var dx=atom.x - atom1.x;
var dy=atom.y - atom1.y;
var rx=Math.sqrt(dx * dx + dy * dy);
if (rx < 0.001 ) rx=0.001;
var sina=dy / rx;
var cosa=dx / rx;
var xx;
var yy;
var b=this.getBond$I$I(ia, ia1);
if (forceLinear || bondType == 3  || b.bondType == 3  || bondType == 2 && b.bondType == 2  ) {
xx=rx + 25.0;
yy=0.0;
} else {
xx=rx + 25.0 * Math.cos(1.0471975511965976);
yy=25.0 * Math.sin(1.0471975511965976);
}if (atom3 != null ) if (((atom3.y - atom1.y) * cosa - (atom3.x - atom1.x) * sina) > 0 ) yy=-yy;
if (up > 0 && yy < 0  ) yy=-yy;
 else if (up < 0 && yy > 0  ) yy=-yy;
this.XY$I$D$D(this.natoms, atom1.x + xx * cosa - yy * sina, atom1.y + yy * cosa + xx * sina);
upWasUsed=true;
break;
case 2:
var newPoint=Clazz.array(Double.TYPE, [2]);
this.getNewPoint$I$D$DA(ia, 25.0, newPoint);
this.XY$I$D$D(this.natoms, newPoint[0], newPoint[1]);
break;
case 3:
case 4:
case 5:
for (var i=1; i <= atom.nv; i++) {
atom1=this.atoms[atom.v[i]];
dx=atom.x - atom1.x;
dy=atom.y - atom1.y;
rx=Math.sqrt(dx * dx + dy * dy);
if (rx < 0.001 ) rx=0.001;
this.XY$I$D$D(this.natoms, atom.x + 25.0 * dx / rx, atom.y + 25.0 * dy / rx);
if (i == atom.nv || this.checkTouchToAtom$I$I$I$D$Z(this.natoms, 1, this.natoms, limit, true) == 0 ) break;
}
break;
}
this.createAndAddNewBond$I$I$I(ia, this.natoms, bondType);
return Boolean.valueOf$Z(upWasUsed);
});

Clazz.newMeth(C$, 'checkTouchToAtom$I$I$I$D$Z',  function (ia, firstAtom, lastAtom, limit, justOne) {
var dx;
var dy;
var rx;
var min=limit + 1;
var touch=0;
var atom=this.atoms[ia];
for (var i=firstAtom; i <= lastAtom; i++) {
if (ia == i) continue;
dx=atom.x - this.atoms[i].x;
dy=atom.y - this.atoms[i].y;
rx=dx * dx + dy * dy;
if (rx < limit ) if (rx < min ) {
min=rx;
touch=i;
if (justOne) return i;
}}
return touch;
});

Clazz.newMeth(C$, 'hasCloseContactWith$jme_core_JMECore$D',  function (other, minAtomDist) {
for (var a1=1, n=this.nAtoms$(); a1 <= n; a1++) {
var at1=this.getAtom$I(a1);
for (var a2=1, n2=other.nAtoms$(); a2 <= n2; a2++) {
var at2=other.getAtom$I(a2);
if (at1.hasCloseContactWith$jme_core_Atom$D(at2, minAtomDist)) {
return true;
}}
}
return false;
});

Clazz.newMeth(C$, 'testAtomAndBondTouch$D$D$Z$Z$DA',  function (xx, yy, ignoreAtoms, ignoreBonds, retMin) {
var i;
var found=0;
var rx;
var min=retMin[0];
if (!ignoreBonds) {
for (i=1; i <= this.nbonds; i++) {
var b=this.bonds[i];
rx=C$.squareEuclideanDist$D$D$D$D(xx, yy, b.centerX, b.centerY);
if (rx < min ) {
min=rx;
found=-i;
var ax=this.atoms[b.va].x;
var ay=this.atoms[b.va].y;
var vx=this.atoms[b.vb].x - ax;
var vy=this.atoms[b.vb].y - ay;
for (var third=1; third <= 2; third++) {
var x3=ax + third * vx / 3;
var y3=ay + third * vy / 3;
rx=C$.squareEuclideanDist$D$D$D$D(xx, yy, x3, y3);
if (rx < min ) {
min=rx;
}}
}}
}if (!ignoreAtoms) {
for (i=1; i <= this.natoms; i++) {
rx=C$.squareEuclideanDist$D$D$D$D(xx, yy, this.x$I(i), this.y$I(i));
if (rx < min ) {
min=rx;
found=i;
}}
}if (found == 0 && !ignoreBonds ) {
for (i=1; i <= this.nbonds; i++) {
var at1=this.bonds[i].va;
var at2=this.bonds[i].vb;
var at1X=this.x$I(at1);
var at1Y=this.y$I(at1);
var at2X=this.x$I(at2);
var at2Y=this.y$I(at2);
at2X-=at1X;
at2Y-=at1Y;
var xx2=xx - at1X;
var yy2=yy - at1Y;
var sqBondLength=at2X * at2X + at2Y * at2Y;
var sqDistToAtom1=xx2 * xx2 + yy2 * yy2;
var sqDistToAtom2=C$.squareEuclideanDist$D$D$D$D(xx2, yy2, at2X, at2Y);
if (sqDistToAtom1 + sqDistToAtom2 > sqBondLength + min ) {
continue;
}var dp=C$.dotProduct$D$D$D$D(xx2, yy2, at2X, at2Y);
if (dp < 0 ) {
continue;
}sqBondLength=Math.sqrt(sqBondLength);
sqDistToAtom1=Math.sqrt(sqDistToAtom1);
var cos=dp / (sqBondLength * sqDistToAtom1);
if (cos >= 1 ) {
continue;
}var otherAngle=1.5707963267948966 - Math.acos(cos);
var dist=sqDistToAtom1 * Math.cos(otherAngle);
dist*=dist;
if (dist < min ) {
found=i * -1;
min=dist;
}}
}retMin[0]=min;
return found;
});

Clazz.newMeth(C$, 'scaleXY$D',  function (scale) {
if (scale > 0 ) {
for (var at=1; at <= this.natoms; at++) {
this.atoms[at].scaleXY$D(scale);
}
this.setBondCenters$();
}});

Clazz.newMeth(C$, 'createAtom$S',  function (symbol) {
var atom=this.createAtom$();
this.setAtom$I$S(this.natoms, symbol);
return atom;
});

Clazz.newMeth(C$, 'setAtomHydrogenCount$I$I',  function (atom, nh) {
var a=this.atoms[atom];
if (a.an == 32) {
a.label+="H";
if (nh > 1) a.label+=nh;
}});

Clazz.newMeth(C$, 'getHydrogenCount$I',  function (i) {
return this.atoms[i].nh;
});

Clazz.newMeth(C$, 'getCharge$I',  function (i) {
return this.atoms[i].q;
});

Clazz.newMeth(C$, 'getMaxAtomMap$',  function () {
if (this.natoms == 0) return 0;
var max=-999999;
for (var at=1; at <= this.natoms; at++) {
var map=this.atoms[at].getMap$();
if (map > max) max=map;
}
return max;
});

Clazz.newMeth(C$, 'resetAtomMaps$',  function () {
var hasChanged=false;
for (var at=1; at <= this.natoms; at++) {
hasChanged=this.atoms[at].resetMap$() || hasChanged ;
}
return hasChanged;
});

Clazz.newMeth(C$, 'has2Dcoordinates$',  function () {
if (this.natoms == 0) {
return true;
}if (this.has3Dcoordinates$()) {
return false;
}if (this.natoms == 2) {
return this.atoms[1].x != this.atoms[2].x  || this.atoms[1].y != this.atoms[2].y  ;
}for (var i=1; i <= this.natoms; i++) {
if (this.atoms[i].x != 0  || this.atoms[i].y != 0  ) {
return true;
}}
return false;
});

Clazz.newMeth(C$, 'has3Dcoordinates$',  function () {
if (this.nAtoms$() <= 1) {
return true;
}for (var at=1; at <= this.natoms; at++) {
if (Math.abs(this.z$I(at)) > 0.001 ) {
return true;
}}
return false;
});

Clazz.newMeth(C$, 'internalBondLengthScaling$',  function () {
var sumlen=0;
var scale=0;
var max=0;
var min=1.7976931348623157E308;
var refBondLength=25.0;
for (var i=1; i <= this.nbonds; i++) {
var b=this.bonds[i];
var d=this.distance$I$I(b.va, b.vb);
sumlen+=d;
if (d > max ) max=d;
if (d < min ) min=d;
}
if (sumlen == 0 ) return 0;
if (this.nbonds > 0) {
var average=sumlen / this.nbonds;
scale=(average - min < max - average  ? min : max);
scale=refBondLength / scale;
} else if (this.natoms > 1) {
scale=3 * refBondLength / this.distance$I$I(1, 2);
}this.scaleXY$D(scale);
this.setBondCenters$();
return refBondLength;
});

Clazz.newMeth(C$, 'centerX$',  function () {
var sum=0;
for (var i=1; i <= this.natoms; i++) {
sum+=this.x$I(i);
}
return (this.natoms > 0 ? sum / this.natoms : 0);
});

Clazz.newMeth(C$, 'centerY$',  function () {
var sum=0;
for (var i=1; i <= this.natoms; i++) {
sum+=this.y$I(i);
}
return (this.natoms > 0 ? sum / this.natoms : 0);
});

Clazz.newMeth(C$, 'closestAtomDistance$D$D',  function (xx, yy) {
var min=1.7976931348623157E308;
for (var i=1; i <= this.natoms; i++) {
var rx=C$.squareEuclideanDist$D$D$D$D(xx, yy, this.x$I(i), this.y$I(i));
if (rx < min ) {
min=rx;
}}
return Math.sqrt(min);
});

Clazz.newMeth(C$, 'checkNeedsCleaning$',  function () {
for (var i=this.natoms + 1; --i >= 1; ) {
var x=this.atoms[i].x;
var y=this.atoms[i].y;
for (var j=i; --j >= 1; ) {
var x2=this.atoms[j].x;
var y2=this.atoms[j].y;
if (Math.abs(x - x2) + Math.abs(y - y2) < 2 ) {
return true;
}}
}
return false;
});

Clazz.newMeth(C$, 'setAtomMapFromInput$I$I',  function (atomIndex, map) {
if (atomIndex > 0 && atomIndex <= this.nAtoms$() ) {
var atom=this.atoms[atomIndex];
atom.setMapOrMark$I$Z(map, !this.parameters.mark);
}return map;
});

Clazz.newMeth(C$, 'finalizeMolecule$',  function () {
this.setNeighborsFromBonds$();
this.deleteHydrogens$jme_core_JMECore_Parameters_HydrogenParams(this.parameters.hydrogenParams);
this.complete$Z(this.parameters.computeValenceState);
if (this.parameters.internalBondScalingForInput) {
this.internalBondLengthScaling$();
}});

Clazz.newMeth(C$, 'getSp2Other$I$I$Z',  function (ia, not, first) {
var a=this.atoms[ia];
if (first) {
for (var i=1; i <= a.nv; i++) {
if (a.v[i] != not && this.atoms[a.v[i]].an != 1 ) return a.v[i];
}
return 0;
}for (var i=a.nv + 1; --i >= 1; ) {
if (a.v[i] != not && this.atoms[a.v[i]].an != 1 ) return a.v[i];
}
return 0;
});

C$.$static$=function(){C$.$static$=0;
C$.DefaultParameters=Clazz.new_($I$(3,1));
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.JMECore, "Parameters", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});
C$.$classes$=[['SmilesParams',1],['HydrogenParams',1]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.smilesParams=Clazz.new_($I$(1,1),[this, null]);
this.hydrogenParams=Clazz.new_($I$(2,1),[this, null]);
this.computeValenceState=true;
this.ignoreStereo=false;
this.mark=false;
this.number=false;
this.showAtomMapNumberWithBackgroundColor=false;
this.internalBondScalingForInput=false;
this.keepSameCoordinatesForOutput=false;
},1);

C$.$fields$=[['Z',['computeValenceState','ignoreStereo','mark','number','showAtomMapNumberWithBackgroundColor','internalBondScalingForInput','keepSameCoordinatesForOutput'],'O',['smilesParams','jme.core.JMECore.Parameters.SmilesParams','hydrogenParams','jme.core.JMECore.Parameters.HydrogenParams']]]
;
(function(){/*c*/var C$=Clazz.newClass(P$.JMECore.Parameters, "SmilesParams", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.allowaromatic=true;
this.stereo=true;
this.canonize=true;
this.autoez=true;
this.allHs=false;
this.smarts=false;
this.star=false;
this.polarnitro=false;
},1);

C$.$fields$=[['Z',['allowaromatic','stereo','canonize','autoez','allHs','smarts','star','polarnitro']]]

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.JMECore.Parameters, "HydrogenParams", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.keepStereoHs=true;
this.keepMappedHs=true;
this.keepIsotopicHs=true;
this.removeHs=false;
this.removeOnlyCHs=false;
this.showHs=true;
},1);

C$.$fields$=[['Z',['keepStereoHs','keepMappedHs','keepIsotopicHs','removeHs','removeOnlyCHs','showHs']]]

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
