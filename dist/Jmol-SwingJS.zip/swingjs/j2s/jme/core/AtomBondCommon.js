(function(){var P$=Clazz.newPackage("jme.core"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "AtomBondCommon");

Clazz.newMeth(C$, 'resetChemicalObjectColors$jme_core_AtomBondCommonA',  function (chemicalObjects) {
for (var chemicalObject, $chemicalObject = 0, $$chemicalObject = chemicalObjects; $chemicalObject<$$chemicalObject.length&&((chemicalObject=($$chemicalObject[$chemicalObject])),1);$chemicalObject++) {
if (chemicalObject != null ) {
chemicalObject.resetBackgroundColors$();
}}
}, 1);

Clazz.newMeth(C$, 'growArray$IA$I',  function (array, newSize) {
var newArray=Clazz.array(Integer.TYPE, [newSize]);
System.arraycopy$O$I$O$I$I(array, 0, newArray, 0, array.length);
return newArray;
}, 1);

Clazz.newMeth(C$, 'copyArray$IA',  function (array) {
var copy=Clazz.array(Integer.TYPE, [array.length]);
System.arraycopy$O$I$O$I$I(array, 0, copy, 0, array.length);
return copy;
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
