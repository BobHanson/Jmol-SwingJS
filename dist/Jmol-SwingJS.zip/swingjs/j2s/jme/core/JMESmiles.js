(function(){var P$=Clazz.newPackage("jme.core"),p$1={},I$=[[0,'StringBuffer',['jme.core.JMECore','.Parameters'],'jme.core.Atom','jme.util.Isotopes']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JMESmiles", null, 'jme.core.JMECore');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.smartsMode=false;
this.smartsModeNoH=false;
},1);

C$.$fields$=[['Z',['doMark','isQuery','autoez','smartsMode','smartsModeNoH'],'O',['a','int[]','+btype']]]

Clazz.newMeth(C$, 'c$$jme_core_JMECore$I$Z',  function (mol, part, isQuery) {
;C$.superclazz.c$$jme_core_JMECore$I.apply(this,[mol, part]);C$.$init$.apply(this);
this.isQuery=isQuery;
}, 1);

Clazz.newMeth(C$, 'createSmilesWithSideEffect$jme_core_JMECore_Parameters',  function (mpars) {
if (this.natoms == 0) return "";
this.parameters=mpars;
this.doMark=mpars.mark;
this.autoez=mpars.smilesParams.autoez;
var con1=Clazz.array(Integer.TYPE, [this.natoms + 10]);
var con2=Clazz.array(Integer.TYPE, [this.natoms + 10]);
var branch=Clazz.array(Integer.TYPE, [this.natoms + 1]);
var candidate=Clazz.array(Integer.TYPE, [7]);
var parent=Clazz.array(Integer.TYPE, [this.natoms + 1]);
var isAromatic=Clazz.array(Boolean.TYPE, [this.natoms + 1]);
var isRingBond=Clazz.array(Boolean.TYPE, [this.nbonds + 1]);
var bondMinimumRingSize=Clazz.array(Integer.TYPE, [this.nbonds + 1]);
var nconnections=0;
if (mpars.smilesParams.canonize && !this.haveQueryOrCoordBonds$() ) {
this.smartsMode=mpars.smilesParams.smarts;
this.smartsModeNoH=this.smartsMode && !mpars.hydrogenParams.showHs ;
var pars=C$.setHydrogenParams$jme_core_JMECore_Parameters(mpars);
this.deleteHydrogens$jme_core_JMECore_Parameters_HydrogenParams(pars);
this.cleanPolarBonds$Z(mpars.smilesParams.polarnitro);
this.findRingBonds$IA(bondMinimumRingSize);
var allowAromatic=mpars.smilesParams.allowaromatic;
this.setBondTypes$ZA$IA$Z(isAromatic, bondMinimumRingSize, allowAromatic);
this.canonize$Z(mpars.computeValenceState);
this.setValenceState$();
this.findRingBonds$IA(bondMinimumRingSize);
this.setBondTypes$ZA$IA$Z(isAromatic, bondMinimumRingSize, allowAromatic);
} else {
this.findRingBonds$IA(bondMinimumRingSize);
this.btype=Clazz.array(Integer.TYPE, [this.nbonds + 1]);
for (var i=1; i <= this.nbonds; i++) this.btype[i]=this.bonds[i].bondType;

}for (var b=1; b <= this.nbonds; b++) {
isRingBond[b]=bondMinimumRingSize[b] > 0;
}
var atom=1;
this.a=Clazz.array(Integer.TYPE, [this.natoms + 1]);
var step=1;
this.a[atom]=step;
var nbranch=0;
while (true){
var ncandidates=0;
for (var i=1; i <= this.nv$I(atom); i++) {
var atomx=this.v$I(atom)[i];
if (this.a[atomx] > 0) {
if (this.a[atomx] > this.a[atom]) continue;
if (atomx == parent[atom]) continue;
var newcon=true;
for (var k=1; k <= nconnections; k++) if (con1[k] == atom && con2[k] == atomx  || con1[k] == atomx && con2[k] == atom  ) {
newcon=false;
break;
}
if (newcon) {
++nconnections;
con1[nconnections]=atom;
con2[nconnections]=atomx;
}} else candidate[++ncandidates]=atomx;
}
if (ncandidates == 0) {
if (step == this.natoms) break;
atom=branch[nbranch--];
} else if (ncandidates == 1) {
parent[candidate[1]]=atom;
atom=candidate[1];
this.a[atom]=++step;
} else {
branch[++nbranch]=atom;
var atomnew=0;
for (var i=1; i <= ncandidates; i++) {
var b=this.getBondIndex$I$I(candidate[i], atom);
if (isRingBond[b]) continue;
atomnew=candidate[i];
break;
}
if (atomnew == 0) {
for (var i=1; i <= ncandidates; i++) {
var b=this.getBondIndex$I$I(candidate[i], atom);
if (this.btype[b] == 2 || this.btype[b] == 3 ) {
atomnew=candidate[i];
break;
}}
}if (atomnew == 0) atomnew=candidate[1];
parent[atomnew]=atom;
atom=atomnew;
this.a[atom]=++step;
}}
parent=Clazz.array(Integer.TYPE, [this.natoms + 1]);
var aa=Clazz.array(Integer.TYPE, [this.natoms + 1]);
var leftBracket=Clazz.array(Boolean.TYPE, [this.natoms + 1]);
var rightBracket=Clazz.array(Boolean.TYPE, [this.natoms + 1]);
nbranch=0;
step=0;
var atomold=0;
for (var i=1; i <= this.natoms; i++) if (this.a[i] == 1) {
atom=i;
break;
}
 loopTwo : while (true){
if (atomold > 0) parent[atom]=atomold;
aa[++step]=atom;
this.a[atom]=0;
var atomnew;
var ncandidates;
while (true){
atomnew=0;
ncandidates=0;
var min=this.natoms + 1;
 cs1 : for (var i=1; i <= this.nv$I(atom); i++) {
var atomx=this.v$I(atom)[i];
for (var j=1; j <= nconnections; j++) if (con1[j] == atomx && con2[j] == atom  || con1[j] == atom && con2[j] == atomx  ) continue cs1;

if (this.a[atomx] > 0) {
++ncandidates;
if (this.a[atomx] < min) {
atomnew=atomx;
min=this.a[atomx];
}}}
if (atomnew == 0) {
if (nbranch == 0) break loopTwo;
rightBracket[atom]=true;
atom=branch[nbranch--];
} else break;
}
atomold=atom;
atom=atomnew;
if (ncandidates > 1) {
branch[++nbranch]=atomold;
leftBracket[atom]=true;
}}
var slashBond=Clazz.array(Integer.TYPE, [this.nbonds + 1]);
var stereo=Clazz.array(Integer.TYPE, [this.natoms + 1]);
if (mpars.smilesParams.stereo) p$1.smilesStereo$IA$IA$IA$IA$IA$IA$IA$I.apply(this, [aa, parent, slashBond, stereo, bondMinimumRingSize, con1, con2, nconnections]);
var queryMode=false;
var smiles=Clazz.new_($I$(1,1).c$$S,[""]);
var ax=Clazz.array(Integer.TYPE, [this.natoms + 1]);
for (var i=1; i <= this.natoms; i++) ax[aa[i]]=i;

for (var i=1; i <= this.natoms; i++) {
atom=aa[i];
if (leftBracket[atom]) smiles.append$S("(");
if (parent[i] > 0) p$1.smilesAddBond$I$I$StringBuffer$IA$Z.apply(this, [atom, parent[atom], smiles, slashBond, queryMode]);
p$1.smilesAddAtom$I$StringBuffer$Z$IA.apply(this, [atom, smiles, isAromatic[atom], stereo]);
for (var j=1; j <= nconnections; j++) {
if (con1[j] == atom || con2[j] == atom ) {
var atom2=con2[j];
if (atom2 == atom) atom2=con1[j];
if (ax[atom] < ax[atom2]) p$1.smilesAddBond$I$I$StringBuffer$IA$Z.apply(this, [con1[j], con2[j], smiles, slashBond, queryMode]);
if (j > 9) smiles.append$S("%");
smiles.append$S( new Integer(j).toString());
}}
if (rightBracket[atom]) smiles.append$S(")");
}
return smiles.toString();
});

Clazz.newMeth(C$, 'setHydrogenParams$jme_core_JMECore_Parameters',  function (mpars) {
var pars=Clazz.new_($I$(2,1)).hydrogenParams;
pars.keepStereoHs=!mpars.smilesParams.stereo;
pars.removeHs=!mpars.smilesParams.smarts;
pars.removeOnlyCHs=mpars.hydrogenParams.showHs && mpars.smilesParams.smarts ;
return pars;
}, 1);

Clazz.newMeth(C$, 'smilesAddAtom$I$StringBuffer$Z$IA',  function (at, smiles, isAromatic, stereo) {
var z="X";
var atom=this.atoms[at];
var iso=atom.iso;
var nh=atom.nh;
var q=atom.q;
var an=atom.an;
var map=this.findAtomMapForOutput$I(at);
var isMapped=(map != 0);
var bracket=(q != 0 || iso != 0  || stereo[at] != 0  || isMapped  || this.doMark && atom.backgroundColors[0] > 0   || !this.smartsModeNoH && this.smartsMode && nh > 0   && an != 3  );
switch (an) {
case 2:
z="B";
break;
case 3:
if (isAromatic) z="c";
 else z="C";
break;
case 4:
if (isAromatic) {
z="n";
if (nh > 0) bracket=true;
} else z="N";
break;
case 5:
if (isAromatic) z="o";
 else z="O";
break;
case 7:
if (isAromatic) {
z="p";
if (nh > 0) bracket=true;
} else z="P";
break;
case 8:
if (isAromatic) z="s";
 else z="S";
break;
case 13:
if (isAromatic) z="se";
 else z="Se";
bracket=true;
break;
case 6:
z="Si";
bracket=true;
break;
case 9:
z="F";
break;
case 10:
z="Cl";
break;
case 11:
z="Br";
break;
case 12:
z="I";
break;
case 1:
z="H";
bracket=true;
break;
case 32:
bracket=true;
z=atom.label;
if (z == null ) {
z="X";
}if ((!isMapped) && (z.equals$O("*") || z.equals$O("a") || z.equals$O("A")  ) ) bracket=false;
break;
}
if ($I$(3).chargedMetalType$I(an) > 0) {
z=$I$(3).zlabel[an];
bracket=true;
}if (an >= 33 && an <= 42 ) {
bracket=true;
z=$I$(3).zlabel[an];
}if (bracket) {
if (iso != 0) {
z="[" + iso + z ;
} else {
z="[" + z;
}if (stereo[at] == 1) z+="@";
 else if (stereo[at] == -1) z+="@@";
if (true) {
if (nh == 1) z+="H";
 else if (nh > 1) z+="H" + nh;
}if (q != 0) {
if (q > 0) z+="+";
 else z+="-";
if (Math.abs(q) > 1) z+=Math.abs(q);
}if (isMapped) z+=":" + map;
z+="]";
}smiles.append$S(z);
}, p$1);

Clazz.newMeth(C$, 'smilesAddBond$I$I$StringBuffer$IA$Z',  function (atom1, atom2, smiles, slashBond, queryMode) {
var b=this.getBondIndex$I$I(atom1, atom2);
var bond=this.bonds[b];
if (this.btype[b] != 5 && bond.isDouble$() ) smiles.append$S("=");
 else if (bond.isTriple$()) smiles.append$S("#");
 else if (bond.isQuery$()) {
var z="?";
var o=bond.btag;
if (o != null ) z=o;
smiles.append$S(z);
} else if (this.btype[b] == 5 && queryMode ) smiles.append$S(":");
 else if (bond.isCoordination$()) smiles.append$S("~");
 else if (slashBond[b] == 1) smiles.append$S("/");
 else if (slashBond[b] == -1) smiles.append$S("\\");
 else {
}}, p$1);

Clazz.newMeth(C$, 'smilesStereo$IA$IA$IA$IA$IA$IA$IA$I',  function (aa, parent, slashBond, stereo, bondMinimumRingSize, con1, con2, nconnections) {
var ax=Clazz.array(Integer.TYPE, [this.natoms + 1]);
for (var at=1; at <= this.natoms; at++) ax[aa[at]]=at;

var doneEZ=Clazz.array(Boolean.TYPE, [this.nbonds + 1]);
for (var i=1; i <= this.natoms; i++) {
var atom1=aa[i];
var atom2=parent[atom1];
var bi=this.getBondIndex$I$I(atom1, atom2);
if (bi == 0) continue;
p$1.stereoEZ$I$IA$IA$IA.apply(this, [bi, ax, slashBond, bondMinimumRingSize]);
doneEZ[bi]=true;
}
for (var i=1; i <= this.nbonds; i++) {
if (!doneEZ[i]) p$1.stereoEZ$I$IA$IA$IA.apply(this, [i, ax, slashBond, bondMinimumRingSize]);
}
doneEZ=null;
 atom_loop : for (var at=1; at <= this.natoms; at++) {
if (this.nv$I(at) < 2 || this.nv$I(at) > 4 ) continue;
var nstereo=0;
var doubleBonded=0;
for (var neighbor=1; neighbor <= this.nv$I(at); neighbor++) {
var bi=this.getBondIndex$I$I(at, this.v$I(at)[neighbor]);
if (this.btype[bi] == 5) continue atom_loop;
if (this.bonds[bi].bondType == 1 && C$.upDownBond$jme_core_Bond$I(this.bonds[bi], at) != 0 ) ++nstereo;
if (this.bonds[bi].bondType == 2) doubleBonded=this.v$I(at)[neighbor];
}
if (nstereo == 0) continue;
if (doubleBonded > 0) p$1.stereoAllene$I$IA$IA$IA$IA$IA$I.apply(this, [at, ax, stereo, parent, con1, con2, nconnections]);
 else p$1.stereoC4$I$IA$IA$IA$IA$I$IA.apply(this, [at, parent, ax, con1, con2, nconnections, stereo]);
}
}, p$1);

Clazz.newMeth(C$, 'stereoC4$I$IA$IA$IA$IA$I$IA',  function (atom, parent, ax, con1, con2, nconnections, stereo) {
var ref=Clazz.array(Integer.TYPE, [4]);
var refx=Clazz.array(Integer.TYPE, [4]);
p$1.identifyNeighbors$I$IA$IA$IA$IA$I$IA.apply(this, [atom, ax, parent, con1, con2, nconnections, ref]);
var nup=0;
var ndown=0;
var up=0;
var down=0;
var marked=0;
var nonmarked=0;
for (var i=0; i < 4; i++) {
if (ref[i] <= 0) continue;
var bi=this.getBondIndex$I$I(atom, ref[i]);
refx[i]=C$.upDownBond$jme_core_Bond$I(this.bonds[bi], atom);
if (refx[i] > 0) {
++nup;
up=ref[i];
marked=ref[i];
} else if (refx[i] < 0) {
++ndown;
down=ref[i];
marked=ref[i];
} else nonmarked=ref[i];
}
var nstereo=nup + ndown;
var ox;
var t=Clazz.array(Integer.TYPE, [4]);
var stereoRef=0;
if (this.atoms[atom].nv == 3) {
if ((nup == 1 && ndown == 1 ) || (nstereo == 3 && nup > 0  && ndown > 0 ) ) {
this.info$S("Error in C3H stereospecification !");
return;
}var refAtom=ref[0];
if (nstereo == 1) refAtom=marked;
 else if (nstereo == 2) refAtom=nonmarked;
ox=this.C4order$I$I$IA(atom, refAtom, ref);
t[0]=marked;
t[1]=-1;
t[2]=ox[2];
t[3]=ox[1];
if (nup > 0) stereoRef=1;
 else stereoRef=-1;
} else if (this.nv$I(atom) == 4) {
if (nstereo == 1) {
ox=this.C4order$I$I$IA(atom, marked, ref);
t[0]=ox[0];
t[1]=ox[3];
t[2]=ox[2];
t[3]=ox[1];
if (nup > 0) stereoRef=1;
 else stereoRef=-1;
} else {
var refAtom=ref[0];
if (nonmarked > 1) refAtom=nonmarked;
if (nup == 1) refAtom=up;
 else if (ndown == 1) refAtom=down;
ox=this.C4order$I$I$IA(atom, refAtom, ref);
var box=Clazz.array(Integer.TYPE, [4]);
for (var i=0; i < 4; i++) {
var bi=this.getBondIndex$I$I(atom, ox[i]);
box[i]=C$.upDownBond$jme_core_Bond$I(this.bonds[bi], atom);
}
if (nstereo == 4) {
if (nup == 0 || ndown == 0 ) {
this.info$S("Error in C4 stereospecification !");
return;
} else if (nup == 1 || ndown == 1 ) {
t[0]=ox[0];
t[1]=ox[3];
t[2]=ox[2];
t[3]=ox[1];
stereoRef=box[0];
} else {
for (var i=0; i < 4; i++) if (box[i] == -1) box[i]=0;

nstereo=2;
}} else if (nstereo == 3) {
if (nup == 3 || ndown == 3 ) {
t[0]=ox[0];
t[1]=ox[3];
t[2]=ox[2];
t[3]=ox[1];
if (nup > 0) stereoRef=-1;
 else stereoRef=1;
} else {
var d=0;
if (nup == 1) {
d=1;
nup=1;
} else {
d=-1;
ndown=-1;
}for (var i=0; i < 4; i++) if (box[i] == d) box[i]=0;

nstereo=2;
}}if (nstereo == 2) {
if (nup == 1 && ndown == 1 ) {
if (ox[1] == down) {
ox[1]=ox[2];
ox[2]=ox[3];
} else if (ox[2] == down) {
ox[2]=ox[3];
}t[0]=up;
t[1]=down;
t[2]=ox[2];
t[3]=ox[1];
stereoRef=1;
} else {
if ((box[0] == box[1]) || (box[1] == box[2]) ) {
this.info$S("Error in C4 stereospecification ! 2/0r");
return;
}if (box[0] != 0) {
t[0]=ox[0];
t[1]=ox[2];
t[2]=ox[1];
t[3]=ox[3];
} else {
t[0]=ox[1];
t[1]=ox[3];
t[2]=ox[2];
t[3]=ox[0];
}if (nup > 1) stereoRef=1;
 else stereoRef=-1;
}}}}C$.stereoTransformation$IA$IA(t, ref);
if (t[2] == ref[2]) stereo[atom]=1;
 else if (t[2] == ref[3]) stereo[atom]=-1;
 else this.info$S("Error in stereoprocessing ! - t30");
stereo[atom]*=stereoRef;
}, p$1);

Clazz.newMeth(C$, 'identifyNeighbors$I$IA$IA$IA$IA$I$IA',  function (atom, ax, parent, con1, con2, nconnections, ref) {
var nref=-1;
if (parent[atom] > 0) ref[++nref]=parent[atom];
for (var i=1; i <= nconnections; i++) {
if (con1[i] == atom) ref[++nref]=con2[i];
if (con2[i] == atom) ref[++nref]=con1[i];
}
for (var i=nref + 1; i < this.nv$I(atom); i++) {
var min=this.natoms + 1;
 jloop : for (var j=1; j <= this.nv$I(atom); j++) {
var atomx=this.v$I(atom)[j];
for (var k=0; k < i; k++) if (atomx == ref[k]) continue jloop;

if (ax[atomx] < min) {
min=ax[atomx];
ref[i]=atomx;
}}
}
if (parent[atom] == 0 && this.atoms[atom].nh > 0 ) {
ref[3]=ref[2];
ref[2]=ref[1];
ref[1]=ref[0];
ref[0]=-1;
System.out.println$S("stereowarning #7");
} else if (this.atoms[atom].nh > 0) {
ref[3]=ref[2];
ref[2]=ref[1];
ref[1]=-1;
}}, p$1);

Clazz.newMeth(C$, 'C4order$I$I$IA',  function (center, ref0, ref) {
var ox=Clazz.array(Integer.TYPE, [4]);
this.setCosSin$I$I(center, ref0);
var p=Clazz.array(Integer.TYPE, [4]);
for (var i=0; i < 4; i++) {
if (ref[i] == ref0 || ref[i] <= 0 ) continue;
if (p[1] == 0) {
p[1]=ref[i];
continue;
}if (p[2] == 0) {
p[2]=ref[i];
continue;
}if (p[3] == 0) {
p[3]=ref[i];
continue;
}}
var sin=Clazz.array(Double.TYPE, [4]);
var cos=Clazz.array(Double.TYPE, [4]);
for (var i=1; i <= 3; i++) {
if (i == 3 && p[3] == 0 ) continue;
this.setCosSin$I$I(center, p[i]);
cos[i]=this.temp[0];
sin[i]=this.temp[1];
}
var c12=C$.compareAngles$D$D$D$D(sin[1], cos[1], sin[2], cos[2]);
if (p[3] > 0) {
var c23=C$.compareAngles$D$D$D$D(sin[2], cos[2], sin[3], cos[3]);
var c13=C$.compareAngles$D$D$D$D(sin[1], cos[1], sin[3], cos[3]);
if (c12 > 0 && c23 > 0 ) {
ox[1]=p[1];
ox[2]=p[2];
ox[3]=p[3];
} else if (c13 > 0 && c23 < 0 ) {
ox[1]=p[1];
ox[2]=p[3];
ox[3]=p[2];
} else if (c12 < 0 && c13 > 0 ) {
ox[1]=p[2];
ox[2]=p[1];
ox[3]=p[3];
} else if (c23 > 0 && c13 < 0 ) {
ox[1]=p[2];
ox[2]=p[3];
ox[3]=p[1];
} else if (c13 < 0 && c12 > 0 ) {
ox[1]=p[3];
ox[2]=p[1];
ox[3]=p[2];
} else if (c23 < 0 && c12 < 0 ) {
ox[1]=p[3];
ox[2]=p[2];
ox[3]=p[1];
}} else {
if (c12 > 0) {
ox[1]=p[1];
ox[2]=p[2];
} else {
ox[1]=p[2];
ox[2]=p[1];
}var u12=p$1.angle$I$I$I.apply(this, [center, p[1], p[2]]);
var u23=p$1.angle$I$I$I.apply(this, [center, p[2], ref0]);
var u13=p$1.angle$I$I$I.apply(this, [center, p[1], ref0]);
if ((u12 + u23) < 3.141592653589793  || (u23 + u13) < 3.141592653589793   || (u12 + u13) < 3.141592653589793  ) {
if (u12 > u23  && u12 > u13  ) {
var o=ox[1];
ox[1]=ox[2];
ox[2]=o;
}}}ox[0]=ref0;
return ox;
});

Clazz.newMeth(C$, 'angle$I$I$I',  function (p1, p2, p3) {
var r12=this.distance$I$I(p1, p2);
var r13=this.distance$I$I(p1, p3);
var r23=this.distance$I$I(p2, p3);
return Math.acos((r12 * r12 + r13 * r13 - r23 * r23) / (2.0 * r12 * r13 ));
}, p$1);

Clazz.newMeth(C$, 'doubleBondNeighborsOfAtom1WithoutDoubleBondedAtom$I',  function (atom1) {
var neighbors=Clazz.array(Integer.TYPE, -1, [0, 0]);
for (var j=1, n=0; j <= this.nv$I(atom1); j++) {
var atomx=this.v$I(atom1)[j];
var bi=this.getBondIndex$I$I(atom1, atomx);
if (this.bondType$I(bi) == 2) continue;
neighbors[n++]=atomx;
}
return neighbors;
}, p$1);

Clazz.newMeth(C$, 'stereoEZ$I$IA$IA$IA',  function (bond, ax, slashBond, bondMinimumRingSize) {
if (this.bondType$I(bond) != 2 || this.btype[bond] == 5 ) return;
if (bondMinimumRingSize[bond] > 0 && bondMinimumRingSize[bond] <= 7 ) return;
if (!this.autoez && this.bonds[bond].stereo != 10 ) return;
if (this.bonds[bond].stereo == 10) return;
var atom1=this.bonds[bond].va;
var atom2=this.bonds[bond].vb;
if (this.atoms[atom1].isCumuleneSP$() && this.atoms[atom2].isCumuleneSP$() ) {
return;
}var cumuleneAtoms=null;
if (this.atoms[atom1].isCumuleneSP$()) {
cumuleneAtoms=p$1.findCumuleneChain$I.apply(this, [atom2]);
} else if (this.atoms[atom2].isCumuleneSP$()) {
cumuleneAtoms=p$1.findCumuleneChain$I.apply(this, [atom1]);
}if (cumuleneAtoms != null ) {
if ((cumuleneAtoms[0] - 1) % 2 == 1) {
atom1=cumuleneAtoms[1];
atom2=cumuleneAtoms[cumuleneAtoms[0]];
} else return;
}var a=Clazz.array(Integer.TYPE, -1, [atom1, atom2]);
for (var eachBondAtom, $eachBondAtom = 0, $$eachBondAtom = a; $eachBondAtom<$$eachBondAtom.length&&((eachBondAtom=($$eachBondAtom[$eachBondAtom])),1);$eachBondAtom++) {
var nv=this.nv$I(eachBondAtom);
if (nv < 2 || nv > 3 ) return;
}
if (ax[atom1] > ax[atom2]) {
var d=atom1;
atom1=atom2;
atom2=d;
}var neighbors=p$1.doubleBondNeighborsOfAtom1WithoutDoubleBondedAtom$I.apply(this, [atom1]);
var ref11=neighbors[0];
var ref12=neighbors[1];
var ref1=0;
var ref1x=false;
if (ref12 > 0 && ax[ref11] > ax[ref12] ) {
var d=ref11;
ref11=ref12;
ref12=d;
}var bi=this.getBondIndex$I$I(atom1, ref11);
if (slashBond[bi] != 0) {
ref1=ref11;
} else if (this.bondType$I(bi) == 1 && this.btype[bi] != 5 ) ref1=ref11;
if (ref1 == 0 && ref12 > 0 ) {
bi=this.getBondIndex$I$I(atom1, ref12);
if (slashBond[bi] != 0) ref1=ref12;
 else if (this.bondType$I(bi) == 1 && this.btype[bi] != 5 ) ref1=ref12;
}if (ax[ref1] > ax[atom1]) ref1x=true;
neighbors=p$1.doubleBondNeighborsOfAtom1WithoutDoubleBondedAtom$I.apply(this, [atom2]);
var ref21=neighbors[0];
var ref22=neighbors[1];
if (ref21 == 0 && ref22 == 0 ) {
return;
}var ref2=0;
if (ref22 > 0 && ax[ref21] < ax[ref22] ) {
var d=ref21;
ref21=ref22;
ref22=d;
}bi=this.getBondIndex$I$I(atom2, ref21);
if (this.bondType$I(bi) == 1 && this.btype[bi] != 5  && slashBond[bi] == 0 ) ref2=ref21;
if (ref2 == 0 && ref22 > 0 ) {
bi=this.getBondIndex$I$I(atom2, ref22);
if (this.bondType$I(bi) == 1 && this.btype[bi] != 5 ) ref2=ref22;
}if (ref1 == 0 || ref2 == 0 ) return;
this.setCosSin$I$I(atom1, atom2);
var y1=(this.y$I(ref1) - this.y$I(atom1)) * this.temp[0] - (this.x$I(ref1) - this.x$I(atom1)) * this.temp[1];
var y2=(this.y$I(ref2) - this.y$I(atom1)) * this.temp[0] - (this.x$I(ref2) - this.x$I(atom1)) * this.temp[1];
if (Math.abs(y1) < 2  || Math.abs(y2) < 2  ) {
this.info$S("Not unique E/Z geometry !");
return;
}var b1=this.getBondIndex$I$I(ref1, atom1);
var b2=this.getBondIndex$I$I(ref2, atom2);
var newSlash=1;
if (slashBond[b1] == 0) {
for (var j=1; j <= this.nv$I(ref1); j++) {
var atomx=this.v$I(ref1)[j];
if (atomx == atom1) continue;
bi=this.getBondIndex$I$I(ref1, atomx);
if (slashBond[bi] != 0) {
if (ax[atomx] > ax[ref1]) newSlash=-slashBond[bi];
 else newSlash=slashBond[bi];
break;
}}
slashBond[b1]=newSlash;
}if (slashBond[b2] != 0) {
System.err.println$S("E/Z internal error !");
return;
}if ((y1 > 0  && y2 > 0  ) || (y1 < 0  && y2 < 0  ) ) slashBond[b2]=-slashBond[b1];
 else slashBond[b2]=slashBond[b1];
if (ref1x) slashBond[b2]=-slashBond[b2];
}, p$1);

Clazz.newMeth(C$, 'upDownBond$jme_core_Bond$I',  function (bond, atom) {
var sb=bond.stereo;
if (sb == 0 || sb > 4 ) return 0;
if (sb == 1 && bond.va == atom ) return 1;
if (sb == 2 && bond.va == atom ) return -1;
if (sb == 3 && bond.vb == atom ) return 1;
if (sb == 4 && bond.vb == atom ) return -1;
return 0;
}, 1);

Clazz.newMeth(C$, 'findCumuleneChain$I',  function (startAtom) {
var numberCumuleneAtoms=1;
var currentCumuleneAtom=startAtom;
var cumuleneAtoms;
cumuleneAtoms=Clazz.array(Integer.TYPE, [this.natoms + 1]);
if (this.atoms[startAtom].isCumuleneSP$()) {
cumuleneAtoms[0]=0;
return cumuleneAtoms;
}cumuleneAtoms[1]=startAtom;
 FIND_CUMULENE_ATOM : while (true){
 NEIGHBOR_LOOP : for (var ni=1; ni <= this.nv$I(currentCumuleneAtom); ni++) {
var atomx=this.v$I(currentCumuleneAtom)[ni];
if (atomx == cumuleneAtoms[1] || atomx == cumuleneAtoms[numberCumuleneAtoms - 1] ) continue NEIGHBOR_LOOP;
var bi=this.getBondIndex$I$I(currentCumuleneAtom, atomx);
if (this.bonds[bi].bondType == 2 && this.btype[bi] != 5 ) {
cumuleneAtoms[++numberCumuleneAtoms]=atomx;
currentCumuleneAtom=atomx;
continue FIND_CUMULENE_ATOM;
}}
break FIND_CUMULENE_ATOM;
}
cumuleneAtoms[0]=numberCumuleneAtoms;
return cumuleneAtoms;
}, p$1);

Clazz.newMeth(C$, 'stereoAllene$I$IA$IA$IA$IA$IA$I',  function (ati, ax, stereo, parent, con1, con2, nconnections) {
var cumuleneAtoms=p$1.findCumuleneChain$I.apply(this, [ati]);
var numberCumuleneAtoms=cumuleneAtoms[0];
if (numberCumuleneAtoms % 2 == 0) return;
var start=cumuleneAtoms[1];
var center=cumuleneAtoms[((numberCumuleneAtoms + 1)/2|0)];
var end=cumuleneAtoms[numberCumuleneAtoms];
if (this.nv$I(end) < 2 || this.nv$I(end) > 3 ) return;
var ref11=0;
var ref12=0;
var ref21=0;
var ref22=0;
var ref1=0;
var ref2=0;
var ref1x=false;
var ref2x=false;
for (var ni=1; ni <= this.nv$I(start); ni++) {
var atomx=this.v$I(start)[ni];
if (atomx == cumuleneAtoms[2]) continue;
if (ref11 == 0) ref11=atomx;
 else ref12=atomx;
}
if (ax[ref12] > 0 && ax[ref11] > ax[ref12] ) {
var d=ref11;
ref11=ref12;
ref12=d;
}ref1=ref11;
if (ref1 == 0) {
ref1=ref12;
ref1x=true;
}for (var j=1; j <= this.nv$I(end); j++) {
var atomx=this.v$I(end)[j];
if (atomx == cumuleneAtoms[numberCumuleneAtoms - 1]) continue;
if (ref21 == 0) ref21=atomx;
 else ref22=atomx;
}
if (ax[ref22] > 0 && ax[ref21] > ax[ref22] ) {
var d=ref21;
ref21=ref22;
ref22=d;
}ref2=ref21;
if (ref2 == 0) {
ref2=ref22;
ref2x=true;
}var ref11x=ref11 > 0 ? C$.upDownBond$jme_core_Bond$I(this.bonds[this.getBondIndex$I$I(start, ref11)], start) : 0;
var ref12x=ref12 > 0 ? C$.upDownBond$jme_core_Bond$I(this.bonds[this.getBondIndex$I$I(start, ref12)], start) : 0;
var ref21x=ref21 > 0 ? C$.upDownBond$jme_core_Bond$I(this.bonds[this.getBondIndex$I$I(end, ref21)], end) : 0;
var ref22x=ref22 > 0 ? C$.upDownBond$jme_core_Bond$I(this.bonds[this.getBondIndex$I$I(end, ref22)], end) : 0;
if (Math.abs(ref11x + ref12x) > 1 || ref21x != 0  || ref22x != 0 ) {
this.info$S("Bad stereoinfo on allene !");
return;
}var atom2=cumuleneAtoms[numberCumuleneAtoms - 1];
this.setCosSin$I$I(end, atom2);
var y2=(this.y$I(ref2) - this.y$I(atom2)) * this.temp[0] - (this.x$I(ref2) - this.x$I(atom2)) * this.temp[1];
if (y2 > 0 ) stereo[center]=1;
 else stereo[center]=-1;
if (ref1x) stereo[center]*=-1;
if (ref2x) stereo[center]*=-1;
if (ref1 == ref11 && ref11x < 0 ) stereo[center]*=-1;
if (ref1 == ref12 && ref12x < 0 ) stereo[center]*=-1;
if (ax[ref1] > ax[ref2]) stereo[center]*=-1;
}, p$1);

Clazz.newMeth(C$, 'getSmiles$jme_core_JMECore$jme_core_JMECore_Parameters$Z',  function (deepCopy, pars, isQuery) {
var nparts=deepCopy.computeMultiPartIndices$();
var parts=Clazz.array(C$, [nparts]);
for (var part=1; part <= nparts; part++) {
parts[part - 1]=Clazz.new_(C$.c$$jme_core_JMECore$I$Z,[deepCopy, part, isQuery]);
}
var result="";
for (var p=0; p < parts.length; p++) {
var smiles=parts[p].createSmilesWithSideEffect$jme_core_JMECore_Parameters(pars);
if (result.length$() > 0) {
result+=".";
}result+=smiles;
parts[p]=null;
}
return result;
}, 1);

Clazz.newMeth(C$, 'findRingBonds$IA',  function (sizes) {
for (var i=1; i <= this.nbonds; i++) {
sizes[i]=this.minimumRingSize$jme_core_Bond(this.bonds[i]);
}
});

Clazz.newMeth(C$, 'isInRing$I$IA',  function (atom, minBondRingSizes) {
for (var i=1; i <= this.nv$I(atom); i++) {
if (minBondRingSizes[this.getBondIndex$I$I(atom, this.v$I(atom)[i])] > 0) return true;
}
return false;
});

Clazz.newMeth(C$, 'setBondTypes$ZA$IA$Z',  function (isAromatic, minBondRingSizes, allowAromatic) {
this.btype=Clazz.array(Integer.TYPE, [this.nbonds + 1]);
var pa=Clazz.array(Boolean.TYPE, [this.natoms + 1]);
if (allowAromatic) {
for (var i=1; i <= this.natoms; i++) {
pa[i]=false;
isAromatic[i]=false;
if (!this.isInRing$I$IA(i, minBondRingSizes)) continue;
if (this.nv$I(i) + this.atoms[i].nh > 3) continue;
switch (this.an$I(i)) {
case 3:
case 4:
case 7:
case 5:
case 8:
case 13:
pa[i]=true;
break;
case 32:
if (this.atoms[i].label.startsWith$S("A")) pa[i]=false;
 else pa[i]=true;
break;
}
}
}if (this.isQuery) this.doRingQueryCheck$ZA$IA(isAromatic, minBondRingSizes);
for (var b=1; b <= this.nbonds; b++) {
if (this.isSingle$I(b)) this.btype[b]=1;
 else if (this.isDouble$I(b)) this.btype[b]=2;
 else if (this.bonds[b].bondType == 3) this.btype[b]=3;
 else System.err.println$S("problems in findAromatic " + this.bonds[b].bondType);
}
 bondloop : for (var b=1; b <= this.nbonds; b++) {
if (minBondRingSizes[b] == 0) continue;
var atom1=this.bonds[b].va;
var atom2=this.bonds[b].vb;
if (!pa[atom1] || !pa[atom2] ) continue;
var a=Clazz.array(Boolean.TYPE, [this.natoms + 1]);
for (var i=1; i <= this.nv$I(atom1); i++) {
var atom=this.v$I(atom1)[i];
if (atom != atom2 && pa[atom] ) a[atom]=true;
}
var ok=false;
while (true){
for (var i=1; i <= this.natoms; i++) {
ok=false;
if (a[i] && pa[i] && i != atom1  ) {
for (var j=1; j <= this.nv$I(i); j++) {
var atom=this.v$I(i)[j];
if (atom == atom2) {
isAromatic[atom1]=true;
isAromatic[atom2]=true;
this.btype[b]=5;
continue bondloop;
}if (!a[atom] && pa[atom] ) {
a[atom]=true;
ok=true;
}}
}if (ok) break;
}
if (!ok) break;
}
}
});

Clazz.newMeth(C$, 'doRingQueryCheck$ZA$IA',  function (isAromatic, minBondRingSizes) {
var ra=Clazz.array(Boolean.TYPE, [this.natoms + 1]);
var doCheck=false;
for (var b=1; b <= this.nbonds; b++) {
var atom1=this.bonds[b].va;
var atom2=this.bonds[b].vb;
ra[atom1]=true;
ra[atom2]=true;
if (this.an$I(atom1) == 32 || this.an$I(atom2) == 32 ) doCheck=true;
}
if (!doCheck) return;
 bondloop1 : for (var b=1; b <= this.nbonds; b++) {
if (minBondRingSizes[b] == 0) continue;
var atom1=this.bonds[b].va;
var atom2=this.bonds[b].vb;
var a=Clazz.array(Boolean.TYPE, [this.natoms + 1]);
for (var i=1; i <= this.nv$I(atom1); i++) {
var atom=this.v$I(atom1)[i];
if (atom != atom2 && ra[atom] ) a[atom]=true;
}
var ok=false;
while (true){
for (var i=1; i <= this.natoms; i++) {
ok=false;
if (a[i] && ra[i] && i != atom1  ) {
for (var j=1; j <= this.nv$I(i); j++) {
var atom=this.v$I(i)[j];
if (atom == atom2) {
for (var k=1; k <= this.natoms; k++) {
if (!a[k]) continue;
if (this.an$I(k) == 5) {
this.AN$I$I(k, 32);
this.atoms[k].label="#8";
}if (this.an$I(k) == 4) {
this.AN$I$I(k, 32);
this.atoms[k].label="#7";
}if (this.an$I(k) == 8) {
this.AN$I$I(k, 32);
this.atoms[k].label="#16";
}}
continue bondloop1;
}if (!a[atom] && ra[atom] ) {
a[atom]=true;
ok=true;
}}
}if (ok) break;
}
if (!ok) break;
}
}
});

Clazz.newMeth(C$, 'canonize$Z',  function (computeValenceState) {
var ok;
var a=Clazz.array(Integer.TYPE, [this.natoms + 1]);
var aold=Clazz.array(Integer.TYPE, [this.natoms + 1]);
var d=Clazz.array(Long.TYPE, [this.natoms + 1]);
var prime=Clazz.array(Long.TYPE, [this.natoms + 2]);
prime=C$.generatePrimes$I(this.natoms);
for (var i=1; i <= this.natoms; i++) {
var atom=this.atoms[i];
var xbo=1;
for (var j=1; j <= this.nbonds; j++) {
if (this.bonds[j].va == i || this.bonds[j].vb == i ) {
xbo*=this.btype[j];
}}
var xan=this.an$I(i);
if (xan == 32) {
var zlabel=this.atoms[i].label;
if (zlabel != null  && zlabel.length$() > 0 ) {
var c1=(zlabel.charCodeAt$I(0)) - 65 + 1;
var c2=0;
if (zlabel.length$() > 1) c2=(zlabel.charCodeAt$I(1)) - 97;
if (c1 < 0) c1=0;
if (c2 < 0) c2=0;
xan=c1 * 28 + c2;
}}var qq=0;
if (this.q$I(i) != 0) {
if (this.q$I(i) < -2) qq=1;
 else if (this.q$I(i) == -2) qq=2;
 else if (this.q$I(i) == -1) qq=3;
 else if (this.q$I(i) == 1) qq=4;
 else if (this.q$I(i) == 2) qq=5;
 else if (this.q$I(i) > 2) qq=6;
}var deltaIso=0;
if (atom.iso != 0) {
deltaIso=$I$(4,"getDeltaIsotopicMassOfElement$S$I",[this.getAtomLabel$I(i), atom.iso]);
if (deltaIso < 0) {
deltaIso=10 - deltaIso;
}}var xx=126;
var dFactor=xbo;
dFactor+=this.atoms[i].nh * xx;
xx*=7;
dFactor+=qq * xx;
xx*=7;
if (deltaIso != 0) dFactor+=deltaIso * xx;
xx*=7;
dFactor+=xan * xx;
xx*=783;
dFactor+=this.nv$I(i) * xx;
d[i]=dFactor;
}
var breaklevel=0;
while (true){
if (this.canonsort$IA$JA(a, d)) break;
ok=false;
for (var i=1; i <= this.natoms; i++) if (a[i] != aold[i]) {
aold[i]=a[i];
ok=true;
}
if (ok) {
for (var i=1; i <= this.natoms; i++) {
d[i]=1;
for (var j=1; j <= this.nv$I(i); j++) (d[i]=Long.$mul(d[i],(prime[a[this.v$I(i)[j]]])));

}
breaklevel=0;
} else {
if (breaklevel > 0) {
for (var i=1; i <= this.natoms; i++) d[i]=1;

 bd : for (var i=1; i <= this.natoms - 1; i++) for (var j=i + 1; j <= this.natoms; j++) if (a[i] == a[j]) {
d[i]=2;
break bd;
}

} else {
for (var i=1; i <= this.natoms; i++) {
d[i]=1;
for (var j=1; j <= this.nv$I(i); j++) {
var atom=this.v$I(i)[j];
(d[i]=Long.$mul(d[i],(this.an$I(atom) * this.btype[this.getBondIndex$I$I(i, atom)])));
}
}
breaklevel=1;
}}this.canonsort$IA$JA(a, d);
for (var i=1; i <= this.natoms; i++) d[i]=aold[i] * this.natoms + a[i];

}
for (var i=1; i <= this.natoms; i++) aold[i]=a[i];

for (var s=1; s <= this.natoms; s++) {
for (var i=1; i <= this.natoms; i++) {
if (aold[i] == s) {
C$.swap$jme_core_AtomBondCommonA$I$I(this.atoms, i, s);
aold[i]=aold[s];
aold[s]=s;
break;
}}
}
for (var i=1; i <= this.nbonds; i++) {
this.bonds[i].va=a[this.bonds[i].va];
this.bonds[i].vb=a[this.bonds[i].vb];
if (this.bonds[i].va > this.bonds[i].vb) {
var du=this.bonds[i].va;
this.bonds[i].va=this.bonds[i].vb;
this.bonds[i].vb=du;
if (this.bonds[i].stereo == 1) this.bonds[i].stereo=3;
 else if (this.bonds[i].stereo == 2) this.bonds[i].stereo=4;
 else if (this.bonds[i].stereo == 3) this.bonds[i].stereo=1;
 else if (this.bonds[i].stereo == 4) this.bonds[i].stereo=2;
}}
for (var i=1; i < this.nbonds; i++) {
var minva=this.natoms;
var minvb=this.natoms;
var b=0;
for (var j=i; j <= this.nbonds; j++) {
if (this.bonds[j].va < minva) {
minva=this.bonds[j].va;
minvb=this.bonds[j].vb;
b=j;
} else if (this.bonds[j].va == minva && this.bonds[j].vb < minvb ) {
minvb=this.bonds[j].vb;
b=j;
}}
C$.swap$jme_core_AtomBondCommonA$I$I(this.bonds, i, b);
}
this.complete$Z(computeValenceState);
});

Clazz.newMeth(C$, 'swap$jme_core_AtomBondCommonA$I$I',  function (array, i, j) {
var temp=array[j];
array[j]=array[i];
array[i]=temp;
}, 1);

Clazz.newMeth(C$, 'canonsort$IA$JA',  function (a, d) {
var min=0;
var nth=0;
var ndone=0;
while (true){
++nth;
for (var i=1; i <= this.natoms; i++) if (Long.$gt(d[i],0 )) {
min=d[i];
break;
}
for (var i=1; i <= this.natoms; i++) if (Long.$gt(d[i],0 ) && Long.$lt(d[i],min ) ) min=d[i];

for (var i=1; i <= this.natoms; i++) if (Long.$eq(d[i],min )) {
a[i]=nth;
d[i]=0;
++ndone;
}
if (ndone == this.natoms) break;
}
if (nth == this.natoms) return true;
 else return false;
});

Clazz.newMeth(C$, 'generatePrimes$I',  function (n) {
var npn;
var pn=Clazz.array(Long.TYPE, [n + 2]);
var prime=Clazz.array(Integer.TYPE, [100]);
var test=5;
var index=0;
var num=0;
var check=true;
prime[0]=3;
pn[1]=2;
pn[2]=3;
npn=2;
if (n < 3) return pn;
while (test < (prime[num] * prime[num])){
index=0;
check=true;
while (check == true  && index <= num  && test >= (prime[index] * prime[index]) ){
if (test % prime[index] == 0) check=false;
 else ++index;
}
if (check == true ) {
pn[++npn]=test;
if (npn >= n) return pn;
if (num < (prime.length - 1)) {
++num;
prime[num]=test;
}}test+=2;
}
System.err.println$S("ERROR - Prime Number generator failed !");
return pn;
}, 1);

Clazz.newMeth(C$, 'stereoTransformation$IA$IA',  function (t, ref) {
var d=0;
if (ref[0] == t[1]) {
d=t[0];
t[0]=t[1];
t[1]=d;
d=t[2];
t[2]=t[3];
t[3]=d;
} else if (ref[0] == t[2]) {
d=t[2];
t[2]=t[0];
t[0]=d;
d=t[1];
t[1]=t[3];
t[3]=d;
} else if (ref[0] == t[3]) {
d=t[3];
t[3]=t[0];
t[0]=d;
d=t[1];
t[1]=t[2];
t[2]=d;
}if (ref[1] == t[2]) {
d=t[1];
t[1]=t[2];
t[2]=d;
d=t[2];
t[2]=t[3];
t[3]=d;
} else if (ref[1] == t[3]) {
d=t[1];
t[1]=t[3];
t[3]=d;
d=t[2];
t[2]=t[3];
t[3]=d;
}}, 1);

Clazz.newMeth(C$, 'compareAngles$D$D$D$D',  function (sina, cosa, sinb, cosb) {
var qa=0;
var qb=0;
if (sina >= 0.0  && cosa >= 0.0  ) qa=1;
 else if (sina >= 0.0  && cosa < 0.0  ) qa=2;
 else if (sina < 0.0  && cosa < 0.0  ) qa=3;
 else if (sina < 0.0  && cosa >= 0.0  ) qa=4;
if (sinb >= 0.0  && cosb >= 0.0  ) qb=1;
 else if (sinb >= 0.0  && cosb < 0.0  ) qb=2;
 else if (sinb < 0.0  && cosb < 0.0  ) qb=3;
 else if (sinb < 0.0  && cosb >= 0.0  ) qb=4;
if (qa < qb) return 1;
 else if (qa > qb) return -1;
switch (qa) {
case 1:
case 4:
if (sina < sinb ) return 1;
 else return -1;
case 2:
case 3:
if (sina > sinb ) return 1;
 else return -1;
}
System.err.println$S("stereowarning #31");
return 0;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
