(function(){var P$=Clazz.newPackage("jme.core"),I$=[[0,'jme.core.AtomBondCommon']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Bond", null, null, 'jme.core.AtomBondCommon');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.bondType=1;
this.guideX=NaN;
this.mark=-99199;
},1);

C$.$fields$=[['Z',['smallRing'],'D',['centerX','centerY','guideX','guideY'],'I',['va','vb','bondType','stereo','partIndex','mark'],'S',['btag'],'O',['backgroundColors','int[]']]]

Clazz.newMeth(C$, 'setBondType$I',  function (type) {
this.bondType=type;
});

Clazz.newMeth(C$, 'getBondType$',  function () {
return this.bondType;
});

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.resetBackgroundColors$();
}, 1);

Clazz.newMeth(C$, 'deepCopy$',  function () {
return this.copyTo$jme_core_Bond(Clazz.new_(C$));
});

Clazz.newMeth(C$, 'copyTo$jme_core_Bond',  function (b) {
b.backgroundColors=$I$(1).copyArray$IA(this.backgroundColors);
b.mark=this.mark;
b.va=this.va;
b.vb=this.vb;
b.bondType=this.bondType;
b.smallRing=this.smallRing;
b.stereo=this.stereo;
b.btag=this.btag;
b.centerX=this.centerX;
b.centerY=this.centerY;
b.guideX=this.guideX;
b.guideY=this.guideY;
b.partIndex=this.partIndex;
return b;
});

Clazz.newMeth(C$, 'convertBondType$I',  function (bondType) {
var result=null;
switch (bondType) {
case 1:
result="single";
break;
case 2:
result="double";
break;
case 3:
result="triple";
break;
case 5:
result="aromatic";
break;
case 0:
result="coordination";
break;
case 9:
result="query";
break;
}
return result;
}, 1);

Clazz.newMeth(C$, 'convertBondStereo$I',  function (stereo) {
var result=null;
switch (stereo) {
case 2:
case 4:
result="down";
break;
case 1:
case 3:
result="up";
break;
case 5:
case 6:
result="either";
break;
case 10:
result="either";
break;
}
return result;
}, 1);

Clazz.newMeth(C$, 'is$jme_core_Bond',  function (b) {
return (this.va == b.va && this.vb == b.vb  || this.va == b.vb && this.vb == b.va  );
});

Clazz.newMeth(C$, 'isAB$I$I',  function (atom1, atom2) {
return (this.va == atom1 && this.vb == atom2  || this.va == atom2 && this.vb == atom1  );
});

Clazz.newMeth(C$, 'isSingle$',  function () {
return this.bondType == 1;
});

Clazz.newMeth(C$, 'isDouble$',  function () {
return this.bondType == 2;
});

Clazz.newMeth(C$, 'isTriple$',  function () {
return this.bondType == 3;
});

Clazz.newMeth(C$, 'toggleNormalCrossedDoubleBond$',  function () {
if (this.isDouble$()) {
this.stereo=(this.smallRing ? 0 : 10 - this.stereo);
}});

Clazz.newMeth(C$, 'isCoordination$',  function () {
return this.bondType == 0;
});

Clazz.newMeth(C$, 'setCoordination$Boolean',  function (yesOrNo) {
this.bondType=yesOrNo.booleanValue$() ? 0 : 1;
return this;
});

Clazz.newMeth(C$, 'isQuery$',  function () {
return this.bondType == 9;
});

Clazz.newMeth(C$, 'toggleCoordination$',  function () {
return this.setCoordination$Boolean(Boolean.valueOf$Z(!this.isCoordination$()));
});

Clazz.newMeth(C$, 'resetObjectMark$',  function () {
var hasChanged=this.backgroundColors[0] != -99199;
this.resetBackgroundColors$();
;return hasChanged;
});

Clazz.newMeth(C$, 'addBackgroundColor$I',  function (c) {
for (var i=0; i < this.backgroundColors.length; i++) {
if (this.backgroundColors[i] == c) {
return;
}}
this.backgroundColors=$I$(1).growArray$IA$I(this.backgroundColors, this.backgroundColors.length + 1);
this.backgroundColors[this.backgroundColors.length - 1]=c;
});

Clazz.newMeth(C$, 'resetBackgroundColors$',  function () {
this.backgroundColors=Clazz.array(Integer.TYPE, -1, [-99199]);
});

Clazz.newMeth(C$, 'getBackgroundColors$',  function () {
return this.backgroundColors;
});

Clazz.newMeth(C$, 'resetMark$',  function () {
if (this.mark == -99199) return false;
this.mark=-99199;
return true;
});

Clazz.newMeth(C$, 'getMark$',  function () {
return Math.max(this.mark, 0);
});

Clazz.newMeth(C$, 'setMark$I',  function (mark) {
this.mark=mark;
});

Clazz.newMeth(C$, 'isMarked$',  function () {
return this.mark > 0;
});

Clazz.newMeth(C$, 'checkSmallRing$',  function () {
if (this.smallRing) {
if (this.bondType == 3) this.bondType=1;
 else if (this.bondType == 2 && this.stereo == 10 ) this.stereo=0;
}});

Clazz.newMeth(C$, 'toString',  function () {
return "[Bond " + this.va + " " + this.vb + " " + this.bondType + "]" ;
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
