(function(){var P$=Clazz.newPackage("jme.core"),I$=[[0,'java.util.regex.Pattern','jme.core.AtomBondCommon','jme.util.Isotopes']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Atom", null, null, 'jme.core.AtomBondCommon');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.map=-99199;
this.mark=-99199;
this.q=0;
this.v=Clazz.array(Integer.TYPE, [7]);
this.an=3;
this.nh=0;
},1);

C$.$fields$=[['Z',['deleteFlag'],'D',['x','y','z'],'I',['map','mark','iso','q','partIndex','nv','an','nh','sbo'],'S',['label','atag'],'O',['backgroundColors','int[]','+v']]
,['O',['zlabel','String[]','atomicSymbolPattern','java.util.regex.Pattern','+atomicSymbolPatternIsotopAndCharge']]]

Clazz.newMeth(C$, 'chargedMetalType$I',  function (an) {
if (an >= 14 && an <= 20 ) return 1;
if (an >= 21 && an <= 28 ) return 2;
if (an >= 29 && an <= 31 ) return 3;
return 0;
}, 1);

Clazz.newMeth(C$, 'atomicData$',  function () {
C$.zlabel[32]="X";
C$.zlabel[1]="H";
C$.zlabel[2]="B";
C$.zlabel[3]="C";
C$.zlabel[4]="N";
C$.zlabel[5]="O";
C$.zlabel[9]="F";
C$.zlabel[10]="Cl";
C$.zlabel[11]="Br";
C$.zlabel[12]="I";
C$.zlabel[8]="S";
C$.zlabel[7]="P";
C$.zlabel[6]="Si";
C$.zlabel[13]="Se";
C$.zlabel[32]="X";
C$.zlabel[14]="K";
C$.zlabel[16]="Li";
C$.zlabel[15]="Na";
C$.zlabel[17]="Rb";
C$.zlabel[18]="Cs";
C$.zlabel[19]="Fr";
C$.zlabel[20]="Ag";
C$.zlabel[21]="Mg";
C$.zlabel[22]="Ca";
C$.zlabel[24]="Sr";
C$.zlabel[23]="Ba";
C$.zlabel[25]="Zn";
C$.zlabel[26]="Ni";
C$.zlabel[27]="Cu";
C$.zlabel[28]="Cd";
C$.zlabel[29]="Al";
C$.zlabel[30]="Ga";
C$.zlabel[31]="Au";
for (var i=33; i <= 42; i++) {
C$.zlabel[i]="R" + (i > 33 ? Integer.valueOf$I((i - 33)) : "");
}
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.resetBackgroundColors$();
}, 1);

Clazz.newMeth(C$, 'deepCopy$',  function () {
return this.copyTo$jme_core_Atom(Clazz.new_(C$));
});

Clazz.newMeth(C$, 'copyTo$jme_core_Atom',  function (a) {
a.backgroundColors=$I$(2).copyArray$IA(this.backgroundColors);
a.mark=this.mark;
a.map=this.map;
a.iso=this.iso;
a.x=this.x;
a.y=this.y;
a.z=this.z;
a.q=this.q;
a.label=this.label;
a.v=$I$(2).copyArray$IA(this.v);
a.nv=this.nv;
a.an=this.an;
a.atag=this.atag;
a.nh=this.nh;
a.sbo=this.sbo;
a.partIndex=this.partIndex;
a.deleteFlag=this.deleteFlag;
return a;
});

Clazz.newMeth(C$, 'addNeighbor$I',  function (neighbor) {
if (this.nv < 6) {
++this.nv;
this.v[this.nv]=neighbor;
}});

Clazz.newMeth(C$, 'hasBeenMapped$',  function () {
return this.map != -99199;
});

Clazz.newMeth(C$, 'resetObjectMark$',  function () {
return this.resetMap$();
});

Clazz.newMeth(C$, 'resetMap$',  function () {
var hasChanged=this.hasBeenMapped$();
this.map=-99199;
return hasChanged;
});

Clazz.newMeth(C$, 'getMap$',  function () {
return this.hasBeenMapped$() ? this.map : 0;
});

Clazz.newMeth(C$, 'getMapOrMark$Z',  function (isMap) {
return isMap ? this.getMap$() : this.getMark$();
});

Clazz.newMeth(C$, 'setMapOrMark$I$Z',  function (m, isMap) {
if (isMap) this.setMap$I(m);
 else this.setMark$I(m);
});

Clazz.newMeth(C$, 'setMap$I',  function (map) {
this.map=map;
});

Clazz.newMeth(C$, 'isMapped$',  function () {
return this.getMap$() != 0;
});

Clazz.newMeth(C$, 'isMappedOrMarked$',  function () {
return this.isMapped$() || this.getMark$() != 0 ;
});

Clazz.newMeth(C$, 'isCumuleneSP$',  function () {
return this.sbo >= 4 && this.nv == 2 ;
});

Clazz.newMeth(C$, 'moveXY$D$D',  function (dx, dy) {
this.x+=dx;
this.y+=dy;
});

Clazz.newMeth(C$, 'scaleXY$D',  function (scale) {
this.x*=scale;
this.y*=scale;
});

Clazz.newMeth(C$, 'XY$D$D',  function (x, y) {
this.x=x;
this.y=y;
});

Clazz.newMeth(C$, 'iso$',  function () {
return this.iso;
});

Clazz.newMeth(C$, 'q$',  function () {
return this.q;
});

Clazz.newMeth(C$, 'Q$I',  function (charge) {
this.q=charge;
});

Clazz.newMeth(C$, 'incrQ$I',  function (incr) {
this.q+=incr;
});

Clazz.newMeth(C$, 'squareDistance$jme_core_Atom',  function (other) {
return Math.pow(this.x - other.x, 2) + Math.pow(this.y - other.y, 2);
});

Clazz.newMeth(C$, 'hasCloseContactWith$jme_core_Atom$D',  function (other, minDistance) {
var dist=this.squareDistance$jme_core_Atom(other);
return dist < Math.pow(minDistance, 2) ;
});

Clazz.newMeth(C$, 'parseAtomSymbolIsotop$S',  function (symbol) {
this.iso=0;
var m=C$.atomicSymbolPattern.matcher$CharSequence(symbol);
if (m.find$()) {
var isomass=Integer.parseInt$S(m.group$I(1));
var element=m.group$I(2);
if ($I$(3).isKnown$S$I(element, isomass)) {
this.iso=isomass;
symbol=element + m.group$I(3);
}}return symbol;
});

Clazz.newMeth(C$, 'parseAtomicSymbolPatternIsotopMappAndCharge$S$jme_core_JMECore_Parameters',  function (symbol, parameters) {
var m=C$.atomicSymbolPatternIsotopAndCharge.matcher$CharSequence(symbol);
if (m.find$()) {
var iso=m.group$I(1);
var element=m.group$I(2);
var hCount=m.group$I(3);
var hCountNumber=m.group$I(4);
var chargeNumber=m.group$I(6);
var chargeSign=m.group$I(5);
var multiCharge=m.group$I(7);
var query=m.group$I(8);
var atomMap=m.group$I(10);
var charge=0;
var isValid=true;
if ($I$(3).getNaturalMass$S(element) != -1) {
if (iso != null  && iso.length$() > 0 ) {
var isomass=Integer.parseInt$S(iso);
if ($I$(3).isKnown$S$I(element, isomass)) {
this.iso=isomass;
} else {
isValid=false;
}}} else {
isValid=false;
}if (isValid) {
var hasChargeSign=chargeSign != null  && chargeSign.length$() > 0 ;
var hasChargeNumber=chargeNumber != null  && chargeNumber.length$() > 0 ;
var hasMultiCharge=multiCharge != null  && multiCharge.length$() > 0 ;
if (hasChargeSign || hasChargeNumber ) {
charge=1;
if (hasChargeNumber) {
charge=Integer.parseInt$S(chargeNumber);
}charge*=chargeSign.equals$O("-") ? -1 : 1;
} else if (hasMultiCharge) {
charge=multiCharge.length$();
charge*=multiCharge.equals$O("-") ? -1 : 1;
}}if (isValid) {
symbol=element + (query != null  ? query : "");
this.q=charge;
}if (atomMap != null  && atomMap.length$() > 0 ) {
try {
var map=Integer.parseInt$S(atomMap);
if (map > 0) {
if (parameters.mark) {
this.setMark$I(map);
}if (parameters.number) {
this.setMap$I(map);
}}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}if (hCount != null ) {
this.nh=1;
if (hCountNumber != null  && hCountNumber.length$() > 0 ) this.nh=Integer.parseInt$S(hCountNumber);
}}return symbol;
});

Clazz.newMeth(C$, 'getLabel$',  function () {
return (this.an == 32 ? this.label : C$.zlabel[this.an]);
});

Clazz.newMeth(C$, 'addBackgroundColor$I',  function (c) {
for (var i=0; i < this.backgroundColors.length; i++) {
if (this.backgroundColors[i] == c) {
return;
};}
this.backgroundColors=$I$(2).growArray$IA$I(this.backgroundColors, this.backgroundColors.length + 1);
this.backgroundColors[this.backgroundColors.length - 1]=c;
});

Clazz.newMeth(C$, 'resetBackgroundColors$',  function () {
this.backgroundColors=Clazz.array(Integer.TYPE, -1, [-99199]);
});

Clazz.newMeth(C$, 'resetMark$',  function () {
if (this.mark == -99199) return false;
this.mark=-99199;
return true;
});

Clazz.newMeth(C$, 'getMark$',  function () {
return Math.max(this.mark, 0);
});

Clazz.newMeth(C$, 'setMark$I',  function (markOrMap) {
this.mark=markOrMap;
});

Clazz.newMeth(C$, 'isMarked$',  function () {
return this.mark > 0;
});

Clazz.newMeth(C$, 'toString',  function () {
return "[Atom " + this.getLabel$() + " " + new Double(this.x).toString() + " " + new Double(this.y).toString() + "]" ;
});

Clazz.newMeth(C$, 'getBackgroundColors$',  function () {
return this.backgroundColors;
});

Clazz.newMeth(C$, 'checkAtomicSymbol$S',  function (s) {
for (var an=1; an < C$.zlabel.length; an++) {
if (s.equals$O(C$.zlabel[an])) return an;
}
return 32;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.zlabel=Clazz.array(String, [43]);
{
C$.atomicData$();
};
C$.atomicSymbolPattern=$I$(1,"compile$S",["^(\\d+)([A-Z][a-z]?)(\\b.*)"]);
C$.atomicSymbolPatternIsotopAndCharge=$I$(1,"compile$S",["^(\\d+)?\\s*([A-Z][a-z]?)\\s*(H(\\d*))?(?:(?:([+-])(\\d*))|((?:\\++)|(?:-+)))?([^:+-]+?([,;#!])?[^:+-]+?)?(?::(\\d+))?$"]);
};
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
