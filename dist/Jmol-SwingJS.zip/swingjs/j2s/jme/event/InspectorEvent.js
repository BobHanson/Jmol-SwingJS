(function(){var P$=Clazz.newPackage("jme.event"),I$=[[0,'javax.swing.SwingUtilities','jme.JME','jme.event.ChangeAtomPropertyCallback','jme.gui.AtomInspector']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InspectorEvent", null, null, 'java.awt.event.ActionListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['atomIndex','bondIndex','molIndex','x','y'],'O',['jme','jme.JME','mol','jme.JMEmol']]]

Clazz.newMeth(C$, 'c$$jme_JME',  function (jme) {
;C$.$init$.apply(this);
this.jme=jme;
}, 1);

Clazz.newMeth(C$, 'reset$',  function () {
this.mol=null;
this.molIndex=this.atomIndex=this.bondIndex=this.x=this.y=0;
});

Clazz.newMeth(C$, 'getAtomMap$',  function () {
return this.mol.findAtomMapForOutput$I(this.atomIndex);
});

Clazz.newMeth(C$, 'getAtomCharge$',  function () {
return this.mol.findAtomChargeForOutput$I(this.atomIndex);
});

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
$I$(1,"invokeLater$Runnable",[((P$.InspectorEvent$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "InspectorEvent$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'run$',  function () /*block*/{
var change=null;
if (this.$finals$.e.getActionCommand$.apply(this.$finals$.e, []) == $I$(2).changeAtomMapAction || this.$finals$.e.getActionCommand$.apply(this.$finals$.e, []) == $I$(2).changeAtomMarkAction ) {
var actionType=this.$finals$.e.getActionCommand$.apply(this.$finals$.e, []) == $I$(2).changeAtomMapAction ? "map" : "mark";
change=((P$.InspectorEvent$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "InspectorEvent$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('jme.event.ChangeAtomPropertyCallback'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'setAtomValue$I',  function (newValue) {
this.b$['jme.event.InspectorEvent'].changeAtomMap$I.apply(this.b$['jme.event.InspectorEvent'], [newValue]);
});

Clazz.newMeth(C$, 'getAtomValue$',  function () {
return this.b$['jme.event.InspectorEvent'].getAtomMap$.apply(this.b$['jme.event.InspectorEvent'], []);
});

Clazz.newMeth(C$, 'actionType$',  function () {
return this.$finals$.actionType;
});

Clazz.newMeth(C$, 'reportError$S',  function (errorMessage) {
this.b$['jme.event.InspectorEvent'].showError$S.apply(this.b$['jme.event.InspectorEvent'], [errorMessage]);
});

Clazz.newMeth(C$, 'finished$',  function () {
this.b$['jme.event.InspectorEvent'].jme.setAtomToHighLight$I$I.apply(this.b$['jme.event.InspectorEvent'].jme, [this.b$['jme.event.InspectorEvent'].molIndex, 0]);
this.b$['jme.event.InspectorEvent'].jme.requestFocusInWindow$.apply(this.b$['jme.event.InspectorEvent'].jme, []);
});
})()
), Clazz.new_($I$(3,1),[this, {actionType:actionType}],P$.InspectorEvent$1));
} else if (this.$finals$.e.getActionCommand$.apply(this.$finals$.e, []) == $I$(2).changeAtomChargeAction) {
var actionType="charge";
change=((P$.InspectorEvent$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "InspectorEvent$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('jme.event.ChangeAtomPropertyCallback'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'setAtomValue$I',  function (newValue) {
this.b$['jme.event.InspectorEvent'].changeAtomCharge$I.apply(this.b$['jme.event.InspectorEvent'], [newValue]);
});

Clazz.newMeth(C$, 'getAtomValue$',  function () {
return this.b$['jme.event.InspectorEvent'].getAtomCharge$.apply(this.b$['jme.event.InspectorEvent'], []);
});

Clazz.newMeth(C$, 'actionType$',  function () {
return "charge";
});

Clazz.newMeth(C$, 'reportError$S',  function (errorMessage) {
this.b$['jme.event.InspectorEvent'].showError$S.apply(this.b$['jme.event.InspectorEvent'], [errorMessage]);
});

Clazz.newMeth(C$, 'finished$',  function () {
this.b$['jme.event.InspectorEvent'].jme.setAtomToHighLight$I$I.apply(this.b$['jme.event.InspectorEvent'].jme, [this.b$['jme.event.InspectorEvent'].molIndex, 0]);
this.b$['jme.event.InspectorEvent'].jme.requestFocusInWindow$.apply(this.b$['jme.event.InspectorEvent'].jme, []);
});
})()
), Clazz.new_($I$(3,1),[this, null],P$.InspectorEvent$2));
}if (change != null ) {
change.atomSymbol=this.b$['jme.event.InspectorEvent'].mol.getAtomLabel$I.apply(this.b$['jme.event.InspectorEvent'].mol, [this.b$['jme.event.InspectorEvent'].atomIndex]);
var atomInspector=Clazz.new_($I$(4,1).c$$jme_event_ChangeAtomPropertyCallback,[change]);
this.b$['jme.event.InspectorEvent'].jme.setAtomToHighLight$I$I.apply(this.b$['jme.event.InspectorEvent'].jme, [this.b$['jme.event.InspectorEvent'].molIndex, this.b$['jme.event.InspectorEvent'].atomIndex]);
atomInspector.action$jme_event_InspectorEvent.apply(atomInspector, [this.b$['jme.event.InspectorEvent']]);
}});
})()
), Clazz.new_(P$.InspectorEvent$lambda1.$init$,[this, {e:e}]))]);
});

Clazz.newMeth(C$, 'changeAtomMap$I',  function (newMap) {
if (newMap >= 0) {
this.jme.changeAtomMap$jme_JMEmol$I$I(this.mol, this.atomIndex, newMap);
} else {
this.showError$S("Atom map or mark should be positive");
}});

Clazz.newMeth(C$, 'changeAtomCharge$I',  function (newCharge) {
this.jme.changeAtomCharge$jme_JMEmol$I$I(this.mol, this.atomIndex, newCharge);
});

Clazz.newMeth(C$, 'showError$S',  function (message) {
this.jme.showError$S(message);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
