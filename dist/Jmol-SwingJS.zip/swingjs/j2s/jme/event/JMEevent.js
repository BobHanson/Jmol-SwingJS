(function(){var P$=Clazz.newPackage("jme.event"),p$1={},I$=[[0,['jme.event.JMEevent','.Origin']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JMEevent", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['Origin',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.stackLevel=0;
},1);

C$.$fields$=[['I',['atom','bond','atomBackgroundColorIndex','atomE','bondE','molecule','stackLevel'],'S',['action','argument','origin'],'O',['bondAtoms','int[]','+bondAtomsE','argumentJSO','java.lang.Object']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.reset$();
}, 1);

Clazz.newMeth(C$, 'reset$',  function () {
this.atom=0;
this.bond=0;
this.molecule=0;
this.atomBackgroundColorIndex=-1;
this.bondAtoms=Clazz.array(Integer.TYPE, -1, [0, 0]);
this.atomE=0;
this.bondE=0;
this.bondAtomsE=Clazz.array(Integer.TYPE, -1, [0, 0]);
this.action=null;
this.argument=null;
this.origin=null;
this.stackLevel=0;
return this;
});

Clazz.newMeth(C$, 'getAtom$',  function () {
return this.atom;
});

Clazz.newMeth(C$, 'log$S',  function (string) {
p$1.consoleLog$S.apply(this, [string]);
});

Clazz.newMeth(C$, 'consoleLog$S',  function (msg) {
alert('native method must be replaced! consoleLog');
}
, p$1);

Clazz.newMeth(C$, 'setAtomAndMol$jme_JMEmolList$I$I',  function (moleculeParts, atom, mol) {
this.atom=atom;
this.molecule=mol + 1;
this.atomE=moleculeParts.computeAtomEnsembleIndex$I$I(mol, atom);
var eAtom=moleculeParts.getEnsembleAtom$I$I(mol, atom);
if (eAtom != null  && eAtom.atom != null  ) {
this.atomBackgroundColorIndex=eAtom.atom.getMark$();
}return this;
});

Clazz.newMeth(C$, 'getBond$',  function () {
return this.bond;
});

Clazz.newMeth(C$, 'setBondAndMol$jme_JMEmolList$I$I',  function (moleculeParts, bond, mol) {
this.bond=bond;
if (bond > 0 && mol >= 0 ) {
this.molecule=mol;
var jmeMol=moleculeParts.get$I(mol);
this.bondAtoms[0]=jmeMol.bonds[bond].va;
this.bondAtoms[1]=jmeMol.bonds[bond].vb;
this.bondE=moleculeParts.computeBondEnsembleIndex$I$I(mol, bond);
this.bondAtomsE[0]=moleculeParts.computeAtomEnsembleIndex$I$I(mol, this.bondAtoms[0]);
this.bondAtomsE[1]=moleculeParts.computeAtomEnsembleIndex$I$I(mol, this.bondAtoms[1]);
}return this;
});

Clazz.newMeth(C$, 'getAction$',  function () {
return this.action;
});

Clazz.newMeth(C$, 'setAction$S',  function (action) {
this.action=action;
return this;
});

Clazz.newMeth(C$, 'setAtomAndBondAndMol$jme_JMEmolList$I$I$I',  function (moleculeParts, atom, bond, mol) {
this.setBondAndMol$jme_JMEmolList$I$I(moleculeParts, bond, mol);
return this.setAtomAndMol$jme_JMEmolList$I$I(moleculeParts, atom, mol);
});

Clazz.newMeth(C$, 'setArgument$S',  function (arg) {
this.argument=arg;
return this;
});

Clazz.newMeth(C$, 'setOrigin_API$',  function () {
p$1.setOriginIfNotAlreadySet$S.apply(this, [$I$(1).API]);
});

Clazz.newMeth(C$, 'setOrigin_GUI$',  function () {
p$1.setOriginIfNotAlreadySet$S.apply(this, [$I$(1).GUI]);
});

Clazz.newMeth(C$, 'setOrigin_DROP$',  function () {
p$1.setOriginIfNotAlreadySet$S.apply(this, [$I$(1).DROP]);
});

Clazz.newMeth(C$, 'setOrigin_INIT$',  function () {
p$1.setOriginIfNotAlreadySet$S.apply(this, [$I$(1).INIT]);
});

Clazz.newMeth(C$, 'setOrigin_PASTE$',  function () {
p$1.setOriginIfNotAlreadySet$S.apply(this, [$I$(1).PASTE]);
});

Clazz.newMeth(C$, 'setOriginIfNotAlreadySet$S',  function (newOrigin) {
if (this.origin == null ) {
this.origin=newOrigin;
}}, p$1);

Clazz.newMeth(C$, 'isOrigin_API$',  function () {
return this.origin == $I$(1).API;
});

Clazz.newMeth(C$, 'toString',  function () {
return "[JMEEvent " + this.action + (this.origin == null  ? "" : " origin=" + this.origin) + (this.atom > 0 ? " atom=" + this.atom : "") + (this.bond > 0 ? " bond=" + this.bond + "(" + this.bondAtoms[0] + "-" + this.bondAtoms[1] + ")"  : "") + "]" ;
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.JMEevent, "Origin", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['S',['API','PASTE','DROP','GUI','INIT']]]

C$.$static$=function(){C$.$static$=0;
C$.API="API";
C$.PASTE="PASTE";
C$.DROP="DROP";
C$.GUI="GUI";
C$.INIT="INIT";
};

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
