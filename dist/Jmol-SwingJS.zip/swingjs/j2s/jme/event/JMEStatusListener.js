(function(){var P$=Clazz.newPackage("jme.event"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "JMEStatusListener");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 15:49:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
