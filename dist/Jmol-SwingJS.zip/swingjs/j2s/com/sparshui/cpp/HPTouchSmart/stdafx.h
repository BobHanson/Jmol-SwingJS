#pragma once

#include "targetver.h"
#include <iostream>
#include <stdio.h>
#include <winsock2.h>
#include <conio.h>
#include <tchar.h>
#include <windows.h>

#pragma comment( lib, "ws2_32.lib" )