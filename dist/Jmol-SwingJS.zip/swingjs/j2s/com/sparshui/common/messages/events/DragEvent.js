(function(){var P$=Clazz.newPackage("com.sparshui.common.messages.events"),I$=[[0,'com.sparshui.common.utils.Converter']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DragEvent", null, null, 'com.sparshui.common.Event');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this._nPoints=($b$[0] = 1, $b$[0]);
},1);

C$.$fields$=[['B',['_nPoints'],'F',['_dx','_dy'],'J',['_time']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this._dx=0;
this._dy=0;
}, 1);

Clazz.newMeth(C$, 'c$$F$F$I$J',  function (dx, dy, nPoints, time) {
;C$.$init$.apply(this);
this._dx=dx;
this._dy=dy;
this._nPoints=($b$[0] = nPoints, $b$[0]);
this._time=time;
}, 1);

Clazz.newMeth(C$, 'c$$BA',  function (data) {
;C$.$init$.apply(this);
if (data.length < 17) {
System.err.println$S("Error constructing Drag Event.");
this._dx=0;
this._dy=0;
} else {
this._dx=$I$(1).byteArrayToFloat$BA$I(data, 0);
this._dy=$I$(1).byteArrayToFloat$BA$I(data, 4);
this._nPoints=data[8];
this._time=$I$(1).byteArrayToLong$BA$I(data, 9);
}}, 1);

Clazz.newMeth(C$, 'getTime$',  function () {
return this._time;
});

Clazz.newMeth(C$, 'getNPoints$',  function () {
return this._nPoints;
});

Clazz.newMeth(C$, 'getDx$',  function () {
return this._dx;
});

Clazz.newMeth(C$, 'getDy$',  function () {
return this._dy;
});

Clazz.newMeth(C$, 'setDx$F',  function (dx) {
this._dx=dx;
});

Clazz.newMeth(C$, 'setDy$F',  function (dy) {
this._dy=dy;
});

Clazz.newMeth(C$, 'getEventType$',  function () {
return 0;
});

Clazz.newMeth(C$, 'toString',  function () {
var ret="Drag Event: dx = " + new Float(this._dx).toString() + ", dy = " + new Float(this._dy).toString() ;
return ret;
});

Clazz.newMeth(C$, 'serialize$',  function () {
var data=Clazz.array(Byte.TYPE, [21]);
$I$(1,"intToByteArray$BA$I$I",[data, 0, this.getEventType$()]);
$I$(1).floatToByteArray$BA$I$F(data, 4, this._dx);
$I$(1).floatToByteArray$BA$I$F(data, 8, this._dy);
data[12]=this._nPoints;
$I$(1).longToByteArray$BA$I$J(data, 13, this._time);
return data;
});
var $b$ = new Int8Array(1);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 17:33:31 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
