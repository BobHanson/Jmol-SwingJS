(function(){var P$=Clazz.newPackage("com.sparshui.common.messages.events"),I$=[[0,'com.sparshui.common.Location','com.sparshui.common.utils.Converter']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ZoomEvent", null, null, 'com.sparshui.common.Event');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['F',['_scale'],'J',['_time'],'O',['_center','com.sparshui.common.Location']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this._scale=1;
this._center=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'c$$F$com_sparshui_common_Location$J',  function (scale, center, time) {
;C$.$init$.apply(this);
this._scale=scale;
this._center=center;
this._time=time;
}, 1);

Clazz.newMeth(C$, 'getScale$',  function () {
return this._scale;
});

Clazz.newMeth(C$, 'getTime$',  function () {
return this._time;
});

Clazz.newMeth(C$, 'getCenter$',  function () {
return this._center;
});

Clazz.newMeth(C$, 'setCenter$com_sparshui_common_Location',  function (center) {
this._center=center;
});

Clazz.newMeth(C$, 'getX$',  function () {
return this._center.getX$();
});

Clazz.newMeth(C$, 'getY$',  function () {
return this._center.getY$();
});

Clazz.newMeth(C$, 'c$$BA',  function (data) {
;C$.$init$.apply(this);
if (data.length < 12) {
System.err.println$S("Error constructing Zoom Event.");
this._scale=1;
this._center=Clazz.new_($I$(1,1).c$$F$F,[0, 0]);
} else {
this._scale=$I$(2).byteArrayToFloat$BA$I(data, 0);
this._center=Clazz.new_([$I$(2).byteArrayToFloat$BA$I(data, 4), $I$(2).byteArrayToFloat$BA$I(data, 8)],$I$(1,1).c$$F$F);
}}, 1);

Clazz.newMeth(C$, 'getEventType$',  function () {
return 4;
});

Clazz.newMeth(C$, 'serialize$',  function () {
var data=Clazz.array(Byte.TYPE, [16]);
$I$(2,"intToByteArray$BA$I$I",[data, 0, this.getEventType$()]);
$I$(2).floatToByteArray$BA$I$F(data, 4, this._scale);
$I$(2,"floatToByteArray$BA$I$F",[data, 8, this._center.getX$()]);
$I$(2,"floatToByteArray$BA$I$F",[data, 12, this._center.getY$()]);
return data;
});

Clazz.newMeth(C$, 'toString',  function () {
return ("ZOOM Scale: " + new Float(this._scale).toString() + ", Center: " + this._center.toString() );
});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 17:33:31 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
