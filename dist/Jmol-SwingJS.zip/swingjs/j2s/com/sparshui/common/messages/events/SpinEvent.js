(function(){var P$=Clazz.newPackage("com.sparshui.common.messages.events"),I$=[[0,'com.sparshui.common.utils.Converter']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SpinEvent", null, null, 'com.sparshui.common.Event');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['F',['_rotationX','_rotationY','_rotationZ']]]

Clazz.newMeth(C$, 'getEventType$',  function () {
return 2;
});

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this._rotationX=0.0;
this._rotationY=0.0;
this._rotationZ=0.0;
}, 1);

Clazz.newMeth(C$, 'c$$F$F$F',  function (rotationX, rotationY, rotationZ) {
;C$.$init$.apply(this);
this._rotationX=rotationX;
this._rotationY=rotationY;
this._rotationZ=rotationZ;
}, 1);

Clazz.newMeth(C$, 'getRotationX$',  function () {
return this._rotationX;
});

Clazz.newMeth(C$, 'getRotationY$',  function () {
return this._rotationY;
});

Clazz.newMeth(C$, 'getRotationZ$',  function () {
return this._rotationZ;
});

Clazz.newMeth(C$, 'setRotationX$F',  function (rotation) {
this._rotationX=rotation;
});

Clazz.newMeth(C$, 'setRotationY$F',  function (rotation) {
this._rotationY=rotation;
});

Clazz.newMeth(C$, 'setRotationZ$F',  function (rotation) {
this._rotationZ=rotation;
});

Clazz.newMeth(C$, 'c$$BA',  function (data) {
;C$.$init$.apply(this);
if (data.length < 12) {
System.err.println$S("An error occurred while deserializing a TouchEvent.");
} else {
this._rotationX=$I$(1).byteArrayToFloat$BA$I(data, 0);
this._rotationY=$I$(1).byteArrayToFloat$BA$I(data, 4);
this._rotationY=$I$(1).byteArrayToFloat$BA$I(data, 8);
}}, 1);

Clazz.newMeth(C$, 'serialize$',  function () {
var data=Clazz.array(Byte.TYPE, [16]);
$I$(1,"intToByteArray$BA$I$I",[data, 0, this.getEventType$()]);
$I$(1).floatToByteArray$BA$I$F(data, 4, this._rotationX);
$I$(1).floatToByteArray$BA$I$F(data, 8, this._rotationY);
$I$(1).floatToByteArray$BA$I$F(data, 12, this._rotationZ);
return data;
});

Clazz.newMeth(C$, 'toString',  function () {
return ("Spin Event - rotationX: " + new Float(this._rotationX).toString() + ", rotationY: " + new Float(this._rotationY).toString() + ", rotationZ: " + new Float(this._rotationZ).toString() );
});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 17:33:31 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
