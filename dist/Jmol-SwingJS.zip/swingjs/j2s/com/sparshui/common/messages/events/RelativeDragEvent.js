(function(){var P$=Clazz.newPackage("com.sparshui.common.messages.events"),I$=[[0,'com.sparshui.common.utils.Converter']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "RelativeDragEvent", null, null, 'com.sparshui.common.Event');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['F',['_changeInX','_changeInY']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this._changeInX=0;
this._changeInY=0;
}, 1);

Clazz.newMeth(C$, 'c$$F$F',  function (changeInX, changeInY) {
;C$.$init$.apply(this);
this._changeInX=changeInX;
this._changeInY=changeInY;
}, 1);

Clazz.newMeth(C$, 'getChangeInX$',  function () {
return this._changeInX;
});

Clazz.newMeth(C$, 'getChangeInY$',  function () {
return this._changeInY;
});

Clazz.newMeth(C$, 'c$$BA',  function (data) {
;C$.$init$.apply(this);
if (data.length < 8) {
System.err.println$S("Error constructing Drag Event.");
this._changeInX=0;
this._changeInY=0;
} else {
this._changeInX=$I$(1).byteArrayToFloat$BA$I(data, 0);
this._changeInY=$I$(1).byteArrayToFloat$BA$I(data, 4);
}}, 1);

Clazz.newMeth(C$, 'getEventType$',  function () {
return 7;
});

Clazz.newMeth(C$, 'serialize$',  function () {
var data=Clazz.array(Byte.TYPE, [12]);
$I$(1,"intToByteArray$BA$I$I",[data, 0, this.getEventType$()]);
$I$(1).floatToByteArray$BA$I$F(data, 4, this._changeInX);
$I$(1).floatToByteArray$BA$I$F(data, 8, this._changeInY);
return data;
});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 17:33:31 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
