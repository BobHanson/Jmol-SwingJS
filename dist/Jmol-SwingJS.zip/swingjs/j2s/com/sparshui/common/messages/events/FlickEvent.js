(function(){var P$=Clazz.newPackage("com.sparshui.common.messages.events"),I$=[[0,'com.sparshui.common.utils.Converter']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FlickEvent", null, null, 'com.sparshui.common.Event');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['F',['xDirection','yDirection','speedLevel']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.xDirection=0;
this.yDirection=0;
this.speedLevel=0;
}, 1);

Clazz.newMeth(C$, 'c$$F$F',  function (absx, absy) {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I',  function (_speedLevel, _xDirection, _yDirection) {
;C$.$init$.apply(this);
this.speedLevel=_speedLevel;
this.xDirection=_xDirection;
this.yDirection=_yDirection;
}, 1);

Clazz.newMeth(C$, 'c$$BA',  function (data) {
;C$.$init$.apply(this);
if (data.length < 12) {
System.err.println$S("Error constructing Flick Event.");
} else {
this.speedLevel=$I$(1).byteArrayToFloat$BA$I(data, 0);
this.xDirection=$I$(1).byteArrayToFloat$BA$I(data, 4);
this.yDirection=$I$(1).byteArrayToFloat$BA$I(data, 8);
}}, 1);

Clazz.newMeth(C$, 'getSpeedLevel$',  function () {
return this.speedLevel;
});

Clazz.newMeth(C$, 'getXdirection$',  function () {
return this.xDirection;
});

Clazz.newMeth(C$, 'getYdirection$',  function () {
return this.yDirection;
});

Clazz.newMeth(C$, 'getEventType$',  function () {
return 6;
});

Clazz.newMeth(C$, 'toString',  function () {
var ret="Flick Event";
return ret;
});

Clazz.newMeth(C$, 'serialize$',  function () {
var data=Clazz.array(Byte.TYPE, [16]);
$I$(1,"intToByteArray$BA$I$I",[data, 0, this.getEventType$()]);
$I$(1).floatToByteArray$BA$I$F(data, 4, this.speedLevel);
$I$(1).floatToByteArray$BA$I$F(data, 8, this.xDirection);
$I$(1).floatToByteArray$BA$I$F(data, 12, this.yDirection);
return data;
});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 17:33:31 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
