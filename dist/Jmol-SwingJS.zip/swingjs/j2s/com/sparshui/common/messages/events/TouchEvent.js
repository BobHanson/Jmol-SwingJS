(function(){var P$=Clazz.newPackage("com.sparshui.common.messages.events"),I$=[[0,'com.sparshui.common.utils.Converter']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TouchEvent", null, null, 'com.sparshui.common.Event');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['F',['_x','_y'],'I',['_id','_state'],'J',['_time']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this._id=2147483647;
this._x=0;
this._y=0;
this._state=0;
}, 1);

Clazz.newMeth(C$, 'c$$I$F$F$I',  function (id, x, y, state) {
;C$.$init$.apply(this);
this._id=id;
this._x=x;
this._y=y;
this._state=state;
this._time=System.currentTimeMillis$();
}, 1);

Clazz.newMeth(C$, 'c$$com_sparshui_server_TouchPoint',  function (tp) {
;C$.$init$.apply(this);
this._id=tp.getID$();
this._x=tp.getLocation$().getX$();
this._y=tp.getLocation$().getY$();
this._state=tp.getState$();
this._time=tp.getTime$();
}, 1);

Clazz.newMeth(C$, 'getTouchID$',  function () {
return this._id;
});

Clazz.newMeth(C$, 'getTime$',  function () {
return this._time;
});

Clazz.newMeth(C$, 'getX$',  function () {
return this._x;
});

Clazz.newMeth(C$, 'getY$',  function () {
return this._y;
});

Clazz.newMeth(C$, 'setX$F',  function (x) {
this._x=x;
});

Clazz.newMeth(C$, 'setY$F',  function (y) {
this._y=y;
});

Clazz.newMeth(C$, 'getState$',  function () {
return this._state;
});

Clazz.newMeth(C$, 'getEventType$',  function () {
return 3;
});

Clazz.newMeth(C$, 'c$$BA',  function (data) {
;C$.$init$.apply(this);
if (data.length < 24) {
System.err.println$S("An error occurred while deserializing a TouchEvent.");
} else {
this._id=$I$(1).byteArrayToInt$BA$I(data, 0);
this._x=$I$(1).byteArrayToFloat$BA$I(data, 4);
this._y=$I$(1).byteArrayToFloat$BA$I(data, 8);
this._state=$I$(1).byteArrayToInt$BA$I(data, 12);
this._time=$I$(1).byteArrayToLong$BA$I(data, 16);
}}, 1);

Clazz.newMeth(C$, 'serialize$',  function () {
var data=Clazz.array(Byte.TYPE, [28]);
$I$(1,"intToByteArray$BA$I$I",[data, 0, this.getEventType$()]);
$I$(1).intToByteArray$BA$I$I(data, 4, this._id);
$I$(1).floatToByteArray$BA$I$F(data, 8, this._x);
$I$(1).floatToByteArray$BA$I$F(data, 12, this._y);
$I$(1).intToByteArray$BA$I$I(data, 16, this._state);
$I$(1).longToByteArray$BA$I$J(data, 20, this._time);
return data;
});

Clazz.newMeth(C$, 'toString',  function () {
return ("Touch Event: ID: " + this._id + ", X: " + new Float(this._x).toString() + ", Y: " + new Float(this._y).toString() + "State: " + this._state );
});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 17:33:31 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
