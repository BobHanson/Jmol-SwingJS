(function(){var P$=Clazz.newPackage("com.sparshui.common.utils"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Converter");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'intToByteArray$I',  function (intBits) {
var ret=Clazz.array(Byte.TYPE, [4]);
ret[0]=(((intBits & -16777216) >> 24)|0);
ret[1]=(((intBits & 16711680) >> 16)|0);
ret[2]=(((intBits & 65280) >> 8)|0);
ret[3]=(((intBits & 255) >> 0)|0);
return ret;
}, 1);

Clazz.newMeth(C$, 'intToByteArray$BA$I$I',  function (data, i, idata) {
data[i++]=(((idata & -16777216) >> 24)|0);
data[i++]=(((idata & 16711680) >> 16)|0);
data[i++]=(((idata & 65280) >> 8)|0);
data[i]=(((idata & 255) >> 0)|0);
}, 1);

Clazz.newMeth(C$, 'byteArrayToInt$BA',  function (b) {
return ((b[0] << 24) & -16777216) | ((b[1] << 16) & 16711680) | ((b[2] << 8) & 65280) | (b[3] & 255) ;
}, 1);

Clazz.newMeth(C$, 'byteArrayToInt$BA$I',  function (b, i) {
return ((b[i++] << 24) & -16777216) | ((b[i++] << 16) & 16711680) | ((b[i++] << 8) & 65280) | (b[i] & 255) ;
}, 1);

Clazz.newMeth(C$, 'floatToByteArray$BA$I$F',  function (data, i, fdata) {
C$.intToByteArray$BA$I$I(data, i, Float.floatToIntBits$F(fdata));
}, 1);

Clazz.newMeth(C$, 'byteArrayToFloat$BA$I',  function (data, i) {
return Float.intBitsToFloat$I(C$.byteArrayToInt$BA$I(data, i));
}, 1);

Clazz.newMeth(C$, 'longToByteArray$BA$I$J',  function (data, i, ldata) {
C$.intToByteArray$BA$I$I(data, i, (Long.$ival((Long.$sr(ldata,32)))));
C$.intToByteArray$BA$I$I(data, i + 4, (Long.$ival((Long.$and(ldata,-1)))));
}, 1);

Clazz.newMeth(C$, 'byteArrayToLong$BA$I',  function (data, i) {
return Long.$or((Long.$sl((C$.byteArrayToInt$BA$I(data, i)),32)),Long.$and(C$.byteArrayToInt$BA$I(data, i + 4),4294967295));
}, 1);

Clazz.newMeth(C$, 'byteArrayToString$BA',  function (bytes) {
var chars=Clazz.array(Character.TYPE, [bytes.length]);
for (var i=0; i < chars.length; i++) chars[i]=String.fromCharCode(bytes[i]);

return  String.instantialize(chars);
}, 1);

Clazz.newMeth(C$, 'stringToByteArray$S',  function (s) {
var chars=s.toCharArray$();
var bytes=Clazz.array(Byte.TYPE, [s.length$()]);
for (var i=0; i < chars.length; i++) bytes[i]=(chars[i].$c()|0);

return bytes;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 17:33:31 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
