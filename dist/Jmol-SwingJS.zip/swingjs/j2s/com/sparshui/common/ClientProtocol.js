(function(){var P$=Clazz.newPackage("com.sparshui.common"),I$=[[0,'java.io.DataInputStream','java.io.DataOutputStream']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ClientProtocol", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['MessageType',4]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['_socket','java.net.Socket','_in','java.io.DataInputStream','_out','java.io.DataOutputStream']]]

Clazz.newMeth(C$, 'c$$java_net_Socket',  function (socket) {
;C$.$init$.apply(this);
this._socket=socket;
this._in=Clazz.new_([this._socket.getInputStream$()],$I$(1,1).c$$java_io_InputStream);
this._out=Clazz.new_([this._socket.getOutputStream$()],$I$(2,1).c$$java_io_OutputStream);
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.ClientProtocol, "MessageType", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 17:33:31 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
