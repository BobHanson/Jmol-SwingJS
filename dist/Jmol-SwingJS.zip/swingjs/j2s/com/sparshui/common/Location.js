(function(){var P$=Clazz.newPackage("com.sparshui.common"),I$=[[0,'java.awt.Toolkit','javajs.util.V3d']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Location", null, null, 'java.io.Serializable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['F',['_x','_y']]
,['O',['screenDim','java.awt.Dimension']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this._x=0;
this._y=0;
}, 1);

Clazz.newMeth(C$, 'c$$F$F',  function (x, y) {
;C$.$init$.apply(this);
this._x=x;
this._y=y;
}, 1);

Clazz.newMeth(C$, 'getX$',  function () {
return this._x;
});

Clazz.newMeth(C$, 'getY$',  function () {
return this._y;
});

Clazz.newMeth(C$, 'toString',  function () {
return "x = " + new Float(this._x).toString() + ", y = " + new Float(this._y).toString() + (this._x < 1  && this._x > 0   ? "(" + new Float(C$.pixelLocation$com_sparshui_common_Location(this).getX$()).toString() + " " + new Float(C$.pixelLocation$com_sparshui_common_Location(this).getY$()).toString() + ")"  : "") ;
});

Clazz.newMeth(C$, 'getDistance$com_sparshui_common_Location',  function (location) {
var dx;
var dy;
return Math.sqrt((dx=this._x - location._x) * dx + (dy=this._y - location._y) * dy);
});

Clazz.newMeth(C$, 'getVector$com_sparshui_common_Location',  function (location) {
return $I$(2).new3$D$D$D(location._x - this._x, location._y - this._y, 0);
});

Clazz.newMeth(C$, 'getCenter$com_sparshui_common_Location$com_sparshui_common_Location',  function (a, b) {
return C$.getCentroid$com_sparshui_common_Location$com_sparshui_common_Location$F(a, b, 0.5);
}, 1);

Clazz.newMeth(C$, 'getCentroid$com_sparshui_common_Location$com_sparshui_common_Location$F',  function (a, b, w) {
var w1=1 - w;
return Clazz.new_(C$.c$$F$F,[a._x * w1 + b._x * w, a._y * w1 + b._y * w]);
}, 1);

Clazz.newMeth(C$, 'pixelLocation$com_sparshui_common_Location',  function (location) {
return location == null  ? null : Clazz.new_(C$.c$$F$F,[location.getX$() * C$.screenDim.width, location.getY$() * C$.screenDim.height]);
}, 1);

Clazz.newMeth(C$, 'screenLocation$com_sparshui_common_Location',  function (location) {
return (location == null  ? null : Clazz.new_(C$.c$$F$F,[location.getX$() / C$.screenDim.width, location.getY$() / C$.screenDim.height]));
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.screenDim=$I$(1).getDefaultToolkit$().getScreenSize$();
};
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 17:33:31 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
