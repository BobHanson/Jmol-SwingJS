(function(){var P$=Clazz.newPackage("com.sparshui.server"),I$=[[0,'javajs.util.Lst','com.sparshui.server.GestureFactory']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Group");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['_id'],'O',['_gestureTypes','javajs.util.Lst','+_gestures','+_touchPoints','_clientProtocol','com.sparshui.server.ServerToClientProtocol']]]

Clazz.newMeth(C$, 'c$$I$javajs_util_Lst$com_sparshui_server_ServerToClientProtocol',  function (id, gestureTypes, clientProtocol) {
;C$.$init$.apply(this);
this._id=id;
this._gestureTypes=gestureTypes;
this._gestures=Clazz.new_($I$(1,1));
this._touchPoints=Clazz.new_($I$(1,1));
this._clientProtocol=clientProtocol;
for (var i=0; i < this._gestureTypes.size$(); i++) {
var gesture=$I$(2,"createGesture$com_sparshui_GestureType",[this._gestureTypes.get$I(i)]);
if (gesture != null ) this._gestures.addLast$O(gesture);
}
}, 1);

Clazz.newMeth(C$, 'getID$',  function () {
return this._id;
});

Clazz.newMeth(C$, 'update$com_sparshui_server_TouchPoint',  function (changedPoint) {
var events=Clazz.new_($I$(1,1));
var state=changedPoint.getState$();
if (state == 0) this._touchPoints.addLast$O(changedPoint);
for (var i=0; i < this._gestures.size$(); i++) {
var gesture=this._gestures.get$I(i);
events.addAll$java_util_Collection(gesture.processChange$java_util_List$com_sparshui_server_TouchPoint(this._touchPoints, changedPoint));
}
if (state == 1) this._touchPoints.removeObj$O(changedPoint);
try {
this._clientProtocol.processEvents$I$javajs_util_Lst(this._id, events);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 17:33:31 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
