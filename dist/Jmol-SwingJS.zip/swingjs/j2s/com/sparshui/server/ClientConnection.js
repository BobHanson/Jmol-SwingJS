(function(){var P$=Clazz.newPackage("com.sparshui.server"),p$1={},I$=[[0,'com.sparshui.server.ServerToClientProtocol','java.util.Hashtable','com.sparshui.server.Group']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ClientConnection");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['_protocol','com.sparshui.server.ServerToClientProtocol','_groups','java.util.Map']]]

Clazz.newMeth(C$, 'c$$java_net_Socket',  function (socket) {
;C$.$init$.apply(this);
this._protocol=Clazz.new_($I$(1,1).c$$java_net_Socket,[socket]);
this._groups=Clazz.new_($I$(2,1));
}, 1);

Clazz.newMeth(C$, 'processBirth$com_sparshui_server_TouchPoint',  function (touchPoint) {
var groupID=(touchPoint == null  ? 268435456 : p$1.getGroupID$com_sparshui_server_TouchPoint.apply(this, [touchPoint]));
var jmolFlags=(groupID & -268435456);
if (jmolFlags != 0) {
switch (jmolFlags) {
case 268435456:
this._groups=Clazz.new_($I$(2,1));
break;
}
groupID&=~jmolFlags;
}var group=p$1.getGroup$I.apply(this, [groupID]);
if (group != null ) {
touchPoint.setGroup$com_sparshui_server_Group(group);
return true;
}return false;
});

Clazz.newMeth(C$, 'getGestures$I',  function (groupID) {
return this._protocol.getGestures$I(groupID);
}, p$1);

Clazz.newMeth(C$, 'getGroupID$com_sparshui_server_TouchPoint',  function (touchPoint) {
return this._protocol.getGroupID$com_sparshui_server_TouchPoint(touchPoint);
}, p$1);

Clazz.newMeth(C$, 'getGroup$I',  function (groupID) {
if (groupID == 0) return null;
var group=null;
var gid=Integer.valueOf$I(groupID);
if (this._groups.containsKey$O(gid)) {
group=this._groups.get$O(gid);
} else {
var gestureTypes=p$1.getGestures$I.apply(this, [groupID]);
group=Clazz.new_($I$(3,1).c$$I$javajs_util_Lst$com_sparshui_server_ServerToClientProtocol,[groupID, gestureTypes, this._protocol]);
this._groups.put$O$O(gid, group);
}return group;
}, p$1);

Clazz.newMeth(C$, 'processError$I',  function (errCode) {
try {
this._protocol.processError$I(errCode);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 17:33:31 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
