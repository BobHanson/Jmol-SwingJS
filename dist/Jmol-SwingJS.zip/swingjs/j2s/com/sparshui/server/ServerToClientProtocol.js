(function(){var P$=Clazz.newPackage("com.sparshui.server"),p$1={},I$=[[0,'java.io.ByteArrayOutputStream','java.io.DataOutputStream','javajs.util.Lst','com.sparshui.GestureType','com.sparshui.common.utils.Converter']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ServerToClientProtocol", null, 'com.sparshui.common.ClientProtocol');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['_bufferOut','java.io.DataOutputStream','_buffer','java.io.ByteArrayOutputStream']]]

Clazz.newMeth(C$, 'c$$java_net_Socket',  function (socket) {
;C$.superclazz.c$$java_net_Socket.apply(this,[socket]);C$.$init$.apply(this);
this._buffer=Clazz.new_($I$(1,1));
this._bufferOut=Clazz.new_($I$(2,1).c$$java_io_OutputStream,[this._buffer]);
}, 1);

Clazz.newMeth(C$, 'getGestures$I',  function (groupID) {
var gestures=Clazz.new_($I$(3,1));
this._bufferOut.writeInt$I(groupID);
p$1.sendBuffer$I.apply(this, [2]);
for (var length=this._in.readInt$(); length > 0; length-=4) {
var gestureID=this._in.readInt$();
if (gestureID < 0) {
var bytes=Clazz.array(Byte.TYPE, [-gestureID]);
this._in.read$BA(bytes);
gestures.addLast$O(Clazz.new_([$I$(5).byteArrayToString$BA(bytes)],$I$(4,1).c$$S));
length-=bytes.length;
} else {
gestures.addLast$O(Clazz.new_($I$(4,1).c$$I,[gestureID]));
}}
return gestures;
});

Clazz.newMeth(C$, 'getGroupID$com_sparshui_server_TouchPoint',  function (touchPoint) {
var tempFloat=Clazz.array(Byte.TYPE, [4]);
$I$(5,"floatToByteArray$BA$I$F",[tempFloat, 0, touchPoint.getLocation$().getX$()]);
this._bufferOut.write$BA(tempFloat);
$I$(5,"floatToByteArray$BA$I$F",[tempFloat, 0, touchPoint.getLocation$().getY$()]);
this._bufferOut.write$BA(tempFloat);
p$1.sendBuffer$I.apply(this, [1]);
var ret=this._in.readInt$();
return ret;
});

Clazz.newMeth(C$, 'processEvents$I$javajs_util_Lst',  function (groupID, events) {
for (var i=0; i < events.size$(); i++) {
this._bufferOut.writeInt$I(groupID);
this._bufferOut.write$BA(events.get$I(i).serialize$());
p$1.sendBuffer$I.apply(this, [0]);
}
});

Clazz.newMeth(C$, 'processError$I',  function (errCode) {
this._bufferOut.writeInt$I(-1);
this._bufferOut.writeInt$I(errCode);
p$1.sendBuffer$I.apply(this, [0]);
});

Clazz.newMeth(C$, 'sendBuffer$I',  function (type) {
this._out.writeByte$I(($b$[0] = type, $b$[0]));
this._out.writeInt$I(this._buffer.size$());
this._out.write$BA(this._buffer.toByteArray$());
this._buffer.reset$();
}, p$1);
var $b$ = new Int8Array(1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 17:33:31 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
