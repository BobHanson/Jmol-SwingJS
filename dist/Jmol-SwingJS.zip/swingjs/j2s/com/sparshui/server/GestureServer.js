(function(){var P$=Clazz.newPackage("com.sparshui.server"),p$1={},I$=[[0,'javajs.util.Lst','org.jmol.util.Logger','Thread','java.net.ServerSocket','com.sparshui.server.ClientConnection','com.sparshui.server.InputDeviceConnection','com.sparshui.server.TouchPoint']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "GestureServer", null, null, ['Runnable', 'org.jmol.api.JmolGestureServerInterface']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this._clients=Clazz.new_($I$(1,1));
this.ic=null;
},1);

C$.$fields$=[['I',['port','myState'],'O',['clientServer','com.sparshui.server.GestureServer','+deviceServer','+main','clientThread','Thread','+deviceThread','_clientSocket','java.net.ServerSocket','+_deviceSocket','+_mySocket','_clients','javajs.util.Lst','ic','com.sparshui.server.InputDeviceConnection']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
$I$(2).info$S(this + " constructed");
}, 1);

Clazz.newMeth(C$, 'finalize$',  function () {
if ($I$(2).debugging) $I$(2).debug$S(this + " finalized");
});

Clazz.newMeth(C$, 'c$$I$com_sparshui_server_GestureServer',  function (port, main) {
;C$.$init$.apply(this);
this.port=port;
this.main=main;
}, 1);

Clazz.newMeth(C$, 'startGestureServer$',  function () {
this.clientServer=Clazz.new_(C$.c$$I$com_sparshui_server_GestureServer,[5946, this]);
this.clientThread=Clazz.new_($I$(3,1).c$$Runnable,[this.clientServer]);
this.clientThread.setName$S("Jmol SparshUI Client GestureServer on port 5946");
this.clientThread.start$();
this.deviceServer=Clazz.new_(C$.c$$I$com_sparshui_server_GestureServer,[5947, this]);
this.deviceThread=Clazz.new_($I$(3,1).c$$Runnable,[this.deviceServer]);
this.deviceThread.setName$S("Jmol SparshUI Device GestureServer on port 5947");
this.deviceThread.start$();
});

Clazz.newMeth(C$, 'dispose$',  function () {
try {
this._clientSocket.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
try {
this._deviceSocket.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
try {
this.clientThread.interrupt$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
try {
this.deviceThread.interrupt$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
this._clientSocket=null;
this.clientThread=null;
this._deviceSocket=null;
this.deviceThread=null;
this.clientServer=null;
this.deviceServer=null;
});

Clazz.newMeth(C$, 'run$',  function () {
try {
p$1.openSocket.apply(this, []);
p$1.acceptConnections.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
$I$(2).info$S("[GestureServer] connection unavailable");
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'openSocket',  function () {
try {
if (this.port == 5946) this._mySocket=this.main._clientSocket=Clazz.new_($I$(4,1).c$$I,[this.port]);
 else this._mySocket=this.main._deviceSocket=Clazz.new_($I$(4,1).c$$I,[this.port]);
$I$(2).info$S("[GestureServer] Socket Open: " + this.port);
this.main.myState=1;
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
$I$(2).error$S("[GestureServer] Failed to open a server socket.");
e.printStackTrace$();
this.main.myState=0;
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'acceptConnections',  function () {
while (!this._mySocket.isClosed$()){
try {
if (this.port == 5947) {
$I$(2).info$S("[GestureServer] Accepting device connections");
p$1.acceptConnection$java_net_Socket.apply(this, [this._mySocket.accept$()]);
return;
}$I$(2).info$S("[GestureServer] Accepting client connections");
p$1.acceptConnection$java_net_Socket.apply(this, [this._mySocket.accept$()]);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
$I$(2).error$S("[GestureServer] Failed to establish connection on port " + this.port);
e.printStackTrace$();
} else {
throw e;
}
}
}
$I$(2).info$S("[GestureServer] Socket Closed on port " + this.port);
}, p$1);

Clazz.newMeth(C$, 'acceptConnection$java_net_Socket',  function (socket) {
var add=socket.getInetAddress$().getAddress$();
if (add[0] != 127 || add[1] != 0  || add[2] != 0  || add[3] != 1 ) return;
var type=socket.getInputStream$().read$();
if (type == 0) {
$I$(2).info$S("[GestureServer] client connection established on port " + this.port);
p$1.acceptClientConnection$java_net_Socket.apply(this, [socket]);
} else if (type == 1) {
$I$(2).info$S("[GestureServer] device connection established on port " + this.port);
p$1.acceptInputDeviceConnection$java_net_Socket.apply(this, [socket]);
}}, p$1);

Clazz.newMeth(C$, 'acceptClientConnection$java_net_Socket',  function (socket) {
$I$(2).info$S("[GestureServer] Client connection accepted");
var cc=Clazz.new_($I$(5,1).c$$java_net_Socket,[socket]);
this.main._clients.addLast$O(cc);
if (this.main.ic == null ) {
cc.processError$I(-2);
} else {
this.main.myState|=2;
}}, p$1);

Clazz.newMeth(C$, 'acceptInputDeviceConnection$java_net_Socket',  function (socket) {
$I$(2).info$S("[GestureServer] Input device connection accepted");
this.main.ic=Clazz.new_($I$(6,1).c$$com_sparshui_server_GestureServer$java_net_Socket,[this, socket]);
this.main.myState|=4;
}, p$1);

Clazz.newMeth(C$, 'notifyInputLost$',  function () {
$I$(2).error$S("[GestureServer] sending clients message that input device was lost.");
this.main.ic=null;
this.main.myState&=~4;
p$1.processBirth$com_sparshui_server_TouchPoint.apply(this, [null]);
});

Clazz.newMeth(C$, 'processTouchPoint$java_util_Map$I$com_sparshui_common_Location$J$I',  function (inputDeviceTouchPoints, id, location, time, state) {
if ($I$(2).debugging) {
$I$(2,"debug$S",["[GestureServer] processTouchPoint id=" + id + " state=" + state + " " + location + " " + Long.$s(time) ]);
}var iid=Integer.valueOf$I(id);
if (inputDeviceTouchPoints.containsKey$O(iid)) {
var touchPoint=inputDeviceTouchPoints.get$O(iid);
if (!touchPoint.isClaimed$()) return false;
if ($I$(2).debugging) $I$(2).debug$S("[GestureServer] OK");
{
touchPoint.update$com_sparshui_common_Location$J$I(location, time, state);
}return true;
}var touchPoint=Clazz.new_($I$(7,1).c$$I$com_sparshui_common_Location$J,[id, location, time]);
inputDeviceTouchPoints.put$O$O(iid, touchPoint);
return p$1.processBirth$com_sparshui_server_TouchPoint.apply(this, [touchPoint]);
});

Clazz.newMeth(C$, 'processBirth$com_sparshui_server_TouchPoint',  function (touchPoint) {
var clients_to_remove=null;
var isClaimed=false;
for (var i=0; i < this.main._clients.size$(); i++) {
var client=this.main._clients.get$I(i);
try {
if (touchPoint == null ) client.processError$I(-2);
 else isClaimed=client.processBirth$com_sparshui_server_TouchPoint(touchPoint);
if (isClaimed) break;
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
if (clients_to_remove == null ) clients_to_remove=Clazz.new_($I$(1,1));
clients_to_remove.addLast$O(client);
} else {
throw e;
}
}
}
if (clients_to_remove != null ) for (var i=0; i < clients_to_remove.size$(); i++) {
this.main._clients.removeObj$O(clients_to_remove.get$I(i));
$I$(2).info$S("[GestureServer] Client Disconnected");
}
return isClaimed;
}, p$1);

Clazz.newMeth(C$, 'getState$',  function () {
return this.myState;
});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 17:33:31 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
