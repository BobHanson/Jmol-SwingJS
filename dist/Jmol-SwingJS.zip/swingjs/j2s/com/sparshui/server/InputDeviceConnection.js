(function(){var P$=Clazz.newPackage("com.sparshui.server"),p$1={},I$=[[0,'java.io.DataInputStream','java.util.Hashtable','java.util.ArrayList','com.sparshui.common.Location','Thread']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InputDeviceConnection", null, null, 'Runnable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['_gestureServer','com.sparshui.server.GestureServer','_socket','java.net.Socket','_in','java.io.DataInputStream','_touchPoints','java.util.Map','_flaggedids','java.util.List']]]

Clazz.newMeth(C$, 'c$$com_sparshui_server_GestureServer$java_net_Socket',  function (gestureServer, socket) {
;C$.$init$.apply(this);
this._gestureServer=gestureServer;
this._socket=socket;
this._in=Clazz.new_([socket.getInputStream$()],$I$(1,1).c$$java_io_InputStream);
this._touchPoints=Clazz.new_($I$(2,1));
this._flaggedids=Clazz.new_($I$(3,1));
p$1.startListening.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'removeDeadTouchPoints',  function () {
for (var i=0; i < this._flaggedids.size$(); i++) {
var id=this._flaggedids.get$I(i);
this._touchPoints.remove$O(id);
}
this._flaggedids.clear$();
}, p$1);

Clazz.newMeth(C$, 'flagTouchPointForRemoval$I',  function (id) {
this._flaggedids.add$O(Integer.valueOf$I(id));
}, p$1);

Clazz.newMeth(C$, 'receiveData',  function () {
try {
while (!this._socket.isInputShutdown$()){
p$1.readTouchPoints.apply(this, []);
}
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
System.out.println$S("[InputDeviceConnection] InputDevice Disconnected");
this._gestureServer.notifyInputLost$();
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'readTouchPoints',  function () {
var count=this._in.readInt$();
if (count == 0) {
this._in.close$();
return false;
}var touchPointDataLength;
if (count < 0) {
count=-count;
touchPointDataLength=this._in.readInt$();
} else {
touchPointDataLength=13;
}var doConsume=false;
for (var i=0; i < count; i++) doConsume=!!(doConsume|(p$1.readTouchPoint$I.apply(this, [touchPointDataLength])));

p$1.removeDeadTouchPoints.apply(this, []);
return doConsume;
}, p$1);

Clazz.newMeth(C$, 'readTouchPoint$I',  function (len) {
var id=this._in.readInt$();
var x=this._in.readFloat$();
var y=this._in.readFloat$();
var state=this._in.readByte$();
var time=(len >= 21 ? this._in.readLong$() : System.currentTimeMillis$());
if (len > 21) this._in.read$BA(Clazz.array(Byte.TYPE, [len - 21]));
var location=Clazz.new_($I$(4,1).c$$F$F,[x, y]);
var doConsume=this._gestureServer.processTouchPoint$java_util_Map$I$com_sparshui_common_Location$J$I(this._touchPoints, id, location, time, state);
if (state == 1) p$1.flagTouchPointForRemoval$I.apply(this, [id]);
return doConsume;
}, p$1);

Clazz.newMeth(C$, 'startListening',  function () {
var thread=Clazz.new_($I$(5,1).c$$Runnable,[this]);
thread.setName$S("SparshUI Server->InputDeviceConnection on port 5947");
thread.start$();
}, p$1);

Clazz.newMeth(C$, 'run$',  function () {
p$1.receiveData.apply(this, []);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 17:33:31 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
