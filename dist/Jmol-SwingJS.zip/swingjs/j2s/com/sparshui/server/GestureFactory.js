(function(){var P$=Clazz.newPackage("com.sparshui.server"),I$=[[0,'org.jmol.util.Logger']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "GestureFactory");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'createGesture$com_sparshui_GestureType',  function (gType) {
if (gType.sType != null ) {
try {
return Clazz.forName(gType.sType).newInstance$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
$I$(1,"error$S",["[GestureFactory] Error creating instance for " + gType.sType + ": \n" + e.getMessage$() ]);
} else {
throw e;
}
}
return null;
}$I$(1).error$S("[GestureFactory] Gesture not recognized: " + gType.iType);
return null;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 17:33:31 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
