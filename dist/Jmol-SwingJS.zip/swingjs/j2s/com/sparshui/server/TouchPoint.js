(function(){var P$=Clazz.newPackage("com.sparshui.server");
/*c*/var C$=Clazz.newClass(P$, "TouchPoint");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['_changed'],'I',['_id','_state'],'J',['_time'],'O',['_location','com.sparshui.common.Location','_group','com.sparshui.server.Group']]]

Clazz.newMeth(C$, 'isClaimed$',  function () {
return (this._group != null );
});

Clazz.newMeth(C$, 'c$$I$com_sparshui_common_Location$J',  function (id, location, time) {
;C$.$init$.apply(this);
this._id=id;
this._location=location;
this._time=time;
this._state=0;
}, 1);

Clazz.newMeth(C$, 'c$$com_sparshui_server_TouchPoint',  function (tp) {
;C$.$init$.apply(this);
this._id=tp._id;
this._location=tp._location;
this._state=tp._state;
this._time=tp._time;
}, 1);

Clazz.newMeth(C$, 'getTime$',  function () {
return this._time;
});

Clazz.newMeth(C$, 'getID$',  function () {
return this._id;
});

Clazz.newMeth(C$, 'getLocation$',  function () {
return this._location;
});

Clazz.newMeth(C$, 'getState$',  function () {
return this._state;
});

Clazz.newMeth(C$, 'setState$I',  function (state) {
this._state=state;
});

Clazz.newMeth(C$, 'setGroup$com_sparshui_server_Group',  function (group) {
this._group=group;
this._group.update$com_sparshui_server_TouchPoint(this);
});

Clazz.newMeth(C$, 'update$com_sparshui_common_Location$J$I',  function (location, time, state) {
this._location=location;
this._state=state;
this._changed=true;
this._time=time;
if (this._group != null ) this._group.update$com_sparshui_server_TouchPoint(this);
});

Clazz.newMeth(C$, 'resetChanged$',  function () {
this._changed=false;
});

Clazz.newMeth(C$, 'isChanged$',  function () {
return this._changed;
});

Clazz.newMeth(C$, 'clone$',  function () {
return Clazz.new_(C$.c$$com_sparshui_server_TouchPoint,[this]);
});

Clazz.newMeth(C$, 'isNear$com_sparshui_server_TouchPoint',  function (tp) {
return (Math.abs(this._location.getX$() - tp._location.getX$()) < 0.005  && Math.abs(this._location.getY$() - tp._location.getY$()) < 0.005  );
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 17:33:31 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
