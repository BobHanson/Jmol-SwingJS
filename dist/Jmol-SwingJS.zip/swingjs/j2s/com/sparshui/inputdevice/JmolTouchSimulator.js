(function(){var P$=Clazz.newPackage("com.sparshui.inputdevice"),p$1={},I$=[[0,'Thread','java.util.TreeSet',['com.sparshui.inputdevice.JmolTouchSimulator','.TouchDataComparator'],'java.util.Hashtable','java.util.Timer','java.net.Socket','java.io.DataOutputStream','org.jmol.util.Logger',['com.sparshui.inputdevice.JmolTouchSimulator','.TouchData'],'java.awt.Point','javax.swing.SwingUtilities',['com.sparshui.inputdevice.JmolTouchSimulator','.TouchTimerTask'],'java.awt.Toolkit']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JmolTouchSimulator", function(){
Clazz.newInstance(this, arguments,0,C$);
}, null, 'org.jmol.api.JmolTouchSimulatorInterface');
C$.$classes$=[['TouchData',4],['TouchDataComparator',4],['TouchTimerTask',2]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this._events=Clazz.new_([Clazz.new_($I$(3,1),[this, null])],$I$(2,1).c$$java_util_Comparator);
this._active=Clazz.new_($I$(4,1));
this._recording=false;
this._touchID=0;
this._when=0;
},1);

C$.$fields$=[['Z',['_recording'],'I',['_touchID'],'J',['_when'],'O',['_events','java.util.TreeSet','_active','java.util.Map','_timer','java.util.Timer','_display','java.awt.Component','_out','java.io.DataOutputStream']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'dispose$',  function () {
try {
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
try {
this._out.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
try {
this._timer.cancel$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'startSimulator$O',  function (display) {
this._display=display;
var address="localhost";
this._timer=Clazz.new_($I$(5,1));
try {
var socket=Clazz.new_($I$(6,1).c$$S$I,[address, 5947]);
this._out=Clazz.new_([socket.getOutputStream$()],$I$(7,1).c$$java_io_OutputStream);
this._out.writeByte$I(1);
socket.close$();
return true;
} catch (e$$) {
if (Clazz.exceptionOf(e$$,"java.net.UnknownHostException")){
var e = e$$;
{
$I$(8).error$S("Could not locate a server at " + address);
}
} else if (Clazz.exceptionOf(e$$,"java.io.IOException")){
var e = e$$;
{
$I$(8).error$S("Failed to connect to server at " + address);
}
} else {
throw e$$;
}
}
return false;
});

Clazz.newMeth(C$, 'toggleMode$',  function () {
if (this._recording) {
this.endRecording$();
} else {
this.startRecording$();
}});

Clazz.newMeth(C$, 'startRecording$',  function () {
this._recording=true;
this._active.clear$();
});

Clazz.newMeth(C$, 'endRecording$',  function () {
this._recording=false;
p$1.dispatchTouchEvents.apply(this, []);
});

Clazz.newMeth(C$, 'mousePressed$J$I$I',  function (time, x, y) {
p$1.handleMouseEvent$J$I$I$I.apply(this, [time, x, y, 0]);
});

Clazz.newMeth(C$, 'mouseReleased$J$I$I',  function (time, x, y) {
p$1.handleMouseEvent$J$I$I$I.apply(this, [time, x, y, 1]);
});

Clazz.newMeth(C$, 'mouseDragged$J$I$I',  function (time, x, y) {
p$1.handleMouseEvent$J$I$I$I.apply(this, [time, x, y, 2]);
});

Clazz.newMeth(C$, 'handleMouseEvent$J$I$I$I',  function (time, x, y, type) {
var te=Clazz.new_($I$(9,1),[this, null]);
te.id=(type == 0) ? ++this._touchID : this._touchID;
var p=Clazz.new_($I$(10,1).c$$I$I,[x, y]);
try {
$I$(11).convertPointToScreen$java_awt_Point$java_awt_Component(p, this._display);
} catch (e) {
return;
}
te.x=p.x;
te.y=p.y;
te.type=type;
te.when=time;
if (this._recording) {
if (type == 0) {
te.delay=0;
this._when=te.when;
} else {
te.delay=Long.$sub(te.when,this._when);
}this._events.add$O(te);
} else {
this.dispatchTouchEvent$com_sparshui_inputdevice_JmolTouchSimulator_TouchData(te);
if ($I$(8).debugging) $I$(8,"debug$S",["[JmolTouchSimulator] dispatchTouchEvent(" + te.id + ", " + te.x + ", " + te.y + ", " + te.type + ")" ]);
}}, p$1);

Clazz.newMeth(C$, 'dispatchTouchEvents',  function () {
for (var data, $data = this._events.iterator$(); $data.hasNext$()&&((data=($data.next$())),1);) {
var task=Clazz.new_($I$(12,1).c$$com_sparshui_inputdevice_JmolTouchSimulator_TouchData,[this, null, data]);
this._timer.schedule$java_util_TimerTask$J(task, Long.$add(data.delay,250));
}
this._events.clear$();
this._touchID=0;
}, p$1);

Clazz.newMeth(C$, 'dispatchTouchEvent$com_sparshui_inputdevice_JmolTouchSimulator_TouchData',  function (data) {
var tk=$I$(13).getDefaultToolkit$();
var dim=tk.getScreenSize$();
if ($I$(8).debugging) $I$(8,"debug$S",["[JmolTouchSimulator] dispatchTouchEvent(" + data.id + ", " + data.x + ", " + data.y + ", " + data.type + ")" ]);
try {
this._out.writeInt$I(-1);
this._out.writeInt$I(21);
this._out.writeInt$I(data.id);
this._out.writeFloat$F((data.x / dim.width));
this._out.writeFloat$F((data.y / dim.height));
this._out.writeByte$I(($b$[0] = data.type, $b$[0]));
this._out.writeLong$J(data.when);
} catch (e1) {
if (Clazz.exceptionOf(e1,"java.io.IOException")){
System.err.println$S("Failed to send event to server.");
} else {
throw e1;
}
}
});
var $b$ = new Int8Array(1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.JmolTouchSimulator, "TouchData", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['type','id','x','y'],'J',['when','delay']]]

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.JmolTouchSimulator, "TouchDataComparator", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'java.util.Comparator');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$com_sparshui_inputdevice_JmolTouchSimulator_TouchData$com_sparshui_inputdevice_JmolTouchSimulator_TouchData','compare$O$O'],  function (o1, o2) {
return (Long.$eq(o1.delay,o2.delay ) ? (Long.$lt(o1.when,o2.when ) ? -1 : 1) : Long.$lt(o1.delay,o2.delay ) ? -1 : 1);
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.JmolTouchSimulator, "TouchTimerTask", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'java.util.TimerTask');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['data','com.sparshui.inputdevice.JmolTouchSimulator.TouchData']]]

Clazz.newMeth(C$, 'c$$com_sparshui_inputdevice_JmolTouchSimulator_TouchData',  function (data) {
Clazz.super_(C$, this);
this.data=data;
}, 1);

Clazz.newMeth(C$, 'run$',  function () {
$I$(1).currentThread$().setName$S("JmolTouchSimulator for type " + this.data.id);
this.b$['com.sparshui.inputdevice.JmolTouchSimulator'].dispatchTouchEvent$com_sparshui_inputdevice_JmolTouchSimulator_TouchData.apply(this.b$['com.sparshui.inputdevice.JmolTouchSimulator'], [this.data]);
var iid=Integer.valueOf$I(this.data.id);
if (this.data.type == 1) {
this.b$['com.sparshui.inputdevice.JmolTouchSimulator']._active.remove$O(iid);
} else {
this.b$['com.sparshui.inputdevice.JmolTouchSimulator']._active.put$O$O(iid, this.data);
}$I$(1).currentThread$().setName$S("JmolTouchSimulator idle");
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 17:33:31 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
