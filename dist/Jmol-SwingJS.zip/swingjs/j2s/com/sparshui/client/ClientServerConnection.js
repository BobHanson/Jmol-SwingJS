(function(){var P$=Clazz.newPackage("com.sparshui.client"),I$=[[0,'java.net.Socket','java.io.DataOutputStream','com.sparshui.client.ClientToServerProtocol','Thread']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ClientServerConnection", null, 'Thread');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['_client','com.sparshui.client.SparshClient','_socket','java.net.Socket','_protocol','com.sparshui.client.ClientToServerProtocol']]]

Clazz.newMeth(C$, 'c$$S$com_sparshui_client_SparshClient',  function (address, client) {
Clazz.super_(C$, this);
this._client=client;
this._socket=Clazz.new_($I$(1,1).c$$S$I,[address, 5946]);
var out=Clazz.new_([this._socket.getOutputStream$()],$I$(2,1).c$$java_io_OutputStream);
out.writeByte$I(0);
this._protocol=Clazz.new_($I$(3,1).c$$java_net_Socket,[this._socket]);
this.start$();
}, 1);

Clazz.newMeth(C$, 'run$',  function () {
$I$(4).currentThread$().setName$S("SparshUI Client->ServerConnection");
while (this._socket.isConnected$()){
if (!this._protocol.processRequest$com_sparshui_client_SparshClient(this._client)) break;
}
});

Clazz.newMeth(C$, 'close$',  function () {
try {
this._socket.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 17:33:31 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
