(function(){var P$=Clazz.newPackage("com.sparshui.client"),p$1={},I$=[[0,'com.sparshui.common.utils.Converter','com.sparshui.common.messages.events.DragEvent','com.sparshui.common.messages.events.RotateEvent','com.sparshui.common.messages.events.SpinEvent','com.sparshui.common.messages.events.TouchEvent','com.sparshui.common.messages.events.ZoomEvent','com.sparshui.common.messages.events.FlickEvent','com.sparshui.common.messages.events.RelativeDragEvent','com.sparshui.common.Location']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ClientToServerProtocol", null, 'com.sparshui.common.ClientProtocol');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$java_net_Socket',  function (socket) {
;C$.superclazz.c$$java_net_Socket.apply(this,[socket]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'processRequest$com_sparshui_client_SparshClient',  function (client) {
try {
var type=this._in.readByte$();
var length=this._in.readInt$();
var data=Clazz.array(Byte.TYPE, [length]);
if (length > 0) this._in.readFully$BA(data);
switch (type) {
case 0:
p$1.handleEvents$com_sparshui_client_SparshClient$BA.apply(this, [client, data]);
break;
case 1:
p$1.handleGetGroupID$com_sparshui_client_SparshClient$BA.apply(this, [client, data]);
break;
case 2:
p$1.handleGetAllowedGestures$com_sparshui_client_SparshClient$BA.apply(this, [client, data]);
break;
}
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
System.err.println$S("[Client Protocol] GestureServer Connection Lost");
p$1.handleEvents$com_sparshui_client_SparshClient$BA.apply(this, [client, null]);
return false;
} else {
throw e;
}
}
return true;
});

Clazz.newMeth(C$, 'handleEvents$com_sparshui_client_SparshClient$BA',  function (client, data) {
if (data == null ) {
client.processEvent$I$com_sparshui_common_Event(-1, null);
return;
}if (data.length < 1) {
return;
}var groupID=$I$(1).byteArrayToInt$BA(data);
var eventType=$I$(1).byteArrayToInt$BA$I(data, 4);
var newData=Clazz.array(Byte.TYPE, [data.length - 8]);
System.arraycopy$O$I$O$I$I(data, 8, newData, 0, data.length - 8);
var event=null;
switch (eventType) {
case -2:
client.processEvent$I$com_sparshui_common_Event(-2, null);
return;
case 0:
event=Clazz.new_($I$(2,1).c$$BA,[newData]);
break;
case 1:
event=Clazz.new_($I$(3,1).c$$BA,[newData]);
break;
case 2:
event=Clazz.new_($I$(4,1));
break;
case 3:
event=Clazz.new_($I$(5,1).c$$BA,[newData]);
break;
case 4:
event=Clazz.new_($I$(6,1).c$$BA,[newData]);
break;
case 6:
event=Clazz.new_($I$(7,1).c$$BA,[newData]);
break;
case 7:
event=Clazz.new_($I$(8,1).c$$BA,[newData]);
break;
}
if (event != null ) client.processEvent$I$com_sparshui_common_Event(groupID, event);
}, p$1);

Clazz.newMeth(C$, 'handleGetGroupID$com_sparshui_client_SparshClient$BA',  function (client, data) {
this._out.writeInt$I(client.getGroupID$com_sparshui_common_Location(Clazz.new_([$I$(1).byteArrayToFloat$BA$I(data, 0), $I$(1).byteArrayToFloat$BA$I(data, 4)],$I$(9,1).c$$F$F)));
}, p$1);

Clazz.newMeth(C$, 'handleGetAllowedGestures$com_sparshui_client_SparshClient$BA',  function (client, data) {
var gType;
var gestureTypes=client.getAllowedGestures$I($I$(1).byteArrayToInt$BA(data));
var length=(gestureTypes == null  ? 0 : gestureTypes.size$());
var blen=length * 4;
for (var i=0; i < length; i++) {
gType=gestureTypes.get$I(i);
if (gType.sType != null ) blen+=gType.sType.length$();
}
this._out.writeInt$I(blen);
for (var i=0; i < length; i++) {
gType=gestureTypes.get$I(i);
if (gType.sType == null ) {
this._out.writeInt$I(gType.iType);
} else {
var len=gType.sType.length$();
if (len > 0) {
this._out.writeInt$I(-len);
this._out.write$BA($I$(1).stringToByteArray$S(gType.sType));
}}}
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 17:33:31 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
