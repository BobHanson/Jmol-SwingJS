(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.median"),I$=[[0,'StringBuilder','com.actelion.research.calc.regression.ParameterRegressionMethod']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ParameterMedian", null, 'com.actelion.research.calc.regression.ParameterRegressionMethod');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$S.apply(this,["Median"]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, ['compareTo$com_actelion_research_calc_regression_ParameterRegressionMethod','compareTo$O'],  function (o) {
var cmp=0;
return cmp;
});

Clazz.newMeth(C$, 'decodeProperties2Parameter$',  function () {
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(1,1).c$$S,["ParameterMedian{"]);
sb.append$S("name=").append$S(this.getName$());
sb.append$C("}");
return sb.toString();
});

Clazz.newMeth(C$, 'getHeader$',  function () {
var li=$I$(2).getHeader$();
return li;
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:27 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
