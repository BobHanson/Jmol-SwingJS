(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.neuralnetwork"),I$=[[0,['smile.regression.NeuralNetwork','.ActivationFunction'],'com.actelion.research.calc.ArrayUtilsCalc','com.actelion.research.calc.regression.neuralnetwork.NeuralNetworkParameterHelper','com.actelion.research.calc.regression.ParameterRegressionMethod','StringBuilder','java.util.Arrays','java.io.File']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ParameterNeuralNetwork", null, 'com.actelion.research.calc.regression.ParameterRegressionMethod');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['arrInnerLayerArchitecture','int[]','activationFunction','smile.regression.NeuralNetwork.ActivationFunction']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$S.apply(this,["Neural network regression"]);C$.$init$.apply(this);
this.setActivationFunction$smile_regression_NeuralNetwork_ActivationFunction($I$(1).LOGISTIC_SIGMOID);
this.setArrInnerLayerArchitecture$IA(Clazz.array(Integer.TYPE, [0]));
}, 1);

Clazz.newMeth(C$, ['compareTo$com_actelion_research_calc_regression_ParameterRegressionMethod','compareTo$O'],  function (o) {
var cmp=0;
var p=o;
return cmp;
});

Clazz.newMeth(C$, 'setArrInnerLayerArchitecture$IA',  function (arrInnerLayerArchitecture) {
this.arrInnerLayerArchitecture=arrInnerLayerArchitecture;
this.properties.put$O$O("InnerLayerArchitecture", $I$(2).toString$IA(arrInnerLayerArchitecture));
});

Clazz.newMeth(C$, 'setActivationFunction$smile_regression_NeuralNetwork_ActivationFunction',  function (activationFunction) {
this.properties.put$O$O("ActivationFunction", $I$(3).getActivationFunctionName$smile_regression_NeuralNetwork_ActivationFunction(activationFunction));
this.activationFunction=activationFunction;
});

Clazz.newMeth(C$, 'getActivationFunction$',  function () {
return this.activationFunction;
});

Clazz.newMeth(C$, 'getArrInnerLayerArchitecture$',  function () {
return this.arrInnerLayerArchitecture;
});

Clazz.newMeth(C$, 'getHeader$',  function () {
var li=$I$(4).getHeader$();
li.add$O("ActivationFunction");
li.add$O("InnerLayerArchitecture");
return li;
}, 1);

Clazz.newMeth(C$, 'decodeProperties2Parameter$',  function () {
var sActivationFctType=this.properties.getProperty$S("ActivationFunction");
this.activationFunction=$I$(3).getActivationFunction$S(sActivationFctType);
var sArrInnerLayerArchitecture=this.properties.getProperty$S("InnerLayerArchitecture");
this.arrInnerLayerArchitecture=$I$(2).readIntArray$S(sArrInnerLayerArchitecture);
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(5,1).c$$S,["ParameterNeuralNetwork{"]);
sb.append$S("arrInnerLayerArchitecture=").append$S($I$(6).toString$IA(this.arrInnerLayerArchitecture));
sb.append$S(", activationFunction=").append$S($I$(3).getActivationFunctionName$smile_regression_NeuralNetwork_ActivationFunction(this.activationFunction));
sb.append$C("}");
return sb.toString();
});

Clazz.newMeth(C$, 'main$SA',  function (args) {
var dir=Clazz.new_($I$(7,1).c$$S,["/home/korffmo1/tmp/tmp00"]);
var fiProp=Clazz.new_($I$(7,1).c$$java_io_File$S,[dir, "neuralNetwork.properties"]);
var parameter=Clazz.new_(C$);
parameter.setActivationFunction$smile_regression_NeuralNetwork_ActivationFunction($I$(1).LOGISTIC_SIGMOID);
parameter.setArrInnerLayerArchitecture$IA(Clazz.array(Integer.TYPE, -1, [512, 64, 32, 8, 64]));
parameter.write$java_io_File(fiProp);
var parameterIn=Clazz.new_(C$);
parameterIn.read$java_io_File(fiProp);
System.out.println$S(parameterIn.toString());
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:27 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
