(function(){var P$=Clazz.newPackage("com.actelion.research.calc.histogram"),I$=[[0,'StringBuilder','java.util.Random']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "IntegerHistogram");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['+arrBins','arrCounts','int[]']]
,['O',['ARR_BINS_EXAMPLE','int[][]']]]

Clazz.newMeth(C$, 'c$$IAA',  function (arrBins) {
C$.c$$IAA$Z.apply(this, [arrBins, true]);
}, 1);

Clazz.newMeth(C$, 'c$$IAA$Z',  function (arrBins, consecutive) {
;C$.$init$.apply(this);
this.arrBins=arrBins;
this.arrCounts=Clazz.array(Integer.TYPE, [arrBins.length]);
if (consecutive) {
for (var i=1; i < arrBins.length; i++) {
if (arrBins[i - 1][1] != arrBins[i][0]) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Non consecutive bins!"]);
}}
}}, 1);

Clazz.newMeth(C$, 'add$I',  function (v) {
for (var i=0; i < this.arrBins.length; i++) {
if ((v >= this.arrBins[i][0]) && (v < this.arrBins[i][1]) ) {
++this.arrCounts[i];
}}
});

Clazz.newMeth(C$, 'add$IA',  function (a) {
for (var i=0; i < a.length; i++) {
this.add$I(a[i]);
}
});

Clazz.newMeth(C$, 'add$java_util_List',  function (li) {
for (var i=0; i < li.size$(); i++) {
this.add$I((li.get$I(i)).$c());
}
});

Clazz.newMeth(C$, 'getTotalCounts$',  function () {
var c=0;
for (var i=0; i < this.arrBins.length; i++) {
c+=this.arrCounts[i];
}
return c;
});

Clazz.newMeth(C$, 'getBinWithNPercentOfAllCounts$I',  function (percent) {
var nTotal=this.getTotalCounts$();
var nPercent=((nTotal * (percent / 100.0))|0);
var c=0;
var index=-1;
for (var i=0; i < this.arrBins.length; i++) {
c+=this.arrCounts[i];
if (c >= nPercent) {
index=i;
break;
}}
var bin=Clazz.array(Integer.TYPE, [2]);
bin[0]=this.arrBins[index][0];
bin[1]=this.arrBins[index][1];
return bin;
});

Clazz.newMeth(C$, 'toString',  function () {
var sep="\t";
var arrLenOut=Clazz.array(Integer.TYPE, [this.arrCounts.length]);
for (var i=0; i < this.arrBins.length; i++) {
var max=this.arrCounts[i];
if (this.arrBins[i][0] > max) {
max=this.arrBins[i][0];
}if (this.arrBins[i][1] > max) {
max=this.arrBins[i][1];
}var sVal=Integer.toString$I(max);
arrLenOut[i]=sVal.length$() + 1;
}
var sb=Clazz.new_($I$(1,1));
for (var i=0; i < this.arrBins.length; i++) {
var s=Integer.toString$I(this.arrBins[i][0]);
var sb0=Clazz.new_($I$(1,1).c$$S,[s]);
while (sb0.length$() < arrLenOut[i]){
sb0.append$S(" ");
}
sb.append$CharSequence(sb0);
}
sb.append$S("\n");
for (var i=0; i < this.arrBins.length; i++) {
var s=Integer.toString$I(this.arrBins[i][1]);
var sb0=Clazz.new_($I$(1,1).c$$S,[s]);
while (sb0.length$() < arrLenOut[i]){
sb0.append$S(" ");
}
sb.append$CharSequence(sb0);
}
sb.append$S("\n");
for (var i=0; i < this.arrCounts.length; i++) {
var s=Integer.toString$I(this.arrCounts[i]);
var sb0=Clazz.new_($I$(1,1).c$$S,[s]);
while (sb0.length$() < arrLenOut[i]){
sb0.append$S(" ");
}
sb.append$CharSequence(sb0);
}
return sb.toString();
});

Clazz.newMeth(C$, 'main$SA',  function (args) {
var n=10000;
var max=1000;
var bins=20;
var arrBins=C$.getBinsEquallyDistributed$I$I(bins, max);
var ih=Clazz.new_(C$.c$$IAA,[arrBins]);
var rnd=Clazz.new_($I$(2,1));
for (var i=0; i < n; i++) {
ih.add$I(rnd.nextInt$I(max));
}
System.out.println$S(ih.toString());
}, 1);

Clazz.newMeth(C$, 'getBinsEquallyDistributed$I$I',  function (bins, maxValue) {
return C$.getBinsEquallyDistributed$I$I$I(bins, 0, maxValue);
}, 1);

Clazz.newMeth(C$, 'getBinsEquallyDistributed$I$I$I',  function (bins, minValue, maxValue) {
var rangeBin=((maxValue - minValue)/bins|0);
if (bins > maxValue - minValue) {
rangeBin=1;
bins=maxValue - minValue + 1;
}var arr=Clazz.array(Integer.TYPE, [bins, null]);
var binStart=minValue;
for (var i=0; i < bins; i++) {
var binEnd=binStart + rangeBin;
var bin=Clazz.array(Integer.TYPE, [2]);
bin[0]=binStart;
bin[1]=binEnd;
binStart=binEnd;
arr[i]=bin;
}
if (arr[arr.length - 1][1] <= maxValue) {
arr[arr.length - 1][1]=maxValue + 1;
}return arr;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.ARR_BINS_EXAMPLE=Clazz.array(Integer.TYPE, -2, [Clazz.array(Integer.TYPE, -1, [1, 2]), Clazz.array(Integer.TYPE, -1, [2, 3]), Clazz.array(Integer.TYPE, -1, [3, 4]), Clazz.array(Integer.TYPE, -1, [4, 5]), Clazz.array(Integer.TYPE, -1, [5, 6]), Clazz.array(Integer.TYPE, -1, [6, 8]), Clazz.array(Integer.TYPE, -1, [8, 10]), Clazz.array(Integer.TYPE, -1, [10, 20]), Clazz.array(Integer.TYPE, -1, [20, 50]), Clazz.array(Integer.TYPE, -1, [50, 100]), Clazz.array(Integer.TYPE, -1, [100, 1000])]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
