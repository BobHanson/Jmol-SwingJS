(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.linear.pls"),I$=[[0,'com.actelion.research.calc.Matrix','com.actelion.research.calc.MatrixFunctions','com.actelion.research.calc.MatrixTests']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SimPLS");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['R','com.actelion.research.calc.Matrix','+T','+P','+Q','+U','+V','+B','+EX','+EY','+ES']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.R=Clazz.new_($I$(1,1));
this.T=Clazz.new_($I$(1,1));
this.P=Clazz.new_($I$(1,1));
this.Q=Clazz.new_($I$(1,1));
this.U=Clazz.new_($I$(1,1));
this.V=Clazz.new_($I$(1,1));
this.B=Clazz.new_($I$(1,1));
this.EX=Clazz.new_($I$(1,1));
this.EY=Clazz.new_($I$(1,1));
this.ES=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'invLinReg_Yhat$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (B, Xtrain, Xtest, Ytrain) {
var XTestCentered=Clazz.new_($I$(1,1).c$$com_actelion_research_calc_Matrix,[Xtest]);
var YdachC=Clazz.new_($I$(1,1));
var Ydach=Clazz.new_([Xtest.getRowDim$(), Ytrain.getColDim$()],$I$(1,1).c$$I$I);
var maMeanColXTrain=Xtrain.getMeanCols$();
var arrMeanColXTrain=maMeanColXTrain.toArray$();
if (B.getMaximumValue$() < 1.7976931348623157E308 ) {
var rowsTest=Xtest.rows$();
var cols=Xtrain.cols$();
for (var i=0; i < rowsTest; i++) {
var arrRow=XTestCentered.getRow$I(i);
for (var j=0; j < cols; j++) {
arrRow[j]-=arrMeanColXTrain[j];
}
}
YdachC=XTestCentered.multiply$com_actelion_research_calc_Matrix(B);
for (var i=0; i < Ytrain.getColDim$(); i++) {
var meanYtrain=Ytrain.getMeanCol$I(i);
for (var j=0; j < Ydach.getRowDim$(); j++) {
var valDecentered=YdachC.get$I$I(j, i) + meanYtrain;
Ydach.set$I$I$D(j, i, valDecentered);
}
}
} else {
Ydach.resize$I$I(Xtest.getRowDim$(), Ytrain.getColDim$());
Ydach.set$D(2147483647);
}return Ydach;
}, 1);

Clazz.newMeth(C$, 'invLinReg_Yhat$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (BFromCentered, Xtest) {
var Ydach=Clazz.new_($I$(1,1));
if (BFromCentered.getMaximumValue$() < 1.7976931348623157E308 ) {
Ydach=Xtest.multiply$com_actelion_research_calc_Matrix(BFromCentered);
} else {
Ydach.resize$I$I(Xtest.getRowDim$(), BFromCentered.cols$());
Ydach.set$D(2147483647);
}return Ydach;
}, 1);

Clazz.newMeth(C$, 'getExplainedVarS$',  function () {
return this.ES;
});

Clazz.newMeth(C$, 'getExplainedVarX$',  function () {
return this.EX;
});

Clazz.newMeth(C$, 'getExplainedVarY$',  function () {
return this.EY;
});

Clazz.newMeth(C$, 'getP$',  function () {
return this.P;
});

Clazz.newMeth(C$, 'getQ$',  function () {
return this.Q;
});

Clazz.newMeth(C$, 'getR$',  function () {
return this.R;
});

Clazz.newMeth(C$, 'getT$',  function () {
return this.T;
});

Clazz.newMeth(C$, 'getU$',  function () {
return this.U;
});

Clazz.newMeth(C$, 'getV$',  function () {
return this.V;
});

Clazz.newMeth(C$, 'simPlsSave$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$I',  function (Xtrain, Ytrain, facmax) {
var Y0=Clazz.new_($I$(1,1).c$$com_actelion_research_calc_Matrix,[Ytrain]);
var Qd;
var S=Xtrain.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, Y0);
var d=Clazz.new_($I$(1,1));
var e=Clazz.new_($I$(1,1));
var q=Clazz.new_($I$(1,1));
var r;
var t;
var p;
var u;
var v;
var vp;
var vSP;
var sq;
var TP;
var VP;
this.B=null;
this.EX=null;
this.EY=null;
this.ES=null;
var fac;
var facposs=0;
fac=facmax;
if (Xtrain.getRowDim$() <= Xtrain.getColDim$()) facposs=Xtrain.getRowDim$();
 else if (Xtrain.getRowDim$() > Xtrain.getColDim$()) facposs=Xtrain.getColDim$();
if (fac > facposs) fac=facposs;
for (var a=1; a < fac + 1; a++) {
Qd=S.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, S);
$I$(1,"getEigenvector$com_actelion_research_calc_Matrix$I$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix",[Qd, Qd.getRowDim$(), d, e]);
var index=0;
var dMax=d.get$I$I(0, 0);
for (var i=1; i < d.getRowDim$(); i++) {
if (dMax < d.get$I$I(i, 0) ) {
dMax=d.get$I$I(i, 0);
index=i;
}}
q.resize$I$I(Qd.getRowDim$(), 1);
for (var i=0; i < d.getRowDim$(); i++) q.set$I$I$D(i, 0, Qd.get$I$I(i, index));

r=S.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, q);
t=Xtrain.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, r);
t=t.getCenteredMatrix$();
sq=t.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, t);
if (Math.sqrt(sq.get$I$I(0, 0)) > 1.0E-49 ) {
var normt=Math.sqrt(sq.get$I$I(0, 0));
t=t.devide$D(normt);
r=r.devide$D(normt);
} else {
System.err.println$S("Division by ZERO error in SimPls(...), normt. Factor " + a + "." );
break;
}p=Xtrain.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, t);
q=Y0.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, t);
u=Y0.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, q);
v=p;
if (a > 1) {
VP=this.V.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, p);
v=v.subtract$com_actelion_research_calc_Matrix(this.V.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, VP));
TP=this.T.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, u);
u=u.subtract$com_actelion_research_calc_Matrix(this.T.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, TP));
}vp=v.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, v);
if (vp.get$I$I(0, 0) > 1.0E-49 ) {
var normv=Math.sqrt(vp.get$I$I(0, 0));
v=v.devide$D(normv);
} else {
System.err.println$S("Division by ZERO error in SimPlsSave(...), normv. Factor " + a + "." );
break;
}vSP=v.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, S);
S=S.subtract$com_actelion_research_calc_Matrix(v.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, vSP));
this.R.resize$I$I(r.getRowDim$(), a);
this.R.assignCol$I$com_actelion_research_calc_Matrix(a - 1, r);
this.T.resize$I$I(t.getRowDim$(), a);
this.T.assignCol$I$com_actelion_research_calc_Matrix(a - 1, t);
this.P.resize$I$I(p.getRowDim$(), a);
this.P.assignCol$I$com_actelion_research_calc_Matrix(a - 1, p);
this.Q.resize$I$I(q.getRowDim$(), a);
this.Q.assignCol$I$com_actelion_research_calc_Matrix(a - 1, q);
this.U.resize$I$I(u.getRowDim$(), a);
this.U.assignCol$I$com_actelion_research_calc_Matrix(a - 1, u);
this.V.resize$I$I(v.getRowDim$(), a);
this.V.assignCol$I$com_actelion_research_calc_Matrix(a - 1, v);
}
});

Clazz.newMeth(C$, 'simPlsSaveExplainedVariance$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$I',  function (Xtrain, Ytrain, facmax) {
var Y0=Clazz.new_($I$(1,1).c$$com_actelion_research_calc_Matrix,[Ytrain]);
var Qd;
var S=Xtrain.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, Y0);
var Sorig=Clazz.new_($I$(1,1).c$$com_actelion_research_calc_Matrix,[S]);
var d=Clazz.new_($I$(1,1));
var e=Clazz.new_($I$(1,1));
var q=Clazz.new_($I$(1,1));
var r;
var t;
var p;
var u;
var v;
var vp;
var vSP;
var sq;
var TP;
var VP;
var h;
var varX;
var varY;
var qt;
var tmp;
var fac;
var facposs=0;
fac=facmax;
if (Xtrain.getRowDim$() <= Xtrain.getColDim$()) facposs=Xtrain.getRowDim$();
 else if (Xtrain.getRowDim$() > Xtrain.getColDim$()) facposs=Xtrain.getColDim$();
if (fac > facposs) fac=facposs;
for (var a=1; a < fac + 1; a++) {
Qd=S.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, S);
$I$(1,"getEigenvector$com_actelion_research_calc_Matrix$I$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix",[Qd, Qd.getRowDim$(), d, e]);
var index=0;
var dMax=d.get$I$I(0, 0);
for (var i=1; i < d.getRowDim$(); i++) {
if (dMax < d.get$I$I(i, 0) ) {
dMax=d.get$I$I(i, 0);
index=i;
}}
q.resize$I$I(Qd.getRowDim$(), 1);
for (var i=0; i < d.getRowDim$(); i++) q.set$I$I$D(i, 0, Qd.get$I$I(i, index));

r=S.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, q);
t=Xtrain.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, r);
t=t.getCenteredMatrix$();
sq=t.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, t);
if (Math.sqrt(sq.get$I$I(0, 0)) > 1.0E-49 ) {
var normt=Math.sqrt(sq.get$I$I(0, 0));
t=t.devide$D(normt);
r=r.devide$D(normt);
} else {
System.err.println$S("Division by ZERO error in SimPlsSave(...), normt. Factor " + a + "." );
break;
}p=Xtrain.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, t);
q=Y0.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, t);
u=Y0.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, q);
v=p;
if (a > 1) {
VP=this.V.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, p);
v=v.subtract$com_actelion_research_calc_Matrix(this.V.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, VP));
TP=this.T.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, u);
u=u.subtract$com_actelion_research_calc_Matrix(this.T.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, TP));
}vp=v.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, v);
if (vp.get$I$I(0, 0) > 1.0E-49 ) {
var normv=Math.sqrt(vp.get$I$I(0, 0));
v=v.devide$D(normv);
} else {
System.err.println$S("Division by ZERO error in SimPlsSave(...), normv. Factor " + a + "." );
break;
}vSP=v.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, S);
S=S.subtract$com_actelion_research_calc_Matrix(v.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, vSP));
this.R.resize$I$I(r.getRowDim$(), a);
this.R.assignCol$I$com_actelion_research_calc_Matrix(a - 1, r);
this.T.resize$I$I(t.getRowDim$(), a);
this.T.assignCol$I$com_actelion_research_calc_Matrix(a - 1, t);
this.P.resize$I$I(p.getRowDim$(), a);
this.P.assignCol$I$com_actelion_research_calc_Matrix(a - 1, p);
this.Q.resize$I$I(q.getRowDim$(), a);
this.Q.assignCol$I$com_actelion_research_calc_Matrix(a - 1, q);
this.U.resize$I$I(u.getRowDim$(), a);
this.U.assignCol$I$com_actelion_research_calc_Matrix(a - 1, u);
this.V.resize$I$I(v.getRowDim$(), a);
this.V.assignCol$I$com_actelion_research_calc_Matrix(a - 1, v);
var Xhat=this.T.multiply$Z$Z$com_actelion_research_calc_Matrix(false, true, this.P);
var corrEX=$I$(2).getCorrPearson$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(Xhat, Xtrain);
this.EX.resize$I$I(1, a);
this.EX.set$I$I$D(0, a - 1, corrEX);
tmp=r.multiply$Z$Z$com_actelion_research_calc_Matrix(false, true, q);
this.B.resize$I$I(tmp.getRowDim$(), tmp.getColDim$());
this.B=this.B.plus$com_actelion_research_calc_Matrix(tmp);
var Yhat=Xtrain.multiply$com_actelion_research_calc_Matrix(this.B);
this.EY.resize$I$I(1, a);
var corrEY=$I$(2).getCorrPearson$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(Yhat, Y0);
this.EY.set$I$I$D(0, a - 1, corrEY);
var Shat=Xhat.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, Yhat);
var corrES=$I$(2).getCorrPearson$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(Shat, Sorig);
this.ES.resize$I$I(1, a);
this.ES.set$I$I$D(0, a - 1, corrES);
}
});

Clazz.newMeth(C$, 'explainedVariance$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (A, Ahat) {
var mean=0;
var percent=null;
percent=A.devideDivisorBigger$com_actelion_research_calc_Matrix(Ahat);
System.out.println$S("percent\n" + percent.toString$I(3));
mean=Math.abs(percent.getMean$());
return mean;
}, 1);

Clazz.newMeth(C$, 'simPlsSave$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$I',  function (Xtrain, Ytrain, Xtest, Ytest, facmax) {
var Y0=Clazz.new_($I$(1,1).c$$com_actelion_research_calc_Matrix,[Ytrain]);
var Qd;
var S=Xtrain.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, Y0);
var d=Clazz.new_($I$(1,1));
var e=Clazz.new_($I$(1,1));
var q=Clazz.new_($I$(1,1));
var r;
var t;
var p;
var u;
var v;
var vp;
var vSP;
var sq;
var TP;
var VP;
var h;
var varX;
var varY;
var qt;
var tmp;
var fac;
var facposs=0;
fac=facmax;
if (Xtrain.getRowDim$() <= Xtrain.getColDim$()) facposs=Xtrain.getRowDim$();
 else if (Xtrain.getRowDim$() > Xtrain.getColDim$()) facposs=Xtrain.getColDim$();
if (fac > facposs) fac=facposs;
for (var a=1; a < fac + 1; a++) {
Qd=S.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, S);
$I$(1,"getEigenvector$com_actelion_research_calc_Matrix$I$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix",[Qd, Qd.getRowDim$(), d, e]);
var index=0;
var dMax=d.get$I$I(0, 0);
for (var i=1; i < d.getRowDim$(); i++) {
if (dMax < d.get$I$I(i, 0) ) {
dMax=d.get$I$I(i, 0);
index=i;
}}
q.resize$I$I(Qd.getRowDim$(), 1);
for (var i=0; i < d.getRowDim$(); i++) q.set$I$I$D(i, 0, Qd.get$I$I(i, index));

r=S.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, q);
t=Xtrain.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, r);
t=t.getCenteredMatrix$();
sq=t.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, t);
if (Math.sqrt(sq.get$I$I(0, 0)) > 1.0E-49 ) {
var normt=Math.sqrt(sq.get$I$I(0, 0));
t=t.devide$D(normt);
r=r.devide$D(normt);
} else {
System.err.println$S("Division by ZERO error in SimPlsSave(...), normt.");
this.B.set$D(3.4028235E38);
break;
}p=Xtrain.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, t);
q=Y0.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, t);
u=Y0.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, q);
v=p;
if (a > 1) {
VP=this.V.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, p);
v=v.subtract$com_actelion_research_calc_Matrix(this.V.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, VP));
TP=this.T.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, u);
u=u.subtract$com_actelion_research_calc_Matrix(this.T.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, TP));
}vp=v.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, v);
if (vp.get$I$I(0, 0) > 1.0E-49 ) {
var normv=Math.sqrt(vp.get$I$I(0, 0));
v=v.devide$D(normv);
} else {
System.err.println$S("Division by ZERO error in SimPlsSave(...), normv.");
this.B.set$D(3.4028235E38);
break;
}vSP=v.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, S);
S=S.subtract$com_actelion_research_calc_Matrix(v.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, vSP));
this.R.resize$I$I(r.getRowDim$(), a);
this.R.assignCol$I$com_actelion_research_calc_Matrix(a - 1, r);
this.T.resize$I$I(t.getRowDim$(), a);
this.T.assignCol$I$com_actelion_research_calc_Matrix(a - 1, t);
this.P.resize$I$I(p.getRowDim$(), a);
this.P.assignCol$I$com_actelion_research_calc_Matrix(a - 1, p);
this.Q.resize$I$I(q.getRowDim$(), a);
this.Q.assignCol$I$com_actelion_research_calc_Matrix(a - 1, q);
this.U.resize$I$I(u.getRowDim$(), a);
this.U.assignCol$I$com_actelion_research_calc_Matrix(a - 1, u);
this.V.resize$I$I(v.getRowDim$(), a);
this.V.assignCol$I$com_actelion_research_calc_Matrix(a - 1, v);
tmp=r.multiply$Z$Z$com_actelion_research_calc_Matrix(false, true, q);
this.B.resize$I$I(tmp.getRowDim$(), tmp.getColDim$());
this.B=this.B.plus$com_actelion_research_calc_Matrix(tmp);
}
});

Clazz.newMeth(C$, 'getT$com_actelion_research_calc_Matrix',  function (XPreprocessed) {
var Tcalc=XPreprocessed.multiply$com_actelion_research_calc_Matrix(this.getR$());
return Tcalc;
});

Clazz.newMeth(C$, 'main$SA',  function (args) {
var X=$I$(3).testDescriptor01X$();
var Y=$I$(3).testDescriptor01Y$();
var Xc=X.getCenteredMatrix$();
var Yc=Y.getCenteredMatrix$();
var simPLS=Clazz.new_(C$);
var iFactors=2;
simPLS.simPlsSave$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$I(Xc, Yc, iFactors);
System.out.println$S(simPLS.toString$I(4));
var P=simPLS.getP$();
var R=simPLS.getR$();
var U=simPLS.getU$();
var V=simPLS.getV$();
var Q=simPLS.getQ$();
var T=simPLS.getT$();
var That=Xc.multiply$com_actelion_research_calc_Matrix(R);
System.out.println$S("That\n" + That.toString$I(4));
var G=R.multiply$Z$Z$com_actelion_research_calc_Matrix(false, true, Q);
System.out.println$S("U\n" + U.toString$I(4));
System.out.println$S("G\n" + G.toString$I(4));
var Xhat=T.multiply$Z$Z$com_actelion_research_calc_Matrix(false, true, P);
System.out.println$S(Xhat.toString$I(4));
var XG=X.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, G);
System.out.println$S("XG\n" + XG.toString$I(4));
}, 1);

Clazz.newMeth(C$, 'toString$I',  function (iDigits) {
var sOut="";
sOut+="E [%]\n" + this.EX.toString$I(iDigits) + "\n" ;
sOut+="P:\n" + this.P.toString$I(iDigits) + "\n" ;
sOut+="Q:\n" + this.Q.toString$I(iDigits) + "\n" ;
sOut+="R:\n" + this.R.toString$I(iDigits) + "\n" ;
sOut+="T:\n" + this.T.toString$I(iDigits) + "\n" ;
sOut+="U:\n" + this.U.toString$I(iDigits) + "\n" ;
sOut+="V:\n" + this.V.toString$I(iDigits) + "\n" ;
return sOut;
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:33 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
