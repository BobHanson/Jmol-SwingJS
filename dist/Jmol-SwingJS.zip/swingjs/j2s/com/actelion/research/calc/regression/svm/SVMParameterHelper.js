(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.svm"),I$=[[0,'org.machinelearning.svm.libsvm.svm_parameter']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SVMParameterHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'standard$',  function () {
var param=Clazz.new_($I$(1,1));
param.svm_type=0;
param.kernel_type=2;
param.degree=3;
param.gamma=0;
param.coef0=0;
param.nu=0.5;
param.cache_size=100;
param.C=1;
param.eps=0.001;
param.p=0.1;
param.shrinking=1;
param.probability=0;
param.nr_weight=0;
param.weight_label=Clazz.array(Integer.TYPE, [0]);
param.weight=Clazz.array(Double.TYPE, [0]);
return param;
}, 1);

Clazz.newMeth(C$, 'regressionEpsilonSVR$',  function () {
var param=Clazz.new_($I$(1,1));
param.svm_type=3;
param.kernel_type=2;
param.degree=-1;
param.gamma=0;
param.coef0=0;
param.nu=0.5;
param.cache_size=100;
param.C=130;
param.eps=5;
param.p=0.1;
param.shrinking=1;
param.probability=0;
param.nr_weight=0;
param.weight_label=Clazz.array(Integer.TYPE, [0]);
param.weight=Clazz.array(Double.TYPE, [0]);
return param;
}, 1);

Clazz.newMeth(C$, 'regressionNuSVR$D',  function (nu) {
var param=Clazz.new_($I$(1,1));
param.svm_type=4;
param.kernel_type=2;
param.degree=3;
param.gamma=1;
param.coef0=0;
param.nu=nu;
param.cache_size=100;
param.C=1;
param.eps=0.001;
param.p=0.1;
param.shrinking=1;
param.probability=0;
param.nr_weight=0;
param.weight_label=Clazz.array(Integer.TYPE, [0]);
param.weight=Clazz.array(Double.TYPE, [0]);
return param;
}, 1);

Clazz.newMeth(C$, 'getSVMType$I',  function (svmType) {
var strType="";
switch (svmType) {
case 0:
strType="C_SVC";
break;
case 1:
strType="NU_SVC";
break;
case 2:
strType="OneClass";
break;
case 4:
strType="NU_SVR";
break;
case 3:
strType="EpsSVR";
break;
}
return strType;
}, 1);

Clazz.newMeth(C$, 'getSVMType$S',  function (strSVMType) {
var svmType=-1;
if ("C_SVC".equals$O(strSVMType)) {
svmType=0;
} else if ("NU_SVC".equals$O(strSVMType)) {
svmType=1;
} else if ("OneClass".equals$O(strSVMType)) {
svmType=2;
} else if ("NU_SVR".equals$O(strSVMType)) {
svmType=4;
} else if ("EpsSVR".equals$O(strSVMType)) {
svmType=3;
} else {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Unknown svm type " + strSVMType + "." ]);
}return svmType;
}, 1);

Clazz.newMeth(C$, 'getKernelType$I',  function (svmType) {
var strType="";
switch (svmType) {
case 0:
strType="Linear";
break;
case 1:
strType="Poly";
break;
case 2:
strType="RBF";
break;
case 3:
strType="Sigmoid";
break;
case 4:
strType="Precomputed";
break;
}
return strType;
}, 1);

Clazz.newMeth(C$, 'getKernelType$S',  function (strKernelType) {
var svmType=-1;
if ("Linear".equals$O(strKernelType)) {
svmType=0;
} else if ("Poly".equals$O(strKernelType)) {
svmType=1;
} else if ("RBF".equals$O(strKernelType)) {
svmType=2;
} else if ("Sigmoid".equals$O(strKernelType)) {
svmType=3;
} else if ("Precomputed".equals$O(strKernelType)) {
svmType=4;
} else {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Unknown kernel type " + strKernelType + "." ]);
}return svmType;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:06 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
