(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.linear.pls"),I$=[[0,'java.util.Properties','java.io.FileReader','java.io.FileWriter','StringBuilder','com.actelion.research.calc.regression.ParameterRegressionMethod','java.io.File']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ParameterPLS", null, 'com.actelion.research.calc.regression.ParameterRegressionMethod');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['centerData'],'I',['factors']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$S.apply(this,["PLS"]);C$.$init$.apply(this);
this.setFactors$I(3);
this.centerData=true;
}, 1);

Clazz.newMeth(C$, 'c$$I',  function (factors) {
;C$.superclazz.c$$S.apply(this,["PLS"]);C$.$init$.apply(this);
this.setFactors$I(factors);
this.centerData=true;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_calc_regression_linear_pls_ParameterPLS',  function (p) {
;C$.superclazz.c$$com_actelion_research_calc_regression_ParameterRegressionMethod.apply(this,[p]);C$.$init$.apply(this);
this.copy$com_actelion_research_calc_regression_linear_pls_ParameterPLS(p);
}, 1);

Clazz.newMeth(C$, 'copy$com_actelion_research_calc_regression_linear_pls_ParameterPLS',  function (orig) {
C$.superclazz.prototype.copy$com_actelion_research_calc_regression_ParameterRegressionMethod.apply(this, [orig]);
this.setFactors$I(orig.getFactors$());
this.setCenterData$Z(orig.isCenterData$());
});

Clazz.newMeth(C$, 'equals$O',  function (obj) {
if (!(Clazz.instanceOf(obj, "com.actelion.research.calc.regression.linear.pls.ParameterPLS"))) {
return false;
}var eq=true;
var p=obj;
if (!this.getName$().equals$O(p.getName$())) {
eq=false;
}if (this.getFactors$() != p.getFactors$()) {
eq=false;
}return eq;
});

Clazz.newMeth(C$, 'c$$S$I',  function (name, factors) {
;C$.superclazz.c$$S.apply(this,[name]);C$.$init$.apply(this);
this.setFactors$I(factors);
this.centerData=true;
}, 1);

Clazz.newMeth(C$, 'getFactors$',  function () {
return this.factors;
});

Clazz.newMeth(C$, 'setFactors$I',  function (factors) {
this.factors=factors;
this.properties.put$O$O("Factors", Integer.toString$I(factors));
});

Clazz.newMeth(C$, 'isCenterData$',  function () {
return this.centerData;
});

Clazz.newMeth(C$, 'setCenterData$Z',  function (centerData) {
this.centerData=centerData;
});

Clazz.newMeth(C$, 'decodeProperties2Parameter$',  function () {
this.factors=Integer.parseInt$S(this.properties.getProperty$S("Factors"));
});

Clazz.newMeth(C$, ['compareTo$com_actelion_research_calc_regression_ParameterRegressionMethod','compareTo$O'],  function (o) {
var cmp=0;
var parameterPLS=o;
if (this.factors > parameterPLS.factors) {
cmp=1;
} else if (this.factors < parameterPLS.factors) {
cmp=-1;
}return cmp;
});

Clazz.newMeth(C$, 'read$java_io_File',  function (fiProperties) {
var properties=Clazz.new_($I$(1,1));
properties.load$java_io_Reader(Clazz.new_($I$(2,1).c$$java_io_File,[fiProperties]));
var name=properties.getProperty$S("Name");
if (!this.getName$().equals$O(name)) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Name confusion!"]);
}var sFactors=properties.getProperty$S("Factors");
this.factors=Integer.parseInt$S(sFactors);
this.centerData=true;
});

Clazz.newMeth(C$, 'write$java_io_File',  function (fiProperties) {
var properties=Clazz.new_($I$(1,1));
properties.put$O$O("Name", this.getName$());
properties.put$O$O("Factors", Integer.toString$I(this.factors));
properties.store$java_io_Writer$S(Clazz.new_($I$(3,1).c$$java_io_File,[fiProperties]), "");
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(4,1).c$$S,["ParameterPLS{"]);
sb.append$S("name=").append$S(this.getName$());
sb.append$S(" factors=").append$I(this.factors);
sb.append$C("}");
return sb.toString();
});

Clazz.newMeth(C$, 'getHeader$',  function () {
var li=$I$(5).getHeader$();
li.add$O("Factors");
return li;
}, 1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
var dir=Clazz.new_($I$(6,1).c$$S,["/home/korffmo1/tmp/tmp00"]);
var fiProp=Clazz.new_($I$(6,1).c$$java_io_File$S,[dir, "pls.properties"]);
var parameter=Clazz.new_(C$);
parameter.factors=3;
parameter.write$java_io_File(fiProp);
var parameterIn=Clazz.new_(C$);
parameterIn.read$java_io_File(fiProp);
System.out.println$S(parameterIn.toString());
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:27 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
