(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.linear.simple"),I$=[[0,'java.util.Vector','com.actelion.research.util.datamodel.PointDouble','com.actelion.research.util.datamodel.DoubleArray']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "LinearRegression");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['intercept','slope','xMean','yMean'],'O',['v','java.util.Vector','+residuals']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.v=Clazz.new_($I$(1,1));
this.residuals=Clazz.new_($I$(1,1));
this.xMean=0;
this.yMean=0;
}, 1);

Clazz.newMeth(C$, 'addPoint$java_awt_Point',  function (p) {
this.v.addElement$O(Clazz.new_($I$(2,1).c$$java_awt_Point,[p]));
});

Clazz.newMeth(C$, 'addPoint$com_actelion_research_util_datamodel_PointDouble',  function (p) {
this.v.addElement$O(p);
});

Clazz.newMeth(C$, 'addPoint$D$D',  function (x, y) {
this.v.addElement$O(Clazz.new_($I$(2,1).c$$D$D,[x, y]));
});

Clazz.newMeth(C$, 'clear$',  function () {
this.v=Clazz.new_($I$(1,1));
});

Clazz.newMeth(C$, 'getValues$',  function () {
return this.v;
});

Clazz.newMeth(C$, 'getValuesAsArray$',  function () {
var arr=Clazz.array(Double.TYPE, [2, this.v.size$()]);
for (var i=0; i < this.v.size$(); i++) {
arr[0][i]=this.v.get$I(i).x;
arr[1][i]=this.v.get$I(i).y;
}
return arr;
});

Clazz.newMeth(C$, 'getValuesAsArrayX$',  function () {
var arr=Clazz.new_([this.v.size$()],$I$(3,1).c$$I);
for (var i=0; i < this.v.size$(); i++) {
arr.add$D(this.v.get$I(i).x);
}
return arr;
});

Clazz.newMeth(C$, 'getValuesAsArrayY$',  function () {
var arr=Clazz.new_([this.v.size$()],$I$(3,1).c$$I);
for (var i=0; i < this.v.size$(); i++) {
arr.add$D(this.v.get$I(i).y);
}
return arr;
});

Clazz.newMeth(C$, 'regress$',  function () {
this.xMean=0;
this.yMean=0;
for (var p, $p = this.v.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
this.xMean+=p.x;
this.yMean+=p.y;
}
this.xMean/=this.v.size$();
this.yMean/=this.v.size$();
var sxy2=0;
var sxx2=0;
for (var p, $p = this.v.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
sxy2+=(p.x - this.xMean) * (p.y - this.yMean);
sxx2+=(p.x - this.xMean) * (p.x - this.xMean);
}
this.slope=sxy2 / sxx2;
this.intercept=this.yMean - this.slope * this.xMean;
var resid=Clazz.new_($I$(1,1));
var q;
for (var p, $p = this.v.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
var currentResidual=p.y - (this.intercept + this.slope * p.x);
q=Clazz.new_([p.x, (currentResidual|0)],$I$(2,1).c$$D$D);
resid.addElement$O(q);
}
return resid;
});

Clazz.newMeth(C$, 'calculate$',  function () {
if (this.v.size$() > 1) {
this.residuals=this.regress$();
}});

Clazz.newMeth(C$, 'getResiduals$',  function () {
return this.residuals;
});

Clazz.newMeth(C$, 'getMean$',  function () {
return Clazz.new_($I$(2,1).c$$D$D,[this.xMean + 0.5, this.yMean + 0.5]);
});

Clazz.newMeth(C$, 'getIntercept$',  function () {
return this.intercept;
});

Clazz.newMeth(C$, 'getSlope$',  function () {
return this.slope;
});

Clazz.newMeth(C$, 'getXMean$',  function () {
return this.xMean;
});

Clazz.newMeth(C$, 'getYMean$',  function () {
return this.yMean;
});

Clazz.newMeth(C$, 'getY$D',  function (x) {
return this.intercept + this.slope * x;
});

Clazz.newMeth(C$, 'setSlope$D',  function (slope) {
this.slope=slope;
});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:16 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
