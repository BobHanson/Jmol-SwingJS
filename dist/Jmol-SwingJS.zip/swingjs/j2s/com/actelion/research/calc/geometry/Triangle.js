(function(){var P$=Clazz.newPackage("com.actelion.research.calc.geometry"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Triangle");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getArea$D$D$D',  function (sideA, sideB, sideC) {
var s=(sideA + sideB + sideC ) / 2.0;
var a=Math.sqrt(s * (s - sideA) * (s - sideB) * (s - sideC) );
return a;
}, 1);

Clazz.newMeth(C$, 'getAreaRightTriangle$D$D',  function (sideA, sideB) {
var a=(sideA * sideB) / 2.0;
return a;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:15 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
