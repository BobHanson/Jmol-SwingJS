(function(){var P$=Clazz.newPackage("com.actelion.research.calc"),p$1={},I$=[[0,'java.util.concurrent.atomic.AtomicLong','Thread','com.actelion.research.util.datamodel.ScorePoint','Runtime','com.actelion.research.util.Pipeline','java.util.concurrent.ConcurrentLinkedQueue','java.util.ArrayList','com.actelion.research.calc.Matrix','java.util.concurrent.Executors',['com.actelion.research.calc.SimilarityMulticore','.RunSimilarityCalc'],'java.awt.Point']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SimilarityMulticore", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['RunSimilarityCalc',10]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['verbose'],'I',['kernels','similarities2Calculate'],'O',['similarityCalculator','com.actelion.research.chem.descriptor.ISimilarityCalculator','liDescriptor1','java.util.List','+liDescriptor2','sleep','java.util.concurrent.atomic.AtomicLong','queueIndices','com.actelion.research.util.Pipeline','queueScore','java.util.concurrent.ConcurrentLinkedQueue','liRun','java.util.List','calculationsPerSecond','java.util.concurrent.atomic.AtomicLong','maSimilarity','com.actelion.research.calc.Matrix']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_ISimilarityCalculator',  function (similarityCalculator) {
C$.c$$com_actelion_research_chem_descriptor_ISimilarityCalculator$I.apply(this, [similarityCalculator, Math.min($I$(4).getRuntime$().availableProcessors$() - 1, 80)]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_ISimilarityCalculator$I',  function (similarityCalculator, kernels) {
;C$.$init$.apply(this);
this.similarityCalculator=similarityCalculator;
this.kernels=kernels;
this.queueIndices=Clazz.new_($I$(5,1));
this.queueScore=Clazz.new_($I$(6,1));
this.sleep=Clazz.new_($I$(1,1));
this.calculationsPerSecond=Clazz.new_($I$(1,1));
this.verbose=false;
}, 1);

Clazz.newMeth(C$, 'setVerbose$',  function () {
this.verbose=true;
});

Clazz.newMeth(C$, 'run$com_actelion_research_util_datamodel_IdentifiedObject$java_util_List',  function (descriptor, liDescriptor2) {
var liOneSample=Clazz.new_($I$(7,1));
liOneSample.add$O(descriptor);
this.run$java_util_List$java_util_List(liOneSample, liDescriptor2);
});

Clazz.newMeth(C$, 'run$java_util_List',  function (liDescriptor) {
p$1.run$java_util_List$java_util_List$Z.apply(this, [liDescriptor, liDescriptor, true]);
});

Clazz.newMeth(C$, 'run$java_util_List$java_util_List',  function (liDescriptor1, liDescriptor2) {
p$1.run$java_util_List$java_util_List$Z.apply(this, [liDescriptor1, liDescriptor2, false]);
});

Clazz.newMeth(C$, 'run$java_util_List$java_util_List$Z',  function (liDescriptor1, liDescriptor2, singleList) {
this.calculationsPerSecond.set$J(-1);
var t1=Clazz.new_(java.util.Date).getTime$();
this.sleep.set$J(1);
if (this.verbose) {
System.out.println$S("SimilarityMulticore start.");
System.out.println$S("SimilarityMulticore kernels\t" + this.kernels);
}this.liDescriptor1=liDescriptor1;
this.liDescriptor2=liDescriptor2;
if (this.verbose) {
System.out.println$S("liDescriptor1 " + liDescriptor1.size$() + " liDescriptor2 " + liDescriptor2.size$() + "." );
}this.queueScore.clear$();
this.maSimilarity=Clazz.new_([liDescriptor1.size$(), liDescriptor2.size$()],$I$(8,1).c$$I$I);
if (singleList) {
p$1.fillCalculationIndexQueueSingleList.apply(this, []);
} else {
p$1.fillCalculationIndexQueueTwoLists.apply(this, []);
}this.liRun=Clazz.new_($I$(7,1));
var executorService=$I$(9).newFixedThreadPool$I(this.kernels);
for (var i=0; i < this.kernels; i++) {
var rsc=Clazz.new_($I$(10,1).c$$I$com_actelion_research_chem_descriptor_ISimilarityCalculator$com_actelion_research_util_Pipeline$java_util_List$java_util_List$com_actelion_research_calc_Matrix$Z$java_util_concurrent_ConcurrentLinkedQueue,[i, this.similarityCalculator, this.queueIndices, liDescriptor1, liDescriptor2, this.maSimilarity, singleList, this.queueScore]);
this.liRun.add$O(rsc);
executorService.execute$Runnable(rsc);
}
executorService.shutdown$();
while (!executorService.isTerminated$()){
try {
$I$(2).sleep$J(1);
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
} else {
throw e;
}
}
}
var t2=Clazz.new_(java.util.Date).getTime$();
var sec=Long.$div((Long.$sub(t2,t1)),1000);
if (Long.$ne(sec,0 )) {
this.calculationsPerSecond.set$J(Long.$div(this.getCalculatedSimilarityValues$(),sec));
}if (this.verbose) {
System.out.println$S("Similarity calculations " + Long.$s(this.getCalculatedSimilarityValues$()));
System.out.println$S("Similarity calculations per second " + Long.$s(this.calculationsPerSecond.get$()));
var sumCalc=0;
for (var i=0; i < this.liRun.size$(); i++) {
var rsc=this.liRun.get$I(i);
sumCalc=Long.$ival(Long.$add(sumCalc,(rsc.getNSimilarityCalculations$())));
System.out.println$S("Thread " + rsc.getIndexThread$() + " calcs " + Long.$s(rsc.getNSimilarityCalculations$()) );
}
System.out.println$S("Sum calcs " + sumCalc + "." );
}this.sleep.set$J(10);
}, p$1);

Clazz.newMeth(C$, 'getCalculationsPerSecond$',  function () {
return this.calculationsPerSecond.get$();
});

Clazz.newMeth(C$, 'getSimilarities2Calculate$',  function () {
return this.similarities2Calculate;
});

Clazz.newMeth(C$, 'getCalculatedSimilarityValues$',  function () {
var ccCalc=0;
for (var rsc, $rsc = this.liRun.iterator$(); $rsc.hasNext$()&&((rsc=($rsc.next$())),1);) {
(ccCalc=Long.$add(ccCalc,(rsc.getNSimilarityCalculations$())));
}
return ccCalc;
});

Clazz.newMeth(C$, 'isFinished',  function () {
if (!this.queueIndices.isAllDataIn$()) {
return false;
}if (!this.queueIndices.isEmpty$()) {
return false;
}var finished=true;
if (this.queueScore.size$() != this.similarities2Calculate) {
finished=false;
}return finished;
}, p$1);

Clazz.newMeth(C$, 'hasMoreResults$',  function () {
return !this.queueScore.isEmpty$();
});

Clazz.newMeth(C$, 'getNextResult$',  function () {
return this.queueScore.poll$();
});

Clazz.newMeth(C$, 'fillCalculationIndexQueueTwoLists',  function () {
this.queueIndices.setAllDataIn$Z(false);
this.similarities2Calculate=this.liDescriptor1.size$() * this.liDescriptor2.size$();
for (var i=0; i < this.liDescriptor1.size$(); i++) {
for (var j=0; j < this.liDescriptor2.size$(); j++) {
var p=Clazz.new_($I$(11,1).c$$I$I,[i, j]);
this.queueIndices.addData$O(p);
}
}
this.queueIndices.setAllDataIn$Z(true);
if (this.verbose) {
System.out.println$S("SimilarityMulticore sim to calc " + this.similarities2Calculate + "." );
}}, p$1);

Clazz.newMeth(C$, 'fillCalculationIndexQueueSingleList',  function () {
this.queueIndices.setAllDataIn$Z(false);
this.similarities2Calculate=(((this.liDescriptor1.size$() * this.liDescriptor1.size$()) - this.liDescriptor1.size$())/2|0);
for (var i=0; i < this.liDescriptor1.size$(); i++) {
for (var j=i; j < this.liDescriptor1.size$(); j++) {
var p=Clazz.new_($I$(11,1).c$$I$I,[i, j]);
this.queueIndices.addData$O(p);
}
}
this.queueIndices.setAllDataIn$Z(true);
if (this.verbose) {
System.out.println$S("SimilarityMulticore sim to calc " + this.similarities2Calculate + "." );
}}, p$1);

Clazz.newMeth(C$, 'getSimilarityMatrix$',  function () {
return this.maSimilarity;
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.SimilarityMulticore, "RunSimilarityCalc", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'Runnable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['singleList'],'I',['indexThread'],'O',['iSimilarityCalculator','com.actelion.research.chem.descriptor.ISimilarityCalculator','queueIndices','com.actelion.research.util.Pipeline','liDescriptor1','java.util.List','+liDescriptor2','maSimilarity','com.actelion.research.calc.Matrix','queueScore','java.util.concurrent.ConcurrentLinkedQueue','calculatedSimilarities','java.util.concurrent.atomic.AtomicLong']]]

Clazz.newMeth(C$, 'c$$I$com_actelion_research_chem_descriptor_ISimilarityCalculator$com_actelion_research_util_Pipeline$java_util_List$java_util_List$com_actelion_research_calc_Matrix$Z$java_util_concurrent_ConcurrentLinkedQueue',  function (indexThread, similarityCalculator, queueIndices, liDescriptor1, liDescriptor2, maSimilarity, singleList, queueScore) {
;C$.$init$.apply(this);
this.indexThread=indexThread;
this.iSimilarityCalculator=similarityCalculator.getThreadSafeCopy$();
this.queueIndices=queueIndices;
this.liDescriptor1=liDescriptor1;
this.liDescriptor2=liDescriptor2;
this.maSimilarity=maSimilarity;
this.singleList=singleList;
this.queueScore=queueScore;
this.calculatedSimilarities=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'run$',  function () {
while (!this.queueIndices.wereAllDataFetched$()){
var p=this.queueIndices.pollData$();
if (p == null ) {
try {
$I$(2).sleep$J(10);
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
} else {
throw e;
}
}
continue;
}var indexX=p.x;
var indexY=p.y;
var idObj1=null;
idObj1=this.liDescriptor1.get$I(indexX);
var idObj2=null;
idObj2=this.liDescriptor2.get$I(indexY);
var sp=Clazz.new_([Long.$ival(idObj1.getId$()), Long.$ival(idObj2.getId$())],$I$(3,1).c$$I$I);
try {
var sc=this.iSimilarityCalculator.getSimilarity$O$O(idObj1.getData$(), idObj2.getData$());
if (sc < 0.01 ) {
sc=0.01;
}this.calculatedSimilarities.incrementAndGet$();
sp.setScore$D(sc);
this.maSimilarity.set$I$I$D(indexX, indexY, sc);
if (this.singleList) {
this.maSimilarity.set$I$I$D(indexY, indexX, sc);
}this.queueScore.add$O(sp);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
sp.setScore$D(NaN);
this.queueScore.add$O(sp);
e.printStackTrace$();
} else {
throw e;
}
}
}
});

Clazz.newMeth(C$, 'getIndexThread$',  function () {
return this.indexThread;
});

Clazz.newMeth(C$, 'getNSimilarityCalculations$',  function () {
return this.calculatedSimilarities.get$();
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:05 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
