(function(){var P$=Clazz.newPackage("com.actelion.research.calc.statistics.median"),I$=[[0,'StringBuilder']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ModelMedianLong");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['id','size'],'J',['lowerQuartile','median','upperQuartile']]]

Clazz.newMeth(C$, 'range$',  function () {
return Long.$sub(this.upperQuartile,this.lowerQuartile);
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(1,1));
sb.append$J(this.lowerQuartile);
sb.append$S("\t");
sb.append$J(this.median);
sb.append$S("\t");
sb.append$J(this.upperQuartile);
return sb.toString();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:28 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
