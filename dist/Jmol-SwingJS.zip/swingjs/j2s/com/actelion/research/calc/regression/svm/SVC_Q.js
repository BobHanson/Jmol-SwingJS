(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.svm"),p$1={},p$2={},p$3={},I$=[[0,['com.actelion.research.calc.regression.svm.Cache','.head_t'],'com.actelion.research.calc.regression.svm.svm','com.actelion.research.calc.regression.svm.Cache','java.util.Random','com.actelion.research.calc.regression.svm.Solver','com.actelion.research.calc.regression.svm.SVC_Q','com.actelion.research.calc.regression.svm.Solver_NU','com.actelion.research.calc.regression.svm.ONE_CLASS_Q','com.actelion.research.calc.regression.svm.SVR_Q',['com.actelion.research.calc.regression.svm.Solver','.SolutionInfo'],['com.actelion.research.calc.regression.svm.svm','.decision_function'],'org.machinelearning.svm.libsvm.svm_problem','org.machinelearning.svm.libsvm.svm_node','org.machinelearning.svm.libsvm.svm_model','com.actelion.research.calc.regression.svm.Kernel','java.io.DataOutputStream','java.io.BufferedOutputStream','java.io.FileOutputStream','org.machinelearning.svm.libsvm.svm_parameter','java.util.StringTokenizer','java.io.BufferedReader','java.io.FileReader']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SVC_Q", null, 'com.actelion.research.calc.regression.svm.Kernel');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['y','byte[]','cache','com.actelion.research.calc.regression.svm.Cache','QD','double[]']]]

Clazz.newMeth(C$, 'c$$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$BA',  function (prob, param, y_) {
;C$.superclazz.c$$I$org_machinelearning_svm_libsvm_svm_nodeAA$org_machinelearning_svm_libsvm_svm_parameter.apply(this,[prob.l, prob.x, param]);C$.$init$.apply(this);
this.y=y_.clone$();
this.cache=Clazz.new_([prob.l, Clazz.toLong((param.cache_size * (1048576)))],$I$(3,1).c$$I$J);
this.QD=Clazz.array(Double.TYPE, [prob.l]);
for (var i=0; i < prob.l; i++) this.QD[i]=this.kernel_function$I$I(i, i);

}, 1);

Clazz.newMeth(C$, 'get_Q$I$I',  function (i, len) {
var data=Clazz.array(Float.TYPE, [1, null]);
var start;
var j;
if ((start=this.cache.get_data$I$FAA$I(i, data, len)) < len) {
for (j=start; j < len; j++) data[0][j]=(this.y[i] * this.y[j] * this.kernel_function$I$I(i, j) );

}return data[0];
});

Clazz.newMeth(C$, 'get_QD$',  function () {
return this.QD;
});

Clazz.newMeth(C$, 'swap_index$I$I',  function (i, j) {
this.cache.swap_index$I$I(i, j);
C$.superclazz.prototype.swap_index$I$I.apply(this, [i, j]);
do {
var tmp=this.y[i];
this.y[i]=this.y[j];
this.y[j]=tmp;
} while (false);
do {
var tmp=this.QD[i];
this.QD[i]=this.QD[j];
this.QD[j]=tmp;
} while (false);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:05:56 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
