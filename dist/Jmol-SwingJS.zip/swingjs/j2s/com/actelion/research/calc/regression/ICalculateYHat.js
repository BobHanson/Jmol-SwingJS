(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ICalculateYHat");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
