(function(){var P$=Clazz.newPackage("com.actelion.research.calc.classification"),I$=[[0,'StringBuilder','com.actelion.research.util.Formatter']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PrecisionAndRecall", null, null, 'java.io.Serializable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.truePositive=0;
this.trueNegative=0;
this.falsePositive=0;
this.falseNegative=0;
},1);

C$.$fields$=[['I',['truePositive','trueNegative','falsePositive','falseNegative']]]

Clazz.newMeth(C$, 'c$$I$I$I$I',  function (truePositive, trueNegative, falsePositive, falseNegative) {
;C$.$init$.apply(this);
this.truePositive=truePositive;
this.trueNegative=trueNegative;
this.falsePositive=falsePositive;
this.falseNegative=falseNegative;
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'add$com_actelion_research_calc_classification_PrecisionAndRecall',  function (p) {
this.truePositive+=p.truePositive;
this.trueNegative+=p.trueNegative;
this.falsePositive+=p.falsePositive;
this.falseNegative+=p.falseNegative;
});

Clazz.newMeth(C$, 'parse2PrecisionAndRecall$S',  function (sVal) {
if ("TP".equals$O(sVal)) {
++this.truePositive;
} else if ("TN".equals$O(sVal)) {
++this.trueNegative;
} else if ("FP".equals$O(sVal)) {
++this.falsePositive;
} else if ("FN".equals$O(sVal)) {
++this.falseNegative;
} else {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Parsing error for '" + sVal + "'." ]);
}});

Clazz.newMeth(C$, 'getTruePositive$',  function () {
return this.truePositive;
});

Clazz.newMeth(C$, 'setTruePositive$I',  function (truePositive) {
this.truePositive=truePositive;
});

Clazz.newMeth(C$, 'getTrueNegative$',  function () {
return this.trueNegative;
});

Clazz.newMeth(C$, 'setTrueNegative$I',  function (trueNegative) {
this.trueNegative=trueNegative;
});

Clazz.newMeth(C$, 'getFalsePositive$',  function () {
return this.falsePositive;
});

Clazz.newMeth(C$, 'setFalsePositive$I',  function (falsePositive) {
this.falsePositive=falsePositive;
});

Clazz.newMeth(C$, 'getFalseNegative$',  function () {
return this.falseNegative;
});

Clazz.newMeth(C$, 'setFalseNegative$I',  function (falseNegative) {
this.falseNegative=falseNegative;
});

Clazz.newMeth(C$, 'getSum$',  function () {
return this.trueNegative + this.truePositive + this.falsePositive + this.falseNegative ;
});

Clazz.newMeth(C$, 'calculatePrecision$',  function () {
var tp_fp=this.truePositive + this.falsePositive;
if (tp_fp == 0) {
return 0;
}return this.truePositive / (this.truePositive + this.falsePositive);
});

Clazz.newMeth(C$, 'calculateRecall$',  function () {
var tp_fn=this.truePositive + this.falseNegative;
if (tp_fn == 0) {
return 0;
}return this.truePositive / (this.truePositive + this.falseNegative);
});

Clazz.newMeth(C$, 'calculateAccuracy$',  function () {
var acc=(this.truePositive + this.trueNegative) / this.getSum$();
return acc;
});

Clazz.newMeth(C$, 'calculateHarmonicMean$',  function () {
var p=this.calculatePrecision$();
var r=this.calculateRecall$();
if ((p + r) == 0 ) {
return 0;
}var f1=2.0 * (p * r / (p + r));
return f1;
});

Clazz.newMeth(C$, 'calculateCohensKappa$',  function () {
var all=this.getSum$();
var pYes=((this.truePositive + this.falseNegative) / all) * ((this.truePositive + this.falsePositive) / all);
var pNo=((this.falsePositive + this.trueNegative) / all) * ((this.falseNegative + this.trueNegative) / all);
var pe=pYes + pNo;
var po=this.calculateAccuracy$();
var k=(po - pe) / (1.0 - pe);
return k;
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(1,1));
sb.append$S("Accuracy " + $I$(2,"format3$Double",[Double.valueOf$D(this.calculateAccuracy$())]));
sb.append$S(", precision " + $I$(2,"format3$Double",[Double.valueOf$D(this.calculatePrecision$())]));
sb.append$S(", recall " + $I$(2,"format3$Double",[Double.valueOf$D(this.calculateRecall$())]));
sb.append$S(", F1 " + $I$(2,"format3$Double",[Double.valueOf$D(this.calculateHarmonicMean$())]));
sb.append$S(", Cohens' kappa " + $I$(2,"format3$Double",[Double.valueOf$D(this.calculateCohensKappa$())]));
sb.append$S("\n");
sb.append$S("True positive " + this.truePositive);
sb.append$S("\n");
sb.append$S("True negative " + this.trueNegative);
sb.append$S("\n");
sb.append$S("False positive " + this.falsePositive);
sb.append$S("\n");
sb.append$S("False negative " + this.falseNegative);
return sb.toString();
});

Clazz.newMeth(C$, 'getHarmonicMean$java_util_List',  function (li) {
var sum=0;
for (var precisionAndRecall, $precisionAndRecall = li.iterator$(); $precisionAndRecall.hasNext$()&&((precisionAndRecall=($precisionAndRecall.next$())),1);) {
sum+=precisionAndRecall.calculateHarmonicMean$();
}
return sum / li.size$();
}, 1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
var pr=Clazz.new_(C$);
pr.truePositive=20;
pr.trueNegative=15;
pr.falseNegative=5;
pr.falsePositive=10;
System.out.println$S("Cohen's kappa: " + new Double(pr.calculateCohensKappa$()).toString());
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:33 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
