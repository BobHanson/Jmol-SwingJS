(function(){var P$=Clazz.newPackage("com.actelion.research.calc"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ProgressController", null, null, ['com.actelion.research.calc.ProgressListener', 'com.actelion.research.calc.ThreadMaster']);

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:25 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
