(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.svm"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "QMatrix");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:28 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
