(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ConstantsRegressionMethods");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['ARR_MODEL_CODE','String[]','+ARR_MODEL','+ARR_RESULT_EVALUATOR']]]

C$.$static$=function(){C$.$static$=0;
C$.ARR_MODEL_CODE=Clazz.array(String, -1, ["pls", "plsPower", "knn", "svm"]);
C$.ARR_MODEL=Clazz.array(String, -1, ["PLS", "PLS Power", "KNN regression", "SVM regression"]);
C$.ARR_RESULT_EVALUATOR=Clazz.array(String, -1, ["BalancedR2TrainTest", "MaximumR2Test"]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:26 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
