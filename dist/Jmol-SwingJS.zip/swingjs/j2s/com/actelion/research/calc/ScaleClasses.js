(function(){var P$=Clazz.newPackage("com.actelion.research.calc"),p$1={},I$=[[0,'java.util.ArrayList',['com.actelion.research.calc.ScaleClasses','.Limit'],'java.text.DecimalFormat','java.util.Random']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ScaleClasses", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['Limit',10]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['liLimit','java.util.List']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.liLimit=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'add$D$D$D$D',  function (inLow, inHigh, scLow, scHigh) {
var lim=Clazz.new_($I$(2,1).c$$D$D$D$D,[inLow, inHigh, scLow, scHigh]);
this.liLimit.add$O(lim);
});

Clazz.newMeth(C$, 'scale$D',  function (v) {
var sc=0;
for (var limit, $limit = this.liLimit.iterator$(); $limit.hasNext$()&&((limit=($limit.next$())),1);) {
if (limit.isInRange$D(v)) {
sc=limit.scale$D(v);
break;
}}
return sc;
});

Clazz.newMeth(C$, 'scale$F',  function (v) {
var sc=0;
for (var limit, $limit = this.liLimit.iterator$(); $limit.hasNext$()&&((limit=($limit.next$())),1);) {
if (limit.isInRange$D(v)) {
sc=limit.scale$D(v);
break;
}}
return sc;
});

Clazz.newMeth(C$, 'main$SA',  function (args) {
var n=20;
var nf=Clazz.new_($I$(3,1).c$$S,["0.000"]);
var scw=Clazz.new_(C$);
scw.add$D$D$D$D(0.0, 0.25, 0, 0.45);
scw.add$D$D$D$D(0.25, 0.75, 0.45, 0.55);
scw.add$D$D$D$D(0.75, 1.0, 0.55, 1.0);
var rnd=Clazz.new_($I$(4,1));
var li=Clazz.new_($I$(1,1));
li.add$O(Double.valueOf$D(0.0));
li.add$O(Double.valueOf$D(0.1));
li.add$O(Double.valueOf$D(0.25));
li.add$O(Double.valueOf$D(0.5));
li.add$O(Double.valueOf$D(0.6));
li.add$O(Double.valueOf$D(0.7));
li.add$O(Double.valueOf$D(0.8));
li.add$O(Double.valueOf$D(0.9));
li.add$O(Double.valueOf$D(0.91));
li.add$O(Double.valueOf$D(1.0));
for (var ddd, $ddd = li.iterator$(); $ddd.hasNext$()&&((ddd=($ddd.next$())),1);) {
var sc=scw.scale$D((ddd).valueOf());
System.out.println$S("val " + nf.format$O(ddd) + " scaled " + nf.format$D(sc) );
}
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.ScaleClasses, "Limit", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['mInHigh','mInLow','mScHigh','mScLow','mDeltaIn','mDeltaSc','mScale']]]

Clazz.newMeth(C$, 'c$$D$D$D$D',  function (inLow, inHigh, scLow, scHigh) {
;C$.$init$.apply(this);
this.mInHigh=inHigh;
this.mScHigh=scHigh;
this.mInLow=inLow;
this.mScLow=scLow;
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'init',  function () {
this.mDeltaIn=this.mInHigh - this.mInLow;
this.mDeltaSc=this.mScHigh - this.mScLow;
this.mScale=this.mDeltaSc / this.mDeltaIn;
}, p$1);

Clazz.newMeth(C$, 'scale$D',  function (v) {
var sc=0;
var vn=v - this.mInLow;
sc=vn * this.mScale + this.mScLow;
return sc;
});

Clazz.newMeth(C$, 'isInRange$D',  function (v) {
if (v >= this.mInLow  && v <= this.mInHigh  ) return true;
 else return false;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:15 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
