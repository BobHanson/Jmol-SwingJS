(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.median"),I$=[[0,'com.actelion.research.calc.regression.median.ParameterMedian','com.actelion.research.calc.Matrix']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MedianRegression", null, 'com.actelion.research.calc.regression.ARegressionMethod');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['maMedian','com.actelion.research.calc.Matrix']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.setParameterRegressionMethod$com_actelion_research_calc_regression_ParameterRegressionMethod(Clazz.new_($I$(1,1)));
}, 1);

Clazz.newMeth(C$, 'createModel$com_actelion_research_util_datamodel_ModelXYIndex',  function (modelXYIndexTrain) {
this.maMedian=modelXYIndexTrain.Y.getMedianCols$();
var maYHat=this.calculateYHat$com_actelion_research_calc_Matrix(modelXYIndexTrain.X);
return maYHat;
});

Clazz.newMeth(C$, 'calculateYHat$com_actelion_research_calc_Matrix',  function (X) {
var rows=X.rows$();
var cols=this.maMedian.cols$();
var maYHat=Clazz.new_($I$(2,1).c$$I$I,[rows, cols]);
for (var i=0; i < rows; i++) {
for (var j=0; j < cols; j++) {
maYHat.set$I$I$D(i, j, this.maMedian.get$I$I(0, j));
}
}
return maYHat;
});

Clazz.newMeth(C$, 'calculateYHat$DA',  function (arrRow) {
return this.maMedian.get$I$I(0, 0);
});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:16 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
