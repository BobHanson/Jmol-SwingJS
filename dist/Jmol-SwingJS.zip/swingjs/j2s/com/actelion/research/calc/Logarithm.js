(function(){var P$=Clazz.newPackage("com.actelion.research.calc"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Logarithm");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'get$D$D',  function (value, base) {
return Math.log(value) / Math.log(base);
}, 1);

Clazz.newMeth(C$, 'log2$I',  function (n) {
if (n <= 0) throw Clazz.new_(Clazz.load('IllegalArgumentException'));
return 31 - Integer.numberOfLeadingZeros$I(n);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:05:52 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
