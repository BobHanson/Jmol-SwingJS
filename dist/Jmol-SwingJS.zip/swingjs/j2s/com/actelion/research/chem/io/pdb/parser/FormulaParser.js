(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io.pdb.parser"),I$=[[0,'java.util.HashMap','StringBuilder']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FormulaParser");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['indexLine'],'O',['hmId_Formula','java.util.HashMap']]]

Clazz.newMeth(C$, 'parse$java_util_List$I',  function (liRaw, indexLine) {
this.hmId_Formula=Clazz.new_($I$(1,1));
var tag="FORMUL";
var l0=liRaw.get$I(indexLine);
if (!l0.startsWith$S(tag)) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Error in parsing " + tag]);
}var sb=Clazz.new_($I$(2,1));
var start=indexLine;
var nameId=l0.substring$I$I(12, 15);
for (var i=start; i < liRaw.size$(); i++) {
var l=liRaw.get$I(i);
if (!l.startsWith$S(tag)) {
break;
}var nameIdLine=l.substring$I$I(12, 15);
if (!nameId.equals$O(nameIdLine)) {
var name=sb.toString();
this.hmId_Formula.put$O$O(nameId, name);
nameId=nameIdLine;
sb=Clazz.new_($I$(2,1));
}if (sb.length$() > 0) {
sb.append$S(" ");
}var nameLine=l.substring$I(19).trim$();
sb.append$S(nameLine);
++indexLine;
}
if (sb.length$() > 0) {
var name=sb.toString();
this.hmId_Formula.put$O$O(nameId, name);
}this.indexLine=indexLine;
});

Clazz.newMeth(C$, 'getIndexLine$',  function () {
return this.indexLine;
});

Clazz.newMeth(C$, 'getHMId_Formula$',  function () {
return this.hmId_Formula;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:39 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
