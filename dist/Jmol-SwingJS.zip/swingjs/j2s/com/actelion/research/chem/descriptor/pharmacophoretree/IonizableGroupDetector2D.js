(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.pharmacophoretree"),p$1={},I$=[[0,'java.util.ArrayList','java.util.HashSet','com.actelion.research.chem.AtomFunctionAnalyzer','java.util.Collection','java.util.stream.Collectors']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "IonizableGroupDetector2D");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mol','com.actelion.research.chem.StereoMolecule','ionizableGroups','java.util.List','positivelyIonizableAtoms','java.util.Set','+negativelyIonizableAtoms']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.$init$.apply(this);
this.mol=mol;
this.ionizableGroups=Clazz.new_($I$(1,1));
this.positivelyIonizableAtoms=Clazz.new_($I$(2,1));
this.negativelyIonizableAtoms=Clazz.new_($I$(2,1));
}, 1);

Clazz.newMeth(C$, 'detect$',  function () {
var ionizableGroup;
var ringCollection=this.mol.getRingSet$();
for (var r=0; r < ringCollection.getSize$(); r++) {
var tetrazole=Clazz.new_($I$(1,1));
var ringAtoms=ringCollection.getRingAtoms$I(r);
for (var atom, $atom = 0, $$atom = ringAtoms; $atom<$$atom.length&&((atom=new Integer($$atom[$atom])),1);$atom++) {
if (p$1.alreadyDetected$I.apply(this, [(atom).$c()])) continue;
if (this.mol.getAtomicNo$I((atom).$c()) == 7 && this.mol.isAromaticAtom$I((atom).$c())  && this.mol.getConnAtoms$I((atom).$c()) <= 2 ) tetrazole.add$O(atom);
}
if (tetrazole.size$() == 4) {
this.ionizableGroups.add$O(tetrazole);
this.negativelyIonizableAtoms.add$O(tetrazole.get$I(0));
}}
for (var a=0; a < this.mol.getAtoms$(); a++) {
if (p$1.alreadyDetected$I.apply(this, [a])) continue;
if (this.mol.getAtomicNo$I(a) == 8) {
var aa=this.mol.getConnAtom$I$I(a, 0);
if (p$1.alreadyDetected$I.apply(this, [aa])) continue;
if ($I$(3).isAcidicOxygen$com_actelion_research_chem_StereoMolecule$I(this.mol, a)) {
if (this.mol.getAtomicNo$I(aa) == 6) {
ionizableGroup=Clazz.new_($I$(1,1));
ionizableGroup.add$O(Integer.valueOf$I(a));
ionizableGroup.add$O(Integer.valueOf$I(aa));
var aaa1=this.mol.getConnAtom$I$I(aa, 0);
var aaa2=this.mol.getConnAtom$I$I(aa, 1);
var aaa3=this.mol.getConnAtom$I$I(aa, 2);
var aaa=(aaa1 != a && this.mol.getAtomicNo$I(aaa1) == 8 ) ? aaa1 : (aaa2 != a && this.mol.getAtomicNo$I(aaa2) == 8 ) ? aaa2 : aaa3;
if (p$1.alreadyDetected$I.apply(this, [aaa])) continue;
ionizableGroup.add$O(Integer.valueOf$I(aaa));
this.ionizableGroups.add$O(ionizableGroup);
this.negativelyIonizableAtoms.add$O(Integer.valueOf$I(aa));
continue;
} else if (this.mol.getAtomicNo$I(aa) == 15) {
ionizableGroup=Clazz.new_($I$(1,1));
ionizableGroup.add$O(Integer.valueOf$I(a));
ionizableGroup.add$O(Integer.valueOf$I(aa));
for (var i=0; i < this.mol.getConnAtoms$I(aa); i++) {
var aaa=this.mol.getConnAtom$I$I(aa, i);
if (this.mol.getAtomicNo$I(aaa) == 8 && aaa != a ) {
if (p$1.alreadyDetected$I.apply(this, [aaa])) continue;
ionizableGroup.add$O(Integer.valueOf$I(aaa));
}}
this.ionizableGroups.add$O(ionizableGroup);
this.negativelyIonizableAtoms.add$O(Integer.valueOf$I(aa));
continue;
} else if (this.mol.getAtomicNo$I(aa) == 16) {
ionizableGroup=Clazz.new_($I$(1,1));
ionizableGroup.add$O(Integer.valueOf$I(a));
ionizableGroup.add$O(Integer.valueOf$I(aa));
for (var i=0; i < this.mol.getConnAtoms$I(aa); i++) {
var aaa=this.mol.getConnAtom$I$I(aa, i);
if (this.mol.getAtomicNo$I(aaa) == 8 && aaa != a ) {
if (p$1.alreadyDetected$I.apply(this, [aaa])) continue;
ionizableGroup.add$O(Integer.valueOf$I(aaa));
}}
this.ionizableGroups.add$O(ionizableGroup);
this.negativelyIonizableAtoms.add$O(Integer.valueOf$I(aa));
continue;
}}} else if (this.mol.getAtomicNo$I(a) == 7) {
if (this.mol.isAromaticAtom$I(a)) continue;
if (this.mol.getConnAtoms$I(a) <= 2) {
var nDBs=0;
var found=false;
for (var i=0; i < this.mol.getConnAtoms$I(a) && !found ; i++) {
var aa=this.mol.getConnAtom$I$I(a, i);
if (p$1.alreadyDetected$I.apply(this, [aa])) continue;
if (this.mol.getAtomicNo$I(aa) == 6) {
if (this.mol.getBondOrder$I(this.mol.getBond$I$I(a, aa)) == 2) ++nDBs;
for (var j=0; j < this.mol.getConnAtoms$I(aa) && !found ; j++) {
var aaa=this.mol.getConnAtom$I$I(aa, j);
if (this.mol.isAromaticAtom$I(aaa)) continue;
if (aaa == a) continue;
if (p$1.alreadyDetected$I.apply(this, [aaa])) continue;
if (this.mol.getAtomicNo$I(aaa) == 7 && this.mol.getConnAtoms$I(aaa) <= 2 ) {
;if (this.mol.getBondOrder$I(this.mol.getBond$I$I(aa, aaa)) == 2) ++nDBs;
if (nDBs == 1) {
ionizableGroup=Clazz.new_($I$(1,1));
ionizableGroup.add$O(Integer.valueOf$I(a));
ionizableGroup.add$O(Integer.valueOf$I(aa));
ionizableGroup.add$O(Integer.valueOf$I(aaa));
this.ionizableGroups.add$O(ionizableGroup);
this.positivelyIonizableAtoms.add$O(Integer.valueOf$I(aa));
found=true;
}}}
}}
}if (p$1.alreadyDetected$I.apply(this, [a])) continue;
if ($I$(3).isBasicNitrogen$com_actelion_research_chem_StereoMolecule$I(this.mol, a)) {
ionizableGroup=Clazz.new_($I$(1,1));
ionizableGroup.add$O(Integer.valueOf$I(a));
this.ionizableGroups.add$O(ionizableGroup);
this.positivelyIonizableAtoms.add$O(Integer.valueOf$I(a));
continue;
}}if (p$1.alreadyDetected$I.apply(this, [a])) continue;
 else {
var charge=this.mol.getAtomCharge$I(a);
if (charge != 0 && !p$1.hasCounterChargedNeighbour$I.apply(this, [a]) ) {
if (charge > 0) this.positivelyIonizableAtoms.add$O(Integer.valueOf$I(a));
 else this.negativelyIonizableAtoms.add$O(Integer.valueOf$I(a));
}}}
});

Clazz.newMeth(C$, 'hasCounterChargedNeighbour$I',  function (a) {
for (var aa=0; aa < this.mol.getConnAtoms$I(a); aa++) {
if (this.mol.getAtomCharge$I(a) * this.mol.getAtomCharge$I(this.mol.getConnAtom$I$I(a, aa)) < 0) return true;
}
return false;
}, p$1);

Clazz.newMeth(C$, 'alreadyDetected$I',  function (a) {
var isDetected=this.ionizableGroups.stream$().flatMap$java_util_function_Function((function($$){((
(function(){/*m*/var C$=Clazz.newClass(P$, "IonizableGroupDetector2D$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_M*/
Clazz.newMeth(C$, 'apply$O',  function (t) { return t.stream$.apply(t,[])});
})()
)); return Clazz.new_(P$.IonizableGroupDetector2D$lambda1.$init$,[this, null])})($I$(4))).collect$java_util_stream_Collector($I$(5).toList$()).contains$O(Integer.valueOf$I(a)) ? true : false;
return isDetected;
}, p$1);

Clazz.newMeth(C$, 'getPosIonizableAtoms$',  function () {
return this.positivelyIonizableAtoms;
});

Clazz.newMeth(C$, 'getNegIonizableAtoms$',  function () {
return this.negativelyIonizableAtoms;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:37 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
