(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.redgraph"),I$=[[0,'java.util.ArrayList','com.actelion.research.chem.descriptor.flexophore.redgraph.SubGraphIndices','com.actelion.research.util.hash.HashSetInt','java.util.Arrays','StringBuilder',['com.actelion.research.chem.descriptor.flexophore.redgraph.SubGraphIndices','.OverlappingFragments'],'java.util.LinkedList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SubGraphIndices", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['OverlappingFragments',10]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['hsIndexAtom','com.actelion.research.util.hash.HashSetInt']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.hsIndexAtom=Clazz.new_($I$(3,1));
}, 1);

Clazz.newMeth(C$, 'c$$IA',  function (arrIndexAtom) {
;C$.$init$.apply(this);
this.hsIndexAtom=Clazz.new_($I$(3,1).c$$IA,[arrIndexAtom]);
}, 1);

Clazz.newMeth(C$, 'getNumIndices$',  function () {
return this.hsIndexAtom.size$();
});

Clazz.newMeth(C$, 'clear$',  function () {
this.hsIndexAtom.clear$();
});

Clazz.newMeth(C$, 'addIndex$I',  function (indexAtom) {
this.hsIndexAtom.add$I(indexAtom);
});

Clazz.newMeth(C$, 'addIndex$IA',  function (arrIndexAtom) {
this.hsIndexAtom.add$IA(arrIndexAtom);
});

Clazz.newMeth(C$, 'getAtomIndices$',  function () {
return this.hsIndexAtom.getValues$();
});

Clazz.newMeth(C$, 'contains$I',  function (indexAtom) {
return this.hsIndexAtom.contains$I(indexAtom);
});

Clazz.newMeth(C$, 'equalIndices$IA',  function (arrIndexAtom) {
if (this.hsIndexAtom.size$() != arrIndexAtom.length) return false;
var eq=true;
for (var index, $index = 0, $$index = arrIndexAtom; $index<$$index.length&&((index=($$index[$index])),1);$index++) {
if (!this.hsIndexAtom.contains$I(index)) {
eq=false;
break;
}}
return eq;
});

Clazz.newMeth(C$, 'equals$O',  function (obj) {
if (!(Clazz.instanceOf(obj, "com.actelion.research.chem.descriptor.flexophore.redgraph.SubGraphIndices"))) {
return false;
}var sg=obj;
if (this.hsIndexAtom.size$() != sg.getNumIndices$()) {
return false;
}var a0=this.hsIndexAtom.getValues$();
var a1=sg.getAtomIndices$();
$I$(4).sort$IA(a0);
$I$(4).sort$IA(a1);
var eq=true;
for (var i=0; i < a0.length; i++) {
if (a0[i] != a1[i]) {
eq=false;
}}
return eq;
});

Clazz.newMeth(C$, 'isOverlap$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices',  function (frag) {
var overlap=false;
var arrFragIndexAt=frag.hsIndexAtom.getValues$();
for (var indexAtomFrag, $indexAtomFrag = 0, $$indexAtomFrag = arrFragIndexAt; $indexAtomFrag<$$indexAtomFrag.length&&((indexAtomFrag=($$indexAtomFrag[$indexAtomFrag])),1);$indexAtomFrag++) {
if (this.hsIndexAtom.contains$I(indexAtomFrag)) {
overlap=true;
break;
}}
return overlap;
});

Clazz.newMeth(C$, 'getNumOverlappingIndices$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices',  function (frag) {
var nOverlapping=0;
var arrFragIndexAt=frag.hsIndexAtom.getValues$();
for (var indexAtomFrag, $indexAtomFrag = 0, $$indexAtomFrag = arrFragIndexAt; $indexAtomFrag<$$indexAtomFrag.length&&((indexAtomFrag=($$indexAtomFrag[$indexAtomFrag])),1);$indexAtomFrag++) {
if (this.hsIndexAtom.contains$I(indexAtomFrag)) {
++nOverlapping;
}}
return nOverlapping;
});

Clazz.newMeth(C$, 'merge$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices',  function (frag) {
var arrFragIndexAt=frag.hsIndexAtom.getValues$();
for (var indexAtomFrag, $indexAtomFrag = 0, $$indexAtomFrag = arrFragIndexAt; $indexAtomFrag<$$indexAtomFrag.length&&((indexAtomFrag=($$indexAtomFrag[$indexAtomFrag])),1);$indexAtomFrag++) {
this.hsIndexAtom.add$I(indexAtomFrag);
}
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(5,1));
var a=this.hsIndexAtom.getValues$();
$I$(4).sort$IA(a);
for (var i=0; i < a.length; i++) {
sb.append$I(a[i]);
if (i < a.length - 1) {
sb.append$S(",");
}}
return sb.toString();
});

Clazz.newMeth(C$, 'isOnlyCarbon$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices',  function (mol, sgi) {
var carbon=true;
for (var atomIndex, $atomIndex = 0, $$atomIndex = sgi.getAtomIndices$(); $atomIndex<$$atomIndex.length&&((atomIndex=($$atomIndex[$atomIndex])),1);$atomIndex++) {
if (mol.getAtomicNo$I(atomIndex) != 6) {
carbon=false;
break;
}}
return carbon;
}, 1);

Clazz.newMeth(C$, 'isCharged$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices',  function (mol, sgi) {
var charge=0;
for (var atomIndex, $atomIndex = 0, $$atomIndex = sgi.getAtomIndices$(); $atomIndex<$$atomIndex.length&&((atomIndex=($$atomIndex[$atomIndex])),1);$atomIndex++) {
charge+=mol.getAtomCharge$I(atomIndex);
}
return (charge != 0);
}, 1);

Clazz.newMeth(C$, 'merge$java_util_List',  function (liFragment) {
var merged=true;
while (merged){
merged=false;
for (var i=0; i < liFragment.size$(); i++) {
var frag1=liFragment.get$I(i);
for (var j=liFragment.size$() - 1; j > i; j--) {
var frag2=liFragment.get$I(j);
if (frag1.isOverlap$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices(frag2)) {
frag1.merge$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices(frag2);
liFragment.remove$I(j);
merged=true;
}}
}
}
}, 1);

Clazz.newMeth(C$, 'mergeOverlapping$java_util_List$I',  function (liFragment, minNumIndicesOverlapping) {
var liOverlappingFragments=Clazz.new_($I$(1,1));
for (var i=0; i < liFragment.size$(); i++) {
var frag1=liFragment.get$I(i);
var overlappingFragments=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices,[frag1]);
liOverlappingFragments.add$O(overlappingFragments);
}
var merged=true;
while (merged){
merged=false;
for (var i=0; i < liOverlappingFragments.size$(); i++) {
var of1=liOverlappingFragments.get$I(i);
for (var j=liOverlappingFragments.size$() - 1; j > i; j--) {
var of2=liOverlappingFragments.get$I(j);
if (of1.getNumLargestOverlap$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices_OverlappingFragments(of2) >= minNumIndicesOverlapping) {
of1.add$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices_OverlappingFragments(of2);
liOverlappingFragments.remove$I(j);
}}
}
}
var liFragmentMerged=Clazz.new_($I$(1,1));
for (var olf, $olf = liOverlappingFragments.iterator$(); $olf.hasNext$()&&((olf=($olf.next$())),1);) {
liFragmentMerged.add$O(olf.getSubGraphIndices$());
}
return liFragmentMerged;
}, 1);

Clazz.newMeth(C$, 'addAtomIndices$com_actelion_research_util_hash_HashSetInt$java_util_List',  function (hs, liFragment) {
for (var fragment, $fragment = liFragment.iterator$(); $fragment.hasNext$()&&((fragment=($fragment.next$())),1);) {
hs.add$IA(fragment.getAtomIndices$());
}
}, 1);

Clazz.newMeth(C$, 'isLinker$com_actelion_research_chem_StereoMolecule$java_util_List$I',  function (mol, liSGI, indexSGI) {
var atoms=mol.getAtoms$();
var sgi=liSGI.get$I(indexSGI);
var arrAtomIndicesUsedMap=Clazz.array(Boolean.TYPE, [atoms]);
for (var indexAtmUsed, $indexAtmUsed = 0, $$indexAtmUsed = sgi.getAtomIndices$(); $indexAtmUsed<$$indexAtmUsed.length&&((indexAtmUsed=($$indexAtmUsed[$indexAtmUsed])),1);$indexAtmUsed++) {
arrAtomIndicesUsedMap[indexAtmUsed]=true;
}
var mapSGI=Clazz.array(Boolean.TYPE, [liSGI.size$()]);
for (var indAtmStart, $indAtmStart = 0, $$indAtmStart = sgi.getAtomIndices$(); $indAtmStart<$$indAtmStart.length&&((indAtmStart=($$indAtmStart[$indAtmStart])),1);$indAtmStart++) {
var liIndAtm=Clazz.new_($I$(7,1));
liIndAtm.add$O(Integer.valueOf$I(indAtmStart));
 out : while (!liIndAtm.isEmpty$()){
var indAtm=(liIndAtm.poll$()).$c();
var nConnAtms=mol.getConnAtoms$I(indAtm);
for (var i=0; i < nConnAtms; i++) {
var indAtmConn=mol.getConnAtom$I$I(indAtm, i);
if (arrAtomIndicesUsedMap[indAtmConn]) {
continue;
}arrAtomIndicesUsedMap[indAtmConn]=true;
for (var j=0; j < liSGI.size$(); j++) {
if (indexSGI == j) continue;
var sgi2Check=liSGI.get$I(j);
if (sgi2Check.contains$I(indAtmConn)) {
mapSGI[j]=true;
break out;
}}
liIndAtm.add$O(Integer.valueOf$I(indAtmConn));
}
}
}
var ccLinked=0;
for (var b, $b = 0, $$b = mapSGI; $b<$$b.length&&((b=($$b[$b])),1);$b++) {
if (b) ++ccLinked;
}
return (ccLinked > 1);
}, 1);

Clazz.newMeth(C$, 'getComparatorNumIndices$',  function () {
return ((P$.SubGraphIndices$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "SubGraphIndices$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices','compare$O$O'],  function (f1, f2) {
var cmp=0;
if (f1.hsIndexAtom.size$() > f2.hsIndexAtom.size$()) {
cmp=1;
} else if (f1.hsIndexAtom.size$() < f2.hsIndexAtom.size$()) {
cmp=-1;
}return cmp;
});
})()
), Clazz.new_(P$.SubGraphIndices$1.$init$,[this, null]));
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.SubGraphIndices, "OverlappingFragments", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['liSubGraphIndices','java.util.List']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices',  function (sg) {
;C$.$init$.apply(this);
this.liSubGraphIndices=Clazz.new_($I$(1,1));
this.liSubGraphIndices.add$O(sg);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices',  function (sg1, sg2) {
;C$.$init$.apply(this);
this.liSubGraphIndices=Clazz.new_($I$(1,1));
this.liSubGraphIndices.add$O(sg1);
this.liSubGraphIndices.add$O(sg2);
}, 1);

Clazz.newMeth(C$, 'add$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices',  function (sg) {
this.liSubGraphIndices.add$O(sg);
});

Clazz.newMeth(C$, 'add$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices_OverlappingFragments',  function (of) {
this.liSubGraphIndices.addAll$java_util_Collection(of.liSubGraphIndices);
});

Clazz.newMeth(C$, 'getNumLargestOverlap$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices_OverlappingFragments',  function (of) {
var nOverlapMax=0;
for (var sgi0, $sgi0 = this.liSubGraphIndices.iterator$(); $sgi0.hasNext$()&&((sgi0=($sgi0.next$())),1);) {
for (var sgi1, $sgi1 = of.liSubGraphIndices.iterator$(); $sgi1.hasNext$()&&((sgi1=($sgi1.next$())),1);) {
var n=sgi0.getNumOverlappingIndices$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices(sgi1);
if (n > nOverlapMax) {
nOverlapMax=n;
}}
}
return nOverlapMax;
});

Clazz.newMeth(C$, 'containsSubGraph$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices_OverlappingFragments',  function (of) {
var contains=false;
 containsB : for (var sgi1, $sgi1 = this.liSubGraphIndices.iterator$(); $sgi1.hasNext$()&&((sgi1=($sgi1.next$())),1);) {
for (var sgi2, $sgi2 = of.liSubGraphIndices.iterator$(); $sgi2.hasNext$()&&((sgi2=($sgi2.next$())),1);) {
if (sgi1.equals$O(sgi2)) {
contains=true;
break containsB;
}}
}
return contains;
});

Clazz.newMeth(C$, 'getSubGraphIndices$',  function () {
$I$(2).merge$java_util_List(this.liSubGraphIndices);
if (this.liSubGraphIndices.size$() != 1) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["This should not happen."]);
}return this.liSubGraphIndices.get$I(0);
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:10 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
