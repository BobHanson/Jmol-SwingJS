(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.generator"),I$=[[0,['com.actelion.research.chem.descriptor.flexophore.generator.SubFlexophoreGenerator','.ViolatedConditionsCount'],'java.util.HashSet','com.actelion.research.calc.combinatorics.CombinationGenerator','java.util.ArrayList','com.actelion.research.chem.descriptor.flexophore.MolDistHist','com.actelion.research.chem.descriptor.flexophore.PPNode','com.actelion.research.chem.descriptor.flexophore.MolDistHistVizFrag','com.actelion.research.chem.descriptor.flexophore.PPNodeViz']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SubFlexophoreGenerator", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['ViolatedConditionsCount',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['minBinDistThresh','maxDistanceBinThresh','minNumDifferentInteractionTypes'],'O',['violatedConditionsCount','com.actelion.research.chem.descriptor.flexophore.generator.SubFlexophoreGenerator.ViolatedConditionsCount','hsInteractionType','java.util.HashSet']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_generator_SubFlexophoreGenerator',  function (a) {
;C$.$init$.apply(this);
this.minBinDistThresh=a.minBinDistThresh;
this.maxDistanceBinThresh=a.maxDistanceBinThresh;
this.minNumDifferentInteractionTypes=a.minNumDifferentInteractionTypes;
this.violatedConditionsCount=Clazz.new_($I$(1,1));
this.hsInteractionType=Clazz.new_($I$(2,1));
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I',  function (minBinDistThresh, maxDistanceBinThresh, minNumDifferentInteractionTypes) {
;C$.$init$.apply(this);
this.minBinDistThresh=minBinDistThresh;
this.maxDistanceBinThresh=maxDistanceBinThresh;
this.minNumDifferentInteractionTypes=minNumDifferentInteractionTypes;
this.violatedConditionsCount=Clazz.new_($I$(1,1));
this.hsInteractionType=Clazz.new_($I$(2,1));
}, 1);

Clazz.newMeth(C$, 'generateSubPharmacophoresCheckedRange$com_actelion_research_chem_descriptor_flexophore_MolDistHist$I',  function (mdh, size) {
var liIndSub=$I$(3,"getAllOutOf$I$I",[mdh.getNumPPNodes$(), size]);
if (liIndSub == null ) return null;
var liMolDistHistSub=Clazz.new_($I$(4,1));
for (var arrIndSub, $arrIndSub = liIndSub.iterator$(); $arrIndSub.hasNext$()&&((arrIndSub=($arrIndSub.next$())),1);) {
var mdhSub=this.getSubFragmentCheckedRange$com_actelion_research_chem_descriptor_flexophore_MolDistHist$IA(mdh, arrIndSub);
if (mdhSub == null ) {
continue;
}var nNodes=mdhSub.getNumPPNodes$();
this.hsInteractionType.clear$();
for (var k=0; k < nNodes; k++) {
var node=mdhSub.getNode$I(k);
var nIATypes=node.getInteractionTypeCount$();
for (var l=0; l < nIATypes; l++) {
var iaType=node.getInteractionType$I(l);
this.hsInteractionType.add$O(Integer.valueOf$I(iaType));
}
}
if (this.hsInteractionType.size$() < this.minNumDifferentInteractionTypes) {
(this.violatedConditionsCount.ccViolatedMinDiffInteractionTypes=Long.$inc(this.violatedConditionsCount.ccViolatedMinDiffInteractionTypes,1));
continue;
}liMolDistHistSub.add$O(mdhSub);
}
return liMolDistHistSub;
});

Clazz.newMeth(C$, 'getSubFragmentCheckedRange$com_actelion_research_chem_descriptor_flexophore_MolDistHist$IA',  function (mdh, arrIndices) {
var frag=Clazz.new_($I$(5,1).c$$I,[arrIndices.length]);
for (var i=0; i < arrIndices.length; i++) {
var node=Clazz.new_([mdh.getNode$I(arrIndices[i])],$I$(6,1).c$$com_actelion_research_chem_descriptor_flexophore_PPNode);
frag.addNode$com_actelion_research_chem_descriptor_flexophore_PPNode(node);
}
var minDistReached=false;
var maxDistViolated=false;
 violated : for (var i=0; i < arrIndices.length; i++) {
for (var j=i + 1; j < arrIndices.length; j++) {
var arrHist=mdh.getDistHist$I$I(arrIndices[i], arrIndices[j]);
if (!minDistReached) {
for (var length=this.minBinDistThresh; length < arrHist.length; length++) {
if (arrHist[length] > 0) {
minDistReached=true;
break;
}}
}for (var k=arrHist.length - 1; k > this.maxDistanceBinThresh; k--) {
if (arrHist[k] > 0) {
maxDistViolated=true;
break violated;
}}
frag.setDistHist$I$I$BA(i, j, arrHist);
}
}
if (!minDistReached || maxDistViolated ) {
if (!minDistReached) {
(this.violatedConditionsCount.ccMissedMinRange=Long.$inc(this.violatedConditionsCount.ccMissedMinRange,1));
}if (maxDistViolated) {
(this.violatedConditionsCount.ccViolatedMaxRange=Long.$inc(this.violatedConditionsCount.ccViolatedMaxRange,1));
}return null;
}frag.realize$();
return frag;
});

Clazz.newMeth(C$, 'getViolatedConditionsCount$',  function () {
return this.violatedConditionsCount;
});

Clazz.newMeth(C$, 'generateSubPharmacophores$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz$I$I',  function (mdhv, minNumPPPoints, maxNumPPPoints) {
var liHsMolDistHistViz=Clazz.new_($I$(4,1));
for (var size=0; size < maxNumPPPoints + 1; size++) {
liHsMolDistHistViz.add$O(Clazz.new_($I$(2,1)));
}
var maxNumPPPointsReal=Math.min(mdhv.getNumPPNodes$(), maxNumPPPoints) + 1;
for (var size=minNumPPPoints; size < maxNumPPPointsReal; size++) {
var liMDHVSub=C$.generateSubPharmacophores$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz$I(mdhv, size);
liHsMolDistHistViz.get$I(size).addAll$java_util_Collection(liMDHVSub);
}
var liMDHVSubAll=Clazz.new_($I$(4,1));
for (var hsMDHVSub, $hsMDHVSub = liHsMolDistHistViz.iterator$(); $hsMDHVSub.hasNext$()&&((hsMDHVSub=($hsMDHVSub.next$())),1);) {
liMDHVSubAll.addAll$java_util_Collection(hsMDHVSub);
}
return liMDHVSubAll;
}, 1);

Clazz.newMeth(C$, 'generateSubPharmacophores$java_util_List$I$I',  function (liMDHV, minNumPPPoints, maxNumPPPoints) {
var liHsMolDistHistViz=Clazz.new_($I$(4,1));
for (var size=0; size < maxNumPPPoints + 1; size++) {
liHsMolDistHistViz.add$O(Clazz.new_($I$(2,1)));
}
for (var mdhv, $mdhv = liMDHV.iterator$(); $mdhv.hasNext$()&&((mdhv=($mdhv.next$())),1);) {
var maxNumPPPointsReal=Math.min(mdhv.getNumPPNodes$(), maxNumPPPoints) + 1;
for (var size=minNumPPPoints; size < maxNumPPPointsReal; size++) {
var liMDHVSub=C$.generateSubPharmacophores$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz$I(mdhv, size);
liHsMolDistHistViz.get$I(size).addAll$java_util_Collection(liMDHVSub);
}
}
var liMDHVSubAll=Clazz.new_($I$(4,1));
for (var hsMDHVSub, $hsMDHVSub = liHsMolDistHistViz.iterator$(); $hsMDHVSub.hasNext$()&&((hsMDHVSub=($hsMDHVSub.next$())),1);) {
liMDHVSubAll.addAll$java_util_Collection(hsMDHVSub);
}
return liMDHVSubAll;
}, 1);

Clazz.newMeth(C$, 'generateSubPharmacophores$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz$I',  function (mdhv, size) {
var liIndSub=$I$(3,"getAllOutOf$I$I",[mdhv.getNumPPNodes$(), size]);
if (liIndSub == null ) return null;
var hsMolDistHistViz=Clazz.new_($I$(2,1));
var liMDH=C$.getSubFragments$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz$java_util_List(mdhv, liIndSub);
for (var mdhFrag, $mdhFrag = liMDH.iterator$(); $mdhFrag.hasNext$()&&((mdhFrag=($mdhFrag.next$())),1);) {
hsMolDistHistViz.add$O(mdhFrag);
}
var liMDHFeatures=Clazz.new_($I$(4,1).c$$java_util_Collection,[hsMolDistHistViz]);
return liMDHFeatures;
}, 1);

Clazz.newMeth(C$, 'getSubFragments$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz$java_util_List',  function (mdh, liIndices) {
var liFrags=Clazz.new_([liIndices.size$()],$I$(4,1).c$$I);
for (var arr, $arr = liIndices.iterator$(); $arr.hasNext$()&&((arr=($arr.next$())),1);) {
var inevitableAllInSub=true;
if (mdh.getNumMandatoryPharmacophorePoints$() > 0) {
var nInevitableInSub=0;
for (var i=0; i < arr.length; i++) {
if (mdh.isMandatoryPharmacophorePoint$I(arr[i])) {
++nInevitableInSub;
}}
if (nInevitableInSub < mdh.getNumMandatoryPharmacophorePoints$()) {
inevitableAllInSub=false;
}}if (inevitableAllInSub) {
var frag=C$.getSubFragment$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz$IA(mdh, arr);
liFrags.add$O(frag);
}}
return liFrags;
}, 1);

Clazz.newMeth(C$, 'getSubFragment$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz$IA',  function (mdh, arrIndexNodes) {
var frag=Clazz.new_([arrIndexNodes.length, mdh.getMolecule$()],$I$(7,1).c$$I$com_actelion_research_chem_Molecule3D);
for (var i=0; i < arrIndexNodes.length; i++) {
var node=Clazz.new_([mdh.getNode$I(arrIndexNodes[i])],$I$(8,1).c$$com_actelion_research_chem_descriptor_flexophore_PPNodeViz);
frag.addNode$com_actelion_research_chem_descriptor_flexophore_PPNodeViz(node);
}
for (var i=0; i < arrIndexNodes.length; i++) {
for (var j=i + 1; j < arrIndexNodes.length; j++) {
var arrHist=mdh.getDistHist$I$I(arrIndexNodes[i], arrIndexNodes[j]);
frag.setDistHist$I$I$BA(i, j, arrHist);
}
}
frag.setArrIndexParentNodes$IA(arrIndexNodes);
frag.realize$();
return frag;
}, 1);

Clazz.newMeth(C$, 'generateSubPharmacophores$com_actelion_research_chem_descriptor_flexophore_MolDistHist$I',  function (mdh, size) {
var liIndSub=$I$(3,"getAllOutOf$I$I",[mdh.getNumPPNodes$(), size]);
if (liIndSub == null ) return null;
var liMolDistHistSub=Clazz.new_($I$(4,1));
for (var arrIndSub, $arrIndSub = liIndSub.iterator$(); $arrIndSub.hasNext$()&&((arrIndSub=($arrIndSub.next$())),1);) {
var mdhSub=C$.getSubFragment$com_actelion_research_chem_descriptor_flexophore_MolDistHist$IA(mdh, arrIndSub);
liMolDistHistSub.add$O(mdhSub);
}
return liMolDistHistSub;
}, 1);

Clazz.newMeth(C$, 'getSubFragment$com_actelion_research_chem_descriptor_flexophore_MolDistHist$IA',  function (mdh, arrIndexNodes) {
var frag=Clazz.new_($I$(5,1).c$$I,[arrIndexNodes.length]);
for (var i=0; i < arrIndexNodes.length; i++) {
var node=Clazz.new_([mdh.getNode$I(arrIndexNodes[i])],$I$(6,1).c$$com_actelion_research_chem_descriptor_flexophore_PPNode);
frag.addNode$com_actelion_research_chem_descriptor_flexophore_PPNode(node);
}
for (var i=0; i < arrIndexNodes.length; i++) {
for (var j=i + 1; j < arrIndexNodes.length; j++) {
var arrHist=mdh.getDistHist$I$I(arrIndexNodes[i], arrIndexNodes[j]);
frag.setDistHist$I$I$BA(i, j, arrHist);
}
}
frag.realize$();
return frag;
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.SubFlexophoreGenerator, "ViolatedConditionsCount", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['J',['ccMissedMinRange','ccViolatedMaxRange','ccViolatedMinDiffInteractionTypes']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.ccMissedMinRange=0;
this.ccViolatedMaxRange=0;
this.ccViolatedMinDiffInteractionTypes=0;
}, 1);

Clazz.newMeth(C$, 'add$com_actelion_research_chem_descriptor_flexophore_generator_SubFlexophoreGenerator_ViolatedConditionsCount',  function (v) {
(this.ccMissedMinRange=Long.$add(this.ccMissedMinRange,(v.ccMissedMinRange)));
(this.ccViolatedMaxRange=Long.$add(this.ccViolatedMaxRange,(v.ccViolatedMaxRange)));
(this.ccViolatedMinDiffInteractionTypes=Long.$add(this.ccViolatedMinDiffInteractionTypes,(v.ccViolatedMinDiffInteractionTypes)));
});

Clazz.newMeth(C$, 'getCcMissedMinRange$',  function () {
return this.ccMissedMinRange;
});

Clazz.newMeth(C$, 'getCcViolatedMaxRange$',  function () {
return this.ccViolatedMaxRange;
});

Clazz.newMeth(C$, 'getCcViolatedMinDiffInteractionTypes$',  function () {
return this.ccViolatedMinDiffInteractionTypes;
});
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:05 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
