(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io"),p$1={},I$=[[0,'java.io.BufferedReader','java.io.InputStreamReader','java.io.FileInputStream','java.nio.charset.StandardCharsets','com.actelion.research.io.BOMSkipper','com.actelion.research.chem.descriptor.DescriptorHandlerStandard2DFactory','java.util.ArrayList','java.util.TreeMap','java.util.Properties',['com.actelion.research.chem.io.DWARFileParser','.SpecialField'],'com.actelion.research.chem.descriptor.DescriptorConstants','com.actelion.research.chem.descriptor.DescriptorHelper','java.util.Arrays','java.util.stream.Collectors','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.IDCodeParser','com.actelion.research.chem.IsomericSmilesCreator','java.util.HashMap','com.actelion.research.util.BinaryDecoder','com.actelion.research.chem.reaction.ReactionEncoder']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DWARFileParser", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'com.actelion.research.chem.io.CompoundFileParser', ['com.actelion.research.chem.descriptor.DescriptorConstants', 'com.actelion.research.chem.io.CompoundTableConstants']);
C$.$classes$=[['SpecialField',1]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mRecordCount','mMode','mIDCodeColumn','mCoordinateColumn','mCoordinate2DColumn','mCoordinate3DColumn','mMoleculeNameColumn','mFragFpColumn'],'S',['mLine','mCoordinate3DColumnName'],'O',['mFieldName','String[]','+mFieldData','mFieldIndex','int[]','mColumnPropertyMap','java.util.TreeMap','+mSpecialFieldMap','+mDescriptorColumnMap','mHeadOrTailLineList','java.util.ArrayList','mDetails','java.util.HashMap']]]

Clazz.newMeth(C$, 'c$$S',  function (fileName) {
Clazz.super_(C$, this);
try {
this.mReader=Clazz.new_([Clazz.new_([Clazz.new_($I$(3,1).c$$S,[fileName]), $I$(4).UTF_8],$I$(2,1).c$$java_io_InputStream$java_nio_charset_Charset)],$I$(1,1).c$$java_io_Reader);
$I$(5).skip$java_io_Reader(this.mReader);
this.mMode=1;
p$1.init.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
this.mReader=null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'c$$java_io_File',  function (file) {
Clazz.super_(C$, this);
try {
this.mReader=Clazz.new_([Clazz.new_([Clazz.new_($I$(3,1).c$$java_io_File,[file]), $I$(4).UTF_8],$I$(2,1).c$$java_io_InputStream$java_nio_charset_Charset)],$I$(1,1).c$$java_io_Reader);
$I$(5).skip$java_io_Reader(this.mReader);
this.mMode=1;
p$1.init.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
this.mReader=null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'c$$java_io_Reader',  function (reader) {
Clazz.super_(C$, this);
try {
this.mReader=(Clazz.instanceOf(reader, "java.io.BufferedReader")) ? reader : Clazz.new_($I$(1,1).c$$java_io_Reader,[reader]);
this.mMode=1;
p$1.init.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
this.mReader=null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'c$$S$I',  function (fileName, mode) {
Clazz.super_(C$, this);
try {
this.mReader=Clazz.new_([Clazz.new_([Clazz.new_($I$(3,1).c$$S,[fileName]), $I$(4).UTF_8],$I$(2,1).c$$java_io_InputStream$java_nio_charset_Charset)],$I$(1,1).c$$java_io_Reader);
$I$(5).skip$java_io_Reader(this.mReader);
this.mMode=mode;
p$1.init.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
this.mReader=null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'c$$java_io_File$I',  function (file, mode) {
Clazz.super_(C$, this);
try {
this.mReader=Clazz.new_([Clazz.new_([Clazz.new_($I$(3,1).c$$java_io_File,[file]), $I$(4).UTF_8],$I$(2,1).c$$java_io_InputStream$java_nio_charset_Charset)],$I$(1,1).c$$java_io_Reader);
$I$(5).skip$java_io_Reader(this.mReader);
this.mMode=mode;
p$1.init.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
this.mReader=null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'c$$java_io_Reader$I',  function (reader, mode) {
Clazz.super_(C$, this);
try {
this.mReader=(Clazz.instanceOf(reader, "java.io.BufferedReader")) ? reader : Clazz.new_($I$(1,1).c$$java_io_Reader,[reader]);
this.mMode=mode;
p$1.init.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
this.mReader=null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'readHeadOrTailLine',  function () {
var line=this.mReader.readLine$();
if ((this.mMode & 8) != 0 && line != null  ) this.mHeadOrTailLineList.add$O(line);
return line;
}, p$1);

Clazz.newMeth(C$, 'init',  function () {
this.setDescriptorHandlerFactory$com_actelion_research_chem_descriptor_DescriptorHandlerFactory($I$(6).getFactory$());
if ((this.mMode & 8) != 0) this.mHeadOrTailLineList=Clazz.new_($I$(7,1));
var coordinateMode=this.mMode & 7;
var line=p$1.readHeadOrTailLine.apply(this, []);
if (line == null  || !line.equals$O("<datawarrior-fileinfo>") ) throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["no header found"]);
this.mRecordCount=-1;
line=p$1.readHeadOrTailLine.apply(this, []);
while (line != null  && !line.equals$O("</datawarrior-fileinfo>") ){
if (line.startsWith$S("<version")) {
var version=p$1.extractValue$S.apply(this, [line]);
if (!version.startsWith$S("3.") && !version.isEmpty$() ) throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["unsupported .dwar file version"]);
} else if (line.startsWith$S("<rowcount")) {
try {
this.mRecordCount=Integer.parseInt$S(p$1.extractValue$S.apply(this, [line]));
} catch (e) {
if (Clazz.exceptionOf(e,"NumberFormatException")){
} else {
throw e;
}
}
}line=p$1.readHeadOrTailLine.apply(this, []);
}
line=p$1.readHeadOrTailLine.apply(this, []);
while (line != null  && (line.equals$O("<datawarrior explanation>") || line.equals$O("<datawarrior macroList>") ) ){
line=p$1.readHeadOrTailLine.apply(this, []);
while (line != null  && !line.equals$O("</datawarrior explanation>")  && !line.equals$O("</datawarrior macroList>") )line=p$1.readHeadOrTailLine.apply(this, []);

line=p$1.readHeadOrTailLine.apply(this, []);
}
this.mColumnPropertyMap=Clazz.new_($I$(8,1));
if (line != null  && line.equals$O("<column properties>") ) {
line=p$1.readHeadOrTailLine.apply(this, []);
var columnName=null;
while (line != null  && !line.equals$O("</column properties>") ){
if (line.startsWith$S("<columnName")) {
columnName=p$1.extractValue$S.apply(this, [line]);
this.mColumnPropertyMap.put$O$O(columnName, Clazz.new_($I$(9,1)));
} else if (line.startsWith$S("<columnProperty")) {
var property=p$1.extractValue$S.apply(this, [line]).split$S("\\t");
if (property.length == 1) {
this.mColumnPropertyMap.get$O(columnName).setProperty$S$S(property[0], "");
} else {
this.mColumnPropertyMap.get$O(columnName).setProperty$S$S(property[0], property[1]);
}}line=p$1.readHeadOrTailLine.apply(this, []);
}
line=p$1.readHeadOrTailLine.apply(this, []);
}this.mSpecialFieldMap=Clazz.new_($I$(8,1));
for (var columnName, $columnName = this.mColumnPropertyMap.keySet$().iterator$(); $columnName.hasNext$()&&((columnName=($columnName.next$())),1);) {
var properties=this.mColumnPropertyMap.get$O(columnName);
var specialType=properties.getProperty$S("specialType");
if (specialType != null ) this.mSpecialFieldMap.put$O$O(columnName, Clazz.new_([this, null, columnName, specialType, properties.getProperty$S("parent"), properties.getProperty$S("idColumn"), properties.getProperty$S("version")],$I$(10,1).c$$S$S$S$S$S));
}
var columnNameList=Clazz.new_($I$(7,1));
var columnIndexList=Clazz.new_($I$(7,1));
if (line == null ) throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["unexpected end of file"]);
var fromIndex=0;
var toIndex=0;
var sourceColumn=0;
do {
var columnName;
toIndex=line.indexOf$I$I("\t", fromIndex);
if (toIndex == -1) {
columnName=line.substring$I(fromIndex);
} else {
columnName=line.substring$I$I(fromIndex, toIndex);
fromIndex=toIndex + 1;
}if (this.mSpecialFieldMap.containsKey$O(columnName)) {
this.mSpecialFieldMap.get$O(columnName).fieldIndex=sourceColumn;
} else {
columnNameList.add$O(columnName);
columnIndexList.add$O(Integer.valueOf$I(sourceColumn));
}++sourceColumn;
} while (toIndex != -1);
this.mFieldName=Clazz.array(String, [columnNameList.size$()]);
this.mFieldIndex=Clazz.array(Integer.TYPE, [columnNameList.size$()]);
for (var i=0; i < columnNameList.size$(); i++) {
this.mFieldName[i]=columnNameList.get$I(i);
this.mFieldIndex[i]=(columnIndexList.get$I(i)).$c();
}
this.mFieldData=Clazz.array(String, [sourceColumn]);
this.mIDCodeColumn=-1;
this.mCoordinateColumn=-1;
this.mCoordinate2DColumn=-1;
this.mCoordinate3DColumn=-1;
this.mMoleculeNameColumn=-1;
this.mFragFpColumn=-1;
var idcodeColumn=this.mSpecialFieldMap.get$O("Structure");
if (idcodeColumn == null  || !idcodeColumn.type.equals$O("idcode") ) {
for (var specialColumn, $specialColumn = this.mSpecialFieldMap.values$().iterator$(); $specialColumn.hasNext$()&&((specialColumn=($specialColumn.next$())),1);) {
if (specialColumn.type.equals$O("idcode")) {
if (idcodeColumn == null  || idcodeColumn.fieldIndex > specialColumn.fieldIndex ) idcodeColumn=specialColumn;
}}
}if (idcodeColumn != null ) {
if (idcodeColumn.idColumn != null ) {
for (var i=0; i < this.mFieldName.length; i++) {
if (idcodeColumn.idColumn.equals$O(this.mFieldName[i])) {
this.mMoleculeNameColumn=this.mFieldIndex[i];
break;
}}
}this.mIDCodeColumn=idcodeColumn.fieldIndex;
for (var specialColumn, $specialColumn = this.mSpecialFieldMap.values$().iterator$(); $specialColumn.hasNext$()&&((specialColumn=($specialColumn.next$())),1);) {
if (idcodeColumn.name.equals$O(specialColumn.parent)) {
if ($I$(11).DESCRIPTOR_FFP512.shortName.equals$O(specialColumn.type) && "1.2.1".equals$O(specialColumn.version) ) this.mFragFpColumn=specialColumn.fieldIndex;
 else if ("idcoordinates2D".equals$O(specialColumn.type)) this.mCoordinate2DColumn=specialColumn.fieldIndex;
 else if ("idcoordinates3D".equals$O(specialColumn.type)) {
this.mCoordinate3DColumn=specialColumn.fieldIndex;
this.mCoordinate3DColumnName=specialColumn.name;
}if ($I$(12).isDescriptorShortName$S(specialColumn.type) && $I$(12).getDescriptorInfo$S(specialColumn.type).version.equals$O(specialColumn.version) ) {
if (this.mDescriptorColumnMap == null ) this.mDescriptorColumnMap=Clazz.new_($I$(8,1));
this.mDescriptorColumnMap.put$O$O(specialColumn.type, Integer.valueOf$I(specialColumn.fieldIndex));
}}}
if (this.mCoordinate2DColumn != -1 && (coordinateMode == 3 || coordinateMode == 1  || (coordinateMode == 2 && this.mCoordinate3DColumn == -1 ) ) ) this.mCoordinateColumn=this.mCoordinate2DColumn;
if (this.mCoordinate3DColumn != -1 && (coordinateMode == 4 || coordinateMode == 2  || (coordinateMode == 1 && this.mCoordinate2DColumn == -1 ) ) ) this.mCoordinateColumn=this.mCoordinate3DColumn;
}}, p$1);

Clazz.newMeth(C$, 'hasStructures$',  function () {
return (this.mIDCodeColumn != -1);
});

Clazz.newMeth(C$, 'hasStructureCoordinates$',  function () {
return (this.mCoordinateColumn != -1);
});

Clazz.newMeth(C$, 'hasStructureCoordinates2D$',  function () {
return (this.mCoordinate2DColumn != -1);
});

Clazz.newMeth(C$, 'hasStructureCoordinates3D$',  function () {
return (this.mCoordinate3DColumn != -1);
});

Clazz.newMeth(C$, 'getStructureCoordinates3DColumnName$',  function () {
return this.mCoordinate3DColumnName;
});

Clazz.newMeth(C$, 'getFieldNames$',  function () {
return this.mFieldName;
});

Clazz.newMeth(C$, 'getSpecialFieldIndex$S',  function (columnName) {
for (var sf, $sf = this.mSpecialFieldMap.values$().iterator$(); $sf.hasNext$()&&((sf=($sf.next$())),1);) if (columnName.equals$O(sf.name)) return sf.fieldIndex;

return -1;
});

Clazz.newMeth(C$, 'getChildFieldIndex$S$S',  function (parentColumnName, childType) {
for (var sf, $sf = this.mSpecialFieldMap.values$().iterator$(); $sf.hasNext$()&&((sf=($sf.next$())),1);) if (parentColumnName.equals$O(sf.parent) && childType.equals$O(sf.type) ) return sf.fieldIndex;

return -1;
});

Clazz.newMeth(C$, 'getRowCount$',  function () {
return this.mRecordCount;
});

Clazz.newMeth(C$, 'getHeadOrTail$',  function () {
return this.mHeadOrTailLineList;
});

Clazz.newMeth(C$, 'getDetails$',  function () {
return this.mDetails;
});

Clazz.newMeth(C$, 'getRow$',  function () {
return this.mLine;
});

Clazz.newMeth(C$, 'getRawData$Z$Z',  function (includeHeaderRow, structureAsSmiles) {
var fn=this.getFieldNames$();
var sfn=this.getSpecialFieldMap$();
var allFieldNames=Clazz.new_($I$(7,1));
allFieldNames.addAll$java_util_Collection($I$(13).stream$OA(fn).collect$java_util_stream_Collector($I$(14).toList$()));
var allFieldNamesForOutput=Clazz.new_($I$(7,1));
allFieldNamesForOutput.addAll$java_util_Collection(allFieldNames);
for (var sfi, $sfi = sfn.keySet$().stream$().sorted$java_util_Comparator(((P$.DWARFileParser$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "DWARFileParser$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['compare$S$S','compare$O$O'],  function (x, y) { return (Integer.compare$I$I(this.$finals$.sfn.get$O.apply(this.$finals$.sfn, [x]).fieldIndex, this.$finals$.sfn.get$O.apply(this.$finals$.sfn, [y]).fieldIndex));});
})()
), Clazz.new_(P$.DWARFileParser$lambda1.$init$,[this, {sfn:sfn}]))).collect$java_util_stream_Collector($I$(14).toList$()).iterator$(); $sfi.hasNext$()&&((sfi=($sfi.next$())),1);) {
if (sfn.get$O(sfi).type.equals$O("idcode")) {
allFieldNames.add$I$O(sfn.get$O(sfi).fieldIndex, sfi);
allFieldNamesForOutput.add$O(sfi);
}}
var nDataRows=this.getRowCount$();
var nOutputRows=nDataRows + (includeHeaderRow ? 1 : 0);
var rawData=Clazz.array(String, [nOutputRows, allFieldNames.size$()]);
if (includeHeaderRow) {
for (var zi=0; zi < allFieldNamesForOutput.size$(); zi++) {
var fi=allFieldNamesForOutput.get$I(zi);
rawData[0][zi]=fi;
}
}this.next$();
for (var zi=0; zi < nDataRows; zi++) {
var zOutput=zi + (includeHeaderRow ? 1 : 0);
for (var zj=0; zj < allFieldNamesForOutput.size$(); zj++) {
var fi=allFieldNamesForOutput.get$I(zj);
var rawData_i="";
if (sfn.containsKey$O(fi)) {
rawData_i=this.getSpecialFieldData$I(this.getSpecialFieldIndex$S(fi));
if (sfn.get$O(fi).type.equals$O("idcode")) {
if (structureAsSmiles) {
try {
var mi=Clazz.new_($I$(15,1));
var icp=Clazz.new_($I$(16,1));
icp.parse$com_actelion_research_chem_StereoMolecule$S(mi, rawData_i);
var isc=Clazz.new_($I$(17,1).c$$com_actelion_research_chem_StereoMolecule,[mi]);
rawData_i=isc.getSmiles$();
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
System.out.println$S("Exception for: " + rawData_i);
} else {
throw ex;
}
}
}}} else {
rawData_i=this.getFieldData$I(this.getFieldIndex$S(fi));
}rawData[zOutput][zj]=rawData_i;
}
this.next$();
}
return rawData;
});

Clazz.newMeth(C$, 'main$SA',  function (args) {
var dwfp=Clazz.new_(C$.c$$S,["C:\\dev\\pyocl\\data\\Wikipedia_Compounds_6.dwar"]);
var rawData_a=dwfp.getRawData$Z$Z(true, false);
dwfp=Clazz.new_(C$.c$$S,["C:\\dev\\pyocl\\data\\Wikipedia_Compounds_6.dwar"]);
var rawData_b=dwfp.getRawData$Z$Z(false, true);
dwfp=Clazz.new_(C$.c$$S,["C:\\dev\\pyocl\\data\\Wikipedia_Compounds_6.dwar"]);
var rawData_c=dwfp.getRawData$Z$Z(true, true);
System.out.println$S("DATA:\n");
for (var zi=0; zi < rawData_a.length; zi++) {
for (var zj=0; zj < rawData_a[0].length; zj++) {
System.out.print$S(rawData_a[zi][zj] + " ;; ");
}
System.out.println$S("");
}
for (var zi=0; zi < rawData_b.length; zi++) {
for (var zj=0; zj < rawData_b[0].length; zj++) {
System.out.print$S(rawData_b[zi][zj] + " ;; ");
}
System.out.println$();
}
for (var zi=0; zi < rawData_c.length; zi++) {
for (var zj=0; zj < rawData_c[0].length; zj++) {
System.out.print$S(rawData_c[zi][zj] + " ;; ");
}
System.out.println$();
}
}, 1);

Clazz.newMeth(C$, 'advanceToNext$',  function () {
if (this.mReader == null ) return false;
this.mLine=null;
try {
this.mLine=this.mReader.readLine$();
if (this.mLine == null  || this.mLine.equals$O("<datawarrior properties>")  || this.mLine.equals$O("<hitlist data>")  || this.mLine.equals$O("<detail data>")  || this.mLine.startsWith$S("<data dependent properties type=\"") ) {
if ((this.mMode & 8) != 0) {
this.mHeadOrTailLineList.clear$();
this.mHeadOrTailLineList.add$O(this.mLine);
}while (this.mLine != null ){
if (this.mLine.equals$O("<detail data>") && (this.mMode & 16) != 0 ) p$1.extractDetails.apply(this, []);
this.mLine=p$1.readHeadOrTailLine.apply(this, []);
}
this.mReader.close$();
return false;
}} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
return false;
} else {
throw e;
}
}
var column=0;
var index1=0;
var index2=this.mLine.indexOf$I("\t");
while (index2 != -1){
if (column < this.mFieldData.length) this.mFieldData[column]=this.mLine.substring$I$I(index1, index2).replace$CharSequence$CharSequence("<NL>", "\n").replace$CharSequence$CharSequence("<TAB>", "\t");
++column;
index1=index2 + 1;
index2=this.mLine.indexOf$I$I("\t", index1);
}
if (column < this.mFieldData.length) this.mFieldData[column]=this.mLine.substring$I(index1).replace$CharSequence$CharSequence("<NL>", "\n").replace$CharSequence$CharSequence("<TAB>", "\t");
return true;
});

Clazz.newMeth(C$, 'extractDetails',  function () {
this.mDetails=Clazz.new_($I$(18,1));
try {
while (true){
var theLine=p$1.readHeadOrTailLine.apply(this, []);
if (theLine == null  || theLine.equals$O("</detail data>") ) {
break;
}if (theLine.startsWith$S("<detailID")) {
var detailID=p$1.extractValue$S.apply(this, [theLine]);
var decoder=Clazz.new_($I$(19,1).c$$java_io_BufferedReader,[this.mReader]);
var size=decoder.initialize$I(8);
var detailData=Clazz.array(Byte.TYPE, [size]);
for (var i=0; i < size; i++) detailData[i]=(decoder.read$()|0);

this.mDetails.put$O$O(detailID, detailData);
}}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.mDetails=null;
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'getIDCode$',  function () {
if (this.mIDCodeColumn == -1) return null;
var s=this.mFieldData[this.mIDCodeColumn];
return (s == null  || s.isEmpty$() ) ? null : s;
});

Clazz.newMeth(C$, 'getCoordinates$',  function () {
if (this.mCoordinateColumn == -1) return null;
var s=this.mFieldData[this.mCoordinateColumn];
return (s == null  || s.isEmpty$() ) ? null : s;
});

Clazz.newMeth(C$, 'getCoordinates2D$',  function () {
if (this.mCoordinate2DColumn == -1) return null;
var s=this.mFieldData[this.mCoordinate2DColumn];
return (s == null  || s.isEmpty$() ) ? null : s;
});

Clazz.newMeth(C$, 'getCoordinates3D$',  function () {
if (this.mCoordinate3DColumn == -1) return null;
var s=this.mFieldData[this.mCoordinate3DColumn];
return (s == null  || s.isEmpty$() ) ? null : s;
});

Clazz.newMeth(C$, 'getReaction$Z',  function (ensureCoordinates) {
var rxnCode=null;
var rxnColumn=null;
for (var sf, $sf = this.mSpecialFieldMap.values$().iterator$(); $sf.hasNext$()&&((sf=($sf.next$())),1);) {
if ("rxncode".equals$O(sf.type)) {
rxnColumn=sf.name;
rxnCode=this.mFieldData[sf.fieldIndex];
break;
}}
if (rxnCode == null ) return null;
var rxnMapping=null;
var rxnCoords=null;
var rxnCatalysts=null;
for (var sf, $sf = this.mSpecialFieldMap.values$().iterator$(); $sf.hasNext$()&&((sf=($sf.next$())),1);) {
if ("atomMapping".equals$O(sf.type) && rxnColumn.equals$O(sf.parent) ) rxnMapping=this.mFieldData[sf.fieldIndex];
 else if ("idcoordinates2D".equals$O(sf.type) && rxnColumn.equals$O(sf.parent) ) rxnCoords=this.mFieldData[sf.fieldIndex];
 else if ("idcode".equals$O(sf.type) && sf.name.equals$O(this.getColumnProperties$S(rxnColumn).getProperty$S("catalystColumn")) ) rxnCatalysts=this.mFieldData[sf.fieldIndex];
}
return rxnMapping == null  && rxnCoords == null   && rxnCatalysts == null   ? $I$(20).decode$S$Z(rxnCode, ensureCoordinates) : $I$(20).decode$S$S$S$S$S$Z$com_actelion_research_chem_reaction_Reaction(rxnCode, rxnMapping, rxnCoords, null, rxnCatalysts, ensureCoordinates, null);
});

Clazz.newMeth(C$, 'getMoleculeName$',  function () {
if (this.mMoleculeNameColumn == -1) return null;
var s=this.mFieldData[this.mMoleculeNameColumn];
return (s == null  || s.isEmpty$() ) ? null : s;
});

Clazz.newMeth(C$, 'getDescriptor$S',  function (shortName) {
var column=(this.mDescriptorColumnMap == null ) ? null : this.mDescriptorColumnMap.get$O(shortName);
var s=(column == null ) ? null : this.mFieldData[column.intValue$()];
return (s == null  || s.isEmpty$() ) ? C$.superclazz.prototype.getDescriptor$S.apply(this, [shortName]) : (this.getDescriptorHandlerFactory$() == null ) ? null : this.getDescriptorHandlerFactory$().getDefaultDescriptorHandler$S(shortName).decode$S(s);
});

Clazz.newMeth(C$, 'getIndex$',  function () {
if (this.mFragFpColumn == -1) return null;
var s=this.mFieldData[this.mFragFpColumn];
return (s == null  || s.isEmpty$() ) ? null : s;
});

Clazz.newMeth(C$, 'getFieldData$I',  function (no) {
return this.mFieldData[this.mFieldIndex[no]];
});

Clazz.newMeth(C$, 'getSpecialFieldMap$',  function () {
return this.mSpecialFieldMap;
});

Clazz.newMeth(C$, 'getSpecialFieldData$I',  function (fieldIndex) {
return this.mFieldData[fieldIndex];
});

Clazz.newMeth(C$, 'getColumnProperties$S',  function (columnName) {
return this.mColumnPropertyMap.get$O(columnName);
});

Clazz.newMeth(C$, 'extractValue$S',  function (theLine) {
var index1=theLine.indexOf$S("=\"") + 2;
var index2=theLine.indexOf$S$I("\"", index1);
return theLine.substring$I$I(index1, index2);
}, p$1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.DWARFileParser, "SpecialField", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['fieldIndex'],'S',['name','type','parent','idColumn','version']]]

Clazz.newMeth(C$, 'c$$S$S$S$S$S',  function (name, type, parent, idColumn, version) {
;C$.$init$.apply(this);
this.name=name;
this.type=type;
this.parent=parent;
this.idColumn=idColumn;
this.version=version;
this.fieldIndex=-1;
}, 1);

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:39 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
