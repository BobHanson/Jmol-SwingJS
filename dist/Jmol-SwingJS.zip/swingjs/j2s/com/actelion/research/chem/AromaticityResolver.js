(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'com.actelion.research.chem.RingCollection']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AromaticityResolver");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['mAllHydrogensAreExplicit'],'I',['mDelocalizedAtoms','mDelocalizedBonds','mPiElectronsAdded'],'O',['mMol','com.actelion.research.chem.ExtendedMolecule','mIsDelocalizedRing','boolean[]','+mIsDelocalizedAtom','+mIsDelocalizedBond','+mIsDelocalizedBridgeHead','+mIsDelocalizedFiveRingMember','+mIsDelocalizedThreeOrSevenRingMember']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_ExtendedMolecule',  function (mol) {
;C$.$init$.apply(this);
this.mMol=mol;
}, 1);

Clazz.newMeth(C$, 'locateDelocalizedDoubleBonds$ZA',  function (isAromaticBond) {
return this.locateDelocalizedDoubleBonds$ZA$Z$Z(isAromaticBond, false, false);
});

Clazz.newMeth(C$, 'locateDelocalizedDoubleBonds$ZA$Z$Z',  function (isDelocalizedBond, mayChangeAtomCharges, allHydrogensAreExplicit) {
this.mMol.ensureHelperArrays$I(1);
var ringSet=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_ExtendedMolecule$I,[this.mMol, 1]);
p$1.initialize$ZA$com_actelion_research_chem_RingCollection.apply(this, [isDelocalizedBond, ringSet]);
if (this.mDelocalizedBonds == 0) return true;
if (mayChangeAtomCharges) for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mIsDelocalizedAtom[atom] && this.mMol.getAtomicNo$I(atom) == 7  && (this.mIsDelocalizedBridgeHead[atom] || (this.mMol.getConnAtoms$I(atom) == 3 && !this.mIsDelocalizedFiveRingMember[atom] ) ) ) this.mMol.setAtomCharge$I$I(atom, 1);

this.mAllHydrogensAreExplicit=allHydrogensAreExplicit;
p$1.protectFullValenceAtoms$Z.apply(this, [mayChangeAtomCharges]);
if (this.mMol.isFragment$()) p$1.promoteDelocalizedChains.apply(this, []);
p$1.protectObviousNonRingLeaks$com_actelion_research_chem_RingCollection.apply(this, [ringSet]);
p$1.protectAmideBonds$com_actelion_research_chem_RingCollection.apply(this, [ringSet]);
p$1.protectDoubleBondAtoms.apply(this, []);
p$1.promoteObviousBonds.apply(this, []);
while (p$1.promoteOuterShellDelocalizedRingSystems$com_actelion_research_chem_RingCollection$Z.apply(this, [ringSet, mayChangeAtomCharges]))p$1.promoteObviousBonds.apply(this, []);

if (p$1.promoteSixMemberedAromaticRings$com_actelion_research_chem_RingCollection$Z.apply(this, [ringSet, mayChangeAtomCharges])) p$1.promoteObviousBonds.apply(this, []);
while (p$1.promoteOneDelocalizationLeak$com_actelion_research_chem_RingCollection$Z.apply(this, [ringSet, mayChangeAtomCharges]))p$1.promoteObviousBonds.apply(this, []);

while (this.mDelocalizedBonds != 0){
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mIsDelocalizedBond[bond]) {
p$1.promoteBond$I.apply(this, [bond]);
p$1.promoteObviousBonds.apply(this, []);
}}
}
if (this.mDelocalizedAtoms - this.mPiElectronsAdded >= 2) p$1.connectSeparatedSingletons.apply(this, []);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mIsDelocalizedAtom[atom] && this.mMol.getImplicitHydrogens$I(atom) != 0 ) {
if (mayChangeAtomCharges && ((this.mMol.getAtomCharge$I(atom) == 1 && this.mMol.isElectronegative$I(atom) ) || (this.mMol.getAtomCharge$I(atom) == -1 && this.mMol.getAtomicNo$I(atom) == 5 ) ) ) this.mMol.setAtomCharge$I$I(atom, 0);
 else this.mMol.setAtomRadical$I$I(atom, 32);
++this.mPiElectronsAdded;
}}
return (this.mDelocalizedAtoms == this.mPiElectronsAdded);
});

Clazz.newMeth(C$, 'initialize$ZA$com_actelion_research_chem_RingCollection',  function (isDelocalizedBond, ringSet) {
if (isDelocalizedBond != null ) {
this.mIsDelocalizedBond=isDelocalizedBond;
} else {
this.mIsDelocalizedBond=Clazz.array(Boolean.TYPE, [this.mMol.getBonds$()]);
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondType$I(bond) == 8) {
this.mIsDelocalizedBond[bond]=true;
this.mMol.setBondType$I$I(bond, 1);
}}
}for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (this.mIsDelocalizedBond[bond]) ++this.mDelocalizedBonds;

this.mIsDelocalizedAtom=Clazz.array(Boolean.TYPE, [this.mMol.getAtoms$()]);
this.mIsDelocalizedBridgeHead=Clazz.array(Boolean.TYPE, [this.mMol.getAtoms$()]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
var delocalizedConnBonds=0;
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) if (this.mIsDelocalizedBond[this.mMol.getConnBond$I$I(atom, i)]) ++delocalizedConnBonds;

if (delocalizedConnBonds > 0) {
this.mIsDelocalizedAtom[atom]=true;
++this.mDelocalizedAtoms;
if (delocalizedConnBonds == 3) this.mIsDelocalizedBridgeHead[atom]=true;
}}
this.mIsDelocalizedRing=Clazz.array(Boolean.TYPE, [ringSet.getSize$()]);
for (var ring=0; ring < ringSet.getSize$(); ring++) {
this.mIsDelocalizedRing[ring]=true;
for (var bond, $bond = 0, $$bond = ringSet.getRingBonds$I(ring); $bond<$$bond.length&&((bond=($$bond[$bond])),1);$bond++) {
if (!this.mIsDelocalizedBond[bond]) {
this.mIsDelocalizedRing[ring]=false;
break;
}}
}
this.mIsDelocalizedThreeOrSevenRingMember=Clazz.array(Boolean.TYPE, [this.mMol.getAtoms$()]);
this.mIsDelocalizedFiveRingMember=Clazz.array(Boolean.TYPE, [this.mMol.getAtoms$()]);
for (var ring=0; ring < ringSet.getSize$(); ring++) {
if (this.mIsDelocalizedRing[ring] && ringSet.getRingSize$I(ring) != 6 ) {
for (var atom, $atom = 0, $$atom = ringSet.getRingAtoms$I(ring); $atom<$$atom.length&&((atom=($$atom[$atom])),1);$atom++) {
if (ringSet.getRingSize$I(ring) == 5) this.mIsDelocalizedFiveRingMember[atom]=true;
 else this.mIsDelocalizedThreeOrSevenRingMember[atom]=true;
}
}}
this.mPiElectronsAdded=0;
}, p$1);

Clazz.newMeth(C$, 'promoteSixMemberedAromaticRings$com_actelion_research_chem_RingCollection$Z',  function (ringSet, mayChangeAtomCharges) {
var found=false;
for (var ring=0; ring < ringSet.getSize$(); ring++) {
if (ringSet.getRingSize$I(ring) == 6) {
var isQualifyingRing=true;
var ringAtom=ringSet.getRingAtoms$I(ring);
var ringBond=ringSet.getRingBonds$I(ring);
for (var i=0; i < 6; i++) {
if (!p$1.checkAtomTypePi1$I$Z.apply(this, [ringAtom[i], false]) || !this.mIsDelocalizedBond[ringBond[i]] ) {
isQualifyingRing=false;
break;
}}
if (isQualifyingRing) {
if (mayChangeAtomCharges) for (var i=0; i < 6; i++) p$1.checkAtomTypePi1$I$Z.apply(this, [ringAtom[i], true]);

for (var i=0; i < 6; i+=2) p$1.promoteBond$I.apply(this, [ringBond[i]]);

found=true;
break;
}}}
return found;
}, p$1);

Clazz.newMeth(C$, 'promoteOneDelocalizationLeak$com_actelion_research_chem_RingCollection$Z',  function (ringSet, mayChangeAtomCharges) {
for (var ring=0; ring < ringSet.getSize$(); ring++) {
if (ringSet.getRingSize$I(ring) != 6 && this.mIsDelocalizedRing[ring] ) {
var isFullyDelocalizedRing=true;
var ringBond=ringSet.getRingBonds$I(ring);
for (var i=0; i < ringBond.length; i++) {
if (!this.mIsDelocalizedBond[ringBond[i]]) {
isFullyDelocalizedRing=false;
break;
}}
if (isFullyDelocalizedRing) {
var bestDelocalizationLeakIndex=-1;
var bestDelocalizationLeakPriority=0;
var ringAtom=ringSet.getRingAtoms$I(ring);
for (var i=0; i < ringAtom.length; i++) {
var atom=ringAtom[i];
var priority=this.mIsDelocalizedFiveRingMember[atom] ? p$1.checkAtomTypeLeak5$I$Z.apply(this, [atom, false]) : p$1.checkAtomTypeLeak7$I$Z.apply(this, [atom, false]);
if (bestDelocalizationLeakPriority < priority) {
bestDelocalizationLeakPriority=priority;
bestDelocalizationLeakIndex=i;
}}
if (bestDelocalizationLeakIndex != -1) {
var atom=ringAtom[bestDelocalizationLeakIndex];
if (mayChangeAtomCharges) {
if (this.mIsDelocalizedFiveRingMember[atom]) p$1.checkAtomTypeLeak5$I$Z.apply(this, [atom, true]);
 else p$1.checkAtomTypeLeak7$I$Z.apply(this, [atom, true]);
}p$1.protectAtom$I.apply(this, [atom]);
return true;
}}}}
return false;
}, p$1);

Clazz.newMeth(C$, 'promoteOuterShellDelocalizedRingSystems$com_actelion_research_chem_RingCollection$Z',  function (ringSet, mayChangeAtomCharges) {
var sharedDelocalizedRingCount=Clazz.array(Integer.TYPE, [this.mMol.getBonds$()]);
for (var r=0; r < ringSet.getSize$(); r++) {
var ringBond=ringSet.getRingBonds$I(r);
var isDelocalized=true;
for (var i=0; i < ringBond.length; i++) {
if (!this.mIsDelocalizedBond[ringBond[i]]) {
isDelocalized=false;
break;
}}
if (isDelocalized) for (var i=0; i < ringBond.length; i++) ++sharedDelocalizedRingCount[ringBond[i]];

}
var delocalizedBonds=this.mDelocalizedBonds;
for (var r=0; r < ringSet.getSize$(); r++) {
var found=false;
var ringAtom=ringSet.getRingAtoms$I(r);
var ringBond=ringSet.getRingBonds$I(r);
for (var i=0; i < ringBond.length && !found ; i++) {
if (sharedDelocalizedRingCount[ringBond[i]] > 1) {
var first=p$1.nextIndex$I$I.apply(this, [i, ringBond.length]);
if (sharedDelocalizedRingCount[ringBond[first]] == 1) {
var incompatibleAtomFound=false;
var next=p$1.nextIndex$I$I.apply(this, [first, ringBond.length]);
while (sharedDelocalizedRingCount[ringBond[next]] == 1){
if (!p$1.checkAtomTypePi1$I$Z.apply(this, [ringAtom[next], false]) || (ringBond.length != 6 && this.mMol.getAtomicNo$I(ringAtom[next]) != 6 ) ) incompatibleAtomFound=true;
next=p$1.nextIndex$I$I.apply(this, [next, ringBond.length]);
}
if (!incompatibleAtomFound) {
var bridgeBonds=(next > first) ? next - first : next + ringBond.length - first;
if (bridgeBonds > 2 && (bridgeBonds & 1) == 1 ) {
for (var j=1; j < bridgeBonds; j+=2) {
var index=(first + j < ringBond.length) ? first + j : first + j - ringBond.length;
if (mayChangeAtomCharges) {
p$1.checkAtomTypePi1$I$Z.apply(this, [ringAtom[index], true]);
p$1.checkAtomTypePi1$I$Z.apply(this, [ringAtom[index == ringAtom.length - 1 ? 0 : index + 1], true]);
}p$1.promoteBond$I.apply(this, [ringBond[index]]);
}
found=true;
}}}}}
}
return delocalizedBonds != this.mDelocalizedBonds;
}, p$1);

Clazz.newMeth(C$, 'nextIndex$I$I',  function (i, size) {
return i == size - 1 ? 0 : i + 1;
}, p$1);

Clazz.newMeth(C$, 'protectFullValenceAtoms$Z',  function (mayChangeAtomCharges) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mIsDelocalizedAtom[atom] && this.mMol.getLowestFreeValence$I(atom) == 0  && (!mayChangeAtomCharges || (this.mMol.getAtomicNo$I(atom) == 5 && this.mMol.getAtomCharge$I(atom) < 0 ) || (this.mMol.getAtomicNo$I(atom) == 6 || this.mMol.getAtomicNo$I(atom) == 14 ) || (this.mMol.isElectronegative$I(atom) && this.mMol.getAtomCharge$I(atom) > 0 )  ) ) p$1.protectAtom$I.apply(this, [atom]);

}, p$1);

Clazz.newMeth(C$, 'protectAtom$I',  function (atom) {
if (this.mIsDelocalizedAtom[atom]) {
this.mIsDelocalizedAtom[atom]=false;
--this.mDelocalizedAtoms;
}for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) {
var connBond=this.mMol.getConnBond$I$I(atom, i);
if (this.mIsDelocalizedBond[connBond]) {
this.mIsDelocalizedBond[connBond]=false;
--this.mDelocalizedBonds;
}}
}, p$1);

Clazz.newMeth(C$, 'promoteBond$I',  function (bond) {
if (this.mMol.getBondType$I(bond) == 1) {
this.mMol.setBondType$I$I(bond, 2);
this.mPiElectronsAdded+=2;
}for (var i=0; i < 2; i++) {
var bondAtom=this.mMol.getBondAtom$I$I(i, bond);
this.mIsDelocalizedAtom[bondAtom]=false;
for (var j=0; j < this.mMol.getConnAtoms$I(bondAtom); j++) {
var connBond=this.mMol.getConnBond$I$I(bondAtom, j);
if (this.mIsDelocalizedBond[connBond]) {
this.mIsDelocalizedBond[connBond]=false;
--this.mDelocalizedBonds;
}}
}
}, p$1);

Clazz.newMeth(C$, 'promoteObviousBonds',  function () {
var terminalAromaticBondFound;
do {
terminalAromaticBondFound=false;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mIsDelocalizedBond[bond]) {
var isTerminalAromaticBond=false;
for (var i=0; i < 2; i++) {
var bondAtom=this.mMol.getBondAtom$I$I(i, bond);
var aromaticNeighbourFound=false;
for (var j=0; j < this.mMol.getConnAtoms$I(bondAtom); j++) {
if (bond != this.mMol.getConnBond$I$I(bondAtom, j) && this.mIsDelocalizedBond[this.mMol.getConnBond$I$I(bondAtom, j)] ) {
aromaticNeighbourFound=true;
break;
}}
if (!aromaticNeighbourFound) {
isTerminalAromaticBond=true;
break;
}}
if (isTerminalAromaticBond) {
terminalAromaticBondFound=true;
p$1.promoteBond$I.apply(this, [bond]);
}}}
} while (terminalAromaticBondFound);
}, p$1);

Clazz.newMeth(C$, 'promoteDelocalizedChains',  function () {
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mIsDelocalizedBond[bond]) {
for (var i=0; i < 2; i++) {
var terminalAtom=this.mMol.getBondAtom$I$I(i, bond);
var aromaticNeighbourFound=false;
for (var j=0; j < this.mMol.getConnAtoms$I(terminalAtom); j++) {
if (bond != this.mMol.getConnBond$I$I(terminalAtom, j) && this.mIsDelocalizedBond[this.mMol.getConnBond$I$I(terminalAtom, j)] ) {
aromaticNeighbourFound=true;
break;
}}
if (!aromaticNeighbourFound) {
var terminalBond=bond;
var bridgeAtom=this.mMol.getBondAtom$I$I(1 - i, bond);
while (terminalBond != -1){
this.mIsDelocalizedAtom[terminalAtom]=false;
this.mIsDelocalizedBond[terminalBond]=false;
--this.mDelocalizedBonds;
this.mMol.setBondType$I$I(terminalBond, 8);
terminalBond=-1;
terminalAtom=bridgeAtom;
for (var j=0; j < this.mMol.getConnAtoms$I(terminalAtom); j++) {
if (this.mIsDelocalizedBond[this.mMol.getConnBond$I$I(terminalAtom, j)]) {
if (terminalBond == -1) {
terminalBond=this.mMol.getConnBond$I$I(terminalAtom, j);
bridgeAtom=this.mMol.getConnAtom$I$I(terminalAtom, j);
} else {
terminalAtom=-1;
terminalBond=-1;
break;
}}}
}
if (terminalAtom != -1) this.mIsDelocalizedAtom[bridgeAtom]=false;
break;
}}
}}
}, p$1);

Clazz.newMeth(C$, 'protectAmideBonds$com_actelion_research_chem_RingCollection',  function (ringSet) {
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mIsDelocalizedBond[bond] && ringSet.qualifiesAsAmideTypeBond$I(bond) ) {
p$1.protectAtom$I.apply(this, [this.mMol.getBondAtom$I$I(0, bond)]);
p$1.protectAtom$I.apply(this, [this.mMol.getBondAtom$I$I(1, bond)]);
}}
}, p$1);

Clazz.newMeth(C$, 'protectDoubleBondAtoms',  function () {
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondOrder$I(bond) == 2) {
for (var i=0; i < 2; i++) {
var atom=this.mMol.getBondAtom$I$I(i, bond);
if (this.mMol.getAtomicNo$I(atom) <= 8) {
for (var j=0; j < this.mMol.getConnAtoms$I(atom); j++) {
var connBond=this.mMol.getConnBond$I$I(atom, j);
if (this.mIsDelocalizedBond[connBond]) {
p$1.protectAtom$I.apply(this, [atom]);
break;
}}
}}
}}
}, p$1);

Clazz.newMeth(C$, 'protectObviousNonRingLeaks$com_actelion_research_chem_RingCollection',  function (ringSet) {
var isAromaticRingAtom=Clazz.array(Boolean.TYPE, [this.mMol.getAtoms$()]);
for (var ring=0; ring < ringSet.getSize$(); ring++) {
var ringSize=ringSet.getRingSize$I(ring);
if (ringSize == 3 || ringSize == 5  || ringSize == 6  || ringSize == 7 ) {
if (this.mIsDelocalizedRing[ring]) {
for (var atom, $atom = 0, $$atom = ringSet.getRingAtoms$I(ring); $atom<$$atom.length&&((atom=($$atom[$atom])),1);$atom++) isAromaticRingAtom[atom]=true;

}}}
var delocalizedNeighbourCount=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
var hasMetalLigandBond=Clazz.array(Boolean.TYPE, [this.mMol.getAtoms$()]);
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
var atom1=this.mMol.getBondAtom$I$I(0, bond);
var atom2=this.mMol.getBondAtom$I$I(1, bond);
if (!isAromaticRingAtom[atom1] && !isAromaticRingAtom[atom2] ) {
if (this.mIsDelocalizedBond[bond]) {
++delocalizedNeighbourCount[atom1];
++delocalizedNeighbourCount[atom2];
}if (this.mMol.getBondType$I(bond) == 16) {
hasMetalLigandBond[atom1]=true;
hasMetalLigandBond[atom2]=true;
}}}
var priority=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
var graphAtom=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
for (var seedAtom=0; seedAtom < this.mMol.getAtoms$(); seedAtom++) {
if (delocalizedNeighbourCount[seedAtom] == 1) {
graphAtom[0]=seedAtom;
var current=0;
var highest=0;
while (current <= highest){
for (var i=0; i < this.mMol.getConnAtoms$I(graphAtom[current]); i++) {
if (this.mIsDelocalizedBond[this.mMol.getConnBond$I$I(graphAtom[current], i)]) {
var candidate=this.mMol.getConnAtom$I$I(graphAtom[current], i);
if ((current == 0 || candidate != graphAtom[current - 1] ) && delocalizedNeighbourCount[candidate] != 0 ) {
graphAtom[++highest]=candidate;
if ((delocalizedNeighbourCount[candidate] & 1) != 0) {
for (var j=1; j < highest; j+=2) priority[graphAtom[j]]=-1;

highest=0;
}break;
}}}
++current;
}
}}
var atomHandled=Clazz.array(Boolean.TYPE, [this.mMol.getAtoms$()]);
for (var seedAtom=0; seedAtom < this.mMol.getAtoms$(); seedAtom++) {
if (!atomHandled[seedAtom] && delocalizedNeighbourCount[seedAtom] != 0 ) {
graphAtom[0]=seedAtom;
atomHandled[seedAtom]=true;
var current=0;
var highest=0;
while (current <= highest){
for (var i=0; i < this.mMol.getConnAtoms$I(graphAtom[current]); i++) {
if (this.mIsDelocalizedBond[this.mMol.getConnBond$I$I(graphAtom[current], i)]) {
var candidate=this.mMol.getConnAtom$I$I(graphAtom[current], i);
if (!atomHandled[candidate]) {
graphAtom[++highest]=candidate;
atomHandled[candidate]=true;
}}}
++current;
}
if ((highest & 1) == 0) {
for (var i=0; i <= highest; i++) if (priority[graphAtom[i]] == 0) priority[graphAtom[i]]=p$1.checkAtomTypeLeakNonRing$I$Z.apply(this, [graphAtom[i], false]);

var isPossible=true;
for (var i=0; i <= highest; i++) {
if (priority[graphAtom[i]] <= 0) {
if (!p$1.checkAtomTypePi1$I$Z.apply(this, [graphAtom[i], false])) {
isPossible=false;
break;
}}}
if (isPossible) {
var maxPriority=0;
var maxAtom=-1;
for (var i=0; i <= highest; i++) {
if (maxPriority < priority[graphAtom[i]]) {
maxPriority=priority[graphAtom[i]];
maxAtom=graphAtom[i];
}}
if (maxPriority > 0) {
p$1.checkAtomTypeLeakNonRing$I$Z.apply(this, [maxAtom, true]);
p$1.protectAtom$I.apply(this, [maxAtom]);
}}}}}
}, p$1);

Clazz.newMeth(C$, 'connectSeparatedSingletons',  function () {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mMol.ensureHelperArrays$I(1);
if (this.mIsDelocalizedAtom[atom]) {
var found=false;
var graphAtom=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
var parentAtom=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
var graphLevel=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
graphAtom[0]=atom;
parentAtom[atom]=-1;
graphLevel[atom]=1;
var current=0;
var highest=0;
while (current <= highest && !found ){
var currentAtom=graphAtom[current];
for (var i=0; i < this.mMol.getConnAtoms$I(currentAtom) && !found ; i++) {
var isCompatibleBond=!!(((graphLevel[currentAtom] & 1) == 1) ^ (this.mMol.getBondOrder$I(this.mMol.getConnBond$I$I(currentAtom, i)) > 1));
var candidate=this.mMol.getConnAtom$I$I(currentAtom, i);
if (graphLevel[candidate] == 0 && isCompatibleBond ) {
if (this.mIsDelocalizedAtom[candidate]) {
if ((graphLevel[currentAtom] & 1) == 1) {
this.mIsDelocalizedAtom[atom]=false;
this.mIsDelocalizedAtom[candidate]=false;
this.mPiElectronsAdded+=2;
var parent=currentAtom;
for (var j=0; j < graphLevel[currentAtom]; j++) {
var bond=this.mMol.getBond$I$I(candidate, parent);
if (this.mIsDelocalizedBond[bond]) {
this.mIsDelocalizedBond[bond]=false;
--this.mDelocalizedBonds;
}this.mMol.setBondOrder$I$I(bond, this.mMol.getBondOrder$I(bond) == 1 ? 2 : this.mMol.getBondOrder$I(bond) - 1);
candidate=parent;
parent=parentAtom[candidate];
}
found=true;
}} else {
graphAtom[++highest]=candidate;
parentAtom[candidate]=currentAtom;
graphLevel[candidate]=graphLevel[currentAtom] + 1;
}}}
++current;
}
}}
}, p$1);

Clazz.newMeth(C$, 'checkAtomTypePi1$I$Z',  function (atom, correctCharge) {
var atomicNo=this.mMol.getAtomicNo$I(atom);
if ((atomicNo >= 5 && atomicNo <= 8 ) || atomicNo == 15  || atomicNo == 16  || atomicNo == 33  || atomicNo == 34  || atomicNo == 52 ) {
var freeValence=this.mMol.getLowestFreeValence$I(atom);
if (freeValence != 0) return true;
var charge=this.mMol.getAtomCharge$I(atom);
if (atomicNo == 5 && charge >= 0 ) {
if (correctCharge) this.mMol.setAtomCharge$I$I(atom, charge - 1);
return true;
}if (atomicNo != 5 && charge <= 0 ) {
if (correctCharge) this.mMol.setAtomCharge$I$I(atom, charge + 1);
return true;
}}return false;
}, p$1);

Clazz.newMeth(C$, 'checkAtomTypeLeak5$I$Z',  function (atom, correctCharge) {
if (this.mIsDelocalizedBridgeHead[atom]) return 0;
if (this.mMol.getAtomicNo$I(atom) == 7) {
if (this.mMol.getAllConnAtoms$I(atom) == 3) return 6;
 else if (this.mMol.getConnAtoms$I(atom) == 2) return this.mAllHydrogensAreExplicit ? 0 : 4;
} else if (this.mMol.getAtomicNo$I(atom) == 8) {
return 10;
} else if (this.mMol.getAtomicNo$I(atom) == 15 || this.mMol.getAtomicNo$I(atom) == 33 ) {
if (this.mMol.getConnAtoms$I(atom) == 3) return 8;
} else if (this.mMol.getAtomicNo$I(atom) == 16 || this.mMol.getAtomicNo$I(atom) == 34  || this.mMol.getAtomicNo$I(atom) == 52 ) {
if (this.mMol.getConnAtoms$I(atom) == 2) return 11;
if (this.mMol.getConnAtoms$I(atom) == 3) {
if (this.mMol.getAtomCharge$I(atom) == 1) return 12;
if (correctCharge) this.mMol.setAtomCharge$I$I(atom, 1);
return 5;
}} else if (this.mMol.getAtomicNo$I(atom) == 6) {
if (this.mMol.getAtomCharge$I(atom) == -1) return this.mMol.getAllConnAtoms$I(atom) == 3 ? 16 : this.mMol.getAllConnAtomsPlusMetalBonds$I(atom) == 3 ? 15 : 14;
;if (correctCharge) this.mMol.setAtomCharge$I$I(atom, -1);
return (this.mMol.getAllConnAtoms$I(atom) != this.mMol.getAllConnAtomsPlusMetalBonds$I(atom)) ? 2 : 3;
}return 0;
}, p$1);

Clazz.newMeth(C$, 'checkAtomTypeLeak7$I$Z',  function (atom, correctCharge) {
if (this.mIsDelocalizedBridgeHead[atom]) return 0;
if (this.mAllHydrogensAreExplicit) {
if (this.mMol.getAllConnAtoms$I(atom) != 3) return 0;
} else {
if (this.mMol.getAllConnAtoms$I(atom) > 3) return 0;
}if (this.mMol.getAtomicNo$I(atom) == 6) {
if (correctCharge) this.mMol.setAtomCharge$I$I(atom, 1);
return 2;
}if (this.mMol.getAtomicNo$I(atom) == 5) {
return 4;
}return 0;
}, p$1);

Clazz.newMeth(C$, 'checkAtomTypeLeakNonRing$I$Z',  function (atom, correctCharge) {
if (this.mMol.getAtomCharge$I(atom) != 0) return 0;
if (this.mAllHydrogensAreExplicit) {
if (this.mMol.getAtomicNo$I(atom) == 5) {
if (this.mMol.getOccupiedValence$I(atom) != 2) return 0;
if (correctCharge) this.mMol.setAtomCharge$I$I(atom, 1);
return 1;
}if (this.mMol.getAtomicNo$I(atom) == 7) {
if (this.mMol.getOccupiedValence$I(atom) != 2) return 0;
if (correctCharge) this.mMol.setAtomCharge$I$I(atom, -1);
return p$1.hasMetalNeighbour$I.apply(this, [atom]) ? 6 : 3;
}if (this.mMol.getAtomicNo$I(atom) == 8) {
if (this.mMol.getOccupiedValence$I(atom) != 1) return 0;
if (correctCharge) this.mMol.setAtomCharge$I$I(atom, -1);
return p$1.hasMetalNeighbour$I.apply(this, [atom]) ? 7 : 4;
}if (this.mMol.getAtomicNo$I(atom) == 16) {
if (this.mMol.getOccupiedValence$I(atom) != 1) return 0;
if (correctCharge) this.mMol.setAtomCharge$I$I(atom, -1);
return p$1.hasMetalNeighbour$I.apply(this, [atom]) ? 5 : 2;
}if (this.mMol.getAtomicNo$I(atom) == 34) {
if (this.mMol.getOccupiedValence$I(atom) != 1) return 0;
if (correctCharge) this.mMol.setAtomCharge$I$I(atom, -1);
return p$1.hasMetalNeighbour$I.apply(this, [atom]) ? 4 : 1;
}} else {
if (this.mMol.getAtomicNo$I(atom) == 5) {
if (this.mMol.getOccupiedValence$I(atom) > 2) return 0;
if (correctCharge) this.mMol.setAtomCharge$I$I(atom, 1);
return 1;
}if (this.mMol.getAtomicNo$I(atom) == 7) {
if (this.mMol.getOccupiedValence$I(atom) > 2) return 0;
if (correctCharge) this.mMol.setAtomCharge$I$I(atom, -1);
return p$1.hasMetalNeighbour$I.apply(this, [atom]) ? 5 : 3;
}if (this.mMol.getAtomicNo$I(atom) == 8) {
if (this.mMol.getOccupiedValence$I(atom) > 1) return 0;
if (correctCharge) this.mMol.setAtomCharge$I$I(atom, -1);
return p$1.hasMetalNeighbour$I.apply(this, [atom]) ? 7 : 4;
}if (this.mMol.getAtomicNo$I(atom) == 16) {
if (this.mMol.getOccupiedValence$I(atom) > 1) return 0;
if (correctCharge) this.mMol.setAtomCharge$I$I(atom, -1);
return p$1.hasMetalNeighbour$I.apply(this, [atom]) ? 5 : 2;
}}return 0;
}, p$1);

Clazz.newMeth(C$, 'hasMetalNeighbour$I',  function (atom) {
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) if (this.mMol.isMetalAtom$I(this.mMol.getConnAtom$I$I(atom, i))) return true;

return false;
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:28 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
