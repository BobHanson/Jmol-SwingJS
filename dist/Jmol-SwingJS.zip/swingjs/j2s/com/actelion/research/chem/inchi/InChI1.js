(function(){var P$=Clazz.newPackage("com.actelion.research.chem.inchi"),I$=[[0,'java.util.Hashtable','io.github.dan2097.jnainchi.InchiInput','io.github.dan2097.jnainchi.InchiAtom','com.actelion.research.chem.Molecule','io.github.dan2097.jnainchi.InchiBond','io.github.dan2097.jnainchi.InchiBondType','io.github.dan2097.jnainchi.InchiBondStereo','io.github.dan2097.jnainchi.JnaInchi','org.iupac.InchiUtils','java.util.HashMap']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InChI1", null, 'com.actelion.research.chem.inchi.InChIOCL');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.map=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['O',['inchiModel','io.github.dan2097.jnainchi.InchiInput','map','java.util.Map','thisAtom','io.github.dan2097.jnainchi.InchiAtom','thisBond','io.github.dan2097.jnainchi.InchiBond','thisStereo','io.github.dan2097.jnainchi.InchiStereo']]]

Clazz.newMeth(C$, 'initAndRun$Runnable',  function (r) {
r.run$();
});

Clazz.newMeth(C$, 'getInchiImpl$com_actelion_research_chem_StereoMolecule$S$S',  function (mol, molFileDataOrInChI, options) {
});

Clazz.newMeth(C$, 'newInchiStructure$com_actelion_research_chem_StereoMolecule',  function (mol) {
mol.ensureHelperArrays$I(1);
var struc=Clazz.new_($I$(2,1));
var nAtoms=mol.getAllAtoms$();
var atoms=Clazz.array($I$(3), [nAtoms]);
for (var i=0; i < nAtoms; i++) {
var elem=mol.getAtomicNo$I(i);
var sym=$I$(4).cAtomLabel[elem];
var iso=mol.getAtomMass$I(i);
if (elem == 1) {
sym="H";
}var a=atoms[i]=Clazz.new_([sym, mol.getAtomX$I(i), -mol.getAtomY$I(i), mol.getAtomZ$I(i)],$I$(3,1).c$$S$D$D$D);
struc.addAtom$io_github_dan2097_jnainchi_InchiAtom(a);
a.setCharge$I(mol.getAtomCharge$I(i));
if (iso > 0) a.setIsotopicMass$I(iso);
a.setImplicitHydrogen$I(mol.getImplicitHydrogens$I(i));
}
var nBonds=mol.getAllBonds$();
for (var i=0; i < nBonds; i++) {
var oclOrder=mol.getBondTypeSimple$I(i);
var order=C$.getInChIOrder$I(oclOrder);
if (order != null ) {
var atom1=mol.getBondAtom$I$I(0, i);
var atom2=mol.getBondAtom$I$I(1, i);
var oclType=mol.getBondType$I(i);
var oclParity=mol.getBondParity$I(i);
var stereo=C$.getInChIStereo$I$I$I(oclOrder, oclType, oclParity);
var bond=Clazz.new_($I$(5,1).c$$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType$io_github_dan2097_jnainchi_InchiBondStereo,[atoms[atom1], atoms[atom2], order, stereo]);
struc.addBond$io_github_dan2097_jnainchi_InchiBond(bond);
}}
return struc;
}, 1);

Clazz.newMeth(C$, 'getInChIOrder$I',  function (oclOrder) {
switch (oclOrder) {
case 1:
return $I$(6).SINGLE;
case 2:
return $I$(6).DOUBLE;
case 4:
return $I$(6).TRIPLE;
case 8:
return $I$(6).ALTERN;
case 16:
default:
return null;
}
}, 1);

Clazz.newMeth(C$, 'getInChIStereo$I$I$I',  function (oclOrder, oclType, oclParity) {
if (oclOrder == 1) {
switch (oclType) {
case 129:
return $I$(7).SINGLE_1DOWN;
case 257:
return $I$(7).SINGLE_1UP;
default:
if (oclParity == 3) {
return (oclOrder == 2 ? $I$(7).DOUBLE_EITHER : $I$(7).SINGLE_1EITHER);
}}
}return $I$(7).NONE;
}, 1);

Clazz.newMeth(C$, 'initializeInchiModel$S',  function (inchi) {
this.inchiModel=$I$(8).getInchiInputFromInchi$S(inchi).getInchiInput$();
for (var i=this.getNumAtoms$(); --i >= 0; ) this.map.put$O$O(this.inchiModel.getAtom$I(i), Integer.valueOf$I(i));

});

Clazz.newMeth(C$, 'getNumAtoms$',  function () {
return this.inchiModel.getAtoms$().size$();
});

Clazz.newMeth(C$, 'setAtom$I',  function (i) {
this.thisAtom=this.inchiModel.getAtom$I(i);
return this;
});

Clazz.newMeth(C$, 'getElementType$',  function () {
return this.thisAtom.getElName$();
});

Clazz.newMeth(C$, 'getX$',  function () {
return this.thisAtom.getX$();
});

Clazz.newMeth(C$, 'getY$',  function () {
return this.thisAtom.getY$();
});

Clazz.newMeth(C$, 'getZ$',  function () {
return this.thisAtom.getZ$();
});

Clazz.newMeth(C$, 'getCharge$',  function () {
return this.thisAtom.getCharge$();
});

Clazz.newMeth(C$, 'getIsotopicMass$',  function () {
return $I$(9,"getActualMass$S$I",[this.getElementType$(), this.thisAtom.getIsotopicMass$()]);
});

Clazz.newMeth(C$, 'getImplicitH$',  function () {
return this.thisAtom.getImplicitHydrogen$();
});

Clazz.newMeth(C$, 'getNumBonds$',  function () {
return this.inchiModel.getBonds$().size$();
});

Clazz.newMeth(C$, 'setBond$I',  function (i) {
this.thisBond=this.inchiModel.getBond$I(i);
return this;
});

Clazz.newMeth(C$, 'getIndexOriginAtom$',  function () {
return this.map.get$O(this.thisBond.getStart$()).intValue$();
});

Clazz.newMeth(C$, 'getIndexTargetAtom$',  function () {
return this.map.get$O(this.thisBond.getEnd$()).intValue$();
});

Clazz.newMeth(C$, 'getInchiBondType$',  function () {
var type=this.thisBond.getType$();
return type.name$();
});

Clazz.newMeth(C$, 'getNumStereo0D$',  function () {
return this.inchiModel.getStereos$().size$();
});

Clazz.newMeth(C$, 'setStereo0D$I',  function (i) {
this.thisStereo=this.inchiModel.getStereos$().get$I(i);
return this;
});

Clazz.newMeth(C$, 'getNeighbors$',  function () {
var an=this.thisStereo.getAtoms$();
var n=an.length;
var a=Clazz.array(Integer.TYPE, [n]);
for (var i=0; i < n; i++) {
a[i]=this.map.get$O(an[i]).intValue$();
}
return a;
});

Clazz.newMeth(C$, 'getCenterAtom$',  function () {
var ca=this.thisStereo.getCentralAtom$();
return (ca == null  ? -1 : this.map.get$O(ca).intValue$());
});

Clazz.newMeth(C$, 'getStereoType$',  function () {
return C$.uc$O(this.thisStereo.getType$());
});

Clazz.newMeth(C$, 'getParity$',  function () {
return C$.uc$O(this.thisStereo.getParity$());
});

Clazz.newMeth(C$, 'uc$O',  function (o) {
return o.toString().toUpperCase$();
}, 1);

Clazz.newMeth(C$, 'toJSON$io_github_dan2097_jnainchi_InchiInput',  function (inchiModel) {
var na=inchiModel.getAtoms$().size$();
var nb=inchiModel.getBonds$().size$();
var ns=inchiModel.getStereos$().size$();
var mapAtoms=Clazz.new_($I$(10,1));
var haveXYZ=false;
for (var i=0; i < na; i++) {
var a=inchiModel.getAtom$I(i);
if (a.getX$() != 0  || a.getY$() != 0   || a.getZ$() != 0  ) {
haveXYZ=true;
break;
}}
var s="{";
s+="\n\"atomCount\":" + na + ",\n" ;
s+="\"atoms\":[\n";
for (var i=0; i < na; i++) {
var a=inchiModel.getAtom$I(i);
mapAtoms.put$O$O(a, Integer.valueOf$I(i));
if (i > 0) s+=",\n";
s+="{";
s+=C$.toJSONInt$S$I$S("index", (Integer.valueOf$I(i)).$c(), "");
s+=C$.toJSONNotNone$S$O$S("elname", a.getElName$(), ",");
if (haveXYZ) {
s+=C$.toJSONDouble$S$D$S("x", a.getX$(), ",");
s+=C$.toJSONDouble$S$D$S("y", a.getY$(), ",");
s+=C$.toJSONDouble$S$D$S("z", a.getZ$(), ",");
}s+=C$.toJSONNotNone$S$O$S("radical", a.getRadical$(), ",");
s+=C$.toJSONNonZero$S$I$S("charge", a.getCharge$(), ",");
s+=C$.toJSONNonZero$S$I$S("isotopeMass", a.getIsotopicMass$(), ",");
if (a.getImplicitHydrogen$() > 0) s+=C$.toJSONNonZero$S$I$S("implicitH", a.getImplicitHydrogen$(), ",");
s+=C$.toJSONNonZero$S$I$S("implicitDeuterium", a.getImplicitDeuterium$(), ",");
s+=C$.toJSONNonZero$S$I$S("implicitProtium", a.getImplicitProtium$(), ",");
s+=C$.toJSONNonZero$S$I$S("implicitTritium", a.getImplicitTritium$(), ",");
s+="}";
}
s+="\n],";
s+="\n\"bondCount\":" + nb + "," ;
s+="\n\"bonds\":[\n";
for (var i=0; i < nb; i++) {
if (i > 0) s+=",\n";
s+="{";
var b=inchiModel.getBond$I(i);
s+=C$.toJSONInt$S$I$S("originAtom", mapAtoms.get$O(b.getStart$()).intValue$(), "");
s+=C$.toJSONInt$S$I$S("targetAtom", mapAtoms.get$O(b.getEnd$()).intValue$(), ",");
var bt=C$.uc$O(b.getType$());
if (!bt.equals$O("SINGLE")) s+=C$.toJSONString$S$S$S("type", bt, ",");
s+=C$.toJSONNotNone$S$O$S("stereo", C$.uc$O(b.getStereo$()), ",");
s+="}";
}
s+="\n]";
if (ns > 0) {
s+=",\n\"stereoCount\":" + ns + ",\n" ;
s+="\"stereo\":[\n";
for (var i=0; i < ns; i++) {
if (i > 0) s+=",\n";
s+="{";
var d=inchiModel.getStereos$().get$I(i);
var a=d.getCentralAtom$();
s+=C$.toJSONNotNone$S$O$S("parity", d.getParity$(), "");
s+=C$.toJSONNotNone$S$O$S("type", d.getType$(), ",");
if (a != null ) s+=C$.toJSONInt$S$I$S("centralAtom", mapAtoms.get$O(a).intValue$(), ",");
var an=d.getAtoms$();
var nbs=Clazz.array(Integer.TYPE, [an.length]);
for (var j=0; j < an.length; j++) {
nbs[j]=mapAtoms.get$O(an[j]).intValue$();
}
s+=C$.toJSONArray$S$IA$S("neighbors", nbs, ",");
s+="}";
}
s+="\n]";
}s+="}";
return s;
}, 1);

Clazz.newMeth(C$, 'toJSONArray$S$IA$S',  function (key, val, term) {
var s=term + "\"" + key + "\":[" + val[0] ;
for (var i=1; i < val.length; i++) {
s+="," + val[i];
}
return s + "]";
}, 1);

Clazz.newMeth(C$, 'toJSONNonZero$S$I$S',  function (key, val, term) {
return (val == 0 ? "" : C$.toJSONInt$S$I$S(key, val, term));
}, 1);

Clazz.newMeth(C$, 'toJSONInt$S$I$S',  function (key, val, term) {
return term + "\"" + key + "\":" + val ;
}, 1);

Clazz.newMeth(C$, 'toJSONDouble$S$D$S',  function (key, val, term) {
var s;
if (val == 0 ) {
s="0";
} else {
s="" + (new Double(val + (val > 0  ? 1.0E-8 : -1.0E-8)).toString());
s=s.substring$I$I(0, s.indexOf$S(".") + 5);
var n=s.length$();
while (s.charAt$I(--n) == "0"){
}
s=s.substring$I$I(0, n + 1);
}return term + "\"" + key + "\":" + s ;
}, 1);

Clazz.newMeth(C$, 'toJSONString$S$S$S',  function (key, val, term) {
return term + "\"" + key + "\":\"" + val + "\"" ;
}, 1);

Clazz.newMeth(C$, 'toJSONNotNone$S$O$S',  function (key, val, term) {
var s=val.toString();
return ("NONE".equals$O(s) ? "" : term + "\"" + key + "\":\"" + s + "\"" );
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-05 20:55:01 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
