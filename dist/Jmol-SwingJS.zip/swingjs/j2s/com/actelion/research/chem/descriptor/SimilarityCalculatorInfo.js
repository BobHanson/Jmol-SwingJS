(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "SimilarityCalculatorInfo");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['name','shortName']]]

Clazz.newMeth(C$, 'c$$S$S',  function (name, shortName) {
;C$.$init$.apply(this);
this.name=name;
this.shortName=shortName;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:36 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
