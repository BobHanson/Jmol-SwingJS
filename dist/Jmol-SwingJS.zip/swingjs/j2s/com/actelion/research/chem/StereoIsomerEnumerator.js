(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'java.util.TreeMap','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.coords.CoordinateInventor']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "StereoIsomerEnumerator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['mSkipEnantiomers'],'O',['mMol','com.actelion.research.chem.StereoMolecule','mAtomGroupList','int[][]','+mBondGroupList','+mUnknownDoubleBondList','mAtomIsParity1','boolean[][]','+mBondIsParity1']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$Z',  function (mol, skipEnantiomers) {
;C$.$init$.apply(this);
this.mMol=mol;
this.mMol.ensureHelperArrays$I(15);
var groupMap=Clazz.new_($I$(1,1));
this.mSkipEnantiomers=skipEnantiomers;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.getAtomParity$I(atom) != 0 && !this.mMol.isAtomParityPseudo$I(atom) ) {
if (this.mMol.getAtomParity$I(atom) == 3) {
var atomList=Clazz.array(Integer.TYPE, [1]);
atomList[0]=atom;
groupMap.put$O$O("U" + atom, atomList);
} else {
if (this.mMol.getAtomESRType$I(atom) == 0) {
this.mSkipEnantiomers=false;
} else {
var key=(this.mMol.getAtomESRType$I(atom) == 2 ? "O" : "A") + this.mMol.getAtomESRGroup$I(atom);
var atomList=groupMap.get$O(key);
if (atomList == null ) {
atomList=Clazz.array(Integer.TYPE, [1]);
atomList[0]=atom;
groupMap.put$O$O(key, atomList);
} else {
var newAtomList=Clazz.array(Integer.TYPE, [atomList.length + 1]);
for (var i=0; i < atomList.length; i++) newAtomList[i]=atomList[i];

newAtomList[atomList.length]=atom;
groupMap.put$O$O(key, newAtomList);
}}}}}
this.mAtomGroupList=groupMap.values$().toArray$OA(Clazz.array(Integer.TYPE, [0, null]));
this.mAtomIsParity1=Clazz.array(Boolean.TYPE, [this.mAtomGroupList.length, null]);
for (var i=0; i < this.mAtomGroupList.length; i++) {
this.mAtomIsParity1[i]=Clazz.array(Boolean.TYPE, [this.mAtomGroupList[i].length]);
for (var j=0; j < this.mAtomGroupList[i].length; j++) this.mAtomIsParity1[i][j]=(this.mMol.getAtomParity$I(this.mAtomGroupList[i][j]) == 1);

}
groupMap.clear$();
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondParity$I(bond) != 0 && !this.mMol.isBondParityPseudo$I(bond)  && this.mMol.getBondOrder$I(bond) == 1 ) {
if (this.mMol.getBondParity$I(bond) == 3) {
var bondList=Clazz.array(Integer.TYPE, [1]);
bondList[0]=bond;
groupMap.put$O$O("U" + bond, bondList);
} else {
if (this.mMol.getBondESRType$I(bond) == 0) {
this.mSkipEnantiomers=false;
} else {
var key=(this.mMol.getBondESRType$I(bond) == 2 ? "O" : "A") + this.mMol.getBondESRGroup$I(bond);
var bondList=groupMap.get$O(key);
if (bondList == null ) {
bondList=Clazz.array(Integer.TYPE, [1]);
bondList[0]=bond;
groupMap.put$O$O(key, bondList);
} else {
var newBondList=Clazz.array(Integer.TYPE, [bondList.length + 1]);
for (var i=0; i < bondList.length; i++) newBondList[i]=bondList[i];

newBondList[bondList.length]=bond;
groupMap.put$O$O(key, newBondList);
}}}}}
this.mBondGroupList=groupMap.values$().toArray$OA(Clazz.array(Integer.TYPE, [0, null]));
this.mBondIsParity1=Clazz.array(Boolean.TYPE, [this.mBondGroupList.length, null]);
for (var i=0; i < this.mBondGroupList.length; i++) {
this.mBondIsParity1[i]=Clazz.array(Boolean.TYPE, [this.mBondGroupList[i].length]);
for (var j=0; j < this.mBondGroupList[i].length; j++) this.mBondIsParity1[i][j]=(this.mMol.getBondParity$I(this.mBondGroupList[i][j]) == 1);

}
if (this.mAtomGroupList.length == 0 && this.mBondGroupList.length == 0 ) this.mSkipEnantiomers=false;
groupMap.clear$();
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondParity$I(bond) == 3 && !this.mMol.isBondParityPseudo$I(bond)  && this.mMol.getBondOrder$I(bond) == 2 ) {
var bondList=Clazz.array(Integer.TYPE, [1]);
bondList[0]=bond;
groupMap.put$O$O("U" + bond, bondList);
}}
this.mUnknownDoubleBondList=groupMap.values$().toArray$OA(Clazz.array(Integer.TYPE, [0, null]));
}, 1);

Clazz.newMeth(C$, 'isSkippingEnantiomers$',  function () {
return this.mSkipEnantiomers;
});

Clazz.newMeth(C$, 'getStereoIsomerCount$',  function () {
return 1 << (this.mAtomGroupList.length + this.mBondGroupList.length + this.mUnknownDoubleBondList.length  - (this.mSkipEnantiomers ? 1 : 0));
});

Clazz.newMeth(C$, 'getStereoIsomer$I',  function (index) {
var mol=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_Molecule,[this.mMol]);
var skipFirst=this.mSkipEnantiomers;
for (var i=0; i < this.mAtomGroupList.length; i++) {
var invertGroup=!skipFirst && ((index & 1) != 0) ;
for (var j=0; j < this.mAtomGroupList[i].length; j++) {
var parity=(!!(invertGroup ^ this.mAtomIsParity1[i][j])) ? 2 : 1;
var atom=this.mAtomGroupList[i][j];
mol.setAtomParity$I$I$Z(atom, parity, false);
mol.setAtomESR$I$I$I(atom, 0, 0);
}
if (skipFirst) {
skipFirst=false;
continue;
}index>>=1;
}
for (var i=0; i < this.mBondGroupList.length; i++) {
var invertGroup=!skipFirst && ((index & 1) != 0) ;
for (var j=0; j < this.mBondGroupList[i].length; j++) {
var parity=(!!(invertGroup ^ this.mBondIsParity1[i][j])) ? 2 : 1;
var bond=this.mBondGroupList[i][j];
mol.setBondParity$I$I$Z(bond, parity, false);
mol.setBondESR$I$I$I(bond, 0, 0);
}
if (skipFirst) {
skipFirst=false;
continue;
}index>>=1;
}
for (var i=0; i < this.mUnknownDoubleBondList.length; i++) {
var parity=((index & 1) != 0) ? 2 : 1;
var bond=this.mUnknownDoubleBondList[i][0];
mol.setBondType$I$I(bond, 2);
mol.setBondParity$I$I$Z(bond, parity, false);
index>>=1;
}
mol.setParitiesValid$I(0);
mol.setStereoBondsFromParity$();
if (this.mUnknownDoubleBondList.length != 0) {
mol.setParitiesValid$I(0);
Clazz.new_($I$(3,1).c$$I,[0]).invent$com_actelion_research_chem_StereoMolecule(mol);
}return mol;
});

Clazz.newMeth(C$, 'isCorrectStereoIsomer$com_actelion_research_chem_StereoMolecule$I',  function (mol, index) {
mol.ensureHelperArrays$I(15);
var skipFirst=this.mSkipEnantiomers;
for (var i=0; i < this.mAtomGroupList.length; i++) {
var invertGroup=!skipFirst && ((index & 1) != 0) ;
for (var j=0; j < this.mAtomGroupList[i].length; j++) {
var parity=(!!(invertGroup ^ this.mAtomIsParity1[i][j])) ? 2 : 1;
var atom=this.mAtomGroupList[i][j];
if (mol.getAtomParity$I(atom) != parity) return false;
}
if (skipFirst) {
skipFirst=false;
continue;
}index>>=1;
}
for (var i=0; i < this.mBondGroupList.length; i++) {
var invertGroup=!skipFirst && ((index & 1) != 0) ;
for (var j=0; j < this.mBondGroupList[i].length; j++) {
var parity=(!!(invertGroup ^ this.mBondIsParity1[i][j])) ? 2 : 1;
var bond=this.mBondGroupList[i][j];
if (mol.getBondParity$I(bond) != parity) return false;
}
if (skipFirst) {
skipFirst=false;
continue;
}index>>=1;
}
for (var i=0; i < this.mUnknownDoubleBondList.length; i++) {
var parity=((index & 1) != 0) ? 2 : 1;
var bond=this.mUnknownDoubleBondList[i][0];
if (mol.getBondParity$I(bond) != parity) return false;
index>>=1;
}
return true;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:18 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
