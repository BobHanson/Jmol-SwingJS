(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.redgraph"),p$1={},I$=[[0,'StringBuilder','java.util.HashSet','com.actelion.research.chem.StereoMolecule','java.util.ArrayList','com.actelion.research.util.hash.HashSetInt','com.actelion.research.chem.descriptor.flexophore.redgraph.SubGraphIndices','com.actelion.research.chem.ExtendedMoleculeFunctions','java.util.LinkedList',['com.actelion.research.chem.descriptor.flexophore.redgraph.SubGraphExtractor','.MaximumTopologicalDist'],'java.util.Collections','com.actelion.research.chem.RingHelper']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SubGraphExtractor", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['MaximumTopologicalDist',10]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['arrAtomInSmallRing','boolean[]','+arrAtomInLargeRing','+arrRingAtom','hsAtomicNumberExcludeAliphatic','java.util.HashSet']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.arrRingAtom=Clazz.array(Boolean.TYPE, [10000]);
this.hsAtomicNumberExcludeAliphatic=Clazz.new_($I$(2,1));
this.hsAtomicNumberExcludeAliphatic.add$O(Integer.valueOf$I(7));
this.hsAtomicNumberExcludeAliphatic.add$O(Integer.valueOf$I(8));
}, 1);

Clazz.newMeth(C$, 'extract$com_actelion_research_chem_StereoMolecule',  function (molOrig) {
var nAtoms=molOrig.getAtoms$();
for (var i=0; i < nAtoms; i++) {
this.arrRingAtom[i]=false;
}
var mol=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_Molecule,[molOrig]);
mol.ensureHelperArrays$I(7);
p$1.createRingAtomIndexMap$com_actelion_research_chem_StereoMolecule.apply(this, [mol]);
var liEndStandingAtoms=Clazz.new_($I$(4,1));
for (var i=0; i < nAtoms; i++) {
var nConnAtms=mol.getAllConnAtoms$I(i);
var ccConnNonHydrogen=0;
for (var j=0; j < nConnAtms; j++) {
var indexConnAtm=mol.getConnAtom$I$I(i, j);
var atNo=mol.getAtomicNo$I(indexConnAtm);
if (atNo > 1) {
++ccConnNonHydrogen;
}}
if (ccConnNonHydrogen == 1) {
if (mol.getAtomicNo$I(i) > 1) liEndStandingAtoms.add$O(Integer.valueOf$I(i));
}}
var liFragment=Clazz.new_($I$(4,1));
var liFragmentHetero=p$1.getEndStandingHeteroGroups$com_actelion_research_chem_StereoMolecule$java_util_List.apply(this, [mol, liEndStandingAtoms]);
liFragment.addAll$java_util_Collection(liFragmentHetero);
var hsAtomIndicesInFragment=Clazz.new_($I$(5,1));
$I$(6).addAtomIndices$com_actelion_research_util_hash_HashSetInt$java_util_List(hsAtomIndicesInFragment, liFragmentHetero);
var liFragmentRings=p$1.getSmallRingsWithConnEndStanding$com_actelion_research_chem_StereoMolecule.apply(this, [mol]);
liFragment.addAll$java_util_Collection(liFragmentRings);
var hsAtomIndicesInSmallRings=Clazz.new_($I$(5,1));
$I$(6).addAtomIndices$com_actelion_research_util_hash_HashSetInt$java_util_List(hsAtomIndicesInSmallRings, liFragmentRings);
hsAtomIndicesInFragment.add$IA(hsAtomIndicesInSmallRings.getValues$());
var liFragmentRemainingHetero=p$1.getRemainingHeteroGroups$com_actelion_research_chem_StereoMolecule$com_actelion_research_util_hash_HashSetInt.apply(this, [mol, hsAtomIndicesInFragment]);
liFragment.addAll$java_util_Collection(liFragmentRemainingHetero);
$I$(6).addAtomIndices$com_actelion_research_util_hash_HashSetInt$java_util_List(hsAtomIndicesInFragment, liFragmentRemainingHetero);
var liFragmentEndStandingAliphaticGroup=p$1.getEndStandingAliphaticGroups$com_actelion_research_chem_StereoMolecule$java_util_List$com_actelion_research_util_hash_HashSetInt.apply(this, [mol, liEndStandingAtoms, hsAtomIndicesInFragment]);
liFragment.addAll$java_util_Collection(liFragmentEndStandingAliphaticGroup);
var hsAtomIndicesInFragmentEndStandingAliphaticGroup=Clazz.new_($I$(5,1));
$I$(6).addAtomIndices$com_actelion_research_util_hash_HashSetInt$java_util_List(hsAtomIndicesInFragmentEndStandingAliphaticGroup, liFragmentEndStandingAliphaticGroup);
var liFragmentLargeRings=p$1.getAliphaticGroupsInLargeRings$com_actelion_research_chem_StereoMolecule$com_actelion_research_util_hash_HashSetInt.apply(this, [mol, hsAtomIndicesInFragmentEndStandingAliphaticGroup]);
liFragment.addAll$java_util_Collection(liFragmentLargeRings);
C$.mergeBridgedAliphaticRings$com_actelion_research_chem_StereoMolecule$java_util_List(mol, liFragment);
p$1.splitLongHeteroGroups$com_actelion_research_chem_StereoMolecule$java_util_List.apply(this, [mol, liFragment]);
return liFragment;
});

Clazz.newMeth(C$, 'extractAliphaticRingsAndEndStandingAliphaticGroups$com_actelion_research_chem_StereoMolecule',  function (molOrig) {
var mol=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_Molecule,[molOrig]);
mol.ensureHelperArrays$I(7);
var nAtoms=mol.getAtoms$();
p$1.createRingAtomIndexMap$com_actelion_research_chem_StereoMolecule.apply(this, [mol]);
var liEndStandingAtoms=Clazz.new_($I$(4,1));
for (var i=0; i < nAtoms; i++) {
var nConnAtms=mol.getAllConnAtoms$I(i);
var ccConnNonHydrogen=0;
for (var j=0; j < nConnAtms; j++) {
var indexConnAtm=mol.getConnAtom$I$I(i, j);
var atNo=mol.getAtomicNo$I(indexConnAtm);
if (atNo > 1) {
++ccConnNonHydrogen;
}}
if (ccConnNonHydrogen == 1) {
liEndStandingAtoms.add$O(Integer.valueOf$I(i));
}}
var hsAtomNonAliphatic=Clazz.new_($I$(5,1));
for (var indexEndStandingAtom, $indexEndStandingAtom = liEndStandingAtoms.iterator$(); $indexEndStandingAtom.hasNext$()&&((indexEndStandingAtom=($indexEndStandingAtom.next$()).intValue$()),1);) {
if ($I$(7).isHetero$com_actelion_research_chem_ExtendedMolecule$I(mol, indexEndStandingAtom)) {
hsAtomNonAliphatic.add$I(indexEndStandingAtom);
}}
var liFragment=Clazz.new_($I$(4,1));
var liSGIRings=p$1.getSmallRingsWithConnEndStanding$com_actelion_research_chem_StereoMolecule.apply(this, [mol]);
for (var sgiRing, $sgiRing = liSGIRings.iterator$(); $sgiRing.hasNext$()&&((sgiRing=($sgiRing.next$())),1);) {
var arrIndAt=sgiRing.getAtomIndices$();
var ccAromatic=0;
for (var indAt, $indAt = 0, $$indAt = arrIndAt; $indAt<$$indAt.length&&((indAt=($$indAt[$indAt])),1);$indAt++) {
if (mol.isAromaticAtom$I(indAt)) {
++ccAromatic;
}}
if ((ccAromatic/arrIndAt.length|0) < 0.5 ) {
if (C$.containsOnlyCarbon$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices(mol, sgiRing)) {
liFragment.add$O(sgiRing);
}}}
var liFragmentEndStandingAliphaticGroup=p$1.getEndStandingAliphaticGroups$com_actelion_research_chem_StereoMolecule$java_util_List$com_actelion_research_util_hash_HashSetInt.apply(this, [mol, liEndStandingAtoms, hsAtomNonAliphatic]);
liFragment.addAll$java_util_Collection(liFragmentEndStandingAliphaticGroup);
return liFragment;
});

Clazz.newMeth(C$, 'splitLongHeteroGroups$com_actelion_research_chem_StereoMolecule$java_util_List',  function (mol, liFragment) {
var nAtomsSubGroup=3;
var arrTopologicalDistanceMatrix=$I$(7).getTopologicalDistanceMatrix$com_actelion_research_chem_StereoMolecule(mol);
for (var i=liFragment.size$() - 1; i >= 0; i--) {
var sgi=liFragment.get$I(i);
var arrIndAtm=sgi.getAtomIndices$();
var maxTopoDist=C$.getMaximumDistance$IAA$IA(arrTopologicalDistanceMatrix, arrIndAtm);
if (maxTopoDist.dist >= 6) {
liFragment.remove$I(i);
var arrIndAtmPathMaxDist=Clazz.array(Integer.TYPE, [maxTopoDist.dist + 1]);
mol.getPath$IA$I$I$I$ZA(arrIndAtmPathMaxDist, maxTopoDist.at1, maxTopoDist.at2, maxTopoDist.dist + 1, null);
var ringAtm=false;
for (var indAtmPath, $indAtmPath = 0, $$indAtmPath = arrIndAtmPathMaxDist; $indAtmPath<$$indAtmPath.length&&((indAtmPath=($$indAtmPath[$indAtmPath])),1);$indAtmPath++) {
if (mol.isRingAtom$I(indAtmPath)) {
ringAtm=true;
break;
}}
if (ringAtm) {
continue;
}var hsIndAtmSubPath=Clazz.new_($I$(5,1).c$$IA,[arrIndAtmPathMaxDist]);
var nAtomsInPath=arrIndAtmPathMaxDist.length;
for (var j=0; j < nAtomsInPath; j+=3) {
var size=Math.min(3, nAtomsInPath - j);
var arrAtmSubPath=Clazz.array(Integer.TYPE, [size]);
for (var k=0; k < size; k++) {
var index=j + k;
arrAtmSubPath[k]=arrIndAtmPathMaxDist[index];
}
var sgiSub=Clazz.new_($I$(6,1));
sgiSub.addIndex$IA(arrAtmSubPath);
C$.addConnAtoms$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices$com_actelion_research_util_hash_HashSetInt(mol, sgiSub, sgi, hsIndAtmSubPath);
liFragment.add$O(sgiSub);
}
}}
}, p$1);

Clazz.newMeth(C$, 'addConnAtoms$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices$com_actelion_research_util_hash_HashSetInt',  function (mol, sgiSub, sgi, hsIndAtmSubPath) {
var arrAtmSubPath=sgiSub.getAtomIndices$();
var queue=Clazz.new_($I$(8,1));
for (var indAtm, $indAtm = 0, $$indAtm = arrAtmSubPath; $indAtm<$$indAtm.length&&((indAtm=($$indAtm[$indAtm])),1);$indAtm++) {
queue.add$O(Integer.valueOf$I(indAtm));
}
while (!queue.isEmpty$()){
var indAtm=(queue.poll$()).$c();
var nConn=mol.getConnAtoms$I(indAtm);
for (var i=0; i < nConn; i++) {
var indAtmConn=mol.getConnAtom$I$I(indAtm, i);
if (hsIndAtmSubPath.contains$I(indAtmConn)) {
continue;
}if (sgiSub.contains$I(indAtmConn)) {
continue;
}if (!sgi.contains$I(indAtmConn)) {
continue;
}sgiSub.addIndex$I(indAtmConn);
queue.add$O(Integer.valueOf$I(indAtmConn));
}
}
}, 1);

Clazz.newMeth(C$, 'getMaximumDistance$IAA$IA',  function (arrTopologicalDistanceMatrix, arrIndAtm) {
var maxTopoDist=Clazz.new_($I$(9,1));
for (var i=0; i < arrIndAtm.length; i++) {
for (var j=i + 1; j < arrIndAtm.length; j++) {
var d=arrTopologicalDistanceMatrix[arrIndAtm[i]][arrIndAtm[j]];
if (d > maxTopoDist.dist) {
maxTopoDist.dist=d;
maxTopoDist.at1=arrIndAtm[i];
maxTopoDist.at2=arrIndAtm[j];
}}
}
return maxTopoDist;
}, 1);

Clazz.newMeth(C$, 'mergeBridgedAliphaticRings$com_actelion_research_chem_StereoMolecule$java_util_List',  function (mol, liFragment) {
var minNumOverLappingIndices=3;
var merged=true;
var ringCollection=mol.getRingSet$();
while (merged){
merged=false;
 mergedB : for (var i=0; i < liFragment.size$(); i++) {
var sgi0=liFragment.get$I(i);
if (!C$.containsOnlyCarbon$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices(mol, sgi0)) {
continue;
}for (var j=i + 1; j < liFragment.size$(); j++) {
var sgi1=liFragment.get$I(j);
if (!C$.containsOnlyCarbon$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices(mol, sgi1)) {
continue;
}var nOverLapRings=C$.getNumOverlappingRingIndices$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_RingCollection$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices(mol, ringCollection, sgi0, sgi1);
if (nOverLapRings >= 3) {
sgi0.merge$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices(sgi1);
liFragment.remove$I(j);
merged=true;
break mergedB;
}}
}
}
}, 1);

Clazz.newMeth(C$, 'getNumOverlappingRingIndices$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_RingCollection$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices',  function (mol, ringCollection, sgi1, sgi2) {
var maxOverlap=0;
var rings=ringCollection.getSize$();
for (var i=0; i < rings; i++) {
var arrIndAtRing1=ringCollection.getRingAtoms$I(i);
var hs1=Clazz.new_($I$(5,1));
for (var indAtRing1, $indAtRing1 = 0, $$indAtRing1 = arrIndAtRing1; $indAtRing1<$$indAtRing1.length&&((indAtRing1=($$indAtRing1[$indAtRing1])),1);$indAtRing1++) {
if (sgi1.contains$I(indAtRing1)) {
hs1.add$I(indAtRing1);
}}
var arrIndAtHs1=hs1.getValues$();
for (var j=0; j < rings; j++) {
var arrIndAtRing2=ringCollection.getRingAtoms$I(j);
var hs2=Clazz.new_($I$(5,1));
for (var indAtRing2, $indAtRing2 = 0, $$indAtRing2 = arrIndAtRing2; $indAtRing2<$$indAtRing2.length&&((indAtRing2=($$indAtRing2[$indAtRing2])),1);$indAtRing2++) {
if (sgi2.contains$I(indAtRing2)) {
hs2.add$I(indAtRing2);
}}
var nOverlap=0;
for (var indAtHs1, $indAtHs1 = 0, $$indAtHs1 = arrIndAtHs1; $indAtHs1<$$indAtHs1.length&&((indAtHs1=($$indAtHs1[$indAtHs1])),1);$indAtHs1++) {
if (hs2.contains$I(indAtHs1)) {
++nOverlap;
}}
if (nOverlap > maxOverlap) {
maxOverlap=nOverlap;
}}
}
return maxOverlap;
}, 1);

Clazz.newMeth(C$, 'containsOnlyCarbon$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices',  function (mol, sgi) {
var carbon=true;
var arrAtInd=sgi.getAtomIndices$();
for (var indAt, $indAt = 0, $$indAt = arrAtInd; $indAt<$$indAt.length&&((indAt=($$indAt[$indAt])),1);$indAt++) {
if (mol.getAtomicNo$I(indAt) != 6) {
carbon=false;
break;
}}
return carbon;
}, 1);

Clazz.newMeth(C$, 'getRemainingHeteroGroups$com_actelion_research_chem_StereoMolecule$com_actelion_research_util_hash_HashSetInt',  function (mol, hsAtomIndicesUsed) {
var liFragmentRemainingHetero=Clazz.new_($I$(4,1));
var atoms=mol.getAtoms$();
var arrAtomIndicesUsedMap=Clazz.array(Boolean.TYPE, [atoms]);
var arrAtomIndicesUsed=hsAtomIndicesUsed.getValues$();
for (var indexAtmUsed, $indexAtmUsed = 0, $$indexAtmUsed = arrAtomIndicesUsed; $indexAtmUsed<$$indexAtmUsed.length&&((indexAtmUsed=($$indexAtmUsed[$indexAtmUsed])),1);$indexAtmUsed++) {
arrAtomIndicesUsedMap[indexAtmUsed]=true;
}
for (var indAtm=0; indAtm < atoms; indAtm++) {
if (arrAtomIndicesUsedMap[indAtm]) {
continue;
}if (!$I$(7).isHetero$com_actelion_research_chem_ExtendedMolecule$I(mol, indAtm)) {
continue;
}if ($I$(7).isEtherOxygenAtAromatic$com_actelion_research_chem_StereoMolecule$I(mol, indAtm)) {
continue;
}var fragment=Clazz.new_($I$(6,1));
fragment.addIndex$I(indAtm);
liFragmentRemainingHetero.add$O(fragment);
}
for (var fragment, $fragment = liFragmentRemainingHetero.iterator$(); $fragment.hasNext$()&&((fragment=($fragment.next$())),1);) {
var indexAtmHetero1=fragment.getAtomIndices$()[0];
var nAtmsConn=mol.getConnAtoms$I(indexAtmHetero1);
for (var i=0; i < nAtmsConn; i++) {
var indexAtmConn=mol.getConnAtom$I$I(indexAtmHetero1, i);
if (arrAtomIndicesUsedMap[indexAtmConn]) {
continue;
}if ($I$(7).isHetero$com_actelion_research_chem_ExtendedMolecule$I(mol, indexAtmConn)) {
fragment.addIndex$I(indexAtmConn);
} else if (mol.getConnAtoms$I(indexAtmConn) == 1) {
fragment.addIndex$I(indexAtmConn);
}}
}
$I$(6).merge$java_util_List(liFragmentRemainingHetero);
return liFragmentRemainingHetero;
}, p$1);

Clazz.newMeth(C$, 'getEndStandingAliphaticGroups$com_actelion_research_chem_StereoMolecule$java_util_List$com_actelion_research_util_hash_HashSetInt',  function (mol, liEndStandingAtoms, hsAtomIndicesUsed) {
var liFragmentEndStandingAliphaticGroup=Clazz.new_($I$(4,1));
var atoms=mol.getAtoms$();
var arrAtomIndicesUsedMap=Clazz.array(Boolean.TYPE, [atoms]);
var arrAtomIndicesUsed=hsAtomIndicesUsed.getValues$();
for (var indexAtmUsed, $indexAtmUsed = 0, $$indexAtmUsed = arrAtomIndicesUsed; $indexAtmUsed<$$indexAtmUsed.length&&((indexAtmUsed=($$indexAtmUsed[$indexAtmUsed])),1);$indexAtmUsed++) {
arrAtomIndicesUsedMap[indexAtmUsed]=true;
}
for (var indexEndStandingAtom, $indexEndStandingAtom = liEndStandingAtoms.iterator$(); $indexEndStandingAtom.hasNext$()&&((indexEndStandingAtom=($indexEndStandingAtom.next$()).intValue$()),1);) {
if (arrAtomIndicesUsedMap[indexEndStandingAtom]) {
continue;
}if ($I$(7).isHetero$com_actelion_research_chem_ExtendedMolecule$I(mol, indexEndStandingAtom)) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["This should not happen."]);
}if (C$.areAtomicNoConnectedInList$com_actelion_research_chem_StereoMolecule$I$java_util_HashSet(mol, indexEndStandingAtom, this.hsAtomicNumberExcludeAliphatic)) {
continue;
}var nConnected=mol.getConnAtoms$I(indexEndStandingAtom);
var addEndStanding=true;
for (var i=0; i < nConnected; i++) {
var indAtConn=mol.getConnAtom$I$I(indexEndStandingAtom, i);
if (mol.isRingAtom$I(indAtConn)) {
addEndStanding=false;
break;
}if (C$.areAtomicNoConnectedInList$com_actelion_research_chem_StereoMolecule$I$java_util_HashSet(mol, indAtConn, this.hsAtomicNumberExcludeAliphatic)) {
addEndStanding=false;
break;
}}
if (addEndStanding) {
var fragment=Clazz.new_($I$(6,1));
fragment.addIndex$I(indexEndStandingAtom);
liFragmentEndStandingAliphaticGroup.add$O(fragment);
}}
for (var fragment, $fragment = liFragmentEndStandingAliphaticGroup.iterator$(); $fragment.hasNext$()&&((fragment=($fragment.next$())),1);) {
p$1.broadFirstForNonRingCarbon$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices$com_actelion_research_util_hash_HashSetInt$I.apply(this, [mol, fragment, hsAtomIndicesUsed, 1]);
}
$I$(6).merge$java_util_List(liFragmentEndStandingAliphaticGroup);
return liFragmentEndStandingAliphaticGroup;
}, p$1);

Clazz.newMeth(C$, 'areAtomicNoConnectedInList$com_actelion_research_chem_StereoMolecule$I$java_util_HashSet',  function (mol, indexAtCenter, hsAtomicNumber) {
var nConnected=mol.getConnAtoms$I(indexAtCenter);
var contains=false;
for (var i=0; i < nConnected; i++) {
var indAtConn=mol.getConnAtom$I$I(indexAtCenter, i);
var atomicNoConn=mol.getAtomicNo$I(indAtConn);
if (hsAtomicNumber.contains$O(Integer.valueOf$I(atomicNoConn))) {
contains=true;
break;
}}
return contains;
}, 1);

Clazz.newMeth(C$, 'broadFirstForNonRingCarbon$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices$com_actelion_research_util_hash_HashSetInt$I',  function (mol, fragment, hsAtomIndicesUsed, maxDepth) {
var atoms=mol.getAtoms$();
var arrAtomIndicesUsedMap=Clazz.array(Boolean.TYPE, [atoms]);
var arrAtomIndicesUsed=hsAtomIndicesUsed.getValues$();
for (var indexAtmUsed, $indexAtmUsed = 0, $$indexAtmUsed = arrAtomIndicesUsed; $indexAtmUsed<$$indexAtmUsed.length&&((indexAtmUsed=($$indexAtmUsed[$indexAtmUsed])),1);$indexAtmUsed++) {
arrAtomIndicesUsedMap[indexAtmUsed]=true;
}
var liIndAtm=Clazz.new_($I$(8,1));
var arrIndAtmLayer=Clazz.array(Integer.TYPE, [atoms]);
var arrIndAtm=fragment.getAtomIndices$();
for (var indAtm, $indAtm = 0, $$indAtm = arrIndAtm; $indAtm<$$indAtm.length&&((indAtm=($$indAtm[$indAtm])),1);$indAtm++) {
liIndAtm.add$O(Integer.valueOf$I(indAtm));
arrIndAtmLayer[indAtm]=0;
}
while (!liIndAtm.isEmpty$()){
var indAtm=(liIndAtm.poll$()).$c();
if (arrIndAtmLayer[indAtm] > maxDepth) {
continue;
}fragment.addIndex$I(indAtm);
var nConnAtms=mol.getConnAtoms$I(indAtm);
for (var i=0; i < nConnAtms; i++) {
var indAtmConn=mol.getConnAtom$I$I(indAtm, i);
if (arrAtomIndicesUsedMap[indAtmConn]) {
continue;
}if (this.arrAtomInSmallRing[indAtmConn]) {
continue;
}if (mol.getAtomicNo$I(indAtmConn) == 6) {
liIndAtm.add$O(Integer.valueOf$I(indAtmConn));
arrIndAtmLayer[indAtmConn]=arrIndAtmLayer[indAtm] + 1;
}}
}
}, p$1);

Clazz.newMeth(C$, 'largestAliphaticFragment$com_actelion_research_chem_StereoMolecule$IA$I',  function (mol, arrIndAtm, minSizeFragment) {
var liFragment=Clazz.new_($I$(4,1));
var atoms=mol.getAtoms$();
var arrIndAtmMap=Clazz.array(Boolean.TYPE, [atoms]);
for (var indAtm, $indAtm = 0, $$indAtm = arrIndAtm; $indAtm<$$indAtm.length&&((indAtm=($$indAtm[$indAtm])),1);$indAtm++) {
arrIndAtmMap[indAtm]=true;
}
var arrIndAtmUsedMap=Clazz.array(Boolean.TYPE, [atoms]);
var liIndAtm=Clazz.new_($I$(8,1));
var atomFound=true;
while (atomFound){
atomFound=false;
liIndAtm.clear$();
for (var indAtm, $indAtm = 0, $$indAtm = arrIndAtm; $indAtm<$$indAtm.length&&((indAtm=($$indAtm[$indAtm])),1);$indAtm++) {
if (!arrIndAtmUsedMap[indAtm]) {
if (mol.getAtomicNo$I(indAtm) == 6) {
liIndAtm.add$O(Integer.valueOf$I(indAtm));
atomFound=true;
break;
}}}
var fragment=Clazz.new_($I$(6,1));
while (!liIndAtm.isEmpty$()){
var indAtm=(liIndAtm.poll$()).$c();
fragment.addIndex$I(indAtm);
arrIndAtmUsedMap[indAtm]=true;
var nConnAtms=mol.getConnAtoms$I(indAtm);
for (var i=0; i < nConnAtms; i++) {
var indAtmConn=mol.getConnAtom$I$I(indAtm, i);
if (arrIndAtmUsedMap[indAtmConn]) {
continue;
}if (!arrIndAtmMap[indAtmConn]) {
continue;
}if (mol.getAtomicNo$I(indAtmConn) == 6) {
liIndAtm.add$O(Integer.valueOf$I(indAtmConn));
}}
}
liFragment.add$O(fragment);
}
for (var i=liFragment.size$() - 1; i >= 0; i--) {
var fragment=liFragment.get$I(i);
if (fragment.getNumIndices$() < minSizeFragment) {
liFragment.remove$I(i);
continue;
}var arrIndAtmFrag=fragment.getAtomIndices$();
var nCarbonWithElectronegativeNeighbors=0;
for (var indAtmFrag, $indAtmFrag = 0, $$indAtmFrag = arrIndAtmFrag; $indAtmFrag<$$indAtmFrag.length&&((indAtmFrag=($$indAtmFrag[$indAtmFrag])),1);$indAtmFrag++) {
var nAtmConn=mol.getConnAtoms$I(indAtmFrag);
for (var j=0; j < nAtmConn; j++) {
var indAtmConn=mol.getConnAtom$I$I(indAtmFrag, j);
var atomicNo=mol.getAtomicNo$I(indAtmConn);
if ((atomicNo == 7) || (atomicNo == 8) || (atomicNo == 9)  ) {
++nCarbonWithElectronegativeNeighbors;
break;
}}
}
if (arrIndAtmFrag.length - nCarbonWithElectronegativeNeighbors < minSizeFragment) {
liFragment.remove$I(i);
}}
var fragment=null;
if (liFragment.size$() > 0) {
$I$(10,"sort$java_util_List$java_util_Comparator",[liFragment, $I$(6).getComparatorNumIndices$()]);
fragment=liFragment.get$I(liFragment.size$() - 1);
}return fragment;
}, p$1);

Clazz.newMeth(C$, 'createRingAtomIndexMap$com_actelion_research_chem_StereoMolecule',  function (mol) {
var ringCollection=mol.getRingSet$();
var rings=ringCollection.getSize$();
this.arrAtomInSmallRing=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
this.arrAtomInLargeRing=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
for (var ringNo=0; ringNo < rings; ringNo++) {
var ringSize=ringCollection.getRingSize$I(ringNo);
var arrIndexRingAtoms=ringCollection.getRingAtoms$I(ringNo);
if (ringSize <= 6) {
for (var indexRingAtom, $indexRingAtom = 0, $$indexRingAtom = arrIndexRingAtoms; $indexRingAtom<$$indexRingAtom.length&&((indexRingAtom=($$indexRingAtom[$indexRingAtom])),1);$indexRingAtom++) {
this.arrAtomInSmallRing[indexRingAtom]=true;
}
} else {
for (var indexRingAtom, $indexRingAtom = 0, $$indexRingAtom = arrIndexRingAtoms; $indexRingAtom<$$indexRingAtom.length&&((indexRingAtom=($$indexRingAtom[$indexRingAtom])),1);$indexRingAtom++) {
this.arrAtomInLargeRing[indexRingAtom]=true;
}
}}
}, p$1);

Clazz.newMeth(C$, 'isSmallRingAtom$I',  function (indexAtom) {
return this.arrAtomInSmallRing[indexAtom];
}, p$1);

Clazz.newMeth(C$, 'getSmallRingsWithConnEndStanding$com_actelion_research_chem_StereoMolecule',  function (mol) {
var liFragmentRings=Clazz.new_($I$(4,1));
var ringHelper=Clazz.new_($I$(11,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
var ringCollection=ringHelper.getRingCollection$();
var rings=ringCollection.getSize$();
for (var ringNo=0; ringNo < rings; ringNo++) {
var ringSize=ringCollection.getRingSize$I(ringNo);
if (ringSize > 6) {
continue;
}var arrIndexRingAtoms=ringCollection.getRingAtoms$I(ringNo);
if (ringHelper.isEnclosingRing$IA(arrIndexRingAtoms)) {
continue;
}var fragment=Clazz.new_($I$(6,1));
fragment.addIndex$IA(arrIndexRingAtoms);
liFragmentRings.add$O(fragment);
}
var liFragmentRingsMerged=$I$(6).mergeOverlapping$java_util_List$I(liFragmentRings, 3);
for (var subGraphIndices, $subGraphIndices = liFragmentRingsMerged.iterator$(); $subGraphIndices.hasNext$()&&((subGraphIndices=($subGraphIndices.next$())),1);) {
var arrIndexRingAtoms=subGraphIndices.getAtomIndices$();
for (var indexRingAtom, $indexRingAtom = 0, $$indexRingAtom = arrIndexRingAtoms; $indexRingAtom<$$indexRingAtom.length&&((indexRingAtom=($$indexRingAtom[$indexRingAtom])),1);$indexRingAtom++) {
var nConnAtms=mol.getConnAtoms$I(indexRingAtom);
if (nConnAtms < 3) {
continue;
}for (var i=0; i < nConnAtms; i++) {
var indAtmConn=mol.getConnAtom$I$I(indexRingAtom, i);
if (mol.getAtomicNo$I(indAtmConn) == 1) {
continue;
}var nConnAtomsChild=mol.getConnAtoms$I(indAtmConn);
if (nConnAtomsChild == 1) {
subGraphIndices.addIndex$I(indAtmConn);
}}
}
}
return liFragmentRingsMerged;
}, p$1);

Clazz.newMeth(C$, 'getAliphaticGroupsInLargeRings$com_actelion_research_chem_StereoMolecule$com_actelion_research_util_hash_HashSetInt',  function (mol, hsAtomIndicesInFragmentEndStandingAliphaticGroup) {
var liFragmentLargeRings=Clazz.new_($I$(4,1));
var ringCollection=mol.getRingSet$();
var rings=ringCollection.getSize$();
var arrIndAtmUsedInEndStandingAliphaticGroupMap=C$.getMapFromHashSetOfIndices$com_actelion_research_chem_StereoMolecule$com_actelion_research_util_hash_HashSetInt(mol, hsAtomIndicesInFragmentEndStandingAliphaticGroup);
for (var ringNo=0; ringNo < rings; ringNo++) {
var ringSize=ringCollection.getRingSize$I(ringNo);
if (ringSize > 6) {
var arrIndexRingAtoms=ringCollection.getRingAtoms$I(ringNo);
var atomsInRingAlreadyUsed=false;
for (var indAtmRing, $indAtmRing = 0, $$indAtmRing = arrIndexRingAtoms; $indAtmRing<$$indAtmRing.length&&((indAtmRing=($$indAtmRing[$indAtmRing])),1);$indAtmRing++) {
if (arrIndAtmUsedInEndStandingAliphaticGroupMap[indAtmRing]) {
atomsInRingAlreadyUsed=true;
break;
}}
if (atomsInRingAlreadyUsed) {
continue;
}var fragment=p$1.largestAliphaticFragment$com_actelion_research_chem_StereoMolecule$IA$I.apply(this, [mol, arrIndexRingAtoms, 3]);
if (fragment != null ) {
liFragmentLargeRings.add$O(fragment);
}}}
for (var i=liFragmentLargeRings.size$() - 1; i >= 0; i--) {
var fragment=liFragmentLargeRings.get$I(i);
for (var ringNo=0; ringNo < rings; ringNo++) {
var ringSize=ringCollection.getRingSize$I(ringNo);
if (ringSize <= 6) {
var arrIndAtmMap=C$.getMapFromArrayOfIndices$com_actelion_research_chem_StereoMolecule$IA(mol, ringCollection.getRingAtoms$I(ringNo));
var arrIndAtmFrag=fragment.getAtomIndices$();
var nOverlap=0;
for (var indAtmFrag, $indAtmFrag = 0, $$indAtmFrag = arrIndAtmFrag; $indAtmFrag<$$indAtmFrag.length&&((indAtmFrag=($$indAtmFrag[$indAtmFrag])),1);$indAtmFrag++) {
if (arrIndAtmMap[indAtmFrag]) {
++nOverlap;
}}
if (nOverlap > 2) {
liFragmentLargeRings.remove$I(i);
break;
}}}
}
return liFragmentLargeRings;
}, p$1);

Clazz.newMeth(C$, 'getMapFromHashSetOfIndices$com_actelion_research_chem_StereoMolecule$com_actelion_research_util_hash_HashSetInt',  function (mol, hsAtomIndices) {
var arrIndAtmMap=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
var arrIndAtmUsed=hsAtomIndices.getValues$();
for (var indAtmUsed, $indAtmUsed = 0, $$indAtmUsed = arrIndAtmUsed; $indAtmUsed<$$indAtmUsed.length&&((indAtmUsed=($$indAtmUsed[$indAtmUsed])),1);$indAtmUsed++) {
arrIndAtmMap[indAtmUsed]=true;
}
return arrIndAtmMap;
}, 1);

Clazz.newMeth(C$, 'getMapFromArrayOfIndices$com_actelion_research_chem_StereoMolecule$IA',  function (mol, arrAtomIndices) {
var arrIndAtmMap=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
for (var indAtmUsed, $indAtmUsed = 0, $$indAtmUsed = arrAtomIndices; $indAtmUsed<$$indAtmUsed.length&&((indAtmUsed=($$indAtmUsed[$indAtmUsed])),1);$indAtmUsed++) {
arrIndAtmMap[indAtmUsed]=true;
}
return arrIndAtmMap;
}, 1);

Clazz.newMeth(C$, 'getEndStandingHeteroGroups$com_actelion_research_chem_StereoMolecule$java_util_List',  function (mol, liEndStandingAtoms) {
var liFragmentHetero=Clazz.new_($I$(4,1));
for (var indexEndStandingAtom, $indexEndStandingAtom = liEndStandingAtoms.iterator$(); $indexEndStandingAtom.hasNext$()&&((indexEndStandingAtom=($indexEndStandingAtom.next$()).intValue$()),1);) {
var atomicNo=mol.getAtomicNo$I(indexEndStandingAtom);
var indAtmConn=mol.getConnAtom$I$I(indexEndStandingAtom, 0);
if (p$1.isSmallRingAtom$I.apply(this, [indAtmConn])) {
if (atomicNo != 7 && atomicNo != 8  && atomicNo != 16  && atomicNo != 17  && atomicNo != 35 ) continue;
}if ($I$(7).isHetero$com_actelion_research_chem_ExtendedMolecule$I(mol, indexEndStandingAtom) || $I$(7).isHetero$com_actelion_research_chem_ExtendedMolecule$I(mol, indAtmConn) ) {
var fragment=Clazz.new_($I$(6,1));
fragment.addIndex$I(indexEndStandingAtom);
fragment.addIndex$I(indAtmConn);
liFragmentHetero.add$O(fragment);
}}
$I$(6).merge$java_util_List(liFragmentHetero);
for (var frag, $frag = liFragmentHetero.iterator$(); $frag.hasNext$()&&((frag=($frag.next$())),1);) {
var arrAtomIndices=frag.getAtomIndices$();
for (var atmIndex, $atmIndex = 0, $$atmIndex = arrAtomIndices; $atmIndex<$$atmIndex.length&&((atmIndex=($$atmIndex[$atmIndex])),1);$atmIndex++) {
var nConnAtms=mol.getConnAtoms$I(atmIndex);
if (nConnAtms > 1) {
var heteroParent=$I$(7).isHetero$com_actelion_research_chem_ExtendedMolecule$I(mol, atmIndex);
for (var i=0; i < nConnAtms; i++) {
var indexAtmConn=mol.getConnAtom$I$I(atmIndex, i);
if (frag.contains$I(indexAtmConn)) {
continue;
}var heteroChild=$I$(7).isHetero$com_actelion_research_chem_ExtendedMolecule$I(mol, indexAtmConn);
if (p$1.isSmallRingAtom$I.apply(this, [indexAtmConn])) {
continue;
}if (heteroParent || heteroChild ) {
frag.addIndex$I(indexAtmConn);
}}
}}
}
$I$(6).merge$java_util_List(liFragmentHetero);
for (var frag, $frag = liFragmentHetero.iterator$(); $frag.hasNext$()&&((frag=($frag.next$())),1);) {
var arrAtomIndices=frag.getAtomIndices$();
for (var atmIndex, $atmIndex = 0, $$atmIndex = arrAtomIndices; $atmIndex<$$atmIndex.length&&((atmIndex=($$atmIndex[$atmIndex])),1);$atmIndex++) {
var nConnAtms=mol.getConnAtoms$I(atmIndex);
if (nConnAtms > 1) {
for (var i=0; i < nConnAtms; i++) {
var indexAtmConn=mol.getConnAtom$I$I(atmIndex, i);
if (mol.isRingAtom$I(indexAtmConn)) {
continue;
} else if (frag.contains$I(indexAtmConn)) {
continue;
}if ($I$(7).isHetero$com_actelion_research_chem_ExtendedMolecule$I(mol, indexAtmConn)) {
frag.addIndex$I(indexAtmConn);
}}
}}
}
$I$(6).merge$java_util_List(liFragmentHetero);
for (var frag, $frag = liFragmentHetero.iterator$(); $frag.hasNext$()&&((frag=($frag.next$())),1);) {
var arrAtomIndices=frag.getAtomIndices$();
for (var atmIndex, $atmIndex = 0, $$atmIndex = arrAtomIndices; $atmIndex<$$atmIndex.length&&((atmIndex=($$atmIndex[$atmIndex])),1);$atmIndex++) {
var nConnAtms=mol.getConnAtoms$I(atmIndex);
if (nConnAtms == 1) {
continue;
}for (var i=0; i < nConnAtms; i++) {
var indexAtmConn=mol.getConnAtom$I$I(atmIndex, i);
if (frag.contains$I(indexAtmConn)) {
continue;
}var endStandingChild=(mol.getConnAtoms$I(indexAtmConn) == 1) ? true : false;
if (!endStandingChild) {
continue;
}if (mol.getAtomicNo$I(indexAtmConn) != 1) {
frag.addIndex$I(indexAtmConn);
if (mol.getAtomicNo$I(indexAtmConn) != 6) {
System.err.println$S("Wrong non-carbon atom at this index " + indexAtmConn);
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["This should not happen! But happened for " + mol.getIDCode$()]);
}}}
}
}
return liFragmentHetero;
}, p$1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.SubGraphExtractor, "MaximumTopologicalDist", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['at1','at2','dist']]]

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(1,1));
sb.append$I(this.at1);
sb.append$S(" ");
sb.append$I(this.at2);
sb.append$S(" ");
sb.append$I(this.dist);
return sb.toString();
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:37 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
