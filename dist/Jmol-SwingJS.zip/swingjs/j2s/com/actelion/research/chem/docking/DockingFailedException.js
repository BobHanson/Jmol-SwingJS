(function(){var P$=Clazz.newPackage("com.actelion.research.chem.docking"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "DockingFailedException", null, 'Exception');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$S',  function (errorMessage) {
;C$.superclazz.c$$S.apply(this,[errorMessage]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:38 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
