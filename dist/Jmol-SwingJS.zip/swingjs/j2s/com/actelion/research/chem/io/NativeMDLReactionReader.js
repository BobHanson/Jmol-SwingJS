(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io"),p$1={},I$=[[0,'java.io.File','java.util.ArrayList','com.actelion.research.chem.io.DTP','com.actelion.research.chem.io.SBF','StringBuffer','com.actelion.research.util.DoubleFormat','com.actelion.research.chem.reaction.Reaction','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.AromaticityResolver','java.io.DataInputStream','java.io.FileInputStream']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "NativeMDLReactionReader");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['mYield'],'I',['mReactionCount','mBufferIndex','mBitmask','mSolventCount','mCatalystCount','mPointerErrors','mFieldCount'],'S',['mDirectory'],'O',['mDTPDir','com.actelion.research.chem.io.DTP[]','mSBFDir','com.actelion.research.chem.io.SBF[]','mRootDTP','com.actelion.research.chem.io.DTP','mBuffer','int[]','mReaction','com.actelion.research.chem.reaction.Reaction','mReactantData','StringBuffer','+mProductData','+mSolventData','+mCatalystData','mMolRegNo','int[]','+mSolventRegNo','+mCatalystRegNo','mSolvents','java.util.ArrayList','+mCatalysts']]]

Clazz.newMeth(C$, 'c$$S',  function (directory) {
;C$.$init$.apply(this);
this.mDirectory=directory + $I$(1).separator;
p$1.readDTP$S.apply(this, ["DTPDIR.DAT"]);
p$1.readSBF$S.apply(this, ["SBFDIR.DAT"]);
if (this.mDTPDir != null  && this.mSBFDir != null  ) {
for (var dtp=0; dtp < this.mDTPDir.length; dtp++) {
if (this.mDTPDir[dtp].dtpnam.equals$O("VARIATION")) {
this.mRootDTP=this.mDTPDir[dtp];
var dis=p$1.getDataInputStream$S.apply(this, [p$1.pointerfile$I.apply(this, [this.mRootDTP.drpoin])]);
this.mReactionCount=(p$1.readFileSize$java_io_DataInputStream.apply(this, [dis])/4|0) - 2;
}}
}this.mBuffer=Clazz.array(Integer.TYPE, [512]);
this.mSolvents=Clazz.new_($I$(2,1));
this.mCatalysts=Clazz.new_($I$(2,1));
this.mMolRegNo=Clazz.array(Integer.TYPE, [16]);
this.mSolventRegNo=Clazz.array(Integer.TYPE, [40]);
this.mCatalystRegNo=Clazz.array(Integer.TYPE, [40]);
this.mPointerErrors=0;
}, 1);

Clazz.newMeth(C$, 'getReactionCount$',  function () {
return this.mReactionCount;
});

Clazz.newMeth(C$, 'getPointerErrors$',  function () {
return this.mPointerErrors;
});

Clazz.newMeth(C$, 'getVariationCount$I',  function (regNo) {
for (var i=0; i < this.mDTPDir.length; i++) {
var dtp=this.mDTPDir[i];
if (dtp.dtpnam.equals$O("VARIATION")) {
var blocks=p$1.getData$I$IA$com_actelion_research_chem_io_DTP.apply(this, [regNo, this.mBuffer, dtp]);
return blocks;
}}
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["no VARIATION data type"]);
});

Clazz.newMeth(C$, 'pointerfile$I',  function (no) {
if (no < 10) return "DR000" + no + ".DAT" ;
if (no < 100) return "DR00" + no + ".DAT" ;
return "DR0" + no + ".DAT" ;
}, p$1);

Clazz.newMeth(C$, 'datafile$I',  function (no) {
if (no < 10) return "FL000" + no + ".DAT" ;
if (no < 100) return "FL00" + no + ".DAT" ;
return "FL0" + no + ".DAT" ;
}, p$1);

Clazz.newMeth(C$, 'readDTP$S',  function (filename) {
var dis=p$1.getDataInputStream$S.apply(this, [filename]);
var size=(p$1.readFileSize$java_io_DataInputStream.apply(this, [dis])/188|0);
this.mDTPDir=Clazz.array($I$(3), [size]);
var buf=Clazz.array(Byte.TYPE, [20]);
for (var i=0; i < size; i++) {
var dtp=this.mDTPDir[i]=Clazz.new_($I$(3,1));
dtp.lnum=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
dtp.drpoin=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
dtp.parentID=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
dtp.length=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
dtp.typno=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
dtp.security=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
dtp.sbfpoin=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
dtp.sbfnum=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
dtp.hash=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
dtp.unk5=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
dtp.unk6=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
dtp.unk7=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
dis.read$BA$I$I(buf, 0, 20);
dtp.dtpnam= String.instantialize(buf).trim$();
dtp.access1=dis.readByte$();
dtp.access2=dis.readByte$();
dis.read$BA$I$I(dtp.empty=Clazz.array(Byte.TYPE, [2]), 0, 2);
dtp.isparent=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
dtp.depdata=Clazz.array(Integer.TYPE, [20]);
for (var j=0; j < 20; j++) dtp.depdata[j]=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);

dtp.rootID=Clazz.array(Integer.TYPE, [4]);
for (var j=0; j < 4; j++) dtp.rootID[j]=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);

dtp.unk9=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
dtp.unk10=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
dtp.drsize=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
dtp.unk11=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
}
dis.close$();
}, p$1);

Clazz.newMeth(C$, 'readSBF$S',  function (filename) {
var dis=p$1.getDataInputStream$S.apply(this, [filename]);
var size=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
if (size < 0) size=(-size/160|0);
 else size=(dis.available$()/160|0);
this.mSBFDir=Clazz.array($I$(4), [size]);
var buf=Clazz.array(Byte.TYPE, [20]);
for (var i=0; i < size; i++) {
var sbf=this.mSBFDir[i]=Clazz.new_($I$(4,1));
dis.read$BA$I$I(buf, 0, 20);
sbf.shortnam= String.instantialize(buf).trim$();
dis.read$BA$I$I(buf, 0, 20);
sbf.format1= String.instantialize(buf).trim$();
dis.read$BA$I$I(buf, 0, 20);
sbf.format2= String.instantialize(buf).trim$();
dis.read$BA$I$I(buf, 0, 20);
sbf.name= String.instantialize(buf).trim$();
sbf.lnum=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
sbf.type=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
sbf.a2=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
sbf.a3=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
sbf.datalen=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
sbf.datatyp=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
sbf.a5=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
sbf.dtppoin=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
sbf.a7=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
sbf.begin=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
sbf.a8=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
sbf.a9=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
sbf.a10=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
sbf.a11=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
sbf.a12=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
sbf.a13=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
sbf.a14=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
sbf.a15=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
sbf.a16=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
sbf.a17=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
sbf.fieldNo=-1;
}
dis.close$();
}, p$1);

Clazz.newMeth(C$, 'getReaction$I$I',  function (reaction, variation) {
var regNo=reaction + 1;
this.mReaction=null;
this.mYield=-1;
var variationPointer=-1;
this.mCatalysts.clear$();
this.mSolvents.clear$();
this.mSolventCount=0;
this.mCatalystCount=0;
for (var i=0; i < this.mDTPDir.length; i++) {
var dtp=this.mDTPDir[i];
if (dtp.dtpnam.equals$O("VARIATION")) {
var blocks=p$1.getData$I$IA$com_actelion_research_chem_io_DTP.apply(this, [regNo, this.mBuffer, dtp]);
if (blocks == 0) throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["invalid regNo"]);
if (variation >= blocks) throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["invalid variation"]);
variationPointer=this.mBuffer[variation];
break;
}}
if (variationPointer == -1) throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["no VARIATION data type"]);
for (var i=0; i < this.mDTPDir.length; i++) if (this.mDTPDir[i].typno == 3) p$1.getReaction$I$com_actelion_research_chem_io_DTP.apply(this, [regNo, this.mDTPDir[i]]);

for (var i=0; i < this.mDTPDir.length; i++) {
if (this.mDTPDir[i].typno == 24) p$1.getMapping$I$com_actelion_research_chem_io_DTP.apply(this, [regNo, this.mDTPDir[i]]);
if ((this.mDTPDir[i].typno == -19) || (this.mDTPDir[i].typno == -20) ) {
if (this.mDTPDir[i].rootID[2] - 1 == i) p$1.getDeepCatalysts$I$com_actelion_research_chem_io_DTP.apply(this, [variationPointer, this.mDTPDir[i]]);
 else p$1.getCatalysts$I$com_actelion_research_chem_io_DTP.apply(this, [variationPointer, this.mDTPDir[i]]);
}try {
if (this.mDTPDir[i].dtpnam.equals$O("RXNYIELD")) {
var blocks=p$1.getData$I$IA$com_actelion_research_chem_io_DTP.apply(this, [variationPointer, this.mBuffer, this.mDTPDir[i]]);
if (blocks == 1) p$1.extractFloatYield.apply(this, []);
}} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
} else {
throw e;
}
}
}
try {
if (this.mYield == -1 ) {
var product=null;
for (var i=0; i < this.mDTPDir.length; i++) {
if (this.mDTPDir[i].typno == -14) {
var blocks=p$1.getData$I$IA$com_actelion_research_chem_io_DTP.apply(this, [variationPointer, this.mBuffer, this.mDTPDir[i]]);
if (blocks != 0) {
product=Clazz.array(Integer.TYPE, [blocks]);
for (var j=0; j < blocks; j++) product[j]=this.mBuffer[j];

}break;
}}
if (product != null ) {
for (var i=0; i < this.mDTPDir.length; i++) {
if (this.mDTPDir[i].dtpnam.equals$O("YIELD")) {
for (var j=0; j < product.length; j++) {
if (p$1.getData$I$IA$com_actelion_research_chem_io_DTP.apply(this, [product[j], this.mBuffer, this.mDTPDir[i]]) == 1) {
p$1.extractFloatYield.apply(this, []);
if (this.mYield != -1 ) break;
}}
break;
}if (this.mDTPDir[i].dtpnam.equals$O("PRODAT")) {
if (this.mSBFDir[this.mDTPDir[i].sbfpoin - 1].name.equals$O("PERCENT YIELD:") || this.mSBFDir[this.mDTPDir[i].sbfpoin - 1].name.equals$O("Percent Yield:") ) {
for (var j=0; j < product.length; j++) {
if (p$1.getData$I$IA$com_actelion_research_chem_io_DTP.apply(this, [product[j], this.mBuffer, this.mDTPDir[i]]) == 1) {
if (this.mSBFDir[this.mDTPDir[i].sbfpoin - 1].type == 1) p$1.extractFloatYield.apply(this, []);
 else if (this.mSBFDir[this.mDTPDir[i].sbfpoin - 1].type == 4) p$1.extractIntYield.apply(this, []);
if (this.mYield != -1 ) break;
}}
break;
}}}
}}} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
} else {
throw e;
}
}
return this.mReaction;
});

Clazz.newMeth(C$, 'getCatalysts$',  function () {
return this.mCatalysts;
});

Clazz.newMeth(C$, 'getSolvents$',  function () {
return this.mSolvents;
});

Clazz.newMeth(C$, 'getReactantData$',  function () {
return this.mReactantData.length$() == 0 ? null : this.mReactantData.toString();
});

Clazz.newMeth(C$, 'getProductData$',  function () {
return this.mProductData.length$() == 0 ? null : this.mProductData.toString();
});

Clazz.newMeth(C$, 'getSolventData$',  function () {
return this.mSolventData.length$() == 0 ? null : this.mSolventData.toString();
});

Clazz.newMeth(C$, 'getCatalystData$',  function () {
return this.mCatalystData.length$() == 0 ? null : this.mCatalystData.toString();
});

Clazz.newMeth(C$, 'getFieldNames$',  function () {
this.mFieldCount=0;
for (var i=0; i < this.mDTPDir.length; i++) if (this.mDTPDir[i].parentID == -2) if (this.mDTPDir[i].typno == 0) p$1.getFieldNameBranch$com_actelion_research_chem_io_DTP.apply(this, [this.mDTPDir[i]]);

var fieldName=Clazz.array(String, [this.mFieldCount]);
for (var i=0; i < this.mSBFDir.length; i++) {
if (this.mSBFDir[i].fieldNo != -1) fieldName[this.mSBFDir[i].fieldNo]=this.mDTPDir[this.mSBFDir[i].dtppoin - 1].dtpnam + ((this.mSBFDir[i].name.length$() != 0) ? "." + this.mSBFDir[i].name : this.mSBFDir[i].shortnam.equals$O("*") ? "" : "." + this.mSBFDir[i].shortnam);
}
return fieldName;
});

Clazz.newMeth(C$, 'getFieldNameBranch$com_actelion_research_chem_io_DTP',  function (dtp) {
if (dtp.isparent != 0) {
for (var count=0; count < 20; count++) {
var deepdtp=dtp.depdata[count] - 1;
if (deepdtp == -1) break;
if (dtp.typno == 0) p$1.getFieldNameBranch$com_actelion_research_chem_io_DTP.apply(this, [this.mDTPDir[deepdtp]]);
}
} else {
for (var count=0; count < dtp.sbfnum; count++) {
var sbf=dtp.sbfpoin + count - 1;
this.mSBFDir[sbf].fieldNo=this.mFieldCount++;
}
}}, p$1);

Clazz.newMeth(C$, 'getFieldData$I$I',  function (reaction, variation) {
this.mReactantData=Clazz.new_($I$(5,1));
this.mProductData=Clazz.new_($I$(5,1));
this.mSolventData=Clazz.new_($I$(5,1));
this.mCatalystData=Clazz.new_($I$(5,1));
var regNo=reaction + 1;
var fieldData=Clazz.array(String, [this.mFieldCount]);
for (var i=0; i < this.mDTPDir.length; i++) if (this.mDTPDir[i].parentID == -2) if (this.mDTPDir[i].typno == 0) p$1.getBranch$I$com_actelion_research_chem_io_DTP$I$SA.apply(this, [regNo, this.mDTPDir[i], variation, fieldData]);

for (var i=0; i < this.mDTPDir.length; i++) {
if (this.mDTPDir[i].parentID == -1) {
if (this.mDTPDir[i].typno == 0) {
for (var mol=0; mol < this.mReaction.getReactants$(); mol++) if (this.mMolRegNo[mol] != 0) p$1.putMolText$I$StringBuffer$I$com_actelion_research_chem_io_DTP.apply(this, [this.mMolRegNo[mol], this.mReactantData, mol, this.mDTPDir[i]]);

for (var mol=0; mol < this.mReaction.getProducts$(); mol++) if (this.mMolRegNo[this.mReaction.getReactants$() + mol] != 0) p$1.putMolText$I$StringBuffer$I$com_actelion_research_chem_io_DTP.apply(this, [this.mMolRegNo[this.mReaction.getReactants$() + mol], this.mProductData, mol, this.mDTPDir[i]]);

for (var mol=0; mol < this.mSolventCount; mol++) if (this.mSolventRegNo[mol] != 0) p$1.putMolText$I$StringBuffer$I$com_actelion_research_chem_io_DTP.apply(this, [this.mSolventRegNo[mol], this.mSolventData, mol, this.mDTPDir[i]]);

for (var mol=0; mol < this.mCatalystCount; mol++) if (this.mCatalystRegNo[mol] != 0) p$1.putMolText$I$StringBuffer$I$com_actelion_research_chem_io_DTP.apply(this, [this.mCatalystRegNo[mol], this.mCatalystData, mol, this.mDTPDir[i]]);

}}}
return fieldData;
});

Clazz.newMeth(C$, 'getBranch$I$com_actelion_research_chem_io_DTP$I$SA',  function (entry, dtp, variation, fieldData) {
var data=Clazz.array(Integer.TYPE, [1024]);
var blocks=0;
try {
blocks=p$1.getData$I$IA$com_actelion_research_chem_io_DTP.apply(this, [entry, data, dtp]);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
} else {
throw e;
}
}
if (blocks == 0) return -1;
if (dtp.dtpnam.equals$O("VARIATION")) {
if (variation >= blocks) return -4;
data[0]=data[variation];
blocks=1;
}var indentation=0;
for (var i=1; i < 4; i++) if (dtp.rootID[i] != 0) ++indentation;

if (dtp.isparent != 0) {
for (var eintrag=0; eintrag < blocks; eintrag++) {
for (var count=0; count < 20; count++) {
var deepdtp=dtp.depdata[count] - 1;
if (deepdtp == -1) break;
if (dtp.typno == 0) p$1.getBranch$I$com_actelion_research_chem_io_DTP$I$SA.apply(this, [data[2 * eintrag], this.mDTPDir[deepdtp], variation, fieldData]);
 else if (dtp.typno == -13) p$1.putMolText$I$StringBuffer$I$com_actelion_research_chem_io_DTP.apply(this, [data[2 * eintrag], this.mReactantData, eintrag, this.mDTPDir[deepdtp]]);
 else if (dtp.typno == -14) p$1.putMolText$I$StringBuffer$I$com_actelion_research_chem_io_DTP.apply(this, [data[2 * eintrag], this.mProductData, eintrag, this.mDTPDir[deepdtp]]);
 else if (dtp.typno == -19) p$1.putMolText$I$StringBuffer$I$com_actelion_research_chem_io_DTP.apply(this, [data[2 * eintrag], this.mSolventData, eintrag, this.mDTPDir[deepdtp]]);
 else if (dtp.typno == -20) p$1.putMolText$I$StringBuffer$I$com_actelion_research_chem_io_DTP.apply(this, [data[2 * eintrag], this.mCatalystData, eintrag, this.mDTPDir[deepdtp]]);
}
}
if (dtp.typno == -19) this.mSolventCount=Math.min(this.mSolventCount + blocks, 40);
if (dtp.typno == -20) this.mCatalystCount=Math.min(this.mCatalystCount + blocks, 40);
} else {
var offset=0;
for (var block=0; block < blocks; block++) {
for (var count=0; count < dtp.sbfnum; count++) {
var sbf=dtp.sbfpoin + count - 1;
if (dtp.length == 0) if (this.mSBFDir[sbf].begin > data[offset]) break;
var datapoin=offset + this.mSBFDir[sbf].begin - (dtp.length == 0 ? 0 : 1);
if (this.mSBFDir[sbf].type == 1) {
if (this.mSBFDir[sbf].format2.length$() == 0 || data[datapoin] == 538976288 ) continue;
var text=p$1.filterText$S.apply(this, [p$1.formatedString$IA$I$com_actelion_research_chem_io_SBF.apply(this, [data, datapoin, this.mSBFDir[sbf]])]);
p$1.appendFieldData$SA$I$S.apply(this, [fieldData, this.mSBFDir[sbf].fieldNo, text]);
} else if (this.mSBFDir[sbf].type == 2) {
if (data[datapoin] == -2139062144) continue;
var buf=Clazz.new_($I$(5,1));
var v=0;
for (var i=0; i < this.mSBFDir[sbf].datalen; i++) {
v=((i & 3) == 0) ? data[datapoin + (i >> 2)] : v >>> 8;
buf.append$C(String.fromCharCode((v & 255)));
}
var text=p$1.filterText$S.apply(this, [buf.toString()]);
p$1.appendFieldData$SA$I$S.apply(this, [fieldData, this.mSBFDir[sbf].fieldNo, text]);
} else if (this.mSBFDir[sbf].type == 4) {
if (data[datapoin] == 538976288) continue;
var text="" + data[datapoin];
p$1.appendFieldData$SA$I$S.apply(this, [fieldData, this.mSBFDir[sbf].fieldNo, text]);
} else if (this.mSBFDir[sbf].type == 5) {
if (data[datapoin] == 0 || data[datapoin] == -2139062144 ) continue;
var length=4 * (data[offset] + 1 - this.mSBFDir[sbf].begin);
var buf=Clazz.new_($I$(5,1));
var v=0;
for (var i=0; i < length; i++) {
v=((i & 3) == 0) ? data[datapoin + (i >> 2)] : v >>> 8;
buf.append$C(String.fromCharCode((v & 255)));
}
var text=p$1.filterText$S.apply(this, [buf.toString()]);
p$1.appendFieldData$SA$I$S.apply(this, [fieldData, this.mSBFDir[sbf].fieldNo, text]);
}}
offset+=(dtp.length != 0) ? dtp.length + 1 : data[offset] + 2;
}
}return 0;
}, p$1);

Clazz.newMeth(C$, 'appendFieldData$SA$I$S',  function (fieldData, index, text) {
if (fieldData[index] == null ) fieldData[index]=text;
 else fieldData[index]=fieldData[index] + '\n' + text ;
}, p$1);

Clazz.newMeth(C$, 'putMolText$I$StringBuffer$I$com_actelion_research_chem_io_DTP',  function (entry, text, mol, dtp) {
var data=Clazz.array(Integer.TYPE, [512]);
if (dtp.isparent == 1) return -2;
var blocks=0;
try {
blocks=p$1.getData$I$IA$com_actelion_research_chem_io_DTP.apply(this, [entry, data, dtp]);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
} else {
throw e;
}
}
if (blocks == 0) return -3;
if (dtp.typno == 0) {
var offset=0;
for (var block=0; block < blocks; block++) {
for (var count=0; count < dtp.sbfnum; count++) {
var text1=null;
var text2=null;
var sbf=dtp.sbfpoin + count - 1;
if (dtp.length == 0) if (this.mSBFDir[sbf].begin > data[offset]) break;
text1=this.mSBFDir[sbf].name;
var datapoin=offset + this.mSBFDir[sbf].begin - (dtp.length == 0 ? 0 : 1);
if (this.mSBFDir[sbf].type == 1) {
if (this.mSBFDir[sbf].format2.length$() == 0 || data[datapoin] == 538976288 ) {
text2="";
continue;
}text2=p$1.filterText$S.apply(this, [p$1.formatedString$IA$I$com_actelion_research_chem_io_SBF.apply(this, [data, datapoin, this.mSBFDir[sbf]])]);
} else if (this.mSBFDir[sbf].type == 2) {
if (data[datapoin] == -2139062144) {
text2="";
continue;
}var buf=Clazz.new_($I$(5,1));
var v=0;
for (var i=0; i < this.mSBFDir[sbf].datalen; i++) {
v=((i & 3) == 0) ? data[datapoin + (i >> 2)] : v >>> 8;
buf.append$C(String.fromCharCode((v & 255)));
}
text2=p$1.filterText$S.apply(this, [buf.toString()]);
} else if (this.mSBFDir[sbf].type == 4) {
if (data[datapoin] == 538976288) {
text2="";
continue;
}text2="" + data[datapoin];
} else if (this.mSBFDir[sbf].type == 5) {
if (data[datapoin] == 0 || data[datapoin] == -2139062144 ) {
text2="";
continue;
}var length=4 * (data[offset] + 1 - this.mSBFDir[sbf].begin);
var buf=Clazz.new_($I$(5,1));
var v=0;
for (var i=0; i < length; i++) {
v=((i & 3) == 0) ? data[datapoin + (i >> 2)] : v >>> 8;
buf.append$C(String.fromCharCode((v & 255)));
}
text2=p$1.filterText$S.apply(this, [buf.toString()]);
}if (text2 != null ) {
if (text.length$() != 0) text.append$C("\n");
text.append$S("" + (mol + 1) + ") " + text1 );
if (!text1.endsWith$S(":")) text.append$S(":");
text.append$S(text2);
}}
offset+=(dtp.length != 0) ? dtp.length + 1 : data[offset] + 2;
}
}return 0;
}, p$1);

Clazz.newMeth(C$, 'formatedString$IA$I$com_actelion_research_chem_io_SBF',  function (data, datapoin, sbf) {
var range=Clazz.array(Double.TYPE, [2]);
var string=Clazz.new_($I$(5,1));
var dataCount=0;
var formatpoin=0;
var lengthAfterR1=0;
while (formatpoin < sbf.format2.length$()){
if (sbf.format2.charAt$I(formatpoin) == "R") {
if (dataCount > 1) return string.toString();
if (dataCount == 1) {
var previous=string.charAt$I(string.length$() - 1);
if (previous >= "0" && previous.$c() <= 9  ) string.append$C(" ");
}range[dataCount]=p$1.convertFloat$I.apply(this, [data[datapoin]]);
if (dataCount != 0) {
if (range[0] == range[1] ) {
string.setLength$I(lengthAfterR1);
++formatpoin;
continue;
}}string.append$S($I$(6).toString$D(1.00000001 * range[dataCount]));
if (dataCount == 0) lengthAfterR1=string.length$();
++dataCount;
++datapoin;
}if (sbf.format2.charAt$I(formatpoin) == "\'") {
++formatpoin;
while (sbf.format2.charAt$I(formatpoin) != "\'" && (formatpoin < 20) ){
if (sbf.format2.charAt$I(formatpoin) == "-") string.append$S(" - ");
 else string.append$C(sbf.format2.charAt$I(formatpoin));
++formatpoin;
}
}++formatpoin;
}
return string.toString();
}, p$1);

Clazz.newMeth(C$, 'filterText$S',  function (s) {
return s;
}, p$1);

Clazz.newMeth(C$, 'getDeepCatalysts$I$com_actelion_research_chem_io_DTP',  function (entry, dtp) {
var data=Clazz.array(Integer.TYPE, [50]);
var blocks=p$1.getData$I$IA$com_actelion_research_chem_io_DTP.apply(this, [entry, data, this.mDTPDir[dtp.rootID[1] - 1]]);
for (var block=0; block < blocks; block++) p$1.getCatalysts$I$com_actelion_research_chem_io_DTP.apply(this, [data[block * 2], dtp]);

}, p$1);

Clazz.newMeth(C$, 'getCatalysts$I$com_actelion_research_chem_io_DTP',  function (entry, dtp) {
var data=Clazz.array(Integer.TYPE, [100]);
var regno=Clazz.array(Integer.TYPE, [4]);
var blocks=p$1.getData$I$IA$com_actelion_research_chem_io_DTP.apply(this, [entry, data, dtp]);
if (blocks == 0) return;
for (var block=0; block < blocks; block++) {
for (var count=0; count < 20; count++) {
var deepdtp=dtp.depdata[count] - 1;
if (deepdtp == -1) break;
try {
if (this.mDTPDir[deepdtp].typno == -5 && p$1.getData$I$IA$com_actelion_research_chem_io_DTP.apply(this, [data[block * 2], regno, this.mDTPDir[deepdtp]]) == 1 ) {
this.mSolvents.add$O(p$1.getMolecule$I.apply(this, [regno[0]]));
this.mSolventRegNo[this.mSolventCount]=regno[0];
++this.mSolventCount;
}if (this.mDTPDir[deepdtp].typno == -6 && p$1.getData$I$IA$com_actelion_research_chem_io_DTP.apply(this, [data[block * 2], regno, this.mDTPDir[deepdtp]]) == 1 ) {
this.mCatalysts.add$O(p$1.getMolecule$I.apply(this, [regno[0]]));
this.mCatalystRegNo[this.mCatalystCount]=regno[0];
++this.mCatalystCount;
}} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
} else {
throw e;
}
}
break;
}
}
}, p$1);

Clazz.newMeth(C$, 'getData$I$IA$com_actelion_research_chem_io_DTP',  function (entry, data, dtp) {
var pointer=p$1.getPointer$I$com_actelion_research_chem_io_DTP.apply(this, [entry, dtp]);
if (pointer == 0) return 0;
if (pointer < 0) throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["getData() pointer < 0"]);
var filename=p$1.datafile$I.apply(this, [dtp.drpoin]);
var dis=p$1.getDataInputStream$S.apply(this, [filename]);
var size=p$1.readFileSize$java_io_DataInputStream.apply(this, [dis]);
if (4 + 4 * pointer >= size) {
dis.close$();
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["pointer >= filesize"]);
}dis.skipBytes$I(4 * pointer);
var offset=0;
var blocks=0;
switch (dtp.length) {
case 0:
do {
data[offset]=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
if (data[offset] < 0 || data[offset] >= 512 - offset - 2  ) {
dis.close$();
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["getData() unexpected value"]);
}for (var i=0; i <= data[offset]; i++) data[offset + i + 1 ]=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);

offset+=data[offset] + 2;
++blocks;
} while ((dtp.access2 == 77 ) && (data[offset - 1] == pointer + offset) );
break;
default:
do {
if ((dtp.length < 0) || (offset + dtp.length > 510) ) {
dis.close$();
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["getData() unexpected value"]);
}for (var i=0; i <= dtp.length; i++) data[offset + i]=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);

offset+=dtp.length + 1;
++blocks;
} while ((dtp.access2 == 77 ) && (data[offset - 1] == pointer + offset) );
break;
}
dis.close$();
return blocks;
}, p$1);

Clazz.newMeth(C$, 'getReaction$I$com_actelion_research_chem_io_DTP',  function (entry, dtp) {
var data=Clazz.array(Integer.TYPE, [20]);
if (p$1.getData$I$IA$com_actelion_research_chem_io_DTP.apply(this, [entry, data, dtp]) != 1) throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["getReaction() no molecules"]);
this.mReaction=Clazz.new_($I$(7,1));
for (var i=1; i <= data[0]; i++) {
this.mMolRegNo[i - 1]=Math.abs(data[i]);
if (data[i] < 0) this.mReaction.addReactant$com_actelion_research_chem_StereoMolecule(p$1.getMolecule$I.apply(this, [-data[i]]));
 else this.mReaction.addProduct$com_actelion_research_chem_StereoMolecule(p$1.getMolecule$I.apply(this, [data[i]]));
}
}, p$1);

Clazz.newMeth(C$, 'getMolecule$I',  function (regNo) {
var mol=Clazz.new_($I$(8,1));
for (var i=0; i < this.mDTPDir.length; i++) {
var dtp=this.mDTPDir[i];
if (dtp.parentID != -1) continue;
if (dtp.typno == 1) p$1.getSema$com_actelion_research_chem_Molecule$I$com_actelion_research_chem_io_DTP.apply(this, [mol, regNo, dtp]);
 else if (dtp.typno == 2) p$1.getCoords$com_actelion_research_chem_Molecule$I$com_actelion_research_chem_io_DTP.apply(this, [mol, regNo, dtp]);
}
Clazz.new_($I$(9,1).c$$com_actelion_research_chem_ExtendedMolecule,[mol]).locateDelocalizedDoubleBonds$ZA(null);
mol.setStereoBondsFromParity$();
return mol;
}, p$1);

Clazz.newMeth(C$, 'getSema$com_actelion_research_chem_Molecule$I$com_actelion_research_chem_io_DTP',  function (mol, molRegNo, dtp) {
if (p$1.getData$I$IA$com_actelion_research_chem_io_DTP.apply(this, [molRegNo, this.mBuffer, dtp]) != 1) throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["getSema() no sema data"]);
if (this.mBuffer[1] == -1) throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["getSema() empty sema data"]);
this.mBufferIndex=2;
this.mBitmask=-2147483648;
var entryLen=1 + p$1.readBits$I.apply(this, [4]);
mol.setAllAtoms$I(p$1.readBits$I.apply(this, [entryLen]));
mol.setAllBonds$I(p$1.readBits$I.apply(this, [entryLen]));
if (mol.getAllAtoms$() > mol.getMaxAtoms$() || mol.getAllBonds$() > mol.getMaxBonds$() ) throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["getSema() max atoms or bonds exceeded"]);
var fragments=p$1.readBits$I.apply(this, [entryLen]);
if (mol.getAllBonds$() < mol.getAllAtoms$() - fragments) throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["getSema() unexpected few bonds"]);
var bnd=0;
for (var i=0; i < mol.getAllAtoms$() - 1; i++) {
var atom1=p$1.readBits$I.apply(this, [entryLen]) - 1;
if (atom1 == -1) continue;
var atom2=i + 1;
mol.setBondAtom$I$I$I(0, bnd, atom1);
mol.setBondAtom$I$I$I(1, bnd, atom2);
++bnd;
}
for (var i=mol.getAllAtoms$() - 1; i < mol.getAllBonds$(); i++) {
var atom1=p$1.readBits$I.apply(this, [entryLen]) - 1;
if (atom1 == -1) continue;
var atom2=p$1.readBits$I.apply(this, [entryLen]) - 1;
mol.setBondAtom$I$I$I(0, bnd, atom1);
mol.setBondAtom$I$I$I(1, bnd, atom2);
++bnd;
}
for (var atm=0; atm < mol.getAllAtoms$(); atm++) mol.setAtomicNo$I$I(atm, p$1.readBits$I.apply(this, [8]));

var valences=p$1.readBits$I.apply(this, [entryLen]);
for (var cAtm=0; cAtm < valences; cAtm++) p$1.readBits$I.apply(this, [entryLen + 4]);

var isotops=p$1.readBits$I.apply(this, [entryLen]);
for (var cAtm=0; cAtm < isotops; cAtm++) {
var atm=p$1.readBits$I.apply(this, [entryLen]) - 1;
var mass=p$1.readBits$I.apply(this, [5]);
mol.setAtomMass$I$I(atm, mass - 18);
}
var charged=p$1.readBits$I.apply(this, [entryLen]);
for (var cAtm=0; cAtm < charged; cAtm++) {
var atm=p$1.readBits$I.apply(this, [entryLen]) - 1;
mol.setAtomCharge$I$I(atm, 16 - p$1.readBits$I.apply(this, [5]));
}
var radicals=p$1.readBits$I.apply(this, [entryLen]);
for (var cAtm=0; cAtm < radicals; cAtm++) {
var atm=p$1.readBits$I.apply(this, [entryLen]) - 1;
mol.setAtomRadical$I$I(atm, p$1.readBits$I.apply(this, [2]));
}
bnd=0;
for (var i=0; i < mol.getAllBonds$(); i++) {
var order=p$1.readBits$I.apply(this, [3]);
if (order == 0) continue;
order&=3;
mol.setBondType$I$I(bnd, order == 0 ? 64 : order == 1 ? 1 : order == 2 ? 2 : 4);
++bnd;
}
mol.setAllBonds$I(bnd);
var unknowns=p$1.readBits$I.apply(this, [entryLen]);
for (var i=0; i < unknowns; i++) p$1.readBits$I.apply(this, [3]);

unknowns=p$1.readBits$I.apply(this, [2]);
if ((unknowns & 2) != 0) {
for (var atm=0; atm < mol.getAllAtoms$(); atm++) {
var parity=p$1.readBits$I.apply(this, [3]);
if (parity == 4 || parity == 5 ) mol.setAtomParity$I$I$Z(atm, parity - 3, false);
}
}}, p$1);

Clazz.newMeth(C$, 'getCoords$com_actelion_research_chem_Molecule$I$com_actelion_research_chem_io_DTP',  function (mol, molRegNo, dtp) {
if (p$1.getData$I$IA$com_actelion_research_chem_io_DTP.apply(this, [molRegNo, this.mBuffer, dtp]) != 1) throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["getCoords() no coordinates"]);
this.mBufferIndex=1;
this.mBitmask=-2147483648;
for (var atm=0; atm < mol.getAllAtoms$(); atm++) {
mol.setAtomY$I$D(atm, (($s$[0]=-($s$[0] = p$1.readBits$I.apply(this, [16]), $s$[0]),($s$[0] = p$1.readBits$I.apply(this, [16]), $s$[0])=$s$[0],$s$[0])));
mol.setAtomX$I$D(atm, ($s$[0] = p$1.readBits$I.apply(this, [16]), $s$[0]));
}
}, p$1);

Clazz.newMeth(C$, 'getMapping$I$com_actelion_research_chem_io_DTP',  function (entry, dtp) {
if (p$1.getData$I$IA$com_actelion_research_chem_io_DTP.apply(this, [entry, this.mBuffer, dtp]) != 1) throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["getMapping() no mapping"]);
this.mBitmask=-2147483648;
this.mBufferIndex=1;
var datalen1=(1 + p$1.readBits$I.apply(this, [8])) >> 1;
var datalen2=(1 + p$1.readBits$I.apply(this, [8])) >> 1;
p$1.readBits$I.apply(this, [12]);
var entryLen=p$1.readBits$I.apply(this, [4]);
this.mBufferIndex=2 + datalen1;
var atms=Clazz.array(Integer.TYPE, [this.mReaction.getMolecules$()]);
for (var mol=0; mol < this.mReaction.getMolecules$(); mol++) atms[mol]=p$1.readBits$I.apply(this, [8]);

if ((this.mReaction.getMolecules$() % 4) != 0) {
++this.mBufferIndex;
this.mBitmask=-2147483648;
}this.mBufferIndex+=datalen2;
for (var mol=0; mol < this.mReaction.getMolecules$(); mol++) for (var atm=0; atm < atms[mol]; atm++) this.mReaction.getMolecule$I(mol).setAtomMapNo$I$I$Z(atm, p$1.readBits$I.apply(this, [entryLen]), false);


}, p$1);

Clazz.newMeth(C$, 'getPointer$I$com_actelion_research_chem_io_DTP',  function (entry, dtp) {
if (entry == -2139062144) return 0;
var dis=p$1.getDataInputStream$S.apply(this, [p$1.pointerfile$I.apply(this, [dtp.drpoin])]);
dis.skipBytes$I(4 + (1 + entry) * dtp.drsize * 4 );
try {
var pointer=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
dis.close$();
return pointer;
} catch (e$$) {
if (Clazz.exceptionOf(e$$,"java.io.EOFException")){
var e = e$$;
{
var f=p$1.getFile$S.apply(this, [p$1.pointerfile$I.apply(this, [dtp.drpoin])]);
dis.close$();
++this.mPointerErrors;
return 0;
}
} else if (Clazz.exceptionOf(e$$,"java.io.IOException")){
var e = e$$;
{
dis.close$();
++this.mPointerErrors;
return 0;
}
} else {
throw e$$;
}
}
}, p$1);

Clazz.newMeth(C$, 'readFileSize$java_io_DataInputStream',  function (dis) {
var size=p$1.readInt$java_io_DataInputStream.apply(this, [dis]);
return (size < 0) ? -size : dis.available$();
}, p$1);

Clazz.newMeth(C$, 'readInt$java_io_DataInputStream',  function (dis) {
return p$1.invertInt$I.apply(this, [dis.readInt$()]);
}, p$1);

Clazz.newMeth(C$, 'invertInt$I',  function (i) {
return ((i & 255) << 24) + ((i & 65280) << 8) + ((i & 16711680) >>> 8) + ((i & -16777216) >>> 24) ;
}, p$1);

Clazz.newMeth(C$, 'extractFloatYield',  function () {
if (this.mBuffer[0] != 538976288) {
var yield1=p$1.convertFloat$I.apply(this, [this.mBuffer[0]]);
var yield2=p$1.convertFloat$I.apply(this, [this.mBuffer[1]]);
if (yield1 >= 0  && yield1 <= 100.1  ) {
if (yield2 >= 0  && yield2 <= 100.1  ) yield1=(yield1 + yield2) / 2;
this.mYield=((yield1 + 0.5)|0);
}}}, p$1);

Clazz.newMeth(C$, 'extractIntYield',  function () {
if (this.mBuffer[0] >= 0 && this.mBuffer[0] <= 100 ) this.mYield=this.mBuffer[0];
}, p$1);

Clazz.newMeth(C$, 'convertFloat$I',  function (i) {
if (i == 0) return 0;
var e=(i & 32640) >> 7;
var m=((i & 127) << 16) | ((i & -65536) >>> 16) | 8388608 ;
var v=m / 1.6777216E7 * Math.pow(2, e - 128);
return ((i & 32768) == 0) ? v : -v;
}, p$1);

Clazz.newMeth(C$, 'readBits$I',  function (count) {
var retval=0;
for (var i=0; i < count; i++) {
retval<<=1;
if ((this.mBitmask & this.mBuffer[this.mBufferIndex]) != 0) retval|=1;
this.mBitmask>>>=1;
if (this.mBitmask == 0) {
this.mBitmask=-2147483648;
++this.mBufferIndex;
}}
return retval;
}, p$1);

Clazz.newMeth(C$, 'getFile$S',  function (filename) {
var file=Clazz.new_($I$(1,1).c$$S,[this.mDirectory + filename]);
if (!file.exists$()) file=Clazz.new_([this.mDirectory + filename.toLowerCase$()],$I$(1,1).c$$S);
return file;
}, p$1);

Clazz.newMeth(C$, 'getDataInputStream$S',  function (filename) {
if (Clazz.new_($I$(1,1).c$$S,[this.mDirectory + filename]).exists$()) return Clazz.new_([Clazz.new_($I$(11,1).c$$S,[this.mDirectory + filename])],$I$(10,1).c$$java_io_InputStream);
return Clazz.new_([Clazz.new_([this.mDirectory + filename.toLowerCase$()],$I$(11,1).c$$S)],$I$(10,1).c$$java_io_InputStream);
}, p$1);
var $s$ = new Int16Array(1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:25 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
