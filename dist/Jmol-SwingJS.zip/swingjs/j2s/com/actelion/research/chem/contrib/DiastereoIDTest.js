(function(){var P$=Clazz.newPackage("com.actelion.research.chem.contrib"),I$=[[0,'java.util.TreeMap','com.actelion.research.chem.io.SDFileParser','com.actelion.research.chem.Canonizer','com.actelion.research.chem.contrib.HydrogenHandler']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DiastereoIDTest");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
var sdf2d="./src/main/java/com/actelion/research/chem/contrib/test/test-diastereo.sdf";
var sdf3d="./src/main/java/com/actelion/research/chem/contrib/test/test-diastereo-3d.sdf";
var mol2d=Clazz.new_($I$(1,1));
var mol2dh=Clazz.new_($I$(1,1));
var mol3dh=Clazz.new_($I$(1,1));
var parser=Clazz.new_($I$(2,1).c$$S,[sdf2d]);
while (parser.next$()){
var molecule=parser.getMolecule$();
var idCode=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule,[molecule]).getIDCode$();
mol2d.put$O$O(idCode, molecule);
var moleculeAllH=molecule.getCompactCopy$();
$I$(4).addImplicitHydrogens$com_actelion_research_chem_StereoMolecule(moleculeAllH);
var idCodeAllH=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule,[moleculeAllH]).getIDCode$();
mol2dh.put$O$O(idCodeAllH, moleculeAllH);
if (!idCode.equals$O(idCodeAllH)) {
System.out.println$S("ERROR : 2D: " + idCode + " - " + "2DH: " + idCodeAllH );
}}
parser=Clazz.new_($I$(2,1).c$$S,[sdf3d]);
while (parser.next$()){
var molecule=parser.getMolecule$();
var idCode=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule,[molecule]).getIDCode$();
mol3dh.put$O$O(idCode, molecule);
}
System.out.println$S("SIZE (should be the same): " + mol2d.size$() + " - " + mol2dh.size$() + " - " + mol3dh.size$() );
for (var id, $id = mol2d.keySet$().iterator$(); $id.hasNext$()&&((id=($id.next$())),1);) {
System.out.println$S(id + " - " + mol2dh.containsKey$O(id) + " - " + mol3dh.containsKey$O(id) );
}
System.out.println$S("ID from 3D molecule not present in 2D: ");
for (var id, $id = mol3dh.keySet$().iterator$(); $id.hasNext$()&&((id=($id.next$())),1);) {
if (!mol2d.containsKey$O(id)) {
System.out.println$S(id);
}}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:09 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
