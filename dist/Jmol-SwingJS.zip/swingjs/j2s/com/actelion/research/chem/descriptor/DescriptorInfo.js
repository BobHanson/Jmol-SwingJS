(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "DescriptorInfo", null, 'com.actelion.research.chem.descriptor.SimilarityCalculatorInfo');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['isBinary','isVector','isGraphSimilarity','needsCoordinates'],'I',['type'],'S',['version']]]

Clazz.newMeth(C$, 'c$$S$S$S$I$Z$Z$Z$Z',  function (name, shortName, version, type, isBinary, isVector, isGraphSimilarity, needsCoordinates) {
;C$.superclazz.c$$S$S.apply(this,[name, shortName]);C$.$init$.apply(this);
this.version=version;
this.type=type;
this.isBinary=isBinary;
this.isVector=isVector;
this.isGraphSimilarity=isGraphSimilarity;
this.needsCoordinates=needsCoordinates;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:36 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
