(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),I$=[[0,'com.actelion.research.chem.descriptor.DescriptorConstants','com.actelion.research.chem.descriptor.DescriptorHandlerSkeletonSpheres','com.actelion.research.util.datamodel.IntVec','com.actelion.research.calc.Logarithm']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DescriptorHandlerBinarySkelSpheres", null, 'com.actelion.research.chem.descriptor.AbstractDescriptorHandlerFP');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['dhSkeletonSpheres','com.actelion.research.chem.descriptor.DescriptorHandlerSkeletonSpheres']]
,['S',['VERSION'],'O',['DEFAULT_INSTANCE','com.actelion.research.chem.descriptor.DescriptorHandlerBinarySkelSpheres']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.dhSkeletonSpheres=Clazz.new_($I$(2,1));
}, 1);

Clazz.newMeth(C$, 'getInfo$',  function () {
return $I$(1).DESCRIPTOR_BINARY_SKELETONSPHERES;
});

Clazz.newMeth(C$, 'getVersion$',  function () {
return C$.VERSION;
});

Clazz.newMeth(C$, ['createDescriptor$com_actelion_research_chem_StereoMolecule','createDescriptor$O'],  function (mol) {
var arrSkelSpheres=this.dhSkeletonSpheres.createDescriptor$com_actelion_research_chem_StereoMolecule(mol);
return C$.createDescriptorFromSkelSpheresArrayCompressed$BA(arrSkelSpheres);
});

Clazz.newMeth(C$, 'createDescriptorFromSkelSpheresArrayCompressed$BA',  function (arrSkelSpheres) {
var thresh=8;
if ((arrSkelSpheres == null ) || (arrSkelSpheres.length == 0) ) {
return null;
}var numInteger=(arrSkelSpheres.length/(64)|0);
var lenInBit=(arrSkelSpheres.length/2|0);
var iv=Clazz.new_($I$(3,1).c$$I,[numInteger]);
for (var i=0; i < arrSkelSpheres.length; i+=2) {
var freq=arrSkelSpheres[i] + arrSkelSpheres[i + 1];
if (freq > 0) {
var bitsSet=0;
if (freq > 8) {
bitsSet=8 + $I$(4).log2$I(freq - 8) + 1 ;
} else {
bitsSet=freq;
}for (var j=0; j < bitsSet; j++) {
var index=((i/2|0)) + j;
var indexCircular=C$.getCircularIndexOffset$I$I(index, lenInBit);
iv.setBit$I(indexCircular);
}
}}
return iv.get$();
}, 1);

Clazz.newMeth(C$, 'getCircularIndexOffset$I$I',  function (index, lenDescriptor) {
var indexNew=index;
if (indexNew < lenDescriptor) {
return indexNew;
}indexNew=index - lenDescriptor;
return indexNew;
}, 1);

Clazz.newMeth(C$, 'getThreadSafeCopy$',  function () {
return Clazz.new_(C$);
});

Clazz.newMeth(C$, ['getSimilarity$IA$IA','getSimilarity$O$O'],  function (a1, a2) {
var bcAND=0;
var bcOR=0;
for (var i=0; i < a1.length; i++) {
var v1=a1[i];
var v2=a2[i];
bcAND+=Integer.bitCount$I(v1 & v2);
bcOR+=Integer.bitCount$I(v1 | v2);
}
var score=bcAND / (bcOR);
return C$.correctionTS$D(score);
});

Clazz.newMeth(C$, 'getDefaultInstance$',  function () {
{
if (C$.DEFAULT_INSTANCE == null ) C$.DEFAULT_INSTANCE=Clazz.new_(C$);
}return C$.DEFAULT_INSTANCE;
}, 1);

Clazz.newMeth(C$, 'standardize$D',  function (s) {
if (s <= 0 ) {
return 0;
} else if (s >= 1.0 ) {
return 1.0;
}var sc=s - 0.2;
var v=Math.exp(-8.0 * (sc)) - 0.5;
return v;
}, 1);

Clazz.newMeth(C$, 'correctionTS$D',  function (s) {
var t1=0.7;
var t2=0.7;
var v=1.0 - Math.pow(1 - Math.pow(s, t1), 1.0 / t2);
if (v <= 0 ) {
return 0;
} else if (v >= 1.0 ) {
return 1.0;
}return v;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.VERSION=$I$(1).DESCRIPTOR_BINARY_SKELETONSPHERES.version;
};
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:09 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
