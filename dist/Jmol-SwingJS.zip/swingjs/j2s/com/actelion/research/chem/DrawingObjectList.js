(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'com.actelion.research.chem.AbstractDrawingObject','StringBuilder']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DrawingObjectList", null, 'java.util.ArrayList');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_DrawingObjectList',  function (l) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
try {
if (l != null ) for (var abstractDrawingObject, $abstractDrawingObject = l.iterator$(); $abstractDrawingObject.hasNext$()&&((abstractDrawingObject=($abstractDrawingObject.next$())),1);) this.add$O(abstractDrawingObject.clone$());

} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
} finally {
}
}, 1);

Clazz.newMeth(C$, 'c$$S',  function (objectString) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
if (objectString == null  || objectString.isEmpty$() ) return;
var index1=0;
var index2=objectString.indexOf$I("\n");
while (index2 != -1){
var o=$I$(1,"instantiate$S",[objectString.substring$I$I(index1, index2)]);
if (o != null ) this.add$O(o);
index1=index2 + 1;
index2=objectString.indexOf$I$I("\n", index1);
}
}, 1);

Clazz.newMeth(C$, 'toString',  function () {
var objectString=Clazz.new_($I$(2,1));
for (var abstractDrawingObject, $abstractDrawingObject = this.iterator$(); $abstractDrawingObject.hasNext$()&&((abstractDrawingObject=($abstractDrawingObject.next$())),1);) objectString.append$S(abstractDrawingObject.getDescriptor$()).append$S("\n");

return objectString.toString();
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:30 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
