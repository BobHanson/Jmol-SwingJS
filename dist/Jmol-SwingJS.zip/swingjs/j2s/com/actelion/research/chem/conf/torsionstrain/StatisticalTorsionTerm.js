(function(){var P$=Clazz.newPackage("com.actelion.research.chem.conf.torsionstrain"),p$1={},I$=[[0,'com.actelion.research.chem.conf.torsionstrain.StatisticalTorsionPotential','com.actelion.research.chem.Coordinates']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "StatisticalTorsionTerm", null, null, 'com.actelion.research.chem.potentialenergy.PotentialEnergyTerm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['rik2'],'O',['conf','com.actelion.research.chem.conf.Conformer','atoms','int[]','rearAtoms','int[][]','f','com.actelion.research.chem.interactionstatistics.SplineFunction']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_conf_Conformer$IA$com_actelion_research_chem_interactionstatistics_SplineFunction',  function (conf, atoms, f) {
;C$.$init$.apply(this);
this.conf=conf;
this.f=f;
this.atoms=atoms;
p$1.assessRearAtoms.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'assessRearAtoms',  function () {
var mol=this.conf.getMolecule$();
this.rearAtoms=Clazz.array(Integer.TYPE, [2, null]);
if (this.atoms[0] == -1) {
this.rearAtoms[0]=Clazz.array(Integer.TYPE, [2]);
var index=0;
for (var i=0; i < mol.getConnAtoms$I(this.atoms[1]); i++) {
if (mol.getConnAtom$I$I(this.atoms[1], i) == this.atoms[2]) continue;
 else {
this.rearAtoms[0][index]=mol.getConnAtom$I$I(this.atoms[1], i);
++index;
}}
}if (this.atoms[3] == -1) {
this.rearAtoms[1]=Clazz.array(Integer.TYPE, [2]);
var index=0;
for (var i=0; i < mol.getConnAtoms$I(this.atoms[2]); i++) {
if (mol.getConnAtom$I$I(this.atoms[2], i) == this.atoms[1]) continue;
 else {
this.rearAtoms[1][index]=mol.getConnAtom$I$I(this.atoms[2], i);
++index;
}}
}}, p$1);

Clazz.newMeth(C$, 'create$com_actelion_research_chem_conf_Conformer$IA$S',  function (conf, atoms, torsionID) {
var f=$I$(1).getInstance$().getFunction$S(torsionID);
if (f == null ) {
return null;
}return Clazz.new_(C$.c$$com_actelion_research_chem_conf_Conformer$IA$com_actelion_research_chem_interactionstatistics_SplineFunction,[conf, atoms, f]);
}, 1);

Clazz.newMeth(C$, 'getCartesianTorsionGradient$IA$com_actelion_research_chem_conf_Conformer$DA$D$com_actelion_research_chem_CoordinatesA$IAA',  function (atoms, conf, gradient, dEdPhi, coords, rearAtoms) {
var c1=coords[0];
var c2=coords[1];
var c3=coords[2];
var c4=coords[3];
var a1=atoms[0];
var a2=atoms[1];
var a3=atoms[2];
var a4=atoms[3];
var r=Clazz.array($I$(2), -1, [c1.subC$com_actelion_research_chem_Coordinates(c2), c3.subC$com_actelion_research_chem_Coordinates(c2), c2.subC$com_actelion_research_chem_Coordinates(c3), c4.subC$com_actelion_research_chem_Coordinates(c3)]);
var t=Clazz.array($I$(2), -1, [r[0].cross$com_actelion_research_chem_Coordinates(r[1]), r[2].cross$com_actelion_research_chem_Coordinates(r[3])]);
var d=Clazz.array(Double.TYPE, -1, [t[0].dist$(), t[1].dist$()]);
if (Math.abs(d[0]) < 1.0E-5  || Math.abs(d[1]) < 1.0E-5  ) return;
t[0].unit$();
t[1].unit$();
var cosPhi=t[0].dot$com_actelion_research_chem_Coordinates(t[1]);
var sinPhiSq=1.0 - cosPhi * cosPhi;
var sinPhi=((sinPhiSq > 0.0 ) ? Math.sqrt(sinPhiSq) : 0.0);
var sinTerm=-dEdPhi * (Math.abs(sinPhi) < 1.0E-5  ? (1.0 / cosPhi) : (1.0 / sinPhi));
var dCos_dT=Clazz.array(Double.TYPE, -1, [1.0 / d[0] * (t[1].x - cosPhi * t[0].x), 1.0 / d[0] * (t[1].y - cosPhi * t[0].y), 1.0 / d[0] * (t[1].z - cosPhi * t[0].z), 1.0 / d[1] * (t[0].x - cosPhi * t[1].x), 1.0 / d[1] * (t[0].y - cosPhi * t[1].y), 1.0 / d[1] * (t[0].z - cosPhi * t[1].z)]);
if (rearAtoms != null ) {
if (rearAtoms[0] != null ) {
var derX=sinTerm * (dCos_dT[2] * r[1].y - dCos_dT[1] * r[1].z);
var derY=sinTerm * (dCos_dT[0] * r[1].z - dCos_dT[2] * r[1].x);
var derZ=sinTerm * (dCos_dT[1] * r[1].x - dCos_dT[0] * r[1].y);
gradient[3 * rearAtoms[0][0]]-=derX;
gradient[3 * rearAtoms[0][0] + 1]-=derY;
gradient[3 * rearAtoms[0][0] + 2]-=derZ;
gradient[3 * rearAtoms[0][1]]-=derX;
gradient[3 * rearAtoms[0][1] + 1]-=derY;
gradient[3 * rearAtoms[0][1] + 2]-=derZ;
} else {
gradient[3 * a1 + 0]+=sinTerm * (dCos_dT[2] * r[1].y - dCos_dT[1] * r[1].z);
gradient[3 * a1 + 1]+=sinTerm * (dCos_dT[0] * r[1].z - dCos_dT[2] * r[1].x);
gradient[3 * a1 + 2]+=sinTerm * (dCos_dT[1] * r[1].x - dCos_dT[0] * r[1].y);
}}gradient[3 * a2 + 0]+=sinTerm * (dCos_dT[1] * (r[1].z - r[0].z) + dCos_dT[2] * (r[0].y - r[1].y) + dCos_dT[4] * (-r[3].z) + dCos_dT[5] * (r[3].y));
gradient[3 * a2 + 1]+=sinTerm * (dCos_dT[0] * (r[0].z - r[1].z) + dCos_dT[2] * (r[1].x - r[0].x) + dCos_dT[3] * (r[3].z) + dCos_dT[5] * (-r[3].x));
gradient[3 * a2 + 2]+=sinTerm * (dCos_dT[0] * (r[1].y - r[0].y) + dCos_dT[1] * (r[0].x - r[1].x) + dCos_dT[3] * (-r[3].y) + dCos_dT[4] * (r[3].x));
gradient[3 * a3 + 0]+=sinTerm * (dCos_dT[1] * (r[0].z) + dCos_dT[2] * (-r[0].y) + dCos_dT[4] * (r[3].z - r[2].z) + dCos_dT[5] * (r[2].y - r[3].y));
gradient[3 * a3 + 1]+=sinTerm * (dCos_dT[0] * (-r[0].z) + dCos_dT[2] * (r[0].x) + dCos_dT[3] * (r[2].z - r[3].z) + dCos_dT[5] * (r[3].x - r[2].x));
gradient[3 * a3 + 2]+=sinTerm * (dCos_dT[0] * (r[0].y) + dCos_dT[1] * (-r[0].x) + dCos_dT[3] * (r[3].y - r[2].y) + dCos_dT[4] * (r[2].x - r[3].x));
if (rearAtoms != null ) {
if (rearAtoms[1] != null ) {
var derX=sinTerm * (dCos_dT[4] * r[2].z - dCos_dT[5] * r[2].y);
var derY=sinTerm * (dCos_dT[5] * r[2].x - dCos_dT[3] * r[2].z);
var derZ=sinTerm * (dCos_dT[3] * r[2].y - dCos_dT[4] * r[2].x);
gradient[3 * rearAtoms[1][0]]-=derX;
gradient[3 * rearAtoms[1][0] + 1]-=derY;
gradient[3 * rearAtoms[1][0] + 2]-=derZ;
gradient[3 * rearAtoms[1][1]]-=derX;
gradient[3 * rearAtoms[1][1] + 1]-=derY;
gradient[3 * rearAtoms[1][1] + 2]-=derZ;
} else {
gradient[3 * a4 + 0]+=sinTerm * (dCos_dT[4] * r[2].z - dCos_dT[5] * r[2].y);
gradient[3 * a4 + 1]+=sinTerm * (dCos_dT[5] * r[2].x - dCos_dT[3] * r[2].z);
gradient[3 * a4 + 2]+=sinTerm * (dCos_dT[3] * r[2].y - dCos_dT[4] * r[2].x);
}}}, 1);

Clazz.newMeth(C$, 'getFGValue$DA',  function (gradient) {
for (var i=0; i < gradient.length; i++) {
gradient[i]=0.0;
}
var c1;
var c2;
var c3;
var c4;
var a1=this.atoms[0];
var a2=this.atoms[1];
var a3=this.atoms[2];
var a4=this.atoms[3];
if (a1 == -1) {
var c=this.conf.getCoordinates$I(a2);
var c1a=this.conf.getCoordinates$I(this.rearAtoms[0][0]);
var c2a=this.conf.getCoordinates$I(this.rearAtoms[0][1]);
var v1=c1a.subC$com_actelion_research_chem_Coordinates(c);
var v2=c2a.subC$com_actelion_research_chem_Coordinates(c);
c1=v1.addC$com_actelion_research_chem_Coordinates(v2);
c1.scale$D(-1.0);
} else {
c1=this.conf.getCoordinates$I(a1);
}if (a4 == -1) {
var c=this.conf.getCoordinates$I(a3);
var c1a=this.conf.getCoordinates$I(this.rearAtoms[1][0]);
var c2a=this.conf.getCoordinates$I(this.rearAtoms[1][1]);
var v1=c1a.subC$com_actelion_research_chem_Coordinates(c);
var v2=c2a.subC$com_actelion_research_chem_Coordinates(c);
c4=v1.addC$com_actelion_research_chem_Coordinates(v2);
c4.scale$D(-1.0);
} else {
c4=this.conf.getCoordinates$I(a4);
}c2=this.conf.getCoordinates$I(this.atoms[1]);
c3=this.conf.getCoordinates$I(this.atoms[2]);
var dihedral=$I$(2).getDihedral$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates(c1, c2, c3, c4);
if (dihedral < 0.0 ) dihedral+=6.283185307179586;
var res=this.f.getFGValue$D(360.0 * dihedral / 2 * 3.141592653589793);
var e=res[0];
var dEdPhi=res[1];
C$.getCartesianTorsionGradient$IA$com_actelion_research_chem_conf_Conformer$DA$D$com_actelion_research_chem_CoordinatesA$IAA(this.atoms, this.conf, gradient, dEdPhi, Clazz.array($I$(2), -1, [c1, c2, c3, c4]), this.rearAtoms);
return e;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:03 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
