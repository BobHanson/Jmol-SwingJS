(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff.table"),I$=[[0,'com.actelion.research.chem.forcefield.mmff.Csv','com.actelion.research.chem.forcefield.mmff.Search']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Charge");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['pbci','Object[][]','+bci']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_Tables$S$S',  function (t, csv_pbci, csv_bci) {
;C$.$init$.apply(this);
this.pbci=$I$(1).readFile$S(csv_pbci);
this.bci=$I$(1).readFile$S(csv_bci);
}, 1);

Clazz.newMeth(C$, 'getFcadj$I',  function (type) {
return (this.pbci[type - 1][2]).doubleValue$();
});

Clazz.newMeth(C$, 'getPbci$I',  function (type) {
return (this.pbci[type - 1][1]).doubleValue$();
});

Clazz.newMeth(C$, 'getPartial$I$I$I',  function (bondt, a1t, a2t) {
var sign=a1t > a2t ? 1.0 : -1.0;
var atl=a1t > a2t ? a2t : a1t;
var ath=a1t > a2t ? a1t : a2t;
var a1lo=this.bci_binary_search$I$I$I$I$Z(1, atl, 0, this.bci.length, true);
var a1hi=this.bci_binary_search$I$I$I$I$Z(1, atl, 0, this.bci.length, false);
if (a1lo == -1 || a1hi == -1 ) return this.getPbci$I(a1t) - this.getPbci$I(a2t);
var a2lo=this.bci_binary_search$I$I$I$I$Z(2, ath, a1lo, a1hi + 1, true);
var a2hi=this.bci_binary_search$I$I$I$I$Z(2, ath, a1lo, a1hi + 1, false);
if (a2lo == -1 || a2hi == -1 ) return this.getPbci$I(a1t) - this.getPbci$I(a2t);
if (bondt == 0 && this.get_bci_n$I$I(a2lo, 0) == 0 ) return sign * this.get_bci_f$I$I(a2lo, 3);
 else if (bondt == 1 && this.get_bci_n$I$I(a2hi, 0) == 1 ) return sign * this.get_bci_f$I$I(a2hi, 3);
return this.getPbci$I(a1t) - this.getPbci$I(a2t);
});

Clazz.newMeth(C$, 'bci_binary_search$I$I$I$I$Z',  function (col, val, lo, hi, findlow) {
return $I$(2,"binary$I$I$I$I$Z$com_actelion_research_chem_forcefield_mmff_Searchable",[col, val, lo, hi, findlow, ((P$.Charge$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "Charge$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'com.actelion.research.chem.forcefield.mmff.Searchable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'get$I$I',  function (row, col) {
return (this.b$['com.actelion.research.chem.forcefield.mmff.table.Charge'].bci[row][col]).intValue$();
});

Clazz.newMeth(C$, 'length$',  function () {
return this.b$['com.actelion.research.chem.forcefield.mmff.table.Charge'].bci.length;
});
})()
), Clazz.new_(P$.Charge$1.$init$,[this, null]))]);
});

Clazz.newMeth(C$, 'get_bci_f$I$I',  function (row, col) {
return (this.bci[row][col]).doubleValue$();
});

Clazz.newMeth(C$, 'get_bci_n$I$I',  function (row, col) {
return (this.bci[row][col]).intValue$();
});

Clazz.newMeth(C$, 'get_bci_len$',  function () {
return this.bci.length;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:06 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
