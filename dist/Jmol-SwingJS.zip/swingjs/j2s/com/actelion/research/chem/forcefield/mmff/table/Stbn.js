(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff.table"),I$=[[0,'com.actelion.research.chem.forcefield.mmff.Csv','com.actelion.research.chem.forcefield.mmff.type.Angle','com.actelion.research.chem.forcefield.mmff.Search','com.actelion.research.chem.forcefield.mmff.type.Bond']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Stbn", null, null, 'com.actelion.research.chem.forcefield.mmff.Searchable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['table','Object[][]','t','com.actelion.research.chem.forcefield.mmff.Tables']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_Tables$S',  function (t, csvpath) {
;C$.$init$.apply(this);
this.table=$I$(1).readFile$S(csvpath);
this.t=t;
}, 1);

Clazz.newMeth(C$, 'get$I$I',  function (row, col) {
return (this.table[row][col]).intValue$();
});

Clazz.newMeth(C$, 'length$',  function () {
return this.table.length;
});

Clazz.newMeth(C$, 'index$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I',  function (mol, a1, a2, a3) {
var a1t=mol.getAtomType$I(a1);
var a2t=mol.getAtomType$I(a2);
var a3t=mol.getAtomType$I(a3);
var angt=$I$(2).getStbnType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I(this.t, mol, a1, a2, a3);
if (a1t > a3t) a1t=($I$(3,"s$O$O",[Integer.valueOf$I(a3t), Integer.valueOf$I(a3t=a1t)])).$c();
return $I$(3,"binary$IA$IA$com_actelion_research_chem_forcefield_mmff_Searchable",[Clazz.array(Integer.TYPE, -1, [2, 1, 3, 0]), Clazz.array(Integer.TYPE, -1, [a2t, a1t, a3t, angt]), this]);
});

Clazz.newMeth(C$, 'kba$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I',  function (mol, a1, a2, a3) {
var a1t=mol.getAtomType$I(a1);
var a3t=mol.getAtomType$I(a3);
var b1t=$I$(4).getType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(this.t, mol, a1, a2);
var b2t=$I$(4).getType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(this.t, mol, a2, a3);
var idx=this.index$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I(mol, a1, a2, a3);
var at=a1t > a3t || a1t == a3t && b1t < b2t   ? 1 : 0;
if (idx >= 0) return (this.table[idx][4 + at]).doubleValue$();
return this.t.dfsb.kb$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I(mol, a1, a2, a3);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:38 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
