(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff.table"),I$=[[0,'com.actelion.research.chem.forcefield.mmff.Csv','com.actelion.research.chem.forcefield.mmff.type.Bond','com.actelion.research.chem.forcefield.mmff.Search','com.actelion.research.chem.forcefield.mmff.PeriodicTable']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Bond", null, null, 'com.actelion.research.chem.forcefield.mmff.Searchable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['table','Object[][]','t','com.actelion.research.chem.forcefield.mmff.Tables']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_Tables$S',  function (t, csvpath) {
;C$.$init$.apply(this);
this.table=$I$(1).readFile$S(csvpath);
this.t=t;
}, 1);

Clazz.newMeth(C$, 'get$I$I',  function (row, col) {
return (this.table[row][col]).intValue$();
});

Clazz.newMeth(C$, 'length$',  function () {
return this.table.length;
});

Clazz.newMeth(C$, 'r0$I',  function (index) {
return (this.table[index][4]).doubleValue$();
});

Clazz.newMeth(C$, 'kb$I',  function (index) {
return (this.table[index][3]).doubleValue$();
});

Clazz.newMeth(C$, 'r0$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I',  function (mol, atom1, atom2) {
var bondt=$I$(2,"getType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I",[this.t, mol, mol.getBond$I$I(atom1, atom2)]);
var a1t=mol.getAtomType$I(atom1);
var a2t=mol.getAtomType$I(atom2);
if (a1t > a2t) a1t=($I$(3,"s$O$O",[Integer.valueOf$I(a2t), Integer.valueOf$I(a2t=a1t)])).$c();
var index=$I$(3,"binary$IA$IA$com_actelion_research_chem_forcefield_mmff_Searchable",[Clazz.array(Integer.TYPE, -1, [1, 2, 0]), Clazz.array(Integer.TYPE, -1, [a1t, a2t, bondt]), this]);
if (index >= 0) return this.r0$I(index);
 else {
var a1no=mol.getAtomicNo$I(atom1);
var a2no=mol.getAtomicNo$I(atom2);
if (a1no > a2no) a1no=($I$(3,"s$O$O",[Integer.valueOf$I(a2no), Integer.valueOf$I(a2no=a1no)])).$c();
var a1cri=$I$(3).binary$I$I$com_actelion_research_chem_forcefield_mmff_Searchable(0, a1no, this.t.covrad);
var a2cri=$I$(3).binary$I$I$com_actelion_research_chem_forcefield_mmff_Searchable(0, a2no, this.t.covrad);
var r0_i=this.t.covrad.r0$I(a1cri);
var r0_j=this.t.covrad.r0$I(a2cri);
var chi_i=this.t.covrad.chi$I(a1cri);
var chi_j=this.t.covrad.chi$I(a2cri);
var c=a1no == 1 || a2no == 1  ? 0.05 : 0.085;
return r0_i + r0_j - c * Math.pow(Math.abs(chi_i - chi_j), 1.4);
}});

Clazz.newMeth(C$, 'kb$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I',  function (mol, atom1, atom2) {
var bondt=$I$(2,"getType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I",[this.t, mol, mol.getBond$I$I(atom1, atom2)]);
var a1t=mol.getAtomType$I(atom1);
var a2t=mol.getAtomType$I(atom2);
if (a1t > a2t) a1t=($I$(3,"s$O$O",[Integer.valueOf$I(a2t), Integer.valueOf$I(a2t=a1t)])).$c();
var index=$I$(3,"binary$IA$IA$com_actelion_research_chem_forcefield_mmff_Searchable",[Clazz.array(Integer.TYPE, -1, [1, 2, 0]), Clazz.array(Integer.TYPE, -1, [a1t, a2t, bondt]), this]);
if (index >= 0) {
return this.kb$I(index);
} else {
var a1no=mol.getAtomicNo$I(atom1);
var a2no=mol.getAtomicNo$I(atom2);
if (a1no > a2no) a1no=($I$(3,"s$O$O",[Integer.valueOf$I(a2no), Integer.valueOf$I(a2no=a1no)])).$c();
var r0=this.r0$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(mol, atom1, atom2);
var bndk_idx=$I$(3,"binary$IA$IA$com_actelion_research_chem_forcefield_mmff_Searchable",[Clazz.array(Integer.TYPE, -1, [0, 1]), Clazz.array(Integer.TYPE, -1, [a1no, a2no]), this.t.bndk]);
if (bndk_idx >= 0) {
var coeff=Math.pow(this.t.bndk.r0$I(bndk_idx) / r0, 6);
return this.t.bndk.kb$I(bndk_idx) * coeff;
} else {
var bidx=$I$(3,"binary$IA$IA$com_actelion_research_chem_forcefield_mmff_Searchable",[Clazz.array(Integer.TYPE, -1, [0, 1]), Clazz.array(Integer.TYPE, -1, [$I$(4).rowtm$I(a1no), $I$(4).rowtm$I(a2no)]), this.t.hblaurie]);
return Math.pow(10.0, -(r0 - this.t.hblaurie.fget$I$I(bidx, 2)) / this.t.hblaurie.fget$I$I(bidx, 3));
}}});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:06 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
