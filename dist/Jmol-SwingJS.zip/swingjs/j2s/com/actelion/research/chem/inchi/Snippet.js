(function(){var P$=Clazz.newPackage("com.actelion.research.chem.inchi"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Snippet");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-29 16:52:11 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
