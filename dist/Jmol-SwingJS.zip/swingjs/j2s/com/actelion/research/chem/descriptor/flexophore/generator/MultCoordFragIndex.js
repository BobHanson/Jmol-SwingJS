(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.generator"),I$=[[0,'java.util.ArrayList','com.actelion.research.chem.Coordinates','com.actelion.research.util.datamodel.DoubleArray','com.actelion.research.util.Formatter','com.actelion.research.calc.histogram.MatrixBasedHistogram']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MultCoordFragIndex");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['arrIndexFrag','int[]','liCoord','java.util.List']]]

Clazz.newMeth(C$, 'c$$IA',  function (arrIndexFrag) {
;C$.$init$.apply(this);
this.arrIndexFrag=arrIndexFrag;
this.liCoord=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'getDeepClone$',  function () {
var a=Clazz.array(Integer.TYPE, [this.arrIndexFrag.length]);
System.arraycopy$O$I$O$I$I(this.arrIndexFrag, 0, a, 0, a.length);
var m=Clazz.new_(C$.c$$IA,[a]);
for (var coordinates, $coordinates = this.liCoord.iterator$(); $coordinates.hasNext$()&&((coordinates=($coordinates.next$())),1);) {
m.liCoord.add$O(Clazz.new_($I$(2,1).c$$com_actelion_research_chem_Coordinates,[coordinates]));
}
return m;
});

Clazz.newMeth(C$, 'isEqualIndices$com_actelion_research_chem_descriptor_flexophore_redgraph_SubGraphIndices',  function (sgi) {
return sgi.equalIndices$IA(this.arrIndexFrag);
});

Clazz.newMeth(C$, 'addCoord$com_actelion_research_chem_Coordinates',  function (coordinates) {
this.liCoord.add$O(coordinates);
});

Clazz.newMeth(C$, 'getCoordinates$',  function () {
return this.liCoord;
});

Clazz.newMeth(C$, 'getArrIndexFrag$',  function () {
return this.arrIndexFrag;
});

Clazz.newMeth(C$, 'getDistHist$com_actelion_research_chem_descriptor_flexophore_generator_MultCoordFragIndex$com_actelion_research_chem_descriptor_flexophore_generator_MultCoordFragIndex',  function (m1, m2) {
var minRangeDistanceHistogram=0;
var maxRangeDistanceHistogram=40;
var bins=80;
var n1=m1.liCoord.size$();
var n2=m2.liCoord.size$();
if (n1 != n2) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Number of distances differ for two fragments sets!"]);
}var daDistances=Clazz.new_($I$(3,1).c$$I,[n1]);
for (var i=0; i < n1; i++) {
var dist=m1.liCoord.get$I(i).distance$com_actelion_research_chem_Coordinates(m2.liCoord.get$I(i));
if (dist > 40 ) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Distance " + $I$(4,"format1$Double",[Double.valueOf$D(dist)]) + " between two pharmacophore points exceeded maximum histogram range." ]);
}daDistances.add$D(dist);
}
var maBins=$I$(5).getHistogramBins$D$D$I(0.0, 40.0, 80);
var maHist=$I$(5,"getHistogram$DA$com_actelion_research_calc_Matrix",[daDistances.get$(), maBins]);
var arrHist=maHist.getRow$I(2);
var countValuesInHistogram=0;
for (var i=0; i < arrHist.length; i++) {
countValuesInHistogram=(countValuesInHistogram+(arrHist[i])|0);
}
var arrHistPercent=Clazz.array(Byte.TYPE, [maHist.getColDim$()]);
for (var i=0; i < arrHist.length; i++) {
arrHistPercent[i]=((((arrHist[i] / countValuesInHistogram) * 100.0) + 0.5)|0);
}
return arrHistPercent;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:22 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
