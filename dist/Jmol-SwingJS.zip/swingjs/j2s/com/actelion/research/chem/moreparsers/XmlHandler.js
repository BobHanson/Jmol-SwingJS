(function(){var P$=Clazz.newPackage("com.actelion.research.chem.moreparsers"),I$=[[0,'org.xml.sax.InputSource']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "XmlHandler", null, 'org.xml.sax.helpers.DefaultHandler');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['xmlReader','com.actelion.research.chem.moreparsers.XmlReader']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'parseXML$com_actelion_research_chem_moreparsers_XmlReader$O$java_io_BufferedReader',  function (xmlReader, saxReaderObj, reader) {
this.xmlReader=xmlReader;
var saxReader=saxReaderObj;
saxReader.setFeature$S$Z("http://xml.org/sax/features/validation", false);
saxReader.setFeature$S$Z("http://xml.org/sax/features/namespaces", true);
saxReader.setEntityResolver$org_xml_sax_EntityResolver(this);
saxReader.setContentHandler$org_xml_sax_ContentHandler(this);
saxReader.setErrorHandler$org_xml_sax_ErrorHandler(this);
var is=Clazz.new_($I$(1,1).c$$java_io_Reader,[reader]);
is.setSystemId$S("foo");
saxReader.parse$org_xml_sax_InputSource(is);
});

Clazz.newMeth(C$, 'startDocument$',  function () {
});

Clazz.newMeth(C$, 'endDocument$',  function () {
this.xmlReader.endDocument$();
});

Clazz.newMeth(C$, 'startElement$S$S$S$org_xml_sax_Attributes',  function (namespaceURI, localName, nodeName, attributes) {
this.xmlReader.atts.clear$();
for (var i=attributes.getLength$(); --i >= 0; ) this.xmlReader.atts.put$O$O(attributes.getLocalName$I(i).toLowerCase$(), attributes.getValue$I(i));

this.xmlReader.processStartElement$S$S(localName.toLowerCase$(), nodeName.toLowerCase$());
});

Clazz.newMeth(C$, 'endElement$S$S$S',  function (uri, localName, qName) {
this.xmlReader.processEndElement$S(localName.toLowerCase$());
});

Clazz.newMeth(C$, 'characters$CA$I$I',  function (ch, start, length) {
if (this.xmlReader.keepChars) this.xmlReader.chars.append$CA$I$I(ch, start, length);
});

Clazz.newMeth(C$, 'resolveEntity$S$S$S$S',  function (name, publicId, baseURI, systemId) {
return null;
});

Clazz.newMeth(C$, 'error$org_xml_sax_SAXParseException',  function (exception) {
System.err.println$S("SAX ERROR:" + exception.getMessage$());
});

Clazz.newMeth(C$, 'fatalError$org_xml_sax_SAXParseException',  function (exception) {
System.err.println$S("SAX FATAL:" + exception.getMessage$());
});

Clazz.newMeth(C$, 'warning$org_xml_sax_SAXParseException',  function (exception) {
System.err.println$S("SAX WARNING:" + exception.getMessage$());
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-14 17:56:12 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
