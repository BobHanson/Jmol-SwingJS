(function(){var P$=Clazz.newPackage("com.actelion.research.chem.moreparsers"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ChemicalNameParser", null, 'com.actelion.research.chem.moreparsers.ChemicalIdentifierResolver');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
C$.c$$Z.apply(this, [false]);
}, 1);

Clazz.newMeth(C$, 'c$$Z',  function (keepHydrogenMap) {
;C$.superclazz.c$$S$Z.apply(this,["name", keepHydrogenMap]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-31 11:09:14 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
