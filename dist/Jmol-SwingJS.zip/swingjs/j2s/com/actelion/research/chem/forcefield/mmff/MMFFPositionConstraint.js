(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "MMFFPositionConstraint", null, null, 'com.actelion.research.chem.forcefield.mmff.EnergyTerm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['k','d'],'O',['refPos','double[]','constrained','boolean[]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$D$D',  function (mol, k, d) {
;C$.$init$.apply(this);
this.refPos=Clazz.array(Double.TYPE, [3 * mol.getAllAtoms$()]);
this.constrained=Clazz.array(Boolean.TYPE, [mol.getAllAtoms$()]);
for (var a=0; a < mol.getAllAtoms$(); a++) {
if (mol.getAtomicNo$I(a) == 1) this.constrained[a]=false;
 else this.constrained[a]=true;
this.refPos[3 * a]=mol.getAtomX$I(a);
this.refPos[3 * a + 1]=mol.getAtomY$I(a);
this.refPos[3 * a + 2]=mol.getAtomZ$I(a);
}
this.k=k;
this.d=d;
}, 1);

Clazz.newMeth(C$, 'getEnergy$DA',  function (pos) {
var energy=0.0;
for (var a=0; a < pos.length; a+=3) {
var atomId=(a/3|0);
if (!this.constrained[atomId]) continue;
var dx=pos[a] - this.refPos[a];
var dy=pos[a + 1] - this.refPos[a + 1];
var dz=pos[a + 2] - this.refPos[a + 2];
var dist=Math.sqrt(dx * dx + dy * dy + dz * dz);
var prefactor=0.0;
if (dist > this.d ) prefactor=dist - this.d;
 else prefactor=0.0;
energy+=0.5 * this.k * prefactor * prefactor ;
}
return energy;
});

Clazz.newMeth(C$, 'getGradient$DA$DA',  function (pos, grad) {
for (var a=0; a < pos.length; a+=3) {
var atomId=(a/3|0);
if (!this.constrained[atomId]) continue;
var dx=pos[a] - this.refPos[a];
var dy=pos[a + 1] - this.refPos[a + 1];
var dz=pos[a + 2] - this.refPos[a + 2];
var dist=Math.sqrt(dx * dx + dy * dy + dz * dz);
var prefactor=0.0;
if (dist > this.d ) prefactor=dist - this.d;
 else prefactor=0.0;
grad[a]+=prefactor * dx / Math.max(dist, 1.0E-8);
grad[a + 1]+=prefactor * dy / Math.max(dist, 1.0E-8);
grad[a + 2]+=prefactor * dz / Math.max(dist, 1.0E-8);
}
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:38 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
