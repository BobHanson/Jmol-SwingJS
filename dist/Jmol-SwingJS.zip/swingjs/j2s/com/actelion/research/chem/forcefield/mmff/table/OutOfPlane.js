(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff.table"),I$=[[0,'com.actelion.research.chem.forcefield.mmff.Csv','java.util.Arrays','com.actelion.research.chem.forcefield.mmff.Search']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "OutOfPlane", null, null, 'com.actelion.research.chem.forcefield.mmff.Searchable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['table','Object[][]','t','com.actelion.research.chem.forcefield.mmff.Tables']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_Tables$S',  function (t, csvpath) {
;C$.$init$.apply(this);
this.table=$I$(1).readFile$S(csvpath);
this.t=t;
}, 1);

Clazz.newMeth(C$, 'get$I$I',  function (row, col) {
return (this.table[row][col]).intValue$();
});

Clazz.newMeth(C$, 'length$',  function () {
return this.table.length;
});

Clazz.newMeth(C$, 'getKoop$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I',  function (mol, ac, a1, a2, a3) {
var act=mol.getAtomType$I(ac);
var nbr=Clazz.array(Integer.TYPE, -1, [mol.getAtomType$I(a1), mol.getAtomType$I(a2), mol.getAtomType$I(a3)]);
for (var i=0; i < 4; i++) {
var nbrf=Clazz.array(Integer.TYPE, [3]);
for (var n=0; n < 3; n++) nbrf[n]=this.t.def.table[nbr[n] - 1][i + 1];

$I$(2).sort$IA(nbrf);
var index=$I$(3,"binary$IA$IA$com_actelion_research_chem_forcefield_mmff_Searchable",[Clazz.array(Integer.TYPE, -1, [1, 0, 2, 3]), Clazz.array(Integer.TYPE, -1, [act, nbrf[0], nbrf[1], nbrf[2]]), this]);
if (index >= 0) return (this.table[index][4]).doubleValue$();
}
return 0.0;
});

Clazz.newMeth(C$, 'getKoop$I',  function (index) {
return (this.table[index][4]).doubleValue$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:38 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
