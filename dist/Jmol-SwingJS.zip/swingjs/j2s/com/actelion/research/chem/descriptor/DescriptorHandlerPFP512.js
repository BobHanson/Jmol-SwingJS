(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),p$1={},I$=[[0,'com.actelion.research.chem.descriptor.DescriptorConstants','com.actelion.research.chem.descriptor.FingerPrintGenerator','com.actelion.research.chem.descriptor.AbstractDescriptorHandlerFP']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DescriptorHandlerPFP512", null, 'com.actelion.research.chem.descriptor.AbstractDescriptorHandlerFP', 'com.actelion.research.chem.descriptor.DescriptorConstants');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['sDefaultInstance','com.actelion.research.chem.descriptor.DescriptorHandlerPFP512']]]

Clazz.newMeth(C$, 'getDefaultInstance$',  function () {
{
if (C$.sDefaultInstance == null ) {
C$.sDefaultInstance=Clazz.new_(C$);
}}return C$.sDefaultInstance;
}, 1);

Clazz.newMeth(C$, 'getInfo$',  function () {
return $I$(1).DESCRIPTOR_PFP512;
});

Clazz.newMeth(C$, 'getVersion$',  function () {
return $I$(1).DESCRIPTOR_PFP512.version;
});

Clazz.newMeth(C$, ['createDescriptor$com_actelion_research_chem_StereoMolecule','createDescriptor$O'],  function (mol) {
if (mol == null ) return null;
var bitset=Clazz.new_($I$(2,1)).getFingerprint$com_actelion_research_chem_StereoMolecule(mol);
if (bitset == null ) return $I$(3).FAILED_OBJECT;
var fp=Clazz.array(Integer.TYPE, [16]);
var mask=1;
for (var i=0; i < 32; i++) {
for (var j=0; j < 16; j++) if (bitset.get$I(16 * i + j)) fp[j]+=mask;

mask<<=1;
}
return fp;
});

Clazz.newMeth(C$, 'getThreadSafeCopy$',  function () {
return this;
});

Clazz.newMeth(C$, ['getSimilarity$IA$IA','getSimilarity$O$O'],  function (o1, o2) {
return p$1.normalizeValue$D.apply(this, [C$.superclazz.prototype.getSimilarity$IA$IA.apply(this, [o1, o2])]);
});

Clazz.newMeth(C$, 'normalizeValue$D',  function (value) {
return value <= 0.0  ? 0.0 : value >= 1.0  ? 1.0 : (1.0 - Math.pow(1 - Math.pow(value, 0.85), 1.1764705882352942));
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:36 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
