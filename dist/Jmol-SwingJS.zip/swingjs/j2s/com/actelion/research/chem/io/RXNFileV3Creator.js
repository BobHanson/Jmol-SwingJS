(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io"),p$1={},I$=[[0,'com.actelion.research.chem.reaction.Reaction','java.io.StringWriter','com.actelion.research.chem.reaction.ReactionEncoder','com.actelion.research.chem.MolfileV3Creator']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "RXNFileV3Creator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.rxnbuffer=null;
},1);

C$.$fields$=[['O',['rxnbuffer','StringBuffer']]
,['S',['NL']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_reaction_Reaction',  function (rxn) {
C$.c$$com_actelion_research_chem_reaction_Reaction$S.apply(this, [rxn, null]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_reaction_Reaction$S',  function (r, programName) {
;C$.$init$.apply(this);
var rxn=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_reaction_Reaction,[r]);
try {
var theWriter=Clazz.new_($I$(2,1));
theWriter.write$S("$RXN V3000" + C$.NL);
theWriter.write$S(programName != null  ? programName : "");
theWriter.write$S(C$.NL + C$.NL);
theWriter.write$S("OCL_RXN_V1.0:" + $I$(3).encode$com_actelion_research_chem_reaction_Reaction$Z$I(r, true, 11));
theWriter.write$S(C$.NL);
var rcnt=rxn.getReactants$();
var pcnt=rxn.getProducts$();
theWriter.write$S(String.format$S$OA("M  V30 COUNTS %d %d" + C$.NL, Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(rcnt), Integer.valueOf$I(pcnt)])));
var scalingFactor=p$1.getScalingFactor$com_actelion_research_chem_reaction_Reaction.apply(this, [rxn]);
if (rcnt > 0) {
theWriter.write$S("M  V30 BEGIN REACTANT" + C$.NL);
for (var i=0; i < rxn.getReactants$(); i++) {
theWriter.write$S($I$(4,"writeCTAB$com_actelion_research_chem_StereoMolecule$D",[rxn.getReactant$I(i), scalingFactor]));
}
theWriter.write$S("M  V30 END REACTANT" + C$.NL);
}if (pcnt > 0) {
theWriter.write$S("M  V30 BEGIN PRODUCT" + C$.NL);
for (var i=0; i < rxn.getProducts$(); i++) {
theWriter.write$S($I$(4,"writeCTAB$com_actelion_research_chem_StereoMolecule$D",[rxn.getProduct$I(i), scalingFactor]));
}
theWriter.write$S("M  V30 END PRODUCT" + C$.NL);
}theWriter.write$S("M  END" + C$.NL);
this.rxnbuffer=theWriter.getBuffer$();
theWriter.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("Error in RXNFileCreator: " + e);
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getScalingFactor$com_actelion_research_chem_reaction_Reaction',  function (rxn) {
var avbl=0;
var bondCount=0;
for (var m=0; m < rxn.getMolecules$(); m++) {
avbl+=rxn.getMolecule$I(m).getAverageBondLength$() * rxn.getMolecule$I(m).getAllBonds$();
bondCount+=rxn.getMolecule$I(m).getAllBonds$();
}
if (bondCount != 0) return bondCount / avbl;
return 1.0;
}, p$1);

Clazz.newMeth(C$, 'getRXNfile$',  function () {
return this.rxnbuffer != null  ? this.rxnbuffer.toString() : null;
});

Clazz.newMeth(C$, 'writeRXNfile$java_io_Writer',  function (theWriter) {
if (this.rxnbuffer == null ) throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["NULL RXNFileBuffer!"]);
theWriter.write$S(this.rxnbuffer.toString());
});

C$.$static$=function(){C$.$static$=0;
C$.NL=System.lineSeparator$();
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:39 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
