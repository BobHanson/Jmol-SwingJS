(function(){var P$=Clazz.newPackage("com.actelion.research.chem.chemicalspaces.ptree.search"),p$1={},p$2={},I$=[[0,['com.actelion.research.chem.descriptor.pharmacophoretree.TreeMatcher','.TreeMatching'],['com.actelion.research.chem.chemicalspaces.ptree.search.FragmentPTreeSearch','.FragmentMatching'],'java.util.HashSet','com.actelion.research.chem.descriptor.pharmacophoretree.TreeUtils','java.util.ArrayList','com.actelion.research.chem.descriptor.pharmacophoretree.HungarianAlgorithm',['com.actelion.research.chem.descriptor.pharmacophoretree.TreeMatcher','.FeatureMatch'],'com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreNode','java.util.HashMap',['com.actelion.research.chem.chemicalspaces.ptree.search.FragmentPTreeSearch','.SearchResult'],'java.util.LinkedHashMap',['java.util.Map','.Entry'],'java.util.stream.Collectors',['com.actelion.research.chem.chemicalspaces.ptree.search.FragmentPTreeSearch','.FragmentMatchSearch'],'com.actelion.research.chem.chemicalspaces.synthon.SynthonReactor','StringBuilder']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FragmentPTreeSearch", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['FragmentMatchSearch',9],['FragmentMatching',9],['SearchResult',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['pTreeSimilarityCutoff'],'I',['nBestSolutions'],'O',['queryTree','com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreTree','synthonLib','com.actelion.research.chem.chemicalspaces.ptree.synthon.PharmTreeSynthonLibrary','rxnHelper','com.actelion.research.chem.chemicalspaces.ptree.PharmTreeSynthonReactionHelper','edgeLinkTable','com.actelion.research.chem.chemicalspaces.ptree.search.FragmentPTreeSearch.SearchResult[][]','linkerToSynthons','java.util.Map','cuts','int[]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$com_actelion_research_chem_chemicalspaces_ptree_synthon_PharmTreeSynthonLibrary$D',  function (queryMol, queryTree, synthonLib, pTreeSimilarityCutoff) {
;C$.$init$.apply(this);
this.queryTree=queryTree;
this.rxnHelper=synthonLib.getReactionHelper$();
this.pTreeSimilarityCutoff=pTreeSimilarityCutoff;
this.synthonLib=synthonLib;
this.cuts=Clazz.array(Integer.TYPE, -1, [-1, 1]);
this.nBestSolutions=2000;
this.linkerToSynthons=Clazz.new_($I$(9,1));
}, 1);

Clazz.newMeth(C$, 'processFragments',  function () {
var allLinkers=Clazz.new_($I$(3,1));
var highestLinkerID=0;
this.rxnHelper.getReactantsWithLinkers$().values$().stream$().forEach$java_util_function_Consumer(((P$.FragmentPTreeSearch$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "FragmentPTreeSearch$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$java_util_List','accept$O'],  function (e) { return (this.$finals$.allLinkers.addAll$java_util_Collection.apply(this.$finals$.allLinkers, [e]));});
})()
), Clazz.new_(P$.FragmentPTreeSearch$lambda1.$init$,[this, {allLinkers:allLinkers}])));
for (var linkerID, $linkerID = allLinkers.iterator$(); $linkerID.hasNext$()&&((linkerID=($linkerID.next$()).intValue$()),1);) if (linkerID > highestLinkerID) highestLinkerID=linkerID;

var allSynthons=this.synthonLib.getSynthons$();
this.edgeLinkTable=Clazz.array($I$(10), [highestLinkerID * allSynthons.size$(), this.queryTree.getEdges$().size$() * 2]);
for (var i=0; i < allSynthons.size$(); i++) {
var synthons=allSynthons.get$I(i);
for (var j=0; j < synthons.size$(); j++) {
var synthon=synthons.get$I(j);
var fragmentTree=synthon.getPharmTree$();
for (var n=0; n < fragmentTree.getNodes$().size$(); n++) {
var node=fragmentTree.getNodes$().get$I(n);
if (node.isLinkNode$()) {
var linkerID=node.getFunctionalities$()[0];
var linkerEdge=-1;
for (var e=0; e < fragmentTree.getEdges$().size$(); e++) {
var edge=fragmentTree.getEdges$().get$I(e);
if (edge[0] == n || edge[1] == n ) {
linkerEdge=e;
break;
}}
var id=linkerID + (i << 3);
this.linkerToSynthons.putIfAbsent$O$O(Integer.valueOf$I(id), Clazz.new_($I$(9,1)));
var map=this.linkerToSynthons.get$O(Integer.valueOf$I(id));
map.put$O$O(synthon, Clazz.array(Integer.TYPE, -1, [n, linkerEdge]));
}}
}
}
}, p$2);

Clazz.newMeth(C$, 'search$',  function () {
var hits=Clazz.new_($I$(11,1));
p$2.processFragments.apply(this, []);
for (var i=0; i < this.queryTree.getEdges$().size$(); i++) {
var querySourceTreeEdgeIndeces=Clazz.new_($I$(5,1));
var queryTargetTreeEdgeIndeces=Clazz.new_($I$(5,1));
var querySourceTreeEdgeParentIndeces=Clazz.new_($I$(5,1));
var queryTargetTreeEdgeParentIndeces=Clazz.new_($I$(5,1));
var headNodes=this.queryTree.initialCut$I$I$java_util_List$java_util_List$java_util_List$java_util_List(this.cuts[0], i, querySourceTreeEdgeIndeces, querySourceTreeEdgeParentIndeces, queryTargetTreeEdgeIndeces, queryTargetTreeEdgeParentIndeces);
for (var l, $l = this.linkerToSynthons.keySet$().iterator$(); $l.hasNext$()&&((l=($l.next$()).intValue$()),1);) {
var synthonID=(l & 56) >> 3;
var linkerID=l & 7;
for (var cutDirIndex=0; cutDirIndex < this.cuts.length; cutDirIndex++) {
var result=this.edgeLinkTable[(linkerID - 1) * this.synthonLib.getSynthons$().size$() + synthonID][2 * i + cutDirIndex];
if (result == null ) {
var querySubTreeEdgeIndeces;
var querySubTreeEdgeParentIndeces;
var queryCutDir;
var querySubTreeHeadNode;
if (this.cuts[cutDirIndex] == -1) {
querySubTreeEdgeIndeces=querySourceTreeEdgeIndeces;
querySubTreeEdgeParentIndeces=querySourceTreeEdgeParentIndeces;
queryCutDir=-1;
querySubTreeHeadNode=headNodes[0];
} else {
querySubTreeEdgeIndeces=queryTargetTreeEdgeIndeces;
querySubTreeEdgeParentIndeces=queryTargetTreeEdgeParentIndeces;
queryCutDir=1;
querySubTreeHeadNode=headNodes[1];
}result=Clazz.new_($I$(10,1));
var treeToLinkerHead=this.linkerToSynthons.get$O(Integer.valueOf$I(l));
for (var synthon, $synthon = treeToLinkerHead.keySet$().iterator$(); $synthon.hasNext$()&&((synthon=($synthon.next$())),1);) {
var matching=p$2.matchFragmentSubtree$com_actelion_research_chem_chemicalspaces_ptree_synthon_PharmTreeSynthon$java_util_Map$I$I$I$I$I$java_util_List$java_util_List.apply(this, [synthon, treeToLinkerHead, synthonID, linkerID, queryCutDir, querySubTreeHeadNode, i, querySubTreeEdgeIndeces, querySubTreeEdgeParentIndeces]);
if (matching.sim > (this.pTreeSimilarityCutoff - 0.3) ) {
result.addResult$com_actelion_research_chem_chemicalspaces_ptree_search_FragmentPTreeSearch_FragmentMatching(matching);
}}
if (result.getResults$().size$() > this.nBestSolutions) {
var prunedMatchings=result.getResults$().subList$I$I(0, this.nBestSolutions);
result.setResult$java_util_List(prunedMatchings);
}this.edgeLinkTable[(linkerID - 1) * this.synthonLib.getSynthons$().size$() + synthonID][2 * i + cutDirIndex]=result;
}}
}
}
this.getHits$java_util_LinkedHashMap(hits);
hits=hits.entrySet$().stream$().sorted$java_util_Comparator($I$(12).comparingByValue$().reversed$()).collect$java_util_stream_Collector($I$(13,"toMap$java_util_function_Function$java_util_function_Function$java_util_function_BinaryOperator$java_util_function_Supplier",[(function($$){((
(function(){/*m*/var C$=Clazz.newClass(P$, "FragmentPTreeSearch$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_M*/
Clazz.newMeth(C$, 'apply$O',  function (t) { return t.getKey$.apply(t,[])});
})()
)); return Clazz.new_(P$.FragmentPTreeSearch$lambda2.$init$,[this, null])})($I$(12)), (function($$){((
(function(){/*m*/var C$=Clazz.newClass(P$, "FragmentPTreeSearch$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_M*/
Clazz.newMeth(C$, 'apply$O',  function (t) { return t.getValue$.apply(t,[])});
})()
)); return Clazz.new_(P$.FragmentPTreeSearch$lambda3.$init$,[this, null])})($I$(12)), (P$.FragmentPTreeSearch$lambda4$||(P$.FragmentPTreeSearch$lambda4$=(((P$.FragmentPTreeSearch$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "FragmentPTreeSearch$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BinaryOperator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$Double$Double','apply$O$O'],  function (e1, e2) { return (e1);});
})()
), Clazz.new_(P$.FragmentPTreeSearch$lambda4.$init$,[this, null]))))), ((P$.FragmentPTreeSearch$lambda5||
(function(){/*m*/var C$=Clazz.newClass(P$, "FragmentPTreeSearch$lambda5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Supplier', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_C*/
Clazz.newMeth(C$, 'get$',  function () { return Clazz.new_($I$(11,1),[])});
})()
), Clazz.new_(P$.FragmentPTreeSearch$lambda5.$init$,[this, null]))]));
return hits;
});

Clazz.newMeth(C$, 'matchFragmentSubtree$com_actelion_research_chem_chemicalspaces_ptree_synthon_PharmTreeSynthon$java_util_Map$I$I$I$I$I$java_util_List$java_util_List',  function (synthon, treeToLinkerHead, synthonID, linkerID, queryCutDir, queryTreeHeadNode, queryCutEdge, querySubTreeEdgeIndeces, querySubTreeEdgeParentIndeces) {
var fragTreeHeadNode=treeToLinkerHead.get$O(synthon)[0];
var fragmentTreeEdgeIndeces=Clazz.new_($I$(5,1));
var fragmentTreeEdgeParentIndeces=Clazz.new_($I$(5,1));
var fragmentTree=synthon.getPharmTree$();
fragTreeHeadNode=p$2.processFragmentTree$I$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$java_util_List$java_util_List.apply(this, [fragTreeHeadNode, fragmentTree, fragmentTreeEdgeIndeces, fragmentTreeEdgeParentIndeces]);
var matchSearch;
matchSearch=Clazz.new_([this, this.queryTree, synthon, synthonID, linkerID, queryTreeHeadNode, fragTreeHeadNode, queryCutEdge, treeToLinkerHead.get$O(synthon)[1], queryCutDir, querySubTreeEdgeIndeces, fragmentTreeEdgeIndeces, querySubTreeEdgeParentIndeces, fragmentTreeEdgeParentIndeces],$I$(14,1).c$$com_actelion_research_chem_chemicalspaces_ptree_search_FragmentPTreeSearch$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$com_actelion_research_chem_chemicalspaces_ptree_synthon_PharmTreeSynthon$I$I$I$I$I$I$I$java_util_List$java_util_List$java_util_List$java_util_List);
return matchSearch.matchSearch$();
}, p$2);

Clazz.newMeth(C$, 'getHits$java_util_LinkedHashMap',  function (hits) {
var buffer=0.05;
for (var i=0; i < this.edgeLinkTable.length; i++) {
for (var j=0; j < this.edgeLinkTable[0].length; j++) {
var result=this.edgeLinkTable[i][j];
if (result == null ) continue;
var edge=(j/2|0);
var cutDirIndex=j % 2;
var solutions=p$2.constructSolutions$com_actelion_research_chem_chemicalspaces_ptree_search_FragmentPTreeSearch_SearchResult.apply(this, [result]);
var linkerID=((i/this.synthonLib.getSynthons$().size$()|0)) + 1;
var synthonID=i % this.synthonLib.getSynthons$().size$();
var compatibleCutDirIndex=cutDirIndex == 0 ? 1 : 0;
for (var k=0; k < this.synthonLib.getSynthons$().size$(); k++) {
if (k == synthonID) continue;
var id=(linkerID - 1) * this.synthonLib.getSynthons$().size$() + k;
var compatibleResult=this.edgeLinkTable[id][2 * edge + compatibleCutDirIndex];
if (compatibleResult == null ) continue;
var compatibleSolutions=p$2.constructSolutions$com_actelion_research_chem_chemicalspaces_ptree_search_FragmentPTreeSearch_SearchResult.apply(this, [compatibleResult]);
for (var solution1, $solution1 = solutions.iterator$(); $solution1.hasNext$()&&((solution1=($solution1.next$())),1);) {
var bestScore=0.0;
for (var solution2, $solution2 = compatibleSolutions.iterator$(); $solution2.hasNext$()&&((solution2=($solution2.next$())),1);) {
var combinedSolution=Clazz.new_($I$(5,1));
combinedSolution.addAll$java_util_Collection(solution1);
combinedSolution.addAll$java_util_Collection(solution2);
var sim=p$2.getTotalSimilarity$java_util_List.apply(this, [combinedSolution]);
if (sim < (this.pTreeSimilarityCutoff - 0.05) ) break;
 else {
var reactants=combinedSolution.stream$().map$java_util_function_Function(((P$.FragmentPTreeSearch$lambda6||
(function(){/*m*/var C$=Clazz.newClass(P$, "FragmentPTreeSearch$lambda6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$com_actelion_research_chem_chemicalspaces_ptree_search_FragmentPTreeSearch_FragmentMatching','apply$O'],  function (r) { return (r.synthon.getStructure$.apply(r.synthon, []));});
})()
), Clazz.new_(P$.FragmentPTreeSearch$lambda6.$init$,[this, null]))).collect$java_util_stream_Collector($I$(13).toList$());
if (reactants.size$() != this.synthonLib.getSynthons$().size$()) continue;
var product=$I$(15).react$java_util_List(reactants);
var accept=true;
if (accept) {
var resultString=Clazz.new_($I$(16,1));
resultString.append$S(product.getIDCode$());
resultString.append$S("____");
combinedSolution.stream$().forEach$java_util_function_Consumer(((P$.FragmentPTreeSearch$lambda7||
(function(){/*m*/var C$=Clazz.newClass(P$, "FragmentPTreeSearch$lambda7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_chemicalspaces_ptree_search_FragmentPTreeSearch_FragmentMatching','accept$O'],  function (r) {
this.$finals$.resultString.append$S.apply(this.$finals$.resultString, [r.synthon.getId$.apply(r.synthon, [])]);
this.$finals$.resultString.append$S.apply(this.$finals$.resultString, ["____"]);
});
})()
), Clazz.new_(P$.FragmentPTreeSearch$lambda7.$init$,[this, {resultString:resultString}])));
resultString.append$S(this.synthonLib.getReactionID$());
var rs=resultString.toString();
if (hits.containsKey$O(rs)) {
var oldSim=(hits.get$O(rs)).valueOf();
if (oldSim < sim ) hits.put$O$O(rs, Double.valueOf$D(sim));
} else {
hits.put$O$O(rs, Double.valueOf$D(sim));
}if (sim > bestScore ) {
bestScore=sim;
}}}}
}
}
}
}
});

Clazz.newMeth(C$, 'constructSolutions$com_actelion_research_chem_chemicalspaces_ptree_search_FragmentPTreeSearch_SearchResult',  function (result) {
var allSolutions=Clazz.new_($I$(5,1));
var matchings=result.getResults$();
for (var fm, $fm = matchings.iterator$(); $fm.hasNext$()&&((fm=($fm.next$())),1);) {
var solutionSet=Clazz.new_($I$(5,1));
var solution=Clazz.new_($I$(5,1));
solution.add$O(fm);
solutionSet.add$O(solution);
if (fm.getFurtherMatches$() != null ) {
var furtherMatches=fm.furtherMatchings;
for (var key, $key = furtherMatches.keySet$().iterator$(); $key.hasNext$()&&((key=($key.next$()).intValue$()),1);) {
var toBeDeleted=Clazz.new_($I$(5,1));
var toBeAdded=Clazz.new_($I$(5,1));
for (var oneSolution, $oneSolution = solutionSet.iterator$(); $oneSolution.hasNext$()&&((oneSolution=($oneSolution.next$())),1);) {
toBeDeleted.add$O(oneSolution);
for (var ffm, $ffm = furtherMatches.get$O(Integer.valueOf$I(key)).iterator$(); $ffm.hasNext$()&&((ffm=($ffm.next$())),1);) {
var newSolution=Clazz.new_($I$(5,1).c$$java_util_Collection,[oneSolution]);
newSolution.add$O(ffm);
toBeAdded.add$O(newSolution);
}
}
solutionSet.removeAll$java_util_Collection(toBeDeleted);
solutionSet.addAll$java_util_Collection(toBeAdded);
}
}allSolutions.addAll$java_util_Collection(solutionSet);
}
return allSolutions;
}, p$2);

Clazz.newMeth(C$, 'processFragmentTree$I$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$java_util_List$java_util_List',  function (linkerNode, fragmentTree, treeEdges, treeEdgeParents) {
var cutEdge=-1;
var headNode=-1;
for (var e=0; e < fragmentTree.getEdges$().size$(); e++) {
var edge=fragmentTree.getEdges$().get$I(e);
if (edge[0] == linkerNode) {
cutEdge=e;
headNode=edge[1];
break;
}if (edge[1] == linkerNode) {
cutEdge=e;
headNode=edge[0];
break;
}}
fragmentTree.treeWalkBFS$I$I$java_util_List$java_util_List(headNode, cutEdge, treeEdges, treeEdgeParents);
return headNode;
}, p$2);

Clazz.newMeth(C$, 'matchCompatibleFragments$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$I$I$I$I$I',  function (queryTree, querySubTreeHeadNode, querySubtreeCutEdge, querySubtreeCutEdgeDir, linkerID, fragmentID) {
var querySubTreeEdgeIndeces=Clazz.new_($I$(5,1));
var querySubTreeEdgeParentIndeces=Clazz.new_($I$(5,1));
queryTree.treeWalkBFS$I$I$java_util_List$java_util_List(querySubTreeHeadNode, querySubtreeCutEdge, querySubTreeEdgeIndeces, querySubTreeEdgeParentIndeces);
var allCompatibleMatchings=Clazz.new_($I$(5,1));
var cutDirIndex=querySubtreeCutEdgeDir == this.cuts[0] ? 0 : 1;
for (var i=0; i < this.synthonLib.getSynthons$().size$(); i++) {
var matchings=Clazz.new_($I$(5,1));
if (fragmentID == i) continue;
var index=(i << 3) + linkerID;
var compatibleTrees=this.linkerToSynthons.get$O(Integer.valueOf$I(index));
if (compatibleTrees == null ) continue;
var result=this.edgeLinkTable[(linkerID - 1) * this.synthonLib.getSynthons$().size$() + i][2 * querySubtreeCutEdge + cutDirIndex];
if (result != null ) matchings=result.getResults$();
 else {
for (var synthon, $synthon = compatibleTrees.keySet$().iterator$(); $synthon.hasNext$()&&((synthon=($synthon.next$())),1);) {
var fragTree=synthon.getPharmTree$();
var fragmentTreeEdgeIndeces=Clazz.new_($I$(5,1));
var fragmentTreeEdgeParentIndeces=Clazz.new_($I$(5,1));
var res=compatibleTrees.get$O(synthon);
var fragmentHeadLinkerNode=res[0];
var fragmentLinkerEdge=res[1];
var linkerEdge=fragTree.getEdges$().get$I(fragmentLinkerEdge);
var fragmentHeadNode=linkerEdge[0] == fragmentHeadLinkerNode ? linkerEdge[1] : linkerEdge[0];
fragTree.treeWalkBFS$I$I$java_util_List$java_util_List(fragmentHeadNode, fragmentLinkerEdge, fragmentTreeEdgeIndeces, fragmentTreeEdgeParentIndeces);
var fms=Clazz.new_($I$(14,1).c$$com_actelion_research_chem_chemicalspaces_ptree_search_FragmentPTreeSearch$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$com_actelion_research_chem_chemicalspaces_ptree_synthon_PharmTreeSynthon$I$I$I$I$I$I$I$java_util_List$java_util_List$java_util_List$java_util_List,[this, queryTree, synthon, i, linkerID, querySubTreeHeadNode, fragmentHeadNode, querySubtreeCutEdge, fragmentLinkerEdge, querySubtreeCutEdgeDir, querySubTreeEdgeIndeces, fragmentTreeEdgeIndeces, querySubTreeEdgeParentIndeces, fragmentTreeEdgeParentIndeces]);
var matching=fms.matchSearch$();
matching.calculate$();
matchings.add$O(matching);
}
matchings.sort$java_util_Comparator((P$.FragmentPTreeSearch$lambda8$||(P$.FragmentPTreeSearch$lambda8$=(((P$.FragmentPTreeSearch$lambda8||
(function(){/*m*/var C$=Clazz.newClass(P$, "FragmentPTreeSearch$lambda8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['compare$com_actelion_research_chem_chemicalspaces_ptree_search_FragmentPTreeSearch_FragmentMatching$com_actelion_research_chem_chemicalspaces_ptree_search_FragmentPTreeSearch_FragmentMatching','compare$O$O'],  function (e1, e2) {
return Double.compare$D$D(e2.sim, e1.sim);
});
})()
), Clazz.new_(P$.FragmentPTreeSearch$lambda8.$init$,[this, null]))))));
if (matchings.size$() > this.nBestSolutions) matchings=matchings.subList$I$I(0, this.nBestSolutions);
var sr=Clazz.new_($I$(10,1));
sr.setResult$java_util_List(matchings);
this.edgeLinkTable[(linkerID - 1) * this.synthonLib.getSynthons$().size$() + i][2 * querySubtreeCutEdge + cutDirIndex]=sr;
}allCompatibleMatchings.addAll$java_util_Collection(matchings);
}
return allCompatibleMatchings;
}, p$2);

Clazz.newMeth(C$, 'getTotalSimilarity$java_util_List',  function (matchings) {
var sim=0.0;
var size1=0.0;
var size2=0.0;
for (var matching, $matching = matchings.iterator$(); $matching.hasNext$()&&((matching=($matching.next$())),1);) {
for (var match, $match = matching.getTreeMatching$().getMatches$().iterator$(); $match.hasNext$()&&((match=($match.next$())),1);) {
var sizes=match.getSizes$();
var s=match.getSim$();
sim+=(sizes[0] + sizes[1]) * s;
size1+=sizes[0];
size2+=sizes[1];
}
}
return 0.5 * sim / ((0.5 * Math.max(size1, size2) + (0.5) * Math.min(size1, size2)));
}, p$2);
;
(function(){/*c*/var C$=Clazz.newClass(P$.FragmentPTreeSearch, "FragmentMatchSearch", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['fragmentTreeSynthonID','fragmentTreeLinkerID','queryTreeHeadNode','cutEdgeQueryTree','cutEdgeFragmentTree','cutDirQueryTree','cutDirFragmentTree','fragTreeHeadNode'],'O',['queryTree','com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreTree','+fragmentTree','synthon','com.actelion.research.chem.chemicalspaces.ptree.synthon.PharmTreeSynthon','querySubTreeEdgeIndeces','java.util.List','+querySubTreeEdgeParentIndeces','+fragTreeEdgeIndeces','+fragTreeEdgeParentIndeces','dpMatchMatrix','com.actelion.research.chem.descriptor.pharmacophoretree.TreeMatcher.TreeMatching[][]','pTreeSearch','com.actelion.research.chem.chemicalspaces.ptree.search.FragmentPTreeSearch','queryNodes','java.util.List','+fragmentNodes']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_chemicalspaces_ptree_search_FragmentPTreeSearch$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$com_actelion_research_chem_chemicalspaces_ptree_synthon_PharmTreeSynthon$I$I$I$I$I$I$I$java_util_List$java_util_List$java_util_List$java_util_List',  function (pTreeSearch, queryTree, synthon, fragmentTreeSynthonID, fragmentTreeLinkerID, queryTreeHeadNode, fragTreeHeadNode, cutEdgeQueryTree, cutEdgeFragmentTree, cutDirQueryTree, querySubTreeEdgeIndeces, fragTreeEdgeIndeces, querySubTreeEdgeParentIndeces, fragTreeEdgeParentIndeces) {
;C$.$init$.apply(this);
this.queryTree=queryTree;
this.synthon=synthon;
this.queryTreeHeadNode=queryTreeHeadNode;
this.cutEdgeQueryTree=cutEdgeQueryTree;
this.cutEdgeFragmentTree=cutEdgeFragmentTree;
this.cutDirQueryTree=cutDirQueryTree;
this.querySubTreeEdgeIndeces=querySubTreeEdgeIndeces;
this.querySubTreeEdgeParentIndeces=querySubTreeEdgeParentIndeces;
this.fragTreeHeadNode=fragTreeHeadNode;
this.fragTreeEdgeIndeces=fragTreeEdgeIndeces;
this.fragTreeEdgeParentIndeces=fragTreeEdgeParentIndeces;
this.fragmentTreeSynthonID=fragmentTreeSynthonID;
this.fragmentTreeLinkerID=fragmentTreeLinkerID;
this.pTreeSearch=pTreeSearch;
this.queryNodes=queryTree.getNodes$();
this.fragmentTree=synthon.getPharmTree$();
this.fragmentNodes=this.fragmentTree.getNodes$();
if (this.fragmentTree.getEdges$().get$I(cutEdgeFragmentTree)[1] == fragTreeHeadNode) this.cutDirFragmentTree=1;
 else this.cutDirFragmentTree=-1;
this.dpMatchMatrix=Clazz.array($I$(1), [2 * queryTree.getEdges$().size$(), 2 * this.fragmentTree.getEdges$().size$()]);
}, 1);

Clazz.newMeth(C$, 'matchSearch$',  function () {
return p$1.recMatchSearch$I$I$I$I$I$I$java_util_List$java_util_List$java_util_List$java_util_List.apply(this, [this.queryTreeHeadNode, this.fragTreeHeadNode, this.cutEdgeQueryTree, this.cutEdgeFragmentTree, this.cutDirQueryTree, this.cutDirFragmentTree, this.querySubTreeEdgeIndeces, this.fragTreeEdgeIndeces, this.querySubTreeEdgeParentIndeces, this.fragTreeEdgeParentIndeces]);
});

Clazz.newMeth(C$, 'recMatchSearch$I$I$I$I$I$I$java_util_List$java_util_List$java_util_List$java_util_List',  function (headNode1, headNode2, cutEdge1, cutEdge2, cutDir1, cutDir2, subTreeEdgeIndeces1, subTreeEdgeIndeces2, subTreeEdgeParentIndeces1, subTreeEdgeParentIndeces2) {
var treeMatching=Clazz.new_($I$(1,1));
var fragmentMatching=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_chemicalspaces_ptree_synthon_PharmTreeSynthon$I$I,[this.synthon, this.fragmentTreeSynthonID, this.fragmentTreeLinkerID]);
var index1=cutDir1 == -1 ? cutEdge1 * 2 : cutEdge1 * 2 + 1;
var index2=cutDir2 == -1 ? cutEdge2 * 2 : cutEdge2 * 2 + 1;
var nodes1=this.queryTree.getNodesFromEdges$java_util_List(subTreeEdgeIndeces1);
nodes1.add$O(Integer.valueOf$I(headNode1));
var nodes2=this.fragmentTree.getNodesFromEdges$java_util_List(subTreeEdgeIndeces2);
nodes2.add$O(Integer.valueOf$I(headNode2));
if (this.fragmentTree.getNodes$().get$I(headNode2).isLinkNode$() && nodes2.size$() == 1 ) {
var linkerID=this.fragmentTree.getNodes$().get$I(headNode2).getFunctionalities$()[0];
var matchings=p$2.matchCompatibleFragments$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$I$I$I$I$I.apply(this.pTreeSearch, [this.queryTree, headNode1, cutEdge1, cutDir1, linkerID, this.fragmentTreeSynthonID]);
fragmentMatching.setTreeMatching$com_actelion_research_chem_descriptor_pharmacophoretree_TreeMatcher_TreeMatching(treeMatching);
fragmentMatching.addFurtherMatches$I$java_util_List(linkerID, matchings);
} else {
if (this.dpMatchMatrix[index1][index2] != null ) {
treeMatching=this.dpMatchMatrix[index1][index2];
fragmentMatching.setTreeMatching$com_actelion_research_chem_descriptor_pharmacophoretree_TreeMatcher_TreeMatching(treeMatching);
} else {
var matches=p$1.assessMatch$java_util_Set$java_util_Set.apply(this, [nodes1, nodes2]);
if (matches != null ) {
treeMatching=Clazz.new_($I$(1,1));
for (var fmatch, $fmatch = matches.iterator$(); $fmatch.hasNext$()&&((fmatch=($fmatch.next$())),1);) treeMatching.addFeatureMatch$com_actelion_research_chem_descriptor_pharmacophoretree_TreeMatcher_FeatureMatch(fmatch);

treeMatching.calculate$();
this.dpMatchMatrix[index1][index2]=treeMatching;
fragmentMatching.setTreeMatching$com_actelion_research_chem_descriptor_pharmacophoretree_TreeMatcher_TreeMatching(treeMatching);
} else {
var cuts1=this.queryTree.getExtensionCuts$java_util_List$java_util_List(subTreeEdgeIndeces1, subTreeEdgeParentIndeces1);
var cuts2=this.fragmentTree.getExtensionCuts$java_util_List$java_util_List(subTreeEdgeIndeces2, subTreeEdgeParentIndeces2);
var scores=Clazz.array(Double.TYPE, [cuts1.size$(), cuts2.size$()]);
for (var i=0; i < cuts1.size$(); i++) {
var cut1=cuts1.get$I(i);
var extensionNodes1=Clazz.new_($I$(3,1));
var sourceNodes1=Clazz.new_($I$(3,1));
this.queryTree.enumerateExtensionCutFast$I$IA$java_util_List$java_util_Set$java_util_Set(headNode1, cut1, subTreeEdgeIndeces1, extensionNodes1, sourceNodes1);
for (var j=0; j < cuts2.size$(); j++) {
var cut2=cuts2.get$I(j);
var extensionNodes2=Clazz.new_($I$(3,1));
var sourceNodes2=Clazz.new_($I$(3,1));
this.fragmentTree.enumerateExtensionCutFast$I$IA$java_util_List$java_util_Set$java_util_Set(headNode2, cut2, subTreeEdgeIndeces2, extensionNodes2, sourceNodes2);
scores[i][j]=p$1.scoreExtensionMatch$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$java_util_Set$java_util_Set$java_util_Set$java_util_Set.apply(this, [this.queryTree, this.fragmentTree, extensionNodes1, extensionNodes2, sourceNodes1, sourceNodes2]);
}
}
var bestCuts=Clazz.array(Integer.TYPE, [cuts1.size$() * cuts2.size$(), 2]);
var bestScores=Clazz.array(Double.TYPE, [cuts1.size$() * cuts2.size$()]);
$I$(4).retrieveHighestValuesFrom2DArray$DAA$DA$IAA(scores, bestScores, bestCuts);
var bestScore=-1.7976931348623157E308;
var bestMatching=null;
var counter=0;
for (var cut, $cut = 0, $$cut = bestCuts; $cut<$$cut.length&&((cut=($$cut[$cut])),1);$cut++) {
if (counter > 3) break;
if (cut[0] == -1 || cut[1] == -1 ) continue;
var cut1=cuts1.get$I(cut[0]);
var cut2=cuts2.get$I(cut[1]);
var sourceTreeEdgeIndeces1=Clazz.new_($I$(5,1));
var sourceTreeEdgeParentIndeces1=Clazz.new_($I$(5,1));
var sourceTreeHeadNodes1=Clazz.new_($I$(5,1));
var extensionNodes1=Clazz.new_($I$(3,1));
var cutEdges1=Clazz.new_($I$(5,1));
var cutDirs1=Clazz.new_($I$(5,1));
this.queryTree.enumerateExtensionCutFull$I$IA$java_util_List$java_util_List$java_util_List$java_util_List$java_util_List$java_util_Set$java_util_List$java_util_List(headNode1, cut1, subTreeEdgeIndeces1, subTreeEdgeParentIndeces1, sourceTreeEdgeIndeces1, sourceTreeEdgeParentIndeces1, sourceTreeHeadNodes1, extensionNodes1, cutEdges1, cutDirs1);
var sourceTreeEdgeIndeces2=Clazz.new_($I$(5,1));
var sourceTreeEdgeParentIndeces2=Clazz.new_($I$(5,1));
var sourceTreeHeadNodes2=Clazz.new_($I$(5,1));
var extensionNodes2=Clazz.new_($I$(3,1));
var cutEdges2=Clazz.new_($I$(5,1));
var cutDirs2=Clazz.new_($I$(5,1));
this.fragmentTree.enumerateExtensionCutFull$I$IA$java_util_List$java_util_List$java_util_List$java_util_List$java_util_List$java_util_Set$java_util_List$java_util_List(headNode2, cut2, subTreeEdgeIndeces2, subTreeEdgeParentIndeces2, sourceTreeEdgeIndeces2, sourceTreeEdgeParentIndeces2, sourceTreeHeadNodes2, extensionNodes2, cutEdges2, cutDirs2);
var extensionMatch=p$1.assessExtensionMatch$java_util_Set$java_util_Set.apply(this, [extensionNodes1, extensionNodes2]);
if (extensionMatch == null ) continue;
++counter;
var sourceTreeMatches=Clazz.array($I$(2), [sourceTreeHeadNodes1.size$(), sourceTreeHeadNodes2.size$()]);
var sourceTreeScores=Clazz.array(Double.TYPE, [sourceTreeHeadNodes1.size$(), sourceTreeHeadNodes2.size$()]);
for (var i=0; i < sourceTreeHeadNodes1.size$(); i++) {
for (var j=0; j < sourceTreeHeadNodes2.size$(); j++) {
var m=p$1.recMatchSearch$I$I$I$I$I$I$java_util_List$java_util_List$java_util_List$java_util_List.apply(this, [(sourceTreeHeadNodes1.get$I(i)).$c(), (sourceTreeHeadNodes2.get$I(j)).$c(), (cutEdges1.get$I(i)).$c(), (cutEdges2.get$I(j)).$c(), (cutDirs1.get$I(i)).$c(), (cutDirs2.get$I(j)).$c(), sourceTreeEdgeIndeces1.get$I(i), sourceTreeEdgeIndeces2.get$I(j), sourceTreeEdgeParentIndeces1.get$I(i), sourceTreeEdgeParentIndeces2.get$I(j)]);
sourceTreeMatches[i][j]=m;
sourceTreeScores[i][j]=m.sim;
}
}
var assignment=Clazz.array(Integer.TYPE, [0, 0]);
var transpose=false;
if (sourceTreeScores.length > 0 && sourceTreeScores[0].length > 0 ) {
if (sourceTreeScores.length > sourceTreeScores[0].length) {
sourceTreeScores=$I$(6).transpose$DAA(sourceTreeScores);
transpose=true;
}if (sourceTreeScores.length > 0 && sourceTreeScores[0].length > 0 ) ;assignment=$I$(6).hgAlgorithm$DAA$S(sourceTreeScores, "max");
if (transpose) {
sourceTreeScores=$I$(6).transpose$DAA(sourceTreeScores);
for (var a=0; a < assignment.length; a++) {
var pair=assignment[a];
var ele=pair[0];
pair[0]=pair[1];
pair[1]=ele;
}
}}var matchedSourceTrees1=Clazz.new_($I$(3,1));
var matchedSourceTrees2=Clazz.new_($I$(3,1));
var extensionMatching=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_chemicalspaces_ptree_synthon_PharmTreeSynthon$I$I,[this.synthon, this.fragmentTreeSynthonID, this.fragmentTreeLinkerID]);
var extensionTreeMatching=Clazz.new_($I$(1,1));
extensionMatching.setTreeMatching$com_actelion_research_chem_descriptor_pharmacophoretree_TreeMatcher_TreeMatching(extensionTreeMatching);
extensionTreeMatching.addFeatureMatch$com_actelion_research_chem_descriptor_pharmacophoretree_TreeMatcher_FeatureMatch(extensionMatch);
for (var i=0; i < assignment.length; i++) {
matchedSourceTrees1.add$O(Integer.valueOf$I(assignment[i][0]));
matchedSourceTrees2.add$O(Integer.valueOf$I(assignment[i][1]));
extensionMatching.addFragmentMatch$com_actelion_research_chem_chemicalspaces_ptree_search_FragmentPTreeSearch_FragmentMatching(sourceTreeMatches[assignment[i][0]][assignment[i][1]]);
}
for (var i=0; i < sourceTreeHeadNodes1.size$(); i++) {
if (!matchedSourceTrees1.contains$O(Integer.valueOf$I(i))) {
var nullMatch=p$1.getMatch$I$java_util_List$I$java_util_List.apply(this, [(sourceTreeHeadNodes1.get$I(i)).$c(), sourceTreeEdgeIndeces1.get$I(i), -1, Clazz.new_($I$(5,1))]);
extensionTreeMatching.addFeatureMatch$com_actelion_research_chem_descriptor_pharmacophoretree_TreeMatcher_FeatureMatch(nullMatch);
}}
for (var j=0; j < sourceTreeHeadNodes2.size$(); j++) {
if (!matchedSourceTrees2.contains$O(Integer.valueOf$I(j))) {
var nullMatch=p$1.getMatch$I$java_util_List$I$java_util_List.apply(this, [-1, Clazz.new_($I$(5,1)), (sourceTreeHeadNodes2.get$I(j)).$c(), sourceTreeEdgeIndeces2.get$I(j)]);
extensionTreeMatching.addFeatureMatch$com_actelion_research_chem_descriptor_pharmacophoretree_TreeMatcher_FeatureMatch(nullMatch);
}}
extensionTreeMatching.calculate$();
extensionMatching.calculate$();
var extensionScore=extensionMatching.sim;
if (extensionScore >= bestScore ) {
bestScore=extensionScore;
bestMatching=extensionMatching;
}}
fragmentMatching=bestMatching;
}}}fragmentMatching.calculate$();
return fragmentMatching;
}, p$1);

Clazz.newMeth(C$, 'assessMatch$java_util_Set$java_util_Set',  function (nodes1, nodes2) {
var matches=null;
var size1=C$.getSizeOfNodeSet$java_util_Set$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree(nodes1, this.queryTree);
var size2=C$.getSizeOfNodeSet$java_util_Set$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree(nodes2, this.fragmentTree);
var balanced=C$.isMatchBalanced$D$D(size1, size2);
var containsLinkNodes=false;
for (var n, $n = nodes2.iterator$(); $n.hasNext$()&&((n=($n.next$()).intValue$()),1);) {
if (this.fragmentTree.getNodes$().get$I(n).isLinkNode$()) {
containsLinkNodes=true;
break;
}}
if (!containsLinkNodes) {
if ((size1 < 3.0  || size2 < 3.0  ) || (nodes1.size$() < 2 || nodes2.size$() < 2 ) ) {
if (balanced) {
matches=Clazz.new_($I$(5,1));
matches.add$O(p$1.getMatch$java_util_Set$java_util_Set.apply(this, [nodes1, nodes2]));
} else {
matches=Clazz.new_($I$(5,1));
matches.add$O(p$1.getMatch$java_util_Set$java_util_Set.apply(this, [nodes1, Clazz.new_($I$(3,1))]));
matches.add$O(p$1.getMatch$java_util_Set$java_util_Set.apply(this, [Clazz.new_($I$(3,1)), nodes2]));
}}}return matches;
}, p$1);

Clazz.newMeth(C$, 'assessExtensionMatch$java_util_Set$java_util_Set',  function (nodes1, nodes2) {
var match=null;
var size1;
var size2;
size1=C$.getSizeOfNodeSet$java_util_Set$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree(nodes1, this.queryTree);
size2=C$.getSizeOfNodeSet$java_util_Set$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree(nodes2, this.fragmentTree);
var containsLinkNodes=false;
for (var n, $n = nodes2.iterator$(); $n.hasNext$()&&((n=($n.next$()).intValue$()),1);) {
if (this.fragmentTree.getNodes$().get$I(n).isLinkNode$()) {
containsLinkNodes=true;
break;
}}
if (!containsLinkNodes) {
if (nodes1.size$() != 0 && nodes2.size$() != 0 ) {
if ((size1 < 3.0  || size2 < 3.0  ) || (nodes1.size$() < 2 || nodes2.size$() < 2 ) ) {
match=p$1.getMatch$java_util_Set$java_util_Set.apply(this, [nodes1, nodes2]);
}}}return match;
}, p$1);

Clazz.newMeth(C$, 'getMatch$I$java_util_List$I$java_util_List',  function (headNode1, subTreeEdgeIndeces1, headNode2, subTreeEdgeIndeces2) {
var m=null;
var match=Clazz.array(Integer.TYPE, [2, null]);
if (headNode1 == -1) {
var nodes2=this.fragmentTree.getNodesFromEdges$java_util_List(subTreeEdgeIndeces2);
nodes2.add$O(Integer.valueOf$I(headNode2));
match[0]=Clazz.array(Integer.TYPE, [0]);
match[1]=nodes2.stream$().mapToInt$java_util_function_ToIntFunction((P$.FragmentPTreeSearch$FragmentMatchSearch$lambda1$||(P$.FragmentPTreeSearch$FragmentMatchSearch$lambda1$=(((P$.FragmentPTreeSearch$FragmentMatchSearch$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "FragmentPTreeSearch$FragmentMatchSearch$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToIntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$Integer','applyAsInt$O'],  function (x) { return (x);});
})()
), Clazz.new_(P$.FragmentPTreeSearch$FragmentMatchSearch$lambda1.$init$,[this, null])))))).toArray$();
m=Clazz.new_($I$(7,1).c$$IAA,[match]);
m.calculate$java_util_List$java_util_List(this.queryNodes, this.fragmentNodes);
} else if (headNode2 == -1) {
var nodes1=this.queryTree.getNodesFromEdges$java_util_List(subTreeEdgeIndeces1);
nodes1.add$O(Integer.valueOf$I(headNode1));
match[1]=Clazz.array(Integer.TYPE, [0]);
match[0]=nodes1.stream$().mapToInt$java_util_function_ToIntFunction((P$.FragmentPTreeSearch$FragmentMatchSearch$lambda2$||(P$.FragmentPTreeSearch$FragmentMatchSearch$lambda2$=(((P$.FragmentPTreeSearch$FragmentMatchSearch$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "FragmentPTreeSearch$FragmentMatchSearch$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToIntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$Integer','applyAsInt$O'],  function (x) { return (x);});
})()
), Clazz.new_(P$.FragmentPTreeSearch$FragmentMatchSearch$lambda2.$init$,[this, null])))))).toArray$();
m=Clazz.new_($I$(7,1).c$$IAA,[match]);
m.calculate$java_util_List$java_util_List(this.queryNodes, this.fragmentNodes);
} else {
var nodes1=this.queryTree.getNodesFromEdges$java_util_List(subTreeEdgeIndeces1);
nodes1.add$O(Integer.valueOf$I(headNode1));
var nodes2=this.fragmentTree.getNodesFromEdges$java_util_List(subTreeEdgeIndeces2);
nodes2.add$O(Integer.valueOf$I(headNode2));
match[0]=nodes1.stream$().mapToInt$java_util_function_ToIntFunction((P$.FragmentPTreeSearch$FragmentMatchSearch$lambda3$||(P$.FragmentPTreeSearch$FragmentMatchSearch$lambda3$=(((P$.FragmentPTreeSearch$FragmentMatchSearch$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "FragmentPTreeSearch$FragmentMatchSearch$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToIntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$Integer','applyAsInt$O'],  function (x) { return (x);});
})()
), Clazz.new_(P$.FragmentPTreeSearch$FragmentMatchSearch$lambda3.$init$,[this, null])))))).toArray$();
match[1]=nodes2.stream$().mapToInt$java_util_function_ToIntFunction((P$.FragmentPTreeSearch$FragmentMatchSearch$lambda4$||(P$.FragmentPTreeSearch$FragmentMatchSearch$lambda4$=(((P$.FragmentPTreeSearch$FragmentMatchSearch$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "FragmentPTreeSearch$FragmentMatchSearch$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToIntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$Integer','applyAsInt$O'],  function (x) { return (x);});
})()
), Clazz.new_(P$.FragmentPTreeSearch$FragmentMatchSearch$lambda4.$init$,[this, null])))))).toArray$();
m=Clazz.new_($I$(7,1).c$$IAA,[match]);
m.calculate$java_util_List$java_util_List(this.queryNodes, this.fragmentNodes);
}return m;
}, p$1);

Clazz.newMeth(C$, 'getMatch$java_util_Set$java_util_Set',  function (nodes1, nodes2) {
var m=null;
var match=Clazz.array(Integer.TYPE, [2, null]);
match[0]=nodes1.stream$().mapToInt$java_util_function_ToIntFunction((P$.FragmentPTreeSearch$FragmentMatchSearch$lambda5$||(P$.FragmentPTreeSearch$FragmentMatchSearch$lambda5$=(((P$.FragmentPTreeSearch$FragmentMatchSearch$lambda5||
(function(){/*m*/var C$=Clazz.newClass(P$, "FragmentPTreeSearch$FragmentMatchSearch$lambda5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToIntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$Integer','applyAsInt$O'],  function (x) { return (x);});
})()
), Clazz.new_(P$.FragmentPTreeSearch$FragmentMatchSearch$lambda5.$init$,[this, null])))))).toArray$();
match[1]=nodes2.stream$().mapToInt$java_util_function_ToIntFunction((P$.FragmentPTreeSearch$FragmentMatchSearch$lambda6$||(P$.FragmentPTreeSearch$FragmentMatchSearch$lambda6$=(((P$.FragmentPTreeSearch$FragmentMatchSearch$lambda6||
(function(){/*m*/var C$=Clazz.newClass(P$, "FragmentPTreeSearch$FragmentMatchSearch$lambda6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToIntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$Integer','applyAsInt$O'],  function (x) { return (x);});
})()
), Clazz.new_(P$.FragmentPTreeSearch$FragmentMatchSearch$lambda6.$init$,[this, null])))))).toArray$();
m=Clazz.new_($I$(7,1).c$$IAA,[match]);
m.calculate$java_util_List$java_util_List(this.queryNodes, this.fragmentNodes);
return m;
}, p$1);

Clazz.newMeth(C$, 'scoreExtensionMatch$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$java_util_Set$java_util_Set$java_util_Set$java_util_Set',  function (pTree1, pTree2, extensionNodes1, extensionNodes2, sourceNodes1, sourceNodes2) {
var extensionScore=0.0;
var sourceScore=0.0;
extensionScore=$I$(8).getSimilarity$java_util_Collection$java_util_Collection$java_util_List$java_util_List(extensionNodes1, extensionNodes2, this.queryNodes, this.fragmentNodes);
sourceScore=$I$(8).getSimilarity$java_util_Collection$java_util_Collection$java_util_List$java_util_List(sourceNodes1, sourceNodes2, this.queryNodes, this.fragmentNodes);
return 0.8 * extensionScore + (0.19999999999999996) * sourceScore;
}, p$1);

Clazz.newMeth(C$, 'isMatchBalanced$D$D',  function (size1, size2) {
var isBalanced=true;
var ratio=size1 / size2;
if (ratio > 2.0  || ratio < 0.5  ) isBalanced=false;
return isBalanced;
}, 1);

Clazz.newMeth(C$, 'getSizeOfNodeSet$java_util_Set$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree',  function (nodes, pTree) {
var size=0;
var n=pTree.getNodes$java_util_Collection(nodes);
for (var node, $node = n.iterator$(); $node.hasNext$()&&((node=($node.next$())),1);) size+=node.getSize$();

return size;
}, 1);

Clazz.newMeth(C$, 'getFunctionalitiesOfNodeSet$java_util_Set$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree',  function (nodes, pTree) {
var functionalities=Clazz.array(Integer.TYPE, [$I$(8).FUNCTIONALITY_WEIGHTS.length]);
var n=pTree.getNodes$java_util_Collection(nodes);
for (var node, $node = n.iterator$(); $node.hasNext$()&&((node=($node.next$())),1);) {
var functionalities2=node.getFunctionalities$();
for (var i=0; i < functionalities.length; i++) functionalities[i]+=functionalities2[i];

}
return functionalities;
}, 1);

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.FragmentPTreeSearch, "FragmentMatching", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['sim','size1','size2'],'I',['fragmentSynthonID','fragmentLinkerID'],'O',['synthon','com.actelion.research.chem.chemicalspaces.ptree.synthon.PharmTreeSynthon','treeMatching','com.actelion.research.chem.descriptor.pharmacophoretree.TreeMatcher.TreeMatching','furtherMatchings','java.util.Map']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_chemicalspaces_ptree_synthon_PharmTreeSynthon$I$I',  function (synthon, synthonID, linkerID) {
;C$.$init$.apply(this);
this.synthon=synthon;
this.fragmentSynthonID=synthonID;
this.fragmentLinkerID=linkerID;
this.furtherMatchings=Clazz.new_($I$(9,1));
}, 1);

Clazz.newMeth(C$, 'addFragmentMatch$com_actelion_research_chem_chemicalspaces_ptree_search_FragmentPTreeSearch_FragmentMatching',  function (fragmentMatching) {
if (fragmentMatching.treeMatching != null ) this.treeMatching.addMatching$com_actelion_research_chem_descriptor_pharmacophoretree_TreeMatcher_TreeMatching(fragmentMatching.treeMatching);
if (fragmentMatching.furtherMatchings != null ) {
fragmentMatching.furtherMatchings.forEach$java_util_function_BiConsumer(((P$.FragmentPTreeSearch$FragmentMatching$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "FragmentPTreeSearch$FragmentMatching$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$Integer$java_util_List','accept$O$O'],  function (key, value) { return (this.b$['com.actelion.research.chem.chemicalspaces.ptree.search.FragmentPTreeSearch.FragmentMatching'].furtherMatchings.merge$O$O$java_util_function_BiFunction.apply(this.b$['com.actelion.research.chem.chemicalspaces.ptree.search.FragmentPTreeSearch.FragmentMatching'].furtherMatchings, [key, value, ((P$.FragmentPTreeSearch$FragmentMatching$lambda1$2||
(function(){/*m*/var C$=Clazz.newClass(P$, "FragmentPTreeSearch$FragmentMatching$lambda1$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$java_util_List$java_util_List','apply$O$O'],  function (v1, v2) {
v1.addAll$java_util_Collection.apply(v1, [v2]);
return v1;
});
})()
), Clazz.new_(P$.FragmentPTreeSearch$FragmentMatching$lambda1$2.$init$,[this, null]))]));});
})()
), Clazz.new_(P$.FragmentPTreeSearch$FragmentMatching$lambda1.$init$,[this, null])));
}});

Clazz.newMeth(C$, 'setTreeMatching$com_actelion_research_chem_descriptor_pharmacophoretree_TreeMatcher_TreeMatching',  function (treeMatching) {
this.treeMatching=treeMatching;
});

Clazz.newMeth(C$, 'getTreeMatching$',  function () {
return this.treeMatching;
});

Clazz.newMeth(C$, 'addFurtherMatch$I$com_actelion_research_chem_chemicalspaces_ptree_search_FragmentPTreeSearch_FragmentMatching',  function (linkerID, fragmentMatching) {
this.furtherMatchings.putIfAbsent$O$O(Integer.valueOf$I(linkerID), Clazz.new_($I$(5,1)));
this.furtherMatchings.get$O(Integer.valueOf$I(linkerID)).add$O(fragmentMatching);
});

Clazz.newMeth(C$, 'addFurtherMatches$I$java_util_List',  function (linkerID, fragmentMatchings) {
this.furtherMatchings.putIfAbsent$O$O(Integer.valueOf$I(linkerID), Clazz.new_($I$(5,1)));
this.furtherMatchings.get$O(Integer.valueOf$I(linkerID)).addAll$java_util_Collection(fragmentMatchings);
});

Clazz.newMeth(C$, 'getFurtherMatches$',  function () {
return this.furtherMatchings;
});

Clazz.newMeth(C$, 'getFragmentLinkerID$',  function () {
return this.fragmentLinkerID;
});

Clazz.newMeth(C$, 'getFragmentSynthonID$',  function () {
return this.fragmentSynthonID;
});

Clazz.newMeth(C$, 'getFragmentPTree$',  function () {
return this.synthon;
});

Clazz.newMeth(C$, 'calculate$',  function () {
if (this.furtherMatchings.keySet$().size$() == 0) {
this.sim=this.treeMatching.getSim$();
this.size1=this.treeMatching.getSize1$();
this.size2=this.treeMatching.getSize2$();
} else {
this.sim=0.0;
this.size1=0.0;
this.size2=0.0;
for (var match, $match = this.treeMatching.getMatches$().iterator$(); $match.hasNext$()&&((match=($match.next$())),1);) {
var sizes=match.getSizes$();
var s=match.getSim$();
this.sim+=(sizes[0] + sizes[1]) * s;
this.size1+=sizes[0];
this.size2+=sizes[1];
}
for (var linkerID, $linkerID = this.furtherMatchings.keySet$().iterator$(); $linkerID.hasNext$()&&((linkerID=($linkerID.next$()).intValue$()),1);) {
if (this.furtherMatchings.get$O(Integer.valueOf$I(linkerID)).size$() == 0) continue;
var furtherMatch=this.furtherMatchings.get$O(Integer.valueOf$I(linkerID)).get$I(0);
for (var match, $match = furtherMatch.treeMatching.getMatches$().iterator$(); $match.hasNext$()&&((match=($match.next$())),1);) {
var sizes=match.getSizes$();
var s=match.getSim$();
this.sim+=(sizes[0] + sizes[1]) * s;
this.size1+=sizes[0];
this.size2+=sizes[1];
}
}
this.sim=0.5 * this.sim / ((0.5 * Math.max(this.size1, this.size2) + (0.5) * Math.min(this.size1, this.size2)));
if (this.size1 == 0  && this.size2 == 0  ) this.sim=0.0;
}});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.FragmentPTreeSearch, "SearchResult", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['results','java.util.List']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.results=Clazz.new_($I$(5,1));
}, 1);

Clazz.newMeth(C$, 'getResults$',  function () {
return this.results;
});

Clazz.newMeth(C$, 'setResult$java_util_List',  function (results) {
this.results=results;
});

Clazz.newMeth(C$, 'getResult$I',  function (index) {
return this.results.get$I(index);
});

Clazz.newMeth(C$, 'addResult$java_util_List',  function (results) {
this.results.addAll$java_util_Collection(results);
this.results.sort$java_util_Comparator((P$.FragmentPTreeSearch$SearchResult$lambda1$||(P$.FragmentPTreeSearch$SearchResult$lambda1$=(((P$.FragmentPTreeSearch$SearchResult$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "FragmentPTreeSearch$SearchResult$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['compare$com_actelion_research_chem_chemicalspaces_ptree_search_FragmentPTreeSearch_FragmentMatching$com_actelion_research_chem_chemicalspaces_ptree_search_FragmentPTreeSearch_FragmentMatching','compare$O$O'],  function (c1, c2) {
return Double.compare$D$D(c2.sim, c1.sim);
});
})()
), Clazz.new_(P$.FragmentPTreeSearch$SearchResult$lambda1.$init$,[this, null]))))));
});

Clazz.newMeth(C$, 'addResult$com_actelion_research_chem_chemicalspaces_ptree_search_FragmentPTreeSearch_FragmentMatching',  function (result) {
this.results.add$O(result);
this.results.sort$java_util_Comparator((P$.FragmentPTreeSearch$SearchResult$lambda2$||(P$.FragmentPTreeSearch$SearchResult$lambda2$=(((P$.FragmentPTreeSearch$SearchResult$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "FragmentPTreeSearch$SearchResult$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['compare$com_actelion_research_chem_chemicalspaces_ptree_search_FragmentPTreeSearch_FragmentMatching$com_actelion_research_chem_chemicalspaces_ptree_search_FragmentPTreeSearch_FragmentMatching','compare$O$O'],  function (c1, c2) {
return Double.compare$D$D(c2.sim, c1.sim);
});
})()
), Clazz.new_(P$.FragmentPTreeSearch$SearchResult$lambda2.$init$,[this, null]))))));
});
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:35 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
