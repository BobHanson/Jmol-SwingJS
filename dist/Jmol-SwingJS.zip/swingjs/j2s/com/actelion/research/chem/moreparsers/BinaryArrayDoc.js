(function(){var P$=Clazz.newPackage("com.actelion.research.chem.moreparsers"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "BinaryArrayDoc");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-15 21:01:50 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
