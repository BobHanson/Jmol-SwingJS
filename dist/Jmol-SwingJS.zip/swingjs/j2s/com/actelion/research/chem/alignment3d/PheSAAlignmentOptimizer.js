(function(){var P$=Clazz.newPackage("com.actelion.research.chem.alignment3d"),I$=[[0,['com.actelion.research.chem.alignment3d.PheSAAlignmentOptimizer','.SimilarityMode'],'com.actelion.research.chem.alignment3d.PheSAAlignmentOptimizer','StringBuilder',['com.actelion.research.chem.alignment3d.PheSAAlignmentOptimizer','.PheSASetting'],'com.actelion.research.chem.phesa.MolecularVolume','com.actelion.research.chem.Coordinates','com.actelion.research.chem.conf.Conformer','java.util.Collections','java.util.ArrayList','com.actelion.research.chem.phesa.ShapeVolume','com.actelion.research.chem.phesa.PheSAAlignment','com.actelion.research.chem.alignment3d.transformation.TransformationSequence',['com.actelion.research.chem.alignment3d.PheSAAlignmentOptimizer','.AlignmentResult'],'java.util.Comparator','java.util.stream.Collectors','com.actelion.research.chem.phesa.pharmacophore.PPTriangleCreator','com.actelion.research.chem.phesa.pharmacophore.PPTriangleMatcher','java.util.Random']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PheSAAlignmentOptimizer", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['SimilarityMode',25],['AlignmentResult',9],['PheSASetting',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['D',['EXIT_VECTOR_WEIGHT'],'I',['TRIANGLE_OPTIMIZATIONS','PMI_OPTIMIZATIONS']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'alignTwoMolsInPlace$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule',  function (refMol, fitMol) {
return C$.alignTwoMolsInPlace$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$D(refMol, fitMol, 0.5);
}, 1);

Clazz.newMeth(C$, 'alignTwoMolsInPlace$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$D',  function (refMol, fitMol, ppWeight) {
var setting=Clazz.new_($I$(4,1));
setting.setPpWeight$D(ppWeight);
var similarity=0.0;
var refVol=Clazz.new_($I$(5,1).c$$com_actelion_research_chem_StereoMolecule,[refMol]);
var fitVol=Clazz.new_($I$(5,1).c$$com_actelion_research_chem_StereoMolecule,[fitMol]);
var origCOM=Clazz.new_([refVol.getCOM$()],$I$(6,1).c$$com_actelion_research_chem_Coordinates);
var refConf=Clazz.new_($I$(7,1).c$$com_actelion_research_chem_StereoMolecule,[refMol]);
var fitConf=Clazz.new_($I$(7,1).c$$com_actelion_research_chem_StereoMolecule,[fitMol]);
var rotation=refVol.preProcess$com_actelion_research_chem_conf_Conformer(refConf);
rotation=rotation.getInvert$();
fitVol.preProcess$com_actelion_research_chem_conf_Conformer(fitConf);
var bestSolution=C$.createAlignmentSolutions$java_util_List$java_util_List$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_PheSASetting($I$(8).singletonList$O(refVol), $I$(8).singletonList$O(fitVol), setting).get$I(0);
similarity=bestSolution.getSimilarity$();
for (var a=0; a < fitMol.getAllAtoms$(); a++) {
fitMol.setAtomX$I$D(a, fitConf.getX$I(a));
fitMol.setAtomY$I$D(a, fitConf.getY$I(a));
fitMol.setAtomZ$I$D(a, fitConf.getZ$I(a));
}
bestSolution.getTransform$().apply$com_actelion_research_chem_StereoMolecule(fitMol);
rotation.apply$com_actelion_research_chem_StereoMolecule(fitMol);
fitMol.translate$D$D$D(origCOM.x, origCOM.y, origCOM.z);
return similarity;
}, 1);

Clazz.newMeth(C$, 'alignToNegRecImg$com_actelion_research_chem_phesa_ShapeVolume$java_util_List$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_PheSASetting',  function (ref, fitVols, setting) {
for (var shapeVol, $shapeVol = fitVols.iterator$(); $shapeVol.hasNext$()&&((shapeVol=($shapeVol.next$())),1);) {
shapeVol.removeRings$();
}
var alignmentSolutions=C$.createAlignmentSolutions$java_util_List$java_util_List$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_PheSASetting($I$(8).singletonList$O(ref), fitVols, setting);
var results=Clazz.new_($I$(9,1));
var counter=0;
for (var solution, $solution = alignmentSolutions.iterator$(); $solution.hasNext$()&&((solution=($solution.next$())),1);) {
if (counter++ >= 20) {
break;
}results.add$O(solution);
}
return results;
}, 1);

Clazz.newMeth(C$, 'createAlignmentSolutions$java_util_List$java_util_List$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_PheSASetting',  function (refVols, fitVols, setting) {
var pmiOpti=setting.nrOptimizationsPMI;
var alignmentSolutions=Clazz.new_($I$(9,1));
for (var molVol, $molVol = refVols.iterator$(); $molVol.hasNext$()&&((molVol=($molVol.next$())),1);) {
for (var ppg, $ppg = molVol.getPPGaussians$().iterator$(); $ppg.hasNext$()&&((ppg=($ppg.next$())),1);) {
if (ppg.getPharmacophorePoint$().getFunctionalityIndex$() == 7) {
ppg.setWeight$D(C$.EXIT_VECTOR_WEIGHT);
}}
}
var triangleSolutions=Clazz.new_($I$(9,1));
if (setting.useTriangle) triangleSolutions=C$.getBestTriangleAlignments$java_util_List$java_util_List$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_PheSASetting(refVols, fitVols, setting);
alignmentSolutions.addAll$java_util_Collection(triangleSolutions);
var pmiSolutions=Clazz.new_($I$(9,1));
for (var i=0; i < refVols.size$(); i++) {
var refVol=refVols.get$I(i);
for (var j=0; j < fitVols.size$(); j++) {
var fitVol=Clazz.new_([fitVols.get$I(j)],$I$(10,1).c$$com_actelion_research_chem_phesa_ShapeVolume);
var shapeAlignment=Clazz.new_($I$(11,1).c$$com_actelion_research_chem_phesa_ShapeVolume$com_actelion_research_chem_phesa_ShapeVolume$D,[refVol, fitVol, setting.ppWeight]);
var pmiTransformation=Clazz.new_($I$(12,1));
var transforms=$I$(11).initialTransform$I(2);
var r=shapeAlignment.findAlignment$DAA$com_actelion_research_chem_alignment3d_transformation_TransformationSequence$Z$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_SimilarityMode(transforms, pmiTransformation, false, setting.getSimMode$());
var pmiAlignment=Clazz.new_($I$(13,1).c$$D$com_actelion_research_chem_alignment3d_transformation_TransformationSequence$I$I,[r[0], pmiTransformation, i, j]);
pmiAlignment.setSimilarityContributions$DA(r);
pmiSolutions.add$O(pmiAlignment);
}
}
var sortedPMISolutions=pmiSolutions.stream$().sorted$java_util_Comparator($I$(14).reverseOrder$()).collect$java_util_stream_Collector($I$(15).toList$());
var counter=0;
for (var pmiAlignment, $pmiAlignment = sortedPMISolutions.iterator$(); $pmiAlignment.hasNext$()&&((pmiAlignment=($pmiAlignment.next$())),1);) {
if (counter++ > pmiOpti) break;
var refVol=refVols.get$I(pmiAlignment.getRefConformerIndex$());
var fitVol=Clazz.new_([fitVols.get$I(pmiAlignment.getConformerIndex$())],$I$(10,1).c$$com_actelion_research_chem_phesa_ShapeVolume);
var bestTransform=pmiAlignment.getTransform$();
fitVol.transform$com_actelion_research_chem_alignment3d_transformation_Transformation(bestTransform);
var shapeAlignment=Clazz.new_($I$(11,1).c$$com_actelion_research_chem_phesa_ShapeVolume$com_actelion_research_chem_phesa_ShapeVolume$D,[refVol, fitVol, setting.ppWeight]);
var optimizedTransform=Clazz.new_($I$(12,1));
var r=shapeAlignment.findAlignment$DAA$com_actelion_research_chem_alignment3d_transformation_TransformationSequence$Z$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_SimilarityMode($I$(11).initialTransform$I(0), optimizedTransform, true, setting.simMode);
pmiAlignment.getTransform$().addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(optimizedTransform);
var optimizedPMIAlignment=Clazz.new_([r[0], pmiAlignment.getTransform$(), pmiAlignment.getRefConformerIndex$(), pmiAlignment.getConformerIndex$()],$I$(13,1).c$$D$com_actelion_research_chem_alignment3d_transformation_TransformationSequence$I$I);
optimizedPMIAlignment.setSimilarityContributions$DA(r);
alignmentSolutions.add$O(optimizedPMIAlignment);
}
var sortedSolutions=alignmentSolutions.stream$().sorted$java_util_Comparator($I$(14).reverseOrder$()).collect$java_util_stream_Collector($I$(15).toList$());
return sortedSolutions;
}, 1);

Clazz.newMeth(C$, 'align$com_actelion_research_chem_phesa_PheSAMolecule$com_actelion_research_chem_phesa_PheSAMolecule$com_actelion_research_chem_StereoMoleculeA$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_PheSASetting',  function (refShape, fitShape, bestAlignment, setting) {
var result=Clazz.array(Double.TYPE, [4]);
var alignmentSolutions=C$.createAlignmentSolutions$java_util_List$java_util_List$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_PheSASetting(refShape.getVolumes$(), fitShape.getVolumes$(), setting);
var bestResult=alignmentSolutions.get$I(0);
var refMol=refShape.getConformer$I(bestResult.getRefConformerIndex$());
var fitMol=fitShape.getConformer$I(bestResult.getConformerIndex$());
bestResult.getTransform$().apply$com_actelion_research_chem_StereoMolecule(fitMol);
result=bestResult.getSimilarityContributions$();
bestAlignment[0]=refMol;
bestAlignment[1]=fitMol;
var n1=refShape.getVolumes$().get$I(0).getExitVectorGaussians$().size$();
var n2=fitShape.getVolumes$().get$I(0).getExitVectorGaussians$().size$();
if (refShape.getVolumes$().get$I(0).getExitVectorGaussians$().size$() != 0 || refShape.getVolumes$().get$I(0).getExitVectorGaussians$().size$() != 0 ) {
if (n1 != n2) {
result[0]=0.0;
result[1]=0.0;
result[2]=0.0;
result[3]=0.0;
}}return result;
}, 1);

Clazz.newMeth(C$, 'getBestTriangleAlignments$java_util_List$java_util_List$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_PheSASetting',  function (refVols, fitVols, setting) {
var triangleResults=Clazz.new_($I$(9,1));
for (var i=0; i < refVols.size$(); i++) {
var refVol=refVols.get$I(i);
var refTriangles=$I$(16,"create$java_util_List$com_actelion_research_chem_Coordinates",[refVol.getPPGaussians$(), refVol.getCOM$()]);
for (var j=0; j < fitVols.size$(); j++) {
var fitVol=fitVols.get$I(j);
var fitTriangles=$I$(16,"create$java_util_List$com_actelion_research_chem_Coordinates",[fitVol.getPPGaussians$(), fitVol.getCOM$()]);
triangleResults.addAll$java_util_Collection($I$(17).getMatchingTransforms$java_util_Map$java_util_Map$I$I$Z(refTriangles, fitTriangles, i, j, setting.useDirectionality));
}
}
var sortedTriangleResults=triangleResults.stream$().sorted$java_util_Comparator($I$(14).reverseOrder$()).collect$java_util_stream_Collector($I$(15).toList$());
var optimizedResults=Clazz.new_($I$(9,1));
if (triangleResults.size$() != 0) {
var alignments=$I$(11).initialTransform$I(0);
var counter=0;
for (var result, $result = sortedTriangleResults.iterator$(); $result.hasNext$()&&((result=($result.next$())),1);) {
if (counter++ > setting.nrOptimizationsTriangle) break;
var refVol=refVols.get$I(result.getRefConformerIndex$());
var fitVol=Clazz.new_([fitVols.get$I(result.getConformerIndex$())],$I$(10,1).c$$com_actelion_research_chem_phesa_ShapeVolume);
var bestTransform=result.getTransform$();
fitVol.transform$com_actelion_research_chem_alignment3d_transformation_Transformation(bestTransform);
var shapeAlignment=Clazz.new_($I$(11,1).c$$com_actelion_research_chem_phesa_ShapeVolume$com_actelion_research_chem_phesa_ShapeVolume$D,[refVol, fitVol, setting.ppWeight]);
var optTransform=Clazz.new_($I$(12,1));
var r=shapeAlignment.findAlignment$DAA$com_actelion_research_chem_alignment3d_transformation_TransformationSequence$Z$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_SimilarityMode(alignments, optTransform, true, setting.simMode);
bestTransform.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(optTransform);
var optimizedResult=Clazz.new_([r[0], bestTransform, result.getRefConformerIndex$(), result.getConformerIndex$()],$I$(13,1).c$$D$com_actelion_research_chem_alignment3d_transformation_TransformationSequence$I$I);
optimizedResult.setSimilarityContributions$DA(r);
optimizedResults.add$O(optimizedResult);
}
}var sortedSolutions=optimizedResults.stream$().sorted$java_util_Comparator($I$(14).reverseOrder$()).collect$java_util_stream_Collector($I$(15).toList$());
return sortedSolutions;
}, 1);

Clazz.newMeth(C$, 'createSubAlignments$com_actelion_research_chem_phesa_ShapeVolume$DAA',  function (refVol, baseTransforms) {
var seed=12345;
var maxPoints=10;
var points=Math.min(refVol.getAtomicGaussians$().size$(), 10);
var rnd=Clazz.new_($I$(18,1).c$$J,[12345]);
var transforms=Clazz.new_($I$(9,1));
for (var i=0; i < points; i++) {
var index=rnd.nextInt$I(refVol.getAtomicGaussians$().size$());
var c=refVol.getAtomicGaussians$().get$I(index).getCenter$();
for (var t, $t = 0, $$t = baseTransforms; $t<$$t.length&&((t=($$t[$t])),1);$t++) {
transforms.add$O(Clazz.array(Double.TYPE, -1, [t[0], t[1], t[2], c.x, c.y, c.z]));
}
}
for (var t, $t = 0, $$t = baseTransforms; $t<$$t.length&&((t=($$t[$t])),1);$t++) {
transforms.add$O(t);
}
return transforms.toArray$OA(Clazz.array(Double.TYPE, [0, null]));
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.TRIANGLE_OPTIMIZATIONS=50;
C$.PMI_OPTIMIZATIONS=10;
C$.EXIT_VECTOR_WEIGHT=10.0;
};
;
(function(){/*e*/var C$=Clazz.newClass(P$.PheSAAlignmentOptimizer, "SimilarityMode", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "REFTVERSKY", 0, []);
Clazz.newEnumConst($vals, C$.c$, "TVERSKY", 1, []);
Clazz.newEnumConst($vals, C$.c$, "TANIMOTO", 2, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.PheSAAlignmentOptimizer, "AlignmentResult", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['similarity'],'I',['conformerIndex','refConformerIndex'],'O',['transformation','com.actelion.research.chem.alignment3d.transformation.TransformationSequence','similarityContributions','double[]']]]

Clazz.newMeth(C$, 'c$$D$com_actelion_research_chem_alignment3d_transformation_TransformationSequence$I$I',  function (similarity, transformation, refConformerIndex, conformerIndex) {
;C$.$init$.apply(this);
this.similarity=similarity;
this.transformation=transformation;
this.refConformerIndex=refConformerIndex;
this.conformerIndex=conformerIndex;
}, 1);

Clazz.newMeth(C$, 'getSimilarityContributions$',  function () {
return this.similarityContributions;
});

Clazz.newMeth(C$, 'setSimilarityContributions$DA',  function (similarityContributions) {
this.similarityContributions=similarityContributions;
});

Clazz.newMeth(C$, 'getTransform$',  function () {
return this.transformation;
});

Clazz.newMeth(C$, 'getSimilarity$',  function () {
return this.similarity;
});

Clazz.newMeth(C$, 'getConformerIndex$',  function () {
return this.conformerIndex;
});

Clazz.newMeth(C$, 'getRefConformerIndex$',  function () {
return this.refConformerIndex;
});

Clazz.newMeth(C$, ['compareTo$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_AlignmentResult','compareTo$O'],  function (o) {
return Double.compare$D$D(this.similarity, o.similarity);
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.PheSAAlignmentOptimizer, "PheSASetting", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['useDirectionality','useTriangle'],'D',['ppWeight'],'I',['nrOptimizationsPMI','nrOptimizationsTriangle'],'O',['simMode','com.actelion.research.chem.alignment3d.PheSAAlignmentOptimizer.SimilarityMode']]]

Clazz.newMeth(C$, 'getPpWeight$',  function () {
return this.ppWeight;
});

Clazz.newMeth(C$, 'setPpWeight$D',  function (ppWeight) {
this.ppWeight=ppWeight;
});

Clazz.newMeth(C$, 'getSimMode$',  function () {
return this.simMode;
});

Clazz.newMeth(C$, 'setSimMode$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_SimilarityMode',  function (simMode) {
this.simMode=simMode;
});

Clazz.newMeth(C$, 'isUseDirectionality$',  function () {
return this.useDirectionality;
});

Clazz.newMeth(C$, 'setUseDirectionality$Z',  function (useDirectionality) {
this.useDirectionality=useDirectionality;
});

Clazz.newMeth(C$, 'getNrOptimizationsPMI$',  function () {
return this.nrOptimizationsPMI;
});

Clazz.newMeth(C$, 'setNrOptimizationsPMI$I',  function (nrOptimizationsPMI) {
this.nrOptimizationsPMI=nrOptimizationsPMI;
});

Clazz.newMeth(C$, 'getNrOptimizationsTriangle$',  function () {
return this.nrOptimizationsTriangle;
});

Clazz.newMeth(C$, 'setNrOptimizationsTriangle$I',  function (nrOptimizationsTriangle) {
this.nrOptimizationsTriangle=nrOptimizationsTriangle;
});

Clazz.newMeth(C$, 'isUseTriangle$',  function () {
return this.useTriangle;
});

Clazz.newMeth(C$, 'setUseTriangle$Z',  function (useTriangle) {
this.useTriangle=useTriangle;
});

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.ppWeight=0.5;
this.simMode=$I$(1).TANIMOTO;
this.useDirectionality=true;
this.useTriangle=true;
this.nrOptimizationsPMI=$I$(2).PMI_OPTIMIZATIONS;
this.nrOptimizationsTriangle=$I$(2).TRIANGLE_OPTIMIZATIONS;
}, 1);

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(3,1));
sb.append$S(Double.toString$D(this.ppWeight));
sb.append$S("_");
sb.append$S(this.simMode.toString());
sb.append$S("_");
sb.append$S(Boolean.toString$Z(this.useDirectionality));
sb.append$S("_");
sb.append$S(Boolean.toString$Z(this.useTriangle));
sb.append$S("_");
sb.append$S(Integer.toString$I(this.nrOptimizationsPMI));
sb.append$S("_");
sb.append$S(Integer.toString$I(this.nrOptimizationsTriangle));
return sb.toString();
});

Clazz.newMeth(C$, 'fromString$S',  function (encoded) {
var setting=Clazz.new_(C$);
var split=encoded.split$S("_");
setting.setPpWeight$D(Double.parseDouble$S(split[0]));
setting.setSimMode$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_SimilarityMode($I$(1).valueOf$S(split[1]));
setting.setUseDirectionality$Z(Boolean.parseBoolean$S(split[2]));
setting.setUseTriangle$Z(Boolean.parseBoolean$S(split[3]));
setting.setNrOptimizationsPMI$I(Integer.parseInt$S(split[4]));
setting.setNrOptimizationsTriangle$I(Integer.parseInt$S(split[5]));
return setting;
}, 1);
})()
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:08 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
