(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),I$=[[0,'java.util.Hashtable','com.actelion.research.chem.forcefield.mmff.SortedPair',['com.actelion.research.chem.forcefield.mmff.Separation','.Relation']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Separation", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['Relation',25]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.table=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['O',['table','java.util.Hashtable']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_MMFFMolecule',  function (mol) {
;C$.$init$.apply(this);
for (var atom=0; atom < mol.getAllAtoms$(); atom++) {
this.table.put$O$O(Clazz.new_($I$(2,1).c$$I$I,[atom, atom]), $I$(3).ONE_ONE);
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr1=mol.getConnAtom$I$I(atom, i);
var keytwo=Clazz.new_($I$(2,1).c$$I$I,[atom, nbr1]);
this.table.put$O$O(keytwo, $I$(3).ONE_TWO);
for (var j=0; j < mol.getAllConnAtoms$I(nbr1); j++) {
var nbr2=mol.getConnAtom$I$I(nbr1, j);
var keythree=Clazz.new_($I$(2,1).c$$I$I,[atom, nbr2]);
if (!this.table.containsKey$O(keythree) || this.table.get$O(keythree) === $I$(3).ONE_FOUR  ) this.table.put$O$O(keythree, $I$(3).ONE_THREE);
for (var k=0; k < mol.getAllConnAtoms$I(nbr2); k++) {
var nbr3=mol.getConnAtom$I$I(nbr2, k);
var keyfour=Clazz.new_($I$(2,1).c$$I$I,[atom, nbr3]);
if (!this.table.containsKey$O(keyfour)) this.table.put$O$O(keyfour, $I$(3).ONE_FOUR);
}
}
}
}
}, 1);

Clazz.newMeth(C$, 'get$com_actelion_research_chem_forcefield_mmff_SortedPair',  function (key) {
return this.table.get$O(key) != null  ? this.table.get$O(key) : $I$(3).ONE_X;
});

Clazz.newMeth(C$, 'get$I$I',  function (a1, a2) {
return this.get$com_actelion_research_chem_forcefield_mmff_SortedPair(Clazz.new_($I$(2,1).c$$I$I,[a1, a2]));
});
;
(function(){/*e*/var C$=Clazz.newClass(P$.Separation, "Relation", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "ONE_ONE", 0, []);
Clazz.newEnumConst($vals, C$.c$, "ONE_TWO", 1, []);
Clazz.newEnumConst($vals, C$.c$, "ONE_THREE", 2, []);
Clazz.newEnumConst($vals, C$.c$, "ONE_FOUR", 3, []);
Clazz.newEnumConst($vals, C$.c$, "ONE_X", 4, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:38 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
