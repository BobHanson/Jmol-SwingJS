(function(){var P$=Clazz.newPackage("com.actelion.research.chem.contrib"),I$=[[0,'com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.SmilesParser','com.actelion.research.chem.contrib.DiastereotopicAtomID','com.actelion.research.chem.contrib.HydrogenHandler']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "testDiaID");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
var mol=Clazz.new_($I$(1,1));
var parser=Clazz.new_($I$(2,1));
try {
parser.parse$com_actelion_research_chem_StereoMolecule$S(mol, "C1CCCCC1C");
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$S(e.toString());
} else {
throw e;
}
}
var ids=$I$(3).getAtomIds$com_actelion_research_chem_StereoMolecule(mol);
System.out.println$S(ids[0]);
$I$(4).addImplicitHydrogens$com_actelion_research_chem_StereoMolecule(mol);
ids=$I$(3).getAtomIds$com_actelion_research_chem_StereoMolecule(mol);
System.out.println$S(ids[0]);
System.out.println$S("");
for (var id, $id = 0, $$id = ids; $id<$$id.length&&((id=($$id[$id])),1);$id++) {
System.out.println$S(id);
}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:20 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
