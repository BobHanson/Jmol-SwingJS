(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.entity"),I$=[[0,'com.actelion.research.util.datamodel.IntArray','com.actelion.research.util.datamodel.ByteVec']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Linker");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['id','idFlexophorePoint1','idFlexophorePoint2','hash'],'S',['idcode'],'O',['arrDistanceHistogram','byte[]','iaOriginalAtomIndex','com.actelion.research.util.datamodel.IntArray']]]

Clazz.newMeth(C$, 'c$$I',  function (id) {
;C$.$init$.apply(this);
this.id=id;
this.hash=-1;
this.iaOriginalAtomIndex=Clazz.new_($I$(1,1).c$$I,[12]);
}, 1);

Clazz.newMeth(C$, 'calculateHashCode$',  function () {
if (this.arrDistanceHistogram == null  || this.idcode == null  ) {
this.hash=-1;
return;
}var hashHist=$I$(2).getHashCode$BA(this.arrDistanceHistogram);
var hashIdCode=this.idcode.hashCode$();
this.hash=hashHist ^ hashIdCode;
});

Clazz.newMeth(C$, 'getId$',  function () {
return this.id;
});

Clazz.newMeth(C$, 'hashCode$',  function () {
return this.hash;
});

Clazz.newMeth(C$, 'addOriginalAtomIndex$I',  function (atomIndex) {
this.iaOriginalAtomIndex.add$I(atomIndex);
});

Clazz.newMeth(C$, 'addOriginalAtomIndex$IA',  function (arrAtomIndex) {
this.iaOriginalAtomIndex.add$IA(arrAtomIndex);
});

Clazz.newMeth(C$, 'getOriginalAtomIndex$',  function () {
return this.iaOriginalAtomIndex.get$();
});

Clazz.newMeth(C$, 'getDistanceHistogram$',  function () {
return this.arrDistanceHistogram;
});

Clazz.newMeth(C$, 'setDistanceHistogram$BA',  function (arrDistanceHistogram) {
this.arrDistanceHistogram=arrDistanceHistogram;
this.calculateHashCode$();
});

Clazz.newMeth(C$, 'getIdCode$',  function () {
return this.idcode;
});

Clazz.newMeth(C$, 'setIdCode$S',  function (idcode) {
this.idcode=idcode;
this.calculateHashCode$();
});

Clazz.newMeth(C$, 'equals$O',  function (obj) {
var equal=true;
if (!(Clazz.instanceOf(obj, "com.actelion.research.chem.descriptor.flexophore.entity.Linker"))) {
return false;
}var l=obj;
if ((this.arrDistanceHistogram == null ) && (l.arrDistanceHistogram != null ) ) {
return false;
} else if ((this.arrDistanceHistogram != null ) && (l.arrDistanceHistogram == null ) ) {
return false;
} else if ((this.idcode == null ) && (l.idcode != null ) ) {
return false;
} else if ((this.idcode != null ) && (l.idcode == null ) ) {
return false;
}if (this.arrDistanceHistogram != null ) {
if (l.arrDistanceHistogram != null ) {
if (this.arrDistanceHistogram.length == l.arrDistanceHistogram.length) {
for (var i=0; i < this.arrDistanceHistogram.length; i++) {
if (this.arrDistanceHistogram[i] != l.arrDistanceHistogram[i]) {
equal=false;
break;
}}
}}}if (this.idcode != null ) {
if (l.idcode != null ) {
if (!this.idcode.equals$O(l.idcode)) {
equal=false;
}}}return equal;
});

Clazz.newMeth(C$, 'getIdFlexophorePoint1$',  function () {
return this.idFlexophorePoint1;
});

Clazz.newMeth(C$, 'setIdFlexophorePoint1$I',  function (idFlexophorePoint1) {
this.idFlexophorePoint1=idFlexophorePoint1;
});

Clazz.newMeth(C$, 'getIdFlexophorePoint2$',  function () {
return this.idFlexophorePoint2;
});

Clazz.newMeth(C$, 'setIdFlexophorePoint2$I',  function (idFlexophorePoint2) {
this.idFlexophorePoint2=idFlexophorePoint2;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:10 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
