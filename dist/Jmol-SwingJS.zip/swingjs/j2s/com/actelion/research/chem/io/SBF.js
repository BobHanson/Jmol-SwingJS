(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "SBF");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['lnum','type','a2','a3','datalen','datatyp','a5','dtppoin','a7','begin','a8','a9','a10','a11','a12','a13','a14','a15','a16','a17','fieldNo'],'S',['shortnam','format1','format2','name']]]

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:39 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
