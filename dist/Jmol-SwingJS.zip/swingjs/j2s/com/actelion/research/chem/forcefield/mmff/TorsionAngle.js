(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),I$=[[0,'com.actelion.research.chem.forcefield.mmff.Vector3','java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TorsionAngle", null, null, 'com.actelion.research.chem.forcefield.mmff.EnergyTerm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['v1','v2','v3'],'I',['a1','a2','a3','a4','a1t','a2t','a3t','a4t']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I',  function (table, mol, a1, a2, a3, a4) {
;C$.$init$.apply(this);
this.a1=a1;
this.a2=a2;
this.a3=a3;
this.a4=a4;
this.a1t=mol.getAtomType$I(a1);
this.a2t=mol.getAtomType$I(a2);
this.a3t=mol.getAtomType$I(a3);
this.a4t=mol.getAtomType$I(a4);
var kbs=table.torsion.getForceConstants$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I(mol, a1, a2, a3, a4);
this.v1=kbs.v1;
this.v2=kbs.v2;
this.v3=kbs.v3;
}, 1);

Clazz.newMeth(C$, 'getEnergy$DA',  function (pos) {
var r1=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a1, this.a2]);
var r2=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a3, this.a2]);
var r3=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a2, this.a3]);
var r4=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a4, this.a3]);
var t1=r1.cross$com_actelion_research_chem_forcefield_mmff_Vector3(r2);
var t2=r3.cross$com_actelion_research_chem_forcefield_mmff_Vector3(r4);
var cosPhi=t1.cosAngle$com_actelion_research_chem_forcefield_mmff_Vector3(t2);
var cos2Phi=2.0 * cosPhi * cosPhi  - 1.0;
var cos3Phi=cosPhi * (2.0 * cos2Phi - 1.0);
return 0.5 * (this.v1 * (1.0 + cosPhi) + this.v2 * (1.0 - cos2Phi) + this.v3 * (1.0 + cos3Phi));
});

Clazz.newMeth(C$, 'getGradient$DA$DA',  function (pos, grad) {
var r=Clazz.array($I$(1), -1, [Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a2, this.a1]), Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a2, this.a3]), Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a3, this.a2]), Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a3, this.a4])]);
var t=Clazz.array($I$(1), -1, [r[0].cross$com_actelion_research_chem_forcefield_mmff_Vector3(r[1]), r[2].cross$com_actelion_research_chem_forcefield_mmff_Vector3(r[3])]);
var d=Clazz.array(Double.TYPE, -1, [t[0].length$(), t[1].length$()]);
if (Math.abs(d[0]) < 1.0E-5  || Math.abs(d[1]) < 1.0E-5  ) return;
t[0]=t[0].normalise$();
t[1]=t[1].normalise$();
var cosPhi=t[0].dot$com_actelion_research_chem_forcefield_mmff_Vector3(t[1]);
var sinPhiSq=1.0 - cosPhi * cosPhi;
var sinPhi=((sinPhiSq > 0.0 ) ? Math.sqrt(sinPhiSq) : 0.0);
var sin2Phi=2.0 * sinPhi * cosPhi ;
var sin3Phi=3.0 * sinPhi - 4.0 * sinPhi * sinPhiSq ;
var dE_dPhi=0.5 * (-(this.v1) * sinPhi + 2.0 * this.v2 * sin2Phi  - 3.0 * this.v3 * sin3Phi );
var sinTerm=-dE_dPhi * (Math.abs(sinPhi) < 1.0E-5  ? (1.0 / cosPhi) : (1.0 / sinPhi));
var dCos_dT=Clazz.array(Double.TYPE, -1, [1.0 / d[0] * (t[1].x - cosPhi * t[0].x), 1.0 / d[0] * (t[1].y - cosPhi * t[0].y), 1.0 / d[0] * (t[1].z - cosPhi * t[0].z), 1.0 / d[1] * (t[0].x - cosPhi * t[1].x), 1.0 / d[1] * (t[0].y - cosPhi * t[1].y), 1.0 / d[1] * (t[0].z - cosPhi * t[1].z)]);
grad[3 * this.a1 + 0]+=sinTerm * (dCos_dT[2] * r[1].y - dCos_dT[1] * r[1].z);
grad[3 * this.a1 + 1]+=sinTerm * (dCos_dT[0] * r[1].z - dCos_dT[2] * r[1].x);
grad[3 * this.a1 + 2]+=sinTerm * (dCos_dT[1] * r[1].x - dCos_dT[0] * r[1].y);
grad[3 * this.a2 + 0]+=sinTerm * (dCos_dT[1] * (r[1].z - r[0].z) + dCos_dT[2] * (r[0].y - r[1].y) + dCos_dT[4] * (-r[3].z) + dCos_dT[5] * (r[3].y));
grad[3 * this.a2 + 1]+=sinTerm * (dCos_dT[0] * (r[0].z - r[1].z) + dCos_dT[2] * (r[1].x - r[0].x) + dCos_dT[3] * (r[3].z) + dCos_dT[5] * (-r[3].x));
grad[3 * this.a2 + 2]+=sinTerm * (dCos_dT[0] * (r[1].y - r[0].y) + dCos_dT[1] * (r[0].x - r[1].x) + dCos_dT[3] * (-r[3].y) + dCos_dT[4] * (r[3].x));
grad[3 * this.a3 + 0]+=sinTerm * (dCos_dT[1] * (r[0].z) + dCos_dT[2] * (-r[0].y) + dCos_dT[4] * (r[3].z - r[2].z) + dCos_dT[5] * (r[2].y - r[3].y));
grad[3 * this.a3 + 1]+=sinTerm * (dCos_dT[0] * (-r[0].z) + dCos_dT[2] * (r[0].x) + dCos_dT[3] * (r[2].z - r[3].z) + dCos_dT[5] * (r[3].x - r[2].x));
grad[3 * this.a3 + 2]+=sinTerm * (dCos_dT[0] * (r[0].y) + dCos_dT[1] * (-r[0].x) + dCos_dT[3] * (r[3].y - r[2].y) + dCos_dT[4] * (r[2].x - r[3].x));
grad[3 * this.a4 + 0]+=sinTerm * (dCos_dT[4] * r[2].z - dCos_dT[5] * r[2].y);
grad[3 * this.a4 + 1]+=sinTerm * (dCos_dT[5] * r[2].x - dCos_dT[3] * r[2].z);
grad[3 * this.a4 + 2]+=sinTerm * (dCos_dT[3] * r[2].y - dCos_dT[4] * r[2].x);
});

Clazz.newMeth(C$, 'nonZero$',  function () {
return Math.abs(this.v1) > 0.001  || Math.abs(this.v2) > 0.001   || Math.abs(this.v3) > 0.001  ;
});

Clazz.newMeth(C$, 'findIn$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule',  function (t, mol) {
var tors=Clazz.new_($I$(2,1));
for (var a1=0; a1 < mol.getAllAtoms$(); a1++) {
for (var j=0; j < mol.getAllConnAtoms$I(a1); j++) {
var a2=mol.getConnAtom$I$I(a1, j);
for (var k=0; k < mol.getAllConnAtoms$I(a2); k++) {
var a3=mol.getConnAtom$I$I(a2, k);
if (a1 == a3) continue;
for (var l=0; l < mol.getAllConnAtoms$I(a3); l++) {
var a4=mol.getConnAtom$I$I(a3, l);
if (a2 == a4 || a1 == a4 ) continue;
if (a4 > a1) {
var tor=Clazz.new_(C$.c$$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I,[t, mol, a1, a2, a3, a4]);
if (tor.nonZero$()) tors.add$O(tor);
}}
}
}
}
return tors;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:06 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
