(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io"),p$1={},I$=[[0,'java.util.ArrayList','java.util.TreeMap','java.util.Properties','com.actelion.research.chem.Canonizer']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DWARFileCreator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mWriter','java.io.BufferedWriter','mMasterCopyParser','com.actelion.research.chem.io.DWARFileParser','mRow','String[]','mColumnTitleList','java.util.ArrayList','mColumnPropertiesMap','java.util.TreeMap']]]

Clazz.newMeth(C$, 'c$$java_io_BufferedWriter',  function (writer) {
;C$.$init$.apply(this);
this.mWriter=writer;
this.mColumnTitleList=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'setMasterCopy$com_actelion_research_chem_io_DWARFileParser',  function (parser) {
this.mMasterCopyParser=parser;
var headAndTail=this.mMasterCopyParser.getHeadOrTail$();
for (var title, $title = 0, $$title = headAndTail.get$I(headAndTail.size$() - 1).split$S("\\t"); $title<$$title.length&&((title=($$title[$title])),1);$title++) this.mColumnTitleList.add$O(title);

});

Clazz.newMeth(C$, 'addStructureColumn$S$S',  function (name, idColumnName) {
var structureColumn=this.mColumnTitleList.size$();
var title=p$1.makeUnique$S.apply(this, [name]);
this.mColumnTitleList.add$O(title);
this.addColumnProperty$I$S$S(structureColumn, "specialType", "idcode");
if (idColumnName != null ) this.addColumnProperty$I$S$S(structureColumn, "idColumn", idColumnName);
return structureColumn;
});

Clazz.newMeth(C$, 'add2DCoordinatesColumn$I',  function (structureColumn) {
return p$1.addStructureChildColumn$S$S$I.apply(this, ["idcoordinates2D", "idcoordinates2D", structureColumn]);
});

Clazz.newMeth(C$, 'add3DCoordinatesColumn$S$I',  function (name, structureColumn) {
return p$1.addStructureChildColumn$S$S$I.apply(this, ["idcoordinates3D", name, structureColumn]);
});

Clazz.newMeth(C$, 'addDescriptorColumn$S$S$I',  function (descriptorShortName, descriptorVersion, structureColumn) {
var column=p$1.addStructureChildColumn$S$S$I.apply(this, [descriptorShortName, descriptorShortName, structureColumn]);
this.addColumnProperty$I$S$S(column, "version", descriptorVersion);
return column;
});

Clazz.newMeth(C$, 'addStructureChildColumn$S$S$I',  function (specialType, name, structureColumn) {
var column=this.mColumnTitleList.size$();
this.mColumnTitleList.add$O(p$1.makeUnique$S.apply(this, [name]));
this.addColumnProperty$I$S$S(column, "parent", this.mColumnTitleList.get$I(structureColumn));
this.addColumnProperty$I$S$S(column, "specialType", specialType);
return column;
}, p$1);

Clazz.newMeth(C$, 'addAlphanumericalColumn$S',  function (name) {
this.mColumnTitleList.add$O(p$1.makeUnique$S.apply(this, [name]));
return this.mColumnTitleList.size$() - 1;
});

Clazz.newMeth(C$, 'addColumnProperty$I$S$S',  function (column, key, value) {
if (this.mColumnPropertiesMap == null ) this.mColumnPropertiesMap=Clazz.new_($I$(2,1));
var cp=this.mColumnPropertiesMap.get$O(Integer.valueOf$I(column));
if (cp == null ) {
cp=Clazz.new_($I$(3,1));
this.mColumnPropertiesMap.put$O$O(Integer.valueOf$I(column), cp);
}cp.setProperty$S$S(key, value);
});

Clazz.newMeth(C$, 'getColumnTitles$',  function () {
return this.mColumnTitleList.toArray$OA(Clazz.array(String, [0]));
});

Clazz.newMeth(C$, 'getColumnProperties$S',  function (columnTitle) {
if (this.mMasterCopyParser != null ) {
return this.mMasterCopyParser.getColumnProperties$S(columnTitle);
} else {
for (var i=0; i < this.mColumnTitleList.size$(); i++) if (this.mColumnTitleList.get$I(i).equals$O(columnTitle)) return this.mColumnPropertiesMap.get$O(Integer.valueOf$I(i));

return null;
}});

Clazz.newMeth(C$, 'writeHeader$I',  function (rowCount) {
if (this.mMasterCopyParser == null ) {
this.mWriter.write$S("<datawarrior-fileinfo>");
this.mWriter.newLine$();
this.mWriter.write$S("<version=\"3.3\">");
this.mWriter.newLine$();
if (rowCount > 0) {
this.mWriter.write$S("<rowcount=\"" + rowCount + "\">" );
this.mWriter.newLine$();
}this.mWriter.write$S("</datawarrior-fileinfo>");
this.mWriter.newLine$();
p$1.writeColumnPropertiesAndTitles.apply(this, []);
} else {
for (var line, $line = this.mMasterCopyParser.getHeadOrTail$().iterator$(); $line.hasNext$()&&((line=($line.next$())),1);) {
if (line.trim$().matches$S("<rowcount=\"\\d+\">")) {
if (rowCount < 0) continue;
line="<rowcount=\"" + rowCount + "\">" ;
}if (line.trim$().matches$S("<created=\"\\d+\">")) {
line="<created=\"" + Long.$s(System.currentTimeMillis$()) + "\">" ;
}this.mWriter.write$S(line);
this.mWriter.newLine$();
}
}this.mRow=Clazz.array(String, [this.mColumnTitleList.size$()]);
});

Clazz.newMeth(C$, 'writeColumnPropertiesAndTitles',  function () {
if (this.mColumnPropertiesMap != null ) {
this.mWriter.write$S("<column properties>");
this.mWriter.newLine$();
for (var column, $column = this.mColumnPropertiesMap.keySet$().iterator$(); $column.hasNext$()&&((column=($column.next$()).intValue$()),1);) {
this.mWriter.write$S("<columnName=\"" + this.mColumnTitleList.get$I(column) + "\">" );
this.mWriter.newLine$();
var cp=this.mColumnPropertiesMap.get$O(Integer.valueOf$I(column));
for (var key, $key = cp.stringPropertyNames$().iterator$(); $key.hasNext$()&&((key=($key.next$())),1);) {
var value=cp.getProperty$S(key);
this.mWriter.write$S("<columnProperty=\"" + key + "\t" + value + "\">" );
this.mWriter.newLine$();
}
}
this.mWriter.write$S("</column properties>");
this.mWriter.newLine$();
}var isFirst=true;
for (var i=0; i < this.mColumnTitleList.size$(); i++) {
if (isFirst) isFirst=false;
 else this.mWriter.write$S("\t");
this.mWriter.write$S(this.mColumnTitleList.get$I(i));
}
this.mWriter.newLine$();
}, p$1);

Clazz.newMeth(C$, 'setRowStructure$com_actelion_research_chem_StereoMolecule$I$I',  function (mol, idcodeColumn, coordsColumn) {
var canonizer=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
this.mRow[idcodeColumn]=canonizer.getIDCode$();
this.mRow[coordsColumn]=canonizer.getEncodedCoordinates$();
});

Clazz.newMeth(C$, 'setRowStructure$S$I',  function (idcode, column) {
this.mRow[column]=idcode;
});

Clazz.newMeth(C$, 'setRowCoordinates$S$I',  function (coordinates, column) {
this.mRow[column]=coordinates;
});

Clazz.newMeth(C$, 'setRowValue$S$I',  function (value, column) {
value=value.replaceAll$S$S("\\r?\\n|\\r", "<NL>");
value=value.replace$CharSequence$CharSequence("\t", "<TAB>");
this.mRow[column]=value;
});

Clazz.newMeth(C$, 'writeCurrentRow$',  function () {
var isFirst=true;
for (var i=0; i < this.mRow.length; i++) {
if (isFirst) isFirst=false;
 else this.mWriter.write$S("\t");
if (this.mRow[i] != null ) {
this.mWriter.write$S(this.mRow[i]);
this.mRow[i]=null;
}}
this.mWriter.newLine$();
});

Clazz.newMeth(C$, 'writeTemplate$java_util_ArrayList',  function (properties) {
if (properties != null  && properties.size$() != 0 ) {
this.mWriter.write$S("<datawarrior properties>");
this.mWriter.newLine$();
for (var propertyLine, $propertyLine = properties.iterator$(); $propertyLine.hasNext$()&&((propertyLine=($propertyLine.next$())),1);) {
this.mWriter.write$S(propertyLine);
this.mWriter.newLine$();
}
this.mWriter.write$S("<datawarrior properties>");
this.mWriter.newLine$();
}});

Clazz.newMeth(C$, 'writeEnd$',  function () {
if (this.mMasterCopyParser != null ) {
while (this.mMasterCopyParser.advanceToNext$());
for (var line, $line = this.mMasterCopyParser.getHeadOrTail$().iterator$(); $line.hasNext$()&&((line=($line.next$())),1);) {
this.mWriter.write$S(line);
this.mWriter.newLine$();
}
}this.mWriter.close$();
});

Clazz.newMeth(C$, 'makeUnique$S',  function (name) {
if (name == null  || name.trim$().length$() == 0 ) {
name="Column 1";
} else {
name=name.trim$().replaceAll$S$S("[\\x00-\\x1F]", "_");
}while (p$1.columnNameExists$S.apply(this, [name])){
var index=name.lastIndexOf$I(" ");
if (index == -1) name=name + " 2";
 else {
try {
var suffix=Integer.parseInt$S(name.substring$I(index + 1));
name=name.substring$I$I(0, index + 1) + (suffix + 1);
} catch (nfe) {
if (Clazz.exceptionOf(nfe,"NumberFormatException")){
name=name + " 2";
} else {
throw nfe;
}
}
}}
return name;
}, p$1);

Clazz.newMeth(C$, 'columnNameExists$S',  function (name) {
for (var existing, $existing = this.mColumnTitleList.iterator$(); $existing.hasNext$()&&((existing=($existing.next$())),1);) if (name.equalsIgnoreCase$S(existing)) return true;

return false;
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:25 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
