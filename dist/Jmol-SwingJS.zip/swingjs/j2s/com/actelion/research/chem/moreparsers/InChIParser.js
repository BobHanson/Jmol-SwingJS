(function(){var P$=Clazz.newPackage("com.actelion.research.chem.moreparsers"),I$=[[0,'com.actelion.research.chem.inchi.InChIOCL']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InChIParser");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'parse$com_actelion_research_chem_StereoMolecule$S',  function (mol, inchi) {
return $I$(1).getMoleculeFromInChI$S$com_actelion_research_chem_StereoMolecule(inchi, mol);
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:41 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
