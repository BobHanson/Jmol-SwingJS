(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),I$=[[0,'com.actelion.research.chem.descriptor.DescriptorEncoder','java.nio.charset.StandardCharsets','java.util.Arrays','com.actelion.research.chem.descriptor.DescriptorHandler','com.actelion.research.chem.SSSearcherWithIndex']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AbstractDescriptorHandlerLongFP", null, null, 'com.actelion.research.chem.descriptor.DescriptorHandler');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['FAILED_OBJECT','long[]']]]

Clazz.newMeth(C$, ['encode$JA','encode$O'],  function (o) {
return this.calculationFailed$JA(o) ? "Calculation Failed" :  String.instantialize(Clazz.new_($I$(1,1)).encodeLong$JA(o), $I$(2).UTF_8);
});

Clazz.newMeth(C$, 'decode$S',  function (s) {
return s == null  ? null : s.equals$O("Calculation Failed") ? C$.FAILED_OBJECT : Clazz.new_($I$(1,1)).decodeLong$S(s);
});

Clazz.newMeth(C$, 'decode$BA',  function (bytes) {
return bytes == null  ? null : $I$(3,"equals$BA$BA",[bytes, $I$(4).FAILED_BYTES]) ? C$.FAILED_OBJECT : Clazz.new_($I$(1,1)).decodeLong$BA(bytes);
});

Clazz.newMeth(C$, ['calculationFailed$JA','calculationFailed$O'],  function (o) {
return o == null  || o.length == 0 ;
});

Clazz.newMeth(C$, ['getSimilarity$JA$JA','getSimilarity$O$O'],  function (o1, o2) {
return o1 == null  || o2 == null   || o1.length == 0  || o2.length == 0  ? 0.0 : $I$(5).getSimilarityTanimoto$JA$JA(o1, o2);
});

C$.$static$=function(){C$.$static$=0;
C$.FAILED_OBJECT=Clazz.array(Long.TYPE, [0]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-08-16 17:29:35 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
