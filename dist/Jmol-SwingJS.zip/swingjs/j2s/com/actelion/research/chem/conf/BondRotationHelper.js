(function(){var P$=Clazz.newPackage("com.actelion.research.chem.conf"),p$1={},I$=[[0,'com.actelion.research.chem.conf.TorsionDB','java.util.ArrayList','java.util.stream.IntStream','com.actelion.research.chem.conf.TorsionDetail','java.util.HashSet','com.actelion.research.chem.phesa.PheSAAlignment']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "BondRotationHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['includeTerminalPolarH'],'O',['mMol','com.actelion.research.chem.StereoMolecule','mRotatableBonds','int[]','mIsRotatableBond','boolean[]','mSmallerSideAtomLists','int[][]','+mBiggerSideAtomLists','+mTorsionAtoms','+mRearAtoms','mRotationCenters','int[]','+mRotationCentersBig','mTorsionIDs','String[]','terminalPolarHBond','int[]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
C$.c$$com_actelion_research_chem_StereoMolecule$Z.apply(this, [mol, false]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$Z',  function (mol, includeTerminalPolarH) {
;C$.$init$.apply(this);
this.mMol=mol;
this.includeTerminalPolarH=includeTerminalPolarH;
this.initialize$();
}, 1);

Clazz.newMeth(C$, 'initialize$',  function () {
var disconnectedFragmentNo=Clazz.array(Integer.TYPE, [this.mMol.getAllAtoms$()]);
var disconnectedFragmentCount=this.mMol.getFragmentNumbers$IA$Z$Z(disconnectedFragmentNo, false, true);
var disconnectedFragmentSize=Clazz.array(Integer.TYPE, [disconnectedFragmentCount]);
for (var atom=0; atom < this.mMol.getAllAtoms$(); atom++) ++disconnectedFragmentSize[disconnectedFragmentNo[atom]];

this.mIsRotatableBond=Clazz.array(Boolean.TYPE, [this.mMol.getBonds$()]);
$I$(1).findRotatableBonds$com_actelion_research_chem_StereoMolecule$Z$ZA(this.mMol, true, this.mIsRotatableBond);
if (this.includeTerminalPolarH) this.terminalPolarHBond=p$1.findTerminalBondsPolarHs$ZA.apply(this, [this.mIsRotatableBond]);
var rotBonds=Clazz.new_($I$(2,1));
$I$(3).range$I$I(0, this.mIsRotatableBond.length).forEach$java_util_function_IntConsumer(((P$.BondRotationHelper$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "BondRotationHelper$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (e) {
if (this.b$['com.actelion.research.chem.conf.BondRotationHelper'].mIsRotatableBond[e]) this.$finals$.rotBonds.add$O.apply(this.$finals$.rotBonds, [Integer.valueOf$I(e)]);
});
})()
), Clazz.new_(P$.BondRotationHelper$lambda1.$init$,[this, {rotBonds:rotBonds}])));
this.mRotatableBonds=rotBonds.stream$().mapToInt$java_util_function_ToIntFunction((P$.BondRotationHelper$lambda2$||(P$.BondRotationHelper$lambda2$=(((P$.BondRotationHelper$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "BondRotationHelper$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToIntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$Integer','applyAsInt$O'],  function (i) { return (i);});
})()
), Clazz.new_(P$.BondRotationHelper$lambda2.$init$,[this, null])))))).toArray$();
this.mTorsionAtoms=Clazz.array(Integer.TYPE, [this.mRotatableBonds.length, null]);
this.mRearAtoms=Clazz.array(Integer.TYPE, [this.mRotatableBonds.length, null]);
this.mSmallerSideAtomLists=Clazz.array(Integer.TYPE, [this.mRotatableBonds.length, null]);
this.mBiggerSideAtomLists=Clazz.array(Integer.TYPE, [this.mRotatableBonds.length, null]);
this.mRotationCenters=Clazz.array(Integer.TYPE, [this.mRotatableBonds.length]);
this.mRotationCentersBig=Clazz.array(Integer.TYPE, [this.mRotatableBonds.length]);
this.mTorsionIDs=Clazz.array(String, [this.mRotatableBonds.length]);
for (var i=0; i < this.mRotatableBonds.length; i++) {
var bond=this.mRotatableBonds[i];
var isSpecialBond=false;
if (this.terminalPolarHBond != null ) {
for (var b, $b = 0, $$b = this.terminalPolarHBond; $b<$$b.length&&((b=($$b[$b])),1);$b++) {
if (b == bond) isSpecialBond=true;
}
}var torsionAtoms=Clazz.array(Integer.TYPE, [4]);
var rearAtoms=Clazz.array(Integer.TYPE, [2]);
var detail=Clazz.new_($I$(4,1));
var torsionID=$I$(1).getTorsionID$com_actelion_research_chem_StereoMolecule$I$IA$com_actelion_research_chem_conf_TorsionDetail(this.mMol, bond, torsionAtoms, detail);
this.mTorsionIDs[i]=torsionID;
if (isSpecialBond) {
var a1=this.mMol.getBondAtom$I$I(0, bond);
var a2=this.mMol.getBondAtom$I$I(1, bond);
var a0=this.mMol.getConnAtom$I$I(a1, 0) == a2 ? this.mMol.getConnAtom$I$I(a1, 1) : this.mMol.getConnAtom$I$I(a1, 0);
var a3=this.mMol.getConnAtom$I$I(a2, 0) == a1 ? this.mMol.getConnAtom$I$I(a2, 1) : this.mMol.getConnAtom$I$I(a2, 0);
rearAtoms[0]=a2;
rearAtoms[1]=a1;
torsionAtoms[0]=a0;
torsionAtoms[1]=a1;
torsionAtoms[2]=a2;
torsionAtoms[3]=a3;
} else if (torsionID != null ) {
rearAtoms[0]=detail.getRearAtom$I(0);
rearAtoms[1]=detail.getRearAtom$I(1);
} else {
C$.predictAtomSequence$com_actelion_research_chem_StereoMolecule$I$IA$IA(this.mMol, bond, torsionAtoms, rearAtoms);
}this.mTorsionAtoms[i]=torsionAtoms;
this.mRearAtoms[i]=rearAtoms;
p$1.findSmallerSideAtomList$I$IA$I.apply(this, [disconnectedFragmentSize[disconnectedFragmentNo[this.mMol.getBondAtom$I$I(0, bond)]], disconnectedFragmentNo, i]);
}
});

Clazz.newMeth(C$, 'findTerminalBondsPolarHs$ZA',  function (isRotatableBond) {
var terminalHBonds=Clazz.new_($I$(2,1));
for (var b=0; b < this.mMol.getBonds$(); b++) {
var a1=this.mMol.getBondAtom$I$I(0, b);
var a2=this.mMol.getBondAtom$I$I(1, b);
if (this.mMol.getAtomicNo$I(a1) == 7 || this.mMol.getAtomicNo$I(a1) == 8 ) {
if (this.mMol.getNonHydrogenNeighbourCount$I(a1) == 1 && this.mMol.getAllHydrogens$I(a1) > 0 ) {
isRotatableBond[b]=true;
terminalHBonds.add$O(Integer.valueOf$I(b));
continue;
}}if (this.mMol.getAtomicNo$I(a2) == 7 || this.mMol.getAtomicNo$I(a2) == 8 ) {
if (this.mMol.getNonHydrogenNeighbourCount$I(a2) == 1 && this.mMol.getAllHydrogens$I(a2) > 0 ) {
isRotatableBond[b]=true;
terminalHBonds.add$O(Integer.valueOf$I(b));
}}}
return terminalHBonds.stream$().mapToInt$java_util_function_ToIntFunction((function($$){((
(function(){/*m*/var C$=Clazz.newClass(P$, "BondRotationHelper$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToIntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_M*/
Clazz.newMeth(C$, 'applyAsInt$O',  function (t) { return t.intValue$.apply(t,[])});
})()
)); return Clazz.new_(P$.BondRotationHelper$lambda3.$init$,[this, null])})(Integer)).toArray$();
}, p$1);

Clazz.newMeth(C$, 'findSmallerSideAtomList$I$IA$I',  function (disconnectedFragmentSize, disconnectedFragmentNo, bondIndex) {
var isMember=Clazz.array(Boolean.TYPE, [this.mMol.getAllAtoms$()]);
var memberCount=this.mMol.getSubstituent$I$I$ZA$com_actelion_research_chem_ExtendedMolecule$IA(this.mRearAtoms[bondIndex][0], this.mTorsionAtoms[bondIndex][1], isMember, null, null);
var alkyneAtoms=0;
if (this.mRearAtoms[bondIndex][0] != this.mTorsionAtoms[bondIndex][2]) alkyneAtoms=this.mMol.getPathLength$I$I(this.mRearAtoms[bondIndex][0], this.mTorsionAtoms[bondIndex][2]);
var invert=false;
if (memberCount > disconnectedFragmentSize - alkyneAtoms - memberCount ) {
memberCount=disconnectedFragmentSize - alkyneAtoms - memberCount ;
invert=true;
}if (invert && alkyneAtoms != 0 ) {
var spAtom=this.mRearAtoms[bondIndex][0];
var backAtom=this.mTorsionAtoms[bondIndex][1];
while (this.mMol.getAtomPi$I(spAtom) == 2 && this.mMol.getConnAtoms$I(spAtom) == 2  && this.mMol.getAtomicNo$I(spAtom) < 10 ){
isMember[spAtom]=true;
for (var j=0; j < 2; j++) {
var connAtom=this.mMol.getConnAtom$I$I(spAtom, j);
if (connAtom != backAtom) {
backAtom=spAtom;
spAtom=connAtom;
break;
}}
}
}var memberNo=0;
var fragmentNo=disconnectedFragmentNo[this.mTorsionAtoms[bondIndex][1]];
var smallerSideAtomList=Clazz.array(Integer.TYPE, [memberCount]);
for (var atom=0; atom < this.mMol.getAllAtoms$(); atom++) if (disconnectedFragmentNo[atom] == fragmentNo && (!!(isMember[atom] ^ invert)) ) smallerSideAtomList[memberNo++]=atom;

var rotationCenter=this.mTorsionAtoms[bondIndex][invert ? 2 : 1];
this.mRotationCenters[bondIndex]=rotationCenter;
this.mRotationCentersBig[bondIndex]=this.mTorsionAtoms[bondIndex][invert ? 1 : 2];
this.mSmallerSideAtomLists[bondIndex]=smallerSideAtomList;
var bigSideAtoms=Clazz.new_($I$(5,1));
var smallSideAtoms=Clazz.new_($I$(5,1));
for (var a, $a = 0, $$a = smallerSideAtomList; $a<$$a.length&&((a=($$a[$a])),1);$a++) smallSideAtoms.add$O(Integer.valueOf$I(a));

for (var a=0; a < this.mMol.getAllAtoms$(); a++) {
if (!smallSideAtoms.contains$O(Integer.valueOf$I(a))) {
bigSideAtoms.add$O(Integer.valueOf$I(a));
}}
this.mBiggerSideAtomLists[bondIndex]=bigSideAtoms.stream$().mapToInt$java_util_function_ToIntFunction((function($$){((
(function(){/*m*/var C$=Clazz.newClass(P$, "BondRotationHelper$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToIntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_M*/
Clazz.newMeth(C$, 'applyAsInt$O',  function (t) { return t.intValue$.apply(t,[])});
})()
)); return Clazz.new_(P$.BondRotationHelper$lambda4.$init$,[this, null])})(Integer)).toArray$();
}, p$1);

Clazz.newMeth(C$, 'predictAtomSequence$com_actelion_research_chem_StereoMolecule$I$IA$IA',  function (mol, bond, torsionAtoms, rearAtoms) {
for (var i=0; i < 2; i++) {
var centralAtom=mol.getBondAtom$I$I(i, bond);
var rearAtom=mol.getBondAtom$I$I(1 - i, bond);
while (mol.getAtomPi$I(centralAtom) == 2 && mol.getConnAtoms$I(centralAtom) == 2  && mol.getAtomicNo$I(centralAtom) < 10 ){
for (var j=0; j < 2; j++) {
var connAtom=mol.getConnAtom$I$I(centralAtom, j);
if (connAtom != rearAtom) {
rearAtom=centralAtom;
centralAtom=connAtom;
break;
}}
}
torsionAtoms[i + 1]=centralAtom;
rearAtoms[i]=rearAtom;
}
if (mol.getAtomPi$I(torsionAtoms[1]) == 0 && mol.getConnAtoms$I(torsionAtoms[1]) == 3 ) {
torsionAtoms[0]=-1;
} else {
for (var i=0; i < mol.getConnAtoms$I(torsionAtoms[1]); i++) {
var connAtom=mol.getConnAtom$I$I(torsionAtoms[1], i);
if (connAtom != torsionAtoms[2]) {
torsionAtoms[0]=connAtom;
break;
}}
}if (mol.getAtomPi$I(torsionAtoms[2]) == 0 && mol.getConnAtoms$I(torsionAtoms[2]) == 3 ) {
torsionAtoms[3]=-1;
} else {
for (var i=0; i < mol.getConnAtoms$I(torsionAtoms[2]); i++) {
var connAtom=mol.getConnAtom$I$I(torsionAtoms[2], i);
if (connAtom != torsionAtoms[1]) {
torsionAtoms[3]=connAtom;
break;
}}
}}, 1);

Clazz.newMeth(C$, 'isRotatableBond$I',  function (bond) {
return this.mIsRotatableBond[bond];
});

Clazz.newMeth(C$, 'getRotatableBonds$',  function () {
return this.mRotatableBonds;
});

Clazz.newMeth(C$, 'rotateSmallerSide$I$D',  function (bond, alpha) {
if (!this.isRotatableBond$I(bond)) return;
var bondIndex=-1;
for (var i=0; i < this.mRotatableBonds.length; i++) {
if (this.mRotatableBonds[i] == bond) bondIndex=i;
}
if (bondIndex == -1) return;
var t2=this.mMol.getCoordinates$I(this.mTorsionAtoms[bondIndex][2]);
var unit=t2.subC$com_actelion_research_chem_Coordinates(this.mMol.getCoordinates$I(this.mTorsionAtoms[bondIndex][1])).unit$();
var m=Clazz.array(Double.TYPE, [3, 3]);
var rotationCenter=this.mRotationCenters[bondIndex];
$I$(6,"getRotationMatrix$D$com_actelion_research_chem_Coordinates$DAA",[(rotationCenter == this.mTorsionAtoms[bondIndex][1]) ? alpha : -alpha, unit, m]);
var t2Neg=t2.scaleC$D(-1.0);
for (var atom, $atom = 0, $$atom = this.mSmallerSideAtomLists[bondIndex]; $atom<$$atom.length&&((atom=($$atom[$atom])),1);$atom++) {
if (atom != rotationCenter) {
this.mMol.getCoordinates$I(atom).add$com_actelion_research_chem_Coordinates(t2Neg);
this.mMol.getCoordinates$I(atom).rotate$DAA(m);
this.mMol.getCoordinates$I(atom).add$com_actelion_research_chem_Coordinates(t2);
}}
});

Clazz.newMeth(C$, 'rotateAroundBond$I$D$com_actelion_research_chem_conf_Conformer$Z',  function (bondIndex, alpha, conf, biggerSide) {
var atomList;
var t2;
var unit;
var t2Neg;
var m;
var rotationCenter;
if (biggerSide) {
atomList=this.mBiggerSideAtomLists[bondIndex];
t2=conf.getCoordinates$I(this.mTorsionAtoms[bondIndex][1]);
unit=t2.subC$com_actelion_research_chem_Coordinates(conf.getCoordinates$I(this.mTorsionAtoms[bondIndex][2])).unit$();
m=Clazz.array(Double.TYPE, [3, 3]);
rotationCenter=this.mRotationCentersBig[bondIndex];
$I$(6,"getRotationMatrix$D$com_actelion_research_chem_Coordinates$DAA",[(rotationCenter == this.mTorsionAtoms[bondIndex][2]) ? alpha : -alpha, unit, m]);
t2Neg=t2.scaleC$D(-1.0);
} else {
t2=conf.getCoordinates$I(this.mTorsionAtoms[bondIndex][2]);
unit=t2.subC$com_actelion_research_chem_Coordinates(conf.getCoordinates$I(this.mTorsionAtoms[bondIndex][1])).unit$();
m=Clazz.array(Double.TYPE, [3, 3]);
rotationCenter=this.mRotationCenters[bondIndex];
$I$(6,"getRotationMatrix$D$com_actelion_research_chem_Coordinates$DAA",[(rotationCenter == this.mTorsionAtoms[bondIndex][1]) ? alpha : -alpha, unit, m]);
t2Neg=t2.scaleC$D(-1.0);
atomList=this.mSmallerSideAtomLists[bondIndex];
}for (var atom, $atom = 0, $$atom = atomList; $atom<$$atom.length&&((atom=($$atom[$atom])),1);$atom++) {
if (atom != rotationCenter) {
var coords=conf.getCoordinates$I(atom);
coords.add$com_actelion_research_chem_Coordinates(t2Neg);
coords.rotate$DAA(m);
coords.add$com_actelion_research_chem_Coordinates(t2);
}}
});

Clazz.newMeth(C$, 'setRotatableBonds$IA',  function (rotatableBonds) {
this.mRotatableBonds=rotatableBonds;
});

Clazz.newMeth(C$, 'getSmallerSideAtomLists$',  function () {
return this.mSmallerSideAtomLists;
});

Clazz.newMeth(C$, 'setSmallerSideAtomLists$IAA',  function (smallerSideAtomLists) {
this.mSmallerSideAtomLists=smallerSideAtomLists;
});

Clazz.newMeth(C$, 'getTorsionAtoms$',  function () {
return this.mTorsionAtoms;
});

Clazz.newMeth(C$, 'setTorsionAtoms$IAA',  function (torsionAtoms) {
this.mTorsionAtoms=torsionAtoms;
});

Clazz.newMeth(C$, 'getRearAtoms$',  function () {
return this.mRearAtoms;
});

Clazz.newMeth(C$, 'setRearAtoms$IAA',  function (rearAtoms) {
this.mRearAtoms=rearAtoms;
});

Clazz.newMeth(C$, 'getRotationCenters$',  function () {
return this.mRotationCenters;
});

Clazz.newMeth(C$, 'setRotationCenters$IA',  function (rotationCenters) {
this.mRotationCenters=rotationCenters;
});

Clazz.newMeth(C$, 'getTorsionIDs$',  function () {
return this.mTorsionIDs;
});

Clazz.newMeth(C$, 'setTorsionIDs$SA',  function (torsionIDs) {
this.mTorsionIDs=torsionIDs;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:35 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
