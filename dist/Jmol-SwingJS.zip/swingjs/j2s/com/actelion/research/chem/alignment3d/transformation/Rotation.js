(function(){var P$=Clazz.newPackage("com.actelion.research.chem.alignment3d.transformation"),I$=[[0,'com.actelion.research.chem.Coordinates','java.util.Base64','StringBuilder','com.actelion.research.chem.phesa.EncodeFunctions']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Rotation", null, null, 'com.actelion.research.chem.alignment3d.transformation.Transformation');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['m','double[][]']]]

Clazz.newMeth(C$, 'getRotation$',  function () {
return this.m;
});

Clazz.newMeth(C$, 'c$$DAA',  function (m) {
;C$.$init$.apply(this);
this.m=m;
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
C$.c$$DAA.apply(this, [Clazz.array(Double.TYPE, [3, 3])]);
}, 1);

Clazz.newMeth(C$, 'setRotation$DAA',  function (m) {
this.m=m;
});

Clazz.newMeth(C$, 'getInvert$',  function () {
var invert=Clazz.array(Double.TYPE, [3, 3]);
for (var ii=0; ii < 3; ii++) {
for (var jj=0; jj < 3; jj++) {
invert[jj][ii]=this.m[ii][jj];
}
}
return Clazz.new_(C$.c$$DAA,[invert]);
});

Clazz.newMeth(C$, 'apply$com_actelion_research_chem_Coordinates',  function (coords) {
coords.rotate$DAA(this.m);
});

Clazz.newMeth(C$, 'apply$DA',  function (coords) {
Clazz.assert(C$, this, function(){return (coords.length == 3)});
var c=Clazz.new_($I$(1,1).c$$D$D$D,[coords[0], coords[1], coords[2]]);
this.apply$com_actelion_research_chem_Coordinates(c);
coords[0]=c.x;
coords[1]=c.y;
coords[2]=c.z;
});

Clazz.newMeth(C$, 'encode$',  function () {
var encoder=$I$(2).getEncoder$();
var sb=Clazz.new_($I$(3,1));
sb.append$S("r");
sb.append$S(" ");
for (var d, $d = 0, $$d = this.m; $d<$$d.length&&((d=($$d[$d])),1);$d++) {
sb.append$S(encoder.encodeToString$BA($I$(4).doubleArrayToByteArray$DA(d)));
sb.append$S(";");
}
return sb.toString();
});

Clazz.newMeth(C$, 'decode$S',  function (s) {
var str=s.split$S(";");
var r0=$I$(4,"byteArrayToDoubleArray$BA",[$I$(2).getDecoder$().decode$S(str[0])]);
var r1=$I$(4,"byteArrayToDoubleArray$BA",[$I$(2).getDecoder$().decode$S(str[1])]);
var r2=$I$(4,"byteArrayToDoubleArray$BA",[$I$(2).getDecoder$().decode$S(str[2])]);
var rotation=Clazz.array(Double.TYPE, [3, 3]);
rotation[0]=r0;
rotation[1]=r1;
rotation[2]=r2;
return Clazz.new_(C$.c$$DAA,[rotation]);
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:08 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
