(function(){var P$=Clazz.newPackage("jspecview.appletjs"),I$=[[0,'jspecview.app.JSVAppPro']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JSVAppletPro", null, 'jspecview.appletjs.JSVApplet');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['app0','jspecview.app.JSVApp']]]

Clazz.newMeth(C$, 'c$$java_util_Map',  function (viewerOptions) {
;C$.superclazz.c$$java_util_Map.apply(this,[viewerOptions]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'init$',  function () {
this.app=Clazz.new_($I$(1,1).c$$jspecview_api_AppletFrame$Z,[this, false]);
this.initViewer$();
});

Clazz.newMeth(C$, 'isPro$',  function () {
return true;
});

Clazz.newMeth(C$, 'getAppletInfo$',  function () {
return C$.superclazz.prototype.getAppletInfo$.apply(this, []) + " (PRO)";
});

Clazz.newMeth(C$, 'script$S',  function (script) {
this.runScript$S(script);
});

Clazz.newMeth(C$, 'doExitJmol$',  function () {
this.app0.setVisible$Z(true);
this.app=this.app0;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:27 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
