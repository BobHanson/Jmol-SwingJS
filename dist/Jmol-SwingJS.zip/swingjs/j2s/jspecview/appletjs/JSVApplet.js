(function(){var P$=Clazz.newPackage("jspecview.appletjs"),p$1={},I$=[[0,'java.util.Hashtable','jspecview.app.JSVApp','org.jmol.util.Logger','jspecview.js2d.JsMainPanel','javajs.util.PT','jspecview.js2d.JsPanel','java.net.URL']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JSVApplet", null, null, ['jspecview.api.JSVAppletInterface', 'jspecview.api.AppletFrame', 'javajs.api.JSInterface']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.isStandalone=false;
},1);

C$.$fields$=[['Z',['isStandalone'],'O',['app','jspecview.app.JSVApp','viewer','jspecview.common.JSViewer','viewerOptions','java.util.Map','+htParams']]]

Clazz.newMeth(C$, 'c$$java_util_Map',  function (viewerOptions) {
;C$.$init$.apply(this);
if (viewerOptions == null ) viewerOptions=Clazz.new_($I$(1,1));
this.viewerOptions=viewerOptions;
this.htParams=Clazz.new_($I$(1,1));
for (var entry, $entry = viewerOptions.entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) this.htParams.put$O$O(entry.getKey$().toLowerCase$(), entry.getValue$());

this.init$();
}, 1);

Clazz.newMeth(C$, 'init$',  function () {
this.app=Clazz.new_($I$(2,1).c$$jspecview_api_AppletFrame$Z,[this, true]);
this.initViewer$();
if (this.app.appletReadyCallbackFunctionName != null  && this.viewer.fullName != null  ) this.callToJavaScript$S$OA(this.app.appletReadyCallbackFunctionName, Clazz.array(java.lang.Object, -1, [this.viewer.appletName, this.viewer.fullName, Boolean.TRUE, this]));
});

Clazz.newMeth(C$, 'initViewer$',  function () {
this.viewer=this.app.vwr;
p$1.setLogging.apply(this, []);
this.viewerOptions.remove$O("debug");
var o=this.viewerOptions.get$O("display");
{
o = document.getElementById(o);
}
this.viewer.setDisplay$O(o);
$I$(3,"info$S",[this.getAppletInfo$()]);
});

Clazz.newMeth(C$, 'setLogging',  function () {
var iLevel=((p$1.getValue$S$S.apply(this, ["logLevel", (p$1.getBooleanValue$S$Z.apply(this, ["debug", false]) ? "5" : "4")])).charCodeAt$I(0)) - 48;
if (iLevel != 4) System.out.println$S("setting logLevel=" + iLevel + " -- To change, use script \"set logLevel [0-5]\"" );
$I$(3).setLogLevel$I(iLevel);
}, p$1);

Clazz.newMeth(C$, 'getParameter$S',  function (paramName) {
var o=this.htParams.get$O(paramName.toLowerCase$());
return (o == null  ? null :  String.instantialize(o.toString()));
});

Clazz.newMeth(C$, 'getBooleanValue$S$Z',  function (propertyName, defaultValue) {
var value=p$1.getValue$S$S.apply(this, [propertyName, defaultValue ? "true" : ""]);
return (value.equalsIgnoreCase$S("true") || value.equalsIgnoreCase$S("on") || value.equalsIgnoreCase$S("yes")  );
}, p$1);

Clazz.newMeth(C$, 'getValue$S$S',  function (propertyName, defaultValue) {
var stringValue=this.getParameter$S(propertyName);
System.out.println$S("getValue " + propertyName + " = " + stringValue );
if (stringValue != null ) return stringValue;
return defaultValue;
}, p$1);

Clazz.newMeth(C$, 'isPro$',  function () {
return this.app.isPro$();
});

Clazz.newMeth(C$, 'isSigned$',  function () {
return this.app.isSigned$();
});

Clazz.newMeth(C$, 'finalize$',  function () {
System.out.println$S("JSpecView " + this + " finalized" );
});

Clazz.newMeth(C$, 'destroy$',  function () {
this.app.dispose$();
this.app=null;
});

Clazz.newMeth(C$, 'getParameter$S$S',  function (key, def) {
return this.isStandalone ? System.getProperty$S$S(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, 'getAppletInfo$',  function () {
return $I$(2).getAppletInfo$();
});

Clazz.newMeth(C$, 'getSolnColour$',  function () {
return this.app.getSolnColour$();
});

Clazz.newMeth(C$, 'getCoordinate$',  function () {
return this.app.getCoordinate$();
});

Clazz.newMeth(C$, 'loadInline$S',  function (data) {
this.app.loadInline$S(data);
});

Clazz.newMeth(C$, 'export$S$I',  function (type, n) {
return this.app.exportSpectrum$S$I(type, n);
});

Clazz.newMeth(C$, 'exportSpectrum$S$I',  function (type, n) {
return this.app.exportSpectrum$S$I(type, n);
});

Clazz.newMeth(C$, 'setFilePath$S',  function (tmpFilePath) {
this.app.setFilePath$S(tmpFilePath);
});

Clazz.newMeth(C$, 'setSpectrumNumber$I',  function (i) {
this.app.setSpectrumNumber$I(i);
});

Clazz.newMeth(C$, 'toggleGrid$',  function () {
this.app.toggleGrid$();
});

Clazz.newMeth(C$, 'toggleCoordinate$',  function () {
this.app.toggleCoordinate$();
});

Clazz.newMeth(C$, 'togglePointsOnly$',  function () {
this.app.togglePointsOnly$();
});

Clazz.newMeth(C$, 'toggleIntegration$',  function () {
this.app.toggleIntegration$();
});

Clazz.newMeth(C$, 'addHighlight$D$D$I$I$I$I',  function (x1, x2, r, g, b, a) {
this.app.addHighlight$D$D$I$I$I$I(x1, x2, r, g, b, a);
});

Clazz.newMeth(C$, 'removeAllHighlights$',  function () {
this.app.removeAllHighlights$();
});

Clazz.newMeth(C$, 'removeHighlight$D$D',  function (x1, x2) {
this.app.removeHighlight$D$D(x1, x2);
});

Clazz.newMeth(C$, 'reversePlot$',  function () {
this.app.reversePlot$();
});

Clazz.newMeth(C$, 'script$S',  function (script) {
this.app.initParams$S(script);
});

Clazz.newMeth(C$, 'runScript$S',  function (script) {
this.app.runScript$S(script);
});

Clazz.newMeth(C$, 'syncScript$S',  function (peakScript) {
this.app.syncScript$S(peakScript);
});

Clazz.newMeth(C$, 'writeStatus$S',  function (msg) {
this.app.writeStatus$S(msg);
});

Clazz.newMeth(C$, 'getPropertyAsJavaObject$S',  function (key) {
return this.app.getPropertyAsJavaObject$S(key);
});

Clazz.newMeth(C$, 'getPropertyAsJSON$S',  function (key) {
return this.app.getPropertyAsJSON$S(key);
});

Clazz.newMeth(C$, 'runScriptNow$S',  function (script) {
return this.app.runScriptNow$S(script);
});

Clazz.newMeth(C$, 'print$S',  function (fileName) {
return this.app.print$S(fileName);
});

Clazz.newMeth(C$, 'setDropTargetListener$Z$jspecview_common_JSViewer',  function (isSigned, viewer) {
});

Clazz.newMeth(C$, 'validateContent$I',  function (mode) {
});

Clazz.newMeth(C$, 'createMainPanel$jspecview_common_JSViewer',  function (viewer) {
viewer.mainPanel=Clazz.new_($I$(4,1));
});

Clazz.newMeth(C$, 'newWindow$Z',  function (isSelected) {
});

Clazz.newMeth(C$, 'callToJavaScript$S$OA',  function (callback, data) {
var tokens=$I$(5).split$S$S(callback, ".");
{
try{ var o = window[tokens[0]] for (var i = 1; i < tokens.length; i++){ o = o[tokens[i]] } return o(data[0],data[1],data[2],data[3],data[4],data[5],data[6],data[7],data[8],data[9]);
} catch (e) { System.out.println(callback + " failed " + e);
}
}
});

Clazz.newMeth(C$, 'setPanelVisible$Z',  function (b) {
});

Clazz.newMeth(C$, 'getJSVPanel$jspecview_common_JSViewer$javajs_util_Lst',  function (viewer, specs) {
return (specs == null  ? $I$(6).getEmptyPanel$jspecview_common_JSViewer(viewer) : $I$(6).getPanelMany$jspecview_common_JSViewer$javajs_util_Lst(viewer, specs));
});

Clazz.newMeth(C$, 'setVisible$Z',  function (b) {
});

Clazz.newMeth(C$, 'getDocumentBase$',  function () {
try {
return Clazz.new_([null, this.viewerOptions.get$O("documentBase"), null],$I$(7,1).c$$java_net_URL$S$java_net_URLStreamHandler);
} catch (e) {
if (Clazz.exceptionOf(e,"java.net.MalformedURLException")){
return null;
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'repaint$',  function () {
});

Clazz.newMeth(C$, 'validate$',  function () {
});

Clazz.newMeth(C$, 'doExitJmol$',  function () {
});

Clazz.newMeth(C$, 'getApp$',  function () {
return this.app;
});

Clazz.newMeth(C$, 'setStatusDragDropped$I$I$I$S$SA',  function (mode, x, y, fileName, retType) {
return true;
});

Clazz.newMeth(C$, 'cacheFileByName$S$Z',  function (fileName, isAdd) {
return 0;
});

Clazz.newMeth(C$, 'cachePut$S$O',  function (key, data) {
});

Clazz.newMeth(C$, 'getFullName$',  function () {
return this.app.vwr.fullName;
});

Clazz.newMeth(C$, 'processMouseEvent$I$I$I$I$J',  function (id, x, y, modifiers, time) {
return this.app.vwr.processMouseEvent$I$I$I$I$J(id, x, y, modifiers, time);
});

Clazz.newMeth(C$, 'setDisplay$O',  function (canvas) {
this.app.vwr.setDisplay$O(canvas);
});

Clazz.newMeth(C$, 'startHoverWatcher$Z',  function (enable) {
});

Clazz.newMeth(C$, 'update$',  function () {
this.app.vwr.updateJS$();
});

Clazz.newMeth(C$, 'openFile$S',  function (fileName) {
this.app.vwr.openFile$S$Z(fileName, true);
return null;
});

Clazz.newMeth(C$, 'openFileAsyncSpecial$S$I',  function (fileName, flags) {
this.app.vwr.openFileAsyncSpecial$S$I(fileName, flags);
});

Clazz.newMeth(C$, 'openFileAsyncSpecialType$S$I$S',  function (fileName, flags, type) {
this.openFileAsyncSpecial$S$I(fileName, flags);
});

Clazz.newMeth(C$, 'processTwoPointGesture$DAAA',  function (touches) {
this.app.vwr.processTwoPointGesture$DAAA(touches);
});

Clazz.newMeth(C$, 'setScreenDimension$I$I',  function (width, height) {
this.app.vwr.setScreenDimension$I$I(width, height);
});

Clazz.newMeth(C$, 'checkScript$S',  function (script) {
var s=this.app.checkScript$S(script);
if (s != null ) System.out.println$S(s);
return s;
});

Clazz.newMeth(C$, 'processKeyEvent$O',  function (event) {
this.app.vwr.processKeyEvent$O(event);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:27 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
