(function(){var P$=Clazz.newPackage("jspecview.popup"),p$1={},I$=[[0,'jspecview.common.JSViewer','jspecview.common.JSVersion','javajs.util.PT','jspecview.popup.JSVPopupResourceBundle']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JSVGenericPopup", null, 'org.jmol.popup.GenericPopup', 'jspecview.api.JSVPopupMenu');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['allowMenu','zoomEnabled'],'I',['updateMode','aboutComputedMenuBaseCount'],'O',['vwr','jspecview.common.JSViewer','cnmrPeaks','javajs.util.Lst','+hnmrPeaks','pd','jspecview.common.PanelData','thisJsvp','jspecview.api.JSVPanel']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'initialize$jspecview_common_JSViewer$org_jmol_popup_PopupResource$S',  function (viewer, bundle, title) {
this.vwr=viewer;
this.initSwing$S$org_jmol_popup_PopupResource$O$Z$Z$Z(title, bundle, viewer.getApplet$(), $I$(1).isJS, viewer.isSigned, false);
});

Clazz.newMeth(C$, 'jpiDispose$',  function () {
this.helper.menuClearListeners$org_jmol_api_SC(this.popupMenu);
this.popupMenu=this.thisPopup=null;
});

Clazz.newMeth(C$, 'jpiGetMenuAsObject$',  function () {
return this.popupMenu;
});

Clazz.newMeth(C$, 'jpiShow$I$I',  function (x, y) {
this.show$I$I$Z(x, y, false);
this.appRestorePopupMenu$();
this.menuShowPopup$org_jmol_api_SC$I$I(this.popupMenu, this.thisx, this.thisy);
});

Clazz.newMeth(C$, 'jpiUpdateComputedMenus$',  function () {
if (this.updateMode == -1) return;
this.updateMode=0;
p$1.getViewerData.apply(this, []);
p$1.updateFileMenu.apply(this, []);
p$1.updateFileTypeDependentMenus.apply(this, []);
this.updateMode=1;
p$1.updateAboutSubmenu.apply(this, []);
});

Clazz.newMeth(C$, 'appCheckItem$S$org_jmol_api_SC',  function (item, newMenu) {
});

Clazz.newMeth(C$, 'appFixLabel$S',  function (label) {
if (label.startsWith$S("_")) label=label.substring$I(label.indexOf$S$I("_", 2) + 1);
 else if (label.equals$O("VERSION")) label=$I$(2).VERSION;
label=$I$(3).rep$S$S$S(label, "JAVA", "");
label=$I$(3).rep$S$S$S(label, "CB", "");
label=$I$(3).rep$S$S$S(label, "Menu", "");
label=$I$(3).rep$S$S$S(label, "_", " ");
return label;
});

Clazz.newMeth(C$, 'getScriptForCallback$org_jmol_api_SC$S$S',  function (source, id, script) {
return script;
});

Clazz.newMeth(C$, 'appGetMenuAsString$S',  function (title) {
return (Clazz.new_($I$(4,1))).getMenuAsText$S(title);
});

Clazz.newMeth(C$, 'appGetBooleanProperty$S',  function (name) {
return false;
});

Clazz.newMeth(C$, 'appRunSpecialCheckBox$org_jmol_api_SC$S$S$Z',  function (item, basename, what, TF) {
return false;
});

Clazz.newMeth(C$, 'appRestorePopupMenu$',  function () {
this.thisPopup=this.popupMenu;
});

Clazz.newMeth(C$, 'appRunScript$S',  function (script) {
this.vwr.runScript$S(script);
});

Clazz.newMeth(C$, 'appUpdateForShow$',  function () {
this.thisJsvp=this.vwr.selectedPanel;
p$1.setEnables$jspecview_api_JSVPanel.apply(this, [this.thisJsvp]);
if (this.updateMode == -1) return;
p$1.getViewerData.apply(this, []);
this.updateMode=2;
p$1.updateSpectraMenu.apply(this, []);
p$1.updateAboutSubmenu.apply(this, []);
});

Clazz.newMeth(C$, 'appUpdateSpecialCheckBoxValue$org_jmol_api_SC$S$Z',  function (item, what, TF) {
});

Clazz.newMeth(C$, 'getViewerData',  function () {
}, p$1);

Clazz.newMeth(C$, 'updateFileTypeDependentMenus',  function () {
}, p$1);

Clazz.newMeth(C$, 'updateFileMenu',  function () {
var menu=this.htMenus.get$O("fileMenu");
if (menu == null ) return;
}, p$1);

Clazz.newMeth(C$, 'updateSpectraMenu',  function () {
var menuh=this.htMenus.get$O("hnmrMenu");
var menuc=this.htMenus.get$O("cnmrMenu");
if (menuh != null ) this.menuRemoveAll$org_jmol_api_SC$I(menuh, 0);
if (menuc != null ) this.menuRemoveAll$org_jmol_api_SC$I(menuc, 0);
var menu=this.htMenus.get$O("spectraMenu");
if (menu == null ) return;
this.menuRemoveAll$org_jmol_api_SC$I(menu, 0);
var isOK=!!(p$1.setSpectraMenu$org_jmol_api_SC$javajs_util_Lst.apply(this, [menuh, this.hnmrPeaks]) | p$1.setSpectraMenu$org_jmol_api_SC$javajs_util_Lst.apply(this, [menuc, this.cnmrPeaks]));
if (isOK) {
if (menuh != null ) this.menuAddSubMenu$org_jmol_api_SC$org_jmol_api_SC(menu, menuh);
if (menuc != null ) this.menuAddSubMenu$org_jmol_api_SC$org_jmol_api_SC(menu, menuc);
}this.menuEnable$org_jmol_api_SC$Z(menu, isOK);
}, p$1);

Clazz.newMeth(C$, 'setSpectraMenu$org_jmol_api_SC$javajs_util_Lst',  function (menu, peaks) {
if (menu == null ) return false;
this.menuEnable$org_jmol_api_SC$Z(menu, false);
var n=(peaks == null  ? 0 : peaks.size$());
if (n == 0) return false;
for (var i=0; i < n; i++) {
var peak=peaks.get$I(i);
var title=$I$(3).getQuotedAttribute$S$S(peak, "title");
var atoms=$I$(3).getQuotedAttribute$S$S(peak, "atoms");
if (atoms != null ) this.menuCreateItem$org_jmol_api_SC$S$S$S(menu, title, "select visible & (@" + $I$(3).rep$S$S$S(atoms, ",", " or @") + ")" , "Focus" + i);
}
this.menuEnable$org_jmol_api_SC$Z(menu, true);
return true;
}, p$1);

Clazz.newMeth(C$, 'updateAboutSubmenu',  function () {
var menu=this.htMenus.get$O("aboutComputedMenu");
if (menu == null ) return;
this.menuRemoveAll$org_jmol_api_SC$I(menu, this.aboutComputedMenuBaseCount);
}, p$1);

Clazz.newMeth(C$, 'getSelected$S',  function (key) {
return false;
});

Clazz.newMeth(C$, 'setCompoundMenu$javajs_util_Lst$Z',  function (panelNodes, allowCompoundMenu) {
});

Clazz.newMeth(C$, 'setEnabled$Z$Z',  function (allowMenu, zoomEnabled) {
this.allowMenu=allowMenu;
this.zoomEnabled=zoomEnabled;
p$1.enableMenus.apply(this, []);
});

Clazz.newMeth(C$, 'enableMenus',  function () {
p$1.setItemEnabled$S$Z.apply(this, ["_SIGNED_FileMenu", this.allowMenu]);
p$1.setItemEnabled$S$Z.apply(this, ["ViewMenu", this.pd != null  && this.allowMenu ]);
p$1.setItemEnabled$S$Z.apply(this, ["Open_File...", this.allowMenu]);
p$1.setItemEnabled$S$Z.apply(this, ["Open_Simulation...", this.allowMenu]);
p$1.setItemEnabled$S$Z.apply(this, ["Open_URL...", this.allowMenu]);
p$1.setItemEnabled$S$Z.apply(this, ["Save_AsMenu", this.pd != null  && this.allowMenu ]);
p$1.setItemEnabled$S$Z.apply(this, ["Export_AsMenu", this.pd != null  && this.allowMenu ]);
p$1.setItemEnabled$S$Z.apply(this, ["Append_File...", this.pd != null  && this.allowMenu ]);
p$1.setItemEnabled$S$Z.apply(this, ["Append_Simulation...", this.pd != null  && this.allowMenu ]);
p$1.setItemEnabled$S$Z.apply(this, ["Append_URL...", this.pd != null  && this.allowMenu ]);
p$1.setItemEnabled$S$Z.apply(this, ["Views...", this.pd != null  && this.allowMenu ]);
p$1.setItemEnabled$S$Z.apply(this, ["Script", this.allowMenu]);
p$1.setItemEnabled$S$Z.apply(this, ["Print...", this.pd != null  && this.allowMenu ]);
p$1.setItemEnabled$S$Z.apply(this, ["ZoomMenu", this.pd != null  && this.zoomEnabled ]);
}, p$1);

Clazz.newMeth(C$, 'setEnables$jspecview_api_JSVPanel',  function (jsvp) {
this.pd=(jsvp == null  ? null : jsvp.getPanelData$());
var spec0=(this.pd == null  ? null : this.pd.getSpectrum$());
var isOverlaid=this.pd != null  && this.pd.isShowAllStacked$() ;
var isSingle=this.pd != null  && this.pd.haveSelectedSpectrum$() ;
p$1.setItemEnabled$S$Z.apply(this, ["Integration", this.pd != null  && this.pd.getSpectrum$().canIntegrate$() ]);
p$1.setItemEnabled$S$Z.apply(this, ["Measurements", true]);
p$1.setItemEnabled$S$Z.apply(this, ["Peaks", this.pd != null  && this.pd.getSpectrum$().is1D$() ]);
p$1.setItemEnabled$S$Z.apply(this, ["Predicted_Solution_Colour_(fitted)", isSingle && spec0.canShowSolutionColor$() ]);
p$1.setItemEnabled$S$Z.apply(this, ["Predicted_Solution_Colour_(interpolated)", isSingle && spec0.canShowSolutionColor$() ]);
p$1.setItemEnabled$S$Z.apply(this, ["Toggle_Trans/Abs", isSingle && spec0.canConvertTransAbs$() ]);
p$1.setItemEnabled$S$Z.apply(this, ["Show_Overlay_Key", isOverlaid && this.pd.getNumberOfGraphSets$() == 1 ]);
p$1.setItemEnabled$S$Z.apply(this, ["Overlay_Offset...", isOverlaid]);
p$1.setItemEnabled$S$Z.apply(this, ["JDXMenu", this.pd != null  && spec0.canSaveAsJDX$() ]);
p$1.setItemEnabled$S$Z.apply(this, ["Export_AsMenu", this.pd != null ]);
p$1.enableMenus.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'setItemEnabled$S$Z',  function (key, TF) {
this.menuEnable$org_jmol_api_SC$Z(this.htMenus.get$O(key), TF);
}, p$1);

Clazz.newMeth(C$, 'setSelected$S$Z',  function (key, TF) {
var item=this.htMenus.get$O(key);
if (item == null  || item.isSelected$() == TF  ) return;
this.menuEnable$org_jmol_api_SC$Z(item, false);
item.setSelected$Z(TF);
this.menuEnable$org_jmol_api_SC$Z(item, true);
});

Clazz.newMeth(C$, 'getUnknownCheckBoxScriptToRun$org_jmol_api_SC$S$S$Z',  function (item, name, what, TF) {
return null;
});
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:29 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
