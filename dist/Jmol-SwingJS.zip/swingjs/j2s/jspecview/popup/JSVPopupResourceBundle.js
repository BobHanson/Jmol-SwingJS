(function(){var P$=Clazz.newPackage("jspecview.popup"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "JSVPopupResourceBundle", null, 'org.jmol.popup.PopupResource');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['menuContents','String[][]','+structureContents']]]

Clazz.newMeth(C$, 'getMenuName$',  function () {
return "appMenu";
});

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$S$java_util_Properties.apply(this,[null, null]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'buildStructure$S',  function (menuStructure) {
this.addItems$SAA(C$.menuContents);
this.addItems$SAA(C$.structureContents);
if (menuStructure != null ) this.setStructure$S$org_jmol_api_Translator(menuStructure, null);
});

Clazz.newMeth(C$, 'getWordContents$',  function () {
return Clazz.array(String, -1, []);
});

Clazz.newMeth(C$, 'getMenuAsText$S',  function (title) {
return this.getStuctureAsText$S$SAA$SAA(title, C$.menuContents, C$.structureContents);
});

C$.$static$=function(){C$.$static$=0;
C$.menuContents=Clazz.array(String, -2, [Clazz.array(String, -1, ["appMenu", "_SIGNED_FileMenu Spectra... ShowMenu OptionsMenu ZoomMenu - Integration Peaks Measurements - Script... Properties"]), Clazz.array(String, -1, ["appletMenu", "_SIGNED_FileMenu Spectra... - OptionsMenu ZoomMenu - Integration Peaks Measurements - Script... - Print... - AboutMenu"]), Clazz.array(String, -1, ["_SIGNED_FileMenu", "Open_File... Open_Simulation... Open_URL... - Add_File... Add_Simulation... Add_URL... - Save_AsMenu Export_AsMenu - Close_Views Close_Simulations Close_All"]), Clazz.array(String, -1, ["Save_AsMenu", "Original... JDXMenu CML XML(AnIML)"]), Clazz.array(String, -1, ["JDXMenu", "XY DIF DIFDUP FIX PAC SQZ"]), Clazz.array(String, -1, ["Export_AsMenu", "PDF - JPG PNG SVG"]), Clazz.array(String, -1, ["ShowMenu", "Show_Header Show_Source Show_Overlay_Key"]), Clazz.array(String, -1, ["OptionsMenu", "Toggle_Grid Toggle_X_Axis Toggle_Y_Axis Toggle_Coordinates Toggle_Trans/Abs Reverse_Plot - Predicted_Solution_Colour Fill_Solution_Colour_(all)  Fill_Solution_Colour_(none)"]), Clazz.array(String, -1, ["ZoomMenu", "Next_Zoom Previous_Zoom Reset_Zoom - Set_X_Scale... Reset_X_Scale"]), Clazz.array(String, -1, ["AboutMenu", "VERSION"])]);
C$.structureContents=Clazz.array(String, -2, [Clazz.array(String, -1, ["Open_File...", "load ?"]), Clazz.array(String, -1, ["Open_URL...", "load http://?"]), Clazz.array(String, -1, ["Open_Simulation...", "load $?"]), Clazz.array(String, -1, ["Add_File...", "load append ?"]), Clazz.array(String, -1, ["Add_URL...", "load append http://?"]), Clazz.array(String, -1, ["Add_Simulation...", "load append $?; view \"1HNMR\""]), Clazz.array(String, -1, ["Close_All", "close all"]), Clazz.array(String, -1, ["Close_Views", "close views"]), Clazz.array(String, -1, ["Close Simulations", "close simulations"]), Clazz.array(String, -1, ["Show_Header", "showProperties"]), Clazz.array(String, -1, ["Show_Source", "showSource"]), Clazz.array(String, -1, ["Show_Overlay_Key...", "showKey"]), Clazz.array(String, -1, ["Next_Zoom", "zoom next;showMenu"]), Clazz.array(String, -1, ["Previous_Zoom", "zoom prev;showMenu"]), Clazz.array(String, -1, ["Reset_Zoom", "zoom clear"]), Clazz.array(String, -1, ["Reset_X_Scale", "zoom out"]), Clazz.array(String, -1, ["Set_X_Scale...", "zoom"]), Clazz.array(String, -1, ["Spectra...", "view"]), Clazz.array(String, -1, ["Overlay_Offset...", "stackOffsetY"]), Clazz.array(String, -1, ["Script...", "script INLINE"]), Clazz.array(String, -1, ["Properties", "showProperties"]), Clazz.array(String, -1, ["Toggle_X_Axis", "XSCALEON toggle;showMenu"]), Clazz.array(String, -1, ["Toggle_Y_Axis", "YSCALEON toggle;showMenu"]), Clazz.array(String, -1, ["Toggle_Grid", "GRIDON toggle;showMenu"]), Clazz.array(String, -1, ["Toggle_Coordinates", "COORDINATESON toggle;showMenu"]), Clazz.array(String, -1, ["Reverse_Plot", "REVERSEPLOT toggle;showMenu"]), Clazz.array(String, -1, ["Measurements", "SHOWMEASUREMENTS"]), Clazz.array(String, -1, ["Peaks", "SHOWPEAKLIST"]), Clazz.array(String, -1, ["Integration", "SHOWINTEGRATION"]), Clazz.array(String, -1, ["Toggle_Trans/Abs", "IRMODE TOGGLE"]), Clazz.array(String, -1, ["Predicted_Solution_Colour", "GETSOLUTIONCOLOR"]), Clazz.array(String, -1, ["Fill_Solution_Colour_(all)", "GETSOLUTIONCOLOR fillall"]), Clazz.array(String, -1, ["Fill_Solution_Colour_(none)", "GETSOLUTIONCOLOR fillallnone"]), Clazz.array(String, -1, ["Print...", "print"]), Clazz.array(String, -1, ["Original...", "write SOURCE"]), Clazz.array(String, -1, ["CML", "write CML"]), Clazz.array(String, -1, ["XML(AnIML)", "write XML"]), Clazz.array(String, -1, ["XY", "write XY"]), Clazz.array(String, -1, ["DIF", "write DIF"]), Clazz.array(String, -1, ["DIFDUP", "write DIFDUP"]), Clazz.array(String, -1, ["FIX", "write FIX"]), Clazz.array(String, -1, ["PAC", "write PAC"]), Clazz.array(String, -1, ["SQZ", "write SQZ"]), Clazz.array(String, -1, ["JPG", "write JPG"]), Clazz.array(String, -1, ["SVG", "write SVG"]), Clazz.array(String, -1, ["PNG", "write PNG"]), Clazz.array(String, -1, ["PDF", "write PDF"])]);
};
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:07 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
