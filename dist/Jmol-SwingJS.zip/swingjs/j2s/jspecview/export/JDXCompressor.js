(function(){var P$=Clazz.newPackage("jspecview.export"),I$=[[0,'javajs.util.SB','org.jmol.util.Logger','jspecview.export.Exporter','javajs.util.DF']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JDXCompressor");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'compressDIF$jspecview_common_CoordinateA$I$I$I$D$D$Z',  function (xyCoords, startIndex, endIndex, step, xFactor, yFactor, isDIFDUP) {
var yStr=Clazz.new_($I$(1,1));
var buffer=Clazz.new_($I$(1,1));
for (var i=startIndex; i != endIndex; ) {
buffer.append$S(C$.fixIntNoExponent$D(xyCoords[i].getXVal$() / xFactor));
yStr.setLength$I(0);
if ($I$(2).debugging) $I$(2,"info$S",["" + i + '\t' + new Double(xyCoords[i].getXVal$()).toString() + '\t' + new Double(xyCoords[i].getYVal$()).toString() ]);
var y1=Math.round$D(xyCoords[i].getYVal$() / yFactor);
yStr.append$S(C$.makeSQZ$J(y1));
var lastDif="";
var nDif=0;
i+=step;
if (i == endIndex) {
i-=step;
} else {
while (i + step != endIndex && yStr.length$() < 50 ){
var y2=Math.round$D(xyCoords[i].getYVal$() / yFactor);
var temp=C$.makeDIF$J(Long.$sub(y2,y1));
if (isDIFDUP && temp.equals$O(lastDif) ) {
++nDif;
} else {
lastDif=temp;
if (nDif > 0) {
yStr.append$S(C$.makeDUP$J(nDif + 1));
nDif=0;
}yStr.append$S(temp);
}if ($I$(2).debugging) $I$(2,"info$S",["" + i + '\t' + new Double(xyCoords[i].getXVal$()).toString() + '\t' + new Double(xyCoords[i].getYVal$()).toString() + '\t' + Long.$s(y2) + '\t' + nDif + '\t' + yStr ]);
y1=y2;
i+=step;
}
if (nDif > 0) yStr.append$S(C$.makeDUP$J(nDif + 1));
yStr.append$S(C$.makeSQZ$jspecview_common_Coordinate$D(xyCoords[i], yFactor));
if ($I$(2).debugging) $I$(2,"info$S",["" + i + '\t' + new Double(xyCoords[i].getXVal$()).toString() + '\t' + new Double(xyCoords[i].getYVal$()).toString() + '\t' + nDif + '\t' + yStr ]);
}buffer.append$S(yStr.toString()).append$S($I$(3).newLine);
i+=step;
}
buffer.append$S(C$.fixIntNoExponent$D(xyCoords[endIndex].getXVal$() / xFactor)).append$S(C$.makeSQZ$jspecview_common_Coordinate$D(xyCoords[endIndex], yFactor));
buffer.append$S("  $$checkpoint").append$S($I$(3).newLine);
return buffer.toString();
}, 1);

Clazz.newMeth(C$, 'compressFIX$jspecview_common_CoordinateA$I$I$I$D$D',  function (xyCoords, startIndex, endIndex, step, xFactor, yFactor) {
endIndex+=step;
var buffer=Clazz.new_($I$(1,1));
for (var i=startIndex; i != endIndex; ) {
C$.leftJustify$javajs_util_SB$S$S(buffer, "              ", C$.fixIntNoExponent$D(xyCoords[i].getXVal$() / xFactor));
for (var j=0; j < 6 && i != endIndex ; j++) {
C$.rightJustify$javajs_util_SB$S$S(buffer, "          ", "" + Long.$s(Math.round$D(xyCoords[i].getYVal$() / yFactor)));
buffer.append$S(" ");
i+=step;
}
buffer.append$S($I$(3).newLine);
}
return buffer.toString();
}, 1);

Clazz.newMeth(C$, 'leftJustify$javajs_util_SB$S$S',  function (s, s1, s2) {
s.append$S(s2);
var n=s1.length$() - s2.length$();
if (n > 0) s.append$S(s1.substring$I$I(0, n));
}, 1);

Clazz.newMeth(C$, 'rightJustify$javajs_util_SB$S$S',  function (s, s1, s2) {
var n=s1.length$() - s2.length$();
if (n > 0) s.append$S(s1.substring$I$I(0, n));
s.append$S(s2);
}, 1);

Clazz.newMeth(C$, 'compressSQZ$jspecview_common_CoordinateA$I$I$I$D$D',  function (xyCoords, startIndex, endIndex, step, xFactor, yFactor) {
var yStr=Clazz.new_($I$(1,1));
endIndex+=step;
var buffer=Clazz.new_($I$(1,1));
for (var i=startIndex; i == startIndex || i != endIndex ; ) {
buffer.append$S(C$.fixIntNoExponent$D(xyCoords[i].getXVal$() / xFactor));
yStr.setLength$I(0);
yStr.append$S(C$.makeSQZ$jspecview_common_Coordinate$D(xyCoords[i], yFactor));
i+=step;
while ((yStr.length$() < 60) && i != endIndex ){
yStr.append$S(C$.makeSQZ$jspecview_common_Coordinate$D(xyCoords[i], yFactor));
i+=step;
}
buffer.append$S(yStr.toString()).append$S($I$(3).newLine);
}
return buffer.toString();
}, 1);

Clazz.newMeth(C$, 'compressPAC$jspecview_common_CoordinateA$I$I$I$D$D',  function (xyCoords, startIndex, endIndex, step, xFactor, yFactor) {
var buffer=Clazz.new_($I$(1,1));
endIndex+=step;
for (var i=startIndex; i != endIndex; ) {
buffer.append$S(C$.fixIntNoExponent$D(xyCoords[i].getXVal$() / xFactor)).append$S(C$.fixPacY$D(xyCoords[i].getYVal$() / yFactor));
i+=step;
for (var j=0; j < 4 && i != endIndex ; j++) {
buffer.append$S(C$.fixPacY$D(xyCoords[i].getYVal$() / yFactor));
i+=step;
}
buffer.append$S($I$(3).newLine);
}
return buffer.toString();
}, 1);

Clazz.newMeth(C$, 'fixPacY$D',  function (y) {
return (y < 0  ? "" : " ") + C$.fixIntNoExponent$D(y);
}, 1);

Clazz.newMeth(C$, 'makeSQZ$jspecview_common_Coordinate$D',  function (pt, yFactor) {
return C$.makeSQZ$J(Math.round$D(pt.getYVal$() / yFactor));
}, 1);

Clazz.newMeth(C$, 'makeSQZ$J',  function (y) {
return C$.compress$J$S$S(y, "@ABCDEFGHI", "abcdefghi");
}, 1);

Clazz.newMeth(C$, 'makeDIF$J',  function (dy) {
return C$.compress$J$S$S(dy, "%JKLMNOPQR", "jklmnopqr");
}, 1);

Clazz.newMeth(C$, 'makeDUP$J',  function (y) {
return C$.compress$J$S$S(y, "0STUVWXYZs", "");
}, 1);

Clazz.newMeth(C$, 'compress$J$S$S',  function (y, strPos, strNeg) {
var negative=false;
var yStr=String.valueOf$J(y);
var ch=yStr.charAt$I(0);
if (ch == "-") {
negative=true;
yStr=yStr.substring$I(1);
ch=yStr.charAt$I(0);
}var yStrArray=yStr.toCharArray$();
yStrArray[0]=(negative ? strNeg.charAt$I(ch.$c() - 49) : strPos.charAt$I(ch.$c() - 48));
return  String.instantialize(yStrArray);
}, 1);

Clazz.newMeth(C$, 'getXYList$jspecview_common_CoordinateA$I$I$I',  function (xyCoords, startIndex, endIndex, step) {
endIndex+=step;
var buffer=Clazz.new_($I$(1,1));
for (var i=startIndex; i != endIndex; i+=step) {
var point=xyCoords[i];
buffer.append$S(C$.fixIntNoExponent$D(point.getXVal$())).append$S(", ").append$S(C$.fixIntNoExponent$D(point.getYVal$())).append$S($I$(3).newLine);
}
return buffer.toString();
}, 1);

Clazz.newMeth(C$, 'fixIntNoExponent$D',  function (x) {
return (x == Math.floor(x)  ? String.valueOf$I((x|0)) : $I$(4).formatDecimalTrimmed$D$I(x, 10));
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:06 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
