(function(){var P$=Clazz.newPackage("jspecview.export");
/*c*/var C$=Clazz.newClass(P$, "CMLExporter", null, 'jspecview.export.XMLExporter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'exportTheSpectrum$jspecview_common_JSViewer$jspecview_common_ExportType$javajs_util_OC$jspecview_common_Spectrum$I$I$jspecview_common_PanelData$Z',  function (viewer, mode, out, spec, startIndex, endIndex, pd, asBase64) {
if (!this.setup$jspecview_common_JSViewer$jspecview_common_Spectrum$javajs_util_OC$I$I(viewer, spec, out, startIndex, endIndex)) return null;
if (this.model == null  || this.model.equals$O("") ) this.model="unknown";
if (this.datatype.contains$CharSequence("MASS")) this.spectypeInitials="massSpectrum";
 else if (this.datatype.contains$CharSequence("INFRARED")) {
this.spectypeInitials="infrared";
} else if (this.datatype.contains$CharSequence("UV") || (this.datatype.contains$CharSequence("VIS")) ) {
this.spectypeInitials="UV/VIS";
} else if (this.datatype.contains$CharSequence("NMR")) {
this.spectypeInitials="NMR";
}this.ident=this.spectypeInitials + "_" + this.title.substring$I$I(0, Math.min(10, this.title.length$())) ;
if (this.xUnits.toLowerCase$().equals$O("m/z")) this.xUnits="moverz";
 else if (this.xUnits.toLowerCase$().equals$O("1/cm")) this.xUnits="cm-1";
 else if (this.xUnits.toLowerCase$().equals$O("nanometers")) this.xUnits="nm";
this.setContext$();
return this.writeFormType$S("cml");
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:29 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
