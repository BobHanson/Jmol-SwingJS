(function(){var P$=Clazz.newPackage("jspecview.export"),p$1={},I$=[[0,'javajs.util.PT','jspecview.common.ExportType','jspecview.common.JSViewer','javajs.util.OC','jspecview.common.JSVFileManager']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Exporter", null, null, 'jspecview.api.ExportInterface');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['S',['newLine']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'write$jspecview_common_JSViewer$javajs_util_Lst$Z',  function (viewer, tokens, forInkscape) {
if (tokens == null ) return p$1.printPDF$jspecview_common_JSViewer$S$Z.apply(this, [viewer, null, false]);
var type=null;
var fileName=null;
var eType;
var out;
var jsvp=viewer.selectedPanel;
try {
switch (tokens.size$()) {
default:
return "WRITE what?";
case 1:
fileName=$I$(1,"trimQuotes$S",[tokens.get$I(0)]);
if (fileName.indexOf$S(".") >= 0) type="XY";
if (jsvp == null ) return null;
eType=$I$(2).getType$S(fileName);
switch (eType) {
case $I$(2).PDF:
case $I$(2).PNG:
case $I$(2).JPG:
return this.exportTheSpectrum$jspecview_common_JSViewer$jspecview_common_ExportType$javajs_util_OC$jspecview_common_Spectrum$I$I$jspecview_common_PanelData$Z(viewer, eType, null, null, -1, -1, null, false);
default:
viewer.fileHelper.setFileChooser$jspecview_common_ExportType(eType);
var items=p$1.getExportableItems$jspecview_common_JSViewer$Z.apply(this, [viewer, eType.equals$O($I$(2).SOURCE)]);
var index=(items == null  ? -1 : viewer.getOptionFromDialog$SA$S$S(items, "Export", "Choose a spectrum to export"));
if (index == -2147483648) return null;
var file=viewer.fileHelper.getFile$S$O$Z(p$1.getSuggestedFileName$jspecview_common_JSViewer$jspecview_common_ExportType.apply(this, [viewer, eType]), jsvp, true);
if (file == null ) return null;
out=viewer.getOutputChannel$S$Z(file.getFullPath$(), false);
var msg=p$1.exportSpectrumOrImage$jspecview_common_JSViewer$jspecview_common_ExportType$I$javajs_util_OC.apply(this, [viewer, eType, index, out]);
var isOK=msg.startsWith$S("OK");
if (isOK) viewer.si.siUpdateRecentMenus$S(file.getFullPath$());
out.closeChannel$();
return msg;
}
case 2:
type=tokens.get$I(0).toUpperCase$();
fileName=$I$(1,"trimQuotes$S",[tokens.get$I(1)]);
break;
}
var ext=fileName.substring$I(fileName.lastIndexOf$S(".") + 1).toUpperCase$();
if (ext.equals$O("BASE64")) {
fileName=";base64,";
} else if (ext.equals$O("JDX")) {
if (type == null ) type="XY";
} else if ($I$(2).isExportMode$S(ext)) {
type=ext;
} else if ($I$(2).isExportMode$S(type)) {
fileName+="." + type;
}eType=$I$(2).getType$S(type);
if (forInkscape && eType === $I$(2).SVG  ) eType=$I$(2).SVGI;
out=viewer.getOutputChannel$S$Z(fileName, false);
return p$1.exportSpectrumOrImage$jspecview_common_JSViewer$jspecview_common_ExportType$I$javajs_util_OC.apply(this, [viewer, eType, -1, out]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$O(e);
return null;
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'exportSpectrumOrImage$jspecview_common_JSViewer$jspecview_common_ExportType$I$javajs_util_OC',  function (viewer, eType, index, out) {
var spec;
var pd=viewer.pd$();
if (index < 0 && (index=pd.getCurrentSpectrumIndex$()) < 0 ) return "Error exporting spectrum: No spectrum selected";
spec=pd.getSpectrumAt$I(index);
var startIndex=pd.getStartingPointIndex$I(index);
var endIndex=pd.getEndingPointIndex$I(index);
var msg=null;
try {
var asBase64=out.isBase64$();
msg=this.exportTheSpectrum$jspecview_common_JSViewer$jspecview_common_ExportType$javajs_util_OC$jspecview_common_Spectrum$I$I$jspecview_common_PanelData$Z(viewer, eType, out, spec, startIndex, endIndex, pd, asBase64);
if (asBase64) return msg;
if (msg.startsWith$S("OK")) return "OK - Exported " + eType.name$() + ": " + out.getFileName$() + msg.substring$I(2) ;
} catch (ioe) {
if (Clazz.exceptionOf(ioe,"Exception")){
msg=ioe.toString();
} else {
throw ioe;
}
}
return "Error exporting " + out.getFileName$() + ": " + msg ;
}, p$1);

Clazz.newMeth(C$, 'exportTheSpectrum$jspecview_common_JSViewer$jspecview_common_ExportType$javajs_util_OC$jspecview_common_Spectrum$I$I$jspecview_common_PanelData$Z',  function (viewer, mode, out, spec, startIndex, endIndex, pd, asBase64) {
var jsvp=viewer.selectedPanel;
var type=mode.name$();
switch (mode) {
case $I$(2).AML:
case $I$(2).CML:
case $I$(2).SVG:
case $I$(2).SVGI:
break;
case $I$(2).DIF:
case $I$(2).DIFDUP:
case $I$(2).FIX:
case $I$(2).PAC:
case $I$(2).SQZ:
case $I$(2).XY:
type="JDX";
break;
case $I$(2).JPG:
case $I$(2).PNG:
if (jsvp == null ) return null;
viewer.fileHelper.setFileChooser$jspecview_common_ExportType(mode);
var name=p$1.getSuggestedFileName$jspecview_common_JSViewer$jspecview_common_ExportType.apply(this, [viewer, mode]);
var file=viewer.fileHelper.getFile$S$O$Z(name, jsvp, true);
if (file == null ) return null;
return jsvp.saveImage$S$org_jmol_api_GenericFileInterface$javajs_util_OC(type.toLowerCase$(), file, out);
case $I$(2).PDF:
return p$1.printPDF$jspecview_common_JSViewer$S$Z.apply(this, [viewer, "PDF", asBase64]);
case $I$(2).SOURCE:
if (jsvp == null ) return null;
var data=jsvp.getPanelData$().getSpectrum$().getInlineData$();
if (data != null ) {
out.append$S(data);
out.closeChannel$();
return "OK " + out.getByteCount$() + " bytes" ;
}var path=jsvp.getPanelData$().getSpectrum$().getFilePath$();
return C$.fileCopy$S$javajs_util_OC(path, out);
case $I$(2).UNK:
return null;
}
return ($I$(3,"getInterface$S",["jspecview.export." + type.toUpperCase$() + "Exporter" ])).exportTheSpectrum$jspecview_common_JSViewer$jspecview_common_ExportType$javajs_util_OC$jspecview_common_Spectrum$I$I$jspecview_common_PanelData$Z(viewer, mode, out, spec, startIndex, endIndex, null, false);
});

Clazz.newMeth(C$, 'printPDF$jspecview_common_JSViewer$S$Z',  function (viewer, pdfFileName, isBase64) {
var isJob=(pdfFileName == null  || pdfFileName.length$() == 0 );
if (!isBase64 && !viewer.si.isSigned$() ) return "Error: Applet must be signed for the PRINT command.";
var pd=viewer.pd$();
if (pd == null ) return null;
var useDialog=false;
var pl;
{
useDialog = false;
}
pl=viewer.getDialogPrint$Z(isJob);
if (pl == null ) return null;
if (!useDialog) pl.asPDF=true;
if (isJob && pl.asPDF ) {
isJob=false;
pdfFileName="PDF";
}var jsvp=viewer.selectedPanel;
if (!isBase64 && !isJob ) {
var helper=viewer.fileHelper;
helper.setFileChooser$jspecview_common_ExportType($I$(2).PDF);
if (pdfFileName.equals$O("?") || pdfFileName.equalsIgnoreCase$S("PDF") ) pdfFileName=p$1.getSuggestedFileName$jspecview_common_JSViewer$jspecview_common_ExportType.apply(this, [viewer, $I$(2).PDF]);
var file=helper.getFile$S$O$Z(pdfFileName, jsvp, true);
if (file == null ) return null;
if (!$I$(3).isJS) viewer.setProperty$S$S("directoryLastExportedFile", helper.setDirLastExported$S(file.getParentAsFile$().getFullPath$()));
pdfFileName=file.getFullPath$();
}var s=null;
try {
var out=(isJob ? null : isBase64 ? Clazz.new_($I$(4,1)).setParams$javajs_api_BytePoster$S$Z$java_io_OutputStream(null, ";base64,", false, null) : viewer.getOutputChannel$S$Z(pdfFileName, true));
var printJobTitle=pd.getPrintJobTitle$Z(true);
if (pl.showTitle) {
printJobTitle=jsvp.getInput$S$S$S("Title?", "Title for Printing", printJobTitle);
if (printJobTitle == null ) return null;
}jsvp.printPanel$jspecview_common_PrintLayout$java_io_OutputStream$S(pl, out, printJobTitle);
s=out.toString();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
jsvp.showMessage$S$S(e.toString(), "File Error");
} else {
throw e;
}
}
return s;
}, p$1);

Clazz.newMeth(C$, 'getExportableItems$jspecview_common_JSViewer$Z',  function (viewer, isSameType) {
var pd=viewer.pd$();
var isView=viewer.currentSource.isView;
var nSpectra=pd.getNumberOfSpectraInCurrentSet$();
if (nSpectra == 1 || !isView && isSameType   || pd.getCurrentSpectrumIndex$() >= 0 ) return null;
var items=Clazz.array(String, [nSpectra]);
for (var i=0; i < nSpectra; i++) items[i]=pd.getSpectrumAt$I(i).getTitle$();

return items;
}, p$1);

Clazz.newMeth(C$, 'getSuggestedFileName$jspecview_common_JSViewer$jspecview_common_ExportType',  function (viewer, imode) {
var pd=viewer.pd$();
var sourcePath=pd.getSpectrum$().getFilePath$();
var newName=$I$(5).getTagName$S(sourcePath);
if (newName.startsWith$S("$")) newName=newName.substring$I(1);
var pt=newName.lastIndexOf$S(".");
var name=(pt < 0 ? newName : newName.substring$I$I(0, pt));
var ext=".jdx";
var isPrint=false;
switch (imode) {
case $I$(2).XY:
case $I$(2).FIX:
case $I$(2).PAC:
case $I$(2).SQZ:
case $I$(2).DIF:
case $I$(2).DIFDUP:
if (!(name.endsWith$S("_" + imode))) name+="_" + imode;
ext=".jdx";
break;
case $I$(2).AML:
ext=".xml";
break;
case $I$(2).SOURCE:
if (!(name.endsWith$S("_" + imode))) name+="_" + imode;
var lc=(sourcePath == null  ? "jspecview" : sourcePath.toLowerCase$());
ext=(lc.endsWith$S(".zip") ? ".zip" : lc.endsWith$S(".jdx") ? ".jdx" : "");
break;
case $I$(2).JPG:
case $I$(2).PNG:
case $I$(2).PDF:
isPrint=true;
default:
ext="." + imode.toString().toLowerCase$();
}
if (viewer.currentSource.isView) name=pd.getPrintJobTitle$Z(isPrint);
name+=ext;
return name;
}, p$1);

Clazz.newMeth(C$, 'fileCopy$S$javajs_util_OC',  function (name, out) {
try {
var br=$I$(5).getBufferedReaderFromName$S$S(name, null);
var line=null;
while ((line=br.readLine$()) != null ){
out.append$S(line);
out.append$S(C$.newLine);
}
out.closeChannel$();
return "OK " + out.getByteCount$() + " bytes" ;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return e.toString();
} else {
throw e;
}
}
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.newLine=System.getProperty$S("line.separator");
};
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:52 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
