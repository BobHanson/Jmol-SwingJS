(function(){var P$=Clazz.newPackage("jspecview.export"),p$1={},I$=[[0,'jspecview.common.ColorParameters','jspecview.common.ScriptToken','jspecview.common.ScaleData','javajs.util.Lst','java.util.Hashtable','javajs.util.DF','jspecview.common.ExportType','org.jmol.util.Logger','javajs.util.CU']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SVGExporter", null, 'jspecview.export.FormExporter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['I',['svgWidth','svgHeight','leftInset','rightInset','bottomInset','topInset']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'exportTheSpectrum$jspecview_common_JSViewer$jspecview_common_ExportType$javajs_util_OC$jspecview_common_Spectrum$I$I$jspecview_common_PanelData$Z',  function (viewer, mode, out, spec, startIndex, endIndex, pd, asBase64) {
this.initForm$jspecview_common_JSViewer$javajs_util_OC(viewer, out);
if (pd == null ) pd=viewer.pd$();
var plotAreaColor;
var backgroundColor;
var plotColor;
var gridColor;
var titleColor;
var scaleColor;
var unitsColor;
if (pd == null ) {
plotAreaColor=backgroundColor=$I$(1).LIGHT_GRAY;
plotColor=$I$(1).BLUE;
gridColor=titleColor=scaleColor=unitsColor=$I$(1).BLACK;
} else {
plotAreaColor=pd.getColor$jspecview_common_ScriptToken($I$(2).PLOTAREACOLOR);
backgroundColor=pd.bgcolor;
plotColor=pd.getCurrentPlotColor$I(0);
gridColor=pd.getColor$jspecview_common_ScriptToken($I$(2).GRIDCOLOR);
titleColor=pd.getColor$jspecview_common_ScriptToken($I$(2).TITLECOLOR);
scaleColor=pd.getColor$jspecview_common_ScriptToken($I$(2).SCALECOLOR);
unitsColor=pd.getColor$jspecview_common_ScriptToken($I$(2).UNITSCOLOR);
}var xyCoords=spec.getXYCoords$();
var scaleData=Clazz.new_([xyCoords, startIndex, endIndex, spec.isContinuous$(), spec.isInverted$()],$I$(3,1).c$$jspecview_common_CoordinateA$I$I$Z$Z);
var maxXOnScale=scaleData.maxXOnScale;
var minXOnScale=scaleData.minXOnScale;
var maxYOnScale=scaleData.maxYOnScale;
var minYOnScale=scaleData.minYOnScale;
var xStep=scaleData.steps[0];
var yStep=scaleData.steps[1];
var plotAreaWidth=C$.svgWidth - C$.leftInset - C$.rightInset ;
var plotAreaHeight=C$.svgHeight - C$.topInset - C$.bottomInset ;
var xScaleFactor=(plotAreaWidth / (maxXOnScale - minXOnScale));
var yScaleFactor=(plotAreaHeight / (maxYOnScale - minYOnScale));
var leftPlotArea=C$.leftInset;
var rightPlotArea=C$.leftInset + plotAreaWidth;
var topPlotArea=C$.topInset;
var bottomPlotArea=C$.topInset + plotAreaHeight;
var titlePosition=bottomPlotArea + 60;
this.context.put$S$O("titlePosition",  new Integer(titlePosition));
var xPt;
var yPt;
var xStr;
var yStr;
var vertGridCoords=Clazz.new_($I$(4,1));
var horizGridCoords=Clazz.new_($I$(4,1));
for (var i=minXOnScale; i < maxXOnScale + xStep / 2 ; i+=xStep) {
xPt=leftPlotArea + ((i - minXOnScale) * xScaleFactor);
yPt=topPlotArea;
xStr=C$.formatDecimalTrimmed$D$I(xPt, 6);
yStr=C$.formatDecimalTrimmed$D$I(yPt, 6);
var hash=Clazz.new_($I$(5,1));
hash.put$O$O("xVal", xStr);
hash.put$O$O("yVal", yStr);
vertGridCoords.addLast$O(hash);
}
for (var i=minYOnScale; i < maxYOnScale + yStep / 2 ; i+=yStep) {
xPt=leftPlotArea;
yPt=topPlotArea + ((i - minYOnScale) * yScaleFactor);
xStr=C$.formatDecimalTrimmed$D$I(xPt, 6);
yStr=C$.formatDecimalTrimmed$D$I(yPt, 6);
var hash=Clazz.new_($I$(5,1));
hash.put$O$O("xVal", xStr);
hash.put$O$O("yVal", yStr);
horizGridCoords.addLast$O(hash);
}
var xScaleList=Clazz.new_($I$(4,1));
var xScaleListReversed=Clazz.new_($I$(4,1));
var yScaleList=Clazz.new_($I$(4,1));
var precisionX=scaleData.precision[0];
var precisionY=scaleData.precision[1];
for (var i=minXOnScale; i < (maxXOnScale + xStep / 2) ; i+=xStep) {
xPt=leftPlotArea + ((i - minXOnScale) * xScaleFactor);
xPt-=10;
yPt=bottomPlotArea + 15;
xStr=C$.formatDecimalTrimmed$D$I(xPt, 6);
yStr=C$.formatDecimalTrimmed$D$I(yPt, 6);
var iStr=$I$(6).formatDecimalDbl$D$I(i, precisionX);
var hash=Clazz.new_($I$(5,1));
hash.put$O$O("xVal", xStr);
hash.put$O$O("yVal", yStr);
hash.put$O$O("number", iStr);
xScaleList.addLast$O(hash);
}
for (var i=minXOnScale, j=maxXOnScale; i < (maxXOnScale + xStep / 2) ; i+=xStep, j-=xStep) {
xPt=leftPlotArea + ((j - minXOnScale) * xScaleFactor);
xPt-=10;
yPt=bottomPlotArea + 15;
xStr=C$.formatDecimalTrimmed$D$I(xPt, 6);
yStr=C$.formatDecimalTrimmed$D$I(yPt, 6);
var iStr=$I$(6).formatDecimalDbl$D$I(i, precisionX);
var hash=Clazz.new_($I$(5,1));
hash.put$O$O("xVal", xStr);
hash.put$O$O("yVal", yStr);
hash.put$O$O("number", iStr);
xScaleListReversed.addLast$O(hash);
}
for (var i=minYOnScale; (i < maxYOnScale + yStep / 2 ); i+=yStep) {
xPt=leftPlotArea - 55;
yPt=bottomPlotArea - ((i - minYOnScale) * yScaleFactor);
yPt+=3;
xStr=C$.formatDecimalTrimmed$D$I(xPt, 6);
yStr=C$.formatDecimalTrimmed$D$I(yPt, 6);
var iStr=$I$(6).formatDecimalDbl$D$I(i, precisionY);
var hash=Clazz.new_($I$(5,1));
hash.put$O$O("xVal", xStr);
hash.put$O$O("yVal", yStr);
hash.put$O$O("number", iStr);
yScaleList.addLast$O(hash);
}
var firstTranslateX;
var firstTranslateY;
var secondTranslateX;
var secondTranslateY;
var scaleX;
var scaleY;
var increasing=(pd != null  && pd.getBoolean$jspecview_common_ScriptToken($I$(2).REVERSEPLOT) );
if (increasing) {
firstTranslateX=leftPlotArea;
firstTranslateY=bottomPlotArea;
scaleX=xScaleFactor;
scaleY=-yScaleFactor;
secondTranslateX=-1 * minXOnScale;
secondTranslateY=-1 * minYOnScale;
} else {
firstTranslateX=rightPlotArea;
firstTranslateY=bottomPlotArea;
scaleX=-xScaleFactor;
scaleY=-yScaleFactor;
secondTranslateX=-minXOnScale;
secondTranslateY=-minYOnScale;
}var yTickA=minYOnScale - (yStep / 2);
var yTickB=yStep / 5;
this.context.put$S$O("plotAreaColor", C$.toRGBHexString$javajs_api_GenericColor(plotAreaColor));
this.context.put$S$O("backgroundColor", C$.toRGBHexString$javajs_api_GenericColor(backgroundColor));
this.context.put$S$O("plotColor", C$.toRGBHexString$javajs_api_GenericColor(plotColor));
this.context.put$S$O("gridColor", C$.toRGBHexString$javajs_api_GenericColor(gridColor));
this.context.put$S$O("titleColor", C$.toRGBHexString$javajs_api_GenericColor(titleColor));
this.context.put$S$O("scaleColor", C$.toRGBHexString$javajs_api_GenericColor(scaleColor));
this.context.put$S$O("unitsColor", C$.toRGBHexString$javajs_api_GenericColor(unitsColor));
this.context.put$S$O("svgHeight",  new Integer(C$.svgHeight));
this.context.put$S$O("svgWidth",  new Integer(C$.svgWidth));
this.context.put$S$O("leftPlotArea",  new Integer(leftPlotArea));
this.context.put$S$O("rightPlotArea",  new Integer(rightPlotArea));
this.context.put$S$O("topPlotArea",  new Integer(topPlotArea));
this.context.put$S$O("bottomPlotArea",  new Integer(bottomPlotArea));
this.context.put$S$O("plotAreaHeight",  new Integer(plotAreaHeight));
this.context.put$S$O("plotAreaWidth",  new Integer(plotAreaWidth));
this.context.put$S$O("minXOnScale",  new Double(minXOnScale));
this.context.put$S$O("maxXOnScale",  new Double(maxXOnScale));
this.context.put$S$O("minYOnScale",  new Double(minYOnScale));
this.context.put$S$O("maxYOnScale",  new Double(maxYOnScale));
this.context.put$S$O("yTickA",  new Double(yTickA));
this.context.put$S$O("yTickB",  new Double(yTickB));
this.context.put$S$O("xScaleFactor",  new Double(xScaleFactor));
this.context.put$S$O("yScaleFactor",  new Double(yScaleFactor));
this.context.put$S$O("increasing",  Boolean.from(increasing));
this.context.put$S$O("verticalGridCoords", vertGridCoords);
this.context.put$S$O("horizontalGridCoords", horizGridCoords);
var newXYCoords=Clazz.new_($I$(4,1));
for (var i=startIndex; i <= endIndex; i++) newXYCoords.addLast$O(xyCoords[i]);

var firstX;
var firstY;
var lastX;
firstX=xyCoords[startIndex].getXVal$();
firstY=xyCoords[startIndex].getYVal$();
lastX=xyCoords[endIndex].getXVal$();
System.out.println$S("SVG " + spec.isXIncreasing$() + " " + spec.shouldDisplayXAxisIncreasing$() + " " + new Double(firstX).toString() + " " + new Double(lastX).toString() + " " + startIndex + " " + endIndex + " " + newXYCoords.get$I(0).toString() + " " + increasing );
this.context.put$S$O("title", spec.getTitle$());
this.context.put$S$O("xyCoords", newXYCoords);
this.context.put$S$O("continuous",  Boolean.from(spec.isContinuous$()));
this.context.put$S$O("firstTranslateX",  new Double(firstTranslateX));
this.context.put$S$O("firstTranslateY",  new Double(firstTranslateY));
this.context.put$S$O("scaleX",  new Double(scaleX));
this.context.put$S$O("scaleY",  new Double(scaleY));
this.context.put$S$O("secondTranslateX",  new Double(secondTranslateX));
this.context.put$S$O("secondTranslateY",  new Double(secondTranslateY));
this.context.put$S$O("plotStrokeWidth", p$1.getPlotStrokeWidth$D$D.apply(this, [scaleX, scaleY]));
if (increasing) {
this.context.put$S$O("xScaleList", xScaleList);
this.context.put$S$O("xScaleListReversed", xScaleListReversed);
} else {
this.context.put$S$O("xScaleList", xScaleListReversed);
this.context.put$S$O("xScaleListReversed", xScaleList);
}this.context.put$S$O("yScaleList", yScaleList);
this.context.put$S$O("xUnits", spec.getXUnits$());
this.context.put$S$O("yUnits", spec.getYUnits$());
this.context.put$S$O("firstX", Double.valueOf$D(firstX));
this.context.put$S$O("firstY", Double.valueOf$D(firstY));
this.context.put$S$O("lastX", Double.valueOf$D(lastX));
var xUnitLabelX=rightPlotArea - 50;
var xUnitLabelY=bottomPlotArea + 30;
var yUnitLabelX=leftPlotArea - 80;
var yUnitLabelY=(bottomPlotArea/2|0);
var tempX=yUnitLabelX;
yUnitLabelX=-yUnitLabelY;
yUnitLabelY=tempX;
this.context.put$S$O("xUnitLabelX", "" + xUnitLabelX);
this.context.put$S$O("xUnitLabelY", "" + xUnitLabelY);
this.context.put$S$O("yUnitLabelX", "" + yUnitLabelX);
this.context.put$S$O("yUnitLabelY", "" + yUnitLabelY);
this.context.put$S$O("numDecimalPlacesX",  new Integer(Math.abs(scaleData.exportPrecision[0])));
this.context.put$S$O("numDecimalPlacesY",  new Integer(Math.abs(scaleData.exportPrecision[1])));
var vm=(mode === $I$(7).SVGI  ? "plot_ink.vm" : "plot.vm");
$I$(8).info$S("SVGExporter using " + vm);
return this.writeForm$S(vm);
});

Clazz.newMeth(C$, 'getPlotStrokeWidth$D$D',  function (scaleX, scaleY) {
var s=C$.formatDecimalTrimmed$D$I(Math.abs(scaleY / 1.0E12 * 2), 10);
return s;
}, p$1);

Clazz.newMeth(C$, 'toRGBHexString$javajs_api_GenericColor',  function (c) {
return "#" + $I$(9).toRGBHexString$javajs_api_GenericColor(c);
}, 1);

Clazz.newMeth(C$, 'formatDecimalTrimmed$D$I',  function (x, precision) {
return $I$(6).formatDecimalTrimmed0$D$I(x, precision);
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.svgWidth=850;
C$.svgHeight=400;
C$.leftInset=100;
C$.rightInset=200;
C$.bottomInset=80;
C$.topInset=20;
};
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:57 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
