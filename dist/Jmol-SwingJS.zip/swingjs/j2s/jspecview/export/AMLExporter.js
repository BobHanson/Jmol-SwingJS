(function(){var P$=Clazz.newPackage("jspecview.export");
/*c*/var C$=Clazz.newClass(P$, "AMLExporter", null, 'jspecview.export.XMLExporter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'exportTheSpectrum$jspecview_common_JSViewer$jspecview_common_ExportType$javajs_util_OC$jspecview_common_Spectrum$I$I$jspecview_common_PanelData$Z',  function (viewer, mode, out, spec, startIndex, endIndex, pd, asBase64) {
if (!this.setup$jspecview_common_JSViewer$jspecview_common_Spectrum$javajs_util_OC$I$I(viewer, spec, out, startIndex, endIndex)) return null;
if (this.solvName == null  || this.solvName.equals$O("") ) this.solvName="unknown";
if (this.datatype.contains$CharSequence("MASS")) {
this.spectypeInitials="MS";
} else if (this.datatype.contains$CharSequence("INFRARED")) {
this.spectypeInitials="IR";
} else if (this.datatype.contains$CharSequence("UV") || (this.datatype.contains$CharSequence("VIS")) ) {
this.spectypeInitials="UV";
} else if (this.datatype.contains$CharSequence("NMR")) {
this.spectypeInitials="NMR";
}this.pathlength=(this.pathlength.equals$O("") && this.spectypeInitials.equals$O("UV")  ? "1.0" : "-1");
if (this.vendor == null  || this.vendor.equals$O("") ) this.vendor="not available from JCAMP-DX file";
if (this.model == null  || this.model.equals$O("") ) this.model="not available from JCAMP-DX file";
if (this.resolution == null  || this.resolution.equals$O("") ) this.resolution="not available in JCAMP-DX file";
this.setContext$();
return this.writeFormType$S("animl");
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:06 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
