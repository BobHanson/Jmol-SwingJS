(function(){var P$=Clazz.newPackage("jspecview.export"),p$1={},I$=[[0,'javajs.util.Lst']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "XMLExporter", null, 'jspecview.export.FormExporter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.xUnitFactor="";
this.xUnitExponent="1";
this.spectypeInitials="";
this.vendor="";
this.model="";
this.resolution="";
this.pathlength="";
this.molform="";
this.bp="";
this.mp="";
this.casRN="";
this.casName="";
this.obNucleus="";
this.solvRef="";
this.solvName="";
this.newXYCoords=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['Z',['continuous'],'D',['obFreq','firstX','lastX','deltaX'],'I',['startIndex','endIndex','npoints'],'S',['title','ident','state','xUnits','yUnits','xUnitFactor','xUnitExponent','xUnitLabel','yUnitLabel','datatype','owner','origin','spectypeInitials','longdate','date','time','vendor','model','resolution','pathlength','molform','bp','mp','casRN','casName','obNucleus','solvRef','solvName'],'O',['xyCoords','jspecview.common.Coordinate[]','newXYCoords','javajs.util.Lst']]
,['O',['params','String[]']]]

Clazz.newMeth(C$, 'setup$jspecview_common_JSViewer$jspecview_common_Spectrum$javajs_util_OC$I$I',  function (viewer, spec, out, startIndex, endIndex) {
this.startIndex=startIndex;
this.endIndex=endIndex;
this.initForm$jspecview_common_JSViewer$javajs_util_OC(viewer, out);
return this.setParameters$jspecview_common_Spectrum(spec);
});

Clazz.newMeth(C$, 'setParameters$jspecview_common_Spectrum',  function (spec) {
this.continuous=spec.isContinuous$();
if (!this.continuous) return false;
this.xyCoords=spec.getXYCoords$();
this.npoints=this.endIndex - this.startIndex + 1;
for (var i=this.startIndex; i <= this.endIndex; i++) this.newXYCoords.addLast$O(this.xyCoords[i]);

this.title=spec.getTitle$();
this.xUnits=spec.getXUnits$().toUpperCase$();
this.yUnits=spec.getYUnits$().toUpperCase$();
if (this.xUnits.equals$O("1/CM")) {
this.xUnitLabel="1/cm";
this.xUnitFactor="0.01";
this.xUnitExponent="-1";
} else if (this.xUnits.equals$O("UM") || this.xUnits.equals$O("MICROMETERS") ) {
this.xUnitLabel="um";
this.xUnitFactor="0.000001";
} else if (this.xUnits.equals$O("NM") || this.xUnits.equals$O("NANOMETERS") || this.xUnits.equals$O("WAVELENGTH")  ) {
this.xUnitLabel="nm";
this.xUnitFactor="0.000000001";
} else if (this.xUnits.equals$O("PM") || this.xUnits.equals$O("PICOMETERS") ) {
this.xUnitLabel="pm";
this.xUnitFactor="0.000000000001";
} else {
this.xUnitLabel="Arb. Units";
this.xUnitFactor="";
}this.yUnitLabel=(this.yUnits.equals$O("A") || this.yUnits.equals$O("ABS") || this.yUnits.equals$O("ABSORBANCE") || this.yUnits.equals$O("AU") || this.yUnits.equals$O("AUFS") || this.yUnits.equals$O("OPTICAL DENSITY")   ? "Absorbance" : this.yUnits.equals$O("T") || this.yUnits.equals$O("TRANSMITTANCE")  ? "Transmittance" : this.yUnits.equals$O("COUNTS") || this.yUnits.equals$O("CTS")  ? "Counts" : "Arb. Units");
this.owner=spec.getOwner$();
this.origin=spec.getOrigin$();
this.time=spec.getTime$();
this.longdate=spec.getLongDate$();
this.date=spec.getDate$();
if ((this.longdate.equals$O("")) || (this.date.equals$O("")) ) this.longdate=this.currentTime;
if ((this.date.length$() == 8) && (this.date.charAt$I(0) < "5") ) this.longdate="20" + this.date + " " + this.time ;
if ((this.date.length$() == 8) && (this.date.charAt$I(0) > "5") ) this.longdate="19" + this.date + " " + this.time ;
this.obFreq=spec.getObservedFreq$();
this.firstX=this.xyCoords[this.startIndex].getXVal$();
this.lastX=this.xyCoords[this.endIndex].getXVal$();
this.deltaX=spec.getDeltaX$();
this.datatype=spec.getDataType$();
if (this.datatype.contains$CharSequence("NMR")) {
this.firstX*=this.obFreq;
this.lastX*=this.obFreq;
this.deltaX*=this.obFreq;
}p$1.setParams$javajs_util_Lst.apply(this, [spec.getHeaderTable$()]);
return true;
});

Clazz.newMeth(C$, 'getParamIndex$S',  function (label) {
for (var i=0; i < C$.params.length; i++) if (C$.params[i].equalsIgnoreCase$S(label)) return i;

return -1;
}, 1);

Clazz.newMeth(C$, 'setParams$javajs_util_Lst',  function (table) {
for (var i=0; i < table.size$(); i++) {
var entry=table.get$I(i);
var val=entry[1];
switch (C$.getParamIndex$S(entry[0])) {
case 0:
this.state=val;
break;
case 1:
this.resolution=val;
break;
case 2:
this.model=val;
break;
case 3:
this.vendor=val;
break;
case 4:
this.molform=val;
break;
case 5:
this.casRN=val;
break;
case 6:
this.casName=val;
break;
case 7:
this.mp=val;
break;
case 8:
this.bp=val;
break;
case 9:
this.obNucleus=val;
break;
case 10:
this.solvName=val;
break;
case 11:
this.solvRef=val;
break;
}
}
}, p$1);

Clazz.newMeth(C$, 'setContext$',  function () {
this.context.put$S$O("continuous", Boolean.valueOf$Z(this.continuous));
this.context.put$S$O("file", this.out.getFileName$() + "");
this.context.put$S$O("title", this.title);
this.context.put$S$O("ident", this.ident);
this.context.put$S$O("state", this.state);
this.context.put$S$O("firstX",  new Double(this.firstX));
this.context.put$S$O("lastX",  new Double(this.lastX));
this.context.put$S$O("xyCoords", this.newXYCoords);
this.context.put$S$O("xdata_type", "Float32");
this.context.put$S$O("ydata_type", "Float32");
this.context.put$S$O("npoints", Integer.valueOf$I(this.npoints));
this.context.put$S$O("xencode", "avs");
this.context.put$S$O("yencode", "ivs");
this.context.put$S$O("xUnits", this.xUnits);
this.context.put$S$O("yUnits", this.yUnits);
this.context.put$S$O("xUnitLabel", this.xUnitLabel);
this.context.put$S$O("yUnitLabel", this.yUnitLabel);
this.context.put$S$O("specinits", this.spectypeInitials);
this.context.put$S$O("deltaX",  new Double(this.deltaX));
this.context.put$S$O("owner", this.owner);
this.context.put$S$O("origin", this.origin);
this.context.put$S$O("timestamp", this.longdate);
this.context.put$S$O("DataType", this.datatype);
this.context.put$S$O("currenttime", this.currentTime);
this.context.put$S$O("resolution", this.resolution);
this.context.put$S$O("pathlength", this.pathlength);
this.context.put$S$O("molform", this.molform);
this.context.put$S$O("CASrn", this.casRN);
this.context.put$S$O("CASn", this.casName);
this.context.put$S$O("mp", this.mp);
this.context.put$S$O("bp", this.bp);
this.context.put$S$O("ObFreq",  new Double(this.obFreq));
this.context.put$S$O("ObNucleus", this.obNucleus);
this.context.put$S$O("SolvName", this.solvName);
this.context.put$S$O("SolvRef", this.solvRef);
this.context.put$S$O("vendor", this.vendor);
this.context.put$S$O("model", this.model);
});

Clazz.newMeth(C$, 'writeFormType$S',  function (type) {
return this.writeForm$S(type + (this.datatype.contains$CharSequence("NMR") ? "_nmr" : "_tmp") + ".vm" );
});

C$.$static$=function(){C$.$static$=0;
C$.params=Clazz.array(String, -1, ["##STATE", "##RESOLUTION", "##SPECTROMETER", "##$MANUFACTURER", "##MOLFORM", "##CASREGISTRYNO", "##CASNAME", "##MP", "##BP", "##.OBSERVENUCLEUS", "##.SOLVENTNAME", "##.SOLVENTREFERENCE"]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:07 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
