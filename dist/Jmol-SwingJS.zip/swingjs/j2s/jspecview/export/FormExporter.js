(function(){var P$=Clazz.newPackage("jspecview.export"),I$=[[0,'jspecview.export.FormContext','jspecview.common.JSVFileManager','org.jmol.util.Logger']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FormExporter", null, null, 'jspecview.api.JSVExporter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.context=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['S',['errMsg','currentTime'],'O',['context','jspecview.export.FormContext','out','javajs.util.OC','vwr','jspecview.common.JSViewer']]]

Clazz.newMeth(C$, 'initForm$jspecview_common_JSViewer$javajs_util_OC',  function (viewer, out) {
this.vwr=viewer;
this.out=out;
this.currentTime=viewer.apiPlatform.getDateFormat$S(null);
});

Clazz.newMeth(C$, 'writeForm$S',  function (templateFile) {
var error=Clazz.array(String, [1]);
var template=$I$(2).getResourceString$O$S$SA(this, "resources/" + templateFile, error);
if (template == null ) {
$I$(3).error$S(error[0]);
return error[0];
}this.errMsg=this.context.setTemplate$S(template);
if (this.errMsg != null ) {
$I$(3).error$S(this.errMsg);
return this.errMsg;
}this.errMsg=this.context.merge$javajs_util_OC(this.out);
if (this.out == null ) return this.errMsg;
if (this.errMsg != null ) {
$I$(3).error$S(this.errMsg);
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,[this.errMsg]);
}this.out.closeChannel$();
return "OK " + this.out.getByteCount$() + " bytes" ;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:29 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
