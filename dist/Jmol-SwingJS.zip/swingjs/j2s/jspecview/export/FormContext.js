(function(){var P$=Clazz.newPackage("jspecview.export"),p$1={},I$=[[0,'org.jmol.util.Logger','java.util.Hashtable','javajs.util.Lst','javajs.util.PT',['jspecview.export.FormContext','.FormToken'],'javajs.util.DF']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FormContext", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['FormToken',0]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.context=Clazz.new_($I$(2,1));
this.cmds=Clazz.new_($I$(3,1));
},1);

C$.$fields$=[['I',['commandLevel'],'S',['strError'],'O',['+tokens','context','java.util.Hashtable','formTokens','javajs.util.Lst','+cmds']]
,['O',['ops','String[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'put$S$O',  function (key, value) {
if (value == null ) value="";
this.context.put$O$O(key, value);
});

Clazz.newMeth(C$, 'setTemplate$S',  function (template) {
var errMsg=p$1.getFormTokens$S.apply(this, [template]);
if (errMsg != null ) return errMsg;
return null;
});

Clazz.newMeth(C$, 'getFormTokens$S',  function (template) {
this.formTokens=Clazz.new_($I$(3,1));
if (template.indexOf$S("\r\n") >= 0) template=$I$(4).replaceAllCharacters$S$S$S(template, "\r\n", "\n");
template=template.replace$C$C("\r", "\n");
var lines=template.split$S("\n");
var token="";
for (var i=0; i < lines.length && this.strError == null  ; i++) {
var line=lines[i];
var m=line.length$();
var ch;
while (--m >= 0 && ((ch=line.charAt$I(m)) == " " || ch == "\t" ) ){
}
line=line.substring$I$I(0, m + 1);
if (line.length$() == 0) continue;
var firstChar=-1;
var nChar=line.length$();
while (++firstChar < nChar && Character.isWhitespace$C(line.charAt$I(firstChar)) ){
}
if (line.indexOf$S("#") == firstChar) {
if (token.length$() > 0) {
Clazz.new_($I$(5,1).c$$S$I,[this, null, token, 0]);
token="";
}if (this.strError != null ) break;
Clazz.new_($I$(5,1).c$$S$I,[this, null, line, firstChar]);
continue;
}token+=line + "\n";
}
if (token.length$() > 0 && this.strError == null  ) {
Clazz.new_($I$(5,1).c$$S$I,[this, null, token, 0]);
}return this.strError;
}, p$1);

Clazz.newMeth(C$, 'merge$javajs_util_OC',  function (out) {
var ptr;
for (var i=0; i < this.formTokens.size$() && this.strError == null  ; i++) {
var vt=this.formTokens.get$I(i);
switch (vt.cmdType) {
case 0:
var data=p$1.fillData$S.apply(this, [vt.data]);
out.append$S(data);
continue;
case 1:
if (p$1.evaluate$S$Z.apply(this, [vt.data, true])) {
vt.endPtr=-vt.endPtr;
} else {
i=vt.endPtr - 1;
}continue;
case 2:
case 3:
if ((ptr=this.formTokens.get$I(vt.cmdPtr).endPtr) < 0) {
this.formTokens.get$I(vt.cmdPtr).endPtr=-ptr;
while ((vt=this.formTokens.get$I(vt.endPtr)).cmdType != 4){
}
i=vt.ptr;
continue;
}if (vt.cmdType == 3) {
if (p$1.evaluate$S$Z.apply(this, [vt.data, true])) {
vt.endPtr=-vt.endPtr;
} else {
i=vt.endPtr - 1;
}}continue;
case 5:
p$1.foreach$jspecview_export_FormContext_FormToken.apply(this, [vt]);
case 4:
if ((vt=this.formTokens.get$I(vt.cmdPtr)).cmdType != 5) continue;
if (vt.vc == null ) continue;
if (++vt.pointCount == vt.vc.size$()) {
i=vt.endPtr;
continue;
}var varData=vt.vc.get$I(vt.pointCount);
if (Clazz.instanceOf(varData, "jspecview.common.Coordinate")) {
var c=varData;
this.context.put$O$O("pointCount",  new Integer(vt.pointCount));
this.context.put$O$O(vt.$var + ".xVal",  new Double(c.getXVal$()));
this.context.put$O$O(vt.$var + ".yVal",  new Double(c.getYVal$()));
this.context.put$O$O(vt.$var + ".getXString()", this.getXString$jspecview_common_Coordinate(c));
this.context.put$O$O(vt.$var + ".getYString()", this.getYString$jspecview_common_Coordinate(c));
} else if (Clazz.instanceOf(varData, "java.util.Map")) {
for (var entry, $entry = (varData).entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) this.context.put$O$O(vt.$var + "." + entry.getKey$() , entry.getValue$());

}i=vt.cmdPtr;
continue;
}
}
return (this.strError != null  ? this.strError : out != null  ? out.toString() : null);
});

Clazz.newMeth(C$, 'getXString$jspecview_common_Coordinate',  function (c) {
return $I$(6,"formatDecimalTrimmed0$D$I",[c.getXVal$(), 8]);
});

Clazz.newMeth(C$, 'getYString$jspecview_common_Coordinate',  function (c) {
return $I$(6,"formatDecimalTrimmed0$D$I",[c.getYVal$(), 8]);
});

Clazz.newMeth(C$, 'foreach$jspecview_export_FormContext_FormToken',  function (vt) {
var data=vt.data;
data=data.replace$C$C("(", " ");
data=data.replace$C$C(")", " ");
var tokens=$I$(4).getTokens$S(data);
if (tokens.length != 4) {
return;
}vt.$var=tokens[1].substring$I(1);
var vc=this.context.get$O(tokens[3].substring$I(1));
if (Clazz.instanceOf(vc, "javajs.util.Lst")) vt.vc=vc;
vt.cmdPtr=vt.ptr;
vt.pointCount=-1;
}, p$1);

Clazz.newMeth(C$, 'findOp$S',  function (op) {
for (var i=C$.ops.length; --i >= 0; ) if (C$.ops[i].equals$O(op)) return i;

return -1;
}, 1);

Clazz.newMeth(C$, 'evaluate$S$Z',  function (data, isIf) {
var pt=data.indexOf$S("(");
if (pt < 0) {
this.strError="missing ( in " + data;
return false;
}data=data.substring$I(pt + 1);
pt=data.lastIndexOf$S(")");
if (pt < 0) {
this.strError="missing ) in " + data;
return false;
}data=data.substring$I$I(0, pt);
data=$I$(4,"rep$S$S$S",[data, "=", " = "]);
data=$I$(4).rep$S$S$S(data, "!", " ! ");
data=$I$(4).rep$S$S$S(data, "<", " < ");
data=$I$(4).rep$S$S$S(data, ">", " > ");
data=$I$(4,"rep$S$S$S",[data, "=  =", "=="]);
data=$I$(4,"rep$S$S$S",[data, "<  =", "<="]);
data=$I$(4,"rep$S$S$S",[data, ">  =", ">="]);
data=$I$(4,"rep$S$S$S",[data, "!  =", "!="]);
var tokens=$I$(4).getTokens$S(data);
var key=tokens[0].substring$I(1);
var isNot=false;
var x=false;
var value=null;
var compare="";
try {
switch (tokens.length) {
case 1:
value=p$1.getValue$S.apply(this, [key]);
return (!value.equals$O("") && !value.equals$O("false") );
case 2:
if (key.equals$O("!")) {
key=$I$(4).trim$S$S(tokens[1], "$ ");
value=p$1.getValue$S.apply(this, [key]);
return (value.equals$O("false") || value.equals$O("") );
}break;
case 3:
key=$I$(4).trim$S$S(tokens[0], "$ ");
value=p$1.getValue$S.apply(this, [key]);
compare=$I$(4).trim$S$S(tokens[2], " \"");
switch (C$.findOp$S(tokens[1])) {
case 2:
case 0:
return (value.equals$O(compare));
case 1:
return (!value.equals$O(compare));
default:
$I$(1).warn$S("???? " + key + " " + compare + " " + value );
}
break;
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
$I$(1,"warn$S",[e.toString() + " in VelocityContext.merge"]);
} else {
throw e;
}
}
return isNot ? !x : x;
}, p$1);

Clazz.newMeth(C$, 'getValue$S',  function (key) {
return (this.context.containsKey$O(key) ? this.context.get$O(key).toString() : "");
}, p$1);

Clazz.newMeth(C$, 'fillData$S',  function (data) {
var i=0;
var ccData=data.length$();
while (i < ccData){
while (i < ccData && data.charAt$I(i++) != "$" ){
}
if (i == ccData) break;
var j=i;
var ch;
while (++j < ccData && (Character.isLetterOrDigit$C(ch=data.charAt$I(j)) || ch == "."  || ch == "_" ) ){
}
if (j < ccData && data.charAt$I(j) == "(" ) j+=2;
var key=data.substring$I$I(i, j);
if (this.context.containsKey$O(key)) {
var value=this.context.get$O(key);
var strValue;
if (Clazz.instanceOf(value, "jspecview.common.Coordinate")) {
strValue=value.toString();
} else {
strValue=value.toString();
}data=data.substring$I$I(0, i - 1) + strValue + data.substring$I(j) ;
ccData=data.length$();
i+=strValue.length$();
}}
return data;
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.ops=Clazz.array(String, -1, ["==", "!=", "="]);
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.FormContext, "FormToken", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.cmdPtr=-1;
this.endPtr=-1;
},1);

C$.$fields$=[['Z',['hasVariable'],'I',['cmdType','cmdPtr','endPtr','ptr','pointCount'],'S',['$var','data'],'O',['vc','javajs.util.Lst']]]

Clazz.newMeth(C$, 'c$$S$I',  function (token, firstChar) {
;C$.$init$.apply(this);
this.hasVariable=token.indexOf$S("$") >= 0;
this.data=token;
if (token.indexOf$S("#") != firstChar) {
this.b$['jspecview.export.FormContext'].formTokens.addLast$O(this);
return;
}this.ptr=this.b$['jspecview.export.FormContext'].formTokens.size$();
var checkIf=false;
if (token.indexOf$S("#end") == firstChar) {
this.cmdType=4;
this.endPtr=this.ptr;
--this.b$['jspecview.export.FormContext'].commandLevel;
if (this.b$['jspecview.export.FormContext'].commandLevel < 0) {
this.b$['jspecview.export.FormContext'].strError="misplaced #end";
return;
}this.cmdPtr=this.b$['jspecview.export.FormContext'].cmds.removeItemAt$I(0).intValue$();
this.b$['jspecview.export.FormContext'].formTokens.get$I(this.cmdPtr).endPtr=this.ptr;
} else {
++this.b$['jspecview.export.FormContext'].commandLevel;
if (token.indexOf$S("#if") == firstChar) {
this.cmdType=1;
this.b$['jspecview.export.FormContext'].cmds.add$I$O(0,  new Integer(this.ptr));
} else if (token.indexOf$S("#foreach") == firstChar) {
this.cmdType=5;
this.b$['jspecview.export.FormContext'].cmds.add$I$O(0,  new Integer(this.ptr));
this.cmdPtr=this.ptr;
if (token.indexOf$S("#end") > 0) {
var pt=token.indexOf$S(")") + 1;
this.data=token.substring$I$I(0, pt);
this.b$['jspecview.export.FormContext'].formTokens.addLast$O(this);
Clazz.new_(C$.c$$S$I,[this, null, token.substring$I$I(pt, token.indexOf$S("#end")), 0]);
Clazz.new_(C$.c$$S$I,[this, null, "#end", 0]);
return;
}} else if (token.indexOf$S("#elseif") == firstChar) {
if (this.b$['jspecview.export.FormContext'].cmds.size$() == 0) {
this.b$['jspecview.export.FormContext'].strError="misplaced #elseif";
return;
}this.cmdType=3;
this.cmdPtr=this.b$['jspecview.export.FormContext'].cmds.removeItemAt$I(0).intValue$();
var vt=this.b$['jspecview.export.FormContext'].formTokens.get$I(this.cmdPtr);
checkIf=true;
vt.endPtr=this.ptr;
this.b$['jspecview.export.FormContext'].cmds.add$I$O(0,  new Integer(this.ptr));
} else if (token.indexOf$S("#else") == firstChar) {
if (this.b$['jspecview.export.FormContext'].cmds.size$() == 0) {
this.b$['jspecview.export.FormContext'].strError="misplaced #else";
return;
}this.cmdType=2;
checkIf=true;
this.cmdPtr=this.b$['jspecview.export.FormContext'].cmds.removeItemAt$I(0).intValue$();
this.b$['jspecview.export.FormContext'].formTokens.get$I(this.cmdPtr).endPtr=this.ptr;
this.b$['jspecview.export.FormContext'].cmds.add$I$O(0,  new Integer(this.ptr));
} else {
$I$(1).warn$S("??? " + token);
}if (checkIf) {
var vt=this.b$['jspecview.export.FormContext'].formTokens.get$I(this.cmdPtr);
if (vt.cmdType != 1 && vt.cmdType != 3 ) {
this.b$['jspecview.export.FormContext'].strError="misplaced " + token.trim$();
return;
}}}this.b$['jspecview.export.FormContext'].formTokens.addLast$O(this);
}, 1);

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:29 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
