(function(){var P$=Clazz.newPackage("jspecview.export"),p$1={},I$=[[0,'jspecview.common.Coordinate','jspecview.common.ExportType','jspecview.export.JDXCompressor','jspecview.source.JDXReader','javajs.util.PT','javajs.util.DF']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JDXExporter", null, null, 'jspecview.api.JSVExporter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['out','javajs.util.OC','type','jspecview.common.ExportType','spectrum','jspecview.common.Spectrum','vwr','jspecview.common.JSViewer']]
,['S',['newLine']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'exportTheSpectrum$jspecview_common_JSViewer$jspecview_common_ExportType$javajs_util_OC$jspecview_common_Spectrum$I$I$jspecview_common_PanelData$Z',  function (viewer, type, out, spectrum, startIndex, endIndex, pd, asBase64) {
this.out=out;
this.type=type;
this.spectrum=spectrum;
this.vwr=viewer;
p$1.toStringAux$I$I.apply(this, [startIndex, endIndex]);
out.closeChannel$();
return "OK " + out.getByteCount$() + " bytes" ;
});

Clazz.newMeth(C$, 'toStringAux$I$I',  function (startIndex, endIndex) {
var newXYCoords=this.spectrum.getXYCoords$();
var tabDataSet="";
var tmpDataClass="XYDATA";
if (this.spectrum.isHZtoPPM$()) {
var xyCoords=newXYCoords;
newXYCoords=Clazz.array($I$(1), [xyCoords.length]);
for (var i=0; i < xyCoords.length; i++) newXYCoords[i]=xyCoords[i].copy$();

$I$(1,"applyScale$jspecview_common_CoordinateA$D$D",[newXYCoords, this.spectrum.getObservedFreq$(), 1]);
}var xCompFactor=this.spectrum.getXFactor$();
var isIntegerX=C$.areIntegers$jspecview_common_CoordinateA$I$I$D$Z(newXYCoords, startIndex, endIndex, 1.0, true);
if (!isIntegerX && !C$.areIntegers$jspecview_common_CoordinateA$I$I$D$Z(newXYCoords, startIndex, endIndex, xCompFactor, true) ) xCompFactor=1;
var minY=$I$(1).getMinY$jspecview_common_CoordinateA$I$I(newXYCoords, startIndex, endIndex);
var maxY=$I$(1).getMaxY$jspecview_common_CoordinateA$I$I(newXYCoords, startIndex, endIndex);
var yCompFactor=this.spectrum.getYFactor$();
switch (this.type) {
case $I$(2).XY:
yCompFactor=1;
tmpDataClass=(this.spectrum.isContinuous$() ? "XYDATA" : "XYPOINTS");
break;
case $I$(2).PAC:
yCompFactor=1;
break;
default:
var isIntegerY=C$.areIntegers$jspecview_common_CoordinateA$I$I$D$Z(newXYCoords, startIndex, endIndex, 1.0, false);
if (!isIntegerY && !C$.areIntegers$jspecview_common_CoordinateA$I$I$D$Z(newXYCoords, startIndex, endIndex, yCompFactor, false) ) {
yCompFactor=(maxY - minY) / 1000000.0;
}break;
}
var step=1;
if (this.spectrum.isExportXAxisLeftToRight$() != (this.spectrum.getFirstX$() < this.spectrum.getLastX$() ) ) {
var t=startIndex;
startIndex=endIndex;
endIndex=t;
step=-1;
}switch (this.type) {
case $I$(2).DIF:
case $I$(2).DIFDUP:
tabDataSet=$I$(3,"compressDIF$jspecview_common_CoordinateA$I$I$I$D$D$Z",[newXYCoords, startIndex, endIndex, step, xCompFactor, yCompFactor, this.type === $I$(2).DIFDUP ]);
break;
case $I$(2).FIX:
tabDataSet=$I$(3).compressFIX$jspecview_common_CoordinateA$I$I$I$D$D(newXYCoords, startIndex, endIndex, step, xCompFactor, yCompFactor);
break;
case $I$(2).PAC:
tabDataSet=$I$(3).compressPAC$jspecview_common_CoordinateA$I$I$I$D$D(newXYCoords, startIndex, endIndex, step, xCompFactor, yCompFactor);
break;
case $I$(2).SQZ:
tabDataSet=$I$(3).compressSQZ$jspecview_common_CoordinateA$I$I$I$D$D(newXYCoords, startIndex, endIndex, step, xCompFactor, yCompFactor);
break;
case $I$(2).XY:
tabDataSet=$I$(3).getXYList$jspecview_common_CoordinateA$I$I$I(newXYCoords, startIndex, endIndex, step);
break;
default:
break;
}
var varList=$I$(4).getVarList$S(tmpDataClass);
p$1.getHeaderString$S$D$D$D$D$I$I.apply(this, [tmpDataClass, minY, maxY, xCompFactor, yCompFactor, startIndex, endIndex]);
this.out.append$S("##" + tmpDataClass + "= " + varList + C$.newLine );
this.out.append$S(tabDataSet);
this.out.append$S("##END=");
}, p$1);

Clazz.newMeth(C$, 'getHeaderString$S$D$D$D$D$I$I',  function (tmpDataClass, minY, maxY, tmpXFactor, tmpYFactor, startIndex, endIndex) {
this.out.append$S("##TITLE= ").append$S(this.spectrum.getTitle$()).append$S(C$.newLine);
this.out.append$S("##JCAMP-DX= 5.01").append$S(C$.newLine);
this.out.append$S("##DATA TYPE= ").append$S(this.spectrum.getDataType$()).append$S(C$.newLine);
this.out.append$S("##DATA CLASS= ").append$S(tmpDataClass).append$S(C$.newLine);
this.out.append$S("##ORIGIN= ").append$S(this.spectrum.getOrigin$()).append$S(C$.newLine);
this.out.append$S("##OWNER= ").append$S(this.spectrum.getOwner$()).append$S(C$.newLine);
var d=this.spectrum.getDate$();
var longdate="";
var currentTime=this.vwr.apiPlatform.getDateFormat$S(null);
if (this.spectrum.getLongDate$().equals$O("") || d.length$() != 8 ) {
longdate=currentTime + " $$ export date from JSpecView";
} else if (d.length$() == 8) {
longdate=(d.charAt$I(0) < "5" ? "20" : "19") + d + " " + this.spectrum.getTime$() ;
} else {
longdate=this.spectrum.getLongDate$();
}this.out.append$S("##LONGDATE= ").append$S(longdate).append$S(C$.newLine);
var headerTable=this.spectrum.getHeaderTable$();
for (var i=0; i < headerTable.size$(); i++) {
var entry=headerTable.get$I(i);
var label=entry[0];
var dataSet=entry[1];
var nl=(dataSet.startsWith$S("<") && dataSet.contains$CharSequence("</")  ? C$.newLine : "");
this.out.append$S(label).append$S("= ").append$S(nl).append$S(dataSet).append$S(C$.newLine);
}
var observedFreq=this.spectrum.getObservedFreq$();
if (!this.spectrum.is1D$()) this.out.append$S("##NUM DIM= ").append$S("" + this.spectrum.getNumDim$()).append$S(C$.newLine);
if (observedFreq != 1.7976931348623157E308 ) this.out.append$S("##.OBSERVE FREQUENCY= ").append$S("" + new Double(observedFreq).toString()).append$S(C$.newLine);
var nuc=this.spectrum.getObservedNucleus$();
if (!"".equals$O(nuc)) this.out.append$S("##.OBSERVE NUCLEUS= ").append$S(nuc).append$S(C$.newLine);
this.out.append$S("##XUNITS= ").append$S(this.spectrum.isHZtoPPM$() ? "HZ" : this.spectrum.getXUnits$()).append$S(C$.newLine);
this.out.append$S("##YUNITS= ").append$S(this.spectrum.getYUnits$()).append$S(C$.newLine);
this.out.append$S("##XFACTOR= ").append$S(C$.fixExponentInt$D(tmpXFactor)).append$S(C$.newLine);
this.out.append$S("##YFACTOR= ").append$S(C$.fixExponentInt$D(tmpYFactor)).append$S(C$.newLine);
var f=(this.spectrum.isHZtoPPM$() ? observedFreq : 1);
var xyCoords=this.spectrum.getXYCoords$();
this.out.append$S("##FIRSTX= ").append$S(C$.fixExponentInt$D(xyCoords[startIndex].getXVal$() * f)).append$S(C$.newLine);
this.out.append$S("##FIRSTY= ").append$S(C$.fixExponentInt$D(xyCoords[startIndex].getYVal$())).append$S(C$.newLine);
this.out.append$S("##LASTX= ").append$S(C$.fixExponentInt$D(xyCoords[endIndex].getXVal$() * f)).append$S(C$.newLine);
this.out.append$S("##NPOINTS= ").append$S("" + (Math.abs(endIndex - startIndex) + 1)).append$S(C$.newLine);
this.out.append$S("##MINY= ").append$S(C$.fixExponentInt$D(minY)).append$S(C$.newLine);
this.out.append$S("##MAXY= ").append$S(C$.fixExponentInt$D(maxY)).append$S(C$.newLine);
}, p$1);

Clazz.newMeth(C$, 'areIntegers$jspecview_common_CoordinateA$I$I$D$Z',  function (xyCoords, startIndex, endIndex, factor, isX) {
for (var i=startIndex; i <= endIndex; i++) {
var x=(isX ? xyCoords[i].getXVal$() : xyCoords[i].getYVal$()) / factor;
if (C$.isAlmostInteger$D(x)) return false;
}
return true;
}, 1);

Clazz.newMeth(C$, 'isAlmostInteger$D',  function (x) {
return (x != 0  && Math.abs(x - Math.floor(x)) / x > 1.0E-8  );
}, 1);

Clazz.newMeth(C$, 'fixExponentInt$D',  function (x) {
return (x == Math.floor(x)  ? String.valueOf$I((x|0)) : $I$(5,"rep$S$S$S",[C$.fixExponent$D(x), "E+00", ""]));
}, 1);

Clazz.newMeth(C$, 'fixExponent$D',  function (x) {
var s=$I$(6).formatDecimalDbl$D$I(x, -7);
var pt=s.indexOf$S("E");
if (pt < 0) {
return s;
}if (s.length$() == pt + 3) s=s.substring$I$I(0, pt + 2) + "0" + s.substring$I(pt + 2) ;
return s;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.newLine=System.getProperty$S("line.separator");
};
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:06 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
