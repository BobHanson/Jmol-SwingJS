(function(){var P$=Clazz.newPackage("jspecview.app");
/*c*/var C$=Clazz.newClass(P$, "JSVAppPro", null, 'jspecview.app.JSVApp', ['org.jmol.api.JSVInterface', 'jspecview.api.ScriptInterface']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$jspecview_api_AppletFrame$Z',  function (appletFrame, isJS) {
;C$.superclazz.c$$jspecview_api_AppletFrame$Z.apply(this,[appletFrame, isJS]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'isSigned$',  function () {
return true;
});

Clazz.newMeth(C$, 'isPro$',  function () {
return true;
});

Clazz.newMeth(C$, 'exitJSpecView$Z$O',  function (withDialog, frame) {
this.appletFrame.doExitJmol$();
});

Clazz.newMeth(C$, 'siProcessCommand$S',  function (script) {
this.appletFrame.getApp$().runScriptNow$S(script);
});

Clazz.newMeth(C$, 'saveProperties$java_util_Properties',  function (properties) {
});

Clazz.newMeth(C$, 'setProperties$java_util_Properties',  function (properties) {
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:55 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
