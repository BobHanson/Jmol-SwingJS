(function(){var P$=Clazz.newPackage("jspecview.app"),p$1={},I$=[[0,'jspecview.common.JSViewer','jspecview.common.JSVFileManager','javajs.util.PT','jspecview.common.ScriptToken','org.jmol.util.Logger','jspecview.common.Coordinate','javajs.util.Lst','jspecview.common.JSVersion']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JSVApp", null, null, ['jspecview.api.PanelListener', 'jspecview.api.JSVAppInterface', 'jspecview.api.ScriptInterface']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['isNewWindow'],'S',['appletReadyCallbackFunctionName','coordCallbackFunctionName','loadFileCallbackFunctionName','peakCallbackFunctionName','syncCallbackFunctionName'],'O',['appletFrame','jspecview.api.AppletFrame','vwr','jspecview.common.JSViewer','prevPanel','jspecview.api.JSVPanel']]]

Clazz.newMeth(C$, 'c$$jspecview_api_AppletFrame$Z',  function (appletFrame, isJS) {
;C$.$init$.apply(this);
this.appletFrame=appletFrame;
p$1.initViewer$Z.apply(this, [isJS]);
this.initParams$S(appletFrame.getParameter$S("script"));
}, 1);

Clazz.newMeth(C$, 'initViewer$Z',  function (isJS) {
this.vwr=Clazz.new_($I$(1,1).c$$jspecview_api_ScriptInterface$Z$Z,[this, true, isJS]);
this.appletFrame.setDropTargetListener$Z$jspecview_common_JSViewer(this.isSigned$(), this.vwr);
var path=this.appletFrame.getDocumentBase$();
$I$(2).setDocumentBase$jspecview_common_JSViewer$java_net_URL(this.vwr, path);
}, p$1);

Clazz.newMeth(C$, 'isPro$',  function () {
return this.isSigned$();
});

Clazz.newMeth(C$, 'isSigned$',  function () {
{
return true;
}
});

Clazz.newMeth(C$, 'getAppletFrame$',  function () {
return this.appletFrame;
});

Clazz.newMeth(C$, 'dispose$',  function () {
try {
this.vwr.dispose$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'getPropertyAsJavaObject$S',  function (key) {
return this.vwr.getPropertyAsJavaObject$S(key);
});

Clazz.newMeth(C$, 'getPropertyAsJSON$S',  function (key) {
return $I$(3,"toJSON$S$O",[null, this.getPropertyAsJavaObject$S(key)]);
});

Clazz.newMeth(C$, 'getCoordinate$',  function () {
return this.vwr.getCoordinate$();
});

Clazz.newMeth(C$, 'loadInline$S',  function (data) {
this.siOpenDataOrFile$O$S$javajs_util_Lst$S$I$I$Z$S$S(data, "[inline]", null, null, -1, -1, true, null, null);
this.appletFrame.validateContent$I(3);
});

Clazz.newMeth(C$, 'exportSpectrum$S$I',  function (type, n) {
return this.vwr.export$S$I(type, n);
});

Clazz.newMeth(C$, 'setFilePath$S',  function (tmpFilePath) {
this.runScript$S("load " + $I$(3).esc$S(tmpFilePath));
});

Clazz.newMeth(C$, 'setSpectrumNumber$I',  function (n) {
this.runScript$S($I$(4).SPECTRUMNUMBER + " " + n );
});

Clazz.newMeth(C$, 'reversePlot$',  function () {
p$1.toggle$jspecview_common_ScriptToken.apply(this, [$I$(4).REVERSEPLOT]);
});

Clazz.newMeth(C$, 'toggleGrid$',  function () {
p$1.toggle$jspecview_common_ScriptToken.apply(this, [$I$(4).GRIDON]);
});

Clazz.newMeth(C$, 'toggleCoordinate$',  function () {
p$1.toggle$jspecview_common_ScriptToken.apply(this, [$I$(4).COORDINATESON]);
});

Clazz.newMeth(C$, 'togglePointsOnly$',  function () {
p$1.toggle$jspecview_common_ScriptToken.apply(this, [$I$(4).POINTSONLY]);
});

Clazz.newMeth(C$, 'toggleIntegration$',  function () {
p$1.toggle$jspecview_common_ScriptToken.apply(this, [$I$(4).INTEGRATE]);
});

Clazz.newMeth(C$, 'toggle$jspecview_common_ScriptToken',  function (st) {
if (this.vwr.selectedPanel != null ) this.runScript$S(st + " TOGGLE");
}, p$1);

Clazz.newMeth(C$, 'addHighlight$D$D$I$I$I$I',  function (x1, x2, r, g, b, a) {
this.runScript$S("HIGHLIGHT " + new Double(x1).toString() + " " + new Double(x2).toString() + " " + r + " " + g + " " + b + " " + a );
});

Clazz.newMeth(C$, 'removeHighlight$D$D',  function (x1, x2) {
this.runScript$S("HIGHLIGHT " + new Double(x1).toString() + " " + new Double(x2).toString() + " OFF" );
});

Clazz.newMeth(C$, 'removeAllHighlights$',  function () {
this.runScript$S("HIGHLIGHT OFF");
});

Clazz.newMeth(C$, 'syncScript$S',  function (peakScript) {
this.vwr.syncScript$S(peakScript);
});

Clazz.newMeth(C$, 'writeStatus$S',  function (msg) {
$I$(5).info$S(msg);
});

Clazz.newMeth(C$, 'initParams$S',  function (params) {
this.vwr.parseInitScript$S(params);
p$1.newAppletPanel.apply(this, []);
this.vwr.setPopupMenu$Z$Z(this.vwr.allowMenu, this.vwr.parameters.getBoolean$jspecview_common_ScriptToken($I$(4).ENABLEZOOM));
if (this.vwr.allowMenu) {
this.vwr.closeSource$jspecview_source_JDXSource(null);
}this.runScriptNow$S(params);
});

Clazz.newMeth(C$, 'newAppletPanel',  function () {
$I$(5).info$S("newAppletPanel");
this.appletFrame.createMainPanel$jspecview_common_JSViewer(this.vwr);
}, p$1);

Clazz.newMeth(C$, 'repaint$',  function () {
var applet=(this.vwr == null  ? null : this.vwr.html5Applet);
if ($I$(1).jmolObject == null ) {
this.appletFrame.repaint$();
} else if (applet != null ) {
$I$(1).jmolObject.repaint(applet, true);
}});

Clazz.newMeth(C$, 'updateJS$I$I',  function (width, height) {
});

Clazz.newMeth(C$, 'runScriptNow$S',  function (params) {
return this.vwr.runScriptNow$S(params);
});

Clazz.newMeth(C$, 'checkCallbacks',  function () {
if (this.coordCallbackFunctionName == null  && this.peakCallbackFunctionName == null  ) return;
var coord=Clazz.new_($I$(6,1));
var actualCoord=(this.peakCallbackFunctionName == null  ? null : Clazz.new_($I$(6,1)));
if (!this.vwr.pd$().getPickedCoordinates$jspecview_common_Coordinate$jspecview_common_Coordinate(coord, actualCoord)) return;
var iSpec=this.vwr.mainPanel.getCurrentPanelIndex$();
if (actualCoord == null ) this.appletFrame.callToJavaScript$S$OA(this.coordCallbackFunctionName, Clazz.array(java.lang.Object, -1, [Double.valueOf$D(coord.getXVal$()), Double.valueOf$D(coord.getYVal$()), Integer.valueOf$I(iSpec + 1)]));
 else this.appletFrame.callToJavaScript$S$OA(this.peakCallbackFunctionName, Clazz.array(java.lang.Object, -1, [Double.valueOf$D(coord.getXVal$()), Double.valueOf$D(coord.getYVal$()), Double.valueOf$D(actualCoord.getXVal$()), Double.valueOf$D(actualCoord.getYVal$()), Integer.valueOf$I(iSpec + 1)]));
}, p$1);

Clazz.newMeth(C$, 'doAdvanced$S',  function (filePath) {
});

Clazz.newMeth(C$, 'panelEvent$O',  function (eventObj) {
if (Clazz.instanceOf(eventObj, "jspecview.common.PeakPickEvent")) {
this.vwr.processPeakPickEvent$O$Z(eventObj, false);
} else if (Clazz.instanceOf(eventObj, "jspecview.common.ZoomEvent")) {
} else if (Clazz.instanceOf(eventObj, "jspecview.common.SubSpecChangeEvent")) {
}});

Clazz.newMeth(C$, 'getSolnColour$',  function () {
return this.vwr.getSolutionColorStr$Z(true);
});

Clazz.newMeth(C$, 'updateJSView$S',  function (msg) {
var applet=this.vwr.html5Applet;
var panel=(applet == null  ? null : this.vwr.selectedPanel);
{
if (!applet || applet._viewSet == null) return;
}
applet._updateView(panel, msg);
}, p$1);

Clazz.newMeth(C$, 'syncToJmol$S',  function (msg) {
p$1.updateJSView$S.apply(this, [msg]);
if (this.syncCallbackFunctionName == null ) return;
$I$(5).info$S("JSVApp.syncToJmol JSV>Jmol " + msg);
this.appletFrame.callToJavaScript$S$OA(this.syncCallbackFunctionName, Clazz.array(java.lang.Object, -1, [this.vwr.fullName, msg]));
});

Clazz.newMeth(C$, 'setVisible$Z',  function (b) {
this.appletFrame.setPanelVisible$Z(b);
});

Clazz.newMeth(C$, 'setCursor$I',  function (id) {
this.vwr.apiPlatform.setCursor$I$O(id, this.appletFrame);
});

Clazz.newMeth(C$, 'runScript$S',  function (script) {
this.vwr.runScript$S(script);
});

Clazz.newMeth(C$, 'getScriptQueue$',  function () {
return this.vwr.scriptQueue;
});

Clazz.newMeth(C$, 'siSetCurrentSource$jspecview_source_JDXSource',  function (source) {
this.vwr.currentSource=source;
});

Clazz.newMeth(C$, 'siSendPanelChange$',  function () {
if (this.vwr.selectedPanel === this.prevPanel ) return;
this.prevPanel=this.vwr.selectedPanel;
this.vwr.sendPanelChange$();
});

Clazz.newMeth(C$, 'siNewWindow$Z$Z',  function (isSelected, fromFrame) {
this.isNewWindow=isSelected;
if (fromFrame) {
if (this.vwr.jsvpPopupMenu != null ) this.vwr.jsvpPopupMenu.setSelected$S$Z("Window", false);
} else {
this.appletFrame.newWindow$Z(isSelected);
}});

Clazz.newMeth(C$, 'siValidateAndRepaint$Z',  function (isAll) {
var pd=this.vwr.pd$();
if (pd != null ) pd.setTaintedAll$();
this.appletFrame.validate$();
this.repaint$();
});

Clazz.newMeth(C$, 'siSyncLoad$S',  function (filePath) {
p$1.newAppletPanel.apply(this, []);
$I$(5).info$S("JSVP syncLoad reading " + filePath);
this.siOpenDataOrFile$O$S$javajs_util_Lst$S$I$I$Z$S$S(null, null, null, filePath, -1, -1, false, null, null);
this.appletFrame.validateContent$I(3);
});

Clazz.newMeth(C$, 'siOpenDataOrFile$O$S$javajs_util_Lst$S$I$I$Z$S$S',  function (data, name, specs, url, firstSpec, lastSpec, isAppend, script, id) {
switch (this.vwr.openDataOrFile$O$S$javajs_util_Lst$S$I$I$Z$S(data, name, specs, url, firstSpec, lastSpec, isAppend, id)) {
case 0:
if (script != null ) this.runScript$S(script);
break;
case -1:
return;
default:
this.siSetSelectedPanel$jspecview_api_JSVPanel(null);
return;
}
$I$(5,"info$S",[this.appletFrame.getAppletInfo$() + " File " + this.vwr.currentSource.getFilePath$() + " Loaded Successfully" ]);
});

Clazz.newMeth(C$, 'siProcessCommand$S',  function (scriptItem) {
this.vwr.runScriptNow$S(scriptItem);
});

Clazz.newMeth(C$, 'siSetSelectedPanel$jspecview_api_JSVPanel',  function (jsvp) {
this.vwr.mainPanel.setSelectedPanel$jspecview_common_JSViewer$jspecview_api_JSVPanel$javajs_util_Lst(this.vwr, jsvp, this.vwr.panelNodes);
this.vwr.selectedPanel=jsvp;
this.vwr.spectraTree.setSelectedPanel$jspecview_api_ScriptInterface$jspecview_api_JSVPanel(this, jsvp);
if (jsvp == null ) {
this.vwr.selectedPanel=jsvp=this.appletFrame.getJSVPanel$jspecview_common_JSViewer$javajs_util_Lst(this.vwr, null);
this.vwr.mainPanel.setSelectedPanel$jspecview_common_JSViewer$jspecview_api_JSVPanel$javajs_util_Lst(this.vwr, jsvp, null);
}this.appletFrame.validate$();
if (jsvp != null ) {
jsvp.setEnabled$Z(true);
jsvp.setFocusable$Z(true);
}});

Clazz.newMeth(C$, 'siExecSetCallback$jspecview_common_ScriptToken$S',  function (st, value) {
switch (st) {
case $I$(4).APPLETREADYCALLBACKFUNCTIONNAME:
this.appletReadyCallbackFunctionName=value;
break;
case $I$(4).LOADFILECALLBACKFUNCTIONNAME:
this.loadFileCallbackFunctionName=value;
break;
case $I$(4).PEAKCALLBACKFUNCTIONNAME:
this.peakCallbackFunctionName=value;
break;
case $I$(4).SYNCCALLBACKFUNCTIONNAME:
this.syncCallbackFunctionName=value;
break;
case $I$(4).COORDCALLBACKFUNCTIONNAME:
this.coordCallbackFunctionName=value;
break;
}
});

Clazz.newMeth(C$, 'siLoaded$S',  function (value) {
if (this.loadFileCallbackFunctionName != null ) this.appletFrame.callToJavaScript$S$OA(this.loadFileCallbackFunctionName, Clazz.array(java.lang.Object, -1, [this.vwr.appletName, value]));
p$1.updateJSView$S.apply(this, [null]);
return null;
});

Clazz.newMeth(C$, 'siExecHidden$Z',  function (b) {
});

Clazz.newMeth(C$, 'siExecScriptComplete$S$Z',  function (msg, isOK) {
if (!isOK) this.vwr.showMessage$S(msg);
this.siValidateAndRepaint$Z(false);
});

Clazz.newMeth(C$, 'siUpdateBoolean$jspecview_common_ScriptToken$Z',  function (st, TF) {
});

Clazz.newMeth(C$, 'siCheckCallbacks$S',  function (title) {
p$1.checkCallbacks.apply(this, []);
});

Clazz.newMeth(C$, 'siNodeSet$jspecview_common_PanelNode',  function (panelNode) {
this.appletFrame.validateContent$I(2);
this.siValidateAndRepaint$Z(false);
});

Clazz.newMeth(C$, 'siSourceClosed$jspecview_source_JDXSource',  function (source) {
});

Clazz.newMeth(C$, 'siGetNewJSVPanel$jspecview_common_Spectrum',  function (spec) {
if (spec == null ) {
this.vwr.initialEndIndex=this.vwr.initialStartIndex=-1;
return null;
}var specs=Clazz.new_($I$(7,1));
specs.addLast$O(spec);
var jsvp=this.appletFrame.getJSVPanel$jspecview_common_JSViewer$javajs_util_Lst(this.vwr, specs);
jsvp.getPanelData$().addListener$jspecview_api_PanelListener(this);
this.vwr.parameters.setFor$jspecview_api_JSVPanel$jspecview_common_ColorParameters$Z(jsvp, null, true);
return jsvp;
});

Clazz.newMeth(C$, 'siGetNewJSVPanel2$javajs_util_Lst',  function (specs) {
if (specs == null ) {
this.vwr.initialEndIndex=this.vwr.initialStartIndex=-1;
return this.appletFrame.getJSVPanel$jspecview_common_JSViewer$javajs_util_Lst(this.vwr, null);
}var jsvp=this.appletFrame.getJSVPanel$jspecview_common_JSViewer$javajs_util_Lst(this.vwr, specs);
this.vwr.initialEndIndex=this.vwr.initialStartIndex=-1;
jsvp.getPanelData$().addListener$jspecview_api_PanelListener(this);
this.vwr.parameters.setFor$jspecview_api_JSVPanel$jspecview_common_ColorParameters$Z(jsvp, null, true);
return jsvp;
});

Clazz.newMeth(C$, 'siSetPropertiesFromPreferences$jspecview_api_JSVPanel$Z',  function (jsvp, includeMeasures) {
this.vwr.checkAutoIntegrate$();
});

Clazz.newMeth(C$, 'siSetLoaded$S$S',  function (fileName, filePath) {
});

Clazz.newMeth(C$, 'siSetMenuEnables$jspecview_common_PanelNode$Z',  function (node, isSplit) {
});

Clazz.newMeth(C$, 'siUpdateRecentMenus$S',  function (filePath) {
});

Clazz.newMeth(C$, 'siExecTest$S',  function (value) {
var data="";
this.loadInline$S(data);
});

Clazz.newMeth(C$, 'print$S',  function (fileName) {
return this.vwr.print$S(fileName);
});

Clazz.newMeth(C$, 'checkScript$S',  function (script) {
return this.vwr.checkScript$S(script);
});

Clazz.newMeth(C$, 'getAppletInfo$',  function () {
return "JSpecView Applet " + $I$(8).VERSION + "\n\n" + "Authors:\nProf. Robert M. Hanson,\nD. Facey, K. Bryan, C. Walters, Prof. Robert J. Lancashire and\nvolunteer developers through sourceforge." ;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:55 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
