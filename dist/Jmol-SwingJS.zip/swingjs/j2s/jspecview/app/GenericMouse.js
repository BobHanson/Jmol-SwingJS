(function(){var P$=Clazz.newPackage("jspecview.app"),I$=[[0,'org.jmol.util.Logger']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "GenericMouse", null, null, 'org.jmol.api.GenericMouseInterface');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['isMouseDown','disposed'],'I',['xWhenPressed','yWhenPressed','modifiersWhenPressed10'],'O',['pd','org.jmol.api.EventManager','jsvp','jspecview.api.JSVPanel']]]

Clazz.newMeth(C$, 'c$$jspecview_api_JSVPanel',  function (jsvp) {
;C$.$init$.apply(this);
this.jsvp=jsvp;
this.pd=jsvp.getPanelData$();
}, 1);

Clazz.newMeth(C$, 'clear$',  function () {
});

Clazz.newMeth(C$, 'processEvent$I$I$I$I$J',  function (id, x, y, modifiers, time) {
if (this.pd == null ) {
if (!this.disposed && id == 501  && (modifiers & 4) != 0 ) this.jsvp.showMenu$I$I(x, y);
return true;
}if (id != 507) modifiers=C$.applyLeftMouse$I(modifiers);
switch (id) {
case 507:
this.wheeled$J$I$I(time, x, modifiers | 32);
break;
case 501:
this.xWhenPressed=x;
this.yWhenPressed=y;
this.modifiersWhenPressed10=modifiers;
this.pressed$J$I$I$I$Z(time, x, y, modifiers, false);
break;
case 506:
this.dragged$J$I$I$I(time, x, y, modifiers);
break;
case 504:
this.entered$J$I$I(time, x, y);
break;
case 505:
this.exited$J$I$I(time, x, y);
break;
case 503:
this.moved$J$I$I$I(time, x, y, modifiers);
break;
case 502:
this.released$J$I$I$I(time, x, y, modifiers);
if (x == this.xWhenPressed && y == this.yWhenPressed  && modifiers == this.modifiersWhenPressed10 ) {
this.clicked$J$I$I$I$I(time, x, y, modifiers, 1);
}break;
default:
return false;
}
return true;
});

Clazz.newMeth(C$, 'mouseEntered$java_awt_event_MouseEvent',  function (e) {
this.entered$J$I$I(e.getWhen$(), e.getX$(), e.getY$());
});

Clazz.newMeth(C$, 'mouseExited$java_awt_event_MouseEvent',  function (e) {
this.exited$J$I$I(e.getWhen$(), e.getX$(), e.getY$());
});

Clazz.newMeth(C$, 'mouseMoved$java_awt_event_MouseEvent',  function (e) {
this.moved$J$I$I$I(e.getWhen$(), e.getX$(), e.getY$(), e.getModifiers$());
});

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent',  function (e) {
this.pressed$J$I$I$I$Z(e.getWhen$(), e.getX$(), e.getY$(), e.getModifiers$(), e.isPopupTrigger$());
});

Clazz.newMeth(C$, 'mouseDragged$java_awt_event_MouseEvent',  function (e) {
var modifiers=e.getModifiers$();
if ((modifiers & 28) == 0) modifiers|=16;
this.dragged$J$I$I$I(e.getWhen$(), e.getX$(), e.getY$(), modifiers);
});

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent',  function (e) {
this.released$J$I$I$I(e.getWhen$(), e.getX$(), e.getY$(), e.getModifiers$());
});

Clazz.newMeth(C$, 'mouseClicked$java_awt_event_MouseEvent',  function (e) {
this.clicked$J$I$I$I$I(e.getWhen$(), e.getX$(), e.getY$(), e.getModifiers$(), e.getClickCount$());
});

Clazz.newMeth(C$, 'mouseWheelMoved$java_awt_event_MouseWheelEvent',  function (e) {
e.consume$();
this.wheeled$J$I$I(e.getWhen$(), e.getWheelRotation$(), e.getModifiers$() | 32);
});

Clazz.newMeth(C$, 'keyTyped$java_awt_event_KeyEvent',  function (ke) {
if (this.pd == null ) return;
var ch=ke.getKeyChar$();
var modifiers=ke.getModifiers$();
if ($I$(1).debuggingHigh || true ) $I$(1,"info$S",["MouseManager keyTyped: " + ch + " " + (0 + ch.$c()) + " " + modifiers ]);
if (this.pd.keyTyped$I$I(ch.$c(), modifiers)) ke.consume$();
});

Clazz.newMeth(C$, 'keyPressed$java_awt_event_KeyEvent',  function (ke) {
if (this.pd != null  && this.pd.keyPressed$I$I(ke.getKeyCode$(), ke.getModifiers$()) ) ke.consume$();
});

Clazz.newMeth(C$, 'keyReleased$java_awt_event_KeyEvent',  function (ke) {
if (this.pd != null ) this.pd.keyReleased$I(ke.getKeyCode$());
});

Clazz.newMeth(C$, 'entered$J$I$I',  function (time, x, y) {
if (this.pd != null ) this.pd.mouseEnterExit$J$I$I$Z(time, x, y, false);
});

Clazz.newMeth(C$, 'exited$J$I$I',  function (time, x, y) {
if (this.pd != null ) this.pd.mouseEnterExit$J$I$I$Z(time, x, y, true);
});

Clazz.newMeth(C$, 'clicked$J$I$I$I$I',  function (time, x, y, modifiers, clickCount) {
if (this.pd != null ) this.pd.mouseAction$I$J$I$I$I$I(2, time, x, y, 1, modifiers);
});

Clazz.newMeth(C$, 'moved$J$I$I$I',  function (time, x, y, modifiers) {
if (this.pd == null ) return;
if (this.isMouseDown) this.pd.mouseAction$I$J$I$I$I$I(1, time, x, y, 0, C$.applyLeftMouse$I(modifiers));
 else this.pd.mouseAction$I$J$I$I$I$I(0, time, x, y, 0, modifiers & ~28);
});

Clazz.newMeth(C$, 'wheeled$J$I$I',  function (time, rotation, modifiers) {
if (this.pd != null ) this.pd.mouseAction$I$J$I$I$I$I(3, time, 0, rotation, 0, modifiers);
});

Clazz.newMeth(C$, 'pressed$J$I$I$I$Z',  function (time, x, y, modifiers, isPopupTrigger) {
if (this.pd == null ) {
if (!this.disposed) this.jsvp.showMenu$I$I(x, y);
return;
}this.isMouseDown=true;
this.pd.mouseAction$I$J$I$I$I$I(4, time, x, y, 0, modifiers);
});

Clazz.newMeth(C$, 'released$J$I$I$I',  function (time, x, y, modifiers) {
if (this.pd == null ) return;
this.isMouseDown=false;
this.pd.mouseAction$I$J$I$I$I$I(5, time, x, y, 0, modifiers);
});

Clazz.newMeth(C$, 'dragged$J$I$I$I',  function (time, x, y, modifiers) {
if (this.pd == null ) return;
if ((modifiers & 20) == 20) modifiers=modifiers & ~4 | 2;
this.pd.mouseAction$I$J$I$I$I$I(1, time, x, y, 0, modifiers);
});

Clazz.newMeth(C$, 'applyLeftMouse$I',  function (modifiers) {
return ((modifiers & 28) == 0) ? (modifiers | 16) : modifiers;
}, 1);

Clazz.newMeth(C$, 'processTwoPointGesture$DAAA',  function (touches) {
});

Clazz.newMeth(C$, 'dispose$',  function () {
this.pd=null;
this.jsvp=null;
this.disposed=true;
});

Clazz.newMeth(C$, 'processKeyEvent$O',  function (event) {
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:55 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
