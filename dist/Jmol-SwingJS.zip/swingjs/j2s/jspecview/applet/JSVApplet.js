(function(){var P$=Clazz.newPackage("jspecview.applet"),I$=[[0,'Thread','org.jmol.util.Logger','jspecview.app.JSVApp','javajs.util.Lst',['jspecview.applet.JSVApplet','.CommandWatcher'],'jspecview.java.AwtMainPanel','java.awt.BorderLayout','javax.swing.JFrame','java.awt.event.WindowAdapter','jspecview.java.AwtPanel']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JSVApplet", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'javax.swing.JApplet', ['jspecview.api.JSVAppletInterface', 'jspecview.api.AppletFrame', 'java.awt.event.KeyListener']);
C$.$classes$=[['CommandWatcher',0]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.isStandalone=false;
},1);

C$.$fields$=[['Z',['isStandalone','isJNLP'],'O',['commandWatcherThread','Thread','app','jspecview.app.JSVApp','viewer','jspecview.common.JSViewer','dtl','java.awt.dnd.DropTargetListener','mainPanel','java.awt.Component','offWindowFrame','javax.swing.JFrame']]]

Clazz.newMeth(C$, ['init$','init'],  function () {
this.app=Clazz.new_($I$(3,1).c$$jspecview_api_AppletFrame$Z,[this, false]);
this.init2$();
});

Clazz.newMeth(C$, 'init2$',  function () {
this.isJNLP=(this.getParameter$S("syncId") == null );
this.viewer=this.app.vwr;
this.viewer.display=this.getContentPane$();
this.viewer.scriptQueue=Clazz.new_($I$(4,1));
this.commandWatcherThread=Clazz.new_([Clazz.new_($I$(5,1),[this, null])],$I$(1,1).c$$Runnable);
this.commandWatcherThread.setName$S("CommmandWatcherThread");
this.commandWatcherThread.start$();
$I$(2,"info$S",[this.getAppletInfo$()]);
if (this.app.appletReadyCallbackFunctionName != null  && this.viewer.fullName != null  ) this.callToJavaScript$S$OA(this.app.appletReadyCallbackFunctionName, Clazz.array(java.lang.Object, -1, [this.viewer.appletName, this.viewer.fullName, Boolean.TRUE, this]));
});

Clazz.newMeth(C$, ['isPro$','isPro'],  function () {
return this.app.isPro$();
});

Clazz.newMeth(C$, ['isSigned$','isSigned'],  function () {
return this.app.isSigned$();
});

Clazz.newMeth(C$, ['finalize$','finalize'],  function () {
System.out.println$S("JSpecView " + this + " finalized" );
});

Clazz.newMeth(C$, ['destroy$','destroy'],  function () {
System.out.println$S("destroy called on " + this);
if (this.commandWatcherThread != null ) {
this.commandWatcherThread.interrupt$();
this.commandWatcherThread=null;
}this.app.dispose$();
this.app=null;
if (this.isJNLP) System.exit$I(0);
});

Clazz.newMeth(C$, ['getParameter$S$S','getParameter'],  function (key, def) {
return this.isStandalone ? System.getProperty$S$S(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, ['getAppletInfo$','getAppletInfo'],  function () {
return $I$(3).getAppletInfo$();
});

Clazz.newMeth(C$, ['getSolnColour$','getSolnColour'],  function () {
return this.app.getSolnColour$();
});

Clazz.newMeth(C$, ['getCoordinate$','getCoordinate'],  function () {
return this.app.getCoordinate$();
});

Clazz.newMeth(C$, ['loadInline$S','loadInline'],  function (data) {
this.app.loadInline$S(data);
});

Clazz.newMeth(C$, ['export$S$I','export'],  function (type, n) {
return this.app.exportSpectrum$S$I(type, n);
});

Clazz.newMeth(C$, ['exportSpectrum$S$I','exportSpectrum'],  function (type, n) {
return this.app.exportSpectrum$S$I(type, n);
});

Clazz.newMeth(C$, ['setFilePath$S','setFilePath'],  function (tmpFilePath) {
this.app.setFilePath$S(tmpFilePath);
});

Clazz.newMeth(C$, ['setSpectrumNumber$I','setSpectrumNumber'],  function (i) {
this.app.setSpectrumNumber$I(i);
});

Clazz.newMeth(C$, ['toggleGrid$','toggleGrid'],  function () {
this.app.toggleGrid$();
});

Clazz.newMeth(C$, ['toggleCoordinate$','toggleCoordinate'],  function () {
this.app.toggleCoordinate$();
});

Clazz.newMeth(C$, ['togglePointsOnly$','togglePointsOnly'],  function () {
this.app.togglePointsOnly$();
});

Clazz.newMeth(C$, ['toggleIntegration$','toggleIntegration'],  function () {
this.app.toggleIntegration$();
});

Clazz.newMeth(C$, ['addHighlight$D$D$I$I$I$I','addHighlight'],  function (x1, x2, r, g, b, a) {
this.app.addHighlight$D$D$I$I$I$I(x1, x2, r, g, b, a);
});

Clazz.newMeth(C$, ['removeAllHighlights$','removeAllHighlights'],  function () {
this.app.removeAllHighlights$();
});

Clazz.newMeth(C$, ['removeHighlight$D$D','removeHighlight'],  function (x1, x2) {
this.app.removeHighlight$D$D(x1, x2);
});

Clazz.newMeth(C$, ['reversePlot$','reversePlot'],  function () {
this.app.reversePlot$();
});

Clazz.newMeth(C$, ['script$S','script'],  function (script) {
this.app.initParams$S(script);
});

Clazz.newMeth(C$, ['runScript$S','runScript'],  function (script) {
this.app.runScript$S(script);
});

Clazz.newMeth(C$, ['syncScript$S','syncScript'],  function (peakScript) {
this.app.syncScript$S(peakScript);
});

Clazz.newMeth(C$, ['writeStatus$S','writeStatus'],  function (msg) {
this.app.writeStatus$S(msg);
});

Clazz.newMeth(C$, ['getPropertyAsJavaObject$S','getPropertyAsJavaObject'],  function (key) {
return this.app.getPropertyAsJavaObject$S(key);
});

Clazz.newMeth(C$, ['getPropertyAsJSON$S','getPropertyAsJSON'],  function (key) {
return this.app.getPropertyAsJSON$S(key);
});

Clazz.newMeth(C$, ['runScriptNow$S','runScriptNow'],  function (script) {
return this.app.runScriptNow$S(script);
});

Clazz.newMeth(C$, ['setDropTargetListener$Z$jspecview_common_JSViewer','setDropTargetListener'],  function (isSigned, viewer) {
if (this.dtl == null  && isSigned ) this.dtl=(viewer.getPlatformInterface$S("FileDropper")).set$jspecview_common_JSViewer(viewer);
});

Clazz.newMeth(C$, ['validateContent$I','validateContent'],  function (mode) {
if ((mode & 1) == 1) this.getContentPane$().validate$();
if ((mode & 2) == 2) this.mainPanel.validate$();
});

Clazz.newMeth(C$, ['createMainPanel$jspecview_common_JSViewer','createMainPanel'],  function (viewer) {
this.getContentPane$().removeAll$();
this.mainPanel=(viewer.mainPanel=Clazz.new_([Clazz.new_($I$(7,1))],$I$(6,1).c$$java_awt_BorderLayout));
this.getContentPane$().add$java_awt_Component(this.mainPanel);
});

Clazz.newMeth(C$, ['newWindow$Z','newWindow'],  function (isSelected) {
if (isSelected) {
this.offWindowFrame=Clazz.new_($I$(8,1).c$$S,["JSpecView"]);
this.offWindowFrame.setSize$java_awt_Dimension(this.getSize$());
var d=this.mainPanel.getSize$();
this.offWindowFrame.add$java_awt_Component(this.mainPanel);
this.offWindowFrame.validate$();
this.offWindowFrame.setVisible$Z(true);
this.remove$java_awt_Component(this.mainPanel);
this.app.siValidateAndRepaint$Z(false);
this.offWindowFrame.addWindowListener$java_awt_event_WindowListener(((P$.JSVApplet$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "JSVApplet$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.WindowAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['windowClosing$java_awt_event_WindowEvent','windowClosing'],  function (e) {
this.b$['jspecview.applet.JSVApplet'].windowClosingEvent$java_awt_Dimension.apply(this.b$['jspecview.applet.JSVApplet'], [this.$finals$.d]);
});
})()
), Clazz.new_($I$(9,1),[this, {d:d}],P$.JSVApplet$1)));
} else {
this.getContentPane$().add$java_awt_Component(this.mainPanel);
this.app.siValidateAndRepaint$Z(false);
this.offWindowFrame.removeAll$();
this.offWindowFrame.dispose$();
this.offWindowFrame=null;
}});

Clazz.newMeth(C$, 'windowClosingEvent$java_awt_Dimension',  function (d) {
this.mainPanel.setSize$java_awt_Dimension(d);
this.getContentPane$().add$java_awt_Component(this.mainPanel);
this.setVisible$Z(true);
this.app.siValidateAndRepaint$Z(false);
this.offWindowFrame.removeAll$();
this.offWindowFrame.dispose$();
this.app.siNewWindow$Z$Z(false, true);
});

Clazz.newMeth(C$, ['callToJavaScript$S$OA','callToJavaScript'],  function (callback, params) {
});

Clazz.newMeth(C$, ['setPanelVisible$Z','setPanelVisible'],  function (b) {
this.mainPanel.setVisible$Z(b);
});

Clazz.newMeth(C$, ['getJSVPanel$jspecview_common_JSViewer$javajs_util_Lst','getJSVPanel'],  function (viewer, specs) {
return (specs == null  ? $I$(10).getEmptyPanel$jspecview_common_JSViewer(viewer) : $I$(10).getPanelMany$jspecview_common_JSViewer$javajs_util_Lst(viewer, specs));
});

Clazz.newMeth(C$, ['doExitJmol$','doExitJmol'],  function () {
});

Clazz.newMeth(C$, ['getApp$','getApp'],  function () {
return this.app;
});

Clazz.newMeth(C$, ['print$S','print'],  function (fileName) {
return this.app.print$S(fileName);
});

Clazz.newMeth(C$, ['keyTyped$java_awt_event_KeyEvent','keyTyped'],  function (e) {
});

Clazz.newMeth(C$, ['keyPressed$java_awt_event_KeyEvent','keyPressed'],  function (e) {
this.keyPressedEvent$I$C(e.getKeyCode$(), e.getKeyChar$());
});

Clazz.newMeth(C$, ['keyReleased$java_awt_event_KeyEvent','keyReleased'],  function (e) {
});

Clazz.newMeth(C$, 'keyPressedEvent$I$C',  function (keyCode, keyChar) {
});

Clazz.newMeth(C$, ['checkScript$S','checkScript'],  function (script) {
var s=this.app.checkScript$S(script);
if (s != null ) System.out.println$S(s);
return s;
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.JSVApplet, "CommandWatcher", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'Runnable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$',  function () {
$I$(1).currentThread$().setPriority$I(1);
var commandDelay=200;
while (this.b$['jspecview.applet.JSVApplet'].commandWatcherThread != null ){
try {
$I$(1).sleep$J(commandDelay);
if (this.b$['jspecview.applet.JSVApplet'].commandWatcherThread != null ) {
var q=this.b$['jspecview.applet.JSVApplet'].app.vwr.scriptQueue;
if (q.size$() > 0) {
var scriptItem=q.removeItemAt$I(0);
if (scriptItem != null ) this.b$['jspecview.applet.JSVApplet'].app.siProcessCommand$S(scriptItem);
}}} catch (e$$) {
if (Clazz.exceptionOf(e$$,"InterruptedException")){
var ie = e$$;
{
$I$(2).info$S("CommandWatcher InterruptedException!");
break;
}
} else if (Clazz.exceptionOf(e$$,"Exception")){
var ie = e$$;
{
var s="script processing ERROR:\n\n" + ie.toString();
for (var i=0; i < ie.getStackTrace$().length; i++) {
s+="\n" + ie.getStackTrace$()[i].toString();
}
$I$(2).info$S("CommandWatcher Exception! " + s);
break;
}
} else {
throw e$$;
}
}
}
this.b$['jspecview.applet.JSVApplet'].commandWatcherThread=null;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:27 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
