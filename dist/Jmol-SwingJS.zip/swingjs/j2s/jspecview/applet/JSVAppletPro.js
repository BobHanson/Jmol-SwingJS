(function(){var P$=Clazz.newPackage("jspecview.applet"),I$=[[0,'jspecview.app.JSVAppPro','java.net.URL']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JSVAppletPro", null, 'jspecview.applet.JSVApplet');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['app0','jspecview.app.JSVApp']]]

Clazz.newMeth(C$, ['init$','init'],  function () {
System.out.println$S("jsvappletpro init");
this.app=Clazz.new_($I$(1,1).c$$jspecview_api_AppletFrame$Z,[this, false]);
this.init2$();
});

Clazz.newMeth(C$, ['isPro$','isPro'],  function () {
return true;
});

Clazz.newMeth(C$, ['getAppletInfo$','getAppletInfo'],  function () {
return C$.superclazz.prototype.getAppletInfo$.apply(this, []) + " (PRO)";
});

Clazz.newMeth(C$, ['script$S','script'],  function (script) {
this.runScript$S(script);
});

Clazz.newMeth(C$, ['doExitJmol$','doExitJmol'],  function () {
this.app0.setVisible$Z(true);
this.app=this.app0;
});

Clazz.newMeth(C$, ['getDocumentBase$','getDocumentBase'],  function () {
try {
return Clazz.new_([null, this.getParameter$S("documentBase"), null],$I$(2,1).c$$java_net_URL$S$java_net_URLStreamHandler);
} catch (e) {
if (Clazz.exceptionOf(e,"java.net.MalformedURLException")){
return null;
} else {
throw e;
}
}
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:55 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
