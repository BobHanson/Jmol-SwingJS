(function(){var P$=Clazz.newPackage("jspecview.source"),p$1={},I$=[[0,'jspecview.source.JDXSource','jspecview.source.XMLReader','javajs.util.Base64','javajs.util.BC']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AnIMLReader", null, 'jspecview.source.XMLReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['inResult']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'getXML$java_io_BufferedReader',  function (br) {
try {
this.source=Clazz.new_($I$(1,1).c$$I$S,[0, this.filePath]);
this.getSimpleXmlReader$java_io_BufferedReader(br);
this.parser.nextEvent$();
this.processXML$I$I(0, 3);
if (!this.checkPointCount$()) return null;
this.xFactor=1;
this.yFactor=1;
this.populateVariables$();
} catch (pe) {
if (Clazz.exceptionOf(pe,"Exception")){
System.err.println$S("That file may be empty...");
this.errorLog.append$S("That file may be empty... \n");
} else {
throw pe;
}
}
this.processErrors$S("anIML");
try {
br.close$();
} catch (e1) {
if (Clazz.exceptionOf(e1,"java.io.IOException")){
} else {
throw e1;
}
}
return this.source;
});

Clazz.newMeth(C$, 'processTag$I',  function (tagId) {
switch (tagId) {
case 0:
p$1.processAuditTrail.apply(this, []);
return true;
case 1:
p$1.processExperimentStepSet.apply(this, []);
return true;
case 2:
p$1.processSampleSet.apply(this, []);
return true;
case 11:
p$1.processAuthor.apply(this, []);
return true;
case 3:
this.inResult=true;
return true;
default:
System.out.println$S("AnIMLReader not processing tag " + $I$(2).tagNames[tagId]);
return false;
}
});

Clazz.newMeth(C$, 'processEndTag$I',  function (tagId) {
switch (tagId) {
case 3:
case 1:
this.inResult=false;
break;
}
});

Clazz.newMeth(C$, 'processAuditTrail',  function () {
if (this.tagName.equals$O("user")) {
this.parser.qualifiedValue$();
} else if (this.tagName.equals$O("timestamp")) {
this.parser.qualifiedValue$();
}}, p$1);

Clazz.newMeth(C$, 'processSampleSet',  function () {
if (this.tagName.equals$O("sample")) ++this.samplenum;
 else if (this.tagName.equals$O("parameter")) {
this.attrList=this.parser.getAttrValueLC$S("name");
if (this.attrList.equals$O("name")) {
this.parser.qualifiedValue$();
} else if (this.attrList.equals$O("owner")) {
this.parser.qualifiedValue$();
} else if (this.attrList.equals$O("molecular formula")) {
this.molForm=this.parser.qualifiedValue$();
} else if (this.attrList.equals$O("cas registry number")) {
this.casRN=this.parser.qualifiedValue$();
}}}, p$1);

Clazz.newMeth(C$, 'processExperimentStepSet',  function () {
if (this.tagName.equals$O("result")) {
this.inResult=true;
} else if (this.tagName.equals$O("sampleref")) {
if (this.parser.getAttrValueLC$S("role").contains$CharSequence("samplemeasurement")) this.sampleID=this.parser.getAttrValue$S("sampleID");
} else if (this.tagName.equals$O("author")) {
this.process$I$Z(11, true);
} else if (this.tagName.equals$O("timestamp")) {
this.LongDate=this.parser.thisValue$();
} else if (this.tagName.equals$O("technique")) {
this.techname=this.parser.getAttrValue$S("name").toUpperCase$() + " SPECTRUM";
} else if (this.tagName.equals$O("vectorset") || this.tagName.equals$O("seriesset") && this.inResult  ) {
this.npoints=Integer.parseInt$S(this.parser.getAttrValue$S("length"));
this.xaxisData=Clazz.array(Double.TYPE, [this.npoints]);
this.yaxisData=Clazz.array(Double.TYPE, [this.npoints]);
} else if (this.tagName.equals$O("vector") || this.tagName.equals$O("series") && this.inResult  ) {
var axisLabel=this.parser.getAttrValue$S("name");
var dependency=this.parser.getAttrValueLC$S("dependency");
if (dependency.equals$O("independent")) {
this.xUnits=axisLabel;
p$1.getXValues.apply(this, []);
} else if (dependency.equals$O("dependent")) {
this.yUnits=axisLabel;
p$1.getYValues.apply(this, []);
}} else if (this.tagName.equals$O("parameter")) {
if ((this.attrList=this.parser.getAttrValueLC$S("name")).equals$O("identifier")) {
this.title=this.parser.qualifiedValue$();
} else if (this.attrList.equals$O("nucleus")) {
this.obNucleus=this.parser.qualifiedValue$();
} else if (this.attrList.equals$O("observefrequency")) {
this.StrObFreq=this.parser.qualifiedValue$();
this.obFreq=Double.parseDouble$S(this.StrObFreq);
} else if (this.attrList.equals$O("referencepoint")) {
this.refPoint=Double.parseDouble$S(this.parser.qualifiedValue$());
} else if (this.attrList.equals$O("sample path length")) {
this.pathlength=this.parser.qualifiedValue$();
} else if (this.attrList.equals$O("scanmode")) {
this.parser.thisValue$();
} else if (this.attrList.equals$O("manufacturer")) {
this.vendor=this.parser.thisValue$();
} else if (this.attrList.equals$O("model name")) {
this.modelType=this.parser.thisValue$();
} else if (this.attrList.equals$O("resolution")) {
this.resolution=this.parser.qualifiedValue$();
}}}, p$1);

Clazz.newMeth(C$, 'getXValues',  function () {
this.parser.nextTag$();
if (this.parser.getTagName$().equals$O("autoincrementedvalueset")) {
this.parser.nextTag$();
if (this.parser.getTagName$().equals$O("startvalue")) this.firstX=Double.parseDouble$S(this.parser.qualifiedValue$());
p$1.nextStartTag.apply(this, []);
if (this.parser.getTagName$().equals$O("increment")) this.deltaX=Double.parseDouble$S(this.parser.qualifiedValue$());
}if (!this.inResult) {
p$1.nextStartTag.apply(this, []);
this.xUnits=this.parser.getAttrValue$S("label");
}this.increasing=(this.deltaX > 0  ? true : false);
this.continuous=true;
for (var j=0; j < this.npoints; j++) this.xaxisData[j]=this.firstX + (this.deltaX * j);

this.lastX=this.xaxisData[this.npoints - 1];
}, p$1);

Clazz.newMeth(C$, 'nextStartTag',  function () {
this.parser.nextStartTag$();
while (this.parser.getTagType$() == 6){
this.parser.nextStartTag$();
}
}, p$1);

Clazz.newMeth(C$, 'getYValues',  function () {
var vectorType=this.parser.getAttrValueLC$S("type");
if (vectorType.length$() == 0) vectorType=this.parser.getAttrValueLC$S("vectorType");
this.parser.nextTag$();
this.tagName=this.parser.getTagName$();
if (this.tagName.equals$O("individualvalueset")) {
for (var ii=0; ii < this.npoints; ii++) this.yaxisData[ii]=Double.parseDouble$S(this.parser.qualifiedValue$());

} else if (this.tagName.equals$O("encodedvalueset")) {
this.attrList=this.parser.getCharacters$();
var dataArray=$I$(3).decodeBase64$S(this.attrList);
if (dataArray.length != 0) {
if (vectorType.equals$O("float64")) {
for (var i=0, pt=0; i < this.npoints; i++, pt+=8) this.yaxisData[i]=$I$(4).bytesToDoubleToFloat$BA$I$Z(dataArray, pt, false);

} else {
for (var i=0, pt=0; i < this.npoints; i++, pt+=4) this.yaxisData[i]=$I$(4).bytesToFloat$BA$I$Z(dataArray, pt, false);

}}}this.parser.nextStartTag$();
this.tagName=this.parser.getTagName$();
this.yUnits=this.parser.getAttrValue$S("label");
this.firstY=this.yaxisData[0];
}, p$1);

Clazz.newMeth(C$, 'processAuthor',  function () {
if (this.tagName.equals$O("name")) this.owner=this.parser.thisValue$();
 else if (this.tagName.contains$CharSequence("location")) this.origin=this.parser.thisValue$();
}, p$1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:58 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
