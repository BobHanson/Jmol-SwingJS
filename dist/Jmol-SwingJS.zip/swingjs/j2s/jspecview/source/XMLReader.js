(function(){var P$=Clazz.newPackage("jspecview.source"),I$=[[0,'javajs.util.SB','jspecview.source.XMLParser','javajs.util.Lst','jspecview.common.Spectrum','jspecview.source.JDXReader','jspecview.common.Coordinate','org.jmol.util.Logger']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "XMLReader", null, null, 'jspecview.api.SourceReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.filePath="";
this.tagName="START";
this.attrList="";
this.title="";
this.owner="UNKNOWN";
this.origin="UNKNOWN";
this.tmpEnd="END";
this.molForm="";
this.techname="";
this.npoints=-1;
this.samplenum=-1;
this.xUnits="";
this.yUnits="ARBITRARY UNITS";
this.vendor="na";
this.modelType="MODEL UNKNOWN";
this.LongDate="";
this.pathlength="na";
this.identifier="";
this.plLabel="";
this.resolution="na";
this.resLabel="";
this.LocName="";
this.LocContact="";
this.casName="";
this.sampleowner="";
this.obNucleus="";
this.StrObFreq="";
this.increasing=false;
this.continuous=false;
this.sampleRefNum=0;
this.deltaX=1.7976931348623157E308;
this.xFactor=1.7976931348623157E308;
this.yFactor=1.7976931348623157E308;
this.firstX=1.7976931348623157E308;
this.lastX=1.7976931348623157E308;
this.firstY=1.7976931348623157E308;
this.obFreq=1.7976931348623157E308;
this.refPoint=1.7976931348623157E308;
this.casRN="";
this.errorLog=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['Z',['increasing','continuous'],'D',['deltaX','xFactor','yFactor','firstX','lastX','firstY','obFreq','refPoint'],'I',['npoints','samplenum','ivspoints','evspoints','sampleRefNum'],'S',['filePath','tagName','attrList','title','owner','origin','tmpEnd','molForm','techname','xUnits','yUnits','vendor','modelType','LongDate','pathlength','identifier','plLabel','resolution','resLabel','LocName','LocContact','casName','sampleowner','obNucleus','StrObFreq','casRN','sampleID'],'O',['source','jspecview.source.JDXSource','parser','jspecview.source.XMLParser','yaxisData','double[]','+xaxisData','errorLog','javajs.util.SB']]
,['O',['tagNames','String[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getSource$S$java_io_BufferedReader',  function (filePath, br) {
this.filePath=filePath;
return this.getXML$java_io_BufferedReader(br);
});

Clazz.newMeth(C$, 'getSimpleXmlReader$java_io_BufferedReader',  function (br) {
this.parser=Clazz.new_($I$(2,1).c$$java_io_BufferedReader,[br]);
});

Clazz.newMeth(C$, 'checkStart$',  function () {
if (this.parser.peek$() == 1) return;
var errMsg="Error: XML <xxx> not found at beginning of file; not an XML document?";
this.errorLog.append$S(errMsg);
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,[errMsg]);
});

Clazz.newMeth(C$, 'populateVariables$',  function () {
var LDRTable=Clazz.new_($I$(3,1));
var spectrum=Clazz.new_($I$(4,1));
spectrum.setTitle$S(this.title);
spectrum.setJcampdx$S("5.01");
spectrum.setDataClass$S("XYDATA");
spectrum.setDataType$S(this.techname);
spectrum.setContinuous$Z(this.continuous);
spectrum.setIncreasing$Z(this.increasing);
spectrum.setXFactor$D(this.xFactor);
spectrum.setYFactor$D(this.yFactor);
spectrum.setLongDate$S(this.LongDate);
spectrum.setOrigin$S(this.origin);
spectrum.setOwner$S(this.owner);
$I$(5).addHeader$javajs_util_Lst$S$S(LDRTable, "##PATHLENGTH", this.pathlength);
$I$(5).addHeader$javajs_util_Lst$S$S(LDRTable, "##RESOLUTION", this.resolution);
if (!this.StrObFreq.equals$O("")) $I$(5).addHeader$javajs_util_Lst$S$S(LDRTable, "##.OBSERVEFREQUENCY", this.StrObFreq);
if (!this.obNucleus.equals$O("")) $I$(5).addHeader$javajs_util_Lst$S$S(LDRTable, "##.OBSERVENUCLEUS", this.obNucleus);
$I$(5).addHeader$javajs_util_Lst$S$S(LDRTable, "##$MANUFACTURER", this.vendor);
if (!this.casRN.equals$O("")) $I$(5).addHeader$javajs_util_Lst$S$S(LDRTable, "##CASREGISTRYNO", this.casRN);
if (!this.molForm.equals$O("")) $I$(5).addHeader$javajs_util_Lst$S$S(LDRTable, "##MOLFORM", this.molForm);
if (!this.modelType.equals$O("")) $I$(5).addHeader$javajs_util_Lst$S$S(LDRTable, "##SPECTROMETER/DATA SYSTEM", this.modelType);
spectrum.setHeaderTable$javajs_util_Lst(LDRTable);
var xScale=1;
if (this.obFreq != 1.7976931348623157E308 ) {
spectrum.setObservedFreq$D(this.obFreq);
if (this.xUnits.toUpperCase$().equals$O("HZ")) {
this.xUnits="PPM";
spectrum.setHZtoPPM$Z(true);
xScale=this.obFreq;
}}var xyCoords=Clazz.array($I$(6), [this.npoints]);
for (var x=0; x < this.npoints; x++) xyCoords[x]=Clazz.new_($I$(6,1)).set$D$D(this.xaxisData[x] / xScale, this.yaxisData[x]);

if (!this.increasing) xyCoords=$I$(6).reverse$jspecview_common_CoordinateA(xyCoords);
spectrum.setXUnits$S(this.xUnits);
spectrum.setYUnits$S(this.yUnits);
spectrum.setXYCoords$jspecview_common_CoordinateA(xyCoords);
this.source.addJDXSpectrum$S$jspecview_common_Spectrum$Z(this.filePath, spectrum, false);
});

Clazz.newMeth(C$, 'checkPointCount$',  function () {
if (this.continuous && this.npoints < 5 ) {
System.err.println$S("Insufficient points to plot");
this.errorLog.append$S("Insufficient points to plot \n");
this.source.setErrorLog$S(this.errorLog.toString());
return false;
}return true;
});

Clazz.newMeth(C$, 'processErrors$S',  function (type) {
this.parser=null;
if (this.errorLog.length$() > 0) {
this.errorLog.append$S("these errors were found in " + type + " \n" );
this.errorLog.append$S("=====================\n");
}this.source.setErrorLog$S(this.errorLog.toString());
});

Clazz.newMeth(C$, 'processXML$I$I',  function (i0, i1) {
while (this.parser.hasNext$()){
if (this.parser.nextEvent$() != 1) continue;
var theTag=this.parser.getTagName$();
var requiresEndTag=this.parser.requiresEndTag$();
if ($I$(7).debugging) $I$(7).info$S(this.tagName);
for (var i=i0; i <= i1; i++) if (theTag.equals$O(C$.tagNames[i])) {
this.process$I$Z(i, requiresEndTag);
break;
}
}
});

Clazz.newMeth(C$, 'process$I$Z',  function (tagId, requiresEndTag) {
var thisTagName=C$.tagNames[tagId];
try {
this.tagName=this.parser.getTagName$();
this.attrList=this.parser.getAttributeList$();
if (!this.processTag$I(tagId) || !requiresEndTag ) return;
while (this.parser.hasNext$()){
switch (this.parser.nextEvent$()) {
default:
continue;
case 2:
if (this.parser.getEndTag$().equals$O(thisTagName)) {
this.processEndTag$I(tagId);
return;
}continue;
case 1:
break;
}
this.tagName=this.parser.getTagName$();
if (this.tagName.startsWith$S("!--")) continue;
this.attrList=this.parser.getAttributeList$();
if (!this.processTag$I(tagId)) return;
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
var msg="error reading " + this.tagName + " section: " + e + "\n" + e.getStackTrace$() ;
$I$(7).error$S(msg);
this.errorLog.append$S(msg + "\n");
} else {
throw e;
}
}
});

C$.$static$=function(){C$.$static$=0;
C$.tagNames=Clazz.array(String, -1, ["audittrail", "experimentstepset", "sampleset", "xx result", "spectrum", "metadatalist", "conditionlist", "parameterlist", "sample", "spectrumdata", "peaklist", "author", "peaklist"]);
};
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:29 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
