(function(){var P$=Clazz.newPackage("jspecview.source"),I$=[[0,'jspecview.source.JDXDecompressor']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JDXDecompressorTest");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['D',['dx5'],'I',['testIndex'],'O',['testLines','String[]','testResults','double[][]','+testData']]]

Clazz.newMeth(C$, 'main$SA',  function (args) {
for (var i=0; i < 6; i++) {
C$.testRun$I(i);
}
}, 1);

Clazz.newMeth(C$, 'testRun$I',  function (t) {
var d=Clazz.new_($I$(1,1).c$$S$I,[C$.testLines[t], 0]);
var i=0;
while (d.hasNext$()){
var v=d.next$().doubleValue$();
var vr=C$.testResults[t][i++];
var isOK=(v == vr );
if (!isOK) {
System.err.println$S("test " + t + " failed " + i + ": " + new Double(v).toString() + " != " + new Double(vr).toString() );
return;
}}
System.out.println$S("test " + t + " OK" );
}, 1);

Clazz.newMeth(C$, 'testCreate$I',  function (t) {
var d=Clazz.new_($I$(1,1).c$$S$I,[C$.testLines[t], 0]);
var n=1;
System.out.println$S("new double[] {");
while (d.hasNext$()){
System.out.print$S(d.next$().toString() + ",");
if ((++n % 5) == 0) System.out.println$();
}
System.out.println$S("\n},");
}, 1);

Clazz.newMeth(C$, 'testDemo$SA',  function (args) {
var line;
var x;
var xexp;
var dx;
var yexp;
if (args.length == 0) {
line=C$.testLines[C$.testIndex];
var data=C$.testData[C$.testIndex];
x=data[0];
dx=data[1];
xexp=data[2];
yexp=data[3];
} else {
line=args[0];
x=0;
dx=1;
xexp=-1;
yexp=NaN;
}var d=Clazz.new_($I$(1,1).c$$S$I,[line, 0]);
var n=0;
while (d.hasNext$()){
var s=line.substring$I(d.ich);
if (n > 0) x+=dx;
System.out.println$S((++n) + " " + new Double(x).toString() + " " + d.next$().toString() + " " + s );
}
if (xexp >= 0 ) System.out.println$S("expected x " + new Double(xexp).toString() + " final x " + new Double(x).toString() + " expected y " + new Double(yexp).toString() + " final y " + new Double(d.lastY).toString() );
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.testLines=Clazz.array(String, -1, ["1JT%jX", "D7m9jNOj9RjLmoPKLMj4oJ8j7PJT%olJ3MnJj2J0j7MQpJ9j3j0TJ0J2j3PKmJ2KJ4Ok2J4Mk", "A4j5lqkJ4rNj0J6j3JTpPqPNj6K0%j1J1lnJ8k3Pj1%J3j8J6J2j0J%Jj1Pkj1RJ5nj2OnjJJ3", "Ak8K1MPj4Nj2RJQoKnJ0j8J5mQl4L0j5J7k2NJMTJ1noLNj0KkqLmJ7Lk3MJ7p%qoLJ3nRjoJQ", "b2TJ2j7Nj0J8jpLOlOj2Jj0RJ5pmqJ1lpJ1pPjKJjkPj2MjJ2j2Qj2k3L4qnJ4prmRKmoJ6J5r", "I82314Q00sQ01Q00S2J85%W3A000100"]);
C$.testResults=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [1.0, 2.0, 3.0, 3.0, 2.0, 1.0, 0.0, -1.0, -2.0, -3.0]), Clazz.array(Double.TYPE, -1, [47.0, -2.0, -3.0, 2.0, 8.0, -11.0, -2.0, -3.0, 0.0, -4.0, -10.0, -3.0, -1.0, 2.0, 6.0, -8.0, -14.0, 4.0, -13.0, -6.0, -5.0, -4.0, -4.0, -10.0, -13.0, 0.0, 4.0, -1.0, 0.0, -12.0, -2.0, -19.0, -15.0, -7.0, -14.0, 5.0, -8.0, -18.0, -28.0, -18.0, -6.0, -19.0, -12.0, -10.0, -14.0, -2.0, 0.0, 14.0, 20.0, -2.0, 12.0, 16.0, 14.0]), Clazz.array(Double.TYPE, -1, [14.0, -1.0, -4.0, -12.0, -14.0, 0.0, -9.0, -4.0, -14.0, 2.0, -11.0, -10.0, -9.0, -16.0, -9.0, -17.0, -10.0, -5.0, -21.0, -1.0, -1.0, -12.0, -1.0, -4.0, -9.0, 9.0, -14.0, -7.0, -18.0, -18.0, -5.0, -23.0, -7.0, 5.0, -5.0, -4.0, -4.0, -3.0, -14.0, -7.0, -9.0, -20.0, -11.0, 4.0, -1.0, -13.0, -7.0, -12.0, -13.0, -12.0, 1.0]), Clazz.array(Double.TYPE, -1, [1.0, -27.0, -6.0, -2.0, 5.0, -9.0, -4.0, -16.0, -7.0, -6.0, 2.0, -4.0, -2.0, -7.0, 3.0, -15.0, 0.0, -4.0, 4.0, -30.0, 0.0, -15.0, 2.0, -20.0, -15.0, -14.0, -10.0, -6.0, 5.0, 0.0, -6.0, -3.0, 2.0, -8.0, -6.0, -8.0, -16.0, -13.0, -17.0, 0.0, 3.0, -20.0, -16.0, 1.0, -6.0, -6.0, -14.0, -20.0, -17.0, -4.0, -9.0, 0.0, -1.0, -7.0, -6.0, 2.0]), Clazz.array(Double.TYPE, -1, [-22.0, -22.0, -10.0, -27.0, -22.0, -32.0, -14.0, -15.0, -22.0, -19.0, -13.0, -16.0, -10.0, -22.0, -21.0, -31.0, -22.0, -7.0, -14.0, -18.0, -26.0, -15.0, -18.0, -25.0, -14.0, -21.0, -14.0, -15.0, -13.0, -12.0, -13.0, -15.0, -8.0, -20.0, -16.0, -17.0, -5.0, -17.0, -9.0, -21.0, -44.0, -10.0, -18.0, -23.0, -9.0, -16.0, -25.0, -29.0, -20.0, -18.0, -22.0, -28.0, -12.0, 3.0, -6.0]), Clazz.array(Double.TYPE, -1, [982314.0, 983114.0, 983914.0, 984714.0, 985514.0, 986314.0, 987114.0, 987914.0, 988714.0, 989514.0, 990315.0, 991115.0, 991915.0, 992715.0, 993515.0, 994315.0, 995115.0, 995915.0, 996715.0, 997515.0, 998315.0, 999115.0, 999915.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0, 1000100.0])]);
C$.dx5=-1.1069014507253627;
C$.testData=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [0, 1, 10, -3]), Clazz.array(Double.TYPE, -1, [8191, -1, 8139, 14]), Clazz.array(Double.TYPE, -1, [8139, -1, 8089, 1]), Clazz.array(Double.TYPE, -1, [8089, -1, 8034, 2]), Clazz.array(Double.TYPE, -1, [6142, -1, 6088, -9]), Clazz.array(Double.TYPE, -1, [1374.2821, C$.dx5, 1287.9438 - C$.dx5, 1000100])]);
C$.testIndex=5;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:07 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
