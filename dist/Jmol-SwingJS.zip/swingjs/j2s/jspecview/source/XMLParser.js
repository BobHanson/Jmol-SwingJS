(function(){var P$=Clazz.newPackage("jspecview.source"),p$1={},I$=[[0,['jspecview.source.XMLParser','.XmlEvent'],'javajs.util.SB',['jspecview.source.XMLParser','.Tag'],'java.util.Hashtable',['jspecview.source.XMLParser','.DataString'],['jspecview.source.XMLParser','.DataBuffer']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "XMLParser", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['DataBuffer',2],['DataString',2],['XmlEvent',2],['Tag',0]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.thisEvent=Clazz.new_($I$(1,1).c$$I,[this, null, 0]);
},1);

C$.$fields$=[['O',['thisEvent','jspecview.source.XMLParser.XmlEvent','buffer','jspecview.source.XMLParser.DataBuffer']]]

Clazz.newMeth(C$, 'c$$java_io_BufferedReader',  function (br) {
;C$.$init$.apply(this);
this.buffer=Clazz.new_($I$(6,1).c$$java_io_BufferedReader,[this, null, br]);
}, 1);

Clazz.newMeth(C$, 'getBufferData$',  function () {
return (this.buffer == null  ? null : this.buffer.data.toString().substring$I$I(0, this.buffer.ptr));
});

Clazz.newMeth(C$, 'thisValue$',  function () {
return this.buffer.nextEvent$().toString().trim$();
});

Clazz.newMeth(C$, 'qualifiedValue$',  function () {
this.buffer.nextTag$();
var value=this.buffer.nextEvent$().toString().trim$();
this.buffer.nextTag$();
return value;
});

Clazz.newMeth(C$, 'peek$',  function () {
this.thisEvent=this.buffer.peek$();
return this.thisEvent.getEventType$();
});

Clazz.newMeth(C$, 'hasNext$',  function () {
return this.buffer.hasNext$();
});

Clazz.newMeth(C$, 'nextTag$',  function () {
while ((this.thisEvent=this.buffer.nextTag$()).eventType == 6){
}
});

Clazz.newMeth(C$, 'nextEvent$',  function () {
this.thisEvent=this.buffer.nextEvent$();
return this.thisEvent.getEventType$();
});

Clazz.newMeth(C$, 'nextStartTag$',  function () {
this.thisEvent=this.buffer.nextTag$();
while (!this.thisEvent.isStartElement$())this.thisEvent=this.buffer.nextTag$();

});

Clazz.newMeth(C$, 'getTagName$',  function () {
return this.thisEvent.getTagName$();
});

Clazz.newMeth(C$, 'getTagType$',  function () {
return this.thisEvent.getTagType$();
});

Clazz.newMeth(C$, 'getEndTag$',  function () {
return this.thisEvent.getTagName$();
});

Clazz.newMeth(C$, 'nextValue$',  function () {
this.buffer.nextTag$();
return this.buffer.nextEvent$().toString().trim$();
});

Clazz.newMeth(C$, 'getAttributeList$',  function () {
return this.thisEvent.toString().toLowerCase$();
});

Clazz.newMeth(C$, 'getAttrValueLC$S',  function (key) {
return this.getAttrValue$S(key).toLowerCase$();
});

Clazz.newMeth(C$, 'getAttrValue$S',  function (name) {
var a=this.thisEvent.getAttributeByName$S(name);
return (a == null  ? "" : a);
});

Clazz.newMeth(C$, 'getCharacters$',  function () {
var sb=Clazz.new_($I$(2,1));
this.thisEvent=this.buffer.peek$();
var eventType=this.thisEvent.getEventType$();
while (eventType != 4)this.thisEvent=this.buffer.nextEvent$();

while (eventType == 4){
this.thisEvent=this.buffer.nextEvent$();
eventType=this.thisEvent.getEventType$();
if (eventType == 4) sb.append$S(this.thisEvent.toString());
}
return sb.toString();
});

Clazz.newMeth(C$, 'requiresEndTag$',  function () {
var tagType=this.thisEvent.getTagType$();
return tagType != 3 && tagType != 6 ;
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.XMLParser, "DataBuffer", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, ['jspecview.source.XMLParser','.DataString']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$java_io_BufferedReader',  function (br) {
Clazz.super_(C$, this);
this.reader=br;
}, 1);

Clazz.newMeth(C$, 'hasNext$',  function () {
if (this.ptr == this.ptEnd) try {
this.readLine$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return false;
} else {
throw e;
}
}
return this.ptr < this.ptEnd;
});

Clazz.newMeth(C$, 'readLine$',  function () {
var s=this.reader.readLine$();
if (s == null ) {
return false;
}this.data.append$S(s + "\n");
this.ptEnd=this.data.length$();
return true;
});

Clazz.newMeth(C$, 'peek$',  function () {
if (this.ptEnd - this.ptr < 2) try {
this.readLine$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return Clazz.new_($I$(1,1).c$$I,[this, null, 8]);
} else {
throw e;
}
}
var pt0=this.ptr;
var e=Clazz.new_($I$(1,1).c$$jspecview_source_XMLParser_DataBuffer,[this, null, this]);
this.ptr=pt0;
return e;
});

Clazz.newMeth(C$, 'nextTag$',  function () {
this.flush$();
this.skipTo$C$Z("<", false);
var e=Clazz.new_($I$(1,1).c$$jspecview_source_XMLParser_DataBuffer,[this, null, this]);
return e;
});

Clazz.newMeth(C$, 'nextEvent$',  function () {
this.flush$();
return Clazz.new_($I$(1,1).c$$jspecview_source_XMLParser_DataBuffer,[this, null, this]);
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.XMLParser, "DataString", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['ptr','ptEnd'],'O',['data','javajs.util.SB','reader','java.io.BufferedReader']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.data=Clazz.new_($I$(2,1));
}, 1);

Clazz.newMeth(C$, 'c$$javajs_util_SB',  function (data) {
;C$.$init$.apply(this);
this.data=data;
this.ptEnd=data.length$();
}, 1);

Clazz.newMeth(C$, 'getNCharactersRemaining$',  function () {
return this.ptEnd - this.ptr;
});

Clazz.newMeth(C$, 'flush$',  function () {
if (this.data.length$() < 1000 || this.ptEnd - this.ptr > 100 ) return;
this.data=Clazz.new_($I$(2,1)).append$S(this.data.substring$I(this.ptr));
this.ptr=0;
this.ptEnd=this.data.length$();
});

Clazz.newMeth(C$, 'substring$I$I',  function (i, j) {
return this.data.toString().substring$I$I(i, j);
});

Clazz.newMeth(C$, 'skipOver$C$Z',  function (c, inQuotes) {
if (this.skipTo$C$Z(c, inQuotes) > 0 && this.ptr != this.ptEnd ) {
++this.ptr;
}return this.ptr;
});

Clazz.newMeth(C$, 'skipTo$C$Z',  function (toWhat, inQuotes) {
if (this.data == null ) return -1;
var ch;
if (this.ptr == this.ptEnd) {
if (this.reader == null ) return -1;
this.readLine$();
}var ptEnd1=this.ptEnd - 1;
while (this.ptr < this.ptEnd && (ch=this.data.charAt$I(this.ptr)) != toWhat ){
if (inQuotes && ch == "\\"  && this.ptr < ptEnd1 ) {
if ((ch=this.data.charAt$I(this.ptr + 1)) == "\"" || ch == "\\" ) ++this.ptr;
} else if (ch == "\"") {
++this.ptr;
if (this.skipTo$C$Z("\"", true) < 0) return -1;
}if (++this.ptr == this.ptEnd) {
if (this.reader == null ) return -1;
this.readLine$();
}}
return this.ptr;
});

Clazz.newMeth(C$, 'readLine$',  function () {
return false;
});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.XMLParser, "XmlEvent", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.eventType=0;
this.ptr=0;
},1);

C$.$fields$=[['I',['eventType','ptr'],'S',['data'],'O',['tag','jspecview.source.XMLParser.Tag']]]

Clazz.newMeth(C$, 'toString',  function () {
return (this.data != null  ? this.data : this.tag != null  ? this.tag.text : null);
});

Clazz.newMeth(C$, 'c$$I',  function (eventType) {
;C$.$init$.apply(this);
this.eventType=eventType;
}, 1);

Clazz.newMeth(C$, 'c$$jspecview_source_XMLParser_DataBuffer',  function (b) {
;C$.$init$.apply(this);
this.ptr=b.ptr;
var n=b.getNCharactersRemaining$();
this.eventType=(n == 0 ? 8 : n == 1 || b.data.charAt$I(b.ptr) != "<"  ? 4 : b.data.charAt$I(b.ptr + 1) != "/" ? 1 : 2);
if (this.eventType == 8) return;
if (this.eventType == 4) {
b.skipTo$C$Z("<", false);
this.data=b.data.toString().substring$I$I(this.ptr, b.ptr);
} else {
b.skipOver$C$Z(">", false);
var s=b.data.toString().substring$I$I(this.ptr, b.ptr);
if (s.startsWith$S("<!--")) this.eventType=6;
this.tag=Clazz.new_($I$(3,1).c$$S,[this, null, s]);
}}, 1);

Clazz.newMeth(C$, 'getEventType$',  function () {
return this.eventType;
});

Clazz.newMeth(C$, 'isStartElement$',  function () {
return (this.eventType & 1) != 0;
});

Clazz.newMeth(C$, 'getTagName$',  function () {
return (this.tag == null  ? null : this.tag.getName$());
});

Clazz.newMeth(C$, 'getTagType$',  function () {
return (this.tag == null  ? 0 : this.tag.tagType);
});

Clazz.newMeth(C$, 'getAttributeByName$S',  function (name) {
return (this.tag == null  ? null : this.tag.getAttributeByName$S(name));
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.XMLParser, "Tag", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['tagType'],'S',['name','text'],'O',['attributes','java.util.Hashtable']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S',  function (fulltag) {
;C$.$init$.apply(this);
this.text=fulltag;
this.tagType=(fulltag.startsWith$S("<!--") ? 6 : fulltag.charAt$I(1) == "/" ? 2 : fulltag.charAt$I(fulltag.length$() - 2) == "/" ? 3 : 1);
}, 1);

Clazz.newMeth(C$, 'getName$',  function () {
if (this.name != null ) return this.name;
var ptTemp=(this.tagType == 2 ? 2 : 1);
var n=this.text.length$() - (this.tagType == 3 ? 2 : 1);
while (ptTemp < n && Character.isWhitespace$C(this.text.charAt$I(ptTemp)) )++ptTemp;

var pt0=ptTemp;
while (ptTemp < n && !Character.isWhitespace$C(this.text.charAt$I(ptTemp)) )++ptTemp;

return this.name=this.text.substring$I$I(pt0, ptTemp).toLowerCase$().trim$();
});

Clazz.newMeth(C$, 'getAttributeByName$S',  function (attrName) {
if (this.attributes == null ) p$1.getAttributes.apply(this, []);
return this.attributes.get$O(attrName.toLowerCase$());
});

Clazz.newMeth(C$, 'getAttributes',  function () {
this.attributes=Clazz.new_($I$(4,1));
var d=Clazz.new_([this, null, Clazz.new_($I$(2,1)).append$S(this.text)],$I$(5,1).c$$javajs_util_SB);
try {
if (d.skipTo$C$Z(" ", false) < 0) return;
var pt0;
while ((pt0=++d.ptr) >= 0){
if (d.skipTo$C$Z("=", false) < 0) return;
var name=d.substring$I$I(pt0, d.ptr).trim$().toLowerCase$();
d.skipTo$C$Z("\"", false);
pt0=++d.ptr;
d.skipTo$C$Z("\"", true);
var attr=d.substring$I$I(pt0, d.ptr);
this.attributes.put$O$O(name, attr);
var pt1=name.indexOf$S(":");
if (pt1 >= 0) {
name=name.substring$I(pt1).trim$();
this.attributes.put$O$O(name, attr);
}}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}, p$1);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:29 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
