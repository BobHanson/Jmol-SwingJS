(function(){var P$=Clazz.newPackage("jspecview.source"),p$1={},I$=[[0,'org.jmol.util.Logger','jspecview.common.Coordinate']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JDXDecompressor", null, null, 'java.util.Iterator');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.maxY=4.9E-324;
this.minY=1.7976931348623157E308;
this.lastDif=-2147483648;
this.isDIF=true;
},1);

C$.$fields$=[['Z',['debugging','isDIF'],'D',['xFactor','yFactor','firstX','lastX','maxY','minY','lastY'],'I',['nPoints','ich','lineLen','lastDif','dupCount','nptsFound'],'S',['line'],'O',['t','jspecview.source.JDXSourceStreamTokenizer','xyCoords','jspecview.common.Coordinate[]','errorLog','javajs.util.SB']]
,['O',['actions','int[]']]]

Clazz.newMeth(C$, 'getMinY$',  function () {
return this.minY;
});

Clazz.newMeth(C$, 'getMaxY$',  function () {
return this.maxY;
});

Clazz.newMeth(C$, 'c$$jspecview_source_JDXSourceStreamTokenizer$D$D$D$D$I',  function (t, firstX, lastX, xFactor, yFactor, nPoints) {
;C$.$init$.apply(this);
this.t=t;
this.firstX=firstX;
this.lastX=lastX;
this.xFactor=xFactor;
this.yFactor=yFactor;
this.nPoints=nPoints;
this.debugging=$I$(1).isActiveLevel$I(6);
}, 1);

Clazz.newMeth(C$, 'c$$S$I',  function (line, lastY) {
;C$.$init$.apply(this);
this.line=line.trim$();
this.lineLen=line.length$();
this.lastY=lastY;
}, 1);

Clazz.newMeth(C$, 'decompressData$javajs_util_SB',  function (errorLog) {
this.errorLog=errorLog;
var deltaXcalc=$I$(2).deltaX$D$D$I(this.lastX, this.firstX, this.nPoints);
if (this.debugging) p$1.logError$S.apply(this, ["firstX=" + new Double(this.firstX).toString() + " lastX=" + new Double(this.lastX).toString() + " xFactor=" + new Double(this.xFactor).toString() + " yFactor=" + new Double(this.yFactor).toString() + " deltaX=" + new Double(deltaXcalc).toString() + " nPoints=" + this.nPoints ]);
this.xyCoords=Clazz.array($I$(2), [this.nPoints]);
var difFracMax=0.5;
var prevXcheck=0;
var prevIpt=0;
var lastXExpected=this.lastX;
var x=this.lastX=this.firstX;
var lastLine=null;
var ipt=0;
var yval=0;
var haveWarned=false;
var lineNumber=this.t.labelLineNo;
try {
while ((this.line=this.t.readLineTrimmed$()) != null  && this.line.indexOf$S("##") < 0 ){
++lineNumber;
if ((this.lineLen=this.line.length$()) == 0) continue;
this.ich=0;
var isCheckPoint=this.isDIF;
var xcheck=p$1.readSignedFloat.apply(this, []) * this.xFactor;
yval=p$1.nextValue$D.apply(this, [yval]);
if (!isCheckPoint && ipt > 0 ) x+=deltaXcalc;
if (this.debugging) p$1.logError$S.apply(this, ["Line: " + lineNumber + " isCP=" + isCheckPoint + "\t>>" + this.line + "<<\n x, xcheck " + new Double(x).toString() + " " + new Double(x / this.xFactor).toString()  + " " + new Double(xcheck / this.xFactor).toString() + " " + new Double(deltaXcalc / this.xFactor).toString()]);
var y=yval * this.yFactor;
var point=Clazz.new_($I$(2,1)).set$D$D(x, y);
if (ipt == 0 || !isCheckPoint ) {
p$1.addPoint$jspecview_common_Coordinate$I.apply(this, [point, ipt++]);
} else if (ipt < this.nPoints) {
var lastY=this.xyCoords[ipt - 1].getYVal$();
if (y != lastY ) {
this.xyCoords[ipt - 1]=point;
p$1.logError$S.apply(this, [lastLine + "\n" + this.line + "\nY-value Checkpoint Error! Line " + lineNumber + " for y=" + new Double(y).toString() + " yLast=" + new Double(lastY).toString() ]);
}if (xcheck == prevXcheck  || (xcheck < prevXcheck ) != (deltaXcalc < 0 )  ) {
p$1.logError$S.apply(this, [lastLine + "\n" + this.line + "\nX-sequence Checkpoint Error! Line " + lineNumber + " order for xCheck=" + new Double(xcheck).toString() + " after prevXCheck=" + new Double(prevXcheck).toString() ]);
}var xcheckDif=Math.abs(xcheck - prevXcheck);
var xiptDif=Math.abs((ipt - prevIpt) * deltaXcalc);
var fracDif=Math.abs((xcheckDif - xiptDif)) / xcheckDif;
if (this.debugging) System.err.println$S("JDXD fracDif = " + new Double(xcheck).toString() + "\t" + new Double(prevXcheck).toString() + "\txcheckDif=" + new Double(xcheckDif).toString() + "\txiptDif=" + new Double(xiptDif).toString() + "\tf=" + new Double(fracDif).toString() );
if (fracDif > difFracMax ) {
p$1.logError$S.apply(this, [lastLine + "\n" + this.line + "\nX-value Checkpoint Error! Line " + lineNumber + " expected " + new Double(xiptDif).toString() + " but X-Sequence Check difference reads " + new Double(xcheckDif).toString() ]);
}}prevIpt=(ipt == 1 ? 0 : ipt);
prevXcheck=xcheck;
var nX=0;
while (this.hasNext$()){
var ich0=this.ich;
if (this.debugging) p$1.logError$S.apply(this, ["line " + lineNumber + " char " + ich0 + ":" + this.line.substring$I$I(0, ich0) + ">>>>" + this.line.substring$I(this.ich) ]);
if (Double.isNaN$D(yval=p$1.nextValue$D.apply(this, [yval]))) {
p$1.logError$S.apply(this, ["There was an error reading line " + lineNumber + " char " + ich0 + ":" + this.line.substring$I$I(0, ich0) + ">>>>" + this.line.substring$I(ich0) ]);
} else {
x+=deltaXcalc;
if (yval == 1.7976931348623157E308 ) {
yval=0;
p$1.logError$S.apply(this, ["Point marked invalid '?' for line " + lineNumber + " char " + ich0 + ":" + this.line.substring$I$I(0, ich0) + ">>>>" + this.line.substring$I(ich0) ]);
}p$1.addPoint$jspecview_common_Coordinate$I.apply(this, [Clazz.new_($I$(2,1)).set$D$D(x, yval * this.yFactor), ipt++]);
if (this.debugging) p$1.logError$S.apply(this, ["nx=" + ++nX + " " + new Double(x).toString() + " " + new Double(x / this.xFactor).toString()  + " yval=" + new Double(yval).toString()]);
}}
this.lastX=x;
if (!haveWarned && ipt > this.nPoints ) {
p$1.logError$S.apply(this, ["! points overflow nPoints!"]);
haveWarned=true;
}lastLine=this.line;
}
} catch (ioe) {
if (Clazz.exceptionOf(ioe,"java.io.IOException")){
ioe.printStackTrace$();
} else {
throw ioe;
}
}
p$1.checkZeroFill$I$D.apply(this, [ipt, lastXExpected]);
return this.xyCoords;
});

Clazz.newMeth(C$, 'checkZeroFill$I$D',  function (ipt, lastXExpected) {
this.nptsFound=ipt;
if (this.nPoints == this.nptsFound) {
if (Math.abs(lastXExpected - this.lastX) > 1.0E-5 ) p$1.logError$S.apply(this, ["Something went wrong! The last X value was " + new Double(this.lastX).toString() + " but expected " + new Double(lastXExpected).toString() ]);
} else {
p$1.logError$S.apply(this, ["Decompressor did not find " + this.nPoints + " points -- instead " + this.nptsFound + " xyCoords.length set to " + this.nPoints ]);
for (var i=this.nptsFound; i < this.nPoints; i++) p$1.addPoint$jspecview_common_Coordinate$I.apply(this, [Clazz.new_($I$(2,1)).set$D$D(0, NaN), i]);

}}, p$1);

Clazz.newMeth(C$, 'addPoint$jspecview_common_Coordinate$I',  function (pt, ipt) {
if (ipt >= this.nPoints) return;
this.xyCoords[ipt]=pt;
var y=pt.getYVal$();
if (y > this.maxY ) this.maxY=y;
 else if (y < this.minY ) this.minY=y;
if (this.debugging) p$1.logError$S.apply(this, ["Coord: " + ipt + pt ]);
}, p$1);

Clazz.newMeth(C$, 'logError$S',  function (s) {
if (this.debugging) $I$(1).debug$S(s);
System.err.println$S(s);
this.errorLog.append$S(s).appendC$C("\n");
}, p$1);

Clazz.newMeth(C$, 'nextValue$D',  function (yval) {
if (this.dupCount > 0) return p$1.getDuplicate$D.apply(this, [yval]);
var ch=p$1.skipUnknown.apply(this, []);
switch (C$.actions[ch.$c()]) {
case 1:
this.isDIF=true;
return yval + (this.lastDif=p$1.readNextInteger$I.apply(this, [ch == "%" ? 0 : ch <= "R" ? ch.$c() - 73 : 105 - ch.$c()]));
case 2:
this.dupCount=p$1.readNextInteger$I.apply(this, [(ch == "s" ? 9 : ch.$c() - 82)]) - 1;
return p$1.getDuplicate$D.apply(this, [yval]);
case 3:
yval=p$1.readNextSqueezedNumber$C.apply(this, [ch]);
break;
case 4:
--this.ich;
yval=p$1.readSignedFloat.apply(this, []);
break;
case -1:
yval=1.7976931348623157E308;
break;
default:
yval=NaN;
break;
}
this.isDIF=false;
return yval;
}, p$1);

Clazz.newMeth(C$, 'skipUnknown',  function () {
var ch="\u0000";
while (this.ich < this.lineLen && C$.actions[(ch=this.line.charAt$I(this.ich++)).$c()] == 0 ){
}
return ch;
}, p$1);

Clazz.newMeth(C$, 'readSignedFloat',  function () {
var ich0=this.ich;
var ch="\u0000";
while (this.ich < this.lineLen && " ,\t\n".indexOf$I(ch=this.line.charAt$I(this.ich)) >= 0 )++this.ich;

var factor=1;
switch (ch.$c()) {
case 45:
factor=-1;
case 43:
ich0=++this.ich;
break;
}
if (p$1.scanToNonnumeric.apply(this, []) == "E" && this.ich + 3 < this.lineLen ) {
switch ((this.line.charCodeAt$I(this.ich + 1))) {
case 45:
case 43:
this.ich+=4;
if (this.ich < this.lineLen && (ch=this.line.charAt$I(this.ich)) >= "0"  && ch <= "9" ) ++this.ich;
break;
}
}return factor * Double.parseDouble$S(this.line.substring$I$I(ich0, this.ich));
}, p$1);

Clazz.newMeth(C$, 'getDuplicate$D',  function (yval) {
--this.dupCount;
return (this.isDIF ? yval + this.lastDif : yval);
}, p$1);

Clazz.newMeth(C$, 'readNextInteger$I',  function (n) {
var c=String.fromCharCode(0);
while (this.ich < this.lineLen && (c=this.line.charAt$I(this.ich)) >= "0"  && c <= "9" ){
n=n * 10 + (n < 0 ? 48 - c.$c() : c.$c() - 48);
++this.ich;
}
return n;
}, p$1);

Clazz.newMeth(C$, 'readNextSqueezedNumber$C',  function (ch) {
var ich0=this.ich;
p$1.scanToNonnumeric.apply(this, []);
return Double.parseDouble$S((ch.$c() > 96  ? 96 - ch.$c() : ch.$c() - 64) + this.line.substring$I$I(ich0, this.ich));
}, p$1);

Clazz.newMeth(C$, 'scanToNonnumeric',  function () {
var ch=String.fromCharCode(0);
while (this.ich < this.lineLen && ((ch=this.line.charAt$I(this.ich)) == "." || ch >= "0" && ch <= "9"  ) )++this.ich;

return (this.ich < this.lineLen ? ch : "\u0000");
}, p$1);

Clazz.newMeth(C$, 'getNPointsFound$',  function () {
return this.nptsFound;
});

Clazz.newMeth(C$, 'hasNext$',  function () {
return (this.ich < this.lineLen || this.dupCount > 0 );
});

Clazz.newMeth(C$, 'next$',  function () {
return (this.hasNext$() ? Double.valueOf$D(this.lastY=p$1.nextValue$D.apply(this, [this.lastY])) : null);
});

Clazz.newMeth(C$, 'remove$',  function () {
});

C$.$static$=function(){C$.$static$=0;
C$.actions=Clazz.array(Integer.TYPE, [255]);
{
for (var i=37; i <= 115; i++) {
var c=String.fromCharCode(i);
switch (c.$c()) {
case 37:
case 74:
case 75:
case 76:
case 77:
case 78:
case 79:
case 80:
case 81:
case 82:
case 106:
case 107:
case 108:
case 109:
case 110:
case 111:
case 112:
case 113:
case 114:
C$.actions[i]=1;
break;
case 43:
case 45:
case 46:
case 48:
case 49:
case 50:
case 51:
case 52:
case 53:
case 54:
case 55:
case 56:
case 57:
C$.actions[i]=4;
break;
case 63:
C$.actions[i]=-1;
break;
case 64:
case 65:
case 66:
case 67:
case 68:
case 69:
case 70:
case 71:
case 72:
case 73:
case 97:
case 98:
case 99:
case 100:
case 101:
case 102:
case 103:
case 104:
case 105:
C$.actions[i]=3;
break;
case 83:
case 84:
case 85:
case 86:
case 87:
case 88:
case 89:
case 90:
case 115:
C$.actions[i]=2;
break;
}
}
};
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:58 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
