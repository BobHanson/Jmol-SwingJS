(function(){var P$=Clazz.newPackage("jspecview.source"),p$1={},I$=[[0,'org.jmol.util.Logger','javajs.util.SB']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JDXSourceStreamTokenizer");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.labelLineNo=0;
},1);

C$.$fields$=[['I',['labelLineNo','lineNo'],'S',['rawLabel','value','line','rawLine'],'O',['br','java.io.BufferedReader']]]

Clazz.newMeth(C$, 'c$$java_io_BufferedReader',  function (br) {
;C$.$init$.apply(this);
this.br=br;
}, 1);

Clazz.newMeth(C$, 'peakLabel$',  function () {
return p$1.nextLabel$Z.apply(this, [false]);
});

Clazz.newMeth(C$, 'getLabel$',  function () {
return p$1.nextLabel$Z.apply(this, [true]);
});

Clazz.newMeth(C$, 'nextLabel$Z',  function (isGet) {
this.rawLabel=null;
this.value=null;
while (this.line == null  || this.line.length$() == 0 ){
try {
p$1.readLine.apply(this, []);
if (this.line == null ) {
this.line="";
return null;
}this.line=this.line.trim$();
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
this.line="";
return null;
} else {
throw e;
}
}
if (this.line.startsWith$S("##")) break;
this.line=null;
}
this.rawLine=this.line;
var pt=this.line.indexOf$S("=");
if (pt < 0) {
if (isGet) $I$(1,"info$S",["BAD JDX LINE -- no '=' (line " + this.lineNo + "): " + this.line ]);
this.rawLabel=this.line;
if (!isGet) this.line="";
} else {
this.rawLabel=this.line.substring$I$I(0, pt).trim$();
if (isGet) this.line=this.line.substring$I(pt + 1);
}this.labelLineNo=this.lineNo;
if ($I$(1).debugging) $I$(1).info$S(this.rawLabel);
return C$.cleanLabel$S(this.rawLabel);
}, p$1);

Clazz.newMeth(C$, 'cleanLabel$S',  function (label) {
if (label == null ) return null;
var i;
var str=Clazz.new_($I$(2,1));
for (i=0; i < label.length$(); i++) {
switch ((label.charCodeAt$I(i))) {
case 47:
case 92:
case 32:
case 45:
case 95:
break;
default:
str.appendC$C(label.charAt$I(i));
break;
}
}
return str.toString().toUpperCase$();
}, 1);

Clazz.newMeth(C$, 'getValue$',  function () {
if (this.value != null ) return this.value;
var sb=Clazz.new_($I$(2,1)).append$S(this.line);
if (sb.length$() > 0) sb.appendC$C("\n");
try {
while (p$1.readLine.apply(this, []) != null ){
if (this.line.indexOf$S("##") >= 0 && this.line.trim$().startsWith$S("##") ) break;
sb.append$S(this.line).appendC$C("\n");
}
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
$I$(1,"info$S",[e.toString()]);
} else {
throw e;
}
}
this.value=(this.rawLabel.startsWith$S("##$") ? sb.toString().trim$() : C$.trimLines$javajs_util_SB(sb));
if ($I$(1).debugging) $I$(1).info$S(this.value);
return this.value;
});

Clazz.newMeth(C$, 'readLineTrimmed$',  function () {
p$1.readLine.apply(this, []);
if (this.line == null ) return null;
if (this.line.indexOf$S("$$") < 0) return this.line.trim$();
var sb=Clazz.new_($I$(2,1)).append$S(this.line);
return C$.trimLines$javajs_util_SB(sb);
});

Clazz.newMeth(C$, 'flushLine$',  function () {
var sb=Clazz.new_($I$(2,1)).append$S(this.line);
this.line=null;
return C$.trimLines$javajs_util_SB(sb);
});

Clazz.newMeth(C$, 'readLine',  function () {
this.line=this.br.readLine$();
++this.lineNo;
return this.line;
}, p$1);

Clazz.newMeth(C$, 'trimLines$javajs_util_SB',  function (v) {
var n=v.length$();
var ilast=n - 1;
var vpt=C$.ptNonWhite$javajs_util_SB$I$I(v, 0, n);
if (vpt >= n) return "";
var buffer=Clazz.array(Character.TYPE, [n - vpt]);
var pt=0;
for (; vpt < n; vpt++) {
var ch;
switch ((ch=v.charAt$I(vpt)).$c()) {
case 13:
if (vpt < ilast && v.charAt$I(vpt + 1) == "\n" ) continue;
ch="\n";
break;
case 10:
if (pt > 0 && buffer[pt - 1] != "\n" ) pt-=vpt - C$.ptNonSpaceRev$javajs_util_SB$I(v, vpt) - 1 ;
vpt=C$.ptNonSpace$javajs_util_SB$I$I(v, ++vpt, n) - 1;
break;
case 36:
if (vpt < ilast && v.charAt$I(vpt + 1) == "$" ) {
++vpt;
while (++vpt < n && "\n\r".indexOf$I(v.charAt$I(vpt)) < 0 ){
}
continue;
}break;
}
if (ch == "\n" && pt > 0  && buffer[pt - 1] == "\n" ) continue;
buffer[pt++]=ch;
}
if (pt > 0 && buffer[pt - 1] == "\n" ) --pt;
return ( String.instantialize(buffer)).substring$I$I(0, pt).trim$();
}, 1);

Clazz.newMeth(C$, 'ptNonWhite$javajs_util_SB$I$I',  function (v, pt, n) {
while (pt < n && Character.isWhitespace$C(v.charAt$I(pt)) )++pt;

return pt;
}, 1);

Clazz.newMeth(C$, 'ptNonSpace$javajs_util_SB$I$I',  function (v, pt, n) {
while (pt < n && (v.charAt$I(pt) == " " || v.charAt$I(pt) == "\t" ) )++pt;

return pt;
}, 1);

Clazz.newMeth(C$, 'ptNonSpaceRev$javajs_util_SB$I',  function (v, pt) {
while (--pt >= 0 && (v.charAt$I(pt) == " " || v.charAt$I(pt) == "\t" ) ){
}
return pt;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:58 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
