(function(){var P$=Clazz.newPackage("jspecview.source"),p$1={},I$=[[0,'java.util.Hashtable','org.jmol.util.Logger','javajs.util.PT','jspecview.common.Coordinate','javajs.util.DF',['jspecview.common.Annotation','.AType']]],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JDXDataObject", null, 'jspecview.source.JDXHeader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.sourceID="";
this.fileShiftRef=1.7976931348623157E308;
this.fileShiftRefType=-1;
this.fileShiftRefDataPt=-1;
this.minX=NaN;
this.minY=NaN;
this.maxX=NaN;
this.maxY=NaN;
this.deltaX=NaN;
this.isHZtoPPM=false;
this.xIncreases=true;
this.fileFirstX=1.7976931348623157E308;
this.fileLastX=1.7976931348623157E308;
this.fileNPoints=-1;
this.xFactor=1.7976931348623157E308;
this.yFactor=1.7976931348623157E308;
this.nucleusY="?";
this.freq2dX=NaN;
this.freq2dY=NaN;
this.y2DUnits="";
this.xUnits="";
this.yUnits="";
this.xLabel=null;
this.yLabel=null;
this.varName="";
this.observedNucl="";
this.observedFreq=1.7976931348623157E308;
this.numDim=1;
this.y2D=NaN;
},1);

C$.$fields$=[['Z',['isSimulation','continuous','isHZtoPPM','xIncreases'],'D',['blockID','fileShiftRef','minX','minY','maxX','maxY','deltaX','fileFirstX','fileLastX','xFactor','yFactor','freq2dX','freq2dY','observedFreq','y2D'],'I',['fileShiftRefType','fileShiftRefDataPt','fileNPoints','numDim','nH'],'S',['sourceID','filePath','filePathForwardSlash','inlineData','nucleusX','nucleusY','y2DUnits','xUnits','yUnits','xLabel','yLabel','varName','observedNucl'],'O',['xyCoords','jspecview.common.Coordinate[]','parent','jspecview.common.Spectrum']]
,['O',['gyroData','double[]','gyroMap','java.util.Map']]]

Clazz.newMeth(C$, 'setInlineData$S',  function (data) {
this.inlineData=data;
});

Clazz.newMeth(C$, 'getInlineData$',  function () {
return this.inlineData;
});

Clazz.newMeth(C$, 'setFilePath$S',  function (filePath) {
if (filePath != null ) this.filePathForwardSlash=(this.filePath=filePath.trim$()).replace$C$C("\\", "/");
});

Clazz.newMeth(C$, 'getFilePath$',  function () {
return this.filePath;
});

Clazz.newMeth(C$, 'getFilePathForwardSlash$',  function () {
return this.filePathForwardSlash;
});

Clazz.newMeth(C$, 'setBlockID$D',  function (id) {
this.blockID=id;
});

Clazz.newMeth(C$, 'checkJDXRequiredTokens$',  function () {
var missingTag=(this.fileFirstX == 1.7976931348623157E308  ? "##FIRSTX" : this.fileLastX == 1.7976931348623157E308  ? "##LASTX" : this.fileNPoints == -1 ? "##NPOINTS" : this.xFactor == 1.7976931348623157E308  ? "##XFACTOR" : this.yFactor == 1.7976931348623157E308  ? "##YFACTOR" : null);
if (missingTag != null ) throw Clazz.new_(Clazz.load('jspecview.exception.JSVException').c$$S,["Error Reading Data Set: " + missingTag + " not found" ]);
});

Clazz.newMeth(C$, 'setXFactor$D',  function (xFactor) {
this.xFactor=xFactor;
});

Clazz.newMeth(C$, 'getXFactor$',  function () {
return this.xFactor;
});

Clazz.newMeth(C$, 'setYFactor$D',  function (yFactor) {
this.yFactor=yFactor;
});

Clazz.newMeth(C$, 'getYFactor$',  function () {
return this.yFactor;
});

Clazz.newMeth(C$, 'setVarName$S',  function (name) {
this.varName=name;
});

Clazz.newMeth(C$, 'isImaginary$',  function () {
return this.varName.contains$CharSequence("IMAG");
});

Clazz.newMeth(C$, 'setXUnits$S',  function (xUnits) {
this.xUnits=xUnits;
});

Clazz.newMeth(C$, 'getXUnits$',  function () {
return this.xUnits;
});

Clazz.newMeth(C$, 'setYUnits$S',  function (yUnits) {
if (yUnits.equals$O("PPM")) yUnits="ARBITRARY UNITS";
this.yUnits=yUnits;
});

Clazz.newMeth(C$, 'getYUnits$',  function () {
return this.yUnits;
});

Clazz.newMeth(C$, 'setXLabel$S',  function (value) {
this.xLabel=value;
});

Clazz.newMeth(C$, 'setYLabel$S',  function (value) {
this.yLabel=value;
});

Clazz.newMeth(C$, 'setObservedNucleus$S',  function (value) {
this.observedNucl=value;
if (this.is1D$()) this.parent.nucleusX=this.nucleusX=p$1.fixNucleus$S.apply(this, [value]);
});

Clazz.newMeth(C$, 'getObservedNucleus$',  function () {
return this.observedNucl;
});

Clazz.newMeth(C$, 'setObservedFreq$D',  function (observedFreq) {
this.observedFreq=observedFreq;
});

Clazz.newMeth(C$, 'getObservedFreq$',  function () {
return this.observedFreq;
});

Clazz.newMeth(C$, 'setHydrogenCount$I',  function (nH) {
this.nH=nH;
});

Clazz.newMeth(C$, 'getHydrogenCount$',  function () {
return this.nH;
});

Clazz.newMeth(C$, 'is1D$',  function () {
return this.numDim == 1;
});

Clazz.newMeth(C$, 'getNumDim$',  function () {
return this.numDim;
});

Clazz.newMeth(C$, 'setNumDim$I',  function (n) {
this.numDim=n;
});

Clazz.newMeth(C$, 'setY2D$D',  function (d) {
this.y2D=d;
});

Clazz.newMeth(C$, 'getY2D$',  function () {
return this.y2D;
});

Clazz.newMeth(C$, 'setY2DUnits$S',  function (units) {
this.y2DUnits=units;
});

Clazz.newMeth(C$, 'getY2DPPM$',  function () {
var d=this.y2D;
if (this.y2DUnits.equals$O("HZ")) d/=this.freq2dY;
return d;
});

Clazz.newMeth(C$, 'setNucleusAndFreq$S$Z',  function (nuc, isX) {
nuc=p$1.fixNucleus$S.apply(this, [nuc]);
if (isX) this.nucleusX=nuc;
 else this.nucleusY=nuc;
var freq;
if (this.observedNucl.indexOf$S(nuc) >= 0) {
freq=this.observedFreq;
} else {
var g1=C$.getGyromagneticRatio$S(p$1.fixNucleus$S.apply(this, [this.observedNucl]));
var g2=C$.getGyromagneticRatio$S(nuc);
freq=this.observedFreq * g2 / g1;
}if (isX) this.freq2dX=freq;
 else this.freq2dY=freq;
$I$(2,"info$S",["Freq for " + nuc + " = " + new Double(freq).toString() ]);
});

Clazz.newMeth(C$, 'fixNucleus$S',  function (nuc) {
return $I$(3,"rep$S$S$S",[$I$(3).trim$S$S(nuc, "[]^<>"), "NUC_", ""]);
}, p$1);

Clazz.newMeth(C$, 'getNominalSpecFreq$S$D',  function (nuc, freq) {
var d=freq * C$.getGyromagneticRatio$S("1H") / C$.getGyromagneticRatio$S(nuc);
var century=Long.$ival(Math.round$D(d / 100)) * 100;
return (Double.isNaN$D(d) ? -1 : Math.abs(d - century) < 2  ? century : Long.$ival(Math.round$D(d)));
}, 1);

Clazz.newMeth(C$, 'getGyromagneticRatio$S',  function (nuc) {
var v=null;
try {
v=C$.gyroMap.get$O(nuc);
if (v != null ) return v.doubleValue$();
var pt=0;
while (pt < nuc.length$() && Character.isDigit$C(nuc.charAt$I(pt)) )++pt;

v=C$.gyroMap.get$O(nuc.substring$I$I(0, pt));
if (v != null ) C$.gyroMap.put$O$O(nuc, v);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
return (v == null  ? NaN : v.doubleValue$());
}, 1);

Clazz.newMeth(C$, 'isTransmittance$',  function () {
var s=this.yUnits.toLowerCase$();
return (s.equals$O("transmittance") || s.contains$CharSequence("trans") || s.equals$O("t")  );
});

Clazz.newMeth(C$, 'isAbsorbance$',  function () {
var s=this.yUnits.toLowerCase$();
return (s.equals$O("absorbance") || s.contains$CharSequence("abs") || s.equals$O("a")  );
});

Clazz.newMeth(C$, 'canSaveAsJDX$',  function () {
return this.getDataClass$().equals$O("XYDATA");
});

Clazz.newMeth(C$, 'canIntegrate$',  function () {
return (this.continuous && (this.isHNMR$() || this.isGC$() ) && this.is1D$()  );
});

Clazz.newMeth(C$, 'isAutoOverlayFromJmolClick$',  function () {
return (this.isGC$());
});

Clazz.newMeth(C$, 'isGC$',  function () {
return this.dataType.startsWith$S("GC") || this.dataType.startsWith$S("GAS") ;
});

Clazz.newMeth(C$, 'isMS$',  function () {
return this.dataType.startsWith$S("MASS") || this.dataType.startsWith$S("MS") ;
});

Clazz.newMeth(C$, 'isStackable$',  function () {
return !this.isMS$();
});

Clazz.newMeth(C$, 'isScalable$',  function () {
return true;
});

Clazz.newMeth(C$, 'getYRef$',  function () {
return (!this.isTransmittance$() ? 0.0 : $I$(4).getMaxY$jspecview_common_CoordinateA$I$I(this.xyCoords, 0, this.xyCoords.length - 1) < 2  ? 1.0 : 100.0);
});

Clazz.newMeth(C$, 'isInverted$',  function () {
return this.isTransmittance$();
});

Clazz.newMeth(C$, 'canConvertTransAbs$',  function () {
return (this.continuous && (this.yUnits.toLowerCase$().contains$CharSequence("abs"))  || this.yUnits.toLowerCase$().contains$CharSequence("trans") );
});

Clazz.newMeth(C$, 'canShowSolutionColor$',  function () {
return (this.isContinuous$() && this.canConvertTransAbs$() && (this.xUnits.toLowerCase$().contains$CharSequence("nanometer") || this.xUnits.equalsIgnoreCase$S("nm") ) && this.getFirstX$() < 401    && this.getLastX$() > 699   && this.xyCoords.length >= 30 );
});

Clazz.newMeth(C$, 'isHZtoPPM$',  function () {
return this.isHZtoPPM;
});

Clazz.newMeth(C$, 'setHZtoPPM$Z',  function (val) {
this.isHZtoPPM=val;
});

Clazz.newMeth(C$, 'setIncreasing$Z',  function (val) {
this.xIncreases=val;
});

Clazz.newMeth(C$, 'isXIncreasing$',  function () {
return this.xIncreases;
});

Clazz.newMeth(C$, 'shouldDisplayXAxisIncreasing$',  function () {
var dt=this.dataType.toUpperCase$();
var xu=this.xUnits.toUpperCase$();
if (dt.contains$CharSequence("NMR") && !dt.contains$CharSequence("FID") ) {
return false;
} else if (dt.contains$CharSequence("LINK") && xu.contains$CharSequence("CM") ) {
return false;
} else if (dt.startsWith$S("IR") || dt.contains$CharSequence("INFRA") && xu.contains$CharSequence("CM")  ) {
return false;
} else if (dt.contains$CharSequence("RAMAN") && xu.contains$CharSequence("CM") ) {
return false;
} else if (dt.contains$CharSequence("VIS") && xu.contains$CharSequence("NANOMETERS") ) {
return true;
}return this.xIncreases;
});

Clazz.newMeth(C$, 'setContinuous$Z',  function (val) {
this.continuous=val;
});

Clazz.newMeth(C$, 'isContinuous$',  function () {
return this.continuous;
});

Clazz.newMeth(C$, 'getHeaderRowDataAsArray$',  function () {
var n=8;
if (this.observedFreq != 1.7976931348623157E308 ) ++n;
if (this.observedNucl !== "" ) ++n;
var rowData=this.getHeaderRowDataAsArray$Z$I(true, n);
var i=rowData.length - n;
if (this.observedFreq != 1.7976931348623157E308 ) rowData[i++]=Clazz.array(String, -1, ["##.OBSERVE FREQUENCY", "" + new Double(this.observedFreq).toString()]);
if (this.observedNucl !== "" ) rowData[i++]=Clazz.array(String, -1, ["##.OBSERVE NUCLEUS", this.observedNucl]);
rowData[i++]=Clazz.array(String, -1, ["##XUNITS", this.isHZtoPPM ? "HZ" : this.xUnits]);
rowData[i++]=Clazz.array(String, -1, ["##YUNITS", this.yUnits]);
var x=(this.xIncreases ? this.getFirstX$() : this.getLastX$());
rowData[i++]=Clazz.array(String, -1, ["##FIRSTX", String.valueOf$D(this.isHZtoPPM$() ? x * this.observedFreq : x)]);
x=(this.xIncreases ? this.getLastX$() : this.getFirstX$());
rowData[i++]=Clazz.array(String, -1, ["##FIRSTY", String.valueOf$D(this.xIncreases ? this.getFirstY$() : this.getLastY$())]);
rowData[i++]=Clazz.array(String, -1, ["##LASTX", String.valueOf$D(this.isHZtoPPM$() ? x * this.observedFreq : x)]);
rowData[i++]=Clazz.array(String, -1, ["##XFACTOR", String.valueOf$D(this.getXFactor$())]);
rowData[i++]=Clazz.array(String, -1, ["##YFACTOR", String.valueOf$D(this.getYFactor$())]);
rowData[i++]=Clazz.array(String, -1, ["##NPOINTS", String.valueOf$I(this.xyCoords.length)]);
return rowData;
});

Clazz.newMeth(C$, 'getDefaultUnitPrecision$',  function () {
return 2;
});

Clazz.newMeth(C$, 'setMeasurementText$jspecview_common_Measurement',  function (m) {
var dx=m.getValue$();
if (Double.isNaN$D(dx)) return "";
var precision=1;
var units="";
if (this.isNMR$()) {
if (this.is1D$()) {
var isIntegral=(Clazz.instanceOf(m, "jspecview.common.Integral"));
if (this.isHNMR$() || isIntegral ) {
if (!isIntegral) {
dx*=this.observedFreq;
units=" Hz";
}} else {
units=" ppm";
precision=2;
}} else {
return "";
}}return (dx < 0.1  ? "" : $I$(5).formatDecimalDbl$D$I(dx, precision) + units);
});

Clazz.newMeth(C$, 'isNMR$',  function () {
return (this.dataType.toUpperCase$().indexOf$S("NMR") >= 0);
});

Clazz.newMeth(C$, 'isHNMR$',  function () {
return (this.isNMR$() && this.observedNucl.toUpperCase$().indexOf$S("H") >= 0 );
});

Clazz.newMeth(C$, 'setXYCoords$jspecview_common_CoordinateA',  function (coords) {
this.xyCoords=coords;
});

Clazz.newMeth(C$, 'invertYAxis$',  function () {
for (var i=this.xyCoords.length; --i >= 0; ) {
this.xyCoords[i].setYVal$D(-this.xyCoords[i].getYVal$());
}
var d=this.minY;
this.minY=-this.maxY;
this.maxY=-d;
return this;
});

Clazz.newMeth(C$, 'getFirstX$',  function () {
return this.xyCoords[0].getXVal$();
});

Clazz.newMeth(C$, 'getFirstY$',  function () {
return this.xyCoords[0].getYVal$();
});

Clazz.newMeth(C$, 'getLastX$',  function () {
return this.xyCoords[this.xyCoords.length - 1].getXVal$();
});

Clazz.newMeth(C$, 'getLastY$',  function () {
return this.xyCoords[this.xyCoords.length - 1].getYVal$();
});

Clazz.newMeth(C$, 'getMinX$',  function () {
return (Double.isNaN$D(this.minX) ? (this.minX=$I$(4).getMinX$jspecview_common_CoordinateA$I$I(this.xyCoords, 0, this.xyCoords.length - 1)) : this.minX);
});

Clazz.newMeth(C$, 'getMinY$',  function () {
return (Double.isNaN$D(this.minY) ? (this.minY=$I$(4).getMinY$jspecview_common_CoordinateA$I$I(this.xyCoords, 0, this.xyCoords.length - 1)) : this.minY);
});

Clazz.newMeth(C$, 'getMaxX$',  function () {
return (Double.isNaN$D(this.maxX) ? (this.maxX=$I$(4).getMaxX$jspecview_common_CoordinateA$I$I(this.xyCoords, 0, this.xyCoords.length - 1)) : this.maxX);
});

Clazz.newMeth(C$, 'getMaxY$',  function () {
return (Double.isNaN$D(this.maxY) ? (this.maxY=$I$(4).getMaxY$jspecview_common_CoordinateA$I$I(this.xyCoords, 0, this.xyCoords.length - 1)) : this.maxY);
});

Clazz.newMeth(C$, 'normalizeSimulation$D',  function (max) {
if (!this.isNMR$() || !this.is1D$() ) return;
var f=max / this.getMaxY$();
this.maxY=NaN;
$I$(4).applyScale$jspecview_common_CoordinateA$D$D(this.xyCoords, 1, f);
$I$(2,"info$S",["Y values have been scaled by a factor of " + new Double(f).toString()]);
});

Clazz.newMeth(C$, 'getDeltaX$',  function () {
return (Double.isNaN$D(this.deltaX) ? (this.deltaX=$I$(4,"deltaX$D$D$I",[this.getLastX$(), this.getFirstX$(), this.xyCoords.length])) : this.deltaX);
});

Clazz.newMeth(C$, 'copyTo$jspecview_source_JDXDataObject',  function (newObj) {
newObj.setTitle$S(this.title);
newObj.setJcampdx$S(this.jcampdx);
newObj.setOrigin$S(this.origin);
newObj.setOwner$S(this.owner);
newObj.setDataClass$S(this.dataClass);
newObj.setDataType$S(this.dataType);
newObj.setHeaderTable$javajs_util_Lst(this.headerTable);
newObj.setXFactor$D(this.xFactor);
newObj.setYFactor$D(this.yFactor);
newObj.setXUnits$S(this.xUnits);
newObj.setYUnits$S(this.yUnits);
newObj.setXLabel$S(this.xLabel);
newObj.setYLabel$S(this.yLabel);
newObj.setXYCoords$jspecview_common_CoordinateA(this.xyCoords);
newObj.setContinuous$Z(this.continuous);
newObj.setIncreasing$Z(this.xIncreases);
newObj.observedFreq=this.observedFreq;
newObj.observedNucl=this.observedNucl;
newObj.fileShiftRef=this.fileShiftRef;
newObj.fileShiftRefDataPt=this.fileShiftRefDataPt;
newObj.fileShiftRefType=this.fileShiftRefType;
newObj.isHZtoPPM=this.isHZtoPPM;
newObj.numDim=this.numDim;
newObj.nucleusX=this.nucleusX;
newObj.nucleusY=this.nucleusY;
newObj.freq2dX=this.freq2dX;
newObj.freq2dY=this.freq2dY;
newObj.setFilePath$S(this.filePath);
newObj.nH=this.nH;
});

Clazz.newMeth(C$, 'getTypeLabel$',  function () {
return (this.isNMR$() ? this.nucleusX + "NMR" : this.dataType);
});

Clazz.newMeth(C$, 'getDefaultAnnotationInfo$jspecview_common_Annotation_AType',  function (type) {
var s1;
var s2;
var isNMR=this.isNMR$();
switch (type) {
case $I$(6).Integration:
return Clazz.array(java.lang.Object, -1, [null, Clazz.array(Integer.TYPE, -1, [1]), null]);
case $I$(6).Measurements:
s1=(isNMR ? Clazz.array(String, -1, ["Hz", "ppm"]) : Clazz.array(String, -1, [""]));
s2=(this.isHNMR$() ? Clazz.array(Integer.TYPE, -1, [1, 4]) : Clazz.array(Integer.TYPE, -1, [1, 3]));
return Clazz.array(java.lang.Object, -1, [s1, s2, Integer.valueOf$I(0)]);
case $I$(6).PeakList:
s1=(isNMR ? Clazz.array(String, -1, ["Hz", "ppm"]) : Clazz.array(String, -1, [""]));
s2=(this.isHNMR$() ? Clazz.array(Integer.TYPE, -1, [1, 2]) : Clazz.array(Integer.TYPE, -1, [1, 1]));
return Clazz.array(java.lang.Object, -1, [s1, s2, Integer.valueOf$I(isNMR ? 1 : 0)]);
case $I$(6).NONE:
case $I$(6).OverlayLegend:
break;
case $I$(6).Views:
break;
}
return null;
});

Clazz.newMeth(C$, 'getPeakListArray$jspecview_common_Measurement$DA$D',  function (m, last, maxY) {
var x=m.getXVal$();
var y=m.getYVal$();
if (this.isNMR$()) y/=maxY;
var dx=Math.abs(x - last[0]);
last[0]=x;
var ddx=dx + last[1];
last[1]=dx;
var dddx=ddx + last[2];
last[2]=ddx;
if (this.isNMR$()) {
return Clazz.array(Double.TYPE, -1, [x, y, x * this.observedFreq, (dx * this.observedFreq > 20  ? 0 : dx * this.observedFreq), (ddx * this.observedFreq > 20  ? 0 : ddx * this.observedFreq), (dddx * this.observedFreq > 20  ? 0 : dddx * this.observedFreq)]);
}return Clazz.array(Double.TYPE, -1, [x, y]);
});

Clazz.newMeth(C$, 'finalizeCoordinates$',  function () {
var freq=(Double.isNaN$D(this.freq2dX) ? this.observedFreq : this.freq2dX);
var isHz=(freq != 1.7976931348623157E308  && this.getXUnits$().toUpperCase$().equals$O("HZ") );
if (this.fileShiftRef != 1.7976931348623157E308  && freq != 1.7976931348623157E308   && this.dataType.toUpperCase$().contains$CharSequence("SPECTRUM")  && this.jcampdx.indexOf$S("JEOL") < 0 ) {
p$1.applyShiftReference$D$D.apply(this, [isHz ? freq : 1, this.fileShiftRef]);
}if (this.fileFirstX > this.fileLastX ) $I$(4).reverse$jspecview_common_CoordinateA(this.xyCoords);
if (isHz) {
$I$(4,"applyScale$jspecview_common_CoordinateA$D$D",[this.xyCoords, (1.0 / freq), 1]);
this.setXUnits$S("PPM");
this.setHZtoPPM$Z(true);
}});

Clazz.newMeth(C$, 'setShiftReference$D$I$I',  function (shift, pt, type) {
this.fileShiftRef=shift;
this.fileShiftRefDataPt=(pt > 0 ? pt : 1);
this.fileShiftRefType=type;
});

Clazz.newMeth(C$, 'isShiftTypeSpecified$',  function () {
return (this.fileShiftRefType != -1);
});

Clazz.newMeth(C$, 'applyShiftReference$D$D',  function (referenceFreq, shift) {
if (this.fileShiftRefDataPt > this.xyCoords.length || this.fileShiftRefDataPt < 0 ) return;
var coord;
switch (this.fileShiftRefType) {
case 0:
shift=this.xyCoords[this.fileShiftRefDataPt - 1].getXVal$() - shift * referenceFreq;
break;
case 1:
shift=this.fileFirstX - shift * referenceFreq;
break;
case 2:
shift=this.fileLastX + shift;
break;
}
for (var index=0; index < this.xyCoords.length; index++) {
coord=this.xyCoords[index];
coord.setXVal$D(coord.getXVal$() - shift);
this.xyCoords[index]=coord;
}
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.gyroData=Clazz.array(Double.TYPE, -1, [1, 42.5774806, 2, 6.53590131, 3, 45.4148, 3, 32.436, 6, 6.2661, 7, 16.5483, 9, 5.9842, 10, 4.5752, 11, 13.663, 13, 10.70839657, 14, 3.07770646, 15, 4.3172657, 17, 5.7742, 19, 40.07757016, 21, 3.3631, 23, 11.26952167, 25, 2.6083, 27, 11.1031, 29, 8.4655, 31, 17.2514409, 33, 3.2717, 35, 4.1765, 37, 3.4765, 37, 5.819, 39, 3.46, 39, 1.9893, 40, 2.4737, 41, 1.0919, 43, 2.8688, 45, 10.3591, 47, 2.4041, 49, 2.4048, 50, 4.2505, 51, 11.2133, 53, 2.4115, 55, 10.5763, 57, 1.3816, 59, 10.077, 61, 3.8114, 63, 11.2982, 65, 12.103, 67, 2.6694, 69, 10.2478, 71, 13.0208, 73, 1.4897, 75, 7.315, 77, 8.1571, 79, 10.7042, 81, 11.5384, 83, 1.6442, 85, 4.1254, 87, 13.9811, 87, 1.8525, 89, 2.0949, 91, 3.9748, 93, 10.4523, 95, 2.7874, 97, 2.8463, 99, 9.6294, 99, 1.9553, 101, 2.1916, 103, 1.3477, 105, 1.957, 107, 1.7331, 109, 1.9924, 111, 9.0692, 113, 9.4871, 113, 9.3655, 115, 9.3856, 115, 14.0077, 117, 15.261, 119, 15.966, 121, 10.2551, 123, 5.5532, 123, 11.2349, 125, 13.5454, 127, 8.5778, 129, 11.8604, 131, 3.5159, 133, 5.6234, 135, 4.2582, 137, 4.7634, 138, 5.6615, 139, 6.0612, 137, 4.88, 139, 5.39, 141, 2.37, 141, 13.0359, 143, 2.319, 145, 1.429, 143, 11.59, 147, 5.62, 147, 1.7748, 149, 14631, 151, 10.5856, 153, 4.6745, 155, 1.312, 157, 1.72, 159, 10.23, 161, 1.4654, 163, 2.0508, 165, 9.0883, 167, 1.2281, 169, 3.531, 171, 7.5261, 173, 2.073, 175, 4.8626, 176, 3.451, 177, 1.7282, 179, 1.0856, 180, 4.087, 181, 5.1627, 183, 1.7957, 185, 9.7176, 187, 9.817, 187, 0.9856, 189, 3.3536, 191, 0.7658, 191, 0.8319, 195, 9.2922, 197, 0.7406, 199, 7.7123, 201, 2.8469, 203, 24.7316, 205, 24.9749, 207, 9.034, 209, 6.963, 209, 11.7, 211, 9.16, 223, 5.95, 223, 1.3746, 225, 11.187, 227, 5.6, 229, 1.4, 231, 10.2, 235, 0.83, 237, 9.57, 239, 3.09, 243, 4.6, 1.0E100]);
C$.gyroMap=Clazz.new_($I$(1,1));
{
for (var i=0, n=C$.gyroData.length - 1; i < n; i+=2) C$.gyroMap.put$O$O("" + (C$.gyroData[i]|0), Double.valueOf$D(C$.gyroData[i + 1]));

};
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:07 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
