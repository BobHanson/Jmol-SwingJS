(function(){var P$=Clazz.newPackage("jspecview.source"),I$=[[0,'javajs.util.Lst']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JDXSource", null, 'jspecview.source.JDXHeader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.type=0;
this.isCompoundSource=false;
this.errors="";
},1);

C$.$fields$=[['Z',['isCompoundSource','isView'],'I',['type','peakCount'],'S',['errors','filePath','inlineData'],'O',['jdxSpectra','javajs.util.Lst']]]

Clazz.newMeth(C$, 'dispose$',  function () {
this.headerTable=null;
this.jdxSpectra=null;
});

Clazz.newMeth(C$, 'c$$I$S',  function (type, filePath) {
Clazz.super_(C$, this);
this.type=type;
this.setFilePath$S(filePath);
this.headerTable=Clazz.new_($I$(1,1));
this.jdxSpectra=Clazz.new_($I$(1,1));
this.isCompoundSource=(type != 0);
}, 1);

Clazz.newMeth(C$, 'getJDXSpectrum$I',  function (index) {
return (this.jdxSpectra.size$() <= index ? null : this.jdxSpectra.get$I(index));
});

Clazz.newMeth(C$, 'addJDXSpectrum$S$jspecview_common_Spectrum$Z',  function (filePath, spectrum, forceSub) {
if (filePath == null ) filePath=this.filePath;
spectrum.setFilePath$S(filePath);
if (this.inlineData != null ) spectrum.setInlineData$S(this.inlineData);
var n=this.jdxSpectra.size$();
if (n == 0 || !this.jdxSpectra.get$I(n - 1).addSubSpectrum$jspecview_common_Spectrum$Z(spectrum, forceSub) ) this.jdxSpectra.addLast$O(spectrum);
});

Clazz.newMeth(C$, 'getNumberOfSpectra$',  function () {
return this.jdxSpectra.size$();
});

Clazz.newMeth(C$, 'getSpectra$',  function () {
return this.jdxSpectra;
});

Clazz.newMeth(C$, 'getSpectraAsArray$',  function () {
return (this.jdxSpectra == null  ? null : this.jdxSpectra.toArray$());
});

Clazz.newMeth(C$, 'getErrorLog$',  function () {
return this.errors;
});

Clazz.newMeth(C$, 'setErrorLog$S',  function (errors) {
this.errors=errors;
});

Clazz.newMeth(C$, 'setFilePath$S',  function (filePath) {
this.filePath=filePath;
});

Clazz.newMeth(C$, 'getFilePath$',  function () {
return this.filePath;
});

Clazz.newMeth(C$, 'createView$javajs_util_Lst',  function (specs) {
var source=Clazz.new_(C$.c$$I$S,[-2, "view"]);
source.isView=true;
for (var i=0; i < specs.size$(); i++) source.addJDXSpectrum$S$jspecview_common_Spectrum$Z(specs.get$I(i).getFilePath$(), specs.get$I(i), false);

return source;
}, 1);

Clazz.newMeth(C$, 'getHeaderRowDataAsArray$Z$SAA',  function (addDataClass, rowData) {
if (rowData == null ) rowData=Clazz.array(String, [0, 0]);
var data=this.getHeaderRowDataAsArray$Z$I(addDataClass, rowData.length);
for (var i=rowData.length; --i >= 0; ) data[data.length - rowData.length + i]=rowData[i];

return data;
});

Clazz.newMeth(C$, 'setID$S',  function (id) {
this.jdxSpectra.get$I(0).sourceID=id;
});

Clazz.newMeth(C$, 'matchesFilePath$S',  function (filePath) {
return this.filePath.equals$O(filePath) || this.filePath.replace$C$C("\\", "/").equals$O(filePath) ;
});

Clazz.newMeth(C$, 'setInlineData$S',  function (data) {
this.inlineData=data;
if (this.jdxSpectra != null ) for (var i=this.jdxSpectra.size$(); --i >= 0; ) this.jdxSpectra.get$I(i).setInlineData$S(data);

});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:07 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
