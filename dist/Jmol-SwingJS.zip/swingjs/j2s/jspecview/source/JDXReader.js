(function(){var P$=Clazz.newPackage("jspecview.source"),p$1={},I$=[[0,'javajs.util.PT','java.util.LinkedHashMap','javajs.util.AU','javajs.util.Rdr','jspecview.common.JSVFileManager','jspecview.common.JSViewer','org.jmol.util.Logger','javajs.api.Interface','jspecview.source.JDXSource','jspecview.source.JDXSourceStreamTokenizer','javajs.util.SB','jspecview.common.Spectrum','javajs.util.Lst','java.util.Hashtable','java.util.StringTokenizer','jspecview.common.Coordinate','jspecview.source.JDXDecompressor','java.io.BufferedReader','java.io.StringReader','jspecview.common.PeakInfo']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JDXReader", null, null, 'org.jmol.api.JmolJDXMOLReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.nmrMaxY=NaN;
this.loadImaginary=true;
this.lastErrPath=null;
this.firstSpec=0;
this.lastSpec=0;
this.nSpec=0;
},1);

C$.$fields$=[['Z',['obscure','done','isZipFile','loadImaginary','isSimulation','ignoreShiftReference','ignorePeakTables','isTabularData'],'D',['nmrMaxY','blockID'],'I',['firstSpec','lastSpec','nSpec'],'S',['filePath','lastErrPath','acdMolFile'],'O',['source','jspecview.source.JDXSource','t','jspecview.source.JDXSourceStreamTokenizer','errorLog','javajs.util.SB','mpr','org.jmol.api.JmolJDXMOLParser','reader','java.io.BufferedReader','modelSpectrum','jspecview.common.Spectrum','acdAssignments','javajs.util.Lst','+peakData']]
,['O',['VAR_LIST_TABLE','String[]']]]

Clazz.newMeth(C$, 'getVarList$S',  function (dataClass) {
var index=C$.VAR_LIST_TABLE[0].indexOf$S(dataClass);
return C$.VAR_LIST_TABLE[1].substring$I$I(index + 1, index + 12).trim$();
}, 1);

Clazz.newMeth(C$, 'c$$S$Z$Z$I$I$D',  function (filePath, obscure, loadImaginary, iSpecFirst, iSpecLast, nmrNormalization) {
;C$.$init$.apply(this);
filePath=$I$(1).trimQuotes$S(filePath);
this.isSimulation=(filePath != null  && filePath.startsWith$S("http://SIMULATION/") );
if (this.isSimulation) {
this.nmrMaxY=(Double.isNaN$D(nmrNormalization) ? 10000 : nmrNormalization);
}this.filePath=filePath;
this.obscure=obscure;
this.firstSpec=iSpecFirst;
this.lastSpec=iSpecLast;
this.loadImaginary=loadImaginary;
}, 1);

Clazz.newMeth(C$, 'createJDXSourceFromStream$java_io_InputStream$Z$Z$D',  function ($in, obscure, loadImaginary, nmrMaxY) {
return C$.createJDXSource$org_jmol_api_GenericFileInterface$O$S$Z$Z$I$I$D(null, $in, "stream", obscure, loadImaginary, -1, -1, nmrMaxY);
}, 1);

Clazz.newMeth(C$, 'getHeaderMap$java_io_InputStream$java_util_Map',  function ($in, map) {
return C$.getHeaderMapS$java_io_InputStream$java_util_Map$S($in, map, null);
}, 1);

Clazz.newMeth(C$, 'getHeaderMapS$java_io_InputStream$java_util_Map$S',  function ($in, map, suffix) {
if (map == null ) map=Clazz.new_($I$(2,1));
var hlist=C$.createJDXSource$org_jmol_api_GenericFileInterface$O$S$Z$Z$I$I$D(null, $in, null, false, false, 0, -1, 0).getJDXSpectrum$I(0).headerTable;
for (var i=0, n=hlist.size$(); i < n; i++) {
var h=hlist.get$I(i);
map.put$O$O((suffix == null  ? h[2] : h[2] + suffix), h[1]);
}
return map;
}, 1);

Clazz.newMeth(C$, 'createJDXSource$org_jmol_api_GenericFileInterface$O$S$Z$Z$I$I$D',  function (file, $in, filePath, obscure, loadImaginary, iSpecFirst, iSpecLast, nmrMaxY) {
var isHeaderOnly=(iSpecLast < iSpecFirst);
var data=null;
var br;
var bytes=null;
if ($I$(3).isAB$O($in)) {
bytes=$in;
if ($I$(4).isZipB$BA(bytes)) {
return C$.readBrukerFileZip$BA$S(bytes, file == null  ? filePath : file.getFullPath$());
}}if (Clazz.instanceOf($in, "java.lang.String") || bytes != null  ) {
if (Clazz.instanceOf($in, "java.lang.String")) data=$in;
br=$I$(5).getBufferedReaderForStringOrBytes$O($in);
} else if (Clazz.instanceOf($in, "java.io.InputStream")) {
br=$I$(5).getBufferedReaderForInputStream$java_io_InputStream($in);
} else {
br=$in;
}var header=null;
var source=null;
try {
if (br == null ) {
if (file != null  && file.isDirectory$() ) return C$.readBrukerFileDir$S(file.getFullPath$());
br=$I$(5).getBufferedReaderFromName$S$S(filePath, "##TITLE");
}if (!isHeaderOnly) {
br.mark$I(400);
var chs=Clazz.array(Character.TYPE, [400]);
br.read$CA$I$I(chs, 0, 400);
br.reset$();
header= String.instantialize(chs);
if (header.startsWith$S("PK")) {
br.close$();
return C$.readBrukerFileZip$BA$S(null, file.getFullPath$());
}if (header.indexOf$I("\u0000") >= 0 || header.indexOf$S("##TITLE= Parameter file") == 0  || header.indexOf$S("##TITLE= Audit trail") == 0 ) {
br.close$();
return C$.readBrukerFileDir$S(file.getParentAsFile$().getFullPath$());
}var pt1=header.indexOf$I("#");
var pt2=header.indexOf$I("<");
if (pt1 < 0 || pt2 >= 0 && pt2 < pt1  ) {
var xmlType=header.toLowerCase$();
xmlType=(xmlType.contains$CharSequence("<animl") || xmlType.contains$CharSequence("<!doctype technique")  ? "AnIML" : xmlType.contains$CharSequence("xml-cml") ? "CML" : null);
if (xmlType == null ) return C$.readBrukerFileDir$S(file.getFullPath$());
source=($I$(6).getInterface$S("jspecview.source." + xmlType + "Reader" )).getSource$S$java_io_BufferedReader(filePath, br);
br.close$();
if (source == null ) {
$I$(7).error$S(header + "...");
throw Clazz.new_(Clazz.load('jspecview.exception.JSVException').c$$S,["File type not recognized"]);
}}}if (source == null ) {
source=p$1.getJDXSource$O$Z.apply((Clazz.new_(C$.c$$S$Z$Z$I$I$D,[filePath, obscure, loadImaginary, iSpecFirst, iSpecLast, nmrMaxY])), [br, isHeaderOnly]);
}if (data != null ) source.setInlineData$S(data);
return source;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
if (!$I$(6).isJS) e.printStackTrace$();
if (br != null ) br.close$();
if (header != null ) $I$(7).error$S(header + "...");
var s=e.getMessage$();
{
}throw Clazz.new_(Clazz.load('jspecview.exception.JSVException').c$$S,["Error reading data: " + s]);
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'readBrukerFileDir$S',  function (filePath) {
return ($I$(8).getInterface$S("jspecview.source.BrukerReader")).readBrukerDir$S(filePath);
}, 1);

Clazz.newMeth(C$, 'readBrukerFileZip$BA$S',  function (bytes, filePath) {
return ($I$(8).getInterface$S("jspecview.source.BrukerReader")).readBrukerZip$BA$S(bytes, filePath);
}, 1);

Clazz.newMeth(C$, 'getJDXSource$O$Z',  function (reader, isHeaderOnly) {
this.source=Clazz.new_($I$(9,1).c$$I$S,[0, this.filePath]);
this.isZipFile=(Clazz.instanceOf(reader, "jspecview.api.JSVZipReader"));
this.t=Clazz.new_($I$(10,1).c$$java_io_BufferedReader,[reader]);
this.errorLog=Clazz.new_($I$(11,1));
var label=null;
var value=null;
var isOK=false;
while (!this.done && "##TITLE".equals$O(this.t.peakLabel$()) ){
isOK=true;
if (label != null  && !this.isZipFile ) p$1.logError$S.apply(this, ["Warning - file is a concatenation without LINK record -- does not conform to JCAMP-DX standard 6.1.3!"]);
var spectrum=Clazz.new_($I$(12,1));
var dataLDRTable=Clazz.new_($I$(13,1));
if (isHeaderOnly) spectrum.setHeaderTable$javajs_util_Lst(dataLDRTable);
while (!this.done && (label=this.t.getLabel$()) != null   && (value=p$1.getValue$S.apply(this, [label])) != null  ){
if (this.isTabularData) {
p$1.processTabularData$jspecview_source_JDXDataObject$javajs_util_Lst$S$Z.apply(this, [spectrum, dataLDRTable, label, isHeaderOnly]);
p$1.addSpectrum$jspecview_common_Spectrum$Z.apply(this, [spectrum, false]);
if (this.isSimulation && spectrum.getXUnits$().equals$O("PPM") ) spectrum.setHZtoPPM$Z(true);
spectrum=null;
if (isHeaderOnly) {
C$.addHeader$javajs_util_Lst$S$S(dataLDRTable, this.t.rawLabel, "<data>");
break;
}continue;
}if (!isHeaderOnly) {
if (label.equals$O("##DATATYPE") && value.toUpperCase$().equals$O("LINK") ) {
p$1.getBlockSpectra$javajs_util_Lst.apply(this, [dataLDRTable]);
spectrum=null;
continue;
}if (label.equals$O("##NTUPLES") || label.equals$O("##VARNAME") ) {
p$1.getNTupleSpectra$javajs_util_Lst$jspecview_source_JDXDataObject$S.apply(this, [dataLDRTable, spectrum, label]);
spectrum=null;
continue;
}}if (label.equals$O("##JCAMPDX")) {
p$1.setVenderSpecificValues$S.apply(this, [this.t.rawLine]);
}if (spectrum == null ) spectrum=Clazz.new_($I$(12,1));
p$1.processLabel$jspecview_common_Spectrum$javajs_util_Lst$S$S$Z.apply(this, [spectrum, dataLDRTable, label, value, isHeaderOnly]);
}
if (isHeaderOnly && spectrum != null  ) p$1.addSpectrum$jspecview_common_Spectrum$Z.apply(this, [spectrum, false]);
}
if (!isOK) throw Clazz.new_(Clazz.load('jspecview.exception.JSVException').c$$S,["##TITLE record not found"]);
this.source.setErrorLog$S(this.errorLog.toString());
return this.source;
}, p$1);

Clazz.newMeth(C$, 'processLabel$jspecview_common_Spectrum$javajs_util_Lst$S$S$Z',  function (spectrum, dataLDRTable, label, value, isHeaderOnly) {
if (!p$1.readDataLabel$jspecview_source_JDXDataObject$S$S$javajs_util_SB$Z$Z.apply(this, [spectrum, label, value, this.errorLog, this.obscure, isHeaderOnly]) && !isHeaderOnly ) return;
C$.addHeader$javajs_util_Lst$S$S(dataLDRTable, this.t.rawLabel, value);
if (!isHeaderOnly) p$1.checkCustomTags$jspecview_common_Spectrum$S$S.apply(this, [spectrum, label, value]);
}, p$1);

Clazz.newMeth(C$, 'logError$S',  function (err) {
this.errorLog.append$S(this.filePath == null  || this.filePath.equals$O(this.lastErrPath)  ? "" : this.filePath).append$S("\n").append$S(err).append$S("\n");
this.lastErrPath=this.filePath;
}, p$1);

Clazz.newMeth(C$, 'setVenderSpecificValues$S',  function (rawLine) {
if (rawLine.indexOf$S("JEOL") >= 0) {
System.out.println$S("Skipping ##SHIFTREFERENCE for JEOL " + rawLine);
this.ignoreShiftReference=true;
}if (rawLine.indexOf$S("MestReNova") >= 0) {
this.ignorePeakTables=true;
}}, p$1);

Clazz.newMeth(C$, 'getValue$S',  function (label) {
var value=(p$1.isTabularDataLabel$S.apply(this, [label]) ? "" : this.t.getValue$());
return ("##END".equals$O(label) ? null : value);
}, p$1);

Clazz.newMeth(C$, 'isTabularDataLabel$S',  function (label) {
return (this.isTabularData=("##DATATABLE##PEAKTABLE##XYDATA##XYPOINTS#".indexOf$S(label + "#") >= 0));
}, p$1);

Clazz.newMeth(C$, 'addSpectrum$jspecview_common_Spectrum$Z',  function (spectrum, forceSub) {
if (!this.loadImaginary && spectrum.isImaginary$() ) {
$I$(7).info$S("FileReader skipping imaginary spectrum -- use LOADIMAGINARY TRUE to load this spectrum.");
return true;
}if (this.acdAssignments != null ) {
if (!spectrum.dataType.equals$O("MASS SPECTRUM") && !spectrum.isContinuous$() ) {
$I$(7).info$S("Skipping ACD Labs line spectrum for " + spectrum);
return true;
}if (this.acdAssignments.size$() > 0) {
try {
this.mpr.setACDAssignments$S$S$I$javajs_util_Lst$S(spectrum.title, spectrum.getTypeLabel$(), this.source.peakCount, this.acdAssignments, this.acdMolFile);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
$I$(7).info$S("Failed to create peak data: " + e);
} else {
throw e;
}
}
}if (this.acdMolFile != null ) $I$(5).cachePut$S$S("mol", this.acdMolFile);
}if (!Double.isNaN$D(this.nmrMaxY)) spectrum.normalizeSimulation$D(this.nmrMaxY);
 else if (spectrum.getMaxY$() >= 10000 ) spectrum.normalizeSimulation$D(1000);
if (this.isSimulation) spectrum.setSimulated$S(this.filePath);
++this.nSpec;
if (this.firstSpec > 0 && this.nSpec < this.firstSpec ) return true;
if (this.lastSpec > 0 && this.nSpec > this.lastSpec ) return !(this.done=true);
spectrum.setBlockID$D(this.blockID);
this.source.addJDXSpectrum$S$jspecview_common_Spectrum$Z(null, spectrum, forceSub);
return true;
}, p$1);

Clazz.newMeth(C$, 'getBlockSpectra$javajs_util_Lst',  function (sourceLDRTable) {
$I$(7).debug$S("--JDX block start--");
var label="";
var value=null;
var isNew=(this.source.type == 0);
var forceSub=false;
while ((label=this.t.getLabel$()) != null  && !label.equals$O("##TITLE") ){
value=p$1.getValue$S.apply(this, [label]);
if (isNew && !C$.readHeaderLabel$jspecview_source_JDXHeader$S$S$javajs_util_SB$Z(this.source, label, value, this.errorLog, this.obscure) ) C$.addHeader$javajs_util_Lst$S$S(sourceLDRTable, this.t.rawLabel, value);
if (label.equals$O("##BLOCKS")) {
var nBlocks=$I$(1).parseInt$S(value);
if (nBlocks > 100 && this.firstSpec <= 0 ) forceSub=true;
}}
value=p$1.getValue$S.apply(this, [label]);
if (!"##TITLE".equals$O(label)) throw Clazz.new_(Clazz.load('jspecview.exception.JSVException').c$$S,["Unable to read block source"]);
if (isNew) this.source.setHeaderTable$javajs_util_Lst(sourceLDRTable);
this.source.type=1;
this.source.isCompoundSource=true;
var dataLDRTable;
var spectrum=Clazz.new_($I$(12,1));
dataLDRTable=Clazz.new_($I$(13,1));
p$1.readDataLabel$jspecview_source_JDXDataObject$S$S$javajs_util_SB$Z$Z.apply(this, [spectrum, label, value, this.errorLog, this.obscure, false]);
try {
var tmp;
while ((tmp=this.t.getLabel$()) != null ){
if ((value=p$1.getValue$S.apply(this, [tmp])) == null  && "##END".equals$O(label) ) {
$I$(7,"debug$S",["##END= " + this.t.getValue$()]);
break;
}label=tmp;
if (this.isTabularData) {
p$1.processTabularData$jspecview_source_JDXDataObject$javajs_util_Lst$S$Z.apply(this, [spectrum, dataLDRTable, label, false]);
continue;
}if (label.equals$O("##DATATYPE")) {
if (value.toUpperCase$().equals$O("LINK")) {
p$1.getBlockSpectra$javajs_util_Lst.apply(this, [dataLDRTable]);
spectrum=null;
label=null;
} else if (value.toUpperCase$().startsWith$S("NMR PEAK")) {
if (this.ignorePeakTables) {
this.done=true;
return this.source;
}}} else if (label.equals$O("##NTUPLES") || label.equals$O("##VARNAME") ) {
p$1.getNTupleSpectra$javajs_util_Lst$jspecview_source_JDXDataObject$S.apply(this, [dataLDRTable, spectrum, label]);
spectrum=null;
label="";
}if (this.done) break;
if (spectrum == null ) {
spectrum=Clazz.new_($I$(12,1));
dataLDRTable=Clazz.new_($I$(13,1));
if (label === "" ) continue;
if (label == null ) {
label="##END";
continue;
}}if (value == null ) {
if (spectrum.getXYCoords$().length > 0 && !p$1.addSpectrum$jspecview_common_Spectrum$Z.apply(this, [spectrum, forceSub]) ) return this.source;
spectrum=Clazz.new_($I$(12,1));
dataLDRTable=Clazz.new_($I$(13,1));
continue;
}p$1.processLabel$jspecview_common_Spectrum$javajs_util_Lst$S$S$Z.apply(this, [spectrum, dataLDRTable, label, value, false]);
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
if (!$I$(6).isJS) e.printStackTrace$();
throw Clazz.new_(Clazz.load('jspecview.exception.JSVException').c$$S,[e.getMessage$()]);
} else {
throw e;
}
}
p$1.addErrorLogSeparator.apply(this, []);
this.source.setErrorLog$S(this.errorLog.toString());
$I$(7).debug$S("--JDX block end--");
return this.source;
}, p$1);

Clazz.newMeth(C$, 'addErrorLogSeparator',  function () {
if (this.errorLog.length$() > 0 && this.errorLog.lastIndexOf$S("=====================\n") != this.errorLog.length$() - "=====================\n".length$() ) p$1.logError$S.apply(this, ["=====================\n"]);
}, p$1);

Clazz.newMeth(C$, 'getNTupleSpectra$javajs_util_Lst$jspecview_source_JDXDataObject$S',  function (sourceLDRTable, spectrum0, label) {
var minMaxY=Clazz.array(Double.TYPE, -1, [1.7976931348623157E308, 4.9E-324]);
this.blockID=Math.random();
var isOK=true;
if (this.firstSpec > 0) spectrum0.setNumDim$I(1);
var isVARNAME=label.equals$O("##VARNAME");
if (!isVARNAME) {
label="";
}var nTupleTable=Clazz.new_($I$(14,1));
var plotSymbols=Clazz.array(String, [2]);
var isNew=(this.source.type == 0);
if (isNew) {
this.source.type=2;
this.source.isCompoundSource=true;
this.source.setHeaderTable$javajs_util_Lst(sourceLDRTable);
}while (!(label=(isVARNAME ? label : this.t.getLabel$())).equals$O("##PAGE")){
isVARNAME=false;
var st=Clazz.new_([this.t.getValue$(), ","],$I$(15,1).c$$S$S);
var attrList=Clazz.new_($I$(13,1));
while (st.hasMoreTokens$())attrList.addLast$O(st.nextToken$().trim$());

nTupleTable.put$O$O(label, attrList);
}
var symbols=nTupleTable.get$O("##SYMBOL");
if (!label.equals$O("##PAGE")) throw Clazz.new_(Clazz.load('jspecview.exception.JSVException').c$$S,["Error Reading NTuple Source"]);
var page=this.t.getValue$();
var spectrum=null;
var isFirst=true;
while (!this.done){
if ((label=this.t.getLabel$()).equals$O("##ENDNTUPLES")) {
this.t.getValue$();
break;
}if (label.equals$O("##PAGE")) {
page=this.t.getValue$();
continue;
}if (spectrum == null ) {
spectrum=Clazz.new_($I$(12,1));
spectrum0.copyTo$jspecview_source_JDXDataObject(spectrum);
spectrum.setTitle$S(spectrum0.getTitle$());
if (!spectrum.is1D$()) {
var pt=page.indexOf$I("=");
if (pt >= 0) try {
spectrum.setY2D$D(p$1.parseAFFN$S$S.apply(this, [page.substring$I$I(0, pt), page.substring$I(pt + 1).trim$()]));
var y2dUnits=page.substring$I$I(0, pt).trim$();
var i=symbols.indexOf$O(y2dUnits);
if (i >= 0) spectrum.setY2DUnits$S(nTupleTable.get$O("##UNITS").get$I(i));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}}var dataLDRTable=Clazz.new_($I$(13,1));
spectrum.setHeaderTable$javajs_util_Lst(dataLDRTable);
while (!label.equals$O("##DATATABLE")){
C$.addHeader$javajs_util_Lst$S$S(dataLDRTable, this.t.rawLabel, this.t.getValue$());
label=this.t.getLabel$();
}
var continuous=true;
var line=this.t.flushLine$();
if (line.trim$().indexOf$S("PEAKS") > 0) continuous=false;
var index1=line.indexOf$I("(");
var index2=line.lastIndexOf$I(")");
if (index1 == -1 || index2 == -1 ) throw Clazz.new_(Clazz.load('jspecview.exception.JSVException').c$$S,["Variable List not Found"]);
var varList=line.substring$I$I(index1, index2 + 1);
var countSyms=0;
for (var i=0; i < symbols.size$(); i++) {
var sym=symbols.get$I(i).trim$();
if (varList.indexOf$S(sym) != -1) {
plotSymbols[countSyms++]=sym;
}if (countSyms == 2) break;
}
p$1.setTabularDataType$jspecview_source_JDXDataObject$S.apply(this, [spectrum, "##" + (continuous ? "XYDATA" : "PEAKTABLE")]);
if (!p$1.readNTUPLECoords$jspecview_source_JDXDataObject$java_util_Map$SA$DA.apply(this, [spectrum, nTupleTable, plotSymbols, minMaxY])) throw Clazz.new_(Clazz.load('jspecview.exception.JSVException').c$$S,["Unable to read Ntuple Source"]);
if (!spectrum.nucleusX.equals$O("?")) spectrum0.nucleusX=spectrum.nucleusX;
spectrum0.nucleusY=spectrum.nucleusY;
spectrum0.freq2dX=spectrum.freq2dX;
spectrum0.freq2dY=spectrum.freq2dY;
spectrum0.y2DUnits=spectrum.y2DUnits;
for (var i=0; i < sourceLDRTable.size$(); i++) {
var entry=sourceLDRTable.get$I(i);
var key=$I$(10).cleanLabel$S(entry[0]);
if (!key.equals$O("##TITLE") && !key.equals$O("##DATACLASS") && !key.equals$O("##NTUPLES")  ) dataLDRTable.addLast$O(entry);
}
if (isOK) p$1.addSpectrum$jspecview_common_Spectrum$Z.apply(this, [spectrum, !isFirst]);
isFirst=false;
spectrum=null;
}
p$1.addErrorLogSeparator.apply(this, []);
this.source.setErrorLog$S(this.errorLog.toString());
$I$(7,"info$S",["NTUPLE MIN/MAX Y = " + new Double(minMaxY[0]).toString() + " " + new Double(minMaxY[1]).toString() ]);
return this.source;
}, p$1);

Clazz.newMeth(C$, 'readDataLabel$jspecview_source_JDXDataObject$S$S$javajs_util_SB$Z$Z',  function (spectrum, label, value, errorLog, obscure, isHeaderOnly) {
if (!C$.readHeaderLabel$jspecview_source_JDXHeader$S$S$javajs_util_SB$Z(spectrum, label, value, errorLog, obscure)) return false;
label+=" ";
if (("##MINX ##MINY ##MAXX ##MAXY ##FIRSTY ##DELTAX ##DATACLASS ").indexOf$S(label) >= 0) return false;
switch (("##FIRSTX  ##LASTX   ##NPOINTS ##XFACTOR ##YFACTOR ##XUNITS  ##YUNITS  ##XLABEL  ##YLABEL  ##NUMDIM  ##OFFSET  ").indexOf$S(label)) {
case 0:
spectrum.fileFirstX=p$1.parseAFFN$S$S.apply(this, [label, value]);
return false;
case 10:
spectrum.fileLastX=p$1.parseAFFN$S$S.apply(this, [label, value]);
return false;
case 20:
spectrum.fileNPoints=Integer.parseInt$S(value);
return false;
case 30:
spectrum.setXFactor$D(p$1.parseAFFN$S$S.apply(this, [label, value]));
return false;
case 40:
spectrum.yFactor=p$1.parseAFFN$S$S.apply(this, [label, value]);
return false;
case 50:
spectrum.setXUnits$S(value);
return false;
case 60:
spectrum.setYUnits$S(value);
return false;
case 70:
spectrum.setXLabel$S(value);
return true;
case 80:
spectrum.setYLabel$S(value);
return true;
case 90:
spectrum.setNumDim$I(Integer.parseInt$S(value));
return false;
case 100:
if (!spectrum.isShiftTypeSpecified$()) {
spectrum.setShiftReference$D$I$I(p$1.parseAFFN$S$S.apply(this, [label, value]), 1, 1);
}return false;
default:
if (label.length$() < 17) return true;
if (label.equals$O("##.OBSERVEFREQUENCY ")) {
spectrum.setObservedFreq$D(p$1.parseAFFN$S$S.apply(this, [label, value]));
return false;
}if (label.equals$O("##.OBSERVENUCLEUS ")) {
spectrum.setObservedNucleus$S(value);
return false;
}if (label.equals$O("##$REFERENCEPOINT ") && !spectrum.isShiftTypeSpecified$() ) {
var pt=value.indexOf$S(" ");
if (pt > 0) value=value.substring$I$I(0, pt);
spectrum.setShiftReference$D$I$I(p$1.parseAFFN$S$S.apply(this, [label, value]), 1, 2);
return false;
}if (label.equals$O("##.SHIFTREFERENCE ")) {
if (this.ignoreShiftReference || !(spectrum.dataType.toUpperCase$().contains$CharSequence("SPECTRUM")) ) return false;
value=$I$(1,"replaceAllCharacters$S$S$S",[value, ")(", ""]);
var srt=Clazz.new_($I$(15,1).c$$S$S,[value, ","]);
if (srt.countTokens$() != 4) return false;
try {
srt.nextToken$();
srt.nextToken$();
var pt=Integer.parseInt$S(srt.nextToken$().trim$());
var shift=p$1.parseAFFN$S$S.apply(this, [label, srt.nextToken$().trim$()]);
spectrum.setShiftReference$D$I$I(shift, pt, 0);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
return false;
}return true;
}
}, p$1);

Clazz.newMeth(C$, 'readHeaderLabel$jspecview_source_JDXHeader$S$S$javajs_util_SB$Z',  function (jdxHeader, label, value, errorLog, obscure) {
switch (("##TITLE#####JCAMPDX###ORIGIN####OWNER#####DATATYPE##LONGDATE##DATE######TIME####").indexOf$S(label + "#")) {
case 0:
jdxHeader.setTitle$S(obscure || value == null   || value.equals$O("")  ? "Unknown" : value);
return false;
case 10:
jdxHeader.jcampdx=value;
var version=$I$(1).parseDouble$S(value);
if (version >= 6.0  || Double.isNaN$D(version) ) {
if (errorLog != null ) errorLog.append$S("Warning: JCAMP-DX version may not be fully supported: " + value);
}return false;
case 20:
jdxHeader.origin=(value != null  && !value.equals$O("")  ? value : "Unknown");
return false;
case 30:
jdxHeader.owner=(value != null  && !value.equals$O("")  ? value : "Unknown");
return false;
case 40:
jdxHeader.dataType=value;
return false;
case 50:
jdxHeader.longDate=value;
return false;
case 60:
jdxHeader.date=value;
return false;
case 70:
jdxHeader.time=value;
return false;
}
return true;
}, 1);

Clazz.newMeth(C$, 'setTabularDataType$jspecview_source_JDXDataObject$S',  function (spectrum, label) {
if (label.equals$O("##PEAKASSIGNMENTS")) spectrum.setDataClass$S("PEAKASSIGNMENTS");
 else if (label.equals$O("##PEAKTABLE")) spectrum.setDataClass$S("PEAKTABLE");
 else if (label.equals$O("##XYDATA")) spectrum.setDataClass$S("XYDATA");
 else if (label.equals$O("##XYPOINTS")) spectrum.setDataClass$S("XYPOINTS");
}, p$1);

Clazz.newMeth(C$, 'processTabularData$jspecview_source_JDXDataObject$javajs_util_Lst$S$Z',  function (spec, table, label, isHeaderOnly) {
p$1.setTabularDataType$jspecview_source_JDXDataObject$S.apply(this, [spec, label]);
spec.setHeaderTable$javajs_util_Lst(table);
if (spec.dataClass.equals$O("XYDATA")) {
spec.checkJDXRequiredTokens$();
if (!isHeaderOnly) p$1.decompressData$jspecview_source_JDXDataObject$DA.apply(this, [spec, null]);
return;
}if (spec.dataClass.equals$O("PEAKTABLE") || spec.dataClass.equals$O("XYPOINTS") ) {
spec.setContinuous$Z(spec.dataClass.equals$O("XYPOINTS"));
try {
this.t.readLineTrimmed$();
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
} else {
throw e;
}
}
var xyCoords;
if (spec.xFactor != 1.7976931348623157E308  && spec.yFactor != 1.7976931348623157E308  ) {
var data=this.t.getValue$();
xyCoords=$I$(16).parseDSV$S$D$D(data, spec.xFactor, spec.yFactor);
} else {
xyCoords=$I$(16,"parseDSV$S$D$D",[this.t.getValue$(), 1, 1]);
}spec.setXYCoords$jspecview_common_CoordinateA(xyCoords);
var fileDeltaX=$I$(16,"deltaX$D$D$I",[xyCoords[xyCoords.length - 1].getXVal$(), xyCoords[0].getXVal$(), xyCoords.length]);
spec.setIncreasing$Z(fileDeltaX > 0 );
return;
}throw Clazz.new_(Clazz.load('jspecview.exception.JSVException').c$$S,["Unable to read JDX file tabular data for line " + this.t.labelLineNo]);
}, p$1);

Clazz.newMeth(C$, 'readNTUPLECoords$jspecview_source_JDXDataObject$java_util_Map$SA$DA',  function (spec, nTupleTable, plotSymbols, minMaxY) {
var list;
var label;
if (spec.dataClass.equals$O("XYDATA")) {
list=nTupleTable.get$O("##SYMBOL");
var index1=list.indexOf$O(plotSymbols[0]);
var index2=list.indexOf$O(plotSymbols[1]);
list=nTupleTable.get$O("##VARNAME");
spec.setVarName$S(list.get$I(index2).toUpperCase$());
list=nTupleTable.get$O(label="##FACTOR");
spec.setXFactor$D(p$1.parseAFFN$S$S.apply(this, [label, list.get$I(index1)]));
spec.setYFactor$D(p$1.parseAFFN$S$S.apply(this, [label, list.get$I(index2)]));
list=nTupleTable.get$O(label="##LAST");
spec.fileLastX=p$1.parseAFFN$S$S.apply(this, [label, list.get$I(index1)]);
list=nTupleTable.get$O(label="##FIRST");
spec.fileFirstX=p$1.parseAFFN$S$S.apply(this, [label, list.get$I(index1)]);
list=nTupleTable.get$O("##VARDIM");
spec.fileNPoints=Integer.parseInt$S(list.get$I(index1));
list=nTupleTable.get$O("##UNITS");
spec.setXUnits$S(list.get$I(index1));
spec.setYUnits$S(list.get$I(index2));
if (spec.nucleusX == null  && (list=nTupleTable.get$O("##.NUCLEUS")) != null  ) {
spec.setNucleusAndFreq$S$Z(list.get$I(0), false);
spec.setNucleusAndFreq$S$Z(list.get$I(index1), true);
} else {
if (spec.nucleusX == null ) spec.nucleusX="?";
}p$1.decompressData$jspecview_source_JDXDataObject$DA.apply(this, [spec, minMaxY]);
return true;
}if (spec.dataClass.equals$O("PEAKTABLE") || spec.dataClass.equals$O("XYPOINTS") ) {
spec.setContinuous$Z(spec.dataClass.equals$O("XYPOINTS"));
list=nTupleTable.get$O("##SYMBOL");
var index1=list.indexOf$O(plotSymbols[0]);
var index2=list.indexOf$O(plotSymbols[1]);
list=nTupleTable.get$O("##UNITS");
spec.setXUnits$S(list.get$I(index1));
spec.setYUnits$S(list.get$I(index2));
spec.setXYCoords$jspecview_common_CoordinateA($I$(16,"parseDSV$S$D$D",[this.t.getValue$(), spec.xFactor, spec.yFactor]));
return true;
}return false;
}, p$1);

Clazz.newMeth(C$, 'parseAFFN$S$S',  function (label, val) {
var pt=val.indexOf$S("E");
if (pt > 0) {
var len=val.length$();
var ch;
switch (len - pt) {
case 2:
case 3:
p$1.logError$S.apply(this, ["Warning - " + label + " value " + val + " is not of the format xxxE[+/-]nn or xxxE[+/-]nnn (spec. 4.5.3) -- warning only; accepted" ]);
break;
case 4:
case 5:
if ((ch=val.charAt$I(pt + 1)) == "+" || ch == "-" ) break;
default:
p$1.logError$S.apply(this, ["Error - " + label + " value " + val + " is not of the format xxxE[+/-]nn or xxxE[+/-]nnn (spec. 4.5.3) -- " + val.substring$I(pt) + " ignored!" ]);
val=val.substring$I$I(0, pt);
}
}return Double.parseDouble$S(val);
}, p$1);

Clazz.newMeth(C$, 'decompressData$jspecview_source_JDXDataObject$DA',  function (spec, minMaxY) {
var errPt=this.errorLog.length$();
spec.setIncreasing$Z(spec.fileLastX > spec.fileFirstX );
spec.setContinuous$Z(true);
var decompressor=Clazz.new_($I$(17,1).c$$jspecview_source_JDXSourceStreamTokenizer$D$D$D$D$I,[this.t, spec.fileFirstX, spec.fileLastX, spec.xFactor, spec.yFactor, spec.fileNPoints]);
var t=System.currentTimeMillis$();
var xyCoords=decompressor.decompressData$javajs_util_SB(this.errorLog);
if ($I$(7).debugging) $I$(7,"debug$S",["decompression time = " + (Long.$s(Long.$sub(System.currentTimeMillis$(),t))) + " ms" ]);
spec.setXYCoords$jspecview_common_CoordinateA(xyCoords);
var d=decompressor.getMinY$();
if (minMaxY != null ) {
if (d < minMaxY[0] ) minMaxY[0]=d;
d=decompressor.getMaxY$();
if (d > minMaxY[1] ) minMaxY[1]=d;
}spec.finalizeCoordinates$();
if (this.errorLog.length$() != errPt) {
var fileDeltaX=$I$(16).deltaX$D$D$I(spec.fileLastX, spec.fileFirstX, spec.fileNPoints);
p$1.logError$S.apply(this, [spec.getTitle$()]);
p$1.logError$S.apply(this, ["firstX from Header " + new Double(spec.fileFirstX).toString()]);
p$1.logError$S.apply(this, ["lastX from Header " + new Double(spec.fileLastX).toString() + " Found " + new Double(decompressor.lastX).toString() ]);
p$1.logError$S.apply(this, ["deltaX from Header " + new Double(fileDeltaX).toString()]);
p$1.logError$S.apply(this, ["Number of points in Header " + spec.fileNPoints + " Found " + decompressor.getNPointsFound$() ]);
} else {
}if ($I$(7).debugging) {
System.err.println$S(this.errorLog.toString());
}}, p$1);

Clazz.newMeth(C$, 'addHeader$javajs_util_Lst$S$S',  function (table, label, value) {
var entry=null;
for (var i=0; i < table.size$(); i++) if ((entry=table.get$I(i))[0].equals$O(label)) {
entry[1]=value;
return;
}
table.addLast$O(Clazz.array(String, -1, [label, value, $I$(10).cleanLabel$S(label)]));
}, 1);

Clazz.newMeth(C$, 'checkCustomTags$jspecview_common_Spectrum$S$S',  function (spectrum, label, value) {
if (label.length$() > 10) label=label.substring$I$I(0, 10);
if (spectrum == null ) System.out.println$S(label);
 else this.modelSpectrum=spectrum;
var pt="##$MODELS ##$PEAKS  ##$SIGNALS##$MOLFILE##PEAKASSI##$UVIRASS##$MSFRAGM".indexOf$S(label);
if (pt < 0) return false;
p$1.getMpr.apply(this, []).set$org_jmol_api_JmolJDXMOLReader$S$java_util_Map(this, this.filePath, null);
try {
this.reader=Clazz.new_([Clazz.new_($I$(19,1).c$$S,[value])],$I$(18,1).c$$java_io_Reader);
switch (pt) {
case 0:
this.mpr.readModels$();
break;
case 10:
case 20:
this.peakData=Clazz.new_($I$(13,1));
this.source.peakCount+=this.mpr.readPeaks$Z$I(pt == 20, this.source.peakCount);
break;
case 30:
this.acdAssignments=Clazz.new_($I$(13,1));
this.acdMolFile=$I$(1).rep$S$S$S(value, "$$ Empty String", "");
break;
case 40:
case 50:
case 60:
this.acdAssignments=this.mpr.readACDAssignments$I$Z((spectrum).fileNPoints, pt == 40);
break;
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
throw Clazz.new_(Clazz.load('jspecview.exception.JSVException').c$$S,[e.getMessage$()]);
} else {
throw e;
}
} finally {
this.reader=null;
}
return true;
}, p$1);

Clazz.newMeth(C$, 'getMpr',  function () {
return (this.mpr == null  ? this.mpr=$I$(6).getInterface$S("org.jmol.jsv.JDXMOLParser") : this.mpr);
}, p$1);

Clazz.newMeth(C$, 'rd$',  function () {
return this.reader.readLine$();
});

Clazz.newMeth(C$, 'setSpectrumPeaks$I$S$S',  function (nH, peakXLabel, peakYlabel) {
this.modelSpectrum.setPeakList$javajs_util_Lst$S$S(this.peakData, peakXLabel, peakYlabel);
if (this.modelSpectrum.isNMR$()) this.modelSpectrum.setHydrogenCount$I(nH);
});

Clazz.newMeth(C$, 'addPeakData$S',  function (info) {
if (this.peakData == null ) this.peakData=Clazz.new_($I$(13,1));
this.peakData.addLast$O(Clazz.new_($I$(20,1).c$$S,[info]));
});

Clazz.newMeth(C$, 'processModelData$S$S$S$S$S$D$D$Z',  function (id, data, type, base, last, modelScale, vibScale, isFirst) {
});

Clazz.newMeth(C$, 'discardLinesUntilContains$S',  function (containsMatch) {
var line;
while ((line=this.rd$()) != null  && line.indexOf$S(containsMatch) < 0 ){
}
return line;
});

Clazz.newMeth(C$, 'discardLinesUntilContains2$S$S',  function (s1, s2) {
var line;
while ((line=this.rd$()) != null  && line.indexOf$S(s1) < 0  && line.indexOf$S(s2) < 0 ){
}
return line;
});

Clazz.newMeth(C$, 'discardLinesUntilNonBlank$',  function () {
var line;
while ((line=this.rd$()) != null  && line.trim$().length$() == 0 ){
}
return line;
});

C$.$static$=function(){C$.$static$=0;
C$.VAR_LIST_TABLE=Clazz.array(String, -1, ["PEAKTABLE   XYDATA      XYPOINTS", " (XY..XY)    (X++(Y..Y)) (XY..XY)    "]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:58 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
