(function(){var P$=Clazz.newPackage("jspecview.source"),p$1={},I$=[[0,'javajs.util.Lst']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JDXHeader");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.title="";
this.jcampdx="5.01";
this.dataType="";
this.dataClass="";
this.origin="";
this.owner="PUBLIC DOMAIN";
this.longDate="";
this.date="";
this.time="";
this.headerTable=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['S',['title','jcampdx','dataType','dataClass','origin','owner','longDate','date','time','qualifiedType'],'O',['headerTable','javajs.util.Lst']]
,['O',['typeNames','String[]']]]

Clazz.newMeth(C$, 'setTitle$S',  function (title) {
this.title=title;
});

Clazz.newMeth(C$, 'setJcampdx$S',  function (versionNum) {
this.jcampdx=versionNum;
});

Clazz.newMeth(C$, 'setDataType$S',  function (dataType) {
this.dataType=dataType;
});

Clazz.newMeth(C$, 'setDataClass$S',  function (dataClass) {
this.dataClass=dataClass;
});

Clazz.newMeth(C$, 'setOrigin$S',  function (origin) {
this.origin=origin;
});

Clazz.newMeth(C$, 'setOwner$S',  function (owner) {
this.owner=owner;
});

Clazz.newMeth(C$, 'setLongDate$S',  function (longDate) {
this.longDate=longDate;
});

Clazz.newMeth(C$, 'setDate$S',  function (date) {
this.date=date;
});

Clazz.newMeth(C$, 'setTime$S',  function (time) {
this.time=time;
});

Clazz.newMeth(C$, 'getTitle$',  function () {
return this.title;
});

Clazz.newMeth(C$, 'getTypeName$S',  function (type) {
type=type.toUpperCase$();
for (var i=0; i < C$.typeNames.length; i++) if (C$.typeNames[i].startsWith$S(type)) {
return C$.typeNames[i].substring$I(18);
}
return type;
}, 1);

Clazz.newMeth(C$, 'getQualifiedDataType$',  function () {
return (this.qualifiedType == null  ? (this.qualifiedType=C$.getTypeName$S(this.dataType)) : this.qualifiedType);
});

Clazz.newMeth(C$, 'getJcampdx$',  function () {
return this.jcampdx;
});

Clazz.newMeth(C$, 'getDataType$',  function () {
return this.dataType;
});

Clazz.newMeth(C$, 'getOrigin$',  function () {
return this.origin;
});

Clazz.newMeth(C$, 'getOwner$',  function () {
return this.owner;
});

Clazz.newMeth(C$, 'getLongDate$',  function () {
return this.longDate;
});

Clazz.newMeth(C$, 'getDate$',  function () {
return this.date;
});

Clazz.newMeth(C$, 'getTime$',  function () {
return this.time;
});

Clazz.newMeth(C$, 'getDataClass$',  function () {
return this.dataClass;
});

Clazz.newMeth(C$, 'setHeaderTable$javajs_util_Lst',  function (table) {
this.headerTable=table;
});

Clazz.newMeth(C$, 'getHeaderTable$',  function () {
return this.headerTable;
});

Clazz.newMeth(C$, 'getHeaderRowDataAsArray$Z$I',  function (addDataClass, nMore) {
var rowData=Clazz.array(String, [(addDataClass ? 6 : 5) + this.headerTable.size$() + nMore , null]);
var i=0;
rowData[i++]=Clazz.array(String, -1, ["##TITLE", this.title]);
rowData[i++]=Clazz.array(String, -1, ["##JCAMP-DX", this.jcampdx]);
rowData[i++]=Clazz.array(String, -1, ["##DATA TYPE", this.dataType]);
if (addDataClass) rowData[i++]=Clazz.array(String, -1, ["##DATA CLASS", this.dataClass]);
rowData[i++]=Clazz.array(String, -1, ["##ORIGIN", this.origin]);
rowData[i++]=Clazz.array(String, -1, ["##OWNER", this.owner]);
for (var j=0; j < this.headerTable.size$(); j++) rowData[i++]=p$1.getRow$I.apply(this, [j]);

return rowData;
});

Clazz.newMeth(C$, 'getRow$I',  function (j) {
var s=this.headerTable.get$I(j);
{
return [s[0], javajs.util.PT.rep(s[1], "<", "&lt;")];
}
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.typeNames=Clazz.array(String, -1, ["ND NMR SPECTRUM   NMR", "NMR SPECTRUM      NMR", "INFRARED SPECTRUM IR", "MASS SPECTRUM     MS", "RAMAN SPECTRUM    RAMAN", "GAS CHROMATOGRAM  GC", "UV/VIS SPECTRUM   UV/VIS"]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:53 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
