(function(){var P$=Clazz.newPackage("jspecview.source"),p$1={},I$=[[0,'jspecview.source.JDXSource','jspecview.source.XMLReader','java.util.Vector','javajs.util.PT']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CMLReader", null, 'jspecview.source.XMLReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.specfound=false;
this.Ydelim="";
},1);

C$.$fields$=[['Z',['specfound'],'S',['Ydelim'],'O',['peakData','java.util.Vector']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'getXML$java_io_BufferedReader',  function (br) {
try {
this.source=Clazz.new_($I$(1,1).c$$I$S,[0, this.filePath]);
this.getSimpleXmlReader$java_io_BufferedReader(br);
this.processXML$I$I(4, 10);
if (!this.checkPointCount$()) return null;
this.populateVariables$();
} catch (pe) {
if (Clazz.exceptionOf(pe,"Exception")){
System.err.println$S("Error: " + pe);
} else {
throw pe;
}
}
this.processErrors$S("CML");
try {
br.close$();
} catch (e1) {
if (Clazz.exceptionOf(e1,"java.io.IOException")){
} else {
throw e1;
}
}
return this.source;
});

Clazz.newMeth(C$, 'processTag$I',  function (tagId) {
switch (tagId) {
case 4:
p$1.processSpectrum.apply(this, []);
return false;
case 9:
p$1.processSpectrumData.apply(this, []);
return true;
case 10:
p$1.processPeaks.apply(this, []);
return false;
case 8:
p$1.processSample.apply(this, []);
return true;
case 5:
p$1.processMetadataList.apply(this, []);
return true;
case 6:
p$1.processConditionList.apply(this, []);
return true;
case 7:
p$1.processParameterList.apply(this, []);
return true;
case 12:
this.processPeakList$();
return true;
default:
System.out.println$S("CMLSource not processing tag " + $I$(2).tagNames[tagId]);
return false;
}
});

Clazz.newMeth(C$, 'processEndTag$I',  function (tagId) {
});

Clazz.newMeth(C$, 'processSpectrum',  function () {
if (this.attrList.contains$CharSequence("title")) this.title=this.parser.getAttrValue$S("title");
 else if (this.attrList.contains$CharSequence("id")) this.title=this.parser.getAttrValue$S("id");
if (this.attrList.contains$CharSequence("type")) this.techname=this.parser.getAttrValue$S("type").toUpperCase$() + " SPECTRUM";
}, p$1);

Clazz.newMeth(C$, 'processMetadataList',  function () {
if (this.tagName.equals$O("metadata")) {
this.tagName=this.parser.getAttrValueLC$S("name");
if (this.tagName.contains$CharSequence(":origin")) {
if (this.attrList.contains$CharSequence("content")) this.origin=this.parser.getAttrValue$S("content");
 else this.origin=this.parser.thisValue$();
} else if (this.tagName.contains$CharSequence(":owner")) {
if (this.attrList.contains$CharSequence("content")) this.owner=this.parser.getAttrValue$S("content");
 else this.owner=this.parser.thisValue$();
} else if (this.tagName.contains$CharSequence("observenucleus")) {
if (this.attrList.contains$CharSequence("content")) this.obNucleus=this.parser.getAttrValue$S("content");
 else this.obNucleus=this.parser.thisValue$();
}}}, p$1);

Clazz.newMeth(C$, 'processParameterList',  function () {
if (this.tagName.equals$O("parameter")) {
var title=this.parser.getAttrValueLC$S("title");
if (title.equals$O("nmr.observe frequency")) {
this.StrObFreq=this.parser.qualifiedValue$();
this.obFreq=Double.parseDouble$S(this.StrObFreq);
} else if (title.equals$O("nmr.observe nucleus")) {
this.obNucleus=this.parser.getAttrValue$S("value");
} else if (title.equals$O("spectrometer/data system")) {
this.modelType=this.parser.getAttrValue$S("value");
} else if (title.equals$O("resolution")) {
this.resolution=this.parser.qualifiedValue$();
}}}, p$1);

Clazz.newMeth(C$, 'processConditionList',  function () {
if (this.tagName.equals$O("scalar")) {
var dictRef=this.parser.getAttrValueLC$S("dictRef");
if (dictRef.contains$CharSequence(":field")) {
this.StrObFreq=this.parser.thisValue$();
if ((this.StrObFreq.charCodeAt$I(0)) > 47  && (this.StrObFreq.charCodeAt$I(0)) < 58  ) this.obFreq=Double.parseDouble$S(this.StrObFreq);
}}}, p$1);

Clazz.newMeth(C$, 'processSample',  function () {
if (this.tagName.equals$O("formula")) {
if (this.attrList.contains$CharSequence("concise")) this.molForm=this.parser.getAttrValue$S("concise");
 else if (this.attrList.contains$CharSequence("inline")) this.molForm=this.parser.getAttrValue$S("inline");
} else if (this.tagName.equals$O("name")) {
this.casName=this.parser.thisValue$();
}}, p$1);

Clazz.newMeth(C$, 'processSpectrumData',  function () {
if (this.tagName.equals$O("xaxis")) {
if (this.attrList.contains$CharSequence("multipliertodata")) this.xFactor=Double.parseDouble$S(this.parser.getAttrValue$S("multiplierToData"));
this.parser.nextTag$();
this.tagName=this.parser.getTagName$();
this.attrList=this.parser.getAttributeList$();
if (this.tagName.equals$O("array")) {
this.xUnits=C$.checkUnits$S(this.parser.getAttrValue$S("units"));
this.npoints=Integer.parseInt$S(this.parser.getAttrValue$S("size"));
this.xaxisData=Clazz.array(Double.TYPE, [this.npoints]);
if (this.attrList.contains$CharSequence("start")) {
this.firstX=Double.parseDouble$S(this.parser.getAttrValue$S("start"));
this.lastX=Double.parseDouble$S(this.parser.getAttrValue$S("end"));
this.deltaX=(this.lastX - this.firstX) / (this.npoints - 1);
this.increasing=this.deltaX > 0  ? true : false;
this.continuous=true;
for (var j=0; j < this.npoints; j++) this.xaxisData[j]=this.firstX + (this.deltaX * j);

} else {
var posDelim=0;
var jj=-1;
var tempX="";
this.Ydelim=" ";
this.attrList=this.parser.getCharacters$().replace$C$C("\n", " ").replace$C$C("\r", " ").trim$();
do {
++jj;
posDelim=this.attrList.indexOf$S(this.Ydelim);
tempX=this.attrList.substring$I$I(0, posDelim);
this.xaxisData[jj]=Double.parseDouble$S(tempX) * this.xFactor;
this.attrList=this.attrList.substring$I$I(posDelim + 1, this.attrList.length$()).trim$();
posDelim=this.attrList.indexOf$S(this.Ydelim);
while (posDelim > 0){
++jj;
tempX=this.attrList.substring$I$I(0, posDelim);
this.xaxisData[jj]=Double.parseDouble$S(tempX) * this.xFactor;
this.attrList=this.attrList.substring$I$I(posDelim + 1, this.attrList.length$()).trim$();
posDelim=this.attrList.indexOf$S(this.Ydelim);
}
if (jj < this.npoints - 1) {
++jj;
this.xaxisData[jj]=Double.parseDouble$S(this.attrList) * this.xFactor;
}} while (jj < this.npoints - 1);
this.firstX=this.xaxisData[0];
this.lastX=this.xaxisData[this.npoints - 1];
this.continuous=true;
}}} else if (this.tagName.equals$O("yaxis")) {
if (this.attrList.contains$CharSequence("multipliertodata")) this.yFactor=Double.parseDouble$S(this.parser.getAttrValue$S("multiplierToData"));
this.parser.nextTag$();
this.tagName=this.parser.getTagName$();
this.attrList=this.parser.getAttributeList$();
if (this.tagName.equals$O("array")) {
this.yUnits=C$.checkUnits$S(this.parser.getAttrValue$S("units"));
var npointsY=Integer.valueOf$S(this.parser.getAttrValue$S("size"));
if (this.npoints != npointsY.intValue$()) System.err.println$S("npoints variation between X and Y arrays");
this.yaxisData=Clazz.array(Double.TYPE, [this.npoints]);
this.Ydelim=this.parser.getAttrValue$S("delimeter");
if (this.Ydelim.equals$O("")) this.Ydelim=" ";
var posDelim=0;
var jj=-1;
var tempY="";
this.attrList=this.parser.getCharacters$().replace$C$C("\n", " ").replace$C$C("\r", " ").trim$();
do {
++jj;
posDelim=this.attrList.indexOf$S(this.Ydelim);
tempY=this.attrList.substring$I$I(0, posDelim);
this.yaxisData[jj]=Double.parseDouble$S(tempY) * this.yFactor;
this.attrList=this.attrList.substring$I$I(posDelim + 1, this.attrList.length$()).trim$();
posDelim=this.attrList.indexOf$S(this.Ydelim);
while (posDelim > 0){
++jj;
tempY=this.attrList.substring$I$I(0, posDelim);
this.yaxisData[jj]=Double.parseDouble$S(tempY) * this.yFactor;
this.attrList=this.attrList.substring$I$I(posDelim + 1, this.attrList.length$()).trim$();
posDelim=this.attrList.indexOf$S(this.Ydelim);
}
if (jj < this.npoints - 1) {
++jj;
this.yaxisData[jj]=Double.parseDouble$S(this.attrList) * this.yFactor;
}} while (jj < this.npoints - 1);
}this.firstY=this.yaxisData[0];
this.specfound=true;
}}, p$1);

Clazz.newMeth(C$, 'processPeaks',  function () {
if (this.specfound) return;
this.peakData=Clazz.new_($I$(3,1));
this.process$I$Z(12, true);
this.npoints=this.peakData.size$();
this.xaxisData=Clazz.array(Double.TYPE, [this.npoints]);
this.yaxisData=Clazz.array(Double.TYPE, [this.npoints]);
for (var i=0; i < this.npoints; i++) {
var xy=this.peakData.get$I(i);
this.xaxisData[i]=xy[0];
this.yaxisData[i]=xy[1];
}
this.peakData=null;
this.firstX=this.xaxisData[0];
this.lastX=this.xaxisData[this.npoints - 1];
this.firstY=this.yaxisData[0];
this.increasing=(this.lastX > this.firstX );
this.continuous=false;
}, p$1);

Clazz.newMeth(C$, 'processPeakList$',  function () {
if (this.tagName.equals$O("peak")) {
if (this.attrList.contains$CharSequence("xvalue")) {
var xy=Clazz.array(Double.TYPE, [2]);
xy[1]=50;
xy[0]=Double.parseDouble$S(this.parser.getAttrValue$S("xValue"));
if (this.attrList.contains$CharSequence("xunits")) this.xUnits=C$.checkUnits$S(this.parser.getAttrValue$S("xUnits"));
if (this.attrList.contains$CharSequence("yvalue")) xy[1]=Double.parseDouble$S(this.parser.getAttrValue$S("yValue"));
if (this.attrList.contains$CharSequence("yunits")) this.yUnits=C$.checkUnits$S(this.parser.getAttrValue$S("yUnits"));
if (this.attrList.contains$CharSequence("atomrefs")) xy[1]=49 * $I$(4,"getTokens$S",[this.parser.getAttrValue$S("atomRefs")]).length;
this.peakData.add$O(xy);
}}});

Clazz.newMeth(C$, 'checkUnits$S',  function (units) {
units=units.substring$I(units.indexOf$S(":") + 1).toUpperCase$();
return (units.equals$O("RELABUNDANCE") ? "RELATIVE ABUNDANCE" : units.contains$CharSequence("ARBITRARY") ? "ARBITRARY UNITS" : units.equals$O("MOVERZ") ? "M/Z" : units.equals$O("CM-1") ? "1/CM" : units.equals$O("NM") ? "NANOMETERS" : units);
}, 1);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:29 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
