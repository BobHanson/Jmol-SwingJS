(function(){var P$=Clazz.newPackage("jspecview.source"),p$1={},I$=[[0,'java.util.zip.ZipInputStream','java.io.FileInputStream','java.io.ByteArrayInputStream','java.util.Hashtable','jspecview.source.JDXReader','java.io.File','jspecview.source.JDXSource','javajs.util.Lst','jspecview.common.Spectrum','jspecview.common.Coordinate','javajs.util.BinaryDocument','java.io.BufferedInputStream','javajs.util.Rdr']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "BrukerReader");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.allowPhasing=false;
},1);

C$.$fields$=[['Z',['allowPhasing']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'readBrukerZip$BA$S',  function (bytes, fullPath) {
try {
var zis=Clazz.new_([bytes == null  ? Clazz.new_($I$(2,1).c$$S,[fullPath]) : Clazz.new_($I$(3,1).c$$BA,[bytes])],$I$(1,1).c$$java_io_InputStream);
var ze;
var map=Clazz.new_($I$(4,1));
var data1r=Clazz.array(Byte.TYPE, [0]);
var data1i=Clazz.array(Byte.TYPE, [0]);
var data2rr=Clazz.array(Byte.TYPE, [0]);
var root=null;
var title=null;
 out : while ((ze=zis.getNextEntry$()) != null ){
var zeName=ze.getName$();
var pt=zeName.lastIndexOf$I("/");
var zeShortName=zeName.substring$I(pt + 1);
if (root == null ) {
root=zeName.substring$I$I(0, pt + 1);
pt=root.indexOf$S("/pdata/");
if (pt >= 0) root=root.substring$I$I(0, pt + 1);
}if (!zeName.startsWith$S(root)) break out;
var isacq=false;
if (zeShortName.equals$O("title")) {
title= String.instantialize(p$1.getBytes$java_io_InputStream$I$Z.apply(this, [zis, Long.$ival(ze.getSize$()), false]));
map.put$O$O("##title", title);
} else if (zeShortName.equals$O("1r")) {
data1r=p$1.getBytes$java_io_InputStream$I$Z.apply(this, [zis, Long.$ival(ze.getSize$()), false]);
} else if (zeShortName.equals$O("1i")) {
if (this.allowPhasing) data1i=p$1.getBytes$java_io_InputStream$I$Z.apply(this, [zis, Long.$ival(ze.getSize$()), false]);
} else if (zeShortName.equals$O("2rr")) {
data2rr=p$1.getBytes$java_io_InputStream$I$Z.apply(this, [zis, Long.$ival(ze.getSize$()), false]);
} else if (zeShortName.equals$O("proc2s") || zeShortName.equals$O("acqu2s") ) {
$I$(5,"getHeaderMapS$java_io_InputStream$java_util_Map$S",[Clazz.new_([p$1.getBytes$java_io_InputStream$I$Z.apply(this, [zis, Long.$ival(ze.getSize$()), false])],$I$(3,1).c$$BA), map, "_2"]);
} else if (zeShortName.equals$O("procs") || (isacq=zeShortName.equals$O("acqus")) ) {
if (isacq) {
root=zeName.substring$I$I(0, pt + 1);
}$I$(5,"getHeaderMap$java_io_InputStream$java_util_Map",[Clazz.new_([p$1.getBytes$java_io_InputStream$I$Z.apply(this, [zis, Long.$ival(ze.getSize$()), false])],$I$(3,1).c$$BA), map]);
}}
zis.close$();
map.put$O$O("##TITLE", (title == null  ? "" : title));
return p$1.getSource$S$java_util_Map$BA$BA$BA.apply(this, [fullPath, map, data1r, data1i, data2rr]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return null;
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'readBrukerDir$S',  function (fullPath) {
var dir=Clazz.new_($I$(6,1).c$$S,[fullPath]);
if (!dir.isDirectory$()) {
dir=dir.getParentFile$();
}var procs=Clazz.new_($I$(6,1).c$$java_io_File$S,[dir, "procs"]);
if (!procs.exists$()) procs=Clazz.new_($I$(6,1).c$$java_io_File$S,[dir, "pdata/1/procs"]);
var pdata=procs.getParentFile$();
var brukerDir=pdata.getParentFile$().getParentFile$();
var map=Clazz.new_($I$(4,1));
p$1.mapParameters$java_io_File$S$java_util_Map$S.apply(this, [brukerDir, "acqus", map, null]);
p$1.mapParameters$java_io_File$S$java_util_Map$S.apply(this, [brukerDir, "acqu2s", map, "_2"]);
p$1.mapParameters$java_io_File$S$java_util_Map$S.apply(this, [pdata, "procs", map, null]);
p$1.mapParameters$java_io_File$S$java_util_Map$S.apply(this, [pdata, "proc2s", map, "_2"]);
map.put$O$O("##TITLE",  String.instantialize(p$1.getFileContentsAsBytes$java_io_File.apply(this, [Clazz.new_($I$(6,1).c$$java_io_File$S,[pdata, "title"])])));
var data1r=p$1.getFileContentsAsBytes$java_io_File.apply(this, [Clazz.new_([procs.getParent$(), "1r"],$I$(6,1).c$$S$S)]);
var data1i=(this.allowPhasing ? p$1.getFileContentsAsBytes$java_io_File.apply(this, [Clazz.new_([procs.getParent$(), "1i"],$I$(6,1).c$$S$S)]) : Clazz.array(Byte.TYPE, [0]));
var data2rr=p$1.getFileContentsAsBytes$java_io_File.apply(this, [Clazz.new_([procs.getParent$(), "2rr"],$I$(6,1).c$$S$S)]);
return p$1.getSource$S$java_util_Map$BA$BA$BA.apply(this, [brukerDir.toString(), map, data1r, data1i, data2rr]);
});

Clazz.newMeth(C$, 'mapParameters$java_io_File$S$java_util_Map$S',  function (dir, fname, map, suffix) {
var f=Clazz.new_($I$(6,1).c$$java_io_File$S,[dir, fname]);
if (!f.exists$()) return;
var is=Clazz.new_($I$(2,1).c$$java_io_File,[f]);
$I$(5).getHeaderMapS$java_io_InputStream$java_util_Map$S(is, map, suffix);
is.close$();
}, p$1);

Clazz.newMeth(C$, 'getSource$S$java_util_Map$BA$BA$BA',  function (brukerDir, map, data1r, data1i, data2rr) {
var dtypp=Integer.parseInt$S(map.get$O("##$DTYPP"));
var byteorp=(dtypp == 0 ? Integer.parseInt$S(map.get$O("##$BYTORDP")) : 2147483647);
if (dtypp == -2147483648 || byteorp == -2147483648 ) return null;
var source=null;
if (data1r.length > 0) {
source=Clazz.new_([(data1i.length == 0 ? 0 : 2), brukerDir],$I$(7,1).c$$I$S);
p$1.setSource$DA$DA$java_util_Map$jspecview_source_JDXSource$Z.apply(this, [p$1.getData$BA$I$I.apply(this, [data1r, dtypp, byteorp]), p$1.getData$BA$I$I.apply(this, [data1i, dtypp, byteorp]), map, source, false]);
} else if (data2rr.length > 0) {
source=Clazz.new_($I$(7,1).c$$I$S,[2, brukerDir]);
p$1.setSource$DA$DA$java_util_Map$jspecview_source_JDXSource$Z.apply(this, [p$1.getData$BA$I$I.apply(this, [data2rr, dtypp, byteorp]), null, map, source, true]);
}return source;
}, p$1);

Clazz.newMeth(C$, 'setSource$DA$DA$java_util_Map$jspecview_source_JDXSource$Z',  function (datar, datai, map, source, is2D) {
var LDRTable=Clazz.new_($I$(8,1));
var spectrum0=Clazz.new_($I$(9,1));
spectrum0.setTitle$S(map.get$O("##TITLE"));
spectrum0.setJcampdx$S(is2D ? "6.0" : "5.1");
spectrum0.setDataClass$S("XYDATA");
spectrum0.setDataType$S(is2D ? "nD NMR SPECTRUM" : "NMR SPECTRUM");
spectrum0.setContinuous$Z(true);
spectrum0.setIncreasing$Z(false);
spectrum0.setLongDate$S(map.get$O("##$DATE"));
spectrum0.setOrigin$S("Bruker BioSpin GmbH/JSpecView");
spectrum0.setOwner$S(map.get$O("##OWNER"));
var freq=C$.parseDouble$S(map.get$O("##$SFO1"));
var ref=C$.parseDouble$S(map.get$O("##$ABSF1"));
if (ref == 0 ) {
ref=C$.parseDouble$S(map.get$O("##$OFFSET"));
}var nuc1=p$1.cleanJDXValue$S.apply(this, [map.get$O("##$NUC1")]);
var nuc2=p$1.cleanJDXValue$S.apply(this, [map.get$O("##$NUC2")]);
if (nuc2.length$() == 0) nuc2=nuc1;
var sw_hz=C$.parseDouble$S(map.get$O("##$SWP"));
var sw=sw_hz / freq;
var shift=ref - sw;
var solvent=p$1.cleanJDXValue$S.apply(this, [map.get$O("##$SOLVENT")]);
var shiftType="INTERNAL";
$I$(5,"addHeader$javajs_util_Lst$S$S",[LDRTable, "##.SHIFTREFERENCE", shiftType + ", " + solvent + ", 1, " + new Double(ref).toString() ]);
$I$(5,"addHeader$javajs_util_Lst$S$S",[LDRTable, "##.OBSERVEFREQUENCY", "" + new Double(freq).toString()]);
$I$(5).addHeader$javajs_util_Lst$S$S(LDRTable, "##.OBSERVENUCLEUS", nuc1);
$I$(5,"addHeader$javajs_util_Lst$S$S",[LDRTable, "##SPECTROMETER/DATA SYSTEM", p$1.cleanJDXValue$S.apply(this, [map.get$O("##$INSTRUM")])]);
spectrum0.setHeaderTable$javajs_util_Lst(LDRTable);
spectrum0.setObservedNucleus$S(nuc1);
spectrum0.setObservedFreq$D(freq);
spectrum0.setHZtoPPM$Z(true);
if (is2D) {
source.isCompoundSource=true;
spectrum0.setNumDim$I(2);
spectrum0.setNucleusAndFreq$S$Z(nuc2, false);
var si0=Integer.parseInt$S(map.get$O("##$SI"));
var si1=Integer.parseInt$S(map.get$O("##$SI_2"));
var ref1=C$.parseDouble$S(map.get$O("##$ABSF1_2"));
if (ref1 == 0 ) {
ref1=C$.parseDouble$S(map.get$O("##$OFFSET"));
}var freq1=C$.parseDouble$S(map.get$O("##$SFO1_2"));
var sw_hz1=C$.parseDouble$S(map.get$O("##$SWP_2"));
var npoints=si0;
var xfactor=sw_hz / npoints;
var xfactor1=sw_hz1 / si1;
var freq2=freq1;
freq1=ref1 * freq1 - xfactor1;
spectrum0.fileNPoints=npoints;
spectrum0.fileFirstX=sw_hz - xfactor;
spectrum0.fileLastX=0;
var f=1;
for (var j=0, pt=0; j < si1; j++) {
var spectrum=Clazz.new_($I$(9,1));
spectrum0.copyTo$jspecview_source_JDXDataObject(spectrum);
spectrum.setTitle$S(spectrum0.getTitle$());
spectrum.setY2D$D(freq1);
spectrum.blockID=Math.random();
spectrum0.fileNPoints=npoints;
spectrum0.fileFirstX=sw_hz - xfactor;
spectrum0.fileLastX=0;
spectrum.setY2DUnits$S("HZ");
spectrum.setXFactor$D(1);
spectrum.setYFactor$D(1);
spectrum.setObservedNucleus$S(nuc2);
spectrum.setObservedFreq$D(freq2);
var xyCoords=Clazz.array($I$(10), [npoints]);
for (var i=0; i < npoints; i++) {
xyCoords[npoints - i - 1 ]=Clazz.new_($I$(10,1)).set$D$D((npoints - i) * xfactor / freq + shift, datar[pt++] * f);
}
spectrum.setXYCoords$jspecview_common_CoordinateA(xyCoords);
source.addJDXSpectrum$S$jspecview_common_Spectrum$Z(null, spectrum, j > 0);
freq1-=xfactor1;
}
} else {
var npoints=datar.length;
var xfactor=sw_hz / npoints;
spectrum0.fileFirstX=sw_hz - xfactor;
spectrum0.fileLastX=0;
spectrum0.fileNPoints=npoints;
var xyCoords=Clazz.array($I$(10), [npoints]);
for (var i=0; i < npoints; i++) {
xyCoords[npoints - i - 1 ]=Clazz.new_($I$(10,1)).set$D$D((npoints - i - 1 ) * xfactor / freq + shift, datar[i]);
}
spectrum0.setXYCoords$jspecview_common_CoordinateA(xyCoords);
spectrum0.fileNPoints=npoints;
spectrum0.setXFactor$D(xfactor);
spectrum0.setYFactor$D(1);
spectrum0.setXUnits$S("ppm");
spectrum0.setYUnits$S("ARBITRARY UNITS");
spectrum0.setNumDim$I(1);
if (spectrum0.getMaxY$() >= 10000 ) spectrum0.normalizeSimulation$D(1000);
source.addJDXSpectrum$S$jspecview_common_Spectrum$Z(null, spectrum0, false);
}}, p$1);

Clazz.newMeth(C$, 'parseDouble$S',  function (val) {
return (val == null  || val.length$() == 0  ? NaN : Double.parseDouble$S(val));
}, 1);

Clazz.newMeth(C$, 'getData$BA$I$I',  function (bytes, dtypp, byteorp) {
var len=(bytes.length/(dtypp == 0 ? 4 : 8)|0);
var doc=Clazz.new_($I$(11,1));
doc.setStream$java_io_BufferedInputStream$Z(Clazz.new_([Clazz.new_($I$(3,1).c$$BA,[bytes])],$I$(12,1).c$$java_io_InputStream), byteorp != 0);
var ad=Clazz.array(Double.TYPE, [len]);
var d=0;
var dmin=1.7976931348623157E308;
var dmax=-1.7976931348623157E308;
if (dtypp == 0) {
for (var i=0; i < len; i++) {
var f=1;
ad[i]=d=doc.readInt$() * f;
if (d < dmin ) dmin=d;
if (d > dmax ) dmax=d;
}
} else {
for (var i=0; i < len; i++) {
ad[i]=d=doc.readDouble$();
if (d < dmin ) dmin=d;
if (d > dmax ) dmax=d;
}
}doc.close$();
return ad;
}, p$1);

Clazz.newMeth(C$, 'cleanJDXValue$S',  function (val) {
var s=(val == null  ? "" : val.startsWith$S("<") ? val.substring$I$I(1, val.length$() - 1) : val);
return (s.equals$O("off") ? "" : s);
}, p$1);

Clazz.newMeth(C$, 'getFileContentsAsBytes$java_io_File',  function (file) {
if (!file.exists$()) return Clazz.array(Byte.TYPE, [0]);
var len=Long.$ival(file.length$());
return p$1.getBytes$java_io_InputStream$I$Z.apply(this, [Clazz.new_($I$(2,1).c$$java_io_File,[file]), len, true]);
}, p$1);

Clazz.newMeth(C$, 'getBytes$java_io_InputStream$I$Z',  function ($in, len, andClose) {
try {
return $I$(13).getLimitedStreamBytes$java_io_InputStream$J($in, len);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
return Clazz.array(Byte.TYPE, [0]);
}, p$1);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:07 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
