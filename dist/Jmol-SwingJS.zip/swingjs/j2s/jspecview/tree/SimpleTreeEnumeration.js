(function(){var P$=Clazz.newPackage("jspecview.tree"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "SimpleTreeEnumeration", null, null, 'java.util.Enumeration');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['pt'],'O',['node','jspecview.tree.SimpleTreeNode']]]

Clazz.newMeth(C$, 'c$$jspecview_tree_SimpleTreeNode',  function (jsTreeNode) {
;C$.$init$.apply(this);
this.node=jsTreeNode;
}, 1);

Clazz.newMeth(C$, 'hasMoreElements$',  function () {
return (this.pt < this.node.children.size$());
});

Clazz.newMeth(C$, 'nextElement$',  function () {
return this.node.children.get$I(this.pt++);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:08 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
