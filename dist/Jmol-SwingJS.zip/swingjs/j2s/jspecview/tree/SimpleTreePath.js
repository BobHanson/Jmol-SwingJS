(function(){var P$=Clazz.newPackage("jspecview.tree"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "SimpleTreePath", null, null, 'jspecview.api.JSVTreePath');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['path','Object[]']]]

Clazz.newMeth(C$, 'c$$OA',  function (path) {
;C$.$init$.apply(this);
this.path=path;
}, 1);

Clazz.newMeth(C$, 'getLastPathComponent$',  function () {
return (this.path == null  || this.path.length == 0  ? null : this.path[this.path.length - 1]);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:08 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
