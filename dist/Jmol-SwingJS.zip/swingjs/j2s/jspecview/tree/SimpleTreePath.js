(function(){var P$=Clazz.newPackage("jspecview.tree"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "SimpleTreePath", null, null, 'jspecview.api.JSVTreePath');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['path','Object[]']]]

Clazz.newMeth(C$, 'c$$OA',  function (path) {
;C$.$init$.apply(this);
this.path=path;
}, 1);

Clazz.newMeth(C$, 'getLastPathComponent$',  function () {
return (this.path == null  || this.path.length == 0  ? null : this.path[this.path.length - 1]);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:53 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
