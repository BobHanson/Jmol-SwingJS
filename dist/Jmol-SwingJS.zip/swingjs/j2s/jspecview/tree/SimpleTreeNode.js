(function(){var P$=Clazz.newPackage("jspecview.tree"),I$=[[0,'javajs.util.Lst','jspecview.tree.SimpleTreeEnumeration']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SimpleTreeNode", null, null, 'jspecview.api.JSVTreeNode');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['index'],'S',['text'],'O',['panelNode','jspecview.common.PanelNode','prevNode','jspecview.tree.SimpleTreeNode','children','javajs.util.Lst']]]

Clazz.newMeth(C$, 'c$$S$jspecview_common_PanelNode',  function (text, panelNode) {
;C$.$init$.apply(this);
this.text=text;
this.panelNode=panelNode;
this.children=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'getPanelNode$',  function () {
return this.panelNode;
});

Clazz.newMeth(C$, 'getIndex$',  function () {
return this.index;
});

Clazz.newMeth(C$, 'setIndex$I',  function (index) {
this.index=index;
});

Clazz.newMeth(C$, 'children$',  function () {
return Clazz.new_($I$(2,1).c$$jspecview_tree_SimpleTreeNode,[this]);
});

Clazz.newMeth(C$, 'getChildCount$',  function () {
return this.children.size$();
});

Clazz.newMeth(C$, 'getPath$',  function () {
var o=Clazz.new_($I$(1,1));
var node=this;
o.addLast$O(node);
while ((node=node.prevNode) != null )o.add$I$O(0, node);

return o.toArray$();
});

Clazz.newMeth(C$, 'isLeaf$',  function () {
return (this.prevNode != null  && this.prevNode.prevNode != null  );
});

Clazz.newMeth(C$, 'toString',  function () {
return this.text;
});

Clazz.newMeth(C$, 'getChildAt$I',  function (childIndex) {
return this.children.get$I(childIndex);
});

Clazz.newMeth(C$, 'getParent$',  function () {
return this.prevNode;
});

Clazz.newMeth(C$, 'getIndex$javax_swing_tree_TreeNode',  function (node) {
return this.children.indexOf$O(node);
});

Clazz.newMeth(C$, 'getAllowsChildren$',  function () {
return true;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:29 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
