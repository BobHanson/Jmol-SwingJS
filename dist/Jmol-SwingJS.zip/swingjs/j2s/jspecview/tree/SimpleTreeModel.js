(function(){var P$=Clazz.newPackage("jspecview.tree"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "SimpleTreeModel");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['rootNode','jspecview.api.JSVTreeNode']]]

Clazz.newMeth(C$, 'c$$jspecview_api_JSVTreeNode',  function (rootNode) {
;C$.$init$.apply(this);
this.rootNode=rootNode;
}, 1);

Clazz.newMeth(C$, 'insertNodeInto$jspecview_api_JSVTreeNode$jspecview_api_JSVTreeNode$I',  function (fileNode, rootNode, i) {
var node=rootNode;
node.children.add$I$O(i, fileNode);
(fileNode).prevNode=node;
});

Clazz.newMeth(C$, 'removeNodeFromParent$jspecview_api_JSVTreeNode',  function (node) {
(node).prevNode.children.removeObj$O(node);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:53 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
