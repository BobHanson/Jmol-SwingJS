(function(){var P$=Clazz.newPackage("jspecview.tree"),p$1={},I$=[[0,'jspecview.tree.SimpleTreeNode','jspecview.tree.SimpleTreeModel','jspecview.common.PanelNode','jspecview.common.JSVFileManager','jspecview.tree.SimpleTreePath']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SimpleTree", null, null, 'jspecview.api.JSVTree');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['si','jspecview.api.ScriptInterface','rootNode','jspecview.api.JSVTreeNode','spectraTreeModel','jspecview.tree.SimpleTreeModel','vwr','jspecview.common.JSViewer','selectedPath','jspecview.tree.SimpleTreePath']]]

Clazz.newMeth(C$, 'getRootNode$',  function () {
return this.rootNode;
});

Clazz.newMeth(C$, 'c$$jspecview_common_JSViewer',  function (viewer) {
;C$.$init$.apply(this);
this.vwr=viewer;
this.rootNode=Clazz.new_($I$(1,1).c$$S$jspecview_common_PanelNode,["Spectra", null]);
this.spectraTreeModel=Clazz.new_($I$(2,1).c$$jspecview_api_JSVTreeNode,[this.rootNode]);
}, 1);

Clazz.newMeth(C$, 'valueChanged$',  function () {
this.vwr.selectedTreeNode$jspecview_api_JSVTreeNode(p$1.getLastSelectedPathComponent.apply(this, []));
});

Clazz.newMeth(C$, 'getLastSelectedPathComponent',  function () {
return (this.selectedPath == null  ? null : this.selectedPath.getLastPathComponent$());
}, p$1);

Clazz.newMeth(C$, 'setSelectedPanel$jspecview_api_ScriptInterface$jspecview_api_JSVPanel',  function (si, jsvp) {
if (jsvp != null ) {
var treeNode=$I$(3).findNode$jspecview_api_JSVPanel$javajs_util_Lst(jsvp, this.vwr.panelNodes).treeNode;
p$1.setSelectionPath$jspecview_api_JSVTreePath.apply(this, [this.vwr.spectraTree.newTreePath$OA(treeNode.getPath$())]);
}});

Clazz.newMeth(C$, 'setSelectionPath$jspecview_api_JSVTreePath',  function (newTreePath) {
this.selectedPath=newTreePath;
this.valueChanged$();
}, p$1);

Clazz.newMeth(C$, 'createTree$I$jspecview_source_JDXSource$jspecview_api_JSVPanelA',  function (fileCount, source, panels) {
var tree=this.vwr.spectraTree;
var rootNode=tree.getRootNode$();
var panelNodes=this.vwr.panelNodes;
var fileName=$I$(4,"getTagName$S",[source.getFilePath$()]);
var panelNode=Clazz.new_($I$(3,1).c$$S$S$jspecview_source_JDXSource$jspecview_api_JSVPanel,[null, fileName, source, null]);
var fileNode=Clazz.new_($I$(1,1).c$$S$jspecview_common_PanelNode,[fileName, panelNode]);
panelNode.setTreeNode$jspecview_api_JSVTreeNode(fileNode);
tree.spectraTreeModel.insertNodeInto$jspecview_api_JSVTreeNode$jspecview_api_JSVTreeNode$I(fileNode, rootNode, rootNode.getChildCount$());
for (var i=0; i < panels.length; i++) {
var jsvp=panels[i];
var id=fileCount + "." + (i + 1) ;
panelNode=Clazz.new_($I$(3,1).c$$S$S$jspecview_source_JDXSource$jspecview_api_JSVPanel,[id, fileName, source, jsvp]);
var treeNode=Clazz.new_([panelNode.toString(), panelNode],$I$(1,1).c$$S$jspecview_common_PanelNode);
panelNode.setTreeNode$jspecview_api_JSVTreeNode(treeNode);
panelNodes.addLast$O(panelNode);
tree.spectraTreeModel.insertNodeInto$jspecview_api_JSVTreeNode$jspecview_api_JSVTreeNode$I(treeNode, fileNode, fileNode.getChildCount$());
}
this.vwr.selectFrameNode$jspecview_api_JSVPanel(panels[0]);
return fileNode;
});

Clazz.newMeth(C$, 'setPath$jspecview_api_JSVTreePath',  function (path) {
p$1.setSelectionPath$jspecview_api_JSVTreePath.apply(this, [path]);
});

Clazz.newMeth(C$, 'newTreePath$OA',  function (path) {
return Clazz.new_($I$(5,1).c$$OA,[path]);
});

Clazz.newMeth(C$, 'deleteNodes$javajs_util_Lst',  function (toDelete) {
for (var i=0; i < toDelete.size$(); i++) {
this.spectraTreeModel.removeNodeFromParent$jspecview_api_JSVTreeNode(toDelete.get$I(i));
}
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:29 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
