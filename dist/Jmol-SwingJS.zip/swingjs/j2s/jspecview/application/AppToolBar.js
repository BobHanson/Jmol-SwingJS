(function(){var P$=Clazz.newPackage("jspecview.application"),p$1={},I$=[[0,'jspecview.common.ScriptToken','javax.swing.JToggleButton','javax.swing.JButton','javax.swing.ImageIcon','jspecview.application.AboutDialog']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AppToolBar", null, 'javax.swing.JToolBar');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mainFrame','jspecview.application.MainFrame','vwr','jspecview.common.JSViewer','gridToggleButton','javax.swing.JToggleButton','+coordsToggleButton','+revPlotToggleButton','spectraButton','javax.swing.JButton','+errorLogButton','errorLogIcon','javax.swing.ImageIcon','+errorLogYellowIcon','+errorLogRedIcon']]]

Clazz.newMeth(C$, 'c$$jspecview_application_MainFrame',  function (mainFrame) {
Clazz.super_(C$, this);
this.mainFrame=mainFrame;
this.vwr=mainFrame.vwr;
p$1.jbInit.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'setSelections$jspecview_api_JSVPanel',  function (jsvp) {
if (jsvp != null ) {
var pd=jsvp.getPanelData$();
this.gridToggleButton.setSelected$Z(pd.getBoolean$jspecview_common_ScriptToken($I$(1).GRIDON));
this.coordsToggleButton.setSelected$Z(pd.getBoolean$jspecview_common_ScriptToken($I$(1).COORDINATESON));
this.revPlotToggleButton.setSelected$Z(pd.getBoolean$jspecview_common_ScriptToken($I$(1).REVERSEPLOT));
}});

Clazz.newMeth(C$, 'setMenuEnables$jspecview_common_PanelNode',  function (node) {
if (node == null ) return;
this.setSelections$jspecview_api_JSVPanel(node.jsvp);
this.spectraButton.setToolTipText$S("View Spectra");
});

Clazz.newMeth(C$, 'setError$Z$Z',  function (isError, isWarningOnly) {
this.errorLogButton.setIcon$javax_swing_Icon(isWarningOnly ? this.errorLogYellowIcon : isError ? this.errorLogRedIcon : this.errorLogIcon);
this.errorLogButton.setEnabled$Z(isError || isWarningOnly );
});

Clazz.newMeth(C$, 'jbInit',  function () {
p$1.addButton$javax_swing_AbstractButton$S$O$S.apply(this, [null, "Open", "open24", "open"]);
p$1.addButton$javax_swing_AbstractButton$S$O$S.apply(this, [null, "Print", "print24", "print"]);
this.addSeparator$();
p$1.addButton$javax_swing_AbstractButton$S$O$S.apply(this, [this.gridToggleButton=Clazz.new_($I$(2,1)), "Toggle Grid", "grid24", "GRIDON TOGGLE"]);
p$1.addButton$javax_swing_AbstractButton$S$O$S.apply(this, [this.coordsToggleButton=Clazz.new_($I$(2,1)), "Toggle Coordinates", "coords24", "COORDINATESON TOGGLE"]);
p$1.addButton$javax_swing_AbstractButton$S$O$S.apply(this, [this.revPlotToggleButton=Clazz.new_($I$(2,1)), "Reverse Plot", "reverse24", "REVERSEPLOT TOGGLE"]);
this.addSeparator$();
p$1.addButton$javax_swing_AbstractButton$S$O$S.apply(this, [null, "Previous View", "previous24", "zoom previous"]);
p$1.addButton$javax_swing_AbstractButton$S$O$S.apply(this, [null, "Next View", "next24", "zoom next"]);
p$1.addButton$javax_swing_AbstractButton$S$O$S.apply(this, [null, "Reset", "reset24", "zoom out"]);
p$1.addButton$javax_swing_AbstractButton$S$O$S.apply(this, [null, "Clear Views", "clear24", "zoom clear"]);
this.addSeparator$();
p$1.addButton$javax_swing_AbstractButton$S$O$S.apply(this, [this.spectraButton=Clazz.new_($I$(3,1)), "Overlay Display", "overlay24", "view"]);
p$1.addButton$javax_swing_AbstractButton$S$O$S.apply(this, [null, "Display Key for Overlaid Spectra", "overlayKey24", "showKey TOGGLE"]);
this.addSeparator$();
this.errorLogIcon=C$.getIcon$O("errorLog24");
this.errorLogRedIcon=C$.getIcon$O("errorLogRed24");
this.errorLogYellowIcon=C$.getIcon$O("errorLogYellow24");
p$1.addButton$javax_swing_AbstractButton$S$O$S.apply(this, [null, "Properties", "information24", "showProperties"]);
p$1.addButton$javax_swing_AbstractButton$S$O$S.apply(this, [this.errorLogButton=Clazz.new_($I$(3,1)), "Error Log", this.errorLogIcon, "SHOWERRORS"]);
this.addSeparator$();
p$1.addButton$javax_swing_AbstractButton$S$O$S.apply(this, [null, "About JSpecView", "about24", "about"]);
}, p$1);

Clazz.newMeth(C$, 'getIcon$O',  function (name) {
return Clazz.new_([Clazz.getClass(C$).getResource$S("icons/" + name + ".gif" )],$I$(4,1).c$$java_net_URL);
}, 1);

Clazz.newMeth(C$, 'addButton$javax_swing_AbstractButton$S$O$S',  function (button, tip, icon, script) {
if (button == null ) button=Clazz.new_($I$(3,1));
if (Clazz.instanceOf(icon, "java.lang.String")) icon=C$.getIcon$O(icon);
button.setBorder$javax_swing_border_Border(null);
button.setToolTipText$S(tip);
button.setIcon$javax_swing_Icon(icon);
button.addActionListener$java_awt_event_ActionListener(((P$.AppToolBar$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "AppToolBar$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
if (this.$finals$.script.equals$O("open")) this.b$['jspecview.application.AppToolBar'].vwr.openFileFromDialog$Z$Z$S$S(false, false, null, null);
 else if (this.$finals$.script.equals$O("about")) Clazz.new_($I$(5,1).c$$java_awt_Frame,[this.b$['jspecview.application.AppToolBar'].mainFrame]);
 else this.b$['jspecview.application.AppToolBar'].vwr.runScript$S(this.$finals$.script);
});
})()
), Clazz.new_(P$.AppToolBar$1.$init$,[this, {script:script}])));
this.add$java_awt_Component$O(button, null);
return button;
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:51 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
