(function(){var P$=Clazz.newPackage("jspecview.application"),p$1={},I$=[[0,'javajs.util.Lst']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CommandHistory");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.cmdList=Clazz.new_($I$(1,1));
this.cmdPt=-1;
this.cmdOffset=0;
},1);

C$.$fields$=[['I',['cmdPt','cmdOffset'],'O',['vwr','jspecview.common.JSViewer','input','javax.swing.JTextField','cmdList','javajs.util.Lst']]]

Clazz.newMeth(C$, 'c$$jspecview_common_JSViewer$javax_swing_JTextField',  function (viewer, commandInput) {
;C$.$init$.apply(this);
this.vwr=viewer;
this.input=commandInput;
}, 1);

Clazz.newMeth(C$, 'keyPressed$I',  function (keyCode) {
switch (keyCode) {
case 27:
this.input.setText$S("");
return;
case 10:
var cmd=this.input.getText$();
p$1.addCommand$S.apply(this, [cmd]);
this.vwr.runScript$S(cmd);
this.input.setText$S("");
this.input.requestFocusInWindow$();
return;
case 38:
case 40:
var s=p$1.recallCommand$Z.apply(this, [keyCode == 38]);
if (s != null ) this.input.setText$S(s);
break;
}
});

Clazz.newMeth(C$, 'recallCommand$Z',  function (isPrevious) {
this.cmdOffset=0;
if (isPrevious) {
if (this.cmdPt < 0 || this.cmdPt == this.cmdList.size$() ) return "";
this.cmdOffset=-1;
} else {
if (this.cmdPt <= 0) return "";
if (--this.cmdPt < 0) this.cmdPt=0;
}var cmd=this.cmdList.get$I(isPrevious ? this.cmdPt++ : this.cmdPt);
return cmd;
}, p$1);

Clazz.newMeth(C$, 'addCommand$S',  function (cmd) {
this.cmdPt+=this.cmdOffset;
this.cmdOffset=0;
if (this.cmdPt < 0) this.cmdPt=0;
if (this.cmdPt < this.cmdList.size$() && this.cmdList.get$I(this.cmdPt).equals$O(cmd) ) return;
this.cmdList.add$I$O(this.cmdPt, cmd);
}, p$1);

Clazz.newMeth(C$, 'dumpList$',  function () {
for (var i=0; i < this.cmdList.size$(); i++) System.out.println$S((i == this.cmdPt ? ">" : "") + i + "\t" + this.cmdList.get$I(i) );

System.out.println$S("");
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:04 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
