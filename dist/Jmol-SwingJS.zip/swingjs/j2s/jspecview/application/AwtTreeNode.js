(function(){var P$=Clazz.newPackage("jspecview.application"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "AwtTreeNode", null, 'javax.swing.tree.DefaultMutableTreeNode', 'jspecview.api.JSVTreeNode');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['index'],'O',['panelNode','jspecview.common.PanelNode']]]

Clazz.newMeth(C$, 'children$',  function () {
return C$.superclazz.prototype.children$.apply(this, []);
});

Clazz.newMeth(C$, 'c$$S$jspecview_common_PanelNode',  function (text, panelNode) {
;C$.superclazz.c$$O.apply(this,[text]);C$.$init$.apply(this);
this.panelNode=panelNode;
}, 1);

Clazz.newMeth(C$, 'getPanelNode$',  function () {
return this.panelNode;
});

Clazz.newMeth(C$, 'getIndex$',  function () {
return this.index;
});

Clazz.newMeth(C$, 'setIndex$I',  function (index) {
this.index=index;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:04 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
