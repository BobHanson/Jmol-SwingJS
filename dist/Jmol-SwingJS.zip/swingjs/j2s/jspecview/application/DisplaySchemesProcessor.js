(function(){var P$=Clazz.newPackage("jspecview.application"),p$1={},I$=[[0,'java.util.TreeMap','jspecview.java.AwtParameters','jspecview.common.ScriptToken','jspecview.common.ColorParameters','java.io.BufferedWriter','java.io.FileWriter','jspecview.common.JSVFileManager','jspecview.source.XMLParser','javajs.util.SB','javajs.util.CU']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DisplaySchemesProcessor");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.newLine=System.getProperty$S("line.separator");
this.fileName="displaySchemes.xml";
},1);

C$.$fields$=[['S',['newLine','fileName'],'O',['displaySchemes','java.util.TreeMap','parser','jspecview.source.XMLParser']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.displaySchemes=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'loadDefault$',  function () {
var dsdef=Clazz.new_($I$(2,1)).setName$S("Default");
dsdef.displayFontName="default";
dsdef.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).TITLECOLOR, $I$(4).BLACK);
dsdef.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).UNITSCOLOR, $I$(4).BLACK);
dsdef.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).SCALECOLOR, $I$(4).BLACK);
dsdef.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).COORDINATESCOLOR, $I$(4).BLACK);
dsdef.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).PEAKTABCOLOR, $I$(4).RED);
dsdef.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).HIGHLIGHTCOLOR, $I$(4).DARK_GRAY);
dsdef.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).GRIDCOLOR, $I$(4).BLACK);
dsdef.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).PLOTCOLOR, $I$(4).BLACK);
dsdef.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).PLOTAREACOLOR, $I$(4).WHITE);
dsdef.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).BACKGROUNDCOLOR, $I$(4).WHITE);
dsdef.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).INTEGRALPLOTCOLOR, $I$(4).RED);
this.displaySchemes.put$O$O("Default", dsdef);
return dsdef;
});

Clazz.newMeth(C$, 'getDefaultScheme$',  function () {
var ds=this.displaySchemes.get$O("Default");
if (ds == null ) {
ds=this.loadDefault$();
}return ds;
});

Clazz.newMeth(C$, 'store$',  function () {
this.serializeDisplaySchemes$java_io_Writer(Clazz.new_([Clazz.new_($I$(6,1).c$$S,[this.fileName])],$I$(5,1).c$$java_io_Writer));
});

Clazz.newMeth(C$, 'getDisplaySchemes$',  function () {
return this.displaySchemes;
});

Clazz.newMeth(C$, 'load$java_io_InputStream',  function (stream) {
try {
return this.load$java_io_BufferedReader($I$(7).getBufferedReaderForInputStream$java_io_InputStream(stream));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return false;
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'load$S',  function (dispSchemeFileName) {
this.fileName=dispSchemeFileName;
try {
var br=$I$(7).getBufferedReaderFromName$S$S(this.fileName, "##TITLE");
return this.load$java_io_BufferedReader(br);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$S("DisplaySchemeProcessor ignored: " + e.getMessage$());
return false;
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'load$java_io_BufferedReader',  function (br) {
this.parser=Clazz.new_($I$(8,1).c$$java_io_BufferedReader,[br]);
var defaultDS="Default";
var ds=null;
var attr;
try {
while (this.parser.hasNext$()){
if (this.parser.nextEvent$() != 1) continue;
var theTag=this.parser.getTagName$();
if (theTag.equals$O("displayschemes")) {
defaultDS=this.parser.getAttrValue$S("default");
}if (theTag.equals$O("displayscheme")) {
var name=this.parser.getAttrValue$S("name");
ds=Clazz.new_($I$(2,1)).setName$S(name);
if (name.equals$O(defaultDS)) ds.isDefault=true;
this.displaySchemes.put$O$O(name, ds);
}if (ds == null ) continue;
if (theTag.equals$O("font")) {
attr=this.parser.getAttrValue$S("face");
if (attr.length$() > 0) ds.displayFontName=attr;
} else {
if (theTag.equals$O("coordinateColor")) theTag="coordinatesColor";
var st=$I$(3).getScriptToken$S(theTag);
if (st !== $I$(3).UNKNOWN ) {
var color=p$1.getColor$jspecview_common_ColorParameters.apply(this, [ds]);
if (color == null ) {
var def;
switch (st) {
default:
def=null;
break;
case $I$(3).TITLECOLOR:
def="#0000ff";
break;
case $I$(3).COORDINATESCOLOR:
def="#ff0000";
break;
case $I$(3).PEAKTABCOLOR:
def="#ff0000";
break;
case $I$(3).HIGHLIGHTCOLOR:
def="#808080";
break;
case $I$(3).SCALECOLOR:
def="#660000";
break;
case $I$(3).UNITSCOLOR:
def="#ff0000";
break;
case $I$(3).GRIDCOLOR:
def="#4e4c4c";
break;
case $I$(3).PLOTCOLOR:
def="#ff9900";
break;
case $I$(3).PLOTAREACOLOR:
def="#333333";
break;
case $I$(3).BACKGROUNDCOLOR:
def="#c0c0c0";
break;
}
if (def != null ) color=ds.getColorFromString$S(def);
}if (color != null ) ds.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor(st, color);
}}}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return false;
} else {
throw e;
}
}
return true;
});

Clazz.newMeth(C$, 'getColor$jspecview_common_ColorParameters',  function (p) {
var value=this.parser.getAttrValueLC$S("hex");
return (value.length$() == 0 || value.equals$O("default")  ? null : p.getColorFromString$S(value));
}, p$1);

Clazz.newMeth(C$, 'serializeDisplaySchemes$java_io_Writer',  function (writer) {
if (this.displaySchemes.size$() == 0) {
return;
}var buffer=Clazz.new_($I$(9,1));
var defaultDSName="";
for (var ds, $ds = this.displaySchemes.values$().iterator$(); $ds.hasNext$()&&((ds=($ds.next$())),1);) {
if (ds.isDefault) defaultDSName=ds.name;
buffer.append$S("\t<displayScheme name=\"" + ds.name + "\">" ).append$S(this.newLine);
buffer.append$S("\t\t<font face=\"" + ds.displayFontName + "\"/>" ).append$S(this.newLine);
p$1.writeColor$javajs_util_SB$jspecview_common_ColorParameters$S$jspecview_common_ScriptToken.apply(this, [buffer, ds, "titleColor", $I$(3).TITLECOLOR]);
p$1.writeColor$javajs_util_SB$jspecview_common_ColorParameters$S$jspecview_common_ScriptToken.apply(this, [buffer, ds, "scaleColor", $I$(3).SCALECOLOR]);
p$1.writeColor$javajs_util_SB$jspecview_common_ColorParameters$S$jspecview_common_ScriptToken.apply(this, [buffer, ds, "unitsColor", $I$(3).UNITSCOLOR]);
p$1.writeColor$javajs_util_SB$jspecview_common_ColorParameters$S$jspecview_common_ScriptToken.apply(this, [buffer, ds, "coordinatesColor", $I$(3).COORDINATESCOLOR]);
p$1.writeColor$javajs_util_SB$jspecview_common_ColorParameters$S$jspecview_common_ScriptToken.apply(this, [buffer, ds, "highlightColor", $I$(3).HIGHLIGHTCOLOR]);
p$1.writeColor$javajs_util_SB$jspecview_common_ColorParameters$S$jspecview_common_ScriptToken.apply(this, [buffer, ds, "peakTabColor", $I$(3).PEAKTABCOLOR]);
p$1.writeColor$javajs_util_SB$jspecview_common_ColorParameters$S$jspecview_common_ScriptToken.apply(this, [buffer, ds, "gridColor", $I$(3).GRIDCOLOR]);
p$1.writeColor$javajs_util_SB$jspecview_common_ColorParameters$S$jspecview_common_ScriptToken.apply(this, [buffer, ds, "plotColor", $I$(3).PLOTCOLOR]);
p$1.writeColor$javajs_util_SB$jspecview_common_ColorParameters$S$jspecview_common_ScriptToken.apply(this, [buffer, ds, "plotAreaColor", $I$(3).PLOTAREACOLOR]);
p$1.writeColor$javajs_util_SB$jspecview_common_ColorParameters$S$jspecview_common_ScriptToken.apply(this, [buffer, ds, "backgroundColor", $I$(3).BACKGROUNDCOLOR]);
buffer.append$S("\t</displayScheme>").append$S(this.newLine);
}
buffer.append$S("</displaySchemes>");
var outBuffer=Clazz.new_($I$(9,1));
outBuffer.append$S("<?xml version=\"1.0\"?>" + this.newLine);
outBuffer.append$S("<displaySchemes default=\"" + defaultDSName + "\">" + this.newLine );
outBuffer.append$S(buffer.toString());
writer.write$S(outBuffer.toString());
writer.flush$();
writer.close$();
});

Clazz.newMeth(C$, 'writeColor$javajs_util_SB$jspecview_common_ColorParameters$S$jspecview_common_ScriptToken',  function (buffer, ds, name, t) {
buffer.append$S("\t\t<" + name + " hex=\"" + $I$(10,"toRGBHexString$javajs_api_GenericColor",[ds.getElementColor$jspecview_common_ScriptToken(t)]) + "\"/>" ).append$S(this.newLine);
}, p$1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:55 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
