(function(){var P$=Clazz.newPackage("jspecview.application"),p$1={},I$=[[0,'jspecview.common.ScriptToken','javax.swing.JPanel','java.awt.BorderLayout','javax.swing.JTabbedPane','javax.swing.JCheckBox','javax.swing.JButton','javax.swing.DefaultListModel','javax.swing.JLabel','java.awt.GridBagLayout','javax.swing.JComboBox','java.awt.GridLayout','javax.swing.JScrollPane','javax.swing.JList','javax.swing.JTextField','javax.swing.JRadioButton','javax.swing.ButtonGroup','jspecview.java.AwtParameters','java.awt.Dimension',['jspecview.application.PreferencesDialog','.ElementListSelectionListener'],'javax.swing.border.TitledBorder','javax.swing.BorderFactory','javax.swing.UIManager','java.awt.Color','java.awt.GridBagConstraints','java.awt.Insets','java.awt.Font','javax.swing.JSeparator','java.awt.GraphicsEnvironment','jspecview.source.JDXReader','jspecview.java.AwtPanel','javajs.util.CU','jspecview.java.AwtColor','javax.swing.JColorChooser','javax.swing.JOptionPane']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PreferencesDialog", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'javax.swing.JDialog', 'java.awt.event.ActionListener');
C$.$classes$=[['ElementListSelectionListener',0]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.contentpanel=Clazz.new_($I$(2,1));
this.contentBorderLayout=Clazz.new_($I$(3,1));
this.preferencesTabbedPane=Clazz.new_($I$(4,1));
this.generalPanel=Clazz.new_($I$(2,1));
this.displayPanel=Clazz.new_($I$(2,1));
this.confirmExitCheckBox=Clazz.new_($I$(5,1));
this.statusBarCheckBox=Clazz.new_($I$(5,1));
this.toolbarCheckBox=Clazz.new_($I$(5,1));
this.sidePanelCheckBox=Clazz.new_($I$(5,1));
this.exportDirCheckBox=Clazz.new_($I$(5,1));
this.openedDirCheckBox=Clazz.new_($I$(5,1));
this.legendCheckBox=Clazz.new_($I$(5,1));
this.overlayCheckBox=Clazz.new_($I$(5,1));
this.clearRecentButton=Clazz.new_($I$(6,1));
this.cancelButton=Clazz.new_($I$(6,1));
this.buttonPanel=Clazz.new_($I$(2,1));
this.okButton=Clazz.new_($I$(6,1));
this.borderLayout6=Clazz.new_($I$(3,1));
this.elModel=Clazz.new_($I$(7,1));
this.topPanel=Clazz.new_($I$(2,1));
this.displayFontPanel=Clazz.new_($I$(2,1));
this.colorSchemePanel=Clazz.new_($I$(2,1));
this.elementPanel=Clazz.new_($I$(2,1));
this.elementLabel=Clazz.new_($I$(8,1));
this.gridBagLayout1=Clazz.new_($I$(9,1));
this.defaultFontCheckBox=Clazz.new_($I$(5,1));
this.fontComboBox=Clazz.new_($I$(10,1));
this.gridBagLayout2=Clazz.new_($I$(9,1));
this.colorPanel=Clazz.new_($I$(2,1));
this.schemeComboBox=Clazz.new_($I$(10,1));
this.gridLayout1=Clazz.new_($I$(11,1));
this.defaultColorCheckBox=Clazz.new_($I$(5,1));
this.customButton=Clazz.new_($I$(6,1));
this.gridBagLayout3=Clazz.new_($I$(9,1));
this.listScrollPane=Clazz.new_($I$(12,1));
this.elementList=Clazz.new_($I$(13,1));
this.colorButton8=Clazz.new_($I$(6,1));
this.colorButton7=Clazz.new_($I$(6,1));
this.colorButton6=Clazz.new_($I$(6,1));
this.colorButton5=Clazz.new_($I$(6,1));
this.colorButton4=Clazz.new_($I$(6,1));
this.colorButton3=Clazz.new_($I$(6,1));
this.colorButton2=Clazz.new_($I$(6,1));
this.colorButton1=Clazz.new_($I$(6,1));
this.currentColorButton=Clazz.new_($I$(6,1));
this.processingPanel=Clazz.new_($I$(2,1));
this.gridBagLayout4=Clazz.new_($I$(9,1));
this.saveButton=Clazz.new_($I$(6,1));
this.gridBagLayout5=Clazz.new_($I$(9,1));
this.integrationPanel=Clazz.new_($I$(2,1));
this.absTransPanel=Clazz.new_($I$(2,1));
this.gridBagLayout6=Clazz.new_($I$(9,1));
this.jLabel1=Clazz.new_($I$(8,1));
this.minYTextField=Clazz.new_($I$(14,1));
this.jLabel2=Clazz.new_($I$(8,1));
this.integFactorTextField=Clazz.new_($I$(14,1));
this.jLabel3=Clazz.new_($I$(8,1));
this.jLabel4=Clazz.new_($I$(8,1));
this.processingCustomButton=Clazz.new_($I$(6,1));
this.autoIntegrateCheckBox=Clazz.new_($I$(5,1));
this.integOffsetTextField=Clazz.new_($I$(14,1));
this.separateWindowCheckBox=Clazz.new_($I$(5,1));
this.jLabel5=Clazz.new_($I$(8,1));
this.jLabel6=Clazz.new_($I$(8,1));
this.jLabel7=Clazz.new_($I$(8,1));
this.gridBagLayout7=Clazz.new_($I$(9,1));
this.TtoARadioButton=Clazz.new_($I$(15,1));
this.AtoTRadioButton=Clazz.new_($I$(15,1));
this.conversionButtonGroup=Clazz.new_($I$(16,1));
this.currentDS=Clazz.new_($I$(17,1)).setName$S("Current");
this.previewPanel=null;
this.defaultDSName="";
this.jLabel8=Clazz.new_($I$(8,1));
this.jLabel9=Clazz.new_($I$(8,1));
this.AutoConvertCheckBox=Clazz.new_($I$(5,1));
this.plotColorButton=Clazz.new_($I$(6,1));
this.colorPanel1=Clazz.new_($I$(2,1));
this.procColorButton8=Clazz.new_($I$(6,1));
this.procColorButton7=Clazz.new_($I$(6,1));
this.procColorButton6=Clazz.new_($I$(6,1));
this.procColorButton5=Clazz.new_($I$(6,1));
this.procColorButton4=Clazz.new_($I$(6,1));
this.procColorButton3=Clazz.new_($I$(6,1));
this.procColorButton2=Clazz.new_($I$(6,1));
this.gridLayout2=Clazz.new_($I$(11,1));
this.procColorButton1=Clazz.new_($I$(6,1));
this.gridCheckBox=Clazz.new_($I$(5,1));
this.coordinatesCheckBox=Clazz.new_($I$(5,1));
this.scaleXCheckBox=Clazz.new_($I$(5,1));
this.svgForInkscapeCheckBox=Clazz.new_($I$(5,1));
this.spectrumPanel=Clazz.new_($I$(2,1));
this.spectrumDisplayApplyNowCheckBox=Clazz.new_($I$(5,1).c$$S,["Apply to currently opened spectra"]);
this.isSpectrumDisplayApplyNowEnabled=false;
this.scaleYCheckBox=Clazz.new_($I$(5,1));
this.panel=Clazz.new_($I$(2,1));
this.deleteButton=Clazz.new_($I$(6,1).c$$S,["Delete Scheme"]);
},1);

C$.$fields$=[['Z',['isSpectrumDisplayApplyNowEnabled'],'S',['defaultDSName'],'O',['contentpanel','javax.swing.JPanel','contentBorderLayout','java.awt.BorderLayout','preferencesTabbedPane','javax.swing.JTabbedPane','generalPanel','javax.swing.JPanel','+displayPanel','fontTitledBorder','javax.swing.border.TitledBorder','+contentTitledBorder','confirmExitCheckBox','javax.swing.JCheckBox','+statusBarCheckBox','+toolbarCheckBox','+sidePanelCheckBox','+exportDirCheckBox','+openedDirCheckBox','+legendCheckBox','+overlayCheckBox','clearRecentButton','javax.swing.JButton','+cancelButton','buttonPanel','javax.swing.JPanel','okButton','javax.swing.JButton','borderLayout6','java.awt.BorderLayout','elModel','javax.swing.DefaultListModel','topPanel','javax.swing.JPanel','+displayFontPanel','+colorSchemePanel','+elementPanel','elementLabel','javax.swing.JLabel','gridBagLayout1','java.awt.GridBagLayout','defaultFontCheckBox','javax.swing.JCheckBox','fontComboBox','javax.swing.JComboBox','gridBagLayout2','java.awt.GridBagLayout','colorPanel','javax.swing.JPanel','schemeComboBox','javax.swing.JComboBox','gridLayout1','java.awt.GridLayout','defaultColorCheckBox','javax.swing.JCheckBox','customButton','javax.swing.JButton','gridBagLayout3','java.awt.GridBagLayout','listScrollPane','javax.swing.JScrollPane','elementList','javax.swing.JList','colorButton8','javax.swing.JButton','+colorButton7','+colorButton6','+colorButton5','+colorButton4','+colorButton3','+colorButton2','+colorButton1','+currentColorButton','processingPanel','javax.swing.JPanel','gridBagLayout4','java.awt.GridBagLayout','saveButton','javax.swing.JButton','gridBagLayout5','java.awt.GridBagLayout','integrationPanel','javax.swing.JPanel','+absTransPanel','gridBagLayout6','java.awt.GridBagLayout','integratinTitledBorder','javax.swing.border.TitledBorder','jLabel1','javax.swing.JLabel','minYTextField','javax.swing.JTextField','jLabel2','javax.swing.JLabel','integFactorTextField','javax.swing.JTextField','jLabel3','javax.swing.JLabel','+jLabel4','processingCustomButton','javax.swing.JButton','autoIntegrateCheckBox','javax.swing.JCheckBox','integOffsetTextField','javax.swing.JTextField','absTransTitledBorder','javax.swing.border.TitledBorder','separateWindowCheckBox','javax.swing.JCheckBox','jLabel5','javax.swing.JLabel','+jLabel6','+jLabel7','gridBagLayout7','java.awt.GridBagLayout','TtoARadioButton','javax.swing.JRadioButton','+AtoTRadioButton','conversionButtonGroup','javax.swing.ButtonGroup','currentDS','jspecview.common.ColorParameters','dsp','jspecview.application.DisplaySchemesProcessor','previewPanel','jspecview.java.AwtPanel','jLabel8','javax.swing.JLabel','+jLabel9','AutoConvertCheckBox','javax.swing.JCheckBox','plotColorButton','javax.swing.JButton','colorPanel1','javax.swing.JPanel','procColorButton8','javax.swing.JButton','+procColorButton7','+procColorButton6','+procColorButton5','+procColorButton4','+procColorButton3','+procColorButton2','gridLayout2','java.awt.GridLayout','procColorButton1','javax.swing.JButton','gridCheckBox','javax.swing.JCheckBox','+coordinatesCheckBox','+scaleXCheckBox','+svgForInkscapeCheckBox','applicationPanel','javax.swing.JPanel','+uiPanel','+spectrumPanel','spectrumDisplayApplyNowCheckBox','javax.swing.JCheckBox','preferences','java.util.Properties','scaleYCheckBox','javax.swing.JCheckBox','panel','javax.swing.JPanel','deleteButton','javax.swing.JButton']]]

Clazz.newMeth(C$, 'c$$java_awt_Frame$jspecview_common_JSViewer$S$Z$jspecview_application_DisplaySchemesProcessor',  function (frame, viewer, title, modal, dsp) {
;C$.superclazz.c$$java_awt_Frame$S$Z.apply(this,[frame, title, modal]);C$.$init$.apply(this);
this.setSize$java_awt_Dimension(Clazz.new_($I$(18,1).c$$I$I,[480, 571]));
this.setLocationRelativeTo$java_awt_Component(frame);
this.preferences=viewer.properties;
this.dsp=dsp;
this.elModel.addElement$O("Title");
this.elModel.addElement$O("Plot");
this.elModel.addElement$O("Scale");
this.elModel.addElement$O("Units");
this.elModel.addElement$O("Coordinates");
this.elModel.addElement$O("PlotArea");
this.elModel.addElement$O("Background");
this.elModel.addElement$O("Grid");
try {
this.jbInit$();
if (dsp != null ) {
p$1.initDisplayTab$jspecview_common_JSViewer.apply(this, [viewer]);
}} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
ex.printStackTrace$();
} else {
throw ex;
}
}
p$1.initProcessingTab.apply(this, []);
p$1.initGeneralTab.apply(this, []);
this.elementList.addListSelectionListener$javax_swing_event_ListSelectionListener(Clazz.new_($I$(19,1),[this, null]));
this.elementList.getSelectionModel$().setSelectionInterval$I$I(0, 0);
this.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$, 'jbInit$',  function () {
this.fontTitledBorder=Clazz.new_($I$(20,1).c$$S,[""]);
this.contentTitledBorder=Clazz.new_($I$(20,1).c$$S,[""]);
this.integratinTitledBorder=Clazz.new_($I$(20,1).c$$S,[""]);
this.absTransTitledBorder=Clazz.new_($I$(20,1).c$$S,[""]);
this.contentpanel.setLayout$java_awt_LayoutManager(this.contentBorderLayout);
this.fontTitledBorder.setTitle$S("Font");
this.fontTitledBorder.setTitleJustification$I(2);
this.contentTitledBorder.setTitle$S("Content");
this.contentTitledBorder.setTitleJustification$I(2);
this.gridCheckBox.setToolTipText$S("");
this.gridCheckBox.setText$S("Show grid");
this.coordinatesCheckBox.setText$S("Show coordinates");
this.scaleXCheckBox.setText$S("Show X scale");
this.svgForInkscapeCheckBox.setText$S("SVG export for Inkscape");
this.generalPanel.setBorder$javax_swing_border_Border($I$(21).createEtchedBorder$());
this.statusBarCheckBox.setText$S("Show status bar");
this.toolbarCheckBox.setText$S("Show toolbar");
this.exportDirCheckBox.setText$S("Remember directory of last exported file");
this.openedDirCheckBox.setText$S("Remember directory of last opened file");
this.legendCheckBox.setText$S("Automatically show legend when spectra are overlaid");
this.confirmExitCheckBox.setText$S("Confirm before exiting");
this.sidePanelCheckBox.setText$S("Show side panel");
this.applicationPanel=Clazz.new_($I$(2,1));
this.applicationPanel.setLayout$java_awt_LayoutManager(null);
this.applicationPanel.setBorder$javax_swing_border_Border(Clazz.new_([$I$(22).getBorder$O("TitledBorder.border"), "Application", 2, 2, null, $I$(23).BLACK],$I$(20,1).c$$javax_swing_border_Border$S$I$I$java_awt_Font$java_awt_Color));
this.applicationPanel.setBounds$I$I$I$I(12, 5, 437, 157);
this.generalPanel.add$java_awt_Component(this.applicationPanel);
this.uiPanel=Clazz.new_($I$(2,1));
this.uiPanel.setLayout$java_awt_LayoutManager(null);
this.uiPanel.setBorder$javax_swing_border_Border(Clazz.new_([$I$(22).getBorder$O("TitledBorder.border"), "User Interface", 2, 2, null, $I$(23).BLACK],$I$(20,1).c$$javax_swing_border_Border$S$I$I$java_awt_Font$java_awt_Color));
this.uiPanel.setBounds$I$I$I$I(12, 164, 437, 101);
this.generalPanel.add$java_awt_Component(this.uiPanel);
this.confirmExitCheckBox.setBounds$I$I$I$I(6, 19, 133, 23);
this.applicationPanel.add$java_awt_Component(this.confirmExitCheckBox);
this.openedDirCheckBox.setBounds$I$I$I$I(6, 45, 211, 23);
this.applicationPanel.add$java_awt_Component(this.openedDirCheckBox);
this.exportDirCheckBox.setBounds$I$I$I$I(6, 71, 219, 23);
this.applicationPanel.add$java_awt_Component(this.exportDirCheckBox);
this.svgForInkscapeCheckBox.setBounds$I$I$I$I(6, 97, 143, 23);
this.applicationPanel.add$java_awt_Component(this.svgForInkscapeCheckBox);
this.clearRecentButton.setBounds$I$I$I$I(6, 127, 119, 23);
this.applicationPanel.add$java_awt_Component(this.clearRecentButton);
this.clearRecentButton.setText$S("Clear Recent Files");
this.overlayCheckBox.setBounds$I$I$I$I(6, 150, 241, 23);
this.spectrumPanel.add$java_awt_Component(this.overlayCheckBox);
this.legendCheckBox.setBounds$I$I$I$I(6, 126, 291, 23);
this.spectrumPanel.add$java_awt_Component(this.legendCheckBox);
this.gridCheckBox.setBounds$I$I$I$I(6, 22, 73, 23);
this.spectrumPanel.add$java_awt_Component(this.gridCheckBox);
this.scaleXCheckBox.setBounds$I$I$I$I(6, 48, 97, 23);
this.spectrumPanel.add$java_awt_Component(this.scaleXCheckBox);
this.coordinatesCheckBox.setBounds$I$I$I$I(142, 22, 111, 23);
this.spectrumPanel.add$java_awt_Component(this.coordinatesCheckBox);
this.clearRecentButton.addActionListener$java_awt_event_ActionListener(((P$.PreferencesDialog$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "PreferencesDialog$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.PreferencesDialog'].clearRecentButton_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['jspecview.application.PreferencesDialog'], [e]);
});
})()
), Clazz.new_(P$.PreferencesDialog$1.$init$,[this, null])));
this.sidePanelCheckBox.setBounds$I$I$I$I(6, 21, 103, 23);
this.uiPanel.add$java_awt_Component(this.sidePanelCheckBox);
this.toolbarCheckBox.setBounds$I$I$I$I(6, 47, 89, 23);
this.uiPanel.add$java_awt_Component(this.toolbarCheckBox);
this.statusBarCheckBox.setBounds$I$I$I$I(6, 73, 114, 23);
this.uiPanel.add$java_awt_Component(this.statusBarCheckBox);
this.cancelButton.setText$S("Cancel");
this.cancelButton.addActionListener$java_awt_event_ActionListener(((P$.PreferencesDialog$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "PreferencesDialog$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.PreferencesDialog'].cancelButton_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['jspecview.application.PreferencesDialog'], [e]);
});
})()
), Clazz.new_(P$.PreferencesDialog$2.$init$,[this, null])));
this.okButton.setText$S("OK");
this.okButton.addActionListener$java_awt_event_ActionListener(((P$.PreferencesDialog$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "PreferencesDialog$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.PreferencesDialog'].okButton_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['jspecview.application.PreferencesDialog'], [e]);
});
})()
), Clazz.new_(P$.PreferencesDialog$3.$init$,[this, null])));
this.displayPanel.setLayout$java_awt_LayoutManager(this.borderLayout6);
this.gridBagLayout4.rowWeights=Clazz.array(Double.TYPE, -1, [0.0, 1.0]);
this.gridBagLayout4.columnWeights=Clazz.array(Double.TYPE, -1, [0.0, 0.0, 1.0]);
this.topPanel.setLayout$java_awt_LayoutManager(this.gridBagLayout4);
this.elementPanel.setBorder$javax_swing_border_Border($I$(21).createEtchedBorder$());
this.elementPanel.setLayout$java_awt_LayoutManager(this.gridBagLayout1);
this.colorSchemePanel.setBorder$javax_swing_border_Border($I$(21).createEtchedBorder$());
this.colorSchemePanel.setLayout$java_awt_LayoutManager(this.gridBagLayout3);
this.displayFontPanel.setBorder$javax_swing_border_Border($I$(21).createEtchedBorder$());
this.displayFontPanel.setLayout$java_awt_LayoutManager(this.gridBagLayout2);
this.elementLabel.setText$S("Element:");
this.defaultFontCheckBox.setText$S("Use Default");
this.defaultFontCheckBox.addActionListener$java_awt_event_ActionListener(((P$.PreferencesDialog$4||
(function(){/*a*/var C$=Clazz.newClass(P$, "PreferencesDialog$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.PreferencesDialog'].defaultFontCheckBox_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['jspecview.application.PreferencesDialog'], [e]);
});
})()
), Clazz.new_(P$.PreferencesDialog$4.$init$,[this, null])));
this.colorPanel.setLayout$java_awt_LayoutManager(this.gridLayout1);
this.schemeComboBox.setMaximumSize$java_awt_Dimension(Clazz.new_($I$(18,1).c$$I$I,[200, 21]));
this.schemeComboBox.addActionListener$java_awt_event_ActionListener(((P$.PreferencesDialog$5||
(function(){/*a*/var C$=Clazz.newClass(P$, "PreferencesDialog$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.PreferencesDialog'].schemeComboBox_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['jspecview.application.PreferencesDialog'], [e]);
});
})()
), Clazz.new_(P$.PreferencesDialog$5.$init$,[this, null])));
this.gridLayout1.setHgap$I(2);
this.gridLayout1.setRows$I(2);
this.gridLayout1.setVgap$I(2);
this.defaultColorCheckBox.setText$S("Use Default");
this.defaultColorCheckBox.addActionListener$java_awt_event_ActionListener(((P$.PreferencesDialog$6||
(function(){/*a*/var C$=Clazz.newClass(P$, "PreferencesDialog$6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.PreferencesDialog'].defaultColorCheckBox_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['jspecview.application.PreferencesDialog'], [e]);
});
})()
), Clazz.new_(P$.PreferencesDialog$6.$init$,[this, null])));
this.customButton.setText$S("Custom...");
this.customButton.addActionListener$java_awt_event_ActionListener(((P$.PreferencesDialog$7||
(function(){/*a*/var C$=Clazz.newClass(P$, "PreferencesDialog$7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.PreferencesDialog'].customButton_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['jspecview.application.PreferencesDialog'], [e]);
});
})()
), Clazz.new_(P$.PreferencesDialog$7.$init$,[this, null])));
this.elementList.setToolTipText$S("");
this.elementList.setModel$javax_swing_ListModel(this.elModel);
this.elementList.setSelectionMode$I(0);
this.elementList.setVisibleRowCount$I(4);
this.listScrollPane.setMinimumSize$java_awt_Dimension(Clazz.new_($I$(18,1).c$$I$I,[125, 110]));
this.listScrollPane.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(18,1).c$$I$I,[125, 110]));
p$1.addColorButton$javax_swing_JButton$java_awt_Color.apply(this, [this.colorButton1, $I$(23).black]);
p$1.addColorButton$javax_swing_JButton$java_awt_Color.apply(this, [this.colorButton2, $I$(23).white]);
p$1.addColorButton$javax_swing_JButton$java_awt_Color.apply(this, [this.colorButton3, $I$(23).gray]);
p$1.addColorButton$javax_swing_JButton$java_awt_Color.apply(this, [this.colorButton4, $I$(23).blue]);
p$1.addColorButton$javax_swing_JButton$java_awt_Color.apply(this, [this.colorButton5, $I$(23).red]);
p$1.addColorButton$javax_swing_JButton$java_awt_Color.apply(this, [this.colorButton6, Clazz.new_($I$(23,1).c$$I$I$I,[0, 0, 64])]);
p$1.addColorButton$javax_swing_JButton$java_awt_Color.apply(this, [this.colorButton7, Clazz.new_($I$(23,1).c$$I$I$I,[0, 92, 0])]);
p$1.addColorButton$javax_swing_JButton$java_awt_Color.apply(this, [this.colorButton8, $I$(23).magenta]);
this.colorButton3.setText$S(" ");
this.currentColorButton.setBorder$javax_swing_border_Border($I$(21).createLoweredBevelBorder$());
this.currentColorButton.setMaximumSize$java_awt_Dimension(Clazz.new_($I$(18,1).c$$I$I,[50, 11]));
this.currentColorButton.setMinimumSize$java_awt_Dimension(Clazz.new_($I$(18,1).c$$I$I,[50, 11]));
this.currentColorButton.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(18,1).c$$I$I,[50, 11]));
this.currentColorButton.setMnemonic$C("0");
this.processingPanel.setLayout$java_awt_LayoutManager(this.gridBagLayout5);
this.integrationPanel.setLayout$java_awt_LayoutManager(this.gridBagLayout6);
this.integrationPanel.setBorder$javax_swing_border_Border(this.integratinTitledBorder);
this.integratinTitledBorder.setTitle$S("Integration");
this.integratinTitledBorder.setTitleJustification$I(2);
this.jLabel1.setText$S("Integral Factor");
this.jLabel2.setText$S("Minimum Y");
this.jLabel3.setText$S("Integral Offset");
this.jLabel4.setText$S("Plot Color");
this.processingCustomButton.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(18,1).c$$I$I,[87, 21]));
this.processingCustomButton.setText$S("Custom...");
this.processingCustomButton.addActionListener$java_awt_event_ActionListener(((P$.PreferencesDialog$8||
(function(){/*a*/var C$=Clazz.newClass(P$, "PreferencesDialog$8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.PreferencesDialog'].processingCustomButton_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['jspecview.application.PreferencesDialog'], [e]);
});
})()
), Clazz.new_(P$.PreferencesDialog$8.$init$,[this, null])));
this.autoIntegrateCheckBox.setText$S("Automatically Integrate HNMR Spectra");
this.minYTextField.setMinimumSize$java_awt_Dimension(Clazz.new_($I$(18,1).c$$I$I,[40, 21]));
this.minYTextField.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(18,1).c$$I$I,[40, 21]));
this.integFactorTextField.setMinimumSize$java_awt_Dimension(Clazz.new_($I$(18,1).c$$I$I,[40, 21]));
this.integFactorTextField.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(18,1).c$$I$I,[40, 21]));
this.integOffsetTextField.setMinimumSize$java_awt_Dimension(Clazz.new_($I$(18,1).c$$I$I,[40, 21]));
this.integOffsetTextField.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(18,1).c$$I$I,[40, 21]));
this.absTransPanel.setBorder$javax_swing_border_Border(this.absTransTitledBorder);
this.absTransPanel.setLayout$java_awt_LayoutManager(this.gridBagLayout7);
this.absTransTitledBorder.setTitle$S("Absorbance/Transmittance");
this.absTransTitledBorder.setTitleJustification$I(2);
this.separateWindowCheckBox.setEnabled$Z(false);
this.separateWindowCheckBox.setText$S("Show converted Spectrum in a separate window");
this.jLabel5.setText$S("%");
this.jLabel6.setText$S("%");
this.jLabel7.setText$S("%");
this.TtoARadioButton.setSelected$Z(true);
this.TtoARadioButton.setText$S("Transmittance to Absorbance");
this.AtoTRadioButton.setText$S("Absorbance to Transmittance");
this.colorPanel.setBorder$javax_swing_border_Border($I$(21).createRaisedBevelBorder$());
this.jLabel8.setText$S("Color Scheme:");
this.jLabel9.setText$S("Font:");
this.fontComboBox.addActionListener$java_awt_event_ActionListener(((P$.PreferencesDialog$9||
(function(){/*a*/var C$=Clazz.newClass(P$, "PreferencesDialog$9", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.PreferencesDialog'].fontComboBox_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['jspecview.application.PreferencesDialog'], [e]);
});
})()
), Clazz.new_(P$.PreferencesDialog$9.$init$,[this, null])));
this.AutoConvertCheckBox.setToolTipText$S("");
this.AutoConvertCheckBox.setText$S("Automatically Convert");
this.plotColorButton.setBackground$java_awt_Color($I$(23).green);
this.plotColorButton.setBorder$javax_swing_border_Border(null);
this.plotColorButton.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(18,1).c$$I$I,[30, 21]));
this.colorPanel1.setBorder$javax_swing_border_Border($I$(21).createRaisedBevelBorder$());
this.colorPanel1.setLayout$java_awt_LayoutManager(this.gridLayout2);
p$1.addProcColorButton$javax_swing_JButton$java_awt_Color.apply(this, [this.procColorButton1, $I$(23).black]);
p$1.addProcColorButton$javax_swing_JButton$java_awt_Color.apply(this, [this.procColorButton2, $I$(23).white]);
p$1.addProcColorButton$javax_swing_JButton$java_awt_Color.apply(this, [this.procColorButton3, $I$(23).gray]);
p$1.addProcColorButton$javax_swing_JButton$java_awt_Color.apply(this, [this.procColorButton4, $I$(23).blue]);
p$1.addProcColorButton$javax_swing_JButton$java_awt_Color.apply(this, [this.procColorButton5, $I$(23).red]);
p$1.addProcColorButton$javax_swing_JButton$java_awt_Color.apply(this, [this.procColorButton6, Clazz.new_($I$(23,1).c$$I$I$I,[0, 0, 64])]);
p$1.addProcColorButton$javax_swing_JButton$java_awt_Color.apply(this, [this.procColorButton7, Clazz.new_($I$(23,1).c$$I$I$I,[0, 92, 0])]);
p$1.addProcColorButton$javax_swing_JButton$java_awt_Color.apply(this, [this.procColorButton8, $I$(23).magenta]);
this.gridLayout2.setHgap$I(2);
this.gridLayout2.setRows$I(2);
this.gridLayout2.setVgap$I(2);
this.displayFontPanel.add$java_awt_Component$O(this.fontComboBox, Clazz.new_([0, 1, 1, 1, 0.0, 0.0, 18, 2, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 5, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.displayFontPanel.add$java_awt_Component$O(this.defaultFontCheckBox, Clazz.new_([0, 2, 1, 1, 0.0, 1.0, 18, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[10, 5, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.displayFontPanel.add$java_awt_Component$O(this.jLabel9, Clazz.new_([0, 0, 1, 1, 0.0, 0.0, 18, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 5, 0, 0]), 0, 5],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.getContentPane$().add$java_awt_Component(this.contentpanel);
this.contentpanel.add$java_awt_Component$O(this.preferencesTabbedPane, "Center");
this.preferencesTabbedPane.add$java_awt_Component$O(this.generalPanel, "General");
this.preferencesTabbedPane.add$java_awt_Component$O(this.displayPanel, "Display Scheme");
this.displayPanel.add$java_awt_Component$O(this.topPanel, "North");
this.topPanel.add$java_awt_Component$O(this.elementPanel, Clazz.new_([0, 0, 1, 1, 1.0, 1.0, 10, 1, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 0, 5, 5]), 13, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.elementPanel.add$java_awt_Component$O(this.listScrollPane, Clazz.new_([0, 1, 1, 1, 0.0, 1.0, 11, 3, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 0, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.listScrollPane.setViewportView$java_awt_Component(this.elementList);
this.elementPanel.add$java_awt_Component$O(this.elementLabel, Clazz.new_([0, 0, 1, 1, 0.0, 0.0, 18, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 0, 5, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.colorSchemePanel.add$java_awt_Component$O(this.schemeComboBox, Clazz.new_([0, 1, 2, 1, 0.0, 0.0, 10, 2, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 5, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.colorSchemePanel.add$java_awt_Component$O(this.defaultColorCheckBox, Clazz.new_([0, 4, 1, 1, 0.0, 0.0, 17, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 5, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.colorSchemePanel.add$java_awt_Component$O(this.customButton, Clazz.new_([0, 3, 1, 1, 0.0, 0.0, 17, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 5, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.colorSchemePanel.add$java_awt_Component$O(this.colorPanel, Clazz.new_([0, 2, 2, 1, 1.0, 1.0, 10, 2, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 5, 0, 5]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.colorSchemePanel.add$java_awt_Component$O(this.currentColorButton, Clazz.new_([1, 3, 1, 1, 0.0, 0.0, 10, 3, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 0, 0, 0]), -16, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.colorSchemePanel.add$java_awt_Component$O(this.jLabel8, Clazz.new_([0, 0, 1, 1, 0.0, 0.0, 18, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 5, 0, 0]), 0, 5],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.topPanel.add$java_awt_Component$O(this.colorSchemePanel, Clazz.new_([1, 0, 1, 1, 1.0, 1.0, 10, 1, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 10, 5, 5]), 8, 17],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.topPanel.add$java_awt_Component$O(this.displayFontPanel, Clazz.new_([2, 0, 1, 1, 1.0, 1.0, 10, 1, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 10, 5, 1]), 8, 36],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.preferencesTabbedPane.add$java_awt_Component$O(this.processingPanel, "Processing");
this.processingPanel.add$java_awt_Component$O(this.integrationPanel, Clazz.new_([0, 0, 1, 1, 0.0, 0.0, 10, 1, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 0, 10, 0]), 0, 30],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.contentpanel.add$java_awt_Component$O(this.buttonPanel, "South");
this.buttonPanel.add$java_awt_Component$O(this.okButton, null);
this.buttonPanel.add$java_awt_Component$O(this.cancelButton, null);
this.generalPanel.setLayout$java_awt_LayoutManager(null);
this.spectrumPanel.setBorder$javax_swing_border_Border(Clazz.new_([$I$(22).getBorder$O("TitledBorder.border"), "Default Spectrum Display Settings", 2, 2, null, Clazz.new_($I$(23,1).c$$I$I$I,[0, 0, 0])],$I$(20,1).c$$javax_swing_border_Border$S$I$I$java_awt_Font$java_awt_Color));
this.spectrumPanel.setBounds$I$I$I$I(12, 266, 437, 184);
this.generalPanel.add$java_awt_Component(this.spectrumPanel);
this.spectrumPanel.setLayout$java_awt_LayoutManager(null);
this.overlayCheckBox.setText$S("Show compound files as overlaid if possible");
var lblTheFollowingProperties=Clazz.new_($I$(8,1).c$$S,["The spectrum display properties above will apply for new spectra"]);
lblTheFollowingProperties.setFont$java_awt_Font(Clazz.new_($I$(26,1).c$$S$I$I,["Tahoma", 2, 11]));
lblTheFollowingProperties.setForeground$java_awt_Color($I$(23).DARK_GRAY);
lblTheFollowingProperties.setBounds$I$I$I$I(6, 74, 389, 14);
this.spectrumPanel.add$java_awt_Component(lblTheFollowingProperties);
this.spectrumDisplayApplyNowCheckBox.setFont$java_awt_Font(Clazz.new_($I$(26,1).c$$S$I$I,["Tahoma", 2, 11]));
this.spectrumDisplayApplyNowCheckBox.setForeground$java_awt_Color($I$(23).DARK_GRAY);
this.spectrumDisplayApplyNowCheckBox.setBounds$I$I$I$I(6, 87, 220, 23);
this.spectrumPanel.add$java_awt_Component(this.spectrumDisplayApplyNowCheckBox);
this.scaleYCheckBox.setText$S("Show Y scale");
this.scaleYCheckBox.setSelected$Z(false);
this.scaleYCheckBox.setBounds$I$I$I$I(142, 48, 105, 23);
this.spectrumPanel.add$java_awt_Component(this.scaleYCheckBox);
var separator=Clazz.new_($I$(27,1));
separator.setBounds$I$I$I$I(6, 117, 421, 2);
this.spectrumPanel.add$java_awt_Component(separator);
var gbc_panel=Clazz.new_($I$(24,1));
gbc_panel.gridwidth=5;
gbc_panel.fill=1;
gbc_panel.gridx=0;
gbc_panel.gridy=1;
this.topPanel.add$java_awt_Component$O(this.panel, gbc_panel);
this.panel.add$java_awt_Component(this.saveButton);
this.saveButton.setText$S("Save Scheme");
this.deleteButton.addActionListener$java_awt_event_ActionListener(((P$.PreferencesDialog$10||
(function(){/*a*/var C$=Clazz.newClass(P$, "PreferencesDialog$10", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (arg0) {
this.b$['jspecview.application.PreferencesDialog'].deleteButton_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['jspecview.application.PreferencesDialog'], [arg0]);
});
})()
), Clazz.new_(P$.PreferencesDialog$10.$init$,[this, null])));
this.panel.add$java_awt_Component(this.deleteButton);
this.saveButton.addActionListener$java_awt_event_ActionListener(((P$.PreferencesDialog$11||
(function(){/*a*/var C$=Clazz.newClass(P$, "PreferencesDialog$11", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.PreferencesDialog'].saveButton_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['jspecview.application.PreferencesDialog'], [e]);
});
})()
), Clazz.new_(P$.PreferencesDialog$11.$init$,[this, null])));
this.processingPanel.add$java_awt_Component$O(this.absTransPanel, Clazz.new_([0, 1, 1, 1, 1.0, 1.0, 10, 1, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 0, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.integrationPanel.add$java_awt_Component$O(this.jLabel2, Clazz.new_([0, 0, 2, 1, 0.0, 0.0, 18, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 5, 10, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.integrationPanel.add$java_awt_Component$O(this.jLabel1, Clazz.new_([0, 1, 2, 1, 0.0, 0.0, 18, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 5, 10, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.integrationPanel.add$java_awt_Component$O(this.autoIntegrateCheckBox, Clazz.new_([0, 5, 4, 1, 0.0, 1.0, 18, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[10, 5, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.integrationPanel.add$java_awt_Component$O(this.minYTextField, Clazz.new_([1, 0, 1, 1, 0.0, 0.0, 18, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 50, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.integrationPanel.add$java_awt_Component$O(this.integFactorTextField, Clazz.new_([1, 1, 1, 1, 0.0, 0.0, 18, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 50, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.integrationPanel.add$java_awt_Component$O(this.jLabel3, Clazz.new_([0, 2, 1, 1, 0.0, 0.0, 18, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 5, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.integrationPanel.add$java_awt_Component$O(this.integOffsetTextField, Clazz.new_([1, 2, 1, 1, 0.0, 0.0, 18, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 50, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.integrationPanel.add$java_awt_Component$O(this.jLabel5, Clazz.new_([2, 0, 1, 1, 1.0, 0.0, 18, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 5, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.integrationPanel.add$java_awt_Component$O(this.jLabel6, Clazz.new_([2, 1, 1, 1, 0.0, 0.0, 18, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 5, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.integrationPanel.add$java_awt_Component$O(this.jLabel7, Clazz.new_([2, 2, 1, 2, 0.0, 0.0, 18, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 5, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.integrationPanel.add$java_awt_Component$O(this.colorPanel1, Clazz.new_([2, 3, 1, 1, 1.0, 0.0, 17, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[5, 5, 5, 5]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.integrationPanel.add$java_awt_Component$O(this.jLabel4, Clazz.new_([0, 3, 1, 1, 0.0, 0.0, 18, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[5, 5, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.integrationPanel.add$java_awt_Component$O(this.processingCustomButton, Clazz.new_([2, 4, 1, 1, 0.0, 0.0, 16, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 5, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.integrationPanel.add$java_awt_Component$O(this.plotColorButton, Clazz.new_([1, 3, 1, 1, 0.0, 0.0, 18, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[5, 50, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.absTransPanel.add$java_awt_Component$O(this.separateWindowCheckBox, Clazz.new_([0, 0, 1, 1, 1.0, 0.0, 17, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 5, 0, 0]), 147, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.absTransPanel.add$java_awt_Component$O(this.TtoARadioButton, Clazz.new_([0, 2, 1, 1, 0.0, 0.0, 17, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 20, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.absTransPanel.add$java_awt_Component$O(this.AtoTRadioButton, Clazz.new_([0, 3, 1, 1, 0.0, 0.0, 18, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 20, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.absTransPanel.add$java_awt_Component$O(this.AutoConvertCheckBox, Clazz.new_([0, 1, 1, 1, 0.0, 0.0, 18, 0, Clazz.new_($I$(25,1).c$$I$I$I$I,[0, 5, 0, 0]), 0, 0],$I$(24,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I));
this.conversionButtonGroup.add$javax_swing_AbstractButton(this.TtoARadioButton);
this.conversionButtonGroup.add$javax_swing_AbstractButton(this.AtoTRadioButton);
});

Clazz.newMeth(C$, 'addProcColorButton$javax_swing_JButton$java_awt_Color',  function (btn, c) {
this.colorPanel1.add$java_awt_Component$O(btn, null);
btn.setBackground$java_awt_Color(c);
btn.setBorder$javax_swing_border_Border($I$(21).createLoweredBevelBorder$());
btn.setName$S("pcb");
btn.addActionListener$java_awt_event_ActionListener(this);
btn.setText$S(" ");
btn.setMaximumSize$java_awt_Dimension(Clazz.new_($I$(18,1).c$$I$I,[20, 20]));
btn.setMinimumSize$java_awt_Dimension(Clazz.new_($I$(18,1).c$$I$I,[20, 20]));
btn.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(18,1).c$$I$I,[20, 20]));
}, p$1);

Clazz.newMeth(C$, 'addColorButton$javax_swing_JButton$java_awt_Color',  function (btn, c) {
this.colorPanel.add$java_awt_Component$O(btn, null);
btn.setBackground$java_awt_Color(c);
btn.setBorder$javax_swing_border_Border($I$(21).createLoweredBevelBorder$());
btn.setName$S("cb");
btn.addActionListener$java_awt_event_ActionListener(this);
}, p$1);

Clazz.newMeth(C$, 'initDisplayTab$jspecview_common_JSViewer',  function (viewer) {
var displaySchemes=this.dsp.getDisplaySchemes$();
this.defaultDSName=this.preferences.getProperty$S("defaultDisplaySchemeName");
for (var key, $key = displaySchemes.keySet$().iterator$(); $key.hasNext$()&&((key=($key.next$())),1);) this.schemeComboBox.addItem$O(key);

var ge=$I$(28).getLocalGraphicsEnvironment$();
var allFontNames=ge.getAvailableFontFamilyNames$();
for (var i=0; i < allFontNames.length; i++) this.fontComboBox.addItem$O(allFontNames[i]);

this.schemeComboBox.setSelectedItem$O(this.defaultDSName);
try {
var source=$I$(29,"createJDXSourceFromStream$java_io_InputStream$Z$Z$D",[this.getClass$().getResourceAsStream$S("resources/sample.jdx"), false, false, NaN]);
this.previewPanel=$I$(30,"getPanelOne$jspecview_common_JSViewer$jspecview_common_Spectrum",[viewer, source.getSpectra$().get$I(0)]);
this.previewPanel.getPanelData$().setBoolean$jspecview_common_ScriptToken$Z($I$(1).ENABLEZOOM, false);
this.previewPanel.getPanelData$().setBoolean$jspecview_common_ScriptToken$Z($I$(1).GRIDON, true);
this.previewPanel.getPanelData$().setBoolean$jspecview_common_ScriptToken$Z($I$(1).TITLEON, true);
this.previewPanel.getPanelData$().setBoolean$jspecview_common_ScriptToken$Z($I$(1).COORDINATESON, true);
} catch (e$$) {
if (Clazz.exceptionOf(e$$,"jspecview.exception.JSVException")){
var ex = e$$;
{
ex.printStackTrace$();
}
} else if (Clazz.exceptionOf(e$$,"Exception")){
var ioe = e$$;
{
ioe.printStackTrace$();
return;
}
} else {
throw e$$;
}
}
if (this.previewPanel != null ) this.displayPanel.add$java_awt_Component$O(this.previewPanel, "Center");
 else {
this.displayPanel.add$java_awt_Component$O(Clazz.new_($I$(6,1).c$$S,["Error Loading Sample File!"]), "Center");
}this.schemeComboBox.setSelectedItem$O(this.currentDS.name);
this.fontComboBox.setSelectedItem$O(this.currentDS.displayFontName);
this.repaint$();
}, p$1);

Clazz.newMeth(C$, 'initProcessingTab',  function () {
this.minYTextField.setText$S(this.preferences.getProperty$S("integralMinY"));
this.integFactorTextField.setText$S(this.preferences.getProperty$S("integralFactor"));
this.integOffsetTextField.setText$S(this.preferences.getProperty$S("integralOffset"));
this.plotColorButton.setBackground$java_awt_Color(Clazz.new_([$I$(31,"getArgbFromString$S",[this.preferences.getProperty$S("integralPlotColor")])],$I$(23,1).c$$I));
this.autoIntegrateCheckBox.setSelected$Z(Boolean.parseBoolean$S(this.preferences.getProperty$S("automaticallyIntegrate")));
var autoConvert=this.preferences.getProperty$S("automaticTAConversion");
if (autoConvert.equals$O("TtoA")) {
this.TtoARadioButton.setSelected$Z(true);
this.autoIntegrateCheckBox.setSelected$Z(true);
} else if (autoConvert.equals$O("AtoT")) {
this.AtoTRadioButton.setSelected$Z(true);
this.autoIntegrateCheckBox.setSelected$Z(true);
} else {
this.autoIntegrateCheckBox.setSelected$Z(false);
}this.separateWindowCheckBox.setSelected$Z(Boolean.parseBoolean$S(this.preferences.getProperty$S("AtoTSeparateWindow")));
}, p$1);

Clazz.newMeth(C$, 'initGeneralTab',  function () {
this.confirmExitCheckBox.setSelected$Z(Boolean.parseBoolean$S(this.preferences.getProperty$S("confirmBeforeExit")));
this.openedDirCheckBox.setSelected$Z(Boolean.parseBoolean$S(this.preferences.getProperty$S("useDirectoryLastOpenedFile")));
this.exportDirCheckBox.setSelected$Z(Boolean.parseBoolean$S(this.preferences.getProperty$S("useDirectoryLastExportedFile")));
this.svgForInkscapeCheckBox.setSelected$Z(Boolean.parseBoolean$S(this.preferences.getProperty$S("svgForInkscape")));
this.overlayCheckBox.setSelected$Z(Boolean.parseBoolean$S(this.preferences.getProperty$S("automaticallyOverlay")));
this.legendCheckBox.setSelected$Z(Boolean.parseBoolean$S(this.preferences.getProperty$S("automaticallyShowLegend")));
this.gridCheckBox.setSelected$Z(Boolean.parseBoolean$S(this.preferences.getProperty$S("showGrid")));
this.coordinatesCheckBox.setSelected$Z(Boolean.parseBoolean$S(this.preferences.getProperty$S("showCoordinates")));
this.scaleXCheckBox.setSelected$Z(Boolean.parseBoolean$S(this.preferences.getProperty$S("showXScale")));
this.scaleYCheckBox.setSelected$Z(Boolean.parseBoolean$S(this.preferences.getProperty$S("showYScale")));
this.sidePanelCheckBox.setSelected$Z(Boolean.parseBoolean$S(this.preferences.getProperty$S("showSidePanel")));
this.toolbarCheckBox.setSelected$Z(Boolean.parseBoolean$S(this.preferences.getProperty$S("showToolBar")));
this.statusBarCheckBox.setSelected$Z(Boolean.parseBoolean$S(this.preferences.getProperty$S("showStatusBar")));
}, p$1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (ae) {
var button=ae.getSource$();
var color=button.getBackground$();
if (button.getName$().equals$O("cb")) {
this.currentColorButton.setBackground$java_awt_Color(color);
var element=this.elementList.getSelectedValue$();
this.setCurrentColor$S$java_awt_Color(element, color);
this.currentDS.name="Current";
this.updatePreviewPanel$();
} else {
this.plotColorButton.setBackground$java_awt_Color(color);
}});

Clazz.newMeth(C$, 'cancelButton_actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.dispose$();
});

Clazz.newMeth(C$, 'setCurrentColor$S$java_awt_Color',  function (element, color) {
this.currentDS.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(1).getScriptToken$S(element + "COLOR"), Clazz.new_([color.getRGB$()],$I$(32,1).c$$I));
});

Clazz.newMeth(C$, 'okButton_actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.preferences.setProperty$S$S("confirmBeforeExit", Boolean.toString$Z(this.confirmExitCheckBox.isSelected$()));
this.preferences.setProperty$S$S("automaticallyOverlay", Boolean.toString$Z(this.overlayCheckBox.isSelected$()));
this.preferences.setProperty$S$S("automaticallyShowLegend", Boolean.toString$Z(this.legendCheckBox.isSelected$()));
this.preferences.setProperty$S$S("useDirectoryLastOpenedFile", Boolean.toString$Z(this.openedDirCheckBox.isSelected$()));
this.preferences.setProperty$S$S("useDirectoryLastExportedFile", Boolean.toString$Z(this.exportDirCheckBox.isSelected$()));
this.preferences.setProperty$S$S("showSidePanel", Boolean.toString$Z(this.sidePanelCheckBox.isSelected$()));
this.preferences.setProperty$S$S("showToolBar", Boolean.toString$Z(this.toolbarCheckBox.isSelected$()));
this.preferences.setProperty$S$S("showStatusBar", Boolean.toString$Z(this.statusBarCheckBox.isSelected$()));
this.preferences.setProperty$S$S("showGrid", Boolean.toString$Z(this.gridCheckBox.isSelected$()));
this.preferences.setProperty$S$S("showCoordinates", Boolean.toString$Z(this.coordinatesCheckBox.isSelected$()));
this.preferences.setProperty$S$S("showXScale", Boolean.toString$Z(this.scaleXCheckBox.isSelected$()));
this.preferences.setProperty$S$S("showYScale", Boolean.toString$Z(this.scaleYCheckBox.isSelected$()));
this.preferences.setProperty$S$S("svgForInkscape", Boolean.toString$Z(this.svgForInkscapeCheckBox.isSelected$()));
this.isSpectrumDisplayApplyNowEnabled=this.spectrumDisplayApplyNowCheckBox.isSelected$();
this.preferences.setProperty$S$S("automaticallyIntegrate", Boolean.toString$Z(this.autoIntegrateCheckBox.isSelected$()));
var autoTACovert=this.AutoConvertCheckBox.isSelected$();
if (autoTACovert) {
if (this.TtoARadioButton.isSelected$()) this.preferences.setProperty$S$S("automaticTAConversion", "TtoA");
 else this.preferences.setProperty$S$S("automaticTAConversion", "AtoT");
} else {
this.preferences.setProperty$S$S("automaticTAConversion", "false");
}this.preferences.setProperty$S$S("AtoTSeparateWindow", Boolean.toString$Z(this.separateWindowCheckBox.isSelected$()));
this.preferences.setProperty$S$S("integralMinY", this.minYTextField.getText$());
this.preferences.setProperty$S$S("integralFactor", this.integFactorTextField.getText$());
this.preferences.setProperty$S$S("integralOffset", this.integOffsetTextField.getText$());
this.preferences.setProperty$S$S("integralPlotColor", $I$(31,"toRGBHexString$javajs_api_GenericColor",[Clazz.new_([this.plotColorButton.getBackground$().getRGB$()],$I$(32,1).c$$I)]));
this.preferences.setProperty$S$S("defaultDisplaySchemeName", this.currentDS.name);
if (this.currentDS.name.equals$O("Current")) {
var dispSchemes=this.dsp.getDisplaySchemes$();
dispSchemes.put$O$O("Current", this.currentDS);
}this.dispose$();
});

Clazz.newMeth(C$, 'getPreferences$',  function () {
return this.preferences;
});

Clazz.newMeth(C$, 'customButton_actionPerformed$java_awt_event_ActionEvent',  function (e) {
var color=$I$(33,"showDialog$java_awt_Component$S$java_awt_Color",[this, "Choose Color", $I$(23).BLACK]);
if (color != null ) {
this.currentColorButton.setBackground$java_awt_Color(color);
this.setCurrentColor$S$java_awt_Color(this.elementList.getSelectedValue$(), color);
this.currentDS.name="Current";
this.updatePreviewPanel$();
}});

Clazz.newMeth(C$, 'deleteButton_actionPerformed$java_awt_event_ActionEvent',  function (e) {
var option=$I$(34).showConfirmDialog$java_awt_Component$O$S$I$I(this, "Do you really want to delete '" + this.currentDS.name + "'? This cannot be undone." , "Delete Scheme", 0, 2);
if (option == 0) {
var dispSchemes=this.dsp.getDisplaySchemes$();
dispSchemes.remove$O(this.currentDS.name);
var selectedIndex=this.schemeComboBox.getSelectedIndex$();
this.schemeComboBox.removeItemAt$I(selectedIndex);
try {
this.dsp.store$();
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
$I$(34).showMessageDialog$java_awt_Component$O$S$I(this, "There was an error deleting the Display Scheme", "Error Deleting Scheme", 0);
} else {
throw ex;
}
}
}});

Clazz.newMeth(C$, 'saveButton_actionPerformed$java_awt_event_ActionEvent',  function (e) {
var input="";
while (input != null  && input.equals$O("") )input=$I$(34).showInputDialog$java_awt_Component$O$S$I(this, "Enter the Name of the Display Scheme", "Display Scheme Name", -1);

if (input == null ) return;
this.currentDS.name=input;
var isdefault=this.defaultFontCheckBox.isSelected$();
if (!isdefault) {
var fontName=this.fontComboBox.getSelectedItem$();
this.currentDS.displayFontName=fontName;
}var dispSchemes=this.dsp.getDisplaySchemes$();
dispSchemes.put$O$O(input, this.currentDS);
try {
this.dsp.store$();
var found=false;
for (var i=0; i < this.schemeComboBox.getItemCount$(); i++) {
var item=this.schemeComboBox.getItemAt$I(i);
if (item.equals$O(input)) {
found=true;
break;
}}
if (!found) this.schemeComboBox.addItem$O(input);
this.schemeComboBox.setSelectedItem$O(input);
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
$I$(34).showMessageDialog$java_awt_Component$O$S$I(this, "There was an error saving the Display Scheme", "Error Saving Scheme", 0);
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'schemeComboBox_actionPerformed$java_awt_event_ActionEvent',  function (e) {
var schemeCB=e.getSource$();
var schemeName=schemeCB.getSelectedItem$();
var ds=null;
var schemes=this.dsp.getDisplaySchemes$();
for (var entry, $entry = schemes.entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) {
ds=entry.getValue$();
if (ds.name.equals$O(schemeName)) {
this.currentDS=ds.copy$();
break;
}}
this.elementList.getSelectionModel$().setSelectionInterval$I$I(0, 0);
var fontName=this.currentDS.displayFontName;
this.fontComboBox.setSelectedItem$O(fontName);
this.currentDS.name=ds.name;
this.updatePreviewPanel$();
});

Clazz.newMeth(C$, 'updatePreviewPanel$',  function () {
if (this.previewPanel != null ) {
this.previewPanel.setColorOrFont$jspecview_common_ColorParameters$jspecview_common_ScriptToken(this.currentDS, null);
this.repaint$();
}});

Clazz.newMeth(C$, 'fontComboBox_actionPerformed$java_awt_event_ActionEvent',  function (e) {
var fontName=(e.getSource$()).getSelectedItem$();
this.currentDS.displayFontName=fontName;
this.currentDS.name="Current";
this.updatePreviewPanel$();
});

Clazz.newMeth(C$, 'defaultFontCheckBox_actionPerformed$java_awt_event_ActionEvent',  function (e) {
var cb=e.getSource$();
if (cb.isSelected$()) {
this.fontComboBox.setSelectedItem$O("Default");
this.fontComboBox.setEnabled$Z(false);
this.currentDS.displayFontName="Default";
this.currentDS.name="Current";
this.updatePreviewPanel$();
} else {
this.fontComboBox.setEnabled$Z(true);
}});

Clazz.newMeth(C$, 'defaultColorCheckBox_actionPerformed$java_awt_event_ActionEvent',  function (e) {
var cb=e.getSource$();
if (cb.isSelected$()) {
this.schemeComboBox.setSelectedItem$O("Default");
this.schemeComboBox.setEnabled$Z(false);
this.customButton.setEnabled$Z(false);
this.saveButton.setEnabled$Z(false);
this.colorButton1.setEnabled$Z(false);
this.colorButton2.setEnabled$Z(false);
this.colorButton3.setEnabled$Z(false);
this.colorButton4.setEnabled$Z(false);
this.colorButton5.setEnabled$Z(false);
this.colorButton6.setEnabled$Z(false);
this.colorButton7.setEnabled$Z(false);
this.colorButton8.setEnabled$Z(false);
this.updatePreviewPanel$();
} else {
this.schemeComboBox.setEnabled$Z(true);
this.colorPanel.setEnabled$Z(true);
this.customButton.setEnabled$Z(true);
this.saveButton.setEnabled$Z(true);
this.colorButton1.setEnabled$Z(true);
this.colorButton2.setEnabled$Z(true);
this.colorButton3.setEnabled$Z(true);
this.colorButton4.setEnabled$Z(true);
this.colorButton5.setEnabled$Z(true);
this.colorButton6.setEnabled$Z(true);
this.colorButton7.setEnabled$Z(true);
this.colorButton8.setEnabled$Z(true);
}});

Clazz.newMeth(C$, 'getSelectedDisplayScheme$',  function () {
return this.currentDS;
});

Clazz.newMeth(C$, 'clearRecentButton_actionPerformed$java_awt_event_ActionEvent',  function (e) {
var option=$I$(34).showConfirmDialog$java_awt_Component$O$S$I$I(this, "Recent File Paths will be cleared!", "Warning", 2, 2);
if (option == 0) this.preferences.setProperty$S$S("recentFilePaths", "");
});

Clazz.newMeth(C$, 'processingCustomButton_actionPerformed$java_awt_event_ActionEvent',  function (e) {
var color=$I$(33,"showDialog$java_awt_Component$S$java_awt_Color",[this, "Choose Color", $I$(23).BLACK]);
if (color != null ) this.plotColorButton.setBackground$java_awt_Color(color);
});

Clazz.newMeth(C$, 'shouldApplySpectrumDisplaySettingsNow$',  function () {
return this.isSpectrumDisplayApplyNowEnabled;
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.PreferencesDialog, "ElementListSelectionListener", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'javax.swing.event.ListSelectionListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'valueChanged$javax_swing_event_ListSelectionEvent',  function (lse) {
this.b$['jspecview.application.PreferencesDialog'].currentColorButton.setBackground$java_awt_Color(this.b$['jspecview.application.PreferencesDialog'].currentDS.getElementColor$jspecview_common_ScriptToken($I$(1,"getScriptToken$S",[(lse.getSource$()).getSelectedValue$()])));
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:56 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
