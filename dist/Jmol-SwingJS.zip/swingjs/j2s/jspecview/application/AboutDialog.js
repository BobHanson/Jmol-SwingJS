(function(){var P$=Clazz.newPackage("jspecview.application"),p$1={},I$=[[0,'javax.swing.JPanel','javax.swing.JLabel','javax.swing.ImageIcon','javax.swing.border.BevelBorder','javax.swing.border.EmptyBorder','javax.swing.border.CompoundBorder','javax.swing.BoxLayout','jspecview.common.JSVersion','javax.swing.JButton','javax.swing.JTextArea','java.awt.Font']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AboutDialog", null, 'javax.swing.JDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.p=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['O',['p','javax.swing.JPanel','txt','javax.swing.JTextArea']]]

Clazz.newMeth(C$, 'c$$java_awt_Frame$S$Z',  function (owner, title, modal) {
;C$.superclazz.c$$java_awt_Frame$S$Z.apply(this,[owner, title, modal]);C$.$init$.apply(this);
try {
p$1.jbInit.apply(this, []);
this.setTitle$S("About JSpecView");
this.pack$();
this.setResizable$Z(false);
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
ex.printStackTrace$();
} else {
throw ex;
}
}
if (owner != null ) this.setLocation$I$I(((owner.getLocation$().x + owner.getSize$().width)/2|0), ((owner.getLocation$().y + owner.getSize$().height)/2|0));
this.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Frame',  function (frame) {
C$.c$$java_awt_Frame$S$Z.apply(this, [frame, "", true]);
}, 1);

Clazz.newMeth(C$, 'jbInit',  function () {
var lbl=Clazz.new_([Clazz.new_([this.getClass$().getResource$S("icons/about.gif")],$I$(3,1).c$$java_net_URL)],$I$(2,1).c$$javax_swing_Icon);
var b1=Clazz.new_($I$(4,1).c$$I,[1]);
var b2=Clazz.new_($I$(5,1).c$$I$I$I$I,[5, 5, 5, 5]);
lbl.setBorder$javax_swing_border_Border(Clazz.new_($I$(6,1).c$$javax_swing_border_Border$javax_swing_border_Border,[b1, b2]));
this.p.add$java_awt_Component(lbl);
this.getContentPane$().add$java_awt_Component$O(this.p, "West");
this.p=Clazz.new_($I$(1,1));
this.p.setLayout$java_awt_LayoutManager(Clazz.new_($I$(7,1).c$$java_awt_Container$I,[this.p, 1]));
var message="JSpecView Application\n" + "Version " + $I$(8).VERSION ;
this.txt=p$1.drawMessage$S$S$I$I.apply(this, [message, "Helvetica", 1, 12]);
this.p.add$java_awt_Component(this.txt);
message="Distributed under the GNU Lesser Public License\n";
message+="via sourceforge at http://jspecview.sf.net";
this.txt=p$1.drawMessage$S$S$I$I.apply(this, [message, "Arial", 0, 12]);
this.p.add$java_awt_Component(this.txt);
message="Authors:\nProf. Robert M. Hanson,\nD. Facey, K. Bryan, C. Walters, Prof. Robert J. Lancashire and\nvolunteer developers through sourceforge.";
this.txt=p$1.drawMessage$S$S$I$I.apply(this, [message, "Arial", 1, 12]);
this.p.add$java_awt_Component(this.txt);
message="Copyright (c) 2002-2017, Department of Chemistry\nUniversity of the West Indies, Mona Campus\nJAMAICA";
this.txt=p$1.drawMessage$S$S$I$I.apply(this, [message, "Arial", 0, 12]);
this.p.add$java_awt_Component(this.txt);
this.getContentPane$().add$java_awt_Component$O(this.p, "Center");
var okButton=Clazz.new_($I$(9,1).c$$S,["OK"]);
okButton.addActionListener$java_awt_event_ActionListener(((P$.AboutDialog$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "AboutDialog$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['java.awt.Dialog'].setVisible$Z.apply(this.b$['java.awt.Dialog'], [false]);
});
})()
), Clazz.new_(P$.AboutDialog$1.$init$,[this, null])));
this.p=Clazz.new_($I$(1,1));
this.p.add$java_awt_Component(okButton);
this.getContentPane$().add$java_awt_Component$O(this.p, "South");
}, p$1);

Clazz.newMeth(C$, 'drawMessage$S$S$I$I',  function (message, fontType, fontStyle, fontSize) {
var text=Clazz.new_($I$(10,1).c$$S,[message]);
text.setBorder$javax_swing_border_Border(Clazz.new_($I$(5,1).c$$I$I$I$I,[5, 10, 5, 10]));
text.setFont$java_awt_Font(Clazz.new_($I$(11,1).c$$S$I$I,[fontType, fontStyle, fontSize]));
text.setEditable$Z(false);
text.setBackground$java_awt_Color(this.getBackground$());
return text;
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:51 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
