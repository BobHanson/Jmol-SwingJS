(function(){var P$=Clazz.newPackage("jspecview.application"),I$=[[0,'jspecview.application.AwtTreeNode','javax.swing.tree.DefaultTreeModel','jspecview.common.PanelNode','jspecview.common.JSVFileManager','javax.swing.tree.TreePath','jspecview.application.AwtTreePath']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AwtTree", null, 'javax.swing.JTree', 'jspecview.api.JSVTree');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['si','jspecview.api.ScriptInterface','rootNode','jspecview.api.JSVTreeNode','spectraTreeModel','javax.swing.tree.DefaultTreeModel','vwr','jspecview.common.JSViewer']]]

Clazz.newMeth(C$, 'getRootNode$',  function () {
return this.rootNode;
});

Clazz.newMeth(C$, 'c$$jspecview_common_JSViewer',  function (viewer) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
var v=this.vwr=viewer;
this.rootNode=Clazz.new_($I$(1,1).c$$S$jspecview_common_PanelNode,["Spectra", null]);
this.spectraTreeModel=Clazz.new_($I$(2,1).c$$javax_swing_tree_TreeNode,[this.rootNode]);
this.setModel$javax_swing_tree_TreeModel(this.spectraTreeModel);
this.getSelectionModel$().setSelectionMode$I(1);
this.addTreeSelectionListener$javax_swing_event_TreeSelectionListener(((P$.AwtTree$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "AwtTree$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'javax.swing.event.TreeSelectionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'valueChanged$javax_swing_event_TreeSelectionEvent',  function (e) {
this.$finals$.v.selectedTreeNode$jspecview_api_JSVTreeNode(this.b$['javax.swing.JTree'].getLastSelectedPathComponent$.apply(this.b$['javax.swing.JTree'], []));
});
})()
), Clazz.new_(P$.AwtTree$1.$init$,[this, {v:v}])));
this.setRootVisible$Z(false);
}, 1);

Clazz.newMeth(C$, 'setSelectedPanel$jspecview_api_ScriptInterface$jspecview_api_JSVPanel',  function (si, jsvp) {
if (jsvp != null ) {
var treeNode=$I$(3).findNode$jspecview_api_JSVPanel$javajs_util_Lst(jsvp, this.vwr.panelNodes).treeNode;
this.scrollPathToVisible$javax_swing_tree_TreePath(this.vwr.spectraTree.newTreePath$OA(treeNode.getPath$()));
this.setSelectionPath$javax_swing_tree_TreePath(this.vwr.spectraTree.newTreePath$OA(treeNode.getPath$()));
}});

Clazz.newMeth(C$, 'createTree$I$jspecview_source_JDXSource$jspecview_api_JSVPanelA',  function (fileCount, source, panels) {
var tree=this.vwr.spectraTree;
var rootNode=tree.getRootNode$();
var panelNodes=this.vwr.panelNodes;
var fileName=$I$(4,"getTagName$S",[source.getFilePath$()]);
var panelNode=Clazz.new_($I$(3,1).c$$S$S$jspecview_source_JDXSource$jspecview_api_JSVPanel,[null, fileName, source, null]);
var fileNode=Clazz.new_($I$(1,1).c$$S$jspecview_common_PanelNode,[fileName, panelNode]);
panelNode.setTreeNode$jspecview_api_JSVTreeNode(fileNode);
tree.spectraTreeModel.insertNodeInto$javax_swing_tree_MutableTreeNode$javax_swing_tree_MutableTreeNode$I(fileNode, rootNode, rootNode.getChildCount$());
tree.scrollPathToVisible$javax_swing_tree_TreePath(Clazz.new_([fileNode.getPath$()],$I$(5,1).c$$OA));
for (var i=0; i < panels.length; i++) {
var jsvp=panels[i];
var id=fileCount + "." + (i + 1) ;
panelNode=Clazz.new_($I$(3,1).c$$S$S$jspecview_source_JDXSource$jspecview_api_JSVPanel,[id, fileName, source, jsvp]);
var treeNode=Clazz.new_([panelNode.toString(), panelNode],$I$(1,1).c$$S$jspecview_common_PanelNode);
panelNode.setTreeNode$jspecview_api_JSVTreeNode(treeNode);
panelNodes.addLast$O(panelNode);
tree.spectraTreeModel.insertNodeInto$javax_swing_tree_MutableTreeNode$javax_swing_tree_MutableTreeNode$I(treeNode, fileNode, fileNode.getChildCount$());
tree.scrollPathToVisible$javax_swing_tree_TreePath(Clazz.new_([treeNode.getPath$()],$I$(5,1).c$$OA));
}
this.vwr.selectFrameNode$jspecview_api_JSVPanel(panels[0]);
return fileNode;
});

Clazz.newMeth(C$, 'setPath$jspecview_api_JSVTreePath',  function (path) {
this.setSelectionPath$javax_swing_tree_TreePath(path);
});

Clazz.newMeth(C$, 'newTreePath$OA',  function (path) {
return Clazz.new_($I$(6,1).c$$OA,[path]);
});

Clazz.newMeth(C$, 'deleteNodes$javajs_util_Lst',  function (toDelete) {
for (var i=0; i < toDelete.size$(); i++) {
this.spectraTreeModel.removeNodeFromParent$javax_swing_tree_MutableTreeNode(toDelete.get$I(i));
}
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:51 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
