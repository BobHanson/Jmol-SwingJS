(function(){var P$=Clazz.newPackage("jspecview.application"),p$1={},I$=[[0,'java.awt.Font','javax.swing.JTextField','java.awt.BorderLayout','javax.swing.JSplitPane','javax.swing.JPanel','java.awt.Dimension','javajs.util.Lst','javax.swing.JLabel','jspecview.application.JSpecView','java.awt.dnd.DropTarget','java.awt.Toolkit','jspecview.application.AwtTree',['jspecview.application.MainFrame','.SpectraTreeCellRenderer'],'java.awt.event.WindowAdapter','java.util.StringTokenizer','jspecview.application.AppToolBar','jspecview.application.ApplicationMenu','javax.swing.BorderFactory','java.awt.Cursor','jspecview.application.CommandHistory','javax.swing.JScrollPane','java.awt.Color','javax.swing.JOptionPane','jspecview.application.PreferencesDialog','jspecview.export.Exporter','jspecview.common.ScriptToken','jspecview.common.JSVFileManager','javajs.util.SB']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MainFrame", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'javax.swing.JFrame', ['org.jmol.api.JmolSyncInterface', 'jspecview.api.PanelListener', 'jspecview.api.JSVAppInterface']);
C$.$classes$=[['SpectraTreeCellRenderer',2]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.commandInput=Clazz.new_($I$(2,1));
this.mainborderLayout=Clazz.new_($I$(3,1));
this.mainSplitPane=Clazz.new_($I$(4,1));
this.nullPanel=Clazz.new_($I$(5,1));
this.sideSplitPane=Clazz.new_($I$(4,1));
this.jmolDimensionNew=Clazz.new_($I$(6,1).c$$I$I,[350, 300]);
this.recentFilePaths=Clazz.new_($I$(7,1));
this.statusPanel=Clazz.new_($I$(5,1));
this.statusLabel=Clazz.new_($I$(8,1));
this.mainSplitPosition=200;
},1);

C$.$fields$=[['Z',['sidePanelOn','showExitDialog','statusbarOn','toolbarOn','isEmbedded','isHidden','isAwake'],'I',['mainSplitPosition','splitPosition','jmolFrameHeight','jmolFrameWidth'],'S',['tempDS'],'O',['vwr','jspecview.common.JSViewer','appMenu','jspecview.application.ApplicationMenu','toolBar','jspecview.application.AppToolBar','commandInput','javax.swing.JTextField','mainborderLayout','java.awt.BorderLayout','mainSplitPane','javax.swing.JSplitPane','nullPanel','javax.swing.JPanel','sideSplitPane','javax.swing.JSplitPane','advancedApplet','jspecview.app.JSVAppPro','commandHistory','jspecview.application.CommandHistory','dsp','jspecview.application.DisplaySchemesProcessor','jmolDisplay','java.awt.Component','jmolDimensionOld','java.awt.Dimension','jmolPanel','javax.swing.JPanel','jmolDimensionNew','java.awt.Dimension','jmolOrAdvancedApplet','org.jmol.api.JSVInterface','recentFilePaths','javajs.util.Lst','spectraTreeScrollPane','javax.swing.JScrollPane','mainPanel','java.awt.Component','statusPanel','javax.swing.JPanel','statusLabel','javax.swing.JLabel','tree','jspecview.application.AwtTree','jsv','jspecview.application.JSpecView']]]

Clazz.newMeth(C$, 'main$SA',  function (args) {
$I$(9).main$SA(args);
}, 1);

Clazz.newMeth(C$, 'isPro$',  function () {
return true;
});

Clazz.newMeth(C$, 'isSigned$',  function () {
return true;
});

Clazz.newMeth(C$, 'c$$jspecview_application_JSpecView$java_awt_Component$org_jmol_api_JSVInterface',  function (jsv, jmolDisplay, jmolOrAdvancedApplet) {
Clazz.super_(C$, this);
this.jsv=jsv;
this.vwr=jsv.vwr;
this.jmolDisplay=jmolDisplay;
if (jmolDisplay != null ) {
this.jmolPanel=jmolDisplay.getParent$();
}this.jmolOrAdvancedApplet=jmolOrAdvancedApplet;
this.advancedApplet=(Clazz.instanceOf(jmolOrAdvancedApplet, "jspecview.app.JSVAppPro") ? jmolOrAdvancedApplet : null);
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'exitJSpecView$Z',  function (withDialog) {
this.jmolOrAdvancedApplet.saveProperties$java_util_Properties(this.vwr.properties);
this.awaken$Z(false);
this.dsp.getDisplaySchemes$().remove$O("Current");
this.jmolOrAdvancedApplet.exitJSpecView$Z$O(withDialog && this.showExitDialog , this);
});

Clazz.newMeth(C$, 'awaken$Z',  function (visible) {
if (!this.isEmbedded) return;
System.out.println$S("MAINFRAME visible/awake" + visible + " " + this.isAwake + " " + this.jmolDisplay );
if (this.isAwake == visible ) return;
this.isAwake=visible;
if (this.jmolDisplay != null ) try {
var top=this.jmolPanel.getTopLevelAncestor$();
if (visible) {
this.jmolDimensionOld=Clazz.new_($I$(6,1).c$$I$I,[0, 0]);
this.jmolDisplay.getSize$java_awt_Dimension(this.jmolDimensionOld);
this.jmolDisplay.setSize$java_awt_Dimension(this.jmolDimensionNew);
this.jmolPanel.remove$java_awt_Component(this.jmolDisplay);
if (top.getHeight$() > 130) {
this.jmolFrameHeight=top.getHeight$();
this.jmolFrameWidth=top.getWidth$();
top.setSize$I$I(this.jmolFrameWidth, 130);
}this.jmolPanel.add$java_awt_Component(this.nullPanel);
this.sideSplitPane.setBottomComponent$java_awt_Component(this.jmolDisplay);
this.sideSplitPane.setDividerLocation$I(this.splitPosition);
this.sideSplitPane.validate$();
this.jmolPanel.validate$();
System.out.println$S("awakened");
} else {
this.sideSplitPane.setBottomComponent$java_awt_Component(this.nullPanel);
this.splitPosition=this.sideSplitPane.getDividerLocation$();
this.jmolPanel.add$java_awt_Component(this.jmolDisplay);
if (top.getHeight$() <= 130) {
top.setSize$I$I(this.jmolFrameWidth, this.jmolFrameHeight);
}this.jmolDisplay.getSize$java_awt_Dimension(this.jmolDimensionNew);
this.jmolDisplay.setSize$java_awt_Dimension(this.jmolDimensionOld);
this.sideSplitPane.validate$();
this.jmolPanel.validate$();
System.out.println$S("sleeping");
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
this.setVisible$Z(visible);
});

Clazz.newMeth(C$, 'init',  function () {
var dtl=this.vwr.getPlatformInterface$S("FileDropper");
(dtl).set$jspecview_common_JSViewer(this.vwr);
Clazz.new_($I$(10,1).c$$java_awt_Component$java_awt_dnd_DropTargetListener,[this, dtl]);
var cl=this.getClass$();
var iconURL=cl.getResource$S("icons/spec16.gif");
this.setIconImage$java_awt_Image($I$(11).getDefaultToolkit$().getImage$java_net_URL(iconURL));
this.dsp=this.jsv.getDisplaySchemesProcessor$org_jmol_api_JSVInterface(this.jmolOrAdvancedApplet);
if (!this.dsp.load$S("displaySchemes.xml")) {
if (!this.dsp.load$java_io_InputStream(this.getClass$().getResourceAsStream$S("resources/displaySchemes.xml"))) {
this.writeStatus$S("Problem loading Display Scheme");
}}p$1.setApplicationProperties$Z.apply(this, [true]);
this.tempDS=this.jsv.defaultDisplaySchemeName;
this.vwr.spectraTree=this.tree=Clazz.new_($I$(12,1).c$$jspecview_common_JSViewer,[this.vwr]);
this.tree.setCellRenderer$javax_swing_tree_TreeCellRenderer(Clazz.new_($I$(13,1),[this, null]));
this.tree.putClientProperty$O$O("JTree.lineStyle", "Angled");
this.tree.setShowsRootHandles$Z(true);
this.tree.setEditable$Z(false);
this.tree.addMouseListener$java_awt_event_MouseListener(((P$.MainFrame$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "MainFrame$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.MouseListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'mouseClicked$java_awt_event_MouseEvent',  function (e) {
if (e.getClickCount$() == 2 && this.b$['jspecview.application.MainFrame'].vwr.selectedPanel != null  ) {
this.b$['jspecview.application.MainFrame'].vwr.selectedPanel.getPanelData$().setZoom$D$D$D$D(0, 0, 0, 0);
this.b$['java.awt.Component'].repaint$.apply(this.b$['java.awt.Component'], []);
}});

Clazz.newMeth(C$, 'mouseEntered$java_awt_event_MouseEvent',  function (e) {
});

Clazz.newMeth(C$, 'mouseExited$java_awt_event_MouseEvent',  function (e) {
});

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent',  function (e) {
});

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent',  function (e) {
});
})()
), Clazz.new_(P$.MainFrame$1.$init$,[this, null])));
Clazz.new_($I$(10,1).c$$java_awt_Component$java_awt_dnd_DropTargetListener,[this.tree, dtl]);
try {
p$1.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
p$1.setApplicationElements.apply(this, []);
this.setDefaultCloseOperation$I(0);
this.addWindowListener$java_awt_event_WindowListener(((P$.MainFrame$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "MainFrame$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.WindowAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'windowClosing$java_awt_event_WindowEvent',  function (we) {
this.b$['jspecview.application.MainFrame'].windowClosing_actionPerformed$.apply(this.b$['jspecview.application.MainFrame'], []);
});
})()
), Clazz.new_($I$(14,1),[this, null],P$.MainFrame$2)));
this.setSize$I$I(1200, 800);
}, p$1);

Clazz.newMeth(C$, 'setApplicationElements',  function () {
this.appMenu.setSelections$Z$Z$Z$jspecview_api_JSVPanel(this.sidePanelOn, this.toolbarOn, this.statusbarOn, this.vwr.selectedPanel);
this.toolBar.setSelections$jspecview_api_JSVPanel(this.vwr.selectedPanel);
}, p$1);

Clazz.newMeth(C$, 'setApplicationProperties$Z',  function (shouldApplySpectrumDisplaySettings) {
var properties=this.vwr.properties;
var recentFilesString=properties.getProperty$S("recentFilePaths");
this.recentFilePaths.clear$();
if (!recentFilesString.equals$O("")) {
var st=Clazz.new_($I$(15,1).c$$S$S,[recentFilesString, ","]);
while (st.hasMoreTokens$()){
var file=st.nextToken$().trim$();
if (file.length$() < 100) this.recentFilePaths.addLast$O(file);
}
}this.showExitDialog=Boolean.parseBoolean$S(properties.getProperty$S("confirmBeforeExit"));
this.sidePanelOn=Boolean.parseBoolean$S(properties.getProperty$S("showSidePanel"));
this.toolbarOn=Boolean.parseBoolean$S(properties.getProperty$S("showToolBar"));
this.statusbarOn=Boolean.parseBoolean$S(properties.getProperty$S("showStatusBar"));
this.jsv.setApplicationProperties$Z(shouldApplySpectrumDisplaySettings);
}, p$1);

Clazz.newMeth(C$, 'jbInit',  function () {
this.toolBar=Clazz.new_($I$(16,1).c$$jspecview_application_MainFrame,[this]);
this.appMenu=Clazz.new_($I$(17,1).c$$jspecview_application_MainFrame,[this]);
this.appMenu.setRecentMenu$javajs_util_Lst(this.recentFilePaths);
this.setDefaultCloseOperation$I(2);
this.setJMenuBar$javax_swing_JMenuBar(this.appMenu);
this.setTitle$S("JSpecView");
this.getContentPane$().setLayout$java_awt_LayoutManager(this.mainborderLayout);
this.sideSplitPane.setOrientation$I(0);
this.sideSplitPane.setOneTouchExpandable$Z(true);
this.statusLabel.setToolTipText$S("");
this.statusLabel.setHorizontalTextPosition$I(10);
this.statusLabel.setText$S("  ");
this.statusPanel.setBorder$javax_swing_border_Border($I$(18).createEtchedBorder$());
var bl=Clazz.new_($I$(3,1));
bl.setHgap$I(2);
bl.setVgap$I(2);
this.statusPanel.setLayout$java_awt_LayoutManager(bl);
this.mainSplitPane.setCursor$java_awt_Cursor($I$(19).getDefaultCursor$());
this.mainSplitPane.setOneTouchExpandable$Z(true);
this.mainSplitPane.setResizeWeight$D(0.3);
this.getContentPane$().add$java_awt_Component$O(this.statusPanel, "South");
this.statusPanel.add$java_awt_Component$O(this.statusLabel, "North");
this.statusPanel.add$java_awt_Component$O(this.commandInput, "South");
this.commandHistory=Clazz.new_($I$(20,1).c$$jspecview_common_JSViewer$javax_swing_JTextField,[this.vwr, this.commandInput]);
this.commandInput.setFocusTraversalKeysEnabled$Z(false);
this.commandInput.addKeyListener$java_awt_event_KeyListener(((P$.MainFrame$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "MainFrame$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.KeyListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'keyPressed$java_awt_event_KeyEvent',  function (e) {
this.b$['jspecview.application.MainFrame'].keyPressedEvent$I$C.apply(this.b$['jspecview.application.MainFrame'], [e.getKeyCode$(), e.getKeyChar$()]);
});

Clazz.newMeth(C$, 'keyReleased$java_awt_event_KeyEvent',  function (e) {
});

Clazz.newMeth(C$, 'keyTyped$java_awt_event_KeyEvent',  function (e) {
});
})()
), Clazz.new_(P$.MainFrame$3.$init$,[this, null])));
this.getContentPane$().add$java_awt_Component$O(this.toolBar, "North");
this.getContentPane$().add$java_awt_Component$O(this.mainSplitPane, "Center");
this.spectraTreeScrollPane=Clazz.new_($I$(21,1).c$$java_awt_Component,[this.tree]);
if (this.jmolDisplay != null ) {
var leftPanel=Clazz.new_($I$(4,1));
var bl1=Clazz.new_($I$(3,1));
leftPanel.setLayout$java_awt_LayoutManager(bl1);
var jmolDisplayPanel=Clazz.new_($I$(5,1));
jmolDisplayPanel.setBackground$java_awt_Color($I$(22).BLACK);
leftPanel.add$java_awt_Component$O(jmolDisplayPanel, "South");
leftPanel.add$java_awt_Component$O(this.spectraTreeScrollPane, "North");
this.sideSplitPane.setTopComponent$java_awt_Component(this.spectraTreeScrollPane);
this.sideSplitPane.setDividerLocation$I(this.splitPosition=300);
this.awaken$Z(true);
this.mainSplitPane.setLeftComponent$java_awt_Component(this.sideSplitPane);
} else {
this.mainSplitPane.setLeftComponent$java_awt_Component(this.spectraTreeScrollPane);
}this.mainPanel=this.vwr.mainPanel;
this.mainSplitPane.setRightComponent$java_awt_Component(this.mainPanel);
}, p$1);

Clazz.newMeth(C$, 'keyPressedEvent$I$C',  function (keyCode, keyChar) {
this.commandHistory.keyPressed$I(keyCode);
var ret=this.vwr.checkCommandLineForTip$C$S$Z(keyChar, this.commandInput.getText$(), true);
if (ret != null ) this.commandInput.setText$S(ret);
this.commandInput.requestFocusInWindow$();
});

Clazz.newMeth(C$, 'setError$Z$Z',  function (isError, isWarningOnly) {
this.appMenu.setError$Z$Z(isError, isWarningOnly);
this.toolBar.setError$Z$Z(isError, isWarningOnly);
});

Clazz.newMeth(C$, 'showNotImplementedOptionPane$',  function () {
$I$(23).showMessageDialog$java_awt_Component$O$S$I(this, "Not Yet Implemented", "Not Yet Implemented", 1);
});

Clazz.newMeth(C$, 'runScriptNow$S',  function (peakScript) {
return this.vwr.runScriptNow$S(peakScript);
});

Clazz.newMeth(C$, 'panelEvent$O',  function (eventObj) {
if (Clazz.instanceOf(eventObj, "jspecview.common.PeakPickEvent")) {
this.vwr.processPeakPickEvent$O$Z(eventObj, true);
} else if (Clazz.instanceOf(eventObj, "jspecview.common.ZoomEvent")) {
this.writeStatus$S("Double-Click highlighted spectrum in menu to zoom out; CTRL+/CTRL- to adjust Y scaling.");
} else if (Clazz.instanceOf(eventObj, "jspecview.common.SubSpecChangeEvent")) {
var e=eventObj;
if (!e.isValid$()) p$1.advanceSpectrumBy$I.apply(this, [-e.getSubIndex$()]);
}});

Clazz.newMeth(C$, 'advanceSpectrumBy$I',  function (n) {
var i=this.vwr.panelNodes.size$();
for (; --i >= 0; ) if (this.vwr.panelNodes.get$I(i).jsvp === this.vwr.selectedPanel ) break;

this.vwr.setFrameAndTreeNode$I(i + n);
this.vwr.selectedPanel.getFocusNow$Z(false);
}, p$1);

Clazz.newMeth(C$, 'getScriptQueue$',  function () {
return null;
});

Clazz.newMeth(C$, 'setSplitPane$Z',  function (TF) {
if (TF) this.mainSplitPane.setDividerLocation$I(200);
 else this.mainSplitPane.setDividerLocation$I(0);
});

Clazz.newMeth(C$, 'enableToolbar$Z',  function (isEnabled) {
if (isEnabled) this.getContentPane$().add$java_awt_Component$O(this.toolBar, "North");
 else this.getContentPane$().remove$java_awt_Component(this.toolBar);
this.validate$();
});

Clazz.newMeth(C$, 'showPreferences$',  function () {
var pd=Clazz.new_($I$(24,1).c$$java_awt_Frame$jspecview_common_JSViewer$S$Z$jspecview_application_DisplaySchemesProcessor,[this, this.vwr, "Preferences", true, this.dsp]);
this.vwr.properties=pd.getPreferences$();
var shouldApplySpectrumDisplaySetting=pd.shouldApplySpectrumDisplaySettingsNow$();
p$1.setApplicationProperties$Z.apply(this, [shouldApplySpectrumDisplaySetting]);
for (var i=this.vwr.panelNodes.size$(); --i >= 0; ) this.jsv.siSetPropertiesFromPreferences$jspecview_api_JSVPanel$Z(this.vwr.panelNodes.get$I(i).jsvp, shouldApplySpectrumDisplaySetting);

p$1.setApplicationElements.apply(this, []);
this.dsp.getDisplaySchemes$();
if (this.jsv.defaultDisplaySchemeName.equals$O("Current")) {
this.vwr.setProperty$S$S("defaultDisplaySchemeName", this.tempDS);
}});

Clazz.newMeth(C$, 'exportSpectrumViaMenu$S',  function (command) {
Clazz.new_($I$(25,1)).write$jspecview_common_JSViewer$javajs_util_Lst$Z(this.vwr, $I$(26).getTokens$S(command), false);
});

Clazz.newMeth(C$, 'enableStatus$Z',  function (TF) {
if (TF) this.getContentPane$().add$java_awt_Component$O(this.statusPanel, "South");
 else this.getContentPane$().remove$java_awt_Component(this.statusPanel);
this.validate$();
});

Clazz.newMeth(C$, 'windowClosing_actionPerformed$',  function () {
this.exitJSpecView$Z(true);
});

Clazz.newMeth(C$, 'getJSpecViewProperty$S',  function (key) {
return this.vwr.getPropertyAsJavaObject$S(key);
});

Clazz.newMeth(C$, 'register$S$org_jmol_api_JmolSyncInterface',  function (appletID, jmolStatusListener) {
this.jsv.jmol=jmolStatusListener;
this.isEmbedded=true;
});

Clazz.newMeth(C$, 'syncScript$S',  function (peakScript) {
this.tree.setEnabled$Z(false);
this.vwr.syncScript$S(peakScript);
this.tree.setEnabled$Z(true);
});

Clazz.newMeth(C$, 'addHighlight$D$D$I$I$I$I',  function (x1, x2, r, g, b, a) {
this.advancedApplet.addHighlight$D$D$I$I$I$I(x1, x2, r, g, b, a);
});

Clazz.newMeth(C$, 'exportSpectrum$S$I',  function (type, n) {
return this.advancedApplet.exportSpectrum$S$I(type, n);
});

Clazz.newMeth(C$, 'getCoordinate$',  function () {
return this.advancedApplet.getCoordinate$();
});

Clazz.newMeth(C$, 'getPropertyAsJSON$S',  function (key) {
return this.advancedApplet.getPropertyAsJSON$S(key);
});

Clazz.newMeth(C$, 'getPropertyAsJavaObject$S',  function (key) {
return this.advancedApplet.getPropertyAsJavaObject$S(key);
});

Clazz.newMeth(C$, 'getSolnColour$',  function () {
return this.advancedApplet.getSolnColour$();
});

Clazz.newMeth(C$, 'loadInline$S',  function (data) {
this.jsv.siOpenDataOrFile$O$S$javajs_util_Lst$S$I$I$Z$S$S(data, null, null, null, -1, -1, true, null, null);
});

Clazz.newMeth(C$, 'setFilePath$S',  function (tmpFilePath) {
this.jsv.siProcessCommand$S("load " + tmpFilePath);
});

Clazz.newMeth(C$, 'runScript$S',  function (script) {
this.runScriptNow$S(script);
});

Clazz.newMeth(C$, 'removeAllHighlights$',  function () {
this.advancedApplet.removeAllHighlights$();
});

Clazz.newMeth(C$, 'removeHighlight$D$D',  function (x1, x2) {
this.advancedApplet.removeHighlight$D$D(x1, x2);
});

Clazz.newMeth(C$, 'reversePlot$',  function () {
this.advancedApplet.reversePlot$();
});

Clazz.newMeth(C$, 'setCursorObject$O',  function (c) {
this.setCursor$java_awt_Cursor(c);
});

Clazz.newMeth(C$, 'setSpectrumNumber$I',  function (i) {
this.advancedApplet.setSpectrumNumber$I(i);
});

Clazz.newMeth(C$, 'toggleCoordinate$',  function () {
this.advancedApplet.toggleCoordinate$();
});

Clazz.newMeth(C$, 'togglePointsOnly$',  function () {
this.advancedApplet.togglePointsOnly$();
});

Clazz.newMeth(C$, 'toggleGrid$',  function () {
this.advancedApplet.toggleGrid$();
});

Clazz.newMeth(C$, 'toggleIntegration$',  function () {
this.advancedApplet.toggleIntegration$();
});

Clazz.newMeth(C$, 'writeStatus$S',  function (msg) {
if (msg == null ) msg="Unexpected Error";
if (msg.length$() == 0) msg="Enter a command:";
this.statusLabel.setText$S(msg);
});

Clazz.newMeth(C$, 'print$S',  function (fileName) {
return this.vwr.print$S(fileName);
});

Clazz.newMeth(C$, 'checkScript$S',  function (script) {
var s=this.vwr.checkScript$S(script);
if (s != null ) System.out.println$S(s);
return s;
});

Clazz.newMeth(C$, 'setSelectedPanel$jspecview_api_JSVPanel',  function (jsvp) {
if (this.vwr.selectedPanel != null ) this.mainSplitPosition=this.mainSplitPane.getDividerLocation$();
this.vwr.mainPanel.setSelectedPanel$jspecview_common_JSViewer$jspecview_api_JSVPanel$javajs_util_Lst(this.vwr, jsvp, this.vwr.panelNodes);
this.vwr.selectedPanel=jsvp;
this.vwr.spectraTree.setSelectedPanel$jspecview_api_ScriptInterface$jspecview_api_JSVPanel(this.jsv, jsvp);
this.validate$();
if (jsvp != null ) {
jsvp.setEnabled$Z(true);
jsvp.setFocusable$Z(true);
}if (this.mainSplitPosition != 0) this.mainSplitPane.setDividerLocation$I(this.mainSplitPosition);
});

Clazz.newMeth(C$, 'validateAndRepaint$Z',  function (isAll) {
this.validate$();
if (isAll) this.repaint$();
 else this.vwr.requestRepaint$();
});

Clazz.newMeth(C$, 'execHidden$Z',  function (b) {
this.isHidden=(this.jsv.jmol != null  && b );
this.setVisible$Z(!this.isHidden);
});

Clazz.newMeth(C$, 'setCallback$jspecview_common_ScriptToken$S',  function (st, value) {
if (this.advancedApplet != null ) this.advancedApplet.siExecSetCallback$jspecview_common_ScriptToken$S(st, value);
});

Clazz.newMeth(C$, 'updateToolbar$jspecview_common_ScriptToken$Z',  function (st, tf) {
if (this.vwr.selectedPanel != null ) switch (st) {
case $I$(26).COORDINATESON:
this.toolBar.coordsToggleButton.setSelected$Z(tf);
break;
case $I$(26).GRIDON:
this.toolBar.gridToggleButton.setSelected$Z(tf);
break;
}
});

Clazz.newMeth(C$, 'sourceClosed$jspecview_source_JDXSource',  function (source) {
this.appMenu.clearSourceMenu$jspecview_source_JDXSource(source);
this.setTitle$S("JSpecView");
this.validateAndRepaint$Z(false);
});

Clazz.newMeth(C$, 'setLoading$S$S',  function (fileName, filePath) {
this.appMenu.setCloseMenuItem$S(fileName);
this.setTitle$S("JSpecView - " + (filePath.startsWith$S("http://SIMULATION/") ? $I$(27).getSimulationType$S(filePath) + " SIMULATION" : filePath));
this.appMenu.setSourceEnabled$Z(true);
});

Clazz.newMeth(C$, 'updateRecentMenus$S',  function (filePath) {
if (filePath.length$() > 100) return;
if (this.recentFilePaths.size$() >= 10) this.recentFilePaths.removeItemAt$I(9);
if (this.recentFilePaths.contains$O(filePath)) this.recentFilePaths.removeObj$O(filePath);
this.recentFilePaths.add$I$O(0, filePath);
var filePaths=Clazz.new_($I$(28,1));
var n=this.recentFilePaths.size$();
for (var index=0; index < n; index++) filePaths.append$S(", ").append$S(this.recentFilePaths.get$I(index));

this.vwr.setProperty$S$S("recentFilePaths", (n == 0 ? "" : filePaths.substring$I(2)));
this.appMenu.updateRecentMenus$javajs_util_Lst(this.recentFilePaths);
});

Clazz.newMeth(C$, 'setMenuEnables$jspecview_common_PanelNode$Z',  function (node, isSplit) {
this.appMenu.setMenuEnables$jspecview_common_PanelNode(node);
this.toolBar.setMenuEnables$jspecview_common_PanelNode(node);
});

Clazz.newMeth(C$, 'syncToJmol$S',  function (msg) {
if (this.jmolOrAdvancedApplet != null  && this.jmolOrAdvancedApplet !== this.jsv  ) this.jmolOrAdvancedApplet.syncToJmol$S(msg);
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.MainFrame, "SpectraTreeCellRenderer", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.tree.DefaultTreeCellRenderer');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['node','jspecview.api.JSVTreeNode']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'getTreeCellRendererComponent$javax_swing_JTree$O$Z$Z$Z$I$Z',  function (tree, value, sel, expanded, leaf, row, hasFocus) {
C$.superclazz.prototype.getTreeCellRendererComponent$javax_swing_JTree$O$Z$Z$Z$I$Z.apply(this, [tree, value, sel, expanded, leaf, row, hasFocus]);
this.node=value;
return this;
});

Clazz.newMeth(C$, 'getFont$',  function () {
return Clazz.new_(["Dialog", (this.node == null  || this.node.getPanelNode$() == null   || this.node.getPanelNode$().jsvp == null   ? 1 : 2), 12],$I$(1,1).c$$S$I$I);
});
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:56 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
