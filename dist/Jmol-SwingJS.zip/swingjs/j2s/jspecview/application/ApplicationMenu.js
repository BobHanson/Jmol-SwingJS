(function(){var P$=Clazz.newPackage("jspecview.application"),p$1={},I$=[[0,'javax.swing.JCheckBoxMenuItem','jspecview.common.ScriptToken','jspecview.application.AboutDialog','javax.swing.JMenu','jspecview.common.JSVFileManager','javax.swing.JMenuItem','javax.swing.KeyStroke']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ApplicationMenu", null, 'javax.swing.JMenuBar');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.gridCheckBoxMenuItem=Clazz.new_($I$(1,1));
this.coordsCheckBoxMenuItem=Clazz.new_($I$(1,1));
this.pointsOnlyCheckBoxMenuItem=Clazz.new_($I$(1,1));
this.revPlotCheckBoxMenuItem=Clazz.new_($I$(1,1));
this.scaleXCheckBoxMenuItem=Clazz.new_($I$(1,1));
this.scaleYCheckBoxMenuItem=Clazz.new_($I$(1,1));
this.toolbarCheckBoxMenuItem=Clazz.new_($I$(1,1));
this.sidePanelCheckBoxMenuItem=Clazz.new_($I$(1,1));
this.statusCheckBoxMenuItem=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['O',['mainFrame','jspecview.application.MainFrame','viewer','jspecview.common.JSViewer','processingMenu','javax.swing.JMenu','+displayMenu','+exportAsMenu','+openRecentMenu','+saveAsMenu','+saveAsJDXMenu','closeMenuItem','javax.swing.JMenuItem','+closeAllMenuItem','+errorLogMenuItem','+printMenuItem','+sourceMenuItem','+integrationMenuItem','+overlayKeyMenuItem','+transmittanceMenuItem','+solutionColorMenuItem','gridCheckBoxMenuItem','javax.swing.JCheckBoxMenuItem','+coordsCheckBoxMenuItem','+pointsOnlyCheckBoxMenuItem','+revPlotCheckBoxMenuItem','+scaleXCheckBoxMenuItem','+scaleYCheckBoxMenuItem','+toolbarCheckBoxMenuItem','+sidePanelCheckBoxMenuItem','+statusCheckBoxMenuItem']]]

Clazz.newMeth(C$, 'c$$jspecview_application_MainFrame',  function (si) {
Clazz.super_(C$, this);
this.mainFrame=si;
this.viewer=si.vwr;
p$1.jbInit.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'jbInit',  function () {
var openFileMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "F", "Add File...", 70, 2, ((P$.ApplicationMenu$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.openFileFromDialog$Z$Z$S$S(true, false, null, null);
});
})()
), Clazz.new_(P$.ApplicationMenu$1.$init$,[this, null])));
var openSimulationH1MenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "H", "Add H1 Simulation...", 72, 2, ((P$.ApplicationMenu$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.openFileFromDialog$Z$Z$S$S(true, false, "H1", null);
});
})()
), Clazz.new_(P$.ApplicationMenu$2.$init$,[this, null])));
var openSimulationC13MenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "C", "Add C13 Simulation...", 67, 2, ((P$.ApplicationMenu$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.openFileFromDialog$Z$Z$S$S(true, false, "C13", null);
});
})()
), Clazz.new_(P$.ApplicationMenu$3.$init$,[this, null])));
var openURLMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "U", "Add URL...", 85, 2, ((P$.ApplicationMenu$4||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.openFileFromDialog$Z$Z$S$S(true, true, null, null);
});
})()
), Clazz.new_(P$.ApplicationMenu$4.$init$,[this, null])));
this.printMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "P", "Print...", 80, 2, ((P$.ApplicationMenu$5||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("print");
});
})()
), Clazz.new_(P$.ApplicationMenu$5.$init$,[this, null])));
this.closeMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "C", "Close", 115, 2, ((P$.ApplicationMenu$6||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("CLOSE");
});
})()
), Clazz.new_(P$.ApplicationMenu$6.$init$,[this, null])));
this.closeAllMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "L", "Close All", 0, 2, ((P$.ApplicationMenu$7||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("CLOSE ALL");
});
})()
), Clazz.new_(P$.ApplicationMenu$7.$init$,[this, null])));
var scriptMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "T", "Script...", 83, 8, ((P$.ApplicationMenu$8||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("script INLINE");
});
})()
), Clazz.new_(P$.ApplicationMenu$8.$init$,[this, null])));
var exitMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "X", "Exit", 115, 8, ((P$.ApplicationMenu$9||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$9", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].mainFrame.exitJSpecView$Z(false);
});
})()
), Clazz.new_(P$.ApplicationMenu$9.$init$,[this, null])));
C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(this.gridCheckBoxMenuItem, "G", "Grid", 71, 2, ((P$.ApplicationMenu$10||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$10", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ItemListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'itemStateChanged$java_awt_event_ItemEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].setBoolean$jspecview_common_ScriptToken$java_awt_event_ItemEvent.apply(this.b$['jspecview.application.ApplicationMenu'], [$I$(2).GRIDON, e]);
});
})()
), Clazz.new_(P$.ApplicationMenu$10.$init$,[this, null])));
C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(this.coordsCheckBoxMenuItem, "C", "Coordinates", 67, 2, ((P$.ApplicationMenu$11||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$11", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ItemListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'itemStateChanged$java_awt_event_ItemEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].setBoolean$jspecview_common_ScriptToken$java_awt_event_ItemEvent.apply(this.b$['jspecview.application.ApplicationMenu'], [$I$(2).COORDINATESON, e]);
});
})()
), Clazz.new_(P$.ApplicationMenu$11.$init$,[this, null])));
C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(this.pointsOnlyCheckBoxMenuItem, "P", "Points Only", 80, 2, ((P$.ApplicationMenu$12||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$12", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ItemListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'itemStateChanged$java_awt_event_ItemEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].setBoolean$jspecview_common_ScriptToken$java_awt_event_ItemEvent.apply(this.b$['jspecview.application.ApplicationMenu'], [$I$(2).POINTSONLY, e]);
});
})()
), Clazz.new_(P$.ApplicationMenu$12.$init$,[this, null])));
C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(this.revPlotCheckBoxMenuItem, "R", "Reverse Plot", 82, 2, ((P$.ApplicationMenu$13||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$13", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ItemListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'itemStateChanged$java_awt_event_ItemEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].setBoolean$jspecview_common_ScriptToken$java_awt_event_ItemEvent.apply(this.b$['jspecview.application.ApplicationMenu'], [$I$(2).REVERSEPLOT, e]);
});
})()
), Clazz.new_(P$.ApplicationMenu$13.$init$,[this, null])));
C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(this.scaleXCheckBoxMenuItem, "X", "X Scale", 88, 2, ((P$.ApplicationMenu$14||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$14", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ItemListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'itemStateChanged$java_awt_event_ItemEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].setBoolean$jspecview_common_ScriptToken$java_awt_event_ItemEvent.apply(this.b$['jspecview.application.ApplicationMenu'], [$I$(2).XSCALEON, e]);
});
})()
), Clazz.new_(P$.ApplicationMenu$14.$init$,[this, null])));
C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(this.scaleYCheckBoxMenuItem, "Y", "Y Scale", 89, 2, ((P$.ApplicationMenu$15||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$15", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ItemListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'itemStateChanged$java_awt_event_ItemEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].setBoolean$jspecview_common_ScriptToken$java_awt_event_ItemEvent.apply(this.b$['jspecview.application.ApplicationMenu'], [$I$(2).YSCALEON, e]);
});
})()
), Clazz.new_(P$.ApplicationMenu$15.$init$,[this, null])));
var nextZoomMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "N", "Next View", 78, 3, ((P$.ApplicationMenu$16||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$16", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("zoom next");
});
})()
), Clazz.new_(P$.ApplicationMenu$16.$init$,[this, null])));
var prevZoomMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "P", "Previous View", 80, 3, ((P$.ApplicationMenu$17||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$17", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("zoom previous");
});
})()
), Clazz.new_(P$.ApplicationMenu$17.$init$,[this, null])));
var fullZoomMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "F", "Full View", 70, 3, ((P$.ApplicationMenu$18||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$18", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("zoom out");
});
})()
), Clazz.new_(P$.ApplicationMenu$18.$init$,[this, null])));
var clearZoomMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "C", "Clear Views", 67, 3, ((P$.ApplicationMenu$19||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$19", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("zoom clear");
});
})()
), Clazz.new_(P$.ApplicationMenu$19.$init$,[this, null])));
var userZoomMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "Z", "Set Zoom...", 90, 3, ((P$.ApplicationMenu$20||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$20", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("zoom ?");
});
})()
), Clazz.new_(P$.ApplicationMenu$20.$init$,[this, null])));
var viewAllMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "A", "All Spectra", 65, 3, ((P$.ApplicationMenu$21||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$21", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("view all");
});
})()
), Clazz.new_(P$.ApplicationMenu$21.$init$,[this, null])));
var spectraMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "S", "Selected Spectra...", 83, 3, ((P$.ApplicationMenu$22||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$22", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("view");
});
})()
), Clazz.new_(P$.ApplicationMenu$22.$init$,[this, null])));
var overlayStackOffsetYMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "y", "Overlay Offset...", 0, 0, ((P$.ApplicationMenu$23||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$23", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("stackOffsetY ?");
});
})()
), Clazz.new_(P$.ApplicationMenu$23.$init$,[this, null])));
this.sourceMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "S", "Source ...", 83, 2, ((P$.ApplicationMenu$24||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$24", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("showSource");
});
})()
), Clazz.new_(P$.ApplicationMenu$24.$init$,[this, null])));
this.errorLogMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "\u0000", "Error Log ...", 0, 0, ((P$.ApplicationMenu$25||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$25", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("showErrors");
});
})()
), Clazz.new_(P$.ApplicationMenu$25.$init$,[this, null])));
var propertiesMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "P", "Properties", 72, 2, ((P$.ApplicationMenu$26||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$26", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("showProperties");
});
})()
), Clazz.new_(P$.ApplicationMenu$26.$init$,[this, null])));
this.overlayKeyMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "\u0000", "Overlay Key", 0, 0, ((P$.ApplicationMenu$27||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$27", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("showKey toggle");
});
})()
), Clazz.new_(P$.ApplicationMenu$27.$init$,[this, null])));
var preferencesMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "P", "Preferences...", 0, 0, ((P$.ApplicationMenu$28||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$28", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].showPreferencesDialog$.apply(this.b$['jspecview.application.ApplicationMenu'], []);
});
})()
), Clazz.new_(P$.ApplicationMenu$28.$init$,[this, null])));
var aboutMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "\u0000", "About", 0, 0, ((P$.ApplicationMenu$29||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$29", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
Clazz.new_($I$(3,1).c$$java_awt_Frame,[this.b$['jspecview.application.ApplicationMenu'].mainFrame]);
});
})()
), Clazz.new_(P$.ApplicationMenu$29.$init$,[this, null])));
C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(this.toolbarCheckBoxMenuItem, "T", "Toolbar", 84, 9, ((P$.ApplicationMenu$30||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$30", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ItemListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'itemStateChanged$java_awt_event_ItemEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].mainFrame.enableToolbar$Z(e.getStateChange$() == 1);
});
})()
), Clazz.new_(P$.ApplicationMenu$30.$init$,[this, null])));
C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(this.sidePanelCheckBoxMenuItem, "S", "Side Panel", 83, 9, ((P$.ApplicationMenu$31||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$31", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ItemListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'itemStateChanged$java_awt_event_ItemEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].mainFrame.setSplitPane$Z(e.getStateChange$() == 1);
});
})()
), Clazz.new_(P$.ApplicationMenu$31.$init$,[this, null])));
C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(this.statusCheckBoxMenuItem, "B", "Status Bar", 66, 9, ((P$.ApplicationMenu$32||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$32", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ItemListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'itemStateChanged$java_awt_event_ItemEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].mainFrame.enableStatus$Z(e.getStateChange$() == 1);
});
})()
), Clazz.new_(P$.ApplicationMenu$32.$init$,[this, null])));
var fileMenu=Clazz.new_($I$(4,1));
fileMenu.setMnemonic$C("F");
fileMenu.setText$S("File");
var helpMenu=Clazz.new_($I$(4,1));
helpMenu.setMnemonic$C("H");
helpMenu.setText$S("Help");
var optionsMenu=Clazz.new_($I$(4,1));
optionsMenu.setMnemonic$C("O");
optionsMenu.setText$S("Options");
this.displayMenu=Clazz.new_($I$(4,1));
this.displayMenu.setMnemonic$C("D");
this.displayMenu.setText$S("Display");
this.displayMenu.addMenuListener$javax_swing_event_MenuListener(((P$.ApplicationMenu$33||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$33", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'javax.swing.event.MenuListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'menuSelected$javax_swing_event_MenuEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].doMenuSelected$.apply(this.b$['jspecview.application.ApplicationMenu'], []);
});

Clazz.newMeth(C$, 'menuDeselected$javax_swing_event_MenuEvent',  function (e) {
});

Clazz.newMeth(C$, 'menuCanceled$javax_swing_event_MenuEvent',  function (e) {
});
})()
), Clazz.new_(P$.ApplicationMenu$33.$init$,[this, null])));
var zoomMenu=Clazz.new_($I$(4,1));
zoomMenu.setMnemonic$C("Z");
zoomMenu.setText$S("Zoom");
this.openRecentMenu=Clazz.new_($I$(4,1));
this.openRecentMenu.setActionCommand$S("OpenRecent");
this.openRecentMenu.setMnemonic$C("R");
this.openRecentMenu.setText$S("Add Recent");
this.saveAsMenu=Clazz.new_($I$(4,1));
this.saveAsMenu.setMnemonic$C("A");
this.saveAsJDXMenu=Clazz.new_($I$(4,1));
this.saveAsJDXMenu.setMnemonic$C("J");
this.exportAsMenu=Clazz.new_($I$(4,1));
this.exportAsMenu.setMnemonic$C("E");
this.processingMenu=Clazz.new_($I$(4,1));
this.processingMenu.setMnemonic$C("P");
this.processingMenu.setText$S("Processing");
this.processingMenu.addMenuListener$javax_swing_event_MenuListener(((P$.ApplicationMenu$34||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$34", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'javax.swing.event.MenuListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'menuSelected$javax_swing_event_MenuEvent',  function (e) {
});

Clazz.newMeth(C$, 'menuDeselected$javax_swing_event_MenuEvent',  function (e) {
});

Clazz.newMeth(C$, 'menuCanceled$javax_swing_event_MenuEvent',  function (e) {
});
})()
), Clazz.new_(P$.ApplicationMenu$34.$init$,[this, null])));
this.setProcessingMenu$javax_swing_JComponent(this.processingMenu);
fileMenu.add$javax_swing_JMenuItem(openFileMenuItem);
fileMenu.add$javax_swing_JMenuItem(openSimulationH1MenuItem);
fileMenu.add$javax_swing_JMenuItem(openSimulationC13MenuItem);
fileMenu.add$javax_swing_JMenuItem(openURLMenuItem);
fileMenu.add$javax_swing_JMenuItem(this.openRecentMenu);
fileMenu.addSeparator$();
fileMenu.add$javax_swing_JMenuItem(this.closeMenuItem).setEnabled$Z(false);
fileMenu.add$javax_swing_JMenuItem(this.closeAllMenuItem).setEnabled$Z(false);
fileMenu.addSeparator$();
fileMenu.add$javax_swing_JMenuItem(scriptMenuItem);
fileMenu.addSeparator$();
fileMenu.add$javax_swing_JMenuItem(this.saveAsMenu).setEnabled$Z(false);
fileMenu.add$javax_swing_JMenuItem(this.exportAsMenu).setEnabled$Z(false);
fileMenu.addSeparator$();
fileMenu.add$javax_swing_JMenuItem(this.printMenuItem).setEnabled$Z(false);
fileMenu.addSeparator$();
fileMenu.add$javax_swing_JMenuItem(exitMenuItem);
this.displayMenu.add$javax_swing_JMenuItem(viewAllMenuItem);
this.displayMenu.add$javax_swing_JMenuItem(spectraMenuItem);
this.displayMenu.add$javax_swing_JMenuItem(overlayStackOffsetYMenuItem);
this.displayMenu.add$javax_swing_JMenuItem(this.overlayKeyMenuItem).setEnabled$Z(false);
this.displayMenu.addSeparator$();
this.displayMenu.add$javax_swing_JMenuItem(this.gridCheckBoxMenuItem);
this.displayMenu.add$javax_swing_JMenuItem(this.coordsCheckBoxMenuItem);
this.displayMenu.add$javax_swing_JMenuItem(this.scaleXCheckBoxMenuItem);
this.displayMenu.add$javax_swing_JMenuItem(this.scaleYCheckBoxMenuItem);
this.displayMenu.add$javax_swing_JMenuItem(this.revPlotCheckBoxMenuItem);
this.displayMenu.add$javax_swing_JMenuItem(this.pointsOnlyCheckBoxMenuItem);
this.displayMenu.addSeparator$();
this.displayMenu.add$javax_swing_JMenuItem(zoomMenu);
this.displayMenu.addSeparator$();
this.displayMenu.add$javax_swing_JMenuItem(this.sourceMenuItem).setEnabled$Z(false);
this.displayMenu.add$javax_swing_JMenuItem(this.errorLogMenuItem).setEnabled$Z(false);
this.displayMenu.add$javax_swing_JMenuItem(propertiesMenuItem);
zoomMenu.add$javax_swing_JMenuItem(nextZoomMenuItem);
zoomMenu.add$javax_swing_JMenuItem(prevZoomMenuItem);
zoomMenu.add$javax_swing_JMenuItem(fullZoomMenuItem);
zoomMenu.add$javax_swing_JMenuItem(clearZoomMenuItem);
zoomMenu.add$javax_swing_JMenuItem(userZoomMenuItem);
optionsMenu.add$javax_swing_JMenuItem(preferencesMenuItem);
optionsMenu.addSeparator$();
optionsMenu.add$javax_swing_JMenuItem(this.toolbarCheckBoxMenuItem);
optionsMenu.add$javax_swing_JMenuItem(this.sidePanelCheckBoxMenuItem);
optionsMenu.add$javax_swing_JMenuItem(this.statusCheckBoxMenuItem);
helpMenu.add$javax_swing_JMenuItem(aboutMenuItem);
this.add$javax_swing_JMenu(fileMenu);
this.add$javax_swing_JMenu(this.displayMenu).setEnabled$Z(false);
this.add$javax_swing_JMenu(optionsMenu);
this.add$javax_swing_JMenu(this.processingMenu).setEnabled$Z(false);
this.add$javax_swing_JMenu(helpMenu);
C$.setMenus$javax_swing_JMenu$javax_swing_JMenu$javax_swing_JMenu$java_awt_event_ActionListener(this.saveAsMenu, this.saveAsJDXMenu, this.exportAsMenu, (((P$.ApplicationMenu$35||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$35", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].mainFrame.exportSpectrumViaMenu$S(e.getActionCommand$());
});
})()
), Clazz.new_(P$.ApplicationMenu$35.$init$,[this, null]))));
this.toolbarCheckBoxMenuItem.setSelected$Z(true);
this.sidePanelCheckBoxMenuItem.setSelected$Z(true);
this.statusCheckBoxMenuItem.setSelected$Z(true);
}, p$1);

Clazz.newMeth(C$, 'doMenuSelected$',  function () {
var pd=this.mainFrame.vwr.pd$();
this.gridCheckBoxMenuItem.setSelected$Z(pd != null  && pd.getBoolean$jspecview_common_ScriptToken($I$(2).GRIDON) );
this.coordsCheckBoxMenuItem.setSelected$Z(pd != null  && pd.getBoolean$jspecview_common_ScriptToken($I$(2).COORDINATESON) );
this.pointsOnlyCheckBoxMenuItem.setSelected$Z(pd != null  && pd.getBoolean$jspecview_common_ScriptToken($I$(2).POINTSONLY) );
this.revPlotCheckBoxMenuItem.setSelected$Z(pd != null  && pd.getBoolean$jspecview_common_ScriptToken($I$(2).REVERSEPLOT) );
});

Clazz.newMeth(C$, 'setProcessingMenu$javax_swing_JComponent',  function (menu) {
menu.add$java_awt_Component(this.integrationMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "I", "Integration", 0, 0, ((P$.ApplicationMenu$36||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$36", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("showIntegration");
});
})()
), Clazz.new_(P$.ApplicationMenu$36.$init$,[this, null]))));
menu.add$java_awt_Component(C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "M", "Measurements", 0, 0, ((P$.ApplicationMenu$37||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$37", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("showMeasurements");
});
})()
), Clazz.new_(P$.ApplicationMenu$37.$init$,[this, null]))));
menu.add$java_awt_Component(C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "P", "Peaks", 0, 0, ((P$.ApplicationMenu$38||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$38", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("showPeakList");
});
})()
), Clazz.new_(P$.ApplicationMenu$38.$init$,[this, null]))));
menu.add$java_awt_Component(this.transmittanceMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "\u0000", "Transmittance/Absorbance", 0, 0, ((P$.ApplicationMenu$39||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$39", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("IRMODE IMPLIED");
});
})()
), Clazz.new_(P$.ApplicationMenu$39.$init$,[this, null]))));
menu.add$java_awt_Component(this.solutionColorMenuItem=C$.setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener(null, "C", "Predicted Solution Colour", 0, 0, ((P$.ApplicationMenu$40||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$40", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.runScript$S("GETSOLUTIONCOLOR");
});
})()
), Clazz.new_(P$.ApplicationMenu$40.$init$,[this, null]))));
});

Clazz.newMeth(C$, 'setBoolean$jspecview_common_ScriptToken$java_awt_event_ItemEvent',  function (st, e) {
var isOn=(e.getStateChange$() == 1);
this.viewer.runScript$S(st + " " + isOn );
});

Clazz.newMeth(C$, 'setSourceEnabled$Z',  function (b) {
this.closeAllMenuItem.setEnabled$Z(b);
this.displayMenu.setEnabled$Z(b);
this.processingMenu.setEnabled$Z(b);
this.exportAsMenu.setEnabled$Z(b);
this.saveAsMenu.setEnabled$Z(b);
this.printMenuItem.setEnabled$Z(b);
this.sourceMenuItem.setEnabled$Z(b);
this.errorLogMenuItem.setEnabled$Z(b);
});

Clazz.newMeth(C$, 'setCloseMenuItem$S',  function (fileName) {
this.closeMenuItem.setEnabled$Z(fileName != null );
this.closeMenuItem.setText$S(fileName == null  ? "Close" : "Close " + fileName);
});

Clazz.newMeth(C$, 'setError$Z$Z',  function (isError, isWarningOnly) {
this.errorLogMenuItem.setEnabled$Z(isError);
});

Clazz.newMeth(C$, 'setMenuEnables$jspecview_common_PanelNode',  function (node) {
if (node == null ) {
this.setCloseMenuItem$S(null);
this.setSourceEnabled$Z(false);
} else {
this.setSourceEnabled$Z(true);
var pd=node.pd$();
var spec=pd.getSpectrum$();
p$1.setCheckBoxes$jspecview_common_PanelData.apply(this, [pd]);
this.overlayKeyMenuItem.setEnabled$Z(pd.getNumberOfGraphSets$() > 1);
this.setCloseMenuItem$S($I$(5,"getTagName$S",[node.source.getFilePath$()]));
this.exportAsMenu.setEnabled$Z(true);
this.saveAsMenu.setEnabled$Z(true);
this.saveAsJDXMenu.setEnabled$Z(spec.canSaveAsJDX$());
this.integrationMenuItem.setEnabled$Z(spec.canIntegrate$());
this.transmittanceMenuItem.setEnabled$Z(spec.isAbsorbance$() || spec.isTransmittance$() );
this.solutionColorMenuItem.setEnabled$Z(spec.canShowSolutionColor$());
}});

Clazz.newMeth(C$, 'toggleOverlayKeyMenuItem$',  function () {
this.overlayKeyMenuItem.setSelected$Z(this.overlayKeyMenuItem.isSelected$());
return this.overlayKeyMenuItem.isSelected$();
});

Clazz.newMeth(C$, 'showPreferencesDialog$',  function () {
this.mainFrame.showPreferences$();
});

Clazz.newMeth(C$, 'setSelections$Z$Z$Z$jspecview_api_JSVPanel',  function (sidePanelOn, toolbarOn, statusbarOn, jsvp) {
this.sidePanelCheckBoxMenuItem.setSelected$Z(sidePanelOn);
this.toolbarCheckBoxMenuItem.setSelected$Z(toolbarOn);
this.statusCheckBoxMenuItem.setSelected$Z(statusbarOn);
if (jsvp != null ) p$1.setCheckBoxes$jspecview_common_PanelData.apply(this, [jsvp.getPanelData$()]);
});

Clazz.newMeth(C$, 'setCheckBoxes$jspecview_common_PanelData',  function (pd) {
this.gridCheckBoxMenuItem.setSelected$Z(pd.getBoolean$jspecview_common_ScriptToken($I$(2).GRIDON));
this.coordsCheckBoxMenuItem.setSelected$Z(pd.getBoolean$jspecview_common_ScriptToken($I$(2).COORDINATESON));
this.revPlotCheckBoxMenuItem.setSelected$Z(pd.getBoolean$jspecview_common_ScriptToken($I$(2).REVERSEPLOT));
this.scaleXCheckBoxMenuItem.setSelected$Z(pd.getBoolean$jspecview_common_ScriptToken($I$(2).XSCALEON));
this.scaleYCheckBoxMenuItem.setSelected$Z(pd.getBoolean$jspecview_common_ScriptToken($I$(2).YSCALEON));
}, p$1);

Clazz.newMeth(C$, 'setRecentMenu$javajs_util_Lst',  function (recentFilePaths) {
this.openRecentMenu.removeAll$();
for (var i=0; i < recentFilePaths.size$(); i++) {
var path=recentFilePaths.get$I(i);
var menuItem;
menuItem=Clazz.new_($I$(6,1).c$$S,[path]);
this.openRecentMenu.add$javax_swing_JMenuItem(menuItem);
menuItem.addActionListener$java_awt_event_ActionListener(((P$.ApplicationMenu$41||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$41", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.openFile$S$Z((e.getSource$()).getText$(), false);
});
})()
), Clazz.new_(P$.ApplicationMenu$41.$init$,[this, null])));
}
});

Clazz.newMeth(C$, 'updateRecentMenus$javajs_util_Lst',  function (recentFilePaths) {
var menuItem;
this.openRecentMenu.removeAll$();
for (var i=0; i < recentFilePaths.size$(); i++) {
var path=recentFilePaths.get$I(i);
menuItem=Clazz.new_($I$(6,1).c$$S,[path]);
this.openRecentMenu.add$javax_swing_JMenuItem(menuItem);
menuItem.addActionListener$java_awt_event_ActionListener(((P$.ApplicationMenu$42||
(function(){/*a*/var C$=Clazz.newClass(P$, "ApplicationMenu$42", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.application.ApplicationMenu'].viewer.openFile$S$Z((e.getSource$()).getText$(), true);
});
})()
), Clazz.new_(P$.ApplicationMenu$42.$init$,[this, null])));
}
});

Clazz.newMeth(C$, 'clearSourceMenu$jspecview_source_JDXSource',  function (source) {
if (source == null ) {
this.setMenuEnables$jspecview_common_PanelNode(null);
} else {
this.saveAsJDXMenu.setEnabled$Z(true);
this.saveAsMenu.setEnabled$Z(true);
}});

Clazz.newMeth(C$, 'addMenuItem$javax_swing_JMenu$S$C$java_awt_event_ActionListener',  function (m, key, keyChar, actionListener) {
var jmi=Clazz.new_($I$(6,1));
jmi.setMnemonic$C(keyChar == "\u0000" ? key.charAt$I(0) : keyChar);
jmi.setText$S(key);
jmi.addActionListener$java_awt_event_ActionListener(actionListener);
m.add$javax_swing_JMenuItem(jmi);
}, 1);

Clazz.newMeth(C$, 'setMenus$javax_swing_JMenu$javax_swing_JMenu$javax_swing_JMenu$java_awt_event_ActionListener',  function (saveAsMenu, saveAsJDXMenu, exportAsMenu, actionListener) {
saveAsMenu.setText$S("Save As");
C$.addMenuItem$javax_swing_JMenu$S$C$java_awt_event_ActionListener(saveAsMenu, "Original...", "\u0000", actionListener);
saveAsJDXMenu.setText$S("JDX");
C$.addMenuItem$javax_swing_JMenu$S$C$java_awt_event_ActionListener(saveAsJDXMenu, "XY", "\u0000", actionListener);
C$.addMenuItem$javax_swing_JMenu$S$C$java_awt_event_ActionListener(saveAsJDXMenu, "DIF", "\u0000", actionListener);
C$.addMenuItem$javax_swing_JMenu$S$C$java_awt_event_ActionListener(saveAsJDXMenu, "DIFDUP", "U", actionListener);
C$.addMenuItem$javax_swing_JMenu$S$C$java_awt_event_ActionListener(saveAsJDXMenu, "FIX", "\u0000", actionListener);
C$.addMenuItem$javax_swing_JMenu$S$C$java_awt_event_ActionListener(saveAsJDXMenu, "PAC", "\u0000", actionListener);
C$.addMenuItem$javax_swing_JMenu$S$C$java_awt_event_ActionListener(saveAsJDXMenu, "SQZ", "\u0000", actionListener);
saveAsMenu.add$javax_swing_JMenuItem(saveAsJDXMenu);
C$.addMenuItem$javax_swing_JMenu$S$C$java_awt_event_ActionListener(saveAsMenu, "CML", "\u0000", actionListener);
C$.addMenuItem$javax_swing_JMenu$S$C$java_awt_event_ActionListener(saveAsMenu, "XML (AnIML)", "\u0000", actionListener);
if (exportAsMenu != null ) {
exportAsMenu.setText$S("Export As");
C$.addMenuItem$javax_swing_JMenu$S$C$java_awt_event_ActionListener(exportAsMenu, "JPG", "\u0000", actionListener);
C$.addMenuItem$javax_swing_JMenu$S$C$java_awt_event_ActionListener(exportAsMenu, "PNG", "N", actionListener);
C$.addMenuItem$javax_swing_JMenu$S$C$java_awt_event_ActionListener(exportAsMenu, "SVG", "\u0000", actionListener);
C$.addMenuItem$javax_swing_JMenu$S$C$java_awt_event_ActionListener(exportAsMenu, "PDF", "\u0000", actionListener);
}}, 1);

Clazz.newMeth(C$, 'setMenuItem$javax_swing_JMenuItem$C$S$I$I$java_util_EventListener',  function (item, c, text, accel, mask, el) {
if (item == null ) item=Clazz.new_($I$(6,1));
if (c != "\u0000") item.setMnemonic$C(c);
item.setText$S(text);
if (accel > 0) item.setAccelerator$javax_swing_KeyStroke($I$(7).getKeyStroke$I$I$Z(accel, mask, false));
if (Clazz.instanceOf(el, "java.awt.event.ActionListener")) item.addActionListener$java_awt_event_ActionListener(el);
 else if (Clazz.instanceOf(el, "java.awt.event.ItemListener")) item.addItemListener$java_awt_event_ItemListener(el);
return item;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:04 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
