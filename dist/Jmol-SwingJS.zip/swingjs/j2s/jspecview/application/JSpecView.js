(function(){var P$=Clazz.newPackage("jspecview.application"),p$1={},I$=[[0,'jspecview.common.JSViewer','jspecview.common.JSVFileManager','jspecview.java.AwtMainPanel','java.awt.BorderLayout','jspecview.application.MainFrame','javax.swing.UIManager','org.jmol.util.Logger','jspecview.common.JSVersion','java.awt.GraphicsEnvironment','java.io.FileInputStream','java.io.FileOutputStream','javax.swing.JOptionPane','jspecview.java.AwtPanel','javajs.util.PT','java.util.Properties','jspecview.application.DisplaySchemesProcessor','jspecview.common.ScriptToken','jspecview.common.Parameters']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JSpecView", null, null, ['org.jmol.api.JSVInterface', 'jspecview.api.ScriptInterface']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['defaultDisplaySchemeName'],'O',['mainFrame','jspecview.application.MainFrame','vwr','jspecview.common.JSViewer','dsp','jspecview.application.DisplaySchemesProcessor','jmol','org.jmol.api.JmolSyncInterface','prevPanel','jspecview.api.JSVPanel']]
,['S',['propertiesFileName']]]

Clazz.newMeth(C$, 'setMainFrame$jspecview_application_MainFrame',  function (mainFrame) {
this.mainFrame=mainFrame;
});

Clazz.newMeth(C$, 'c$$Z$org_jmol_api_JSVInterface',  function (hasDisplay, jmol) {
;C$.$init$.apply(this);
this.vwr=Clazz.new_($I$(1,1).c$$jspecview_api_ScriptInterface$Z$Z,[this, false, false]);
$I$(2).setDocumentBase$jspecview_common_JSViewer$java_net_URL(this.vwr, null);
this.vwr.mainPanel=Clazz.new_([Clazz.new_($I$(4,1))],$I$(3,1).c$$java_awt_BorderLayout);
if (hasDisplay) {
this.mainFrame=Clazz.new_([this, null, jmol == null  ? this : jmol],$I$(5,1).c$$jspecview_application_JSpecView$java_awt_Component$org_jmol_api_JSVInterface);
} else {
p$1.initHeadless.apply(this, []);
}}, 1);

Clazz.newMeth(C$, 'initHeadless',  function () {
this.dsp=this.getDisplaySchemesProcessor$org_jmol_api_JSVInterface(this);
this.setApplicationProperties$Z(true);
}, p$1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
try {
$I$(6,"setLookAndFeel$S",[$I$(6).getSystemLookAndFeelClassName$()]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
$I$(7,"info$S",["JSpecView Application " + $I$(8).VERSION]);
var noDisplay=$I$(9).isHeadless$();
var autoexit=noDisplay;
var n=args.length;
if (n > 0 && args[n - 1].equalsIgnoreCase$S("-exit") ) {
autoexit=true;
--n;
}if (n > 0 && args[n - 1].equalsIgnoreCase$S("-nodisplay") ) {
noDisplay=autoexit=true;
--n;
}if (autoexit) System.out.println$S("JSpecview running headless");
if (noDisplay) System.out.println$S("JSpecview has no display");
var jsv=Clazz.new_(C$.c$$Z$org_jmol_api_JSVInterface,[!noDisplay, null]);
if (n >= 2) {
if (n == 2 && args[0].equalsIgnoreCase$S("-script") ) {
var script=args[1];
System.out.println$S("JSpecView is running script " + script);
jsv.vwr.runScriptNow$S(args[1]);
} else {
for (var i=0; i < args.length; i++) {
System.out.println$S("JSpecView is attempting to open " + args[i]);
jsv.vwr.openFile$S$Z(args[i], false);
}
}}if (noDisplay || autoexit ) C$.exitNow$();
jsv.mainFrame.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$, 'runScript$S',  function (script) {
this.vwr.runScriptNow$S(script);
});

Clazz.newMeth(C$, 'setProperties$java_util_Properties',  function (properties) {
try {
var fileIn=Clazz.new_($I$(10,1).c$$S,[C$.propertiesFileName]);
properties.load$java_io_InputStream(fileIn);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'saveProperties$java_util_Properties',  function (properties) {
try {
var fileOut=Clazz.new_($I$(11,1).c$$S,[C$.propertiesFileName]);
properties.store$java_io_OutputStream$S(fileOut, "JSpecView Application Properties");
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'exitJSpecView$Z$O',  function (withDialog, frame) {
if (!withDialog) C$.exitNow$();
if (withDialog && $I$(12).showConfirmDialog$java_awt_Component$O$S$I$I(frame, "Exit JSpecView?", "Exit", 0, 3) != 0 ) return;
C$.exitNow$();
});

Clazz.newMeth(C$, 'exitNow$',  function () {
System.out.println$S("JSpecView exit");
System.exit$I(0);
}, 1);

Clazz.newMeth(C$, 'siOpenDataOrFile$O$S$javajs_util_Lst$S$I$I$Z$S$S',  function (data, name, specs, url, firstSpec, lastSpec, isAppend, script, id) {
var isOne=(this.vwr.currentSource == null );
switch (name == null  && url == null   ? -3 : this.vwr.openDataOrFile$O$S$javajs_util_Lst$S$I$I$Z$S(data, name, specs, url, firstSpec, lastSpec, isAppend, id)) {
case 0:
if (script == null  && isOne  && this.vwr.currentSource.isCompoundSource  && this.vwr.pd$().getSpectrum$().isGC$() ) script="VIEW ALL;PEAK GC/MS ID=#1";
if (script != null ) this.runScript$S(script);
break;
case -3:
if (this.mainFrame != null ) {
this.mainFrame.awaken$Z(false);
this.mainFrame.awaken$Z(true);
$I$(12,"showMessageDialog$java_awt_Component$O",[this.mainFrame, "There was an error reading " + (name != null  ? name : url)]);
}break;
}
this.siValidateAndRepaint$Z(false);
});

Clazz.newMeth(C$, 'siSetCurrentSource$jspecview_source_JDXSource',  function (source) {
this.vwr.currentSource=source;
if (source != null  && this.mainFrame != null  ) this.mainFrame.appMenu.setCloseMenuItem$S($I$(2,"getTagName$S",[source.getFilePath$()]));
var isError=(source != null  && source.getErrorLog$().length$() > 0 );
p$1.setError$Z$Z.apply(this, [isError, (isError && source.getErrorLog$().indexOf$S("Warning") >= 0 )]);
});

Clazz.newMeth(C$, 'setError$Z$Z',  function (isError, isWarningOnly) {
if (this.mainFrame != null ) this.mainFrame.setError$Z$Z(isError, isWarningOnly);
}, p$1);

Clazz.newMeth(C$, 'siSetPropertiesFromPreferences$jspecview_api_JSVPanel$Z',  function (jsvp, includeMeasures) {
var ds=this.dsp.getDisplaySchemes$().get$O(this.defaultDisplaySchemeName);
jsvp.getPanelData$().addListener$jspecview_api_PanelListener(this.mainFrame);
this.vwr.parameters.setFor$jspecview_api_JSVPanel$jspecview_common_ColorParameters$Z(jsvp, (ds == null  ? this.dsp.getDefaultScheme$() : ds), includeMeasures);
this.vwr.checkAutoIntegrate$();
jsvp.doRepaint$Z(true);
});

Clazz.newMeth(C$, 'siProcessCommand$S',  function (script) {
this.runScriptNow$S(script);
});

Clazz.newMeth(C$, 'siSetSelectedPanel$jspecview_api_JSVPanel',  function (jsvp) {
if (this.mainFrame != null ) this.mainFrame.setSelectedPanel$jspecview_api_JSVPanel(jsvp);
 else {
this.vwr.mainPanel.setSelectedPanel$jspecview_common_JSViewer$jspecview_api_JSVPanel$javajs_util_Lst(this.vwr, jsvp, this.vwr.panelNodes);
this.vwr.selectedPanel=jsvp;
this.vwr.spectraTree.setSelectedPanel$jspecview_api_ScriptInterface$jspecview_api_JSVPanel(this, jsvp);
if (jsvp != null ) {
jsvp.setEnabled$Z(true);
jsvp.setFocusable$Z(true);
}}});

Clazz.newMeth(C$, 'siSendPanelChange$',  function () {
if (this.vwr.selectedPanel === this.prevPanel ) return;
this.prevPanel=this.vwr.selectedPanel;
this.vwr.sendPanelChange$();
});

Clazz.newMeth(C$, 'siSyncLoad$S',  function (filePath) {
this.vwr.closeSource$jspecview_source_JDXSource(null);
this.siOpenDataOrFile$O$S$javajs_util_Lst$S$I$I$Z$S$S(null, null, null, filePath, -1, -1, false, null, null);
if (this.vwr.currentSource == null ) return;
if (this.vwr.panelNodes.get$I(0).getSpectrum$().isAutoOverlayFromJmolClick$()) this.vwr.execView$S$Z("*", false);
});

Clazz.newMeth(C$, 'siValidateAndRepaint$Z',  function (isAll) {
if (this.mainFrame != null ) {
this.mainFrame.validateAndRepaint$Z(isAll);
}});

Clazz.newMeth(C$, 'siExecHidden$Z',  function (b) {
if (this.mainFrame != null ) {
this.mainFrame.execHidden$Z(b);
}});

Clazz.newMeth(C$, 'siLoaded$S',  function (value) {
var pd=this.vwr.pd$();
return (!pd.getSpectrum$().is1D$() && pd.getDisplay1D$()  ? "Click on the spectrum and use UP or DOWN keys to see subspectra." : null);
});

Clazz.newMeth(C$, 'siExecScriptComplete$S$Z',  function (msg, isOK) {
this.vwr.requestRepaint$();
if (msg != null ) {
this.writeStatus$S(msg);
if (msg.length$() == 0) msg=null;
}});

Clazz.newMeth(C$, 'siExecSetCallback$jspecview_common_ScriptToken$S',  function (st, value) {
if (this.mainFrame != null ) this.mainFrame.setCallback$jspecview_common_ScriptToken$S(st, value);
});

Clazz.newMeth(C$, 'siUpdateBoolean$jspecview_common_ScriptToken$Z',  function (st, TF) {
if (this.mainFrame != null ) this.mainFrame.updateToolbar$jspecview_common_ScriptToken$Z(st, TF);
});

Clazz.newMeth(C$, 'siCheckCallbacks$S',  function (title) {
});

Clazz.newMeth(C$, 'siNodeSet$jspecview_common_PanelNode',  function (panelNode) {
this.siSetMenuEnables$jspecview_common_PanelNode$Z(panelNode, false);
this.writeStatus$S("");
});

Clazz.newMeth(C$, 'siSourceClosed$jspecview_source_JDXSource',  function (source) {
p$1.setError$Z$Z.apply(this, [false, false]);
if (this.mainFrame != null ) this.mainFrame.sourceClosed$jspecview_source_JDXSource(source);
});

Clazz.newMeth(C$, 'siSetLoaded$S$S',  function (fileName, filePath) {
if (this.mainFrame != null ) this.mainFrame.setLoading$S$S(fileName, filePath);
});

Clazz.newMeth(C$, 'siUpdateRecentMenus$S',  function (filePath) {
if (this.mainFrame != null ) this.mainFrame.updateRecentMenus$S(filePath);
});

Clazz.newMeth(C$, 'siSetMenuEnables$jspecview_common_PanelNode$Z',  function (node, isSplit) {
if (this.mainFrame != null ) {
this.mainFrame.setMenuEnables$jspecview_common_PanelNode$Z(node, isSplit);
}});

Clazz.newMeth(C$, 'siGetNewJSVPanel$jspecview_common_Spectrum',  function (spec) {
return (spec == null  ? null : $I$(13).getPanelOne$jspecview_common_JSViewer$jspecview_common_Spectrum(this.vwr, spec));
});

Clazz.newMeth(C$, 'siGetNewJSVPanel2$javajs_util_Lst',  function (specs) {
return $I$(13).getPanelMany$jspecview_common_JSViewer$javajs_util_Lst(this.vwr, specs);
});

Clazz.newMeth(C$, 'siExecTest$S',  function (value) {
System.out.println$S($I$(14,"toJSON$S$O",[null, this.vwr.getPropertyAsJavaObject$S(value)]));
});

Clazz.newMeth(C$, 'siNewWindow$Z$Z',  function (isSelected, fromFrame) {
});

Clazz.newMeth(C$, 'syncToJmol$S',  function (msg) {
$I$(7).info$S("JSV>Jmol " + msg);
if (this.jmol != null ) {
this.jmol.syncScript$S(msg);
return;
}if (this.mainFrame != null ) this.mainFrame.syncToJmol$S(msg);
});

Clazz.newMeth(C$, 'repaint$',  function () {
if (this.mainFrame != null ) this.mainFrame.repaint$();
});

Clazz.newMeth(C$, 'setCursor$I',  function (id) {
if (this.mainFrame != null ) this.mainFrame.setCursor$I(id);
});

Clazz.newMeth(C$, 'isSigned$',  function () {
return true;
});

Clazz.newMeth(C$, 'runScriptNow$S',  function (script) {
return this.vwr.runScriptNow$S(script);
});

Clazz.newMeth(C$, 'writeStatus$S',  function (msg) {
if (this.mainFrame != null ) this.mainFrame.writeStatus$S(msg);
});

Clazz.newMeth(C$, 'getDisplaySchemesProcessor$org_jmol_api_JSVInterface',  function (jmolOrAdvancedApplet) {
var properties=this.vwr.properties=Clazz.new_($I$(15,1));
properties.setProperty$S$S("recentFilePaths", "");
properties.setProperty$S$S("confirmBeforeExit", "true");
properties.setProperty$S$S("automaticallyOverlay", "false");
properties.setProperty$S$S("automaticallyShowLegend", "false");
properties.setProperty$S$S("useDirectoryLastOpenedFile", "true");
properties.setProperty$S$S("useDirectoryLastExportedFile", "false");
properties.setProperty$S$S("directoryLastOpenedFile", "");
properties.setProperty$S$S("directoryLastExportedFile", "");
properties.setProperty$S$S("showSidePanel", "true");
properties.setProperty$S$S("showToolBar", "true");
properties.setProperty$S$S("showStatusBar", "true");
properties.setProperty$S$S("defaultDisplaySchemeName", "Default");
properties.setProperty$S$S("showGrid", "false");
properties.setProperty$S$S("showCoordinates", "false");
properties.setProperty$S$S("showXScale", "true");
properties.setProperty$S$S("showYScale", "true");
properties.setProperty$S$S("svgForInkscape", "false");
properties.setProperty$S$S("automaticTAConversion", "false");
properties.setProperty$S$S("AtoTSeparateWindow", "false");
properties.setProperty$S$S("automaticallyIntegrate", "false");
properties.setProperty$S$S("integralMinY", "0.1");
properties.setProperty$S$S("integralFactor", "50");
properties.setProperty$S$S("integralOffset", "30");
properties.setProperty$S$S("integralPlotColor", "#ff0000");
jmolOrAdvancedApplet.setProperties$java_util_Properties(properties);
return this.dsp=Clazz.new_($I$(16,1));
});

Clazz.newMeth(C$, 'setApplicationProperties$Z',  function (shouldApplySpectrumDisplaySettings) {
var properties=this.vwr.properties;
this.vwr.interfaceOverlaid=Boolean.parseBoolean$S(properties.getProperty$S("automaticallyOverlay"));
this.vwr.autoShowLegend=Boolean.parseBoolean$S(properties.getProperty$S("automaticallyShowLegend"));
var fh=this.vwr.fileHelper;
fh.useDirLastOpened=Boolean.parseBoolean$S(properties.getProperty$S("useDirectoryLastOpenedFile"));
fh.useDirLastExported=Boolean.parseBoolean$S(properties.getProperty$S("useDirectoryLastExportedFile"));
fh.dirLastOpened=properties.getProperty$S("directoryLastOpenedFile");
fh.dirLastExported=properties.getProperty$S("directoryLastExportedFile");
this.defaultDisplaySchemeName=properties.getProperty$S("defaultDisplaySchemeName");
if (shouldApplySpectrumDisplaySettings) {
this.vwr.parameters.setBoolean$jspecview_common_ScriptToken$Z($I$(17).GRIDON, $I$(18,"isTrue$S",[properties.getProperty$S("showGrid")]));
this.vwr.parameters.setBoolean$jspecview_common_ScriptToken$Z($I$(17).COORDINATESON, $I$(18,"isTrue$S",[properties.getProperty$S("showCoordinates")]));
this.vwr.parameters.setBoolean$jspecview_common_ScriptToken$Z($I$(17).XSCALEON, $I$(18,"isTrue$S",[properties.getProperty$S("showXScale")]));
this.vwr.parameters.setBoolean$jspecview_common_ScriptToken$Z($I$(17).YSCALEON, $I$(18,"isTrue$S",[properties.getProperty$S("showYScale")]));
}this.vwr.setIRmode$S(properties.getProperty$S("automaticTAConversion"));
try {
this.vwr.autoIntegrate=Boolean.parseBoolean$S(properties.getProperty$S("automaticallyIntegrate"));
this.vwr.parameters.integralMinY=C$.parseDoubleSafely$S$D(properties.getProperty$S("integralMinY"), this.vwr.parameters.integralMinY);
this.vwr.parameters.integralRange=C$.parseDoubleSafely$S$D(properties.getProperty$S("integralRange"), this.vwr.parameters.integralRange);
this.vwr.parameters.integralOffset=C$.parseDoubleSafely$S$D(properties.getProperty$S("integralOffset"), this.vwr.parameters.integralOffset);
this.vwr.parameters.set$jspecview_common_PanelData$jspecview_common_ScriptToken$S(null, $I$(17).INTEGRALPLOTCOLOR, properties.getProperty$S("integralPlotColor"));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("Bad PropertyValue ");
e.printStackTrace$();
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'parseDoubleSafely$S$D',  function (sval, defVal) {
return (sval == null  ? defVal : Double.parseDouble$S(sval));
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.propertiesFileName="jspecview.properties";
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:04 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
