(function(){var P$=Clazz.newPackage("jspecview.application"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "AwtTreePath", null, 'javax.swing.tree.TreePath', 'jspecview.api.JSVTreePath');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$OA',  function (path) {
;C$.superclazz.c$$OA.apply(this,[path]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:51 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
