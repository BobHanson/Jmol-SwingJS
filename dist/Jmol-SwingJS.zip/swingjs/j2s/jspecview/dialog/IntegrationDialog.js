(function(){var P$=Clazz.newPackage("jspecview.dialog"),p$1={},I$=[[0,['jspecview.common.Annotation','.AType'],'javajs.util.DF']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "IntegrationDialog", null, 'jspecview.dialog.JSVDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['posXY','int[]']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.type=$I$(1).Integration;
}, 1);

Clazz.newMeth(C$, 'getPosXY$',  function () {
return C$.posXY;
});

Clazz.newMeth(C$, 'addUniqueControls$',  function () {
this.txt1=this.dialog.addTextField$S$S$S$S$S$Z("txtBaselineOffset", "Baseline Offset", null, "%", "" + new Double(this.vwr.parameters.integralOffset).toString(), true);
this.txt2=this.dialog.addTextField$S$S$S$S$S$Z("txtScale", "Scale", null, "%", "" + new Double(this.vwr.parameters.integralRange).toString(), true);
this.dialog.addButton$S$S("btnApply", "Apply");
this.addApplyBtn=false;
this.dialog.addButton$S$S("btnAuto", "Auto");
this.dialog.addButton$S$S("btnDelete", "Delete");
this.dialog.addButton$S$S("btnNormalize", "Normalize");
});

Clazz.newMeth(C$, 'applyFromFields$',  function () {
this.apply$OA(Clazz.array(java.lang.Object, -1, [this.dialog.getText$O(this.txt1), this.dialog.getText$O(this.txt2)]));
});

Clazz.newMeth(C$, 'callback$S$S',  function (id, msg) {
var val;
try {
if (id.equals$O("SHOWSELECTION")) {
for (var i=0; i < this.xyData.size$(); i++) if ($I$(2,"formatDecimalDbl$D$I",[this.xyData.get$I(i).getXVal$(), 2]).equals$O(msg)) {
this.iSelected=i;
this.jsvp.getPanelData$().setXPointers$jspecview_common_Spectrum$D$jspecview_common_Spectrum$D(this.$spec, this.xyData.get$I(i).getXVal$(), this.$spec, this.xyData.get$I(i).getXVal2$());
this.jsvp.doRepaint$Z(true);
break;
}
return true;
}if (!id.equals$O("windowClosing") && !id.equals$O("FOCUS") ) {
if (id.equals$O("btnAuto") || this.xyData == null   || this.xyData.size$() == 0 ) {
this.vwr.runScript$S("integrate auto");
this.eventApply$();
return true;
}this.setFocus$Z(true);
}if (id.equals$O("btnDelete")) {
p$1.deleteIntegral.apply(this, []);
} else if (id.equals$O("btnNormalize")) {
if (!p$1.checkSelectedIntegral.apply(this, [])) return true;
var ret=this.manager.getDialogInput$O$S$S$I$O$OA$S(this.dialog, "Enter a normalization factor", "Normalize", 3, null, null, "" + new Double(this.lastNorm).toString());
val=Double.parseDouble$S(ret);
if (val > 0 ) (this.xyData).setSelectedIntegral$jspecview_common_Measurement$D(this.xyData.get$I(this.iSelected), this.lastNorm=val);
this.eventApply$();
} else {
return this.callbackAD$S$S(id, msg);
}} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
} else {
throw ex;
}
}
return true;
});

Clazz.newMeth(C$, 'checkSelectedIntegral',  function () {
if (this.iSelected < 0) {
this.showMessage$S$S$I("Select a line on the table first, then click this button.", "Integration", 1);
return false;
}return true;
}, p$1);

Clazz.newMeth(C$, 'deleteIntegral',  function () {
if (!p$1.checkSelectedIntegral.apply(this, [])) return;
this.xyData.removeItemAt$I(this.iSelected);
this.iSelected=-1;
this.iRowColSelected=-1;
this.applyFromFields$();
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.posXY=Clazz.array(Integer.TYPE, -1, [-2147483648, 0]);
};
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:29 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
