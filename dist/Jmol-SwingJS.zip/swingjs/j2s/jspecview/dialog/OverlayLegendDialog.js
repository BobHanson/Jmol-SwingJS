(function(){var P$=Clazz.newPackage("jspecview.dialog"),I$=[[0,['jspecview.common.Annotation','.AType']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "OverlayLegendDialog", null, 'jspecview.dialog.JSVDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['posXY','int[]']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.type=$I$(1).OverlayLegend;
}, 1);

Clazz.newMeth(C$, 'getPosXY$',  function () {
return C$.posXY;
});

Clazz.newMeth(C$, 'addUniqueControls$',  function () {
});

Clazz.newMeth(C$, 'callback$S$S',  function (id, msg) {
return false;
});

C$.$static$=function(){C$.$static$=0;
C$.posXY=Clazz.array(Integer.TYPE, -1, [-2147483648, 0]);
};
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:57 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
