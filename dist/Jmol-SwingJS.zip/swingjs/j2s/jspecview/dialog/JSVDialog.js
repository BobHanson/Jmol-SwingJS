(function(){var P$=Clazz.newPackage("jspecview.dialog"),p$1={},I$=[[0,'jspecview.dialog.DialogManager',['jspecview.common.Annotation','.AType'],'jspecview.common.PeakData','javajs.util.DF','jspecview.common.IntegralData','javajs.util.PT']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JSVDialog", null, 'jspecview.common.Annotation', 'jspecview.api.AnnotationData');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.precision=1;
this.isON=true;
this.lastNorm=1;
this.iRowColSelected=-1;
this.iSelected=-1;
this.iRowSelected=-1;
this.iColSelected=-1;
},1);

C$.$fields$=[['Z',['addClearBtn','addCombo1','addApplyBtn','isNumeric','defaultVisible','addUnits','isON','skipCreate'],'D',['lastNorm'],'I',['precision','iRowColSelected','iSelected','iRowSelected','iColSelected'],'S',['optionKey','title','subType','graphSetKey'],'O',['options','java.util.Map','type','jspecview.common.Annotation.AType','vwr','jspecview.common.JSViewer','$spec','jspecview.common.Spectrum','manager','jspecview.dialog.DialogManager','dialog','jspecview.api.PlatformDialog','jsvp','jspecview.api.JSVPanel','txt1','java.lang.Object','+txt2','+txt3','+combo1','xyData','jspecview.common.MeasurementData','myParams','jspecview.common.Parameters','loc','int[]','showHideButton','java.lang.Object','tableData','Object[][]','unitOptions','String[]','formatOptions','int[]','unitPtr','Integer']]]

Clazz.newMeth(C$, 'setParams$S$jspecview_common_JSViewer$jspecview_common_Spectrum',  function (title, viewer, spec) {
title=$I$(1).fixTitle$S(title);
this.title=title;
this.vwr=viewer;
this.$spec=spec;
this.manager=viewer.getDialogManager$();
this.jsvp=viewer.selectedPanel;
this.myParams=(viewer.getPlatformInterface$S("Parameters")).setName$S("dialogParams");
this.subType=(spec == null  ? "!" : spec.getTypeLabel$());
this.optionKey=this.type + "_" + this.subType ;
this.options=this.manager.getDialogOptions$();
if (spec != null ) {
var specOptions=spec.getDefaultAnnotationInfo$jspecview_common_Annotation_AType(this.type);
this.options.put$O$O(this.optionKey, specOptions);
this.unitOptions=specOptions[0];
this.formatOptions=specOptions[1];
this.unitPtr=this.options.get$O(this.optionKey + "_unitPtr");
if (this.unitPtr == null ) this.unitPtr=specOptions[2];
}switch (this.type) {
case $I$(2).Integration:
this.isNumeric=true;
this.addClearBtn=true;
this.defaultVisible=true;
this.addApplyBtn=true;
break;
case $I$(2).Measurements:
this.isNumeric=true;
this.addClearBtn=true;
this.addCombo1=true;
this.defaultVisible=true;
break;
case $I$(2).OverlayLegend:
break;
case $I$(2).PeakList:
this.isNumeric=true;
this.addApplyBtn=true;
this.defaultVisible=true;
break;
case $I$(2).Views:
this.defaultVisible=true;
break;
case $I$(2).NONE:
break;
}
p$1.initDialog.apply(this, []);
return this;
});

Clazz.newMeth(C$, 'initDialog',  function () {
this.dialog=this.manager.getDialog$jspecview_dialog_JSVDialog(this);
p$1.restoreDialogPosition$jspecview_api_JSVPanel$IA.apply(this, [this.jsvp, this.getPosXY$()]);
this.dialog.setTitle$S(this.title);
this.layoutDialog$();
}, p$1);

Clazz.newMeth(C$, 'layoutDialog$',  function () {
this.dialog.startLayout$();
this.addUniqueControls$();
if (this.isNumeric) {
p$1.getUnitOptions.apply(this, []);
if (this.addCombo1) this.combo1=this.dialog.addSelectOption$S$S$SA$I$Z("cmbUnits", "Units", this.unitOptions, this.unitPtr.intValue$(), this.addUnits);
if (this.addApplyBtn) this.dialog.addButton$S$S("btnApply", "Apply");
this.showHideButton=this.dialog.addButton$S$S("btnShow", "Show");
if (this.addClearBtn) this.dialog.addButton$S$S("btnClear", "Clear");
}this.dialog.endLayout$();
this.checkEnables$();
this.dialog.setVisible$Z(this.defaultVisible);
});

Clazz.newMeth(C$, 'callbackAD$S$S',  function (id, msg) {
if (id.equals$O("FOCUS")) {
this.eventFocus$();
} else if (id.equals$O("tableSelect")) {
p$1.tableSelect$S.apply(this, [msg]);
} else if (id.equals$O("btnClear")) {
p$1.clear.apply(this, []);
} else if (id.equals$O("btnApply")) {
this.eventApply$();
} else if (id.equals$O("btnShow")) {
var label=this.dialog.getText$O(this.showHideButton);
p$1.eventShowHide$Z.apply(this, [label.equals$O("Show")]);
} else if (id.equals$O("cmbUnits")) {
p$1.setPrecision$I.apply(this, [this.dialog.getSelectedIndex$O(this.combo1)]);
} else if (id.startsWith$S("txt")) {
this.eventApply$();
} else if (id.equals$O("windowClosing")) {
this.done$();
return true;
}if (this.jsvp != null ) this.jsvp.doRepaint$Z(true);
return true;
});

Clazz.newMeth(C$, 'addUniqueControls$jspecview_dialog_DialogManager',  function (dialogHelper) {
});

Clazz.newMeth(C$, 'getAType$',  function () {
return this.type;
});

Clazz.newMeth(C$, 'getGraphSetKey$',  function () {
return this.graphSetKey;
});

Clazz.newMeth(C$, 'setGraphSetKey$S',  function (key) {
this.graphSetKey=key;
});

Clazz.newMeth(C$, 'getSpectrum$',  function () {
return this.$spec;
});

Clazz.newMeth(C$, 'getState$',  function () {
return this.isON;
});

Clazz.newMeth(C$, 'setState$Z',  function (b) {
this.isON=b;
});

Clazz.newMeth(C$, 'checkEnables$',  function () {
var isShow=p$1.checkVisible.apply(this, []);
this.dialog.setText$O$S(this.showHideButton, isShow ? "Hide" : "Show");
});

Clazz.newMeth(C$, 'createTable$OAA$SA$IA',  function (data, header, widths) {
this.tableData=data;
this.dialog.createTable$OAA$SA$IA(data, header, widths);
});

Clazz.newMeth(C$, 'setTableSelectionEnabled$Z',  function (enabled) {
this.dialog.setCellSelectionEnabled$Z(enabled);
});

Clazz.newMeth(C$, 'getParameters$',  function () {
return this.myParams;
});

Clazz.newMeth(C$, 'showMessage$S$S$I',  function (msg, title, msgType) {
this.manager.showMessageDialog$O$S$S$I(this.dialog, msg, title, msgType);
});

Clazz.newMeth(C$, 'setThreshold$D',  function (y) {
this.dialog.setText$O$S(this.txt1, p$1.getThreasholdText$D.apply(this, [y]));
});

Clazz.newMeth(C$, 'setComboSelected$I',  function (i) {
this.dialog.setSelectedIndex$O$I(this.combo1, i);
});

Clazz.newMeth(C$, 'applyFromFields$',  function () {
this.apply$OA(null);
});

Clazz.newMeth(C$, 'reEnable$',  function () {
p$1.paramsReEnable.apply(this, []);
return this;
});

Clazz.newMeth(C$, 'dispose$',  function () {
this.dialog.dispose$();
});

Clazz.newMeth(C$, 'setVisible$Z',  function (visible) {
this.dialog.setVisible$Z(visible);
});

Clazz.newMeth(C$, 'isVisible$',  function () {
return this.dialog.isVisible$();
});

Clazz.newMeth(C$, 'selectTableRow$I',  function (i) {
this.dialog.selectTableRow$I(i);
});

Clazz.newMeth(C$, 'repaint$',  function () {
this.dialog.repaint$();
});

Clazz.newMeth(C$, 'setFields$',  function () {
switch (this.type) {
case $I$(2).Integration:
break;
case $I$(2).Measurements:
break;
case $I$(2).NONE:
break;
case $I$(2).PeakList:
this.myParams=this.xyData.getParameters$();
this.setThreshold$D(this.myParams.peakListThreshold);
this.setComboSelected$I(this.myParams.peakListInterpolation.equals$O("none") ? 1 : 0);
p$1.createData.apply(this, []);
break;
case $I$(2).OverlayLegend:
break;
case $I$(2).Views:
break;
}
});

Clazz.newMeth(C$, 'setFocus$Z',  function (tf) {
this.dialog.setFocus$Z(tf);
});

Clazz.newMeth(C$, 'update$jspecview_common_Coordinate$D$I',  function (clicked, xRange, yOffset) {
this.selectTableRow$I(-1);
switch (this.type) {
case $I$(2).Integration:
this.loadData$();
this.checkEnables$();
break;
case $I$(2).Measurements:
this.loadData$();
this.checkEnables$();
break;
case $I$(2).NONE:
break;
case $I$(2).PeakList:
if (yOffset > 20) this.applyFromFields$();
if (this.xyData == null  || clicked == null   || yOffset > 20 ) return;
var ipt=0;
var dx0=1.0E100;
var xval=clicked.getXVal$();
var md=this.xyData;
var min=Math.abs(xRange / 20);
for (var i=md.size$(); --i >= 0; ) {
var dx=Math.abs(xval - md.get$I(i).getXVal$());
if (dx < dx0 ) {
dx0=dx;
ipt=i;
}}
if (dx0 < min ) {
this.selectTableRow$I(md.size$() - 2 - ipt );
this.repaint$();
}break;
case $I$(2).OverlayLegend:
break;
case $I$(2).Views:
break;
}
});

Clazz.newMeth(C$, 'getPeakData$',  function () {
var md=Clazz.new_([$I$(2).PeakList, this.$spec],$I$(3,1).c$$jspecview_common_Annotation_AType$jspecview_common_Spectrum);
md.setPeakList$jspecview_common_Parameters$I$jspecview_common_ScaleData(this.myParams, this.precision, this.jsvp.getPanelData$().getView$());
this.xyData=md;
return null;
});

Clazz.newMeth(C$, 'getData$',  function () {
if (this.xyData == null ) p$1.createData.apply(this, []);
return this.xyData;
});

Clazz.newMeth(C$, 'setData$jspecview_api_AnnotationData',  function (data) {
this.myParams=data.getParameters$();
this.xyData=data;
});

Clazz.newMeth(C$, 'setSpecShift$D',  function (dx) {
if (this.xyData != null ) this.xyData.setSpecShift$D(dx);
});

Clazz.newMeth(C$, 'setType$jspecview_common_Annotation_AType',  function (type) {
this.type=type;
switch (type) {
case $I$(2).Measurements:
this.addUnits=true;
break;
case $I$(2).Integration:
break;
case $I$(2).PeakList:
break;
case $I$(2).OverlayLegend:
break;
case $I$(2).Views:
break;
case $I$(2).NONE:
break;
}
});

Clazz.newMeth(C$, 'apply$OA',  function (objects) {
try {
switch (this.type) {
case $I$(2).Integration:
var offset=Double.parseDouble$S(objects[0]);
var scale=Double.parseDouble$S(objects[1]);
this.myParams.integralOffset=offset;
this.myParams.integralRange=scale;
this.myParams.integralDrawAll=false;
(this.getData$()).update$jspecview_common_Parameters(this.myParams);
break;
case $I$(2).Measurements:
break;
case $I$(2).NONE:
return;
case $I$(2).PeakList:
if (!this.skipCreate) {
this.setThreshold$D(NaN);
p$1.createData.apply(this, []);
}this.skipCreate=false;
break;
case $I$(2).OverlayLegend:
break;
case $I$(2).Views:
this.vwr.parameters.viewOffset=Double.parseDouble$S(objects[0]);
break;
}
this.loadData$();
this.checkEnables$();
this.jsvp.doRepaint$Z(true);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'done$',  function () {
if (this.jsvp != null  && this.$spec != null  ) this.jsvp.getPanelData$().removeDialog$jspecview_dialog_JSVDialog(this);
if (this.xyData != null ) this.xyData.setState$Z(this.isON);
p$1.saveDialogPosition$IA.apply(this, [this.getPosXY$()]);
this.dispose$();
this.jsvp.doRepaint$Z(true);
});

Clazz.newMeth(C$, 'restoreDialogPosition$jspecview_api_JSVPanel$IA',  function (panel, posXY) {
if (panel != null ) {
if (posXY[0] == -2147483648) {
posXY[0]=0;
posXY[1]=-20;
}var pt=this.manager.getLocationOnScreen$O(panel);
var height=panel.getHeight$();
this.loc=Clazz.array(Integer.TYPE, -1, [Math.max(0, pt[0] + posXY[0]), Math.max(0, pt[1] + height + posXY[1] )]);
this.dialog.setIntLocation$IA(this.loc);
}}, p$1);

Clazz.newMeth(C$, 'saveDialogPosition$IA',  function (posXY) {
try {
var pt=this.manager.getLocationOnScreen$O(this.dialog);
posXY[0]+=pt[0] - this.loc[0];
posXY[1]+=pt[1] - this.loc[1];
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'getThreasholdText$D',  function (y) {
if (Double.isNaN$D(y)) {
var pd=this.jsvp.getPanelData$();
var f=(pd.getSpectrum$().isInverted$() ? 0.1 : 0.9);
var c=pd.getClickedCoordinate$();
y=(c == null  ? (pd.getView$().minYOnScale * f + pd.getView$().maxYOnScale) * (1 - f) : c.getYVal$());
}var sy=$I$(4).formatDecimalDbl$D$I(y, y < 1000  ? 2 : -2);
return " " + sy;
}, p$1);

Clazz.newMeth(C$, 'checkVisible',  function () {
return this.vwr.pd$().getShowAnnotation$jspecview_common_Annotation_AType(this.type);
}, p$1);

Clazz.newMeth(C$, 'getUnitOptions',  function () {
var key=this.optionKey + "_format";
var format=this.options.get$O(key);
if (format == null ) this.options.put$O$O(key, format=Integer.valueOf$I(this.formatOptions[this.unitPtr == null  ? 0 : this.unitPtr.intValue$()]));
}, p$1);

Clazz.newMeth(C$, 'eventFocus$',  function () {
if (this.$spec != null ) this.jsvp.getPanelData$().jumpToSpectrum$jspecview_common_Spectrum(this.$spec);
switch (this.type) {
case $I$(2).Integration:
if (this.iRowSelected >= 0) {
++this.iRowSelected;
p$1.tableCellSelect$I$I.apply(this, [-1, -1]);
}break;
case $I$(2).Measurements:
break;
case $I$(2).NONE:
break;
case $I$(2).PeakList:
p$1.createData.apply(this, []);
this.skipCreate=true;
break;
case $I$(2).OverlayLegend:
break;
case $I$(2).Views:
break;
}
});

Clazz.newMeth(C$, 'eventApply$',  function () {
switch (this.type) {
case $I$(2).Integration:
break;
case $I$(2).Measurements:
break;
case $I$(2).NONE:
break;
case $I$(2).PeakList:
p$1.createData.apply(this, []);
this.skipCreate=true;
break;
case $I$(2).OverlayLegend:
break;
case $I$(2).Views:
break;
}
this.applyFromFields$();
});

Clazz.newMeth(C$, 'eventShowHide$Z',  function (isShow) {
this.isON=isShow;
if (isShow) this.eventApply$();
this.jsvp.doRepaint$Z(true);
this.checkEnables$();
}, p$1);

Clazz.newMeth(C$, 'clear',  function () {
this.setState$Z(true);
if (this.xyData != null ) {
this.xyData.clear$();
this.applyFromFields$();
}}, p$1);

Clazz.newMeth(C$, 'paramsReEnable',  function () {
switch (this.type) {
case $I$(2).Integration:
break;
case $I$(2).Measurements:
break;
case $I$(2).NONE:
break;
case $I$(2).PeakList:
this.skipCreate=true;
break;
case $I$(2).OverlayLegend:
break;
case $I$(2).Views:
break;
}
this.setVisible$Z(true);
this.isON=true;
this.applyFromFields$();
}, p$1);

Clazz.newMeth(C$, 'tableCellSelect$I$I',  function (iRow, iCol) {
System.out.println$S(iRow + " jSVDial " + iCol );
if (iRow < 0) {
iRow=(this.iRowColSelected/1000|0);
iCol=this.iRowColSelected % 1000;
this.iRowColSelected=-1;
}var value=this.tableData[iRow][1];
var icolrow=iRow * 1000 + iCol;
if (icolrow == this.iRowColSelected) return;
this.iRowColSelected=icolrow;
System.out.println$S("Setting rc = " + this.iRowColSelected + " " + this.$spec );
this.selectTableRow$I(this.iRowSelected);
try {
switch (this.type) {
case $I$(2).Integration:
this.callback$S$S("SHOWSELECTION", value.toString());
this.checkEnables$();
break;
case $I$(2).Measurements:
break;
case $I$(2).NONE:
break;
case $I$(2).PeakList:
try {
switch (iCol) {
case 6:
case 5:
case 4:
var x1=Double.parseDouble$S(value);
var x2=Double.parseDouble$S(this.tableData[iRow + 3 - iCol][1]);
this.jsvp.getPanelData$().setXPointers$jspecview_common_Spectrum$D$jspecview_common_Spectrum$D(this.$spec, x1, this.$spec, x2);
break;
default:
this.jsvp.getPanelData$().findX$jspecview_common_Spectrum$D(this.$spec, Double.parseDouble$S(value));
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.jsvp.getPanelData$().findX$jspecview_common_Spectrum$D(this.$spec, 1.0E100);
} else {
throw e;
}
}
this.jsvp.doRepaint$Z(false);
break;
case $I$(2).OverlayLegend:
this.jsvp.getPanelData$().setSpectrum$I$Z(iRow, false);
break;
case $I$(2).Views:
break;
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'loadData$',  function () {
var data;
var header;
var widths;
switch (this.type) {
case $I$(2).Integration:
if (this.xyData == null ) p$1.createData.apply(this, []);
this.iSelected=-1;
data=(this.xyData).getMeasurementListArray$S(null);
header=this.xyData.getDataHeader$();
widths=Clazz.array(Integer.TYPE, -1, [40, 65, 65, 50]);
this.createTable$OAA$SA$IA(data, header, widths);
break;
case $I$(2).Measurements:
if (this.xyData == null ) return;
data=this.xyData.getMeasurementListArray$S(this.dialog.getSelectedItem$O(this.combo1).toString());
header=this.xyData.getDataHeader$();
widths=Clazz.array(Integer.TYPE, -1, [40, 65, 65, 50]);
this.createTable$OAA$SA$IA(data, header, widths);
break;
case $I$(2).NONE:
break;
case $I$(2).PeakList:
if (this.xyData == null ) p$1.createData.apply(this, []);
data=(this.xyData).getMeasurementListArray$S(null);
header=(this.xyData).getDataHeader$();
widths=Clazz.array(Integer.TYPE, -1, [40, 65, 50, 50, 50, 50, 50]);
this.createTable$OAA$SA$IA(data, header, widths);
this.setTableSelectionEnabled$Z(true);
break;
case $I$(2).OverlayLegend:
header=Clazz.array(String, -1, ["No.", "Plot Color", "Title"]);
data=this.vwr.selectedPanel.getPanelData$().getOverlayLegendData$();
widths=Clazz.array(Integer.TYPE, -1, [30, 60, 250]);
this.createTable$OAA$SA$IA(data, header, widths);
this.setTableSelectionEnabled$Z(true);
break;
case $I$(2).Views:
break;
}
});

Clazz.newMeth(C$, 'createData',  function () {
switch (this.type) {
case $I$(2).Integration:
this.xyData=Clazz.new_($I$(5,1).c$$jspecview_common_Spectrum$jspecview_common_Parameters,[this.$spec, this.myParams]);
this.iSelected=-1;
break;
case $I$(2).Measurements:
break;
case $I$(2).NONE:
break;
case $I$(2).PeakList:
try {
var thresh=Double.parseDouble$S(this.dialog.getText$O(this.txt1));
this.myParams.peakListThreshold=thresh;
this.myParams.peakListInterpolation=this.dialog.getSelectedItem$O(this.combo1).toString();
this.myParams.precision=this.precision;
var md=Clazz.new_([$I$(2).PeakList, this.$spec],$I$(3,1).c$$jspecview_common_Annotation_AType$jspecview_common_Spectrum);
md.setPeakList$jspecview_common_Parameters$I$jspecview_common_ScaleData(this.myParams, this.precision, this.jsvp.getPanelData$().getView$());
this.xyData=md;
this.loadData$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
break;
case $I$(2).OverlayLegend:
break;
case $I$(2).Views:
break;
}
}, p$1);

Clazz.newMeth(C$, 'setPrecision$I',  function (i) {
this.precision=this.formatOptions[i];
}, p$1);

Clazz.newMeth(C$, 'tableSelect$S',  function (url) {
var isAdjusting="true".equals$O(p$1.getField$S$S.apply(this, [url, "adjusting"]));
if (isAdjusting) {
this.iColSelected=this.iRowSelected=-1;
System.out.println$S("adjusting" + url);
return;
}var index=$I$(6,"parseInt$S",[p$1.getField$S$S.apply(this, [url, "index"])]);
switch ("ROW COL ROWCOL".indexOf$S(p$1.getField$S$S.apply(this, [url, "selector"]))) {
case 8:
this.iColSelected=$I$(6,"parseInt$S",[p$1.getField$S$S.apply(this, [url, "index2"])]);
case 0:
this.iRowSelected=index;
System.out.println$S("r set to " + index);
break;
case 4:
this.iColSelected=index;
System.out.println$S("c set to " + index);
break;
}
if (this.iColSelected >= 0 && this.iRowSelected >= 0 ) {
p$1.tableCellSelect$I$I.apply(this, [this.iRowSelected, this.iColSelected]);
}}, p$1);

Clazz.newMeth(C$, 'getField$S$S',  function (url, name) {
url+="&";
var key="&" + name + "=" ;
var pt=url.indexOf$S(key);
return (pt < 0 ? null : url.substring$I$I(pt + key.length$(), url.indexOf$S$I("&", pt + 1)));
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:06 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
