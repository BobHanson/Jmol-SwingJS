(function(){var P$=Clazz.newPackage("jspecview.dialog"),p$1={},I$=[[0,'java.util.Hashtable','jspecview.common.JSVFileManager','jspecview.common.JSViewer','javajs.util.PT']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DialogManager");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['vwr','jspecview.common.JSViewer','htSelectors','java.util.Map','+htDialogs','+options']]]

Clazz.newMeth(C$, 'set$jspecview_common_JSViewer',  function (viewer) {
this.vwr=viewer;
this.htSelectors=Clazz.new_($I$(1,1));
this.htDialogs=Clazz.new_($I$(1,1));
return this;
});

Clazz.newMeth(C$, 'registerDialog$jspecview_dialog_JSVDialog',  function (jsvDialog) {
var id=jsvDialog.optionKey;
if (!id.endsWith$S("!")) id+=" " + ("" + new Double(Math.random()).toString()).substring$I(3);
if (this.htDialogs.containsKey$O(id)) this.htDialogs.get$O(id).dispose$();
this.htDialogs.put$O$O(id, jsvDialog);
return id;
});

Clazz.newMeth(C$, 'registerSelector$S$O',  function (selectorName, columnSelector) {
this.htSelectors.put$O$O(columnSelector, selectorName);
});

Clazz.newMeth(C$, 'getSelectorName$O',  function (selector) {
return this.htSelectors.get$O(selector);
});

Clazz.newMeth(C$, 'showSourceErrors$O$jspecview_source_JDXSource',  function (frame, currentSource) {
if (currentSource == null ) {
this.showMessageDialog$O$S$S$I(frame, "Please Select a Spectrum.", "Select Spectrum", 2);
return;
}var errorLog=currentSource.getErrorLog$();
if (errorLog != null  && errorLog.length$() > 0 ) this.showMessage$O$S$S(frame, errorLog, C$.fixTitle$S(currentSource.getFilePath$()));
 else this.showMessageDialog$O$S$S$I(frame, "No errors found.", "Error Log", 1);
});

Clazz.newMeth(C$, 'showSource$O$jspecview_common_Spectrum',  function (frame, spec) {
var filePath=spec.getFilePath$();
if (filePath == null ) {
this.showMessageDialog$O$S$S$I(frame, "Please Select a Spectrum", "Select Spectrum", 2);
return;
}if (filePath === "[inline]" ) {
this.showMessage$O$S$S(null, spec.getInlineData$(), "Inline data");
return;
}try {
var s=$I$(2).getFileAsString$S(filePath);
if ($I$(3).isJS) s=$I$(4).rep$S$S$S(s, "<", "&lt;");
this.showMessage$O$S$S(null, s, C$.fixTitle$S(filePath));
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
this.showMessageDialog$O$S$S$I(frame, "File Not Found", "SHOWSOURCE", 0);
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'processClick$S',  function (eventId) {
var pt=eventId.lastIndexOf$S("/");
var id=eventId.substring$I(pt + 1);
var dialog=eventId.substring$I$I(0, pt);
p$1.dialogCallback$S$S$S.apply(this, [dialog, id, null]);
});

Clazz.newMeth(C$, 'processTableEvent$S$I$I$Z',  function (eventId, index1, index2, adjusting) {
var pt=eventId.lastIndexOf$S("/");
var dialog=eventId.substring$I$I(0, pt);
var selector=eventId.substring$I(pt + 1);
var msg="&selector=" + selector + "&index=" + index1 + (index2 < 0 ? "&adjusting=" + adjusting : "&index2=" + index2) ;
p$1.dialogCallback$S$S$S.apply(this, [dialog, "tableSelect", msg]);
});

Clazz.newMeth(C$, 'processWindowClosing$S',  function (dialogId) {
p$1.dialogCallback$S$S$S.apply(this, [dialogId, "windowClosing", null]);
this.htDialogs.remove$O(dialogId);
});

Clazz.newMeth(C$, 'dialogCallback$S$S$S',  function (dialogId, id, msg) {
var jsvDialog=this.htDialogs.get$O(dialogId);
if (jsvDialog != null ) jsvDialog.callback$S$S(id, msg);
}, p$1);

Clazz.newMeth(C$, 'getDialogOptions$',  function () {
if (this.options == null ) this.options=Clazz.new_($I$(1,1));
return this.options;
});

Clazz.newMeth(C$, 'fixTitle$S',  function (title) {
return (title.length$() > 50 ? title.substring$I$I(0, 50) + "..." : title);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:57 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
