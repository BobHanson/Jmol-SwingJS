(function(){var P$=Clazz.newPackage("jspecview.dialog"),p$1={},I$=[[0,['jspecview.common.Annotation','.AType'],'javajs.util.Lst','javajs.util.PT','javajs.util.SB']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ViewsDialog", null, 'jspecview.dialog.JSVDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.checking=false;
},1);

C$.$fields$=[['Z',['checking'],'O',['treeNodes','javajs.util.Lst','+checkBoxes','closeSelectedButton','java.lang.Object','+combineSelectedButton','+viewSelectedButton']]
,['O',['posXY','int[]']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.type=$I$(1).Views;
}, 1);

Clazz.newMeth(C$, 'getPosXY$',  function () {
return C$.posXY;
});

Clazz.newMeth(C$, 'addUniqueControls$',  function () {
this.checkBoxes=Clazz.new_($I$(2,1));
this.treeNodes=Clazz.new_($I$(2,1));
this.dialog.addButton$S$S("btnSelectAll", "Select All");
this.dialog.addButton$S$S("btnSelectNone", "Select None");
this.txt2=this.dialog.addTextField$S$S$S$S$S$Z("txtOffset", "Offset", "" + new Double(this.vwr.parameters.viewOffset).toString(), "%", null, true);
this.viewSelectedButton=this.dialog.addButton$S$S("btnViewSelected", "View Selected");
this.combineSelectedButton=this.dialog.addButton$S$S("btnCombineSelected", "Combine Selected");
this.closeSelectedButton=this.dialog.addButton$S$S("btnCloseSelected", "Close Selected");
this.dialog.addButton$S$S("btnDone", "Done");
this.dialog.setPreferredSize$I$I(800, 350);
this.txt1=this.dialog.addCheckBox$S$S$I$Z(null, null, 0, false);
p$1.addCheckBoxes$jspecview_api_JSVTreeNode$I$Z.apply(this, [this.vwr.spectraTree.getRootNode$(), 0, true]);
p$1.addCheckBoxes$jspecview_api_JSVTreeNode$I$Z.apply(this, [this.vwr.spectraTree.getRootNode$(), 0, false]);
});

Clazz.newMeth(C$, 'addCheckBoxes$jspecview_api_JSVTreeNode$I$Z',  function (rootNode, level, isViews) {
var enume=rootNode.children$();
while (enume.hasMoreElements$()){
var treeNode=enume.nextElement$();
var node=treeNode.getPanelNode$();
if (node.isView != isViews ) continue;
var title=node.toString();
if (title.indexOf$S("\n") >= 0) title=title.substring$I$I(0, title.indexOf$I("\n"));
var name="chkBox" + this.treeNodes.size$();
var cb=this.dialog.addCheckBox$S$S$I$Z(name, title, level, node.isSelected);
treeNode.setIndex$I(this.treeNodes.size$());
this.treeNodes.addLast$O(treeNode);
this.checkBoxes.addLast$O(cb);
p$1.addCheckBoxes$jspecview_api_JSVTreeNode$I$Z.apply(this, [treeNode, level + 1, isViews]);
}
}, p$1);

Clazz.newMeth(C$, 'checkEnables$',  function () {
var n=0;
for (var i=0; i < this.checkBoxes.size$(); i++) {
if (this.dialog.isSelected$O(this.checkBoxes.get$I(i)) && this.treeNodes.get$I(i).getPanelNode$().jsvp != null  ) {
++n;
}}
System.out.println$S("viewsdialog n=" + n);
this.dialog.setEnabled$O$Z(this.closeSelectedButton, n > 0);
this.dialog.setEnabled$O$Z(this.combineSelectedButton, n > 1);
this.dialog.setEnabled$O$Z(this.viewSelectedButton, n == 1);
});

Clazz.newMeth(C$, 'check$S',  function (name) {
var i=$I$(3,"parseInt$S",[name.substring$I(name.indexOf$S("_") + 1)]);
var node=this.treeNodes.get$I(i);
var cb=this.checkBoxes.get$I(i);
var isSelected=this.dialog.isSelected$O(cb);
if (node.getPanelNode$().jsvp == null ) {
if (!this.checking && isSelected && this.dialog.getText$O(cb).startsWith$S("Overlay")  ) {
this.checking=true;
this.selectAll$Z(false);
this.dialog.setSelected$O$Z(cb, true);
node.getPanelNode$().isSelected=true;
this.checking=false;
}var enume=node.children$();
while (enume.hasMoreElements$()){
var treeNode=enume.nextElement$();
this.dialog.setSelected$O$Z(this.checkBoxes.get$I(treeNode.getIndex$()), isSelected);
treeNode.getPanelNode$().isSelected=isSelected;
node.getPanelNode$().isSelected=isSelected;
}
} else {
node.getPanelNode$().isSelected=isSelected;
}if (isSelected) for (i=this.treeNodes.size$(); --i >= 0; ) if (this.treeNodes.get$I(i).getPanelNode$().isView != node.getPanelNode$().isView ) {
this.dialog.setSelected$O$Z(this.checkBoxes.get$I(this.treeNodes.get$I(i).getIndex$()), false);
this.treeNodes.get$I(i).getPanelNode$().isSelected=false;
}
this.checkEnables$();
});

Clazz.newMeth(C$, 'selectAll$Z',  function (mode) {
for (var i=this.checkBoxes.size$(); --i >= 0; ) {
this.dialog.setSelected$O$Z(this.checkBoxes.get$I(i), mode);
this.treeNodes.get$I(i).getPanelNode$().isSelected=mode;
}
this.checkEnables$();
});

Clazz.newMeth(C$, 'combineSelected$',  function () {
});

Clazz.newMeth(C$, 'viewSelected$',  function () {
var sb=Clazz.new_($I$(4,1));
var thisNode=null;
var n=0;
for (var i=0; i < this.checkBoxes.size$(); i++) {
var cb=this.checkBoxes.get$I(i);
var node=this.treeNodes.get$I(i).getPanelNode$();
if (this.dialog.isSelected$O(cb) && node.jsvp != null  ) {
if (node.isView) {
thisNode=node;
n=2;
break;
}++n;
var label=this.dialog.getText$O(cb);
sb.append$S(" ").append$S(label.substring$I$I(0, label.indexOf$S(":")));
}}
var script=null;
if (n > 1) {
this.eventApply$();
script="STACKOFFSETY " + new Double(this.vwr.parameters.viewOffset).toString();
}if (thisNode == null ) {
this.vwr.execView$S$Z(sb.toString().trim$(), false);
this.layoutDialog$();
} else {
this.vwr.setNode$jspecview_common_PanelNode(thisNode);
}if (script != null ) this.vwr.runScript$S(script);
});

Clazz.newMeth(C$, 'closeSelected$',  function () {
this.vwr.runScript$S("close !selected");
this.layoutDialog$();
});

Clazz.newMeth(C$, 'callback$S$S',  function (id, msg) {
if (id.equals$O("btnSelectAll")) {
this.selectAll$Z(true);
} else if (id.equals$O("btnSelectNone")) {
this.selectAll$Z(false);
} else if (id.equals$O("btnViewSelected")) {
this.viewSelected$();
} else if (id.equals$O("btnCombineSelected")) {
this.viewSelected$();
} else if (id.equals$O("btnCloseSelected")) {
this.closeSelected$();
} else if (id.equals$O("btnDone")) {
this.viewSelected$();
this.dispose$();
this.done$();
} else if (id.equals$O("txtOffset")) {
this.eventApply$();
this.viewSelected$();
} else if (id.startsWith$S("chk")) {
this.checkEnables$();
} else {
return this.callbackAD$S$S(id, msg);
}return true;
});

Clazz.newMeth(C$, 'applyFromFields$',  function () {
this.apply$OA(Clazz.array(java.lang.Object, -1, [this.dialog.getText$O(this.txt2)]));
});

C$.$static$=function(){C$.$static$=0;
C$.posXY=Clazz.array(Integer.TYPE, -1, [-2147483648, 0]);
};
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:52 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
