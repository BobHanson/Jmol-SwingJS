(function(){var P$=Clazz.newPackage("jspecview.api"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "JSVZipReader");
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:51 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
