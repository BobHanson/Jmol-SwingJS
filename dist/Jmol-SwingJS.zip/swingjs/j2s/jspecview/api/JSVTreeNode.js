(function(){var P$=Clazz.newPackage("jspecview.api"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "JSVTreeNode", null, null, 'javax.swing.tree.TreeNode');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:03 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
