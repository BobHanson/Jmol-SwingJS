(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[[0,'java.util.Hashtable','jspecview.common.ScriptToken']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Parameters");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.integralMinY=0.1;
this.integralRange=50.0;
this.integralOffset=30.0;
this.integralDrawAll=false;
this.viewOffset=0;
this.peakListThreshold=NaN;
this.peakListInterpolation="parabolic";
this.precision=2;
},1);

C$.$fields$=[['Z',['integralDrawAll'],'D',['integralMinY','integralRange','integralOffset','viewOffset','peakListThreshold'],'I',['precision'],'S',['name','peakListInterpolation'],'O',['htBooleans','java.util.Map']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.htBooleans=Clazz.new_($I$(1,1));
this.setBoolean$jspecview_common_ScriptToken$Z($I$(2).TITLEON, true);
this.setBoolean$jspecview_common_ScriptToken$Z($I$(2).ENABLEZOOM, true);
this.setBoolean$jspecview_common_ScriptToken$Z($I$(2).DISPLAY2D, true);
this.setBoolean$jspecview_common_ScriptToken$Z($I$(2).COORDINATESON, true);
this.setBoolean$jspecview_common_ScriptToken$Z($I$(2).PEAKTABSON, true);
this.setBoolean$jspecview_common_ScriptToken$Z($I$(2).POINTSONLY, false);
this.setBoolean$jspecview_common_ScriptToken$Z($I$(2).GRIDON, true);
this.setBoolean$jspecview_common_ScriptToken$Z($I$(2).XSCALEON, true);
this.setBoolean$jspecview_common_ScriptToken$Z($I$(2).YSCALEON, true);
this.setBoolean$jspecview_common_ScriptToken$Z($I$(2).XUNITSON, true);
this.setBoolean$jspecview_common_ScriptToken$Z($I$(2).YUNITSON, true);
}, 1);

Clazz.newMeth(C$, 'setName$S',  function (name) {
this.name=name;
return this;
});

Clazz.newMeth(C$, 'getBooleans$',  function () {
return this.htBooleans;
});

Clazz.newMeth(C$, 'setBoolean$jspecview_common_ScriptToken$Z',  function (st, val) {
this.htBooleans.put$O$O(st, Boolean.valueOf$Z(val));
return val;
});

Clazz.newMeth(C$, 'getBoolean$jspecview_common_ScriptToken',  function (t) {
return Boolean.TRUE === this.htBooleans.get$O(t) ;
});

Clazz.newMeth(C$, 'isTrue$S',  function (value) {
return (value.length$() == 0 || Boolean.parseBoolean$S(value) );
}, 1);

Clazz.newMeth(C$, 'getTFToggle$S',  function (value) {
return (value.equalsIgnoreCase$S("TOGGLE") ? null : C$.isTrue$S(value) ? Boolean.TRUE : Boolean.FALSE);
}, 1);

Clazz.newMeth(C$, 'setP$jspecview_common_PanelData$jspecview_common_ScriptToken$S',  function (pd, st, value) {
switch (st) {
default:
return;
case $I$(2).COORDINATESON:
case $I$(2).DISPLAY1D:
case $I$(2).DISPLAY2D:
case $I$(2).ENABLEZOOM:
case $I$(2).GRIDON:
case $I$(2).POINTSONLY:
case $I$(2).PEAKTABSON:
case $I$(2).REVERSEPLOT:
case $I$(2).TITLEON:
case $I$(2).TITLEBOLDON:
case $I$(2).XSCALEON:
case $I$(2).XUNITSON:
case $I$(2).YSCALEON:
case $I$(2).YUNITSON:
var tfToggle=C$.getTFToggle$S(value);
if (tfToggle != null ) {
this.setBoolean$jspecview_common_ScriptToken$Z(st, tfToggle.booleanValue$());
break;
}if (pd == null ) return;
var b=!pd.getBoolean$jspecview_common_ScriptToken(st);
switch (st) {
default:
break;
case $I$(2).XSCALEON:
this.setBoolean$jspecview_common_ScriptToken$Z($I$(2).XUNITSON, b);
pd.setBoolean$jspecview_common_ScriptToken$Z($I$(2).XUNITSON, b);
break;
case $I$(2).YSCALEON:
this.setBoolean$jspecview_common_ScriptToken$Z($I$(2).YUNITSON, b);
pd.setBoolean$jspecview_common_ScriptToken$Z($I$(2).YUNITSON, b);
break;
}
this.setBoolean$jspecview_common_ScriptToken$Z(st, b);
break;
}
if (pd == null ) return;
pd.setBooleans$jspecview_common_Parameters$jspecview_common_ScriptToken(this, st);
});

Clazz.newMeth(C$, 'isMatch$S$S',  function (match, key) {
return match == null  || key.equalsIgnoreCase$S(match) ;
}, 1);

Clazz.newMeth(C$, 'putInfo$S$java_util_Map$S$O',  function (match, info, key, value) {
if (value != null  && C$.isMatch$S$S(match, key) ) info.put$O$O(match == null  ? key : match, value);
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:57 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
