(function(){var P$=Clazz.newPackage("jspecview.common"),p$1={},I$=[[0,'javajs.util.Lst','java.util.Hashtable','jspecview.common.Parameters','jspecview.common.ScriptToken',['jspecview.common.PanelData','.LinkMode'],'jspecview.common.GraphSet','jspecview.common.JSVersion','jspecview.common.ZoomEvent','jspecview.common.Coordinate','org.jmol.util.Font','jspecview.common.SubSpecChangeEvent','jspecview.common.PeakPickEvent',['jspecview.common.PanelData','.Mouse'],'jspecview.common.Spectrum','javajs.util.CU','org.jmol.util.Logger','jspecview.common.JSVFileManager',['jspecview.common.Annotation','.AType'],'jspecview.common.MeasurementData','jspecview.common.JSViewer']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PanelData", function(){
Clazz.newInstance(this, arguments,0,C$);
}, null, 'org.jmol.api.EventManager');
C$.$classes$=[['LinkMode',25],['Mouse',26]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.listeners=Clazz.new_($I$(1,1));
this.options=Clazz.new_($I$(2,1));
this.xAxisLeftToRight=true;
this.scalingFactor=1;
this.left=60;
this.right=50;
this.coordStr="";
this.startupPinTip="Click to set.";
this.doReset=true;
this.printGraphPosition="default";
this.taintedAll=true;
},1);

C$.$fields$=[['Z',['ctrlPressed','shiftPressed','drawXAxisLeftToRight','isIntegralDrag','xAxisLeftToRight','isPrinting','doReset','titleDrawn','display1D','isLinked','taintedAll','testingJavaScript','gridOn','titleOn','peakTabsOn','linking'],'I',['currentSplitPoint','scalingFactor','integralShiftMode','left','right','clickCount','nSpectra','thisWidth','thisHeight','startIndex','endIndex','mouseX','mouseY','xPixelClicked'],'S',['coordStr','startupPinTip','title','commonFilePath','viewTitle','displayFontName','titleFontName','printingFontName','printGraphPosition','printJobTitle'],'O',['g2d','org.jmol.api.GenericGraphics','+g2d0','vwr','jspecview.common.JSViewer','listeners','javajs.util.Lst','currentGraphSet','jspecview.common.GraphSet','options','java.util.Hashtable','jsvp','jspecview.api.JSVPanel','graphSets','javajs.util.Lst','thisWidget','jspecview.common.PlotWidget','coordClicked','jspecview.common.Coordinate','coordsClicked','jspecview.common.Coordinate[]','spectra','javajs.util.Lst','currentFont','org.jmol.util.Font','mouseState','jspecview.common.PanelData.Mouse','coordinatesColor','javajs.api.GenericColor','+gridColor','+integralPlotColor','+peakTabColor','+plotAreaColor','+scaleColor','+titleColor','+unitsColor','+highlightColor','+zoomBoxColor','+zoomBoxColor2','+BLACK','+bgcolor','optionsSaved','java.util.Hashtable','gMain','java.lang.Object']]]

Clazz.newMeth(C$, 'c$$jspecview_api_JSVPanel$jspecview_common_JSViewer',  function (panel, viewer) {
;C$.$init$.apply(this);
this.vwr=viewer;
this.jsvp=panel;
this.g2d=this.g2d0=viewer.g2d;
this.BLACK=this.g2d.getColor1$I(0);
this.highlightColor=this.g2d.getColor4$I$I$I$I(255, 0, 0, 200);
this.zoomBoxColor=this.g2d.getColor4$I$I$I$I(150, 150, 100, 130);
this.zoomBoxColor2=this.g2d.getColor4$I$I$I$I(150, 100, 100, 130);
}, 1);

Clazz.newMeth(C$, 'addListener$jspecview_api_PanelListener',  function (listener) {
if (!this.listeners.contains$O(listener)) {
this.listeners.addLast$O(listener);
}});

Clazz.newMeth(C$, 'getCurrentGraphSet$',  function () {
return this.currentGraphSet;
});

Clazz.newMeth(C$, 'dispose$',  function () {
this.jsvp=null;
for (var i=0; i < this.graphSets.size$(); i++) this.graphSets.get$I(i).dispose$();

this.graphSets=null;
this.currentFont=null;
this.currentGraphSet=null;
this.coordClicked=null;
this.coordsClicked=null;
this.thisWidget=null;
this.options=null;
this.listeners=null;
});

Clazz.newMeth(C$, 'setViewTitle$S',  function (title) {
this.viewTitle=title;
});

Clazz.newMeth(C$, 'getViewTitle$',  function () {
return (this.viewTitle == null  ? this.getTitle$() : this.viewTitle);
});

Clazz.newMeth(C$, 'getInfo$Z$S',  function (selectedOnly, key) {
var info=Clazz.new_($I$(2,1));
var sets=null;
if (selectedOnly) return this.currentGraphSet.getInfo$S$I(key, this.getCurrentSpectrumIndex$());
var entries=this.options.entrySet$();
if ("".equals$O(key)) {
var val="type title nSets ";
for (var entry, $entry = entries.iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) val+=entry.getKey$().name$() + " ";

info.put$O$O("KEYS", val);
} else {
for (var entry, $entry = entries.iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) $I$(3,"putInfo$S$java_util_Map$S$O",[key, info, entry.getKey$().name$(), entry.getValue$()]);

$I$(3,"putInfo$S$java_util_Map$S$O",[key, info, "type", this.getSpectrumAt$I(0).getDataType$()]);
$I$(3).putInfo$S$java_util_Map$S$O(key, info, "title", this.title);
$I$(3,"putInfo$S$java_util_Map$S$O",[key, info, "nSets", Integer.valueOf$I(this.graphSets.size$())]);
}sets=Clazz.new_($I$(1,1));
for (var i=this.graphSets.size$(); --i >= 0; ) sets.addLast$O(this.graphSets.get$I(i).getInfo$S$I(key, -1));

info.put$O$O("sets", sets);
return info;
});

Clazz.newMeth(C$, 'setBooleans$jspecview_common_Parameters$jspecview_common_ScriptToken',  function (parameters, st) {
if (st == null ) {
var booleans=parameters.getBooleans$();
for (var entry, $entry = booleans.entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) this.setBooleans$jspecview_common_Parameters$jspecview_common_ScriptToken(parameters, entry.getKey$());

return;
}this.setBoolean$jspecview_common_ScriptToken$Z(st, parameters.getBoolean$jspecview_common_ScriptToken(st));
});

Clazz.newMeth(C$, 'setBoolean$jspecview_common_ScriptToken$Z',  function (st, isTrue) {
this.setTaintedAll$();
if (st === $I$(4).REVERSEPLOT ) {
this.currentGraphSet.setReversePlot$Z(isTrue);
return;
}this.options.put$O$O(st, Boolean.valueOf$Z(isTrue));
switch (st) {
case $I$(4).DISPLAY1D:
case $I$(4).DISPLAY2D:
this.doReset=true;
break;
}
});

Clazz.newMeth(C$, 'getBoolean$jspecview_common_ScriptToken',  function (st) {
if (st === $I$(4).REVERSEPLOT ) return this.currentGraphSet.reversePlot;
if (this.options == null ) return false;
var b=this.options.get$O(st);
return (b != null  && (Clazz.instanceOf(b, "java.lang.Boolean"))  && (b) === Boolean.TRUE  );
});

Clazz.newMeth(C$, 'setFontName$jspecview_common_ScriptToken$S',  function (st, fontName) {
switch (st) {
case $I$(4).DISPLAYFONTNAME:
this.displayFontName=fontName;
break;
case $I$(4).TITLEFONTNAME:
this.titleFontName=fontName;
break;
}
if (fontName != null ) this.options.put$O$O(st, fontName);
});

Clazz.newMeth(C$, 'getDisplay1D$',  function () {
return this.display1D;
});

Clazz.newMeth(C$, 'setTaintedAll$',  function () {
this.taintedAll=true;
});

Clazz.newMeth(C$, 'initOne$jspecview_common_Spectrum',  function (spectrum) {
this.spectra=Clazz.new_($I$(1,1));
this.spectra.addLast$O(spectrum);
this.initMany$javajs_util_Lst$I$I(this.spectra, 0, 0);
});

Clazz.newMeth(C$, 'initMany$javajs_util_Lst$I$I',  function (spectra, startIndex, endIndex) {
this.startIndex=startIndex;
this.endIndex=endIndex;
this.nSpectra=spectra.size$();
this.spectra=spectra;
this.commonFilePath=spectra.get$I(0).getFilePath$();
for (var i=0; i < this.nSpectra; i++) if (!this.commonFilePath.equalsIgnoreCase$S(spectra.get$I(i).getFilePath$())) {
this.commonFilePath=null;
break;
}
p$1.setGraphSets$jspecview_common_PanelData_LinkMode.apply(this, [$I$(5).NONE]);
});

Clazz.newMeth(C$, 'setGraphSets$jspecview_common_PanelData_LinkMode',  function (linkMode) {
this.graphSets=$I$(6).createGraphSetsAndSetLinkMode$jspecview_common_PanelData$jspecview_api_JSVPanel$javajs_util_Lst$I$I$jspecview_common_PanelData_LinkMode(this, this.jsvp, this.spectra, this.startIndex, this.endIndex, linkMode);
this.currentGraphSet=this.graphSets.get$I(0);
this.title=this.getSpectrum$().getTitleLabel$();
}, p$1);

Clazz.newMeth(C$, 'findMatchingPeakInfo$jspecview_common_PeakInfo',  function (pi) {
var pi2=null;
for (var i=0; i < this.graphSets.size$(); i++) if ((pi2=this.graphSets.get$I(i).findMatchingPeakInfo$jspecview_common_PeakInfo(pi)) != null ) break;

return pi2;
});

Clazz.newMeth(C$, 'integrateAll$jspecview_common_ColorParameters',  function (parameters) {
for (var i=this.graphSets.size$(); --i >= 0; ) this.graphSets.get$I(i).integrate$I$jspecview_common_Parameters(-1, parameters);

});

Clazz.newMeth(C$, 'getNumberOfGraphSets$',  function () {
return this.graphSets.size$();
});

Clazz.newMeth(C$, 'getTitle$',  function () {
return this.title;
});

Clazz.newMeth(C$, 'refresh$',  function () {
this.doReset=true;
});

Clazz.newMeth(C$, 'addAnnotation$javajs_util_Lst',  function (tokens) {
var title=this.currentGraphSet.addAnnotation$javajs_util_Lst$S(tokens, this.getTitle$());
if (title != null ) this.title=title;
});

Clazz.newMeth(C$, 'addPeakHighlight$jspecview_common_PeakInfo',  function (peakInfo) {
for (var i=0; i < this.graphSets.size$(); i++) this.graphSets.get$I(i).addPeakHighlight$jspecview_common_PeakInfo(peakInfo);

});

Clazz.newMeth(C$, 'selectPeakByFileIndex$S$S$S',  function (filePath, index, atomKey) {
var pi=this.currentGraphSet.selectPeakByFileIndex$S$S$S(filePath, index, atomKey);
if (pi == null ) for (var i=this.graphSets.size$(); --i >= 0; ) if (this.graphSets.get$I(i) !== this.currentGraphSet  && (pi=this.graphSets.get$I(i).selectPeakByFileIndex$S$S$S(filePath, index, atomKey)) != null  ) break;

return pi;
});

Clazz.newMeth(C$, 'setPlotColors$javajs_api_GenericColorA',  function (colors) {
for (var i=this.graphSets.size$(); --i >= 0; ) this.graphSets.get$I(i).setPlotColors$O(colors);

});

Clazz.newMeth(C$, 'selectSpectrum$S$S$S$Z',  function (filePath, type, model, andCurrent) {
if (andCurrent) this.currentGraphSet.selectSpectrum$S$S$S(filePath, type, model);
if ("ID".equals$O(type)) {
this.jumpToSpectrumIndex$I$Z(this.getCurrentSpectrumIndex$(), true);
return;
}for (var i=0; i < this.graphSets.size$(); i++) if (this.graphSets.get$I(i) !== this.currentGraphSet ) this.graphSets.get$I(i).selectSpectrum$S$S$S(filePath, type, model);

});

Clazz.newMeth(C$, 'hasFileLoaded$S',  function (filePath) {
for (var i=this.graphSets.size$(); --i >= 0; ) if (this.graphSets.get$I(i).hasFileLoaded$S(filePath)) return true;

return false;
});

Clazz.newMeth(C$, 'clearAllView$',  function () {
for (var i=this.graphSets.size$(); --i >= 0; ) this.graphSets.get$I(i).resetViewCompletely$();

});

Clazz.newMeth(C$, 'drawGraph$O$O$O$I$I$Z',  function (gMain, gFront, gRear, width, height, addFilePath) {
var withCoords;
this.gMain=gMain;
this.display1D=!this.isLinked && this.getBoolean$jspecview_common_ScriptToken($I$(4).DISPLAY1D) ;
var top=40;
var bottom=50;
var isResized=(this.isPrinting || this.doReset || this.thisWidth != width   || this.thisHeight != height );
if (isResized) this.setTaintedAll$();
if (this.taintedAll) this.g2d.fillBackground$O$javajs_api_GenericColor(gRear, this.bgcolor);
if (gFront !== gMain ) {
this.g2d.fillBackground$O$javajs_api_GenericColor(gFront, null);
if (gMain !== gRear ) this.g2d.fillBackground$O$javajs_api_GenericColor(gMain, null);
this.g2d.setStrokeBold$O$Z(gMain, false);
}if (this.isPrinting) {
top*=3;
bottom*=3;
this.scalingFactor=10;
withCoords=false;
} else {
this.scalingFactor=1;
withCoords=this.getBoolean$jspecview_common_ScriptToken($I$(4).COORDINATESON);
this.titleOn=this.getBoolean$jspecview_common_ScriptToken($I$(4).TITLEON);
this.gridOn=this.getBoolean$jspecview_common_ScriptToken($I$(4).GRIDON);
this.peakTabsOn=this.getBoolean$jspecview_common_ScriptToken($I$(4).PEAKTABSON);
}var pointsOnly=this.getBoolean$jspecview_common_ScriptToken($I$(4).POINTSONLY);
this.doReset=false;
this.titleDrawn=false;
this.thisWidth=width;
this.thisHeight=height;
for (var i=this.graphSets.size$(); --i >= 0; ) this.graphSets.get$I(i).drawGraphSet$O$O$O$I$I$I$I$I$I$Z$Z$Z(gMain, gFront, gRear, width, height, this.left, this.right, top, bottom, isResized, this.taintedAll, pointsOnly);

if (this.titleOn && !this.titleDrawn && this.taintedAll  ) this.drawTitle$O$I$I$S(gMain, height * this.scalingFactor, width * this.scalingFactor, this.getDrawTitle$Z(this.isPrinting));
if (withCoords && this.coordStr != null  ) this.drawCoordinates$O$I$I$I(gFront, top, this.thisWidth - this.right, top - 20);
if (addFilePath && this.taintedAll ) {
this.printFilePath$O$I$I$S(gMain, this.left, height, this.commonFilePath != null  ? this.commonFilePath : this.graphSets.size$() == 1 && this.currentGraphSet.getTitle$Z(true) != null   ? this.getSpectrum$().getFilePath$() : null);
}if (this.isPrinting) {
this.printVersion$O$I(gMain, height);
}if (!this.testingJavaScript && (this.isPrinting || gMain === gFront  ) ) this.setTaintedAll$();
 else this.taintedAll=false;
});

Clazz.newMeth(C$, 'drawCoordinates$O$I$I$I',  function (g, top, x, y) {
this.g2d.setGraphicsColor$O$javajs_api_GenericColor(g, this.coordinatesColor);
var font=this.setFont$O$I$I$F$Z(g, this.jsvp.getWidth$(), 1, 14, true);
this.g2d.drawString$O$S$I$I(g, this.coordStr, x - font.stringWidth$S(this.coordStr), y);
});

Clazz.newMeth(C$, 'setFont$O$I$I$F$Z',  function (g, width, style, size, isLabel) {
return this.g2d.setFont$O$org_jmol_util_Font(g, p$1.getFont$O$I$I$F$Z.apply(this, [g, width, style, size, isLabel]));
});

Clazz.newMeth(C$, 'printFilePath$O$I$I$S',  function (g, x, y, s) {
if (s == null ) return;
x*=this.scalingFactor;
y*=this.scalingFactor;
if (s.indexOf$S("?") > 0) s=s.substring$I(s.indexOf$S("?") + 1);
s=s.substring$I(s.lastIndexOf$S("/") + 1);
s=s.substring$I(s.lastIndexOf$S("\\") + 1);
this.g2d.setGraphicsColor$O$javajs_api_GenericColor(g, this.BLACK);
var font=this.setFont$O$I$I$F$Z(g, 1000, 0, 9, true);
if (x != this.left * this.scalingFactor) x-=font.stringWidth$S(s);
this.g2d.drawString$O$S$I$I(g, s, x, y - font.getHeight$());
});

Clazz.newMeth(C$, 'printVersion$O$I',  function (g, pageHeight) {
this.g2d.setGraphicsColor$O$javajs_api_GenericColor(g, this.BLACK);
var font=this.setFont$O$I$I$F$Z(g, 100, 0, 12, true);
var s=this.jsvp.getApiPlatform$().getDateFormat$S(null) + " JSpecView " + $I$(7).VERSION_SHORT ;
var w=font.stringWidth$S(s);
this.g2d.drawString$O$S$I$I(g, s, (this.thisWidth - this.right) * this.scalingFactor - w, pageHeight * this.scalingFactor - font.getHeight$() * 3);
});

Clazz.newMeth(C$, 'drawTitle$O$I$I$S',  function (g, pageHeight, pageWidth, title) {
title=title.replace$C$C("\n", " ");
var font=p$1.getFont$O$I$I$F$Z.apply(this, [g, pageWidth, this.isPrinting || this.getBoolean$jspecview_common_ScriptToken($I$(4).TITLEBOLDON)  ? 1 : 0, 14, true]);
var nPixels=font.stringWidth$S(title);
if (nPixels > pageWidth) {
var size=((14.0 * pageWidth / nPixels)|0);
if (size < 10) size=10;
font=p$1.getFont$O$I$I$F$Z.apply(this, [g, pageWidth, this.isPrinting || this.getBoolean$jspecview_common_ScriptToken($I$(4).TITLEBOLDON)  ? 1 : 0, size, true]);
}this.g2d.setGraphicsColor$O$javajs_api_GenericColor(g, this.titleColor);
p$1.setCurrentFont$org_jmol_util_Font.apply(this, [this.g2d.setFont$O$org_jmol_util_Font(g, font)]);
this.g2d.drawString$O$S$I$I(g, title, (this.isPrinting ? this.left * this.scalingFactor : 5), pageHeight - ((font.getHeight$() * (this.isPrinting ? 2 : 0.5))|0));
});

Clazz.newMeth(C$, 'setCurrentFont$org_jmol_util_Font',  function (font) {
this.currentFont=font;
}, p$1);

Clazz.newMeth(C$, 'getFontHeight$',  function () {
return this.currentFont.getAscent$();
});

Clazz.newMeth(C$, 'getStringWidth$S',  function (s) {
return this.currentFont.stringWidth$S(s);
});

Clazz.newMeth(C$, 'selectFromEntireSet$I',  function (iSpec) {
for (var i=0, pt=0; i < this.graphSets.size$(); i++) {
if (iSpec == -2147483648) {
this.graphSets.get$I(i).setSelected$I(-1);
continue;
}var specs=this.graphSets.get$I(i).spectra;
for (var j=0; j < specs.size$(); j++, pt++) if (iSpec < 0 || iSpec == pt ) this.graphSets.get$I(i).setSelected$I(j);

}
});

Clazz.newMeth(C$, 'addToList$I$javajs_util_Lst',  function (iSpec, list) {
for (var i=0; i < this.spectra.size$(); i++) if (iSpec < 0 || i == iSpec ) list.addLast$O(this.spectra.get$I(i));

});

Clazz.newMeth(C$, 'scaleSelectedBy$D',  function (f) {
for (var i=this.graphSets.size$(); --i >= 0; ) this.graphSets.get$I(i).scaleSelectedBy$D(f);

});

Clazz.newMeth(C$, 'setCurrentGraphSet$jspecview_common_GraphSet$I',  function (gs, yPixel) {
var splitPoint=(gs.nSplit > 1 ? gs.getSplitPoint$I(yPixel) : gs.getCurrentSpectrumIndex$());
var isNewSet=(this.currentGraphSet !== gs );
var isNewSplitPoint=(isNewSet || this.currentSplitPoint != splitPoint );
this.currentGraphSet=gs;
this.currentSplitPoint=splitPoint;
if (isNewSet || gs.nSplit > 1 && isNewSplitPoint  ) this.setSpectrum$I$Z(splitPoint, true);
if (!isNewSet) {
isNewSet=gs.checkSpectrumClickedEvent$I$I$I(this.mouseX, this.mouseY, this.clickCount);
if (!isNewSet) return false;
this.currentSplitPoint=splitPoint=gs.getCurrentSpectrumIndex$();
this.setSpectrum$I$Z(splitPoint, true);
}this.jumpToSpectrumIndex$I$Z(splitPoint, isNewSet || gs.nSplit > 1 && isNewSplitPoint  );
return isNewSet;
}, p$1);

Clazz.newMeth(C$, 'jumpToSpectrum$jspecview_common_Spectrum',  function (spec) {
var index=this.currentGraphSet.getSpectrumIndex$jspecview_common_Spectrum(spec);
this.jumpToSpectrumIndex$I$Z(index, true);
});

Clazz.newMeth(C$, 'jumpToSpectrumIndex$I$Z',  function (index, doSetSpec) {
if (index < 0 || index >= this.currentGraphSet.nSpectra ) return;
this.currentSplitPoint=index;
if (doSetSpec) this.setSpectrum$I$Z(this.currentSplitPoint, this.currentGraphSet.nSplit > 1);
var spec=this.getSpectrum$();
this.notifySubSpectrumChange$I$jspecview_common_Spectrum(spec.getSubIndex$(), spec);
});

Clazz.newMeth(C$, 'splitStack$Z',  function (doSplit) {
this.currentGraphSet.splitStack$Z(doSplit);
});

Clazz.newMeth(C$, 'getNumberOfSpectraInCurrentSet$',  function () {
return this.currentGraphSet.nSpectra;
});

Clazz.newMeth(C$, 'getSourceID$',  function () {
var id=this.getSpectrum$().sourceID;
return (id == null  ? this.getSpectrumAt$I(0).sourceID : id);
});

Clazz.newMeth(C$, 'getStartingPointIndex$I',  function (index) {
return this.currentGraphSet.viewData.getStartingPointIndex$I(index);
});

Clazz.newMeth(C$, 'getEndingPointIndex$I',  function (index) {
return this.currentGraphSet.viewData.getEndingPointIndex$I(index);
});

Clazz.newMeth(C$, 'haveSelectedSpectrum$',  function () {
return this.currentGraphSet.haveSelectedSpectrum$();
});

Clazz.newMeth(C$, 'getShowAnnotation$jspecview_common_Annotation_AType',  function (type) {
return this.currentGraphSet.getShowAnnotation$jspecview_common_Annotation_AType$I(type, -1);
});

Clazz.newMeth(C$, 'showAnnotation$jspecview_common_Annotation_AType$Boolean',  function (type, tfToggle) {
this.currentGraphSet.setShowAnnotation$jspecview_common_Annotation_AType$Boolean(type, tfToggle);
});

Clazz.newMeth(C$, 'setYStackOffsetPercent$I',  function (offset) {
this.currentGraphSet.yStackOffsetPercent=offset;
});

Clazz.newMeth(C$, 'setSpectrum$I$Z',  function (iSpec, isSplit) {
this.currentGraphSet.setSpectrum$I$Z(iSpec, isSplit);
});

Clazz.newMeth(C$, 'getSpectrum$',  function () {
return this.currentGraphSet.getSpectrum$();
});

Clazz.newMeth(C$, 'setSpecForIRMode$jspecview_common_Spectrum',  function (spec) {
this.setTaintedAll$();
var spec0=this.currentGraphSet.getSpectrum$();
this.currentGraphSet.setSpectrumJDX$jspecview_common_Spectrum(spec);
for (var i=0; i < this.spectra.size$(); i++) if (this.spectra.get$I(i) === spec0 ) this.spectra.set$I$O(i, spec);

});

Clazz.newMeth(C$, 'isShowAllStacked$',  function () {
return this.currentGraphSet.showAllStacked;
});

Clazz.newMeth(C$, 'getCurrentSpectrumIndex$',  function () {
return this.currentGraphSet.getCurrentSpectrumIndex$();
});

Clazz.newMeth(C$, 'getSpectrumAt$I',  function (index) {
if (this.currentGraphSet == null ) return null;
return this.currentGraphSet.getSpectrumAt$I(index);
});

Clazz.newMeth(C$, 'addHighlight$jspecview_common_GraphSet$D$D$jspecview_common_Spectrum$I$I$I$I',  function (gs, x1, x2, spec, r, g, b, a) {
(gs == null  ? this.currentGraphSet : gs).addHighlight$D$D$jspecview_common_Spectrum$javajs_api_GenericColor(x1, x2, spec, this.g2d.getColor4$I$I$I$I(r, g, b, a));
});

Clazz.newMeth(C$, 'removeHighlight$D$D',  function (x1, x2) {
this.currentGraphSet.removeHighlight$D$D(x1, x2);
});

Clazz.newMeth(C$, 'removeAllHighlights$',  function () {
this.currentGraphSet.removeAllHighlights$();
});

Clazz.newMeth(C$, 'setZoom$D$D$D$D',  function (x1, y1, x2, y2) {
this.currentGraphSet.setZoom$D$D$D$D(x1, y1, x2, y2);
this.doReset=true;
this.setTaintedAll$();
this.notifyListeners$O(Clazz.new_($I$(8,1)));
});

Clazz.newMeth(C$, 'resetView$',  function () {
this.currentGraphSet.resetView$();
});

Clazz.newMeth(C$, 'previousView$',  function () {
this.currentGraphSet.previousView$();
});

Clazz.newMeth(C$, 'nextView$',  function () {
this.currentGraphSet.nextView$();
});

Clazz.newMeth(C$, 'getSelectedIntegral$',  function () {
return this.currentGraphSet.getSelectedIntegral$();
});

Clazz.newMeth(C$, 'advanceSubSpectrum$I',  function (dir) {
this.currentGraphSet.advanceSubSpectrum$I(dir);
});

Clazz.newMeth(C$, 'setSelectedIntegral$D',  function (val) {
this.currentGraphSet.setSelectedIntegral$D(val);
});

Clazz.newMeth(C$, 'scaleYBy$D',  function (f) {
this.currentGraphSet.scaleYBy$D(f);
});

Clazz.newMeth(C$, 'toPeak$I',  function (i) {
this.currentGraphSet.toPeak$I(i);
});

Clazz.newMeth(C$, 'getClickedCoordinate$',  function () {
return this.coordClicked;
});

Clazz.newMeth(C$, 'getPickedCoordinates$jspecview_common_Coordinate$jspecview_common_Coordinate',  function (coord, actualCoord) {
return $I$(9).getPickedCoordinates$jspecview_common_CoordinateA$jspecview_common_Coordinate$jspecview_common_Coordinate$jspecview_common_Coordinate(this.coordsClicked, this.coordClicked, coord, actualCoord);
});

Clazz.newMeth(C$, 'shiftSpectrum$I$D$D',  function (mode, xOld, xNew) {
return this.currentGraphSet.shiftSpectrum$I$D$D(mode, xOld, xNew);
});

Clazz.newMeth(C$, 'findX$jspecview_common_Spectrum$D',  function (spec, d) {
this.currentGraphSet.setXPointer$jspecview_common_Spectrum$D(spec, d);
});

Clazz.newMeth(C$, 'setXPointers$jspecview_common_Spectrum$D$jspecview_common_Spectrum$D',  function (spec, x1, spec2, x2) {
this.currentGraphSet.setXPointer$jspecview_common_Spectrum$D(spec, x1);
this.currentGraphSet.setXPointer2$jspecview_common_Spectrum$D(spec2, x2);
});

Clazz.newMeth(C$, 'isCurrentGraphSet$jspecview_common_GraphSet',  function (graphSet) {
return graphSet === this.currentGraphSet ;
});

Clazz.newMeth(C$, 'repaint$',  function () {
this.jsvp.doRepaint$Z(false);
});

Clazz.newMeth(C$, 'setToolTipText$S',  function (s) {
this.jsvp.setToolTipText$S(s);
});

Clazz.newMeth(C$, 'setHighlightColor$javajs_api_GenericColor',  function (color) {
this.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(4).HIGHLIGHTCOLOR, color);
});

Clazz.newMeth(C$, 'getInput$S$S$S',  function (message, title, sval) {
return this.jsvp.getInput$S$S$S(message, title, sval);
});

Clazz.newMeth(C$, 'getFont$O$I$I$F$Z',  function (g, width, style, size, isLabel) {
size*=this.scalingFactor;
if (isLabel) {
if (width < 400) size=((width * size) / 400);
} else {
if (width < 250) size=((width * size) / 250);
}var face=this.jsvp.getFontFaceID$S(this.isPrinting ? this.printingFontName : this.displayFontName);
return this.currentFont=$I$(10,"createFont3D$I$I$D$D$D$org_jmol_api_FontManager$O",[face, style, size, size, 0, this.jsvp.getApiPlatform$(), g]);
}, p$1);

Clazz.newMeth(C$, 'notifySubSpectrumChange$I$jspecview_common_Spectrum',  function (isub, spec) {
this.notifyListeners$O(Clazz.new_([isub, (spec == null  ? null : spec.getTitleLabel$())],$I$(11,1).c$$I$S));
});

Clazz.newMeth(C$, 'notifyPeakPickedListeners$jspecview_common_PeakPickEvent',  function (p) {
if (p == null ) {
p=Clazz.new_([this.jsvp, this.coordClicked, this.getSpectrum$().getAssociatedPeakInfo$I$jspecview_common_Coordinate(this.xPixelClicked, this.coordClicked)],$I$(12,1).c$$O$jspecview_common_Coordinate$jspecview_common_PeakInfo);
}this.notifyListeners$O(p);
});

Clazz.newMeth(C$, 'notifyListeners$O',  function (eventObj) {
for (var i=0; i < this.listeners.size$(); i++) if (this.listeners.get$I(i) != null ) this.listeners.get$I(i).panelEvent$O(eventObj);

});

Clazz.newMeth(C$, 'escapeKeyPressed$Z',  function (isDEL) {
this.currentGraphSet.escapeKeyPressed$Z(isDEL);
});

Clazz.newMeth(C$, 'hasFocus$',  function () {
return this.jsvp.hasFocus$();
});

Clazz.newMeth(C$, 'isMouseUp$',  function () {
return (this.mouseState === $I$(13).UP );
});

Clazz.newMeth(C$, 'doMouseMoved$I$I',  function (xPixel, yPixel) {
this.mouseX=xPixel;
this.mouseY=yPixel;
this.mouseState=$I$(13).UP;
this.clickCount=0;
var gs=$I$(6).findGraphSet$javajs_util_Lst$I$I(this.graphSets, xPixel, yPixel);
if (gs == null ) return;
gs.mouseMovedEvent$I$I(xPixel, yPixel);
});

Clazz.newMeth(C$, 'doMousePressed$I$I',  function (xPixel, yPixel) {
this.mouseState=$I$(13).DOWN;
var gs=$I$(6).findGraphSet$javajs_util_Lst$I$I(this.graphSets, xPixel, yPixel);
if (gs == null ) return;
p$1.setCurrentGraphSet$jspecview_common_GraphSet$I.apply(this, [gs, yPixel]);
this.clickCount=(++this.clickCount % 3);
this.currentGraphSet.mousePressedEvent$I$I$I(xPixel, yPixel, this.clickCount);
});

Clazz.newMeth(C$, 'doMouseDragged$I$I',  function (xPixel, yPixel) {
this.isIntegralDrag=!!(this.isIntegralDrag|(this.ctrlPressed));
this.mouseState=$I$(13).DOWN;
if ($I$(6).findGraphSet$javajs_util_Lst$I$I(this.graphSets, xPixel, yPixel) !== this.currentGraphSet ) return;
if (this.currentGraphSet.checkWidgetEvent$I$I$Z(xPixel, yPixel, false)) this.setTaintedAll$();
this.currentGraphSet.mouseMovedEvent$I$I(xPixel, yPixel);
});

Clazz.newMeth(C$, 'doMouseReleased$I$I$Z',  function (xPixel, yPixel, isButton1) {
this.mouseState=$I$(13).UP;
if (this.thisWidget == null  && this.currentGraphSet.pendingMeasurement == null   || !isButton1 ) return;
this.currentGraphSet.mouseReleasedEvent$I$I(xPixel, yPixel);
this.thisWidget=null;
this.isIntegralDrag=false;
this.integralShiftMode=0;
});

Clazz.newMeth(C$, 'doMouseClicked$I$I$Z',  function (xPixel, yPixel, isControlDown) {
var gs=$I$(6).findGraphSet$javajs_util_Lst$I$I(this.graphSets, xPixel, yPixel);
if (gs == null ) return;
p$1.setCurrentGraphSet$jspecview_common_GraphSet$I.apply(this, [gs, yPixel]);
gs.mouseClickedEvent$I$I$I$Z(xPixel, yPixel, this.clickCount, isControlDown);
this.setTaintedAll$();
this.repaint$();
});

Clazz.newMeth(C$, 'hasCurrentMeasurements$jspecview_common_Annotation_AType',  function (type) {
return this.currentGraphSet.hasCurrentMeasurement$jspecview_common_Annotation_AType(type);
});

Clazz.newMeth(C$, 'getDialog$jspecview_common_Annotation_AType',  function (type) {
return this.currentGraphSet.getDialog$jspecview_common_Annotation_AType$I(type, -1);
});

Clazz.newMeth(C$, 'addDialog$I$jspecview_common_Annotation_AType$jspecview_api_AnnotationData',  function (iSpec, type, dialog) {
this.currentGraphSet.addDialog$I$jspecview_common_Annotation_AType$jspecview_api_AnnotationData(iSpec, type, dialog);
});

Clazz.newMeth(C$, 'getPeakListing$jspecview_common_Parameters$Boolean',  function (p, tfToggle) {
if (p != null ) this.currentGraphSet.getPeakListing$I$jspecview_common_Parameters$Z(-1, p, true);
this.currentGraphSet.setPeakListing$Boolean(tfToggle);
});

Clazz.newMeth(C$, 'checkIntegral$jspecview_common_Parameters$S',  function (parameters, value) {
this.currentGraphSet.checkIntegralParams$jspecview_common_Parameters$S(parameters, value);
});

Clazz.newMeth(C$, 'setIntegrationRatios$S',  function (value) {
this.currentGraphSet.setIntegrationRatios$S(value);
});

Clazz.newMeth(C$, 'getView$',  function () {
return this.currentGraphSet.getCurrentView$();
});

Clazz.newMeth(C$, 'closeAllDialogsExcept$jspecview_common_Annotation_AType',  function (type) {
for (var i=this.graphSets.size$(); --i >= 0; ) this.graphSets.get$I(i).closeDialogsExcept$jspecview_common_Annotation_AType(type);

});

Clazz.newMeth(C$, 'removeDialog$jspecview_dialog_JSVDialog',  function (dialog) {
this.currentGraphSet.removeDialog$jspecview_dialog_JSVDialog(dialog);
});

Clazz.newMeth(C$, 'normalizeIntegral$',  function () {
var integral=this.getSelectedIntegral$();
if (integral == null ) return;
var sValue=integral.text;
if (sValue.length$() == 0) sValue="" + new Double(integral.getValue$()).toString();
var newValue=this.getInput$S$S$S("Enter a new value for this integral", "Normalize Integral", sValue);
try {
this.setSelectedIntegral$D(Double.parseDouble$S(newValue));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'getDrawTitle$Z',  function (isPrinting) {
var title=null;
if (isPrinting) title=this.printJobTitle;
 else if (this.nSpectra == 1) {
title=this.getSpectrum$().getPeakTitle$();
} else if (this.viewTitle != null ) {
if (this.currentGraphSet.getTitle$Z(false) != null ) title=this.getSpectrum$().getPeakTitle$();
if (title == null ) title=this.viewTitle;
} else {
title=this.jsvp.getTitle$().trim$();
}if (title.indexOf$S("\n") >= 0) title=title.substring$I$I(0, title.indexOf$S("\n")).trim$();
return title;
});

Clazz.newMeth(C$, 'getPrintJobTitle$Z',  function (isPrinting) {
var title=null;
if (this.nSpectra == 1) {
title=this.getSpectrum$().getTitle$();
} else if (this.viewTitle != null ) {
if (this.graphSets.size$() == 1) title=this.currentGraphSet.getTitle$Z(isPrinting);
if (title == null ) title=this.viewTitle;
} else {
title=this.jsvp.getTitle$().trim$();
}if (title.indexOf$S("\n") >= 0) title=title.substring$I$I(0, title.indexOf$S("\n")).trim$();
 else if (title.startsWith$S("$")) title=title.substring$I(1);
return title;
});

Clazz.newMeth(C$, 'linkSpectra$jspecview_common_PanelData_LinkMode',  function (mode) {
if (mode === $I$(5).ALL ) mode=(this.nSpectra == 2 ? $I$(5).AB : this.nSpectra == 3 ? $I$(5).ABC : $I$(5).NONE);
if (mode !== $I$(5).NONE  && mode.toString().length$() != this.nSpectra ) return;
p$1.setGraphSets$jspecview_common_PanelData_LinkMode.apply(this, [mode]);
});

Clazz.newMeth(C$, 'doZoomLinked$jspecview_common_GraphSet$D$D$Z$Z$Z',  function (graphSet, initX, finalX, addZoom, checkRange, is1d) {
if (this.linking) return;
this.linking=true;
var spec=graphSet.getSpectrumAt$I(0);
for (var i=this.graphSets.size$(); --i >= 0; ) {
var gs=this.graphSets.get$I(i);
if (gs !== graphSet  && $I$(14,"areXScalesCompatible$jspecview_common_Spectrum$jspecview_common_Spectrum$Z$Z",[spec, this.graphSets.get$I(i).getSpectrumAt$I(0), false, true]) ) gs.doZoom$D$D$D$D$Z$Z$Z$Z$Z(initX, 0, finalX, 0, is1d, false, checkRange, false, addZoom);
}
this.linking=false;
});

Clazz.newMeth(C$, 'clearLinkViews$jspecview_common_GraphSet',  function (graphSet) {
if (this.linking) return;
this.linking=true;
var spec=graphSet.getSpectrum$();
for (var i=this.graphSets.size$(); --i >= 0; ) {
var gs=this.graphSets.get$I(i);
if (gs !== graphSet  && $I$(14,"areXScalesCompatible$jspecview_common_Spectrum$jspecview_common_Spectrum$Z$Z",[spec, this.graphSets.get$I(i).getSpectrum$(), false, true]) ) gs.clearViews$();
}
this.linking=false;
});

Clazz.newMeth(C$, 'setlinkedXMove$jspecview_common_GraphSet$D$Z',  function (graphSet, x, isX2) {
if (this.linking) return;
this.linking=true;
var spec=graphSet.getSpectrum$();
for (var i=this.graphSets.size$(); --i >= 0; ) {
var gs=this.graphSets.get$I(i);
if (gs !== graphSet  && $I$(14,"areXScalesCompatible$jspecview_common_Spectrum$jspecview_common_Spectrum$Z$Z",[spec, this.graphSets.get$I(i).getSpectrum$(), false, true]) ) {
if (gs.imageView == null ) if (isX2) {
gs.setXPixelMovedTo$D$D$I$I(1.7976931348623157E308, x, 0, 0);
} else {
gs.setXPixelMovedTo$D$D$I$I(x, 1.7976931348623157E308, 0, 0);
}}}
this.linking=false;
});

Clazz.newMeth(C$, 'set2DCrossHairsLinked$jspecview_common_GraphSet$D$D$Z',  function (graphSet, x, y, isLocked) {
for (var i=this.graphSets.size$(); --i >= 0; ) {
var gs=this.graphSets.get$I(i);
if (gs !== graphSet ) gs.set2DXY$D$D$Z(x, y, isLocked);
}
});

Clazz.newMeth(C$, 'dialogsToFront$jspecview_common_Spectrum',  function (spec) {
this.currentGraphSet.dialogsToFront$jspecview_common_Spectrum(spec);
});

Clazz.newMeth(C$, 'setColor$jspecview_common_ScriptToken$javajs_api_GenericColor',  function (st, color) {
if (color != null ) this.options.put$O$O(st, $I$(15).toRGBHexString$javajs_api_GenericColor(color));
switch (st) {
case $I$(4).COORDINATESCOLOR:
this.coordinatesColor=color;
return;
case $I$(4).HIGHLIGHTCOLOR:
this.highlightColor=color;
if (this.highlightColor.getOpacity255$() == 255) this.highlightColor.setOpacity255$I(150);
return;
case $I$(4).ZOOMBOXCOLOR:
this.zoomBoxColor=color;
return;
case $I$(4).ZOOMBOXCOLOR2:
this.zoomBoxColor2=color;
return;
case $I$(4).BACKGROUNDCOLOR:
this.jsvp.setBackgroundColor$javajs_api_GenericColor(this.bgcolor=color);
break;
case $I$(4).GRIDCOLOR:
this.gridColor=color;
break;
case $I$(4).INTEGRALPLOTCOLOR:
this.integralPlotColor=color;
break;
case $I$(4).PEAKTABCOLOR:
this.peakTabColor=color;
break;
case $I$(4).PLOTCOLOR:
for (var i=this.graphSets.size$(); --i >= 0; ) this.graphSets.get$I(i).setPlotColor0$O(color);

break;
case $I$(4).PLOTAREACOLOR:
this.plotAreaColor=color;
break;
case $I$(4).SCALECOLOR:
this.scaleColor=color;
break;
case $I$(4).TITLECOLOR:
this.titleColor=color;
break;
case $I$(4).UNITSCOLOR:
this.unitsColor=color;
break;
default:
$I$(16).warn$S("AwtPanel --- unrecognized color: " + st);
return;
}
this.taintedAll=true;
});

Clazz.newMeth(C$, 'getColor$jspecview_common_ScriptToken',  function (whatColor) {
switch (whatColor) {
default:
$I$(16).error$S("awtgraphset missing color " + whatColor);
return this.BLACK;
case $I$(4).ZOOMBOXCOLOR2:
return this.zoomBoxColor2;
case $I$(4).ZOOMBOXCOLOR:
return this.zoomBoxColor;
case $I$(4).HIGHLIGHTCOLOR:
return this.highlightColor;
case $I$(4).INTEGRALPLOTCOLOR:
return this.integralPlotColor;
case $I$(4).GRIDCOLOR:
return this.gridColor;
case $I$(4).PEAKTABCOLOR:
return this.peakTabColor;
case $I$(4).PLOTAREACOLOR:
return this.plotAreaColor;
case $I$(4).SCALECOLOR:
return this.scaleColor;
case $I$(4).TITLECOLOR:
return this.titleColor;
case $I$(4).UNITSCOLOR:
return this.unitsColor;
}
});

Clazz.newMeth(C$, 'getOverlayLegendData$',  function () {
var numSpectra=this.currentGraphSet.nSpectra;
var data=Clazz.array(java.lang.Object, [numSpectra, null]);
var f1=this.getSpectrumAt$I(0).getFilePath$();
var f2=this.getSpectrumAt$I(numSpectra - 1).getFilePath$();
var useFileName=f1 != null  && f2 != null   && !f1.equals$O(f2) ;
for (var index=0; index < numSpectra; index++) {
var cols=Clazz.array(java.lang.Object, [3]);
var spectrum=this.getSpectrumAt$I(index);
this.title=spectrum.getTitle$();
if (useFileName) this.title=$I$(17,"getTagName$S",[spectrum.getFilePath$()]) + " - " + this.title ;
var plotColor=this.getCurrentPlotColor$I(index);
cols[0]= new Integer(index + 1);
cols[1]=plotColor;
cols[2]=" " + this.title;
data[index]=cols;
}
return data;
});

Clazz.newMeth(C$, 'setColorOrFont$jspecview_common_ColorParameters$jspecview_common_ScriptToken',  function (params, st) {
if (st == null ) {
var colors=params.elementColors;
for (var entry, $entry = colors.entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) this.setColorOrFont$jspecview_common_ColorParameters$jspecview_common_ScriptToken(params, entry.getKey$());

this.setColorOrFont$jspecview_common_ColorParameters$jspecview_common_ScriptToken(params, $I$(4).DISPLAYFONTNAME);
this.setColorOrFont$jspecview_common_ColorParameters$jspecview_common_ScriptToken(params, $I$(4).TITLEFONTNAME);
return;
}switch (st) {
case $I$(4).DISPLAYFONTNAME:
this.setFontName$jspecview_common_ScriptToken$S(st, params.displayFontName);
return;
case $I$(4).TITLEFONTNAME:
this.setFontName$jspecview_common_ScriptToken$S(st, params.titleFontName);
return;
}
this.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor(st, params.getElementColor$jspecview_common_ScriptToken(st));
});

Clazz.newMeth(C$, 'getCurrentPlotColor$I',  function (i) {
return this.currentGraphSet.getPlotColor$I(i);
});

Clazz.newMeth(C$, 'setPrint$jspecview_common_PrintLayout$S',  function (pl, fontName) {
if (pl == null ) {
this.options.putAll$java_util_Map(this.optionsSaved);
this.optionsSaved=null;
return;
}this.printJobTitle=pl.title;
this.printingFontName=fontName;
this.printGraphPosition=pl.position;
this.optionsSaved=Clazz.new_($I$(2,1));
this.optionsSaved.putAll$java_util_Map(this.options);
this.gridOn=pl.showGrid;
this.titleOn=pl.showTitle;
this.setBoolean$jspecview_common_ScriptToken$Z($I$(4).XSCALEON, pl.showXScale);
this.setBoolean$jspecview_common_ScriptToken$Z($I$(4).XUNITSON, pl.showXScale);
this.setBoolean$jspecview_common_ScriptToken$Z($I$(4).YSCALEON, pl.showYScale);
this.setBoolean$jspecview_common_ScriptToken$Z($I$(4).YUNITSON, pl.showYScale);
});

Clazz.newMeth(C$, 'setDefaultPrintOptions$jspecview_common_PrintLayout',  function (pl) {
pl.showGrid=this.gridOn;
pl.showXScale=this.getBoolean$jspecview_common_ScriptToken($I$(4).XSCALEON);
pl.showYScale=this.getBoolean$jspecview_common_ScriptToken($I$(4).YSCALEON);
pl.showTitle=this.titleOn;
});

Clazz.newMeth(C$, 'showDialog$jspecview_common_Annotation_AType',  function (type) {
var ad=this.getDialog$jspecview_common_Annotation_AType(type);
this.closeAllDialogsExcept$jspecview_common_Annotation_AType(type);
if (ad != null  && Clazz.instanceOf(ad, "jspecview.dialog.JSVDialog") ) return (ad).reEnable$();
var iSpec=this.getCurrentSpectrumIndex$();
if (iSpec < 0) {
this.jsvp.showMessage$S$S("To enable " + type + " first select a spectrum by clicking on it." , "" + type);
return null;
}var spec=this.getSpectrum$();
var dialog=this.vwr.getDialog$jspecview_common_Annotation_AType$jspecview_common_Spectrum(type, spec);
if (ad == null  && type === $I$(18).Measurements  ) ad=Clazz.new_([$I$(18).Measurements, spec],$I$(19,1).c$$jspecview_common_Annotation_AType$jspecview_common_Spectrum);
if (ad != null ) dialog.setData$jspecview_api_AnnotationData(ad);
this.addDialog$I$jspecview_common_Annotation_AType$jspecview_api_AnnotationData(iSpec, type, dialog);
dialog.reEnable$();
return dialog;
});

Clazz.newMeth(C$, 'printPdf$org_jmol_api_GenericGraphics$jspecview_common_PrintLayout',  function (pdfCreator, pl) {
var isPortrait=!pl.layout.equals$O("landscape");
this.print$O$D$D$D$D$D$D$Z$I(pdfCreator, (isPortrait ? pl.imageableHeight : pl.imageableWidth), (isPortrait ? pl.imageableWidth : pl.imageableHeight), pl.imageableX, pl.imageableY, pl.paperHeight, pl.paperWidth, isPortrait, 0);
});

Clazz.newMeth(C$, 'print$O$D$D$D$D$D$D$Z$I',  function (g, height, width, x, y, paperHeight, paperWidth, isPortrait, pi) {
this.g2d=this.g2d0;
if (pi == 0) {
this.isPrinting=true;
var addFilePath=false;
if (Clazz.instanceOf(g, "org.jmol.api.GenericGraphics")) {
this.g2d=g;
g=this.gMain;
}if (this.printGraphPosition.equals$O("default")) {
if (isPortrait) {
height=450;
width=280;
} else {
height=280;
width=450;
}} else if (this.printGraphPosition.equals$O("fit to page")) {
addFilePath=true;
} else {
if (isPortrait) {
height=450;
width=280;
x=(((paperWidth - width)|0)/2|0);
y=(((paperHeight - height)|0)/2|0);
} else {
height=280;
width=450;
y=(((paperWidth - 280)|0)/2|0);
x=(((paperHeight - 450)|0)/2|0);
}}this.g2d.translateScale$O$D$D$D(g, x, y, 0.1);
this.setTaintedAll$();
this.drawGraph$O$O$O$I$I$Z(g, g, g, (width|0), (height|0), addFilePath);
this.isPrinting=false;
return 0;
}this.isPrinting=false;
return 1;
});

Clazz.newMeth(C$, 'keyPressed$I$I',  function (code, modifiers) {
if (this.isPrinting) return false;
this.checkKeyControl$I$Z(code, true);
switch (code) {
case 27:
case 127:
case 8:
this.escapeKeyPressed$Z(code != 27);
this.isIntegralDrag=false;
this.setTaintedAll$();
this.repaint$();
return true;
}
var scaleFactor=0;
var doConsume=false;
if (modifiers == 0) {
switch (code) {
case 37:
case 39:
this.doMouseMoved$I$I((code == 39 ? ++this.mouseX : --this.mouseX), this.mouseY);
this.repaint$();
doConsume=true;
break;
case 33:
case 34:
scaleFactor=(code == 33 ? $I$(6).RT2 : 1 / $I$(6).RT2);
doConsume=true;
break;
case 40:
case 38:
var dir=(code == 40 ? -1 : 1);
if (this.getSpectrumAt$I(0).getSubSpectra$() == null ) {
this.notifySubSpectrumChange$I$jspecview_common_Spectrum(dir, null);
} else {
this.advanceSubSpectrum$I(dir);
this.setTaintedAll$();
this.repaint$();
}doConsume=true;
break;
}
} else if (this.checkMod$I$I(code, 2)) {
switch (code) {
case 40:
case 38:
case 45:
case 61:
scaleFactor=(code == 61 || code == 38  ? $I$(6).RT2 : 1 / $I$(6).RT2);
doConsume=true;
break;
case 37:
case 39:
this.toPeak$I(code == 39 ? 1 : -1);
doConsume=true;
break;
}
}if (scaleFactor != 0 ) {
this.scaleYBy$D(scaleFactor);
this.setTaintedAll$();
this.repaint$();
}return doConsume;
});

Clazz.newMeth(C$, 'keyReleased$I',  function (keyCode) {
if (this.isPrinting) return;
this.checkKeyControl$I$Z(keyCode, false);
});

Clazz.newMeth(C$, 'keyTyped$I$I',  function (ch, mods) {
if (this.isPrinting) return false;
switch (ch) {
case 110:
if (mods != 0) break;
this.normalizeIntegral$();
return true;
case 26:
if (mods != 2) break;
this.previousView$();
this.setTaintedAll$();
this.repaint$();
return true;
case 25:
if (mods != 2) break;
this.nextView$();
this.setTaintedAll$();
this.repaint$();
return true;
}
return false;
});

Clazz.newMeth(C$, 'mouseAction$I$J$I$I$I$I',  function (mode, time, x, y, countIgnored, buttonMods) {
if (this.isPrinting) return;
switch (mode) {
case 4:
if (!this.checkMod$I$I(buttonMods, 16)) return;
this.doMousePressed$I$I(x, y);
break;
case 5:
this.doMouseReleased$I$I$Z(x, y, this.checkMod$I$I(buttonMods, 16));
this.setTaintedAll$();
this.repaint$();
break;
case 1:
this.doMouseDragged$I$I(x, y);
this.repaint$();
break;
case 0:
this.jsvp.getFocusNow$Z(false);
if ((buttonMods & 28) != 0) {
this.doMouseDragged$I$I(x, y);
this.repaint$();
return;
}this.doMouseMoved$I$I(x, y);
if (this.coordStr != null ) this.repaint$();
break;
case 2:
if (this.checkMod$I$I(buttonMods, 4)) {
this.jsvp.showMenu$I$I(x, y);
return;
}this.ctrlPressed=false;
this.doMouseClicked$I$I$Z(x, y, this.updateControlPressed$I(buttonMods));
break;
}
});

Clazz.newMeth(C$, 'checkMod$I$I',  function (buttonMods, mask) {
return ((buttonMods & mask) == mask);
});

Clazz.newMeth(C$, 'checkKeyControl$I$Z',  function (keyCode, isPressed) {
switch (keyCode) {
case 17:
case 157:
this.ctrlPressed=isPressed;
break;
case 16:
this.shiftPressed=isPressed;
break;
}
});

Clazz.newMeth(C$, 'updateControlPressed$I',  function (mods) {
return (this.ctrlPressed=!!(this.ctrlPressed|(this.checkMod$I$I(mods, 2) || this.checkMod$I$I(mods, 20) )));
});

Clazz.newMeth(C$, 'mouseEnterExit$J$I$I$Z',  function (time, x, y, isExit) {
if (isExit) {
this.thisWidget=null;
this.isIntegralDrag=false;
this.integralShiftMode=0;
} else {
try {
this.jsvp.getFocusNow$Z(false);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$S("pd " + this + " cannot focus" );
} else {
throw e;
}
}
}});

Clazz.newMeth(C$, 'setSolutionColor$S',  function (what) {
var isNone=(what.indexOf$S("none") >= 0);
var asFitted=(what.indexOf$S("false") < 0);
if (what.indexOf$S("all") < 0) {
var color=(isNone ? -1 : this.vwr.getSolutionColor$Z(asFitted));
this.getSpectrum$().setFillColor$javajs_api_GenericColor(color == -1 ? null : this.vwr.parameters.getColor1$I(color));
} else {
var vi=$I$(20).getInterface$S("jspecview.common.Visible");
for (var i=this.graphSets.size$(); --i >= 0; ) this.graphSets.get$I(i).setSolutionColor$jspecview_api_VisibleInterface$Z$Z(vi, isNone, asFitted);

}});

Clazz.newMeth(C$, 'setIRMode$jspecview_common_Spectrum_IRMode$S',  function (mode, type) {
for (var i=this.graphSets.size$(); --i >= 0; ) this.graphSets.get$I(i).setIRMode$jspecview_common_Spectrum_IRMode$S(mode, type);

});

Clazz.newMeth(C$, 'closeSpectrum$',  function () {
this.vwr.close$S("views");
this.vwr.close$S(this.getSourceID$());
this.vwr.execView$S$Z("*", true);
});
;
(function(){/*e*/var C$=Clazz.newClass(P$.PanelData, "LinkMode", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getMode$S',  function (abc) {
if (abc.equals$O("*")) return C$.ALL;
for (var mode, $mode = 0, $$mode = C$.values$(); $mode<$$mode.length&&((mode=($$mode[$mode])),1);$mode++) if (mode.name$().equalsIgnoreCase$S(abc)) return mode;

return C$.NONE;
}, 1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "ALL", 0, []);
Clazz.newEnumConst($vals, C$.c$, "NONE", 1, []);
Clazz.newEnumConst($vals, C$.c$, "AB", 2, []);
Clazz.newEnumConst($vals, C$.c$, "ABC", 3, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()
;
(function(){/*e*/var C$=Clazz.newClass(P$.PanelData, "Mouse", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "UP", 0, []);
Clazz.newEnumConst($vals, C$.c$, "DOWN", 1, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:57 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
