(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "CoordComparator", null, null, 'java.util.Comparator');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$jspecview_common_Coordinate$jspecview_common_Coordinate','compare$O$O'],  function (c1, c2) {
return (c1.getXVal$() > c2.getXVal$()  ? 1 : c1.getXVal$() < c2.getXVal$()  ? -1 : 0);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:51 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
