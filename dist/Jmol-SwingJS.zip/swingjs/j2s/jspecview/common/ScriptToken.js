(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[[0,'java.util.Hashtable','javajs.util.Lst','jspecview.common.ScriptTokenizer','javajs.util.PT','javajs.util.SB']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*e*/var C$=Clazz.newClass(P$, "ScriptToken", null, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['tip','description']]
,['O',['htParams','java.util.Map']]]

Clazz.newMeth(C$, 'getTip$',  function () {
return "  " + (this.tip === "T"  ? "TRUE/FALSE/TOGGLE" : this.tip === "TF"  ? "TRUE or FALSE" : this.tip === "C"  ? "COLOR" : this.tip);
});

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S',  function (tip) {
;C$.$init$.apply(this);
this.tip=tip;
this.description="";
}, 1);

Clazz.newMeth(C$, 'c$$S$S',  function (tip, description) {
;C$.$init$.apply(this);
this.tip=tip;
this.description="-- " + description;
}, 1);

Clazz.newMeth(C$, 'getParams$',  function () {
if (C$.htParams == null ) {
C$.htParams=Clazz.new_($I$(1,1));
for (var item, $item = 0, $$item = C$.values$(); $item<$$item.length&&((item=($$item[$item])),1);$item++) C$.htParams.put$O$O(item.name$(), item);

}return C$.htParams;
}, 1);

Clazz.newMeth(C$, 'getScriptToken$S',  function (name) {
var st=C$.getParams$().get$O(name.toUpperCase$());
return (st == null  ? C$.UNKNOWN : st);
}, 1);

Clazz.newMeth(C$, 'getScriptTokenList$S$Z',  function (name, isExact) {
if (name != null ) name=name.toUpperCase$();
var list=Clazz.new_($I$(2,1));
if (isExact) {
var st=C$.getScriptToken$S(name);
if (st != null ) list.addLast$O(st);
} else {
for (var entry, $entry = C$.getParams$().entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) if ((name == null  || entry.getKey$().startsWith$S(name) ) && entry.getValue$().tip != null  ) list.addLast$O(entry.getValue$());

}return list;
}, 1);

Clazz.newMeth(C$, 'getValue$jspecview_common_ScriptToken$jspecview_common_ScriptTokenizer$S',  function (st, params, cmd) {
if (!params.hasMoreTokens$()) return "";
switch (st) {
default:
return $I$(3).nextStringToken$jspecview_common_ScriptTokenizer$Z(params, true);
case C$.CLOSE:
case C$.GETPROPERTY:
case C$.INTEGRATION:
case C$.INTEGRATE:
case C$.JMOL:
case C$.LABEL:
case C$.LOAD:
case C$.PEAK:
case C$.PLOTCOLORS:
case C$.YSCALE:
case C$.WRITE:
return C$.removeCommandName$S(cmd);
case C$.SELECT:
case C$.OVERLAY:
case C$.VIEW:
case C$.ZOOM:
return C$.removeCommandName$S(cmd).replace$C$C(",", " ").trim$();
}
}, 1);

Clazz.newMeth(C$, 'removeCommandName$S',  function (cmd) {
var pt=cmd.indexOf$S(" ");
if (pt < 0) return "";
return cmd.substring$I(pt).trim$();
}, 1);

Clazz.newMeth(C$, 'getKey$jspecview_common_ScriptTokenizer',  function (eachParam) {
var key=eachParam.nextToken$();
if (key.startsWith$S("#") || key.startsWith$S("//") ) return null;
if (key.equalsIgnoreCase$S("SET")) key=eachParam.nextToken$();
return key.toUpperCase$();
}, 1);

Clazz.newMeth(C$, 'getTokens$S',  function (value) {
if (value.startsWith$S("\'") && value.endsWith$S("\'") ) value="\"" + $I$(4).trim$S$S(value, "\'") + "\"" ;
var tokens=Clazz.new_($I$(2,1));
var st=Clazz.new_($I$(3,1).c$$S$Z,[value, false]);
while (st.hasMoreTokens$()){
var s=$I$(3).nextStringToken$jspecview_common_ScriptTokenizer$Z(st, false);
if (s.startsWith$S("//") || s.startsWith$S("#") ) break;
tokens.addLast$O(s);
}
return tokens;
}, 1);

Clazz.newMeth(C$, 'getNameList$javajs_util_Lst',  function (list) {
if (list.size$() == 0) return "";
var sb=Clazz.new_($I$(5,1));
for (var i=0; i < list.size$(); i++) sb.append$S(",").append$S(list.get$I(i).toString());

return sb.toString().substring$I(1);
}, 1);

Clazz.newMeth(C$, 'getDescription$',  function () {
return this.description;
});

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "UNKNOWN", 0, []);
Clazz.newEnumConst($vals, C$.c$, "APPLETID", 1, []);
Clazz.newEnumConst($vals, C$.c$, "APPLETREADYCALLBACKFUNCTIONNAME", 2, []);
Clazz.newEnumConst($vals, C$.c$$S$S, "AUTOINTEGRATE", 3, ["TF", "automatically integrate an NMR spectrum"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "BACKGROUNDCOLOR", 4, ["C", "set the background color"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "CLOSE", 5, ["spectrumId or fileName or ALL or VIEWS or SIMULATIONS", "close one or more views or simulations"]);
Clazz.newEnumConst($vals, C$.c$, "COMPOUNDMENUON", 6, []);
Clazz.newEnumConst($vals, C$.c$, "COORDCALLBACKFUNCTIONNAME", 7, []);
Clazz.newEnumConst($vals, C$.c$$S$S, "COORDINATESCOLOR", 8, ["C", "set the color of the coordinates shown in the upper right-hand corner"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "COORDINATESON", 9, ["T", "turn on or off the coordinates shown in the upper right-hand corner"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "DEBUG", 10, ["TF", "turn debugging on and off"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "DEFAULTLOADSCRIPT", 11, ["\"script...\"", "set the script to be run after each file is loaded"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "DEFAULTNMRNORMALIZATION", 12, ["maxYvalue", "set the value to be given the largest peak in an HMR spectrum"]);
Clazz.newEnumConst($vals, C$.c$, "DISPLAYFONTNAME", 13, []);
Clazz.newEnumConst($vals, C$.c$$S$S, "DISPLAY1D", 14, ["T", "turn on or off display of 1D spectra when 1D and 2D spectra are loaded"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "DISPLAY2D", 15, ["T", "turn on or off display of the 2D spectrum when 1D and 2D spectra are loaded"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "ENABLEZOOM", 16, ["T", "allow or disallow zooming"]);
Clazz.newEnumConst($vals, C$.c$, "ENDINDEX", 17, []);
Clazz.newEnumConst($vals, C$.c$$S$S, "FINDX", 18, ["value", "move the vertical-line cursor to a specific x-axis value"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "GETPROPERTY", 19, ["[propertyName] or ALL or NAMES", "get a property value or all property values as key/value pairs, or a list of names"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "GETSOLUTIONCOLOR", 20, [" FILL or FILLNONE or FILLALL or FILLALLNONE", "estimate the solution color for UV/VIS spectra"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "GRIDCOLOR", 21, ["C", "color of the grid"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "GRIDON", 22, ["T", "turn the grid lines on or off"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "HELP", 23, ["[command]", "get this listing or help for a specific command"]);
Clazz.newEnumConst($vals, C$.c$, "HIDDEN", 24, []);
Clazz.newEnumConst($vals, C$.c$$S$S, "HIGHLIGHTCOLOR", 25, ["C", "set the highlight color"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "HIGHLIGHT", 26, ["OFF or X1 X2 [OFF] or X1 X2 r g b [a]", "turns on or off a highlight color, possibily setting its color, where r g b a are 0-255 or 0.0-1.0"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "INTEGRALOFFSET", 27, ["percent", "sets the integral offset from baseline"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "INTEGRALRANGE", 28, ["percent", "sets the height of the total integration"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "INTEGRATE", 29, ["", "see INTEGRATION"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "INTEGRATION", 30, ["ON/OFF/TOGGLE/AUTO/CLEAR/MIN value/MARK ppm1-ppm2:norm,ppm3-ppm4,...", "show/hide integration or set integrals (1D 1H NMR only)"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "INTEGRALPLOTCOLOR", 31, ["C", "color of the integration line"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "INTEGRATIONRATIOS", 32, ["\'x:value,x:value,..\'", "annotate the spectrum with numbers or text at specific x values"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "INTERFACE", 33, ["SINGLE or OVERLAY", "set how multiple spectra are displayed"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "INVERTY", 34, ["", "invert the Y axis"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "IRMODE", 35, ["A or T or TOGGLE", "set the IR mode to absorption or transmission"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "JMOL", 36, ["...Jmol command...", "send a command to Jmol (if present)"]);
Clazz.newEnumConst($vals, C$.c$, "JSV", 37, []);
Clazz.newEnumConst($vals, C$.c$$S$S, "LABEL", 38, ["x y [color and/or \"text\"]", "add a text label"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "LINK", 39, ["AB or ABC or NONE or ALL", "synchronize the crosshair of a 2D spectrum with 1D cursors"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "LOAD", 40, ["[APPEND] \"fileName\" [first] [last]; use \"\" for current file; $H1/name or $C13/name for simulation", "load a specturm"]);
Clazz.newEnumConst($vals, C$.c$, "LOADFILECALLBACKFUNCTIONNAME", 41, []);
Clazz.newEnumConst($vals, C$.c$$S$S, "LOADIMAGINARY", 42, ["TF", "set TRUE to load imaginary NMR component"]);
Clazz.newEnumConst($vals, C$.c$, "MENUON", 43, []);
Clazz.newEnumConst($vals, C$.c$, "OBSCURE", 44, []);
Clazz.newEnumConst($vals, C$.c$, "OVERLAY", 45, []);
Clazz.newEnumConst($vals, C$.c$$S$S, "OVERLAYSTACKED", 46, ["TF", "whether viewed spectra are shown separately, in a stack"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "PEAK", 47, ["[IR,CNMR,HNMR,MS] [#nnn or ID=xxx or text] [ALL], for example: PEAK HNMR #3", "highlights a peak based on its number or title text, optionally checking all loade spectra"]);
Clazz.newEnumConst($vals, C$.c$, "PEAKCALLBACKFUNCTIONNAME", 48, []);
Clazz.newEnumConst($vals, C$.c$$S$S, "PEAKLIST", 49, ["[THRESHOLD=n] [INTERPOLATE=PARABOLIC or NONE]", "creates a peak list based on a threshold value and parabolic or no interpolation"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "PEAKTABCOLOR", 50, ["C", "sets the color of peak marks for a peak listing"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "PEAKTABSON", 51, ["T", "show peak tabs for simulated spectra"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "PLOTAREACOLOR", 52, ["C", "sets the color of the plot background"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "PLOTCOLOR", 53, ["C", "sets the color of the graph line"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "PLOTCOLORS", 54, ["color,color,color,...", "sets the colors of multiple plots"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "POINTSONLY", 55, ["TF", "show points only for all data"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "PRINT", 56, ["", "prints the current spectrum"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "REVERSEPLOT", 57, ["T", "reverses the x-axis of a spectrum"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "SCALEBY", 58, ["factor", "multiplies the y-scale of the spectrum by a factor"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "SCALECOLOR", 59, ["C", "sets the color of the x-axis and y-axis scales"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "SCRIPT", 60, ["filename.jsv", "runs a script from a file"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "SELECT", 61, ["spectrumID, spectrumID,...", "selects one or more spectra based on IDs"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "SETPEAK", 62, ["xNew, xOld xNew, ?, or NONE", "sets nearest peak to xOld ppm to a new value; NONE resets (1D NMR only)"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "SETX", 63, ["xNew, xOld xNew, ?, or NONE", "sets an old ppm position in the spectrum to a new value; NONE resets (1D NMR only)"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "SHIFTX", 64, ["dx or NONE", "shifts the x-axis of a 1D NMR spectrum by the given ppm; NONE resets (1D NMR only)"]);
Clazz.newEnumConst($vals, C$.c$$S, "SHOWERRORS", 65, ["shows recent errors"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "SHOWINTEGRATION", 66, ["T", "shows an integration listing"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "SHOWKEY", 67, ["T", "shows a color key when multiple spectra are displayed"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "SHOWMEASUREMENTS", 68, ["T", "shows a listing of measurements"]);
Clazz.newEnumConst($vals, C$.c$$S, "SHOWMENU", 69, ["displays the popup menu"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "SHOWPEAKLIST", 70, ["T", "shows a listing for peak picking"]);
Clazz.newEnumConst($vals, C$.c$$S, "SHOWPROPERTIES", 71, ["displays the header information of a JDX file"]);
Clazz.newEnumConst($vals, C$.c$$S, "SHOWSOURCE", 72, ["displays the source JDX file associated with the selected data"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "SPECTRUM", 73, ["id", "displays a specific spectrum, where id is a number 1, 2, 3... or a file.spectrum number such as 2.1"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "SPECTRUMNUMBER", 74, ["n", "displays the nth spectrum loaded"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "STACKOFFSETY", 75, ["percent", "sets the y-axis offset of stacked spectra"]);
Clazz.newEnumConst($vals, C$.c$, "STARTINDEX", 76, []);
Clazz.newEnumConst($vals, C$.c$, "SYNCCALLBACKFUNCTIONNAME", 77, []);
Clazz.newEnumConst($vals, C$.c$, "SYNCID", 78, []);
Clazz.newEnumConst($vals, C$.c$, "TEST", 79, []);
Clazz.newEnumConst($vals, C$.c$$S$S, "TITLEON", 80, ["T", "turns the title in the bottom left corner on or off"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "TITLEBOLDON", 81, ["T", "makes the title bold"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "TITLECOLOR", 82, ["C", "sets the color of the title"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "TITLEFONTNAME", 83, ["fontName", "sets the title font"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "UNITSCOLOR", 84, ["C", "sets the color of the x-axis and y-axis units"]);
Clazz.newEnumConst($vals, C$.c$, "VERSION", 85, []);
Clazz.newEnumConst($vals, C$.c$$S$S, "VIEW", 86, ["spectrumID, spectrumID, ... Example: VIEW 3.1, 3.2  or  VIEW \"acetophenone\"", "creates a view of one or more spectra"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "XSCALEON", 87, ["T", "set FALSE to turn off the x-axis scale"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "XUNITSON", 88, ["T", "set FALSE to turn off the x-axis units"]);
Clazz.newEnumConst($vals, C$.c$$S, "YSCALE", 89, ["[ALL] lowValue highValue"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "YSCALEON", 90, ["T", "set FALSE to turn off the y-axis scale"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "YUNITSON", 91, ["T", "set FALSE to turn off the y-axis units"]);
Clazz.newEnumConst($vals, C$.c$, "WINDOW", 92, []);
Clazz.newEnumConst($vals, C$.c$$S$S, "WRITE", 93, ["[XY,DIF,DIFDUP,PAC,FIX,SQZ,AML,CML,JPG,PDF,PNG,SVG] \"filename\"", "writes a file in the specified format"]);
Clazz.newEnumConst($vals, C$.c$$S$S, "ZOOM", 94, ["OUT or PREVIOUS or NEXT or x1,x2 or x1,y1 x2,y2", "sets the zoom"]);
Clazz.newEnumConst($vals, C$.c$, "ZOOMBOXCOLOR", 95, []);
Clazz.newEnumConst($vals, C$.c$, "ZOOMBOXCOLOR2", 96, []);
};
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:57 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
