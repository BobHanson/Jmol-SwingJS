(function(){var P$=Clazz.newPackage("jspecview.common"),p$1={},I$=[[0,'jspecview.common.IntegralComparator',['jspecview.common.Annotation','.AType'],'jspecview.common.Coordinate','jspecview.common.Integral','java.util.Collections','javajs.util.PT','jspecview.common.ScriptToken','javajs.util.Lst','java.util.StringTokenizer','jspecview.common.Annotation','javajs.util.BS','javajs.util.DF','javajs.util.AU']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "IntegralData", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'jspecview.common.MeasurementData');
C$.$classes$=[['IntMode',25]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.normalizationFactor=1;
},1);

C$.$fields$=[['Z',['haveRegions'],'D',['percentMinY','percentOffset','intRange','normalizationFactor','percentRange','offset','integralTotal'],'O',['xyCoords','jspecview.common.Coordinate[]']]
,['O',['c','java.util.Comparator','$HEADER','String[]']]]

Clazz.newMeth(C$, 'getPercentMinimumY$',  function () {
return this.percentMinY;
});

Clazz.newMeth(C$, 'getPercentOffset$',  function () {
return this.percentOffset;
});

Clazz.newMeth(C$, 'getIntegralFactor$',  function () {
return this.intRange;
});

Clazz.newMeth(C$, 'c$$D$D$D$jspecview_common_Spectrum',  function (integralMinY, integralOffset, integralRange, spec) {
;C$.superclazz.c$$jspecview_common_Annotation_AType$jspecview_common_Spectrum.apply(this,[$I$(2).Integration, spec]);C$.$init$.apply(this);
this.percentMinY=integralMinY;
this.percentOffset=integralOffset;
this.percentRange=integralRange;
this.calculateIntegral$();
}, 1);

Clazz.newMeth(C$, 'c$$jspecview_common_Spectrum$jspecview_common_Parameters',  function (spec, p) {
;C$.superclazz.c$$jspecview_common_Annotation_AType$jspecview_common_Spectrum.apply(this,[$I$(2).Integration, spec]);C$.$init$.apply(this);
if (p == null ) {
this.autoIntegrate$();
return;
}this.percentOffset=p.integralOffset;
this.percentRange=p.integralRange;
this.calculateIntegral$();
}, 1);

Clazz.newMeth(C$, 'update$jspecview_common_Parameters',  function (parameters) {
this.update$D$D$D(parameters.integralMinY, parameters.integralOffset, parameters.integralRange);
});

Clazz.newMeth(C$, 'update$D$D$D',  function (integralMinY, integralOffset, integralRange) {
var percentRange0=this.percentRange;
if (integralRange <= 0  || integralRange == this.percentRange  && integralOffset == this.percentOffset   ) return;
this.percentOffset=integralOffset;
this.percentRange=integralRange;
p$1.checkRange.apply(this, []);
var intRangeNew=integralRange / 100 / this.integralTotal ;
var offsetNew=integralOffset / 100;
for (var i=0; i < this.xyCoords.length; i++) {
var y=this.xyCoords[i].getYVal$();
y=(y - this.offset) / this.intRange;
this.xyCoords[i].setYVal$D(y * intRangeNew + offsetNew);
}
if (this.normalizationFactor != 1 ) this.normalizationFactor*=percentRange0 / integralRange;
if (this.haveRegions) {
for (var i=this.size$(); --i >= 0; ) {
var ir=this.get$I(i);
var y1=this.getYValueAt$D(ir.getXVal$());
var y2=this.getYValueAt$D(ir.getXVal2$());
ir.setYVal$D(y1);
ir.setYVal2$D(y2);
ir.setValue$D(Math.abs(y2 - y1) * 100 * this.normalizationFactor );
}
}this.intRange=intRangeNew;
this.offset=offsetNew;
});

Clazz.newMeth(C$, 'getYValueAt$D',  function (x) {
return $I$(3).getYValueAt$jspecview_common_CoordinateA$D(this.xyCoords, x);
});

Clazz.newMeth(C$, 'addIntegralRegion$D$D',  function (x1, x2) {
if (Double.isNaN$D(x1)) {
this.haveRegions=false;
this.clear$();
return null;
}if (Double.isNaN$D(x2)) {
return p$1.splitIntegral$D.apply(this, [x1]);
}if (x1 == x2 ) return null;
if (x1 < x2 ) {
this.clear$D$D(x1, x2);
return null;
}var y1=this.getYValueAt$D(x1);
var y2=this.getYValueAt$D(x2);
this.haveRegions=true;
var $in=Clazz.new_($I$(4,1)).setInt$D$D$jspecview_common_Spectrum$D$D$D(x1, y1, this.spec, Math.abs(y2 - y1) * 100 * this.normalizationFactor , x2, y2);
this.clear$D$D(x1, x2);
this.addLast$O($in);
$I$(5).sort$java_util_List$java_util_Comparator(this, C$.c);
return $in;
});

Clazz.newMeth(C$, 'splitIntegral$D',  function (x) {
var i=this.find$D(x);
if (i < 0) return null;
var integral=this.removeItemAt$I(i);
var x0=integral.getXVal$();
var x2=integral.getXVal2$();
this.addIntegralRegion$D$D(x0, x);
return this.addIntegralRegion$D$D(x, x2);
}, p$1);

Clazz.newMeth(C$, 'setSpecShift$D',  function (dx) {
$I$(3).shiftX$jspecview_common_CoordinateA$D(this.xyCoords, dx);
for (var i=this.size$(); --i >= 1; ) {
this.get$I(i).addSpecShift$D(dx);
}
});

Clazz.newMeth(C$, 'addMarks$S',  function (ppms) {
ppms=$I$(6).rep$S$S$S(" " + ppms, ",", " ");
ppms=$I$(6).rep$S$S$S(ppms, " -", " #");
ppms=$I$(6).rep$S$S$S(ppms, "--", "-#");
ppms=ppms.replace$C$C("-", "^");
ppms=ppms.replace$C$C("#", "-");
var tokens=$I$(7).getTokens$S(ppms);
for (var i=0; i < tokens.size$(); i++) {
try {
var s=tokens.get$I(i);
var norm=0;
var pt=s.indexOf$I("^");
if (pt < 0) continue;
var pt2=s.indexOf$I(":");
if (pt2 > pt) {
norm=Double.valueOf$S(s.substring$I(pt2 + 1).trim$()).doubleValue$();
s=s.substring$I$I(0, pt2).trim$();
}var x2=Double.valueOf$S(s.substring$I$I(0, pt).trim$()).doubleValue$();
var x1=Double.valueOf$S(s.substring$I(pt + 1).trim$()).doubleValue$();
if (x1 == 0  && x2 == 0  ) this.clear$();
if (x1 == x2 ) continue;
var m=this.addIntegralRegion$D$D(Math.max(x1, x2), Math.min(x1, x2));
if (m != null  && norm > 0  ) this.setSelectedIntegral$jspecview_common_Measurement$D(m, norm);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
continue;
} else {
throw e;
}
}
}
});

Clazz.newMeth(C$, 'calculateIntegral$',  function () {
var specXyCoords=this.spec.getXYCoords$();
this.xyCoords=Clazz.array($I$(3), [specXyCoords.length]);
this.integralTotal=0;
p$1.checkRange.apply(this, []);
var minY=1.0E100;
for (var i=0; i < specXyCoords.length; i++) {
var y=specXyCoords[i].getYVal$();
if (y < minY  && y >= 0  ) minY=y;
}
var minI=1.0E100;
var maxI=-1.0E100;
for (var i=0; i < specXyCoords.length; i++) {
var y=specXyCoords[i].getYVal$();
this.integralTotal+=(y - minY);
if (this.integralTotal < minI ) minI=this.integralTotal;
if (this.integralTotal > maxI ) maxI=this.integralTotal;
}
this.integralTotal=maxI - minI;
this.intRange=(this.percentRange / 100) / this.integralTotal;
this.offset=(this.percentOffset / 100);
var integral=0;
for (var i=specXyCoords.length; --i >= 0; ) {
var y=specXyCoords[i].getYVal$();
integral+=(y - minY);
this.xyCoords[i]=Clazz.new_($I$(3,1)).set$D$D(specXyCoords[i].getXVal$(), integral * this.intRange + this.offset);
}
return this.xyCoords;
});

Clazz.newMeth(C$, 'checkRange',  function () {
this.percentOffset=Math.max(5, this.percentOffset);
this.percentRange=Math.max(10, this.percentRange);
}, p$1);

Clazz.newMeth(C$, 'getIntegrationRatiosFromString$jspecview_common_Spectrum$S',  function (spec, key_values) {
var ratios=Clazz.new_($I$(8,1));
var allParamTokens=Clazz.new_($I$(9,1).c$$S$S,[key_values, ","]);
while (allParamTokens.hasMoreTokens$()){
var token=allParamTokens.nextToken$();
var eachParam=Clazz.new_($I$(9,1).c$$S$S,[token, ":"]);
var ratio=Clazz.new_($I$(10,1)).setA$D$D$jspecview_common_Spectrum$S$Z$Z$I$I(Double.parseDouble$S(eachParam.nextToken$()), 0.0, spec, eachParam.nextToken$(), true, false, 0, 0);
ratios.addLast$O(ratio);
}
return ratios;
}, 1);

Clazz.newMeth(C$, 'getXYCoords$',  function () {
return this.xyCoords;
});

Clazz.newMeth(C$, 'getPercentYValueAt$D',  function (x) {
return this.getYValueAt$D(x) * 100;
});

Clazz.newMeth(C$, 'dispose$',  function () {
this.spec=null;
this.xyCoords=null;
});

Clazz.newMeth(C$, 'setSelectedIntegral$jspecview_common_Measurement$D',  function (integral, val) {
var val0=integral.getValue$();
var factor=(val <= 0  ? 1 / this.normalizationFactor : val / val0);
p$1.factorAllIntegrals$D$Z.apply(this, [factor, val <= 0 ]);
});

Clazz.newMeth(C$, 'factorAllIntegrals$D$Z',  function (factor, isReset) {
for (var i=0; i < this.size$(); i++) {
var m=this.get$I(i);
m.setValue$D(factor * m.getValue$());
}
this.normalizationFactor=(isReset ? 1 : this.normalizationFactor * factor);
}, p$1);

Clazz.newMeth(C$, 'clear$',  function () {
C$.superclazz.prototype.clear$.apply(this, []);
});

Clazz.newMeth(C$, 'remove$I',  function (i) {
return this.removeItemAt$I(i);
});

Clazz.newMeth(C$, 'getBitSet$',  function () {
var bs=$I$(11).newN$I(this.xyCoords.length);
if (this.size$() == 0) {
bs.setBits$I$I(0, this.xyCoords.length);
return bs;
}for (var i=this.size$(); --i >= 0; ) {
var m=this.get$I(i);
var x1=$I$(3,"getNearestIndexForX$jspecview_common_CoordinateA$D",[this.xyCoords, m.getXVal$()]);
var x2=$I$(3,"getNearestIndexForX$jspecview_common_CoordinateA$D",[this.xyCoords, m.getXVal2$()]);
bs.setBits$I$I(Math.min(x1, x2), Math.max(x1, x2));
}
return bs;
});

Clazz.newMeth(C$, 'getMeasurementListArray$S',  function (units) {
var data=Clazz.array(String, [this.size$(), null]);
for (var pt=0, i=this.size$(); --i >= 0; ) data[pt++]=Clazz.array(String, -1, ["" + pt, $I$(12,"formatDecimalDbl$D$I",[this.get$I(i).getXVal$(), 2]), $I$(12,"formatDecimalDbl$D$I",[this.get$I(i).getXVal2$(), 2]), this.get$I(i).text]);

return data;
});

Clazz.newMeth(C$, 'getMeasurementListArrayReal$S',  function (units) {
var data=$I$(13,"newDouble2$I",[this.size$()]);
for (var pt=0, i=this.size$(); --i >= 0; pt++) data[pt]=Clazz.array(Double.TYPE, -1, [this.get$I(i).getXVal$(), this.get$I(i).getXVal2$(), this.get$I(i).getValue$()]);

return data;
});

Clazz.newMeth(C$, 'getDataHeader$',  function () {
return C$.$HEADER;
});

Clazz.newMeth(C$, 'shiftY$I$I$I$I',  function (yOld, yNew, yPixel0, yPixels) {
var pt=((100.0 * (yPixel0 + yPixels - yNew) / yPixels)|0);
if (yOld < 0) pt-=this.percentOffset;
if (yOld < 0) {
this.update$D$D$D(0, this.percentOffset, pt);
} else {
this.update$D$D$D(0, pt, this.percentRange);
}});

Clazz.newMeth(C$, 'autoIntegrate$',  function () {
if (this.xyCoords == null ) this.calculateIntegral$();
if (this.xyCoords.length == 0) return;
this.clear$();
var iStart=-1;
var cutoff=1.0E-4;
var nCount=0;
var nMin=20;
var y0=this.xyCoords[this.xyCoords.length - 1].getYVal$();
for (var i=this.xyCoords.length - 1; --i >= 0; ) {
var y=this.xyCoords[i].getYVal$();
++nCount;
if ((y - y0) < cutoff  && iStart < 0 ) {
if (y < y0 ) {
y0=y;
nCount=0;
}continue;
}if (iStart < 0) {
iStart=i + Math.min(nCount, nMin);
y0=y;
nCount=0;
continue;
}if ((y - y0) < cutoff ) {
if (nCount == 1) y0=y;
if (nCount >= nMin) {
this.addIntegralRegion$D$D(this.xyCoords[iStart].getXVal$(), this.xyCoords[i].getXVal$());
iStart=-1;
y0=y;
nCount=0;
}} else {
nCount=0;
y0=y;
}}
var nH=this.spec.getHydrogenCount$();
if (nH > 0) p$1.factorAllIntegrals$D$Z.apply(this, [nH / this.percentRange, false]);
});

Clazz.newMeth(C$, 'getInfo$java_util_Map',  function (info) {
info.put$O$O("offset", Double.valueOf$D(this.myParams.integralOffset));
info.put$O$O("range", Double.valueOf$D(this.myParams.integralRange));
info.put$O$O("normalizationFactor", Double.valueOf$D(this.normalizationFactor));
info.put$O$O("integralTotal", Double.valueOf$D(this.integralTotal));
C$.superclazz.prototype.getInfo$java_util_Map.apply(this, [info]);
});

Clazz.newMeth(C$, 'setMinimumIntegral$D',  function (val) {
for (var i=this.size$(); --i >= 0; ) if (this.get$I(i).getValue$() < val ) this.removeItemAt$I(i);

});

C$.$static$=function(){C$.$static$=0;
C$.c=Clazz.new_($I$(1,1));
C$.$HEADER=Clazz.array(String, -1, ["peak", "start/ppm", "end/ppm", "value"]);
};
;
(function(){/*e*/var C$=Clazz.newClass(P$.IntegralData, "IntMode", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getMode$S',  function (value) {
for (var mode, $mode = 0, $$mode = C$.values$(); $mode<$$mode.length&&((mode=($$mode[$mode])),1);$mode++) if (value.startsWith$S(mode.name$())) return mode;

return C$.NA;
}, 1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "OFF", 0, []);
Clazz.newEnumConst($vals, C$.c$, "ON", 1, []);
Clazz.newEnumConst($vals, C$.c$, "TOGGLE", 2, []);
Clazz.newEnumConst($vals, C$.c$, "AUTO", 3, []);
Clazz.newEnumConst($vals, C$.c$, "LIST", 4, []);
Clazz.newEnumConst($vals, C$.c$, "MARK", 5, []);
Clazz.newEnumConst($vals, C$.c$, "MIN", 6, []);
Clazz.newEnumConst($vals, C$.c$, "UPDATE", 7, []);
Clazz.newEnumConst($vals, C$.c$, "CLEAR", 8, []);
Clazz.newEnumConst($vals, C$.c$, "NA", 9, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:56 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
