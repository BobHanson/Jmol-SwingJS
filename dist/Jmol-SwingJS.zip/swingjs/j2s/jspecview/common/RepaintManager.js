(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[[0,'jspecview.common.JSViewer']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "RepaintManager");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['repaintPending'],'O',['vwr','jspecview.common.JSViewer']]]

Clazz.newMeth(C$, 'c$$jspecview_common_JSViewer',  function (viewer) {
;C$.$init$.apply(this);
this.vwr=viewer;
}, 1);

Clazz.newMeth(C$, 'refresh$',  function () {
if (this.repaintPending) {
return false;
}this.repaintPending=true;
var applet=this.vwr.html5Applet;
var jmol=($I$(1).isJS && !$I$(1).isSwingJS  ? $I$(1).jmolObject : null);
if (jmol == null ) {
this.vwr.selectedPanel.repaint$();
} else {
jmol.repaint(applet, false);
this.repaintDone$();
}return true;
});

Clazz.newMeth(C$, 'repaintDone$',  function () {
this.repaintPending=false;
this.notify$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:28 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
