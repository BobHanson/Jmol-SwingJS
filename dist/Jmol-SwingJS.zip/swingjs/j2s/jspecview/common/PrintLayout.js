(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "PrintLayout");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.imageableX=0;
this.imageableY=0;
this.paperHeight=((Math.min(11.0, 11.69) * 72)|0);
this.paperWidth=((Math.min(8.5, 8.27) * 72)|0);
this.imageableHeight=this.paperHeight;
this.imageableWidth=this.paperWidth;
this.layout="landscape";
this.position="fit to page";
this.showGrid=true;
this.showXScale=true;
this.showYScale=true;
this.showTitle=true;
this.font="Helvetica";
this.asPDF=true;
},1);

C$.$fields$=[['Z',['showGrid','showXScale','showYScale','showTitle','asPDF'],'I',['imageableX','imageableY','paperHeight','paperWidth','imageableHeight','imageableWidth'],'S',['layout','position','font','title','date'],'O',['paper','java.lang.Object']]]

Clazz.newMeth(C$, 'c$$jspecview_common_PanelData',  function (pd) {
;C$.$init$.apply(this);
if (pd != null ) {
this.asPDF=true;
pd.setDefaultPrintOptions$jspecview_common_PrintLayout(this);
}}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:06 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
