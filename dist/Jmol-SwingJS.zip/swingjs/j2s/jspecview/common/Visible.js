(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[[0,'javajs.util.CU']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Visible", null, null, 'jspecview.api.VisibleInterface');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getColour$jspecview_common_Spectrum$Z',  function (spec, useFitted) {
var xyCoords=spec.getXYCoords$();
var isAbsorbance=spec.isAbsorbance$();
var xyzd=Clazz.array(Double.TYPE, [4]);
C$.getXYZfitted$jspecview_common_CoordinateA$Z$DA(xyCoords, isAbsorbance, xyzd);
xyzd[0]/=xyzd[3];
xyzd[1]/=xyzd[3];
xyzd[2]/=xyzd[3];
var rgb=Clazz.array(Double.TYPE, -1, [xyzd[0] * 3.241 + xyzd[1] * -1.5374 + xyzd[2] * -0.4986, xyzd[0] * -0.9692 + xyzd[1] * 1.876 + xyzd[2] * 0.0416, xyzd[0] * 0.0556 + xyzd[1] * -0.204 + xyzd[2] * 1.057]);
var gamma=2.4;
for (var i=0; i < 3; i++) rgb[i]=(rgb[i] > 0.00304  ? 1.055 * Math.pow(rgb[i], 1 / gamma) - 0.055 : 12.92 * rgb[i]);

var c=$I$(1,"rgb$I$I$I",[C$.fix$D(rgb[0]), C$.fix$D(rgb[1]), C$.fix$D(rgb[2])]);
return c;
});

Clazz.newMeth(C$, 'fix$D',  function (d) {
return (d <= 0  ? 0 : d >= 1  ? 255 : Long.$ival(Math.round$D(255 * d)));
}, 1);

Clazz.newMeth(C$, 'getXYZfitted$jspecview_common_CoordinateA$Z$DA',  function (xyCoords, isAbsorbance, xyzd) {
var cie;
var xb;
var yb;
var zb;
for (var i=xyCoords.length; --i >= 0; ) {
var x=xyCoords[i].getXVal$();
if (x < 400  || x > 700  ) continue;
cie=C$.gauss$D$D$D(85.7145, 2.05719E-5, x - 607.263) + C$.gauss$D$D$D(57.7256, 1.26451E-4, x - 457.096);
xb=C$.gauss$D$D$D(1.06561, 5.00819E-4, x - 598.623) + C$.gauss$D$D$D(0.283831, 0.00292745, x - 435.734) + C$.gauss$D$D$D(0.113771, 0.00192849, x - 549.271) + C$.gauss$D$D$D(0.239103, 0.00255944, x - 460.547) ;
yb=C$.gauss$D$D$D(0.239617, 0.00117296, x - 530.517) + C$.gauss$D$D$D(0.910377, 3.00984E-4, x - 565.635) + C$.gauss$D$D$D(0.0311013, 0.00152386, x - 463.833) ;
zb=C$.gauss$D$D$D(0.988366, 0.00220336, x - 456.345) + C$.gauss$D$D$D(0.381551, 8.48554E-4, x - 450.871) + C$.gauss$D$D$D(0.355693, 6.28546E-4, x - 470.668) + C$.gauss$D$D$D(0.81862, 0.00471059, x - 433.144) ;
var y=xyCoords[i].getYVal$();
if (isAbsorbance) y=Math.pow(10, -Math.max(y, 0));
xyzd[0]+=y * xb * cie ;
xyzd[1]+=y * yb * cie ;
xyzd[2]+=y * zb * cie ;
xyzd[3]+=yb * cie;
}
}, 1);

Clazz.newMeth(C$, 'gauss$D$D$D',  function (a, b, x) {
return a * Math.exp(-b * x * x );
}, 1);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:06 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
