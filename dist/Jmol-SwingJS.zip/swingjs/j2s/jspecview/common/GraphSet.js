(function(){var P$=Clazz.newPackage("jspecview.common"),p$1={},I$=[[0,'javajs.util.Lst','javajs.util.BS','jspecview.common.Coordinate','java.util.Hashtable',['jspecview.common.Annotation','.AType'],['jspecview.common.PanelData','.LinkMode'],'jspecview.common.ColorParameters','jspecview.common.ViewData','jspecview.common.ScaleData','jspecview.common.Measurement','jspecview.common.MeasurementData','jspecview.common.PlotWidget','jspecview.common.ScriptToken','javajs.util.DF','jspecview.common.Spectrum',['jspecview.common.GraphSet','.Highlight'],'javajs.util.PT','org.jmol.util.Logger',['jspecview.common.IntegralData','.IntMode'],'jspecview.common.PeakPickEvent','jspecview.common.PeakData','jspecview.common.IntegralData','jspecview.common.Parameters','javajs.api.GenericColor','jspecview.common.ImageView','jspecview.common.ColoredAnnotation','jspecview.common.Annotation']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "GraphSet", function(){
Clazz.newInstance(this, arguments,0,C$);
}, null, 'jspecview.common.XYScaleConverter');
C$.$classes$=[['Highlight',2]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.highlights=Clazz.new_($I$(1,1));
this.spectra=Clazz.new_($I$(1,1));
this.isSplittable=true;
this.allowStacking=true;
this.graphsTemp=Clazz.new_($I$(1,1));
this.iSpectrumSelected=-1;
this.stackSelected=false;
this.bsSelected=Clazz.new_($I$(2,1));
this.nSplit=1;
this.yStackOffsetPercent=0;
this.showAllStacked=true;
this.fracX=1;
this.fracY=1;
this.fX0=0;
this.fY0=0;
this.allowStackedYScale=true;
this.xAxisLeftToRight=true;
this.iPreviousSpectrumClicked=-1;
this.lastClickX=NaN;
this.lastPixelX=2147483647;
this.coordTemp=Clazz.new_($I$(3,1));
this.FONT_PLAIN=0;
this.FONT_BOLD=1;
this.FONT_ITALIC=2;
this.lastXMax=NaN;
this.lastSpecClicked=-1;
this.xPixelMovedTo=-1;
this.xPixelMovedTo2=-1;
this.mapX=Clazz.new_($I$(4,1));
this.widgetsAreSet=true;
this.COLOR_GREY=-3;
this.COLOR_BLACK=-2;
this.COLOR_INTEGRAL=-1;
},1);

C$.$fields$=[['Z',['cur1D2Locked','isSplittable','allowStacking','isLinked','haveSingleYScale','stackSelected','reversePlot','showAllStacked','sticky2Dcursor','allowStackedYScale','drawXAxisLeftToRight','xAxisLeftToRight','haveSelectedSpectrum','zoomEnabled','is2DSpectrum','inPlotMove','haveLeftRightArrows','widgetsAreSet'],'D',['fracX','fracY','fX0','fY0','lastClickX','lastXMax','yValueMovedTo','xValueMovedTo'],'I',['iSpectrumMovedTo','iSpectrumClicked','iSpectrumSelected','nSplit','yStackOffsetPercent','nSpectra','xPixel0','yPixel0','xPixel1','yPixel1','xVArrows','xHArrows','yHArrows','xPixel00','yPixel00','xPixel11','yPixel11','yPixel000','xPixels','yPixels','xPixel10','xPixels0','iPreviousSpectrumClicked','currentZoomIndex','lastPixelX','height','width','right','top','left','bottom','FONT_PLAIN','FONT_BOLD','FONT_ITALIC','lastSpecClicked','xPixelMovedTo','xPixelMovedTo2','xPixelPlot1','xPixelPlot0','yPixelPlot0','yPixelPlot1','closerX','closerY','splitterX','splitterY','lastIntDragX','nextClickMode','COLOR_GREY','COLOR_BLACK','COLOR_INTEGRAL'],'O',['gs2dLinkedX','jspecview.common.GraphSet','+gs2dLinkedY','highlights','javajs.util.Lst','+spectra','+annotations','selectedSpectrumMeasurements','jspecview.common.MeasurementData','+selectedSpectrumIntegrals','lastAnnotation','jspecview.common.Annotation','pendingMeasurement','jspecview.common.Measurement','pendingIntegral','jspecview.common.Integral','graphsTemp','javajs.util.Lst','widgets','jspecview.common.PlotWidget[]','bsSelected','javajs.util.BS','viewData','jspecview.common.ViewData','viewList','javajs.util.Lst','imageView','jspecview.common.ImageView','pd','jspecview.common.PanelData','zoomBox1D','jspecview.common.PlotWidget','+zoomBox2D','+pin1Dx0','+pin1Dx1','+pin1Dy0','+pin1Dy1','+pin1Dx01','+pin1Dy01','+pin2Dx0','+pin2Dx1','+pin2Dy0','+pin2Dy1','+pin2Dx01','+pin2Dy01','+cur2Dx0','+cur2Dx1','+cur1D2x1','+cur1D2x2','+cur2Dy','piMouseOver','jspecview.common.PeakInfo','coordTemp','jspecview.common.Coordinate','selectedMeasurement','jspecview.common.Measurement','selectedIntegral','jspecview.common.Integral','nextClickForSetPeak','Double','mapX','java.util.Map','+dialogs','aIntegrationRatios','Object[]','jsvp','jspecview.api.JSVPanel','image2D','java.lang.Object','plotColors','javajs.api.GenericColor[]','g2d','org.jmol.api.GenericGraphics','gMain','java.lang.Object']]
,['D',['RT2'],'O',['veryLightGrey','javajs.api.GenericColor']]]

Clazz.newMeth(C$, 'c$$jspecview_common_PanelData',  function (pd) {
;C$.$init$.apply(this);
this.pd=pd;
this.jsvp=pd.jsvp;
this.g2d=pd.g2d;
}, 1);

Clazz.newMeth(C$, 'setSpectrumMovedTo$I',  function (i) {
return this.iSpectrumMovedTo=i;
}, p$1);

Clazz.newMeth(C$, 'setSpectrumClicked$I',  function (i) {
this.stackSelected=this.showAllStacked;
if (i < 0 || this.iSpectrumClicked != i ) {
this.lastClickX=NaN;
this.lastPixelX=2147483647;
}this.iSpectrumClicked=p$1.setSpectrumSelected$I.apply(this, [p$1.setSpectrumMovedTo$I.apply(this, [i])]);
}, p$1);

Clazz.newMeth(C$, 'setSpectrumSelected$I',  function (i) {
var isNew=(i != this.iSpectrumSelected);
this.iSpectrumSelected=i;
if (isNew) {
this.getCurrentView$();
}return this.iSpectrumSelected;
}, p$1);

Clazz.newMeth(C$, 'closeDialogsExcept$jspecview_common_Annotation_AType',  function (type) {
if (this.dialogs != null ) for (var e, $e = this.dialogs.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) {
var ad=e.getValue$();
if (Clazz.instanceOf(ad, "jspecview.dialog.JSVDialog") && (type === $I$(5).NONE  || ad.getAType$() !== type  ) ) (ad).setVisible$Z(false);
}
});

Clazz.newMeth(C$, 'dispose$',  function () {
this.spectra=null;
this.viewData=null;
this.viewList=null;
this.annotations=null;
this.lastAnnotation=null;
this.pendingMeasurement=null;
this.imageView=null;
this.graphsTemp=null;
this.widgets=null;
p$1.disposeImage.apply(this, []);
if (this.dialogs != null ) for (var e, $e = this.dialogs.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) {
var ad=e.getValue$();
if (Clazz.instanceOf(ad, "jspecview.dialog.JSVDialog")) (ad).dispose$();
}
this.dialogs=null;
});

Clazz.newMeth(C$, 'isDrawNoSpectra',  function () {
return (this.iSpectrumSelected == -2147483648);
}, p$1);

Clazz.newMeth(C$, 'getFixedSelectedSpectrumIndex',  function () {
return Math.max(this.iSpectrumSelected, 0);
}, p$1);

Clazz.newMeth(C$, 'getSpectrum$',  function () {
return this.getSpectrumAt$I(p$1.getFixedSelectedSpectrumIndex.apply(this, [])).getCurrentSubSpectrum$();
});

Clazz.newMeth(C$, 'getSpectrumAt$I',  function (index) {
return this.spectra.get$I(index);
});

Clazz.newMeth(C$, 'getSpectrumIndex$jspecview_common_Spectrum',  function (spec) {
for (var i=this.spectra.size$(); --i >= 0; ) if (this.spectra.get$I(i) === spec ) return i;

return -1;
});

Clazz.newMeth(C$, 'addSpec$jspecview_common_Spectrum',  function (spec) {
this.spectra.addLast$O(spec);
++this.nSpectra;
}, p$1);

Clazz.newMeth(C$, 'splitStack$Z',  function (doSplit) {
if (doSplit && this.isSplittable ) {
this.nSplit=this.nSpectra;
this.showAllStacked=false;
p$1.setSpectrumClicked$I.apply(this, [this.iSpectrumSelected]);
this.pd.currentSplitPoint=this.iSpectrumSelected;
} else {
this.nSplit=1;
this.showAllStacked=this.allowStacking && !doSplit ;
p$1.setSpectrumClicked$I.apply(this, [this.iSpectrumSelected]);
}this.stackSelected=false;
C$.setFractionalPositions$jspecview_common_PanelData$javajs_util_Lst$jspecview_common_PanelData_LinkMode(this.pd, this.pd.graphSets, $I$(6).NONE);
this.pd.setTaintedAll$();
});

Clazz.newMeth(C$, 'setPositionForFrame$I',  function (iSplit) {
if (iSplit < 0) iSplit=0;
var marginalHeight=this.height - 50;
this.xPixel00=((this.width * this.fX0)|0);
this.xPixel11=((this.xPixel00 + this.width * this.fracX - 1)|0);
this.xHArrows=this.xPixel00 + 25;
this.xVArrows=this.xPixel11 - (this.right/2|0);
this.xPixel0=this.xPixel00 + ((this.left * (1 - this.fX0))|0);
this.xPixel10=this.xPixel1=this.xPixel11 - this.right;
this.xPixels0=this.xPixels=this.xPixel1 - this.xPixel0 + 1;
this.yPixel000=(this.fY0 == 0  ? 25 : 0) + ((this.height * this.fY0)|0);
this.yPixel00=this.yPixel000 + ((marginalHeight * this.fracY * iSplit )|0);
this.yPixel11=this.yPixel00 + ((marginalHeight * this.fracY)|0) - 1;
this.yHArrows=this.yPixel11 - 12;
this.yPixel0=this.yPixel00 + (this.top/2|0);
this.yPixel1=this.yPixel11 - (this.bottom/2|0);
this.yPixels=this.yPixel1 - this.yPixel0 + 1;
if (this.imageView != null  && this.is2DSpectrum ) {
p$1.setImageWindow.apply(this, []);
if (this.pd.display1D) {
var widthRatio=(this.pd.display1D ? 1.0 * (this.xPixels0 - this.imageView.xPixels) / this.xPixels0 : 1);
this.xPixels=(Math.floor(widthRatio * this.xPixels0 * 0.8 )|0);
this.xPixel1=this.xPixel0 + this.xPixels - 1;
} else {
this.xPixels=0;
this.xPixel1=this.imageView.xPixel0 - 30;
}}}, p$1);

Clazz.newMeth(C$, 'hasPoint$I$I',  function (xPixel, yPixel) {
return (xPixel >= this.xPixel00 && xPixel <= this.xPixel11  && yPixel >= this.yPixel000  && yPixel <= this.yPixel11 * this.nSplit );
}, p$1);

Clazz.newMeth(C$, 'isInPlotRegion$I$I',  function (xPixel, yPixel) {
return (xPixel >= this.xPixel0 && xPixel <= this.xPixel1  && yPixel >= this.yPixel0  && yPixel <= this.yPixel1 );
}, p$1);

Clazz.newMeth(C$, 'getSplitPoint$I',  function (yPixel) {
return Math.max(0, Math.min((((yPixel - this.yPixel000)/(this.yPixel11 - this.yPixel00)|0)), this.nSplit - 1));
});

Clazz.newMeth(C$, 'isSplitWidget$I$I',  function (xPixel, yPixel) {
return p$1.isFrameBox$I$I$I$I.apply(this, [xPixel, yPixel, this.splitterX, this.splitterY]);
}, p$1);

Clazz.newMeth(C$, 'isCloserWidget$I$I',  function (xPixel, yPixel) {
return p$1.isFrameBox$I$I$I$I.apply(this, [xPixel, yPixel, this.closerX, this.closerY]);
}, p$1);

Clazz.newMeth(C$, 'initGraphSet$I$I',  function (startIndex, endIndex) {
if (C$.veryLightGrey == null ) C$.veryLightGrey=this.g2d.getColor3$I$I$I(200, 200, 200);
this.setPlotColors$O($I$(7).defaultPlotColors);
this.xAxisLeftToRight=this.getSpectrumAt$I(0).shouldDisplayXAxisIncreasing$();
p$1.setDrawXAxis.apply(this, []);
var startIndices=Clazz.array(Integer.TYPE, [this.nSpectra]);
var endIndices=Clazz.array(Integer.TYPE, [this.nSpectra]);
this.bsSelected.setBits$I$I(0, this.nSpectra);
this.allowStackedYScale=true;
if (endIndex <= 0) endIndex=2147483647;
this.isSplittable=(this.nSpectra > 1);
this.allowStacking=(this.spectra.get$I(0).isStackable$());
this.showAllStacked=this.allowStacking && (this.nSpectra > 1) ;
for (var i=0; i < this.nSpectra; i++) {
var iLast=this.spectra.get$I(i).getXYCoords$().length - 1;
startIndices[i]=$I$(3).intoRange$I$I$I(startIndex, 0, iLast);
endIndices[i]=$I$(3).intoRange$I$I$I(endIndex, 0, iLast);
this.allowStackedYScale=!!(this.allowStackedYScale&((this.spectra.get$I(i).getYUnits$().equals$O(this.spectra.get$I(0).getYUnits$()) && this.spectra.get$I(i).getUserYFactor$() == this.spectra.get$I(0).getUserYFactor$()  )));
}
p$1.getView$D$D$D$D$IA$IA$jspecview_common_ScaleDataA$jspecview_common_ScaleDataA.apply(this, [0, 0, 0, 0, startIndices, endIndices, null, null]);
this.viewList=Clazz.new_($I$(1,1));
this.viewList.addLast$O(this.viewData);
}, p$1);

Clazz.newMeth(C$, 'getView$D$D$D$D$IA$IA$jspecview_common_ScaleDataA$jspecview_common_ScaleDataA',  function (x1, x2, y1, y2, startIndices, endIndices, viewScales, yScales) {
var graphs=(this.graphsTemp.size$() == 0 ? this.spectra : this.graphsTemp);
var subspecs=this.getSpectrumAt$I(0).getSubSpectra$();
var dontUseSubspecs=(subspecs == null  || subspecs.size$() == 2 && subspecs.get$I(1).isImaginary$()  );
var is2D=!this.getSpectrumAt$I(0).is1D$();
var useFirstSubSpecOnly=false;
if (is2D && useFirstSubSpecOnly  || dontUseSubspecs && y1 == y2   ) {
graphs=this.spectra;
} else if (y1 == y2 ) {
this.viewData=Clazz.new_([subspecs, y1, y2, this.getSpectrum$().isContinuous$()],$I$(8,1).c$$javajs_util_Lst$D$D$Z);
graphs=null;
}if (graphs != null ) {
this.viewData=Clazz.new_([graphs, y1, y2, startIndices, endIndices, this.getSpectrumAt$I(0).isContinuous$(), is2D],$I$(8,1).c$$javajs_util_Lst$D$D$IA$IA$Z$Z);
if (x1 != x2 ) this.getScale$().setXRange$D$D(x1, x2);
}if (viewScales != null ) {
$I$(9,"copyScaleFactors$jspecview_common_ScaleDataA$jspecview_common_ScaleDataA",[viewScales, this.viewData.getScaleData$()]);
if (yScales != null ) $I$(9,"copyYScales$jspecview_common_ScaleDataA$jspecview_common_ScaleDataA",[yScales, this.viewData.getScaleData$()]);
this.getCurrentView$();
}}, p$1);

Clazz.newMeth(C$, 'isNearby$jspecview_common_Coordinate$jspecview_common_Coordinate$jspecview_common_XYScaleConverter$I',  function (a1, a2, c, range) {
var x=a1.getXVal$();
var xp1=c.toPixelX$D(x);
var yp1=this.toPixelY$D(a1.getYVal$());
x=a2.getXVal$();
var xp2=c.toPixelX$D(x);
var yp2=this.toPixelY$D(a2.getYVal$());
return (Math.abs(xp1 - xp2) + Math.abs(yp1 - yp2) < range);
}, p$1);

Clazz.newMeth(C$, 'setReversePlot$Z',  function (val) {
this.reversePlot=val;
if (this.reversePlot) this.closeDialogsExcept$jspecview_common_Annotation_AType($I$(5).NONE);
p$1.setDrawXAxis.apply(this, []);
});

Clazz.newMeth(C$, 'setDrawXAxis',  function () {
this.drawXAxisLeftToRight=!!(this.xAxisLeftToRight ^ this.reversePlot);
for (var i=0; i < this.spectra.size$(); i++) (this.spectra.get$I(i)).setExportXAxisDirection$Z(this.drawXAxisLeftToRight);

}, p$1);

Clazz.newMeth(C$, 'isInTopBar$I$I',  function (xPixel, yPixel) {
return (xPixel == this.fixX$I(xPixel) && yPixel > this.pin1Dx0.yPixel0 - 2  && yPixel < this.pin1Dx0.yPixel1 );
}, p$1);

Clazz.newMeth(C$, 'isInTopBar2D$I$I',  function (xPixel, yPixel) {
return (this.imageView != null  && xPixel == this.imageView.fixX$I(xPixel)  && yPixel > this.pin2Dx0.yPixel0 - 2  && yPixel < this.pin2Dx0.yPixel1 );
}, p$1);

Clazz.newMeth(C$, 'isInRightBar$I$I',  function (xPixel, yPixel) {
return (yPixel == this.fixY$I(yPixel) && xPixel > this.pin1Dy0.xPixel1  && xPixel < this.pin1Dy0.xPixel0 + 2 );
}, p$1);

Clazz.newMeth(C$, 'isInRightBar2D$I$I',  function (xPixel, yPixel) {
return (this.imageView != null  && yPixel == this.fixY$I(yPixel)  && xPixel > this.pin2Dy0.xPixel1  && xPixel < this.pin2Dy0.xPixel0 + 2 );
}, p$1);

Clazz.newMeth(C$, 'toX0$I',  function (xPixel) {
return this.viewList.get$I(0).getScale$().toX0$I$I$I$Z(this.fixX$I(xPixel), this.xPixel0, this.xPixel1, this.drawXAxisLeftToRight);
}, p$1);

Clazz.newMeth(C$, 'toY0$I',  function (yPixel) {
return this.viewList.get$I(0).getScale$().toY0$I$I$I(this.fixY$I(yPixel), this.yPixel0, this.yPixel1);
}, p$1);

Clazz.newMeth(C$, 'toX$I',  function (xPixel) {
if (this.imageView != null  && this.imageView.isXWithinRange$I(xPixel) ) return this.imageView.toX$I(xPixel);
return this.getScale$().toX$I$I$Z(this.fixX$I(xPixel), this.xPixel1, this.drawXAxisLeftToRight);
});

Clazz.newMeth(C$, 'toY$I',  function (yPixel) {
return this.getScale$().toY$I$I(yPixel, this.yPixel0);
});

Clazz.newMeth(C$, 'toPixelX$D',  function (dx) {
return this.getScale$().toPixelX$D$I$I$Z(dx, this.xPixel0, this.xPixel1, this.drawXAxisLeftToRight);
});

Clazz.newMeth(C$, 'toPixelY$D',  function (yVal) {
return this.getScale$().toPixelY$D$I(yVal, this.yPixel1);
});

Clazz.newMeth(C$, 'toPixelX0$D',  function (x) {
return this.viewList.get$I(0).getScale$().toPixelX0$D$I$I$Z(x, this.xPixel0, this.xPixel1, this.drawXAxisLeftToRight);
}, p$1);

Clazz.newMeth(C$, 'toPixelY0$D',  function (y) {
return this.fixY$I(this.viewList.get$I(0).getScale$().toPixelY0$D$I$I(y, this.yPixel0, this.yPixel1));
}, p$1);

Clazz.newMeth(C$, 'fixX$I',  function (xPixel) {
return $I$(3).intoRange$I$I$I(xPixel, this.xPixel0, this.xPixel1);
});

Clazz.newMeth(C$, 'fixY$I',  function (yPixel) {
return $I$(3).intoRange$I$I$I(yPixel, this.yPixel0, this.yPixel1);
});

Clazz.newMeth(C$, 'getXPixel0$',  function () {
return this.xPixel0;
});

Clazz.newMeth(C$, 'getXPixels$',  function () {
return this.xPixels;
});

Clazz.newMeth(C$, 'getYPixels$',  function () {
return this.yPixels;
});

Clazz.newMeth(C$, 'getScale$',  function () {
return this.viewData.getScale$();
});

Clazz.newMeth(C$, 'toPixelYint$D',  function (yVal) {
return this.yPixel1 - ((Double.isNaN$D(yVal) ? -2147483648 : this.yPixels * yVal)|0);
}, p$1);

Clazz.newMeth(C$, 'findAnnotation2D$jspecview_common_Coordinate',  function (xy) {
for (var i=this.annotations.size$(); --i >= 0; ) {
var a=this.annotations.get$I(i);
if (p$1.isNearby$jspecview_common_Coordinate$jspecview_common_Coordinate$jspecview_common_XYScaleConverter$I.apply(this, [a, xy, this.imageView, 10])) return a;
}
return null;
}, p$1);

Clazz.newMeth(C$, 'addAnnotation$jspecview_common_Annotation$Z',  function (annotation, isToggle) {
if (this.annotations == null ) this.annotations=Clazz.new_($I$(1,1));
var removed=false;
for (var i=this.annotations.size$(); --i >= 0; ) if (annotation.is2D ? p$1.isNearby$jspecview_common_Coordinate$jspecview_common_Coordinate$jspecview_common_XYScaleConverter$I.apply(this, [this.annotations.get$I(i), annotation, this.imageView, 10]) : annotation.equals$jspecview_common_Coordinate(this.annotations.get$I(i))) {
removed=true;
this.annotations.removeItemAt$I(i);
}
if (annotation.text.length$() > 0 && (!removed || !isToggle ) ) this.annotations.addLast$O(annotation);
}, p$1);

Clazz.newMeth(C$, 'setImageWindow',  function () {
this.imageView.setPixelWidthHeight$I$I((((this.pd.display1D ? 0.6 : 1) * this.xPixels0)|0), this.yPixels);
this.imageView.setXY0$jspecview_common_Spectrum$I$I(this.getSpectrumAt$I(0), (Math.floor(this.xPixel10 - this.imageView.xPixels)|0), this.yPixel0);
}, p$1);

Clazz.newMeth(C$, 'findNearestMaxMin',  function () {
if (this.nSpectra > 1 && this.iSpectrumClicked < 0 ) return false;
this.xValueMovedTo=this.getSpectrum$().findXForPeakNearest$D(this.xValueMovedTo);
this.setXPixelMovedTo$D$D$I$I(this.xValueMovedTo, 1.7976931348623157E308, 0, 0);
return !Double.isNaN$D(this.xValueMovedTo);
}, p$1);

Clazz.newMeth(C$, 'setXPixelMovedTo$D$D$I$I',  function (x1, x2, xPixel1, xPixel2) {
if (x1 == 1.7976931348623157E308  && x2 == 1.7976931348623157E308  ) {
this.xPixelMovedTo=xPixel1;
this.xPixelMovedTo2=xPixel2;
if (this.isLinked && this.sticky2Dcursor ) {
this.pd.setlinkedXMove$jspecview_common_GraphSet$D$Z(this, this.toX$I(this.xPixelMovedTo), false);
}return;
}if (x1 != 1.7976931348623157E308 ) {
this.xPixelMovedTo=this.toPixelX$D(x1);
if (this.fixX$I(this.xPixelMovedTo) != this.xPixelMovedTo) this.xPixelMovedTo=-1;
this.xPixelMovedTo2=-1;
if (x1 != 1.0E10 ) p$1.setSpectrumClicked$I.apply(this, [p$1.getFixedSelectedSpectrumIndex.apply(this, [])]);
}if (x2 != 1.7976931348623157E308 ) {
this.xPixelMovedTo2=this.toPixelX$D(x2);
}});

Clazz.newMeth(C$, 'processPendingMeasurement$I$I$I',  function (xPixel, yPixel, clickCount) {
if (!p$1.isInPlotRegion$I$I.apply(this, [xPixel, yPixel]) || p$1.is2dClick$I$I.apply(this, [xPixel, yPixel]) ) {
this.pendingMeasurement=null;
return;
}var x=this.toX$I(xPixel);
var y=this.toY$I(yPixel);
var x0=x;
var m;
switch (clickCount) {
case 0:
this.pendingMeasurement.setPt2$D$D(this.toX$I(xPixel), this.toY$I(yPixel));
break;
case 3:
case 2:
if (this.iSpectrumClicked < 0) return;
var spec=this.spectra.get$I(this.iSpectrumClicked);
this.setScale$I(this.iSpectrumClicked);
if (clickCount == 3) {
} else {
m=p$1.findMeasurement$jspecview_common_MeasurementData$I$I$I.apply(this, [this.selectedSpectrumMeasurements, xPixel, yPixel, 1]);
if (m != null ) {
x=m.getXVal$();
y=m.getYVal$();
} else if ((m=p$1.findMeasurement$jspecview_common_MeasurementData$I$I$I.apply(this, [this.selectedSpectrumMeasurements, xPixel, yPixel, 2])) != null ) {
x=m.getXVal2$();
y=m.getYVal2$();
} else {
x=p$1.getNearestPeak$jspecview_common_Spectrum$D$D.apply(this, [spec, x, y]);
}}this.pendingMeasurement=Clazz.new_($I$(10,1)).setM1$D$D$jspecview_common_Spectrum(x, y, spec);
this.pendingMeasurement.setPt2$D$D(x0, y);
this.pd.setTaintedAll$();
this.pd.repaint$();
break;
case 1:
case -2:
case -3:
var isOK=(this.pendingMeasurement != null  && p$1.isVisible$jspecview_api_AnnotationData.apply(this, [this.getDialog$jspecview_common_Annotation_AType$I($I$(5).Measurements, -1)]) );
while (isOK){
this.setScale$I(this.getSpectrumIndex$jspecview_common_Spectrum(this.pendingMeasurement.spec));
if (clickCount != 3) {
if (!p$1.findNearestMaxMin.apply(this, [])) {
isOK=false;
break;
}xPixel=this.xPixelMovedTo;
}x=this.toX$I(xPixel);
y=this.toY$I(yPixel);
this.pendingMeasurement.setPt2$D$D(x, y);
if (this.pendingMeasurement.text.length$() == 0) {
isOK=false;
break;
}p$1.setMeasurement$jspecview_common_Measurement.apply(this, [this.pendingMeasurement]);
if (clickCount != 1) {
isOK=false;
break;
}p$1.setSpectrumClicked$I.apply(this, [this.getSpectrumIndex$jspecview_common_Spectrum(this.pendingMeasurement.spec)]);
this.pendingMeasurement=Clazz.new_($I$(10,1)).setM1$D$D$jspecview_common_Spectrum(x, y, this.pendingMeasurement.spec);
break;
}
if (!isOK) this.pendingMeasurement=null;
this.pd.setTaintedAll$();
this.pd.repaint$();
break;
case 5:
if (p$1.findNearestMaxMin.apply(this, [])) {
var iSpec=p$1.getFixedSelectedSpectrumIndex.apply(this, []);
if (Double.isNaN$D(this.lastXMax) || this.lastSpecClicked != iSpec  || this.pendingMeasurement == null  ) {
this.lastXMax=this.xValueMovedTo;
this.lastSpecClicked=iSpec;
this.pendingMeasurement=Clazz.new_($I$(10,1)).setM1$D$D$jspecview_common_Spectrum(this.xValueMovedTo, this.yValueMovedTo, this.spectra.get$I(iSpec));
} else {
this.pendingMeasurement.setPt2$D$D(this.xValueMovedTo, this.yValueMovedTo);
if (this.pendingMeasurement.text.length$() > 0) p$1.setMeasurement$jspecview_common_Measurement.apply(this, [this.pendingMeasurement]);
this.pendingMeasurement=null;
this.lastXMax=NaN;
}} else {
this.lastXMax=NaN;
}break;
}
}, p$1);

Clazz.newMeth(C$, 'checkIntegralNormalizationClick$I$I',  function (xPixel, yPixel) {
if (this.selectedSpectrumIntegrals == null ) return false;
var integral=p$1.findMeasurement$jspecview_common_MeasurementData$I$I$I.apply(this, [this.selectedSpectrumIntegrals, xPixel, yPixel, -5]);
if (integral == null ) return false;
this.selectedIntegral=integral;
this.pd.normalizeIntegral$();
p$1.updateDialog$jspecview_common_Annotation_AType$I.apply(this, [$I$(5).Integration, -1]);
p$1.setSpectrumClicked$I.apply(this, [this.getSpectrumIndex$jspecview_common_Spectrum(integral.spec)]);
return true;
}, p$1);

Clazz.newMeth(C$, 'getNearestPeak$jspecview_common_Spectrum$D$D',  function (spec, x, y) {
var x0=$I$(3,"getNearestXWithYAbove$jspecview_common_CoordinateA$D$D$Z$Z",[spec.getXYCoords$(), x, y, spec.isInverted$(), false]);
var x1=$I$(3,"getNearestXWithYAbove$jspecview_common_CoordinateA$D$D$Z$Z",[spec.getXYCoords$(), x, y, spec.isInverted$(), true]);
return (Double.isNaN$D(x0) ? x1 : Double.isNaN$D(x1) ? x0 : Math.abs(x0 - x) < Math.abs(x1 - x)  ? x0 : x1);
}, p$1);

Clazz.newMeth(C$, 'findMeasurement$jspecview_common_MeasurementData$I$I$I',  function (measurements, xPixel, yPixel, iPt) {
if (measurements == null  || measurements.size$() == 0 ) return null;
if (iPt == 0) {
var m=p$1.findMeasurement$jspecview_common_MeasurementData$I$I$I.apply(this, [measurements, xPixel, yPixel, -1]);
if (m != null  || Clazz.instanceOf(measurements.get$I(0), "jspecview.common.Integral") ) return m;
return p$1.findMeasurement$jspecview_common_MeasurementData$I$I$I.apply(this, [measurements, xPixel, yPixel, -2]);
}for (var i=measurements.size$(); --i >= 0; ) {
var m=measurements.get$I(i);
var x1;
var x2;
var y1;
var y2;
if (Clazz.instanceOf(m, "jspecview.common.Integral")) {
x1=x2=this.toPixelX$D(m.getXVal2$());
y1=p$1.toPixelYint$D.apply(this, [m.getYVal$()]);
y2=p$1.toPixelYint$D.apply(this, [m.getYVal2$()]);
} else {
x1=this.toPixelX$D(m.getXVal$());
x2=this.toPixelX$D(m.getXVal2$());
y1=y2=(iPt == -2 ? this.yPixel1 - 2 : this.toPixelY$D(m.getYVal$()));
}switch (iPt) {
case 1:
if (Math.abs(xPixel - x1) + Math.abs(yPixel - y1) < 4) return m;
break;
case 2:
if (Math.abs(xPixel - x2) + Math.abs(yPixel - y2) < 4) return m;
break;
case -5:
y1=y2=((y1 + y2)/2|0);
x2=x1 + 20;
default:
case -1:
case -2:
if (C$.isOnLine$I$I$I$I$I$I(xPixel, yPixel, x1, y1, x2, y2)) return m;
break;
}
}
return null;
}, p$1);

Clazz.newMeth(C$, 'setMeasurement$jspecview_common_Measurement',  function (m) {
var iSpec=this.getSpectrumIndex$jspecview_common_Spectrum(m.spec);
var ad=this.getDialog$jspecview_common_Annotation_AType$I($I$(5).Measurements, iSpec);
if (ad == null ) this.addDialog$I$jspecview_common_Annotation_AType$jspecview_api_AnnotationData(iSpec, $I$(5).Measurements, ad=Clazz.new_([$I$(5).Measurements, m.spec],$I$(11,1).c$$jspecview_common_Annotation_AType$jspecview_common_Spectrum));
ad.getData$().addLast$O(m.copyM$());
p$1.updateDialog$jspecview_common_Annotation_AType$I.apply(this, [$I$(5).Measurements, -1]);
}, p$1);

Clazz.newMeth(C$, 'checkArrowUpDownClick$I$I',  function (xPixel, yPixel) {
var ok=false;
var f=(p$1.isArrowClick$I$I$I.apply(this, [xPixel, yPixel, 3]) ? C$.RT2 : p$1.isArrowClick$I$I$I.apply(this, [xPixel, yPixel, 4]) ? 1 / C$.RT2 : 0);
if (f != 0 ) {
if (this.nSplit > 1) p$1.setSpectrumSelected$I.apply(this, [this.iSpectrumMovedTo]);
if ((this.nSpectra == 1 || this.iSpectrumSelected >= 0 ) && this.spectra.get$I(p$1.getFixedSelectedSpectrumIndex.apply(this, [])).isTransmittance$() ) f=1 / f;
this.viewData.scaleSpectrum$I$D(this.imageView == null  ? this.iSpectrumSelected : -2, f);
ok=true;
} else if (p$1.isArrowClick$I$I$I.apply(this, [xPixel, yPixel, -1])) {
this.resetViewCompletely$();
ok=true;
}if (ok) {
if (this.imageView != null ) {
p$1.update2dImage$Z.apply(this, [false]);
p$1.resetPinsFromView.apply(this, []);
}this.pd.setTaintedAll$();
}return ok;
}, p$1);

Clazz.newMeth(C$, 'resetViewCompletely$',  function () {
this.clearViews$();
if (this.showAllStacked && !this.stackSelected ) this.closeDialogsExcept$jspecview_common_Annotation_AType($I$(5).NONE);
this.viewData.resetScaleFactors$();
p$1.updateDialogs.apply(this, []);
});

Clazz.newMeth(C$, 'checkArrowLeftRightClick$I$I',  function (xPixel, yPixel) {
if (this.haveLeftRightArrows) {
var dx=(p$1.isArrowClick$I$I$I.apply(this, [xPixel, yPixel, 1]) ? -1 : p$1.isArrowClick$I$I$I.apply(this, [xPixel, yPixel, 2]) ? 1 : 0);
if (dx != 0) {
p$1.setSpectrumClicked$I.apply(this, [(this.iSpectrumSelected + dx) % this.nSpectra]);
return true;
}if (p$1.isArrowClick$I$I$I.apply(this, [xPixel, yPixel, 0])) {
if (this.showAllStacked) {
this.showAllStacked=false;
p$1.setSpectrumClicked$I.apply(this, [p$1.getFixedSelectedSpectrumIndex.apply(this, [])]);
return true;
}this.showAllStacked=this.allowStacking;
p$1.setSpectrumSelected$I.apply(this, [-1]);
this.stackSelected=false;
}}return false;
}, p$1);

Clazz.newMeth(C$, 'isArrowClick$I$I$I',  function (xPixel, yPixel, type) {
var pt;
switch (type) {
case 3:
case 4:
case -1:
pt=((this.yPixel00 + this.yPixel11)/2|0) + (type == 3 ? -1 : type == 4 ? 1 : 0) * 15;
return (Math.abs(this.xVArrows - xPixel) < 10 && Math.abs(pt - yPixel) < 10 );
case 1:
case 2:
case 0:
pt=this.xHArrows + (type == 1 ? -1 : type == 2 ? 1 : 0) * 15;
return (Math.abs(pt - xPixel) < 10 && Math.abs(this.yHArrows - yPixel) < 10 );
}
return false;
}, p$1);

Clazz.newMeth(C$, 'setWidgetValueByUser$jspecview_common_PlotWidget',  function (pw) {
var sval;
if (pw === this.cur2Dy ) sval="" + this.imageView.toSubspectrumIndex$I(pw.yPixel0);
 else if (pw === this.pin1Dx01 ) sval="" + new Double(Math.min(this.pin1Dx0.getXVal$(), this.pin1Dx1.getXVal$())).toString() + " - " + new Double(Math.max(this.pin1Dx0.getXVal$(), this.pin1Dx1.getXVal$())).toString() ;
 else if (pw === this.pin1Dy01 ) sval="" + new Double(Math.min(this.pin1Dy0.getYVal$(), this.pin1Dy1.getYVal$())).toString() + " - " + new Double(Math.max(this.pin1Dy0.getYVal$(), this.pin1Dy1.getYVal$())).toString() ;
 else if (pw === this.pin2Dx01 ) sval="" + new Double(Math.min(this.pin2Dx0.getXVal$(), this.pin2Dx1.getXVal$())).toString() + " - " + new Double(Math.max(this.pin2Dx0.getXVal$(), this.pin2Dx1.getXVal$())).toString() ;
 else if (pw === this.pin2Dy01 ) sval="" + (Math.min(this.pin2Dy0.getYVal$(), this.pin2Dy1.getYVal$())|0) + " - " + (Math.max(this.pin2Dy0.getYVal$(), this.pin2Dy1.getYVal$())|0) ;
 else sval="" + new Double(pw.getValue$()).toString();
sval=this.pd.getInput$S$S$S("New value?", "Set Slider", sval);
if (sval == null ) return;
sval=sval.trim$();
try {
if (pw === this.pin1Dx01  || pw === this.pin1Dy01   || pw === this.pin2Dx01   || pw === this.pin2Dy01  ) {
var pt=sval.indexOf$S$I("-", 1);
if (pt < 0) return;
var val1=Double.valueOf$S(sval.substring$I$I(0, pt)).doubleValue$();
var val2=Double.valueOf$S(sval.substring$I(pt + 1)).doubleValue$();
if (pw === this.pin1Dx01 ) {
this.doZoom$D$D$D$D$Z$Z$Z$Z$Z(val1, this.pin1Dy0.getYVal$(), val2, this.pin1Dy1.getYVal$(), true, false, false, true, true);
} else if (pw === this.pin1Dy01 ) {
this.doZoom$D$D$D$D$Z$Z$Z$Z$Z(this.pin1Dx0.getXVal$(), val1, this.pin1Dx1.getXVal$(), val2, this.imageView == null , this.imageView == null , false, false, true);
} else if (pw === this.pin2Dx01 ) {
this.imageView.setView0$I$I$I$I(this.imageView.toPixelX0$D(val1), this.pin2Dy0.yPixel0, this.imageView.toPixelX0$D(val2), this.pin2Dy1.yPixel0);
this.doZoom$D$D$D$D$Z$Z$Z$Z$Z(val1, this.pin1Dy0.getYVal$(), val2, this.pin1Dy1.getYVal$(), false, false, false, true, true);
} else if (pw === this.pin2Dy01 ) {
this.imageView.setView0$I$I$I$I(this.pin2Dx0.xPixel0, this.imageView.toPixelY0$D(val1), this.pin2Dx1.xPixel0, this.imageView.toPixelY0$D(val2));
this.doZoom$D$D$D$D$Z$Z$Z$Z$Z(this.imageView.toX$I(this.imageView.xPixel0), this.getScale$().minY, this.imageView.toX$I(this.imageView.xPixel0 + this.imageView.xPixels - 1), this.getScale$().maxY, false, false, false, false, true);
}} else {
var val=Double.valueOf$S(sval).doubleValue$();
if (pw.isXtype) {
var val2=(pw === this.pin1Dx0  || pw === this.cur2Dx0   || pw === this.pin2Dx0   ? this.pin1Dx1.getXVal$() : this.pin1Dx0.getXVal$());
this.doZoom$D$D$D$D$Z$Z$Z$Z$Z(val, 0, val2, 0, !pw.is2D, false, false, true, true);
} else if (pw === this.cur2Dy ) {
p$1.setCurrentSubSpectrum$I.apply(this, [(val|0)]);
} else if (pw === this.pin2Dy0  || pw === this.pin2Dy1  ) {
var val2=(pw === this.pin2Dy0  ? this.pin2Dy1.yPixel0 : this.pin2Dy0.yPixel0);
this.imageView.setView0$I$I$I$I(this.pin2Dx0.xPixel0, this.imageView.subIndexToPixelY$I((val|0)), this.pin2Dx1.xPixel0, val2);
} else {
var val2=(pw === this.pin1Dy0  ? this.pin1Dy1.getYVal$() : this.pin1Dy0.getYVal$());
this.doZoom$D$D$D$D$Z$Z$Z$Z$Z(this.pin1Dx0.getXVal$(), val, this.pin1Dx1.getXVal$(), val2, this.imageView == null , this.imageView == null , false, false, true);
}}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'removeAllHighlights$jspecview_common_Spectrum',  function (spec) {
if (spec == null ) this.highlights.clear$();
 else for (var i=this.highlights.size$(); --i >= 0; ) if (this.highlights.get$I(i).spectrum === spec ) this.highlights.removeItemAt$I(i);

}, p$1);

Clazz.newMeth(C$, 'setCoordClicked$I$D$D',  function (xPixel, x, y) {
if (y == 0 ) this.nextClickForSetPeak=null;
if (Double.isNaN$D(x)) {
this.pd.coordClicked=null;
this.pd.coordsClicked=null;
return null;
}this.pd.coordClicked=Clazz.new_($I$(3,1)).set$D$D(this.lastClickX=x, y);
this.pd.coordsClicked=this.getSpectrum$().getXYCoords$();
this.pd.xPixelClicked=(this.lastPixelX=xPixel);
return this.pd.coordClicked;
}, p$1);

Clazz.newMeth(C$, 'setWidgets$Z$I$Z',  function (needNewPins, subIndex, doDraw1DObjects) {
if (needNewPins || this.pin1Dx0 == null  ) {
if (this.zoomBox1D == null ) p$1.newPins.apply(this, []);
 else p$1.resetPinPositions.apply(this, []);
}p$1.setDerivedPins$I.apply(this, [subIndex]);
p$1.setPinSliderPositions$Z.apply(this, [doDraw1DObjects]);
}, p$1);

Clazz.newMeth(C$, 'newPins',  function () {
this.zoomBox1D=Clazz.new_($I$(12,1).c$$S,["zoomBox1D"]);
this.pin1Dx0=Clazz.new_($I$(12,1).c$$S,["pin1Dx0"]);
this.pin1Dx1=Clazz.new_($I$(12,1).c$$S,["pin1Dx1"]);
this.pin1Dy0=Clazz.new_($I$(12,1).c$$S,["pin1Dy0"]);
this.pin1Dy1=Clazz.new_($I$(12,1).c$$S,["pin1Dy1"]);
this.pin1Dx01=Clazz.new_($I$(12,1).c$$S,["pin1Dx01"]);
this.pin1Dy01=Clazz.new_($I$(12,1).c$$S,["pin1Dy01"]);
this.cur1D2x1=Clazz.new_($I$(12,1).c$$S,["cur1D2x1"]);
this.cur1D2x1.color=$I$(13).PEAKTABCOLOR;
this.cur1D2x2=Clazz.new_($I$(12,1).c$$S,["cur1D2x2"]);
this.cur1D2x2.color=$I$(13).PEAKTABCOLOR;
if (this.imageView != null ) {
this.zoomBox2D=Clazz.new_($I$(12,1).c$$S,["zoomBox2D"]);
this.pin2Dx0=Clazz.new_($I$(12,1).c$$S,["pin2Dx0"]);
this.pin2Dx1=Clazz.new_($I$(12,1).c$$S,["pin2Dx1"]);
this.pin2Dy0=Clazz.new_($I$(12,1).c$$S,["pin2Dy0"]);
this.pin2Dy1=Clazz.new_($I$(12,1).c$$S,["pin2Dy1"]);
this.pin2Dx01=Clazz.new_($I$(12,1).c$$S,["pin2Dx01"]);
this.pin2Dy01=Clazz.new_($I$(12,1).c$$S,["pin2Dy01"]);
this.cur2Dx0=Clazz.new_($I$(12,1).c$$S,["cur2Dx0"]);
this.cur2Dx1=Clazz.new_($I$(12,1).c$$S,["cur2Dx1"]);
this.cur2Dy=Clazz.new_($I$(12,1).c$$S,["cur2Dy"]);
this.pin2Dy0.setY$D$I(0, this.imageView.toPixelY0$D(0));
var n=this.getSpectrumAt$I(0).getSubSpectra$().size$();
this.pin2Dy1.setY$D$I(n, this.imageView.toPixelY0$D(n));
}p$1.setWidgetX$jspecview_common_PlotWidget$D.apply(this, [this.pin1Dx0, this.getScale$().minX]);
p$1.setWidgetX$jspecview_common_PlotWidget$D.apply(this, [this.pin1Dx1, this.getScale$().maxX]);
p$1.setWidgetY$jspecview_common_PlotWidget$D.apply(this, [this.pin1Dy0, this.getScale$().minY]);
p$1.setWidgetY$jspecview_common_PlotWidget$D.apply(this, [this.pin1Dy1, this.getScale$().maxY]);
this.widgets=Clazz.array($I$(12), -1, [this.zoomBox1D, this.zoomBox2D, this.pin1Dx0, this.pin1Dx01, this.pin1Dx1, this.pin1Dy0, this.pin1Dy01, this.pin1Dy1, this.pin2Dx0, this.pin2Dx01, this.pin2Dx1, this.pin2Dy0, this.pin2Dy01, this.pin2Dy1, this.cur2Dx0, this.cur2Dx1, this.cur2Dy, this.cur1D2x1, this.cur1D2x2]);
}, p$1);

Clazz.newMeth(C$, 'setWidgetX$jspecview_common_PlotWidget$D',  function (pw, x) {
pw.setX$D$I(x, p$1.toPixelX0$D.apply(this, [x]));
}, p$1);

Clazz.newMeth(C$, 'setWidgetY$jspecview_common_PlotWidget$D',  function (pw, y) {
pw.setY$D$I(y, p$1.toPixelY0$D.apply(this, [y]));
}, p$1);

Clazz.newMeth(C$, 'resetPinsFromView',  function () {
if (this.pin1Dx0 == null ) return;
p$1.setWidgetX$jspecview_common_PlotWidget$D.apply(this, [this.pin1Dx0, this.getScale$().minXOnScale]);
p$1.setWidgetX$jspecview_common_PlotWidget$D.apply(this, [this.pin1Dx1, this.getScale$().maxXOnScale]);
p$1.setWidgetY$jspecview_common_PlotWidget$D.apply(this, [this.pin1Dy0, this.getScale$().minYOnScale]);
p$1.setWidgetY$jspecview_common_PlotWidget$D.apply(this, [this.pin1Dy1, this.getScale$().maxYOnScale]);
}, p$1);

Clazz.newMeth(C$, 'resetPinPositions',  function () {
p$1.resetX$jspecview_common_PlotWidget.apply(this, [this.pin1Dx0]);
p$1.resetY$jspecview_common_PlotWidget.apply(this, [this.pin1Dy0]);
p$1.resetY$jspecview_common_PlotWidget.apply(this, [this.pin1Dy1]);
if (this.imageView == null ) {
if (this.gs2dLinkedX != null ) p$1.resetX$jspecview_common_PlotWidget.apply(this, [this.cur1D2x1]);
if (this.gs2dLinkedY != null ) p$1.resetX$jspecview_common_PlotWidget.apply(this, [this.cur1D2x2]);
} else {
this.pin2Dy0.setY$D$I(this.pin2Dy0.getYVal$(), this.imageView.toPixelY0$D(this.pin2Dy0.getYVal$()));
this.pin2Dy1.setY$D$I(this.pin2Dy1.getYVal$(), this.imageView.toPixelY0$D(this.pin2Dy1.getYVal$()));
}}, p$1);

Clazz.newMeth(C$, 'resetX$jspecview_common_PlotWidget',  function (p) {
p$1.setWidgetX$jspecview_common_PlotWidget$D.apply(this, [p, p.getXVal$()]);
}, p$1);

Clazz.newMeth(C$, 'resetY$jspecview_common_PlotWidget',  function (p) {
p$1.setWidgetY$jspecview_common_PlotWidget$D.apply(this, [p, p.getYVal$()]);
}, p$1);

Clazz.newMeth(C$, 'setPinSliderPositions$Z',  function (doDraw1DObjects) {
this.pin1Dx0.yPixel0=this.pin1Dx1.yPixel0=this.pin1Dx01.yPixel0=this.yPixel0 - 5;
this.pin1Dx0.yPixel1=this.pin1Dx1.yPixel1=this.pin1Dx01.yPixel1=this.yPixel0;
this.cur1D2x1.yPixel1=this.cur1D2x2.yPixel1=this.yPixel0 - 5;
this.cur1D2x1.yPixel0=this.cur1D2x2.yPixel0=this.yPixel1 + 6;
if (this.imageView == null ) {
this.pin1Dy0.xPixel0=this.pin1Dy1.xPixel0=this.pin1Dy01.xPixel0=this.xPixel1 + 5;
this.pin1Dy0.xPixel1=this.pin1Dy1.xPixel1=this.pin1Dy01.xPixel1=this.xPixel1;
} else {
this.pin1Dy0.xPixel0=this.pin1Dy1.xPixel0=this.pin1Dy01.xPixel0=this.imageView.xPixel1 + 15;
this.pin1Dy0.xPixel1=this.pin1Dy1.xPixel1=this.pin1Dy01.xPixel1=this.imageView.xPixel1 + 10;
this.pin2Dx0.yPixel0=this.pin2Dx1.yPixel0=this.pin2Dx01.yPixel0=this.yPixel0 - 5;
this.pin2Dx0.yPixel1=this.pin2Dx1.yPixel1=this.pin2Dx01.yPixel1=this.yPixel0;
this.pin2Dy0.xPixel0=this.pin2Dy1.xPixel0=this.pin2Dy01.xPixel0=this.imageView.xPixel1 + 5;
this.pin2Dy0.xPixel1=this.pin2Dy1.xPixel1=this.pin2Dy01.xPixel1=this.imageView.xPixel1;
this.cur2Dx0.yPixel0=this.cur2Dx1.yPixel0=this.yPixel1 + 6;
this.cur2Dx0.yPixel1=this.cur2Dx1.yPixel1=this.yPixel0 - 5;
this.cur2Dx0.yPixel0=this.cur2Dx1.yPixel0=this.yPixel1 + 6;
this.cur2Dx1.yPixel1=this.cur2Dx1.yPixel1=this.yPixel0 - 5;
this.cur2Dy.xPixel0=(doDraw1DObjects ? ((this.xPixel1 + this.imageView.xPixel0)/2|0) : this.imageView.xPixel0 - 6);
this.cur2Dy.xPixel1=this.imageView.xPixel1 + 5;
}}, p$1);

Clazz.newMeth(C$, 'setDerivedPins$I',  function (subIndex) {
if (this.gs2dLinkedX != null ) this.cur1D2x1.setX$D$I(this.cur1D2x1.getXVal$(), this.toPixelX$D(this.cur1D2x1.getXVal$()));
if (this.gs2dLinkedY != null ) this.cur1D2x2.setX$D$I(this.cur1D2x2.getXVal$(), this.toPixelX$D(this.cur1D2x2.getXVal$()));
this.pin1Dx01.setX$D$I(0, ((this.pin1Dx0.xPixel0 + this.pin1Dx1.xPixel0)/2|0));
this.pin1Dy01.setY$D$I(0, ((this.pin1Dy0.yPixel0 + this.pin1Dy1.yPixel0)/2|0));
this.pin1Dx01.setEnabled$Z(Math.min(this.pin1Dx0.xPixel0, this.pin1Dx1.xPixel0) > this.xPixel0 || Math.max(this.pin1Dx0.xPixel0, this.pin1Dx1.xPixel0) < this.xPixel1 );
this.pin1Dy01.setEnabled$Z(Math.min(this.pin1Dy0.yPixel0, this.pin1Dy1.yPixel0) > Math.min(this.toPixelY$D(this.getScale$().minY), this.toPixelY$D(this.getScale$().maxY)) || Math.max(this.pin1Dy0.yPixel0, this.pin1Dy1.yPixel0) < Math.max(this.toPixelY$D(this.getScale$().minY), this.toPixelY$D(this.getScale$().maxY)) );
if (this.imageView == null ) return;
var x=this.pin1Dx0.getXVal$();
this.cur2Dx0.setX$D$I(x, this.imageView.toPixelX$D(x));
x=this.pin1Dx1.getXVal$();
this.cur2Dx1.setX$D$I(x, this.imageView.toPixelX$D(x));
x=this.imageView.toX$I(this.imageView.xPixel0);
this.pin2Dx0.setX$D$I(x, this.imageView.toPixelX0$D(x));
x=this.imageView.toX$I(this.imageView.xPixel1);
this.pin2Dx1.setX$D$I(x, this.imageView.toPixelX0$D(x));
this.pin2Dx01.setX$D$I(0, ((this.pin2Dx0.xPixel0 + this.pin2Dx1.xPixel0)/2|0));
var y=this.imageView.imageHeight - 1 - this.imageView.yView1 ;
this.pin2Dy0.setY$D$I(y, this.imageView.toPixelY0$D(y));
y=this.imageView.imageHeight - 1 - this.imageView.yView2 ;
this.pin2Dy1.setY$D$I(y, this.imageView.toPixelY0$D(y));
this.pin2Dy01.setY$D$I(0, ((this.pin2Dy0.yPixel0 + this.pin2Dy1.yPixel0)/2|0));
this.cur2Dy.yPixel0=this.cur2Dy.yPixel1=this.imageView.subIndexToPixelY$I(subIndex);
this.pin2Dx01.setEnabled$Z(Math.min(this.pin2Dx0.xPixel0, this.pin2Dx1.xPixel0) != this.imageView.xPixel0 || Math.max(this.pin2Dx0.xPixel0, this.pin2Dx1.xPixel1) != this.imageView.xPixel1 );
this.pin2Dy01.setEnabled$Z(Math.min(this.pin2Dy0.yPixel0, this.pin2Dy1.yPixel0) != this.yPixel0 || Math.max(this.pin2Dy0.yPixel0, this.pin2Dy1.yPixel1) != this.yPixel1 );
}, p$1);

Clazz.newMeth(C$, 'doZoom$D$D$D$D$Z$Z$Z$Z$Z',  function (initX, initY, finalX, finalY, is1D, is1DY, checkRange, checkLinked, addZoom) {
if (initX == finalX ) {
initX=this.getScale$().minXOnScale;
finalX=this.getScale$().maxXOnScale;
} else if (this.isLinked && checkLinked ) this.pd.doZoomLinked$jspecview_common_GraphSet$D$D$Z$Z$Z(this, initX, finalX, addZoom, checkRange, is1D);
if (initX > finalX ) {
var tempX=initX;
initX=finalX;
finalX=tempX;
}if (initY > finalY ) {
var tempY=initY;
initY=finalY;
finalY=tempY;
}var is2DGrayScaleChange=(!is1D && this.imageView != null   && (this.imageView.minZ != initY  || this.imageView.maxZ != finalY  ) );
if (!this.zoomEnabled && !is2DGrayScaleChange ) return;
if (checkRange) {
if (!this.getScale$().isInRangeX$D(initX) && !this.getScale$().isInRangeX$D(finalX) ) return;
if (!this.getScale$().isInRangeX$D(initX)) {
initX=this.getScale$().minX;
} else if (!this.getScale$().isInRangeX$D(finalX)) {
finalX=this.getScale$().maxX;
}} else {
}this.pd.setTaintedAll$();
var viewScales=this.viewData.getScaleData$();
var startIndices=Clazz.array(Integer.TYPE, [this.nSpectra]);
var endIndices=Clazz.array(Integer.TYPE, [this.nSpectra]);
this.graphsTemp.clear$();
var subspecs=this.getSpectrumAt$I(0).getSubSpectra$();
var dontUseSubspecs=(subspecs == null  || subspecs.size$() == 2 );
var is2D=!this.getSpectrumAt$I(0).is1D$();
if (!is2D && !dontUseSubspecs ) {
this.graphsTemp.addLast$O(this.getSpectrum$());
if (!$I$(9).setDataPointIndices$javajs_util_Lst$D$D$I$IA$IA(this.graphsTemp, initX, finalX, 3, startIndices, endIndices)) return;
} else {
if (!$I$(9).setDataPointIndices$javajs_util_Lst$D$D$I$IA$IA(this.spectra, initX, finalX, 3, startIndices, endIndices)) return;
}var y1=initY;
var y2=finalY;
var isXOnly=(y1 == y2 );
if (isXOnly) {
var f=(!is2DGrayScaleChange && is1D  ? f=this.getScale$().spectrumScaleFactor : 1);
if (Math.abs(f - 1) < 1.0E-4 ) {
y1=this.getScale$().minYOnScale;
y2=this.getScale$().maxYOnScale;
}}var yScales=null;
if (isXOnly || is1DY ) {
this.getCurrentView$();
yScales=this.viewData.getNewScales$I$Z$D$D(this.iSpectrumSelected, isXOnly, y1, y2);
}p$1.getView$D$D$D$D$IA$IA$jspecview_common_ScaleDataA$jspecview_common_ScaleDataA.apply(this, [initX, finalX, y1, y2, startIndices, endIndices, viewScales, yScales]);
this.setXPixelMovedTo$D$D$I$I(1.0E10, 1.7976931348623157E308, 0, 0);
p$1.setWidgetX$jspecview_common_PlotWidget$D.apply(this, [this.pin1Dx0, initX]);
p$1.setWidgetX$jspecview_common_PlotWidget$D.apply(this, [this.pin1Dx1, finalX]);
p$1.setWidgetY$jspecview_common_PlotWidget$D.apply(this, [this.pin1Dy0, y1]);
p$1.setWidgetY$jspecview_common_PlotWidget$D.apply(this, [this.pin1Dy1, y2]);
if (this.imageView == null ) {
p$1.updateDialogs.apply(this, []);
} else {
var isub=this.getSpectrumAt$I(0).getSubIndex$();
var ifix=this.imageView.fixSubIndex$I(isub);
if (ifix != isub) p$1.setCurrentSubSpectrum$I.apply(this, [ifix]);
if (is2DGrayScaleChange) p$1.update2dImage$Z.apply(this, [false]);
}if (addZoom) p$1.addCurrentZoom.apply(this, []);
});

Clazz.newMeth(C$, 'updateDialogs',  function () {
p$1.updateDialog$jspecview_common_Annotation_AType$I.apply(this, [$I$(5).PeakList, -1]);
p$1.updateDialog$jspecview_common_Annotation_AType$I.apply(this, [$I$(5).Measurements, -1]);
}, p$1);

Clazz.newMeth(C$, 'setCurrentSubSpectrum$I',  function (i) {
var spec0=this.getSpectrumAt$I(0);
i=spec0.setCurrentSubSpectrum$I(i);
if (spec0.isForcedSubset$()) this.viewData.setXRangeForSubSpectrum$jspecview_common_CoordinateA(this.getSpectrum$().getXYCoords$());
this.pd.notifySubSpectrumChange$I$jspecview_common_Spectrum(i, this.getSpectrum$());
}, p$1);

Clazz.newMeth(C$, 'addCurrentZoom',  function () {
if (this.viewList.size$() > this.currentZoomIndex + 1) for (var i=this.viewList.size$() - 1; i > this.currentZoomIndex; i--) this.viewList.removeItemAt$I(i);

this.viewList.addLast$O(this.viewData);
++this.currentZoomIndex;
}, p$1);

Clazz.newMeth(C$, 'setZoomTo$I',  function (i) {
this.currentZoomIndex=i;
this.viewData=this.viewList.get$I(i);
p$1.resetPinsFromView.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'clearViews$',  function () {
if (this.isLinked) {
this.pd.clearLinkViews$jspecview_common_GraphSet(this);
}this.setZoom$D$D$D$D(0, 0, 0, 0);
for (var i=this.viewList.size$(); --i >= 1; ) this.viewList.removeItemAt$I(i);

});

Clazz.newMeth(C$, 'drawAll$O$O$O$I$Z$Z$Z',  function (gMain, gFront, gBack, iSplit, needNewPins, doAll, pointsOnly) {
this.g2d=this.pd.g2d;
this.gMain=gMain;
var spec0=this.getSpectrumAt$I(0);
var subIndex=spec0.getSubIndex$();
this.is2DSpectrum=(!spec0.is1D$() && (this.isLinked || this.pd.getBoolean$jspecview_common_ScriptToken($I$(13).DISPLAY2D) ) && (this.imageView != null  || p$1.get2DImage$jspecview_common_Spectrum.apply(this, [spec0]) )  );
if (this.imageView != null  && doAll ) {
if (this.pd.isPrinting && this.g2d !== this.pd.g2d0  ) this.g2d.newGrayScaleImage$O$O$I$I$IA(gMain, this.image2D, this.imageView.imageWidth, this.imageView.imageHeight, this.imageView.getBuffer$());
if (this.is2DSpectrum) p$1.setPositionForFrame$I.apply(this, [iSplit]);
p$1.draw2DImage.apply(this, []);
}var iSelected=(this.stackSelected || !this.showAllStacked  ? this.iSpectrumSelected : -1);
var doYScale=(!this.showAllStacked || this.nSpectra == 1  || iSelected >= 0 );
var doDraw1DObjects=(this.imageView == null  || this.pd.display1D );
var n=(iSelected >= 0 ? 1 : 0);
var iSpectrumForScale=p$1.getFixedSelectedSpectrumIndex.apply(this, []);
if (doDraw1DObjects && doAll ) {
p$1.fillBox$O$I$I$I$I$jspecview_common_ScriptToken.apply(this, [gMain, this.xPixel0, this.yPixel0, this.xPixel1, this.yPixel1, $I$(13).PLOTAREACOLOR]);
if (iSelected < 0) {
doYScale=true;
for (var i=0; i < this.nSpectra; i++) if (p$1.doPlot$I$I.apply(this, [i, iSplit])) {
if (n++ == 0) continue;
doYScale=!!(doYScale&(this.viewData.areYScalesSame$I$I(i - 1, i)));
}
}}var iSpecForFrame=(this.nSpectra == 1 ? 0 : !this.showAllStacked ? this.iSpectrumMovedTo : this.iSpectrumSelected);
var g2=(gBack === gMain  ? gFront : gBack);
if (doAll) {
var addCurrentBox=(this.pd.getCurrentGraphSet$() === this  && !this.isLinked  && (!this.isSplittable || (this.nSplit == 1 || this.pd.currentSplitPoint == iSplit ) ) );
var drawUpDownArrows=(this.zoomEnabled && !p$1.isDrawNoSpectra.apply(this, []) && this.pd.isCurrentGraphSet$jspecview_common_GraphSet(this) && this.spectra.get$I(0).isScalable$() && (addCurrentBox || this.nSpectra == 1 ) && (this.nSplit == 1 || this.pd.currentSplitPoint == this.iSpectrumMovedTo )  );
var addSplitBox=this.isSplittable;
p$1.drawFrame$O$I$Z$Z$Z.apply(this, [gMain, iSpecForFrame, addCurrentBox, addSplitBox, drawUpDownArrows]);
}if (this.pd.isCurrentGraphSet$jspecview_common_GraphSet(this) && iSplit == this.pd.currentSplitPoint  && (n < 2 || this.iSpectrumSelected >= 0 ) ) this.haveSelectedSpectrum=true;
this.haveSingleYScale=(this.showAllStacked && this.nSpectra > 1  ? this.allowStackedYScale && doYScale  : true);
if (doDraw1DObjects) {
var yOffsetPixels=((this.yPixels * (this.yStackOffsetPercent / 100.0))|0);
this.haveLeftRightArrows=false;
for (var i=0, offset=0; i < this.nSpectra; i++) {
if (!p$1.doPlot$I$I.apply(this, [i, iSplit])) continue;
var isGrey=(this.stackSelected && this.iSpectrumSelected >= 0  && this.iSpectrumSelected != i );
var ig=(!this.reversePlot && this.getShowAnnotation$jspecview_common_Annotation_AType$I($I$(5).Integration, i) && (!this.showAllStacked || this.iSpectrumSelected == i )   ? this.getDialog$jspecview_common_Annotation_AType$I($I$(5).Integration, i).getData$() : null);
this.setScale$I(i);
var spec=this.spectra.get$I(i);
if (this.nSplit > 1) {
iSpectrumForScale=i;
}var doDrawWidgets=!isGrey && (this.nSplit == 1 || this.showAllStacked  || this.iSpectrumSelected == iSplit ) ;
var doDraw1DY=(doDrawWidgets && this.haveSelectedSpectrum && i == iSpectrumForScale  );
if (doDrawWidgets) {
this.widgetsAreSet=true;
p$1.resetPinsFromView.apply(this, []);
p$1.drawWidgets$O$O$I$Z$Z$Z$Z.apply(this, [gFront, g2, subIndex, needNewPins, doDraw1DObjects, doDraw1DY, false]);
}if (this.haveSingleYScale && i == iSpectrumForScale  && doAll ) {
p$1.drawGrid$O.apply(this, [gMain]);
if (this.pd.isPrinting && this.nSplit > 1 ) p$1.drawSpectrumSource$O$I.apply(this, [gMain, i]);
}if (doDrawWidgets) p$1.drawWidgets$O$O$I$Z$Z$Z$Z.apply(this, [gFront, g2, subIndex, false, doDraw1DObjects, doDraw1DY, true]);
if (!p$1.isDrawNoSpectra.apply(this, []) && (this.nSpectra == 1 || this.iSpectrumSelected >= 0 ) && (this.haveSingleYScale && i == iSpectrumForScale  || this.showAllStacked && this.stackSelected && i == this.iSpectrumSelected   )  ) p$1.drawHighlightsAndPeakTabs$O$O$I.apply(this, [gFront, g2, i]);
if (doAll) {
if (n == 1 && this.iSpectrumSelected < 0  || this.iSpectrumSelected == i && this.pd.isCurrentGraphSet$jspecview_common_GraphSet(this)  ) {
if (this.pd.titleOn && !this.pd.titleDrawn ) {
this.pd.drawTitle$O$I$I$S(gMain, this.height, this.width, this.pd.getDrawTitle$Z(this.pd.isPrinting));
this.pd.titleDrawn=true;
}}if (this.haveSingleYScale && i == iSpectrumForScale ) {
if (this.pd.getBoolean$jspecview_common_ScriptToken($I$(13).YSCALEON)) p$1.drawYScale$O$jspecview_common_XYScaleConverter.apply(this, [gMain, this]);
if (this.pd.getBoolean$jspecview_common_ScriptToken($I$(13).YUNITSON)) p$1.drawYUnits$O.apply(this, [gMain]);
}}var isContinuous=spec.isContinuous$();
var onSpectrum=((this.nSplit > 1 ? i == this.iSpectrumMovedTo : this.isLinked || i == iSpectrumForScale ) && !this.pd.isPrinting && isContinuous  );
var hasPendingIntegral=(!isGrey && this.pendingIntegral != null   && spec === this.pendingIntegral.spec  );
if (doAll || hasPendingIntegral ) {
p$1.drawPlot$O$I$jspecview_common_Spectrum$Z$I$Z$jspecview_common_IntegralData$Z$Z$Z.apply(this, [hasPendingIntegral && !doAll  ? gFront : gMain, i, spec, isContinuous, offset, isGrey, null, onSpectrum, hasPendingIntegral, pointsOnly]);
}p$1.drawIntegration$O$I$I$Z$jspecview_common_IntegralData$Z$Z.apply(this, [gFront, i, offset, isGrey, ig, isContinuous, onSpectrum]);
p$1.drawMeasurements$O$I.apply(this, [gFront, i]);
if (this.pendingMeasurement != null  && this.pendingMeasurement.spec === spec  ) p$1.drawMeasurement$O$jspecview_common_Measurement.apply(this, [gFront, this.pendingMeasurement]);
if (onSpectrum && this.xPixelMovedTo >= 0 ) {
p$1.drawSpectrumPointer$O$jspecview_common_Spectrum$I$jspecview_common_IntegralData.apply(this, [gFront, spec, offset, ig]);
}if (this.nSpectra > 1 && this.nSplit == 1  && this.pd.isCurrentGraphSet$jspecview_common_GraphSet(this)  && doAll ) {
this.haveLeftRightArrows=true;
if (!this.pd.isPrinting) {
this.setScale$I(0);
iSpecForFrame=(this.iSpectrumSelected);
if (this.nSpectra != 2) {
p$1.setPlotColor$O$I.apply(this, [gMain, (iSpecForFrame + this.nSpectra - 1) % this.nSpectra]);
p$1.fillArrow$O$I$I$I$Z.apply(this, [gMain, 1, this.yHArrows, this.xHArrows - 9, true]);
p$1.setCurrentBoxColor$O.apply(this, [gMain]);
p$1.fillArrow$O$I$I$I$Z.apply(this, [gMain, 1, this.yHArrows, this.xHArrows - 9, false]);
}if (iSpecForFrame >= 0) {
p$1.setPlotColor$O$I.apply(this, [gMain, iSpecForFrame]);
p$1.fillCircle$O$I$I$Z.apply(this, [gMain, this.xHArrows, this.yHArrows, true]);
}p$1.setCurrentBoxColor$O.apply(this, [gMain]);
p$1.fillCircle$O$I$I$Z.apply(this, [gMain, this.xHArrows, this.yHArrows, false]);
p$1.setPlotColor$O$I.apply(this, [gMain, (iSpecForFrame + 1) % this.nSpectra]);
p$1.fillArrow$O$I$I$I$Z.apply(this, [gMain, 2, this.yHArrows, this.xHArrows + 9, true]);
p$1.setCurrentBoxColor$O.apply(this, [gMain]);
p$1.fillArrow$O$I$I$I$Z.apply(this, [gMain, 2, this.yHArrows, this.xHArrows + 9, false]);
}}offset-=yOffsetPixels;
}
if (doAll) {
if (this.pd.getBoolean$jspecview_common_ScriptToken($I$(13).XSCALEON)) p$1.drawXScale$O$jspecview_common_XYScaleConverter.apply(this, [gMain, this]);
if (this.pd.getBoolean$jspecview_common_ScriptToken($I$(13).XUNITSON)) p$1.drawXUnits$O.apply(this, [gMain]);
}} else {
if (doAll) {
if (this.pd.getBoolean$jspecview_common_ScriptToken($I$(13).XSCALEON)) p$1.drawXScale$O$jspecview_common_XYScaleConverter.apply(this, [gMain, this.imageView]);
if (this.pd.getBoolean$jspecview_common_ScriptToken($I$(13).YSCALEON)) p$1.drawYScale$O$jspecview_common_XYScaleConverter.apply(this, [gMain, this.imageView]);
if (subIndex >= 0) p$1.draw2DUnits$O.apply(this, [gMain]);
}p$1.drawWidgets$O$O$I$Z$Z$Z$Z.apply(this, [gFront, g2, subIndex, needNewPins, doDraw1DObjects, true, false]);
p$1.drawWidgets$O$O$I$Z$Z$Z$Z.apply(this, [gFront, g2, subIndex, needNewPins, doDraw1DObjects, true, true]);
this.widgetsAreSet=true;
}if (this.annotations != null ) p$1.drawAnnotations$O$javajs_util_Lst$jspecview_common_ScriptToken.apply(this, [gFront, this.annotations, null]);
}, p$1);

Clazz.newMeth(C$, 'drawSpectrumSource$O$I',  function (g, i) {
this.pd.printFilePath$O$I$I$S(g, this.pd.thisWidth - this.pd.right, this.yPixel0, this.spectra.get$I(i).getFilePath$());
}, p$1);

Clazz.newMeth(C$, 'doPlot$I$I',  function (i, iSplit) {
var isGrey=(this.stackSelected && this.iSpectrumSelected >= 0  && this.iSpectrumSelected != i );
var ok=(this.showAllStacked || this.iSpectrumSelected == -1  || this.iSpectrumSelected == i );
return (this.nSplit > 1 ? i == iSplit : ok && (!this.pd.isPrinting || !isGrey ) );
}, p$1);

Clazz.newMeth(C$, 'drawSpectrumPointer$O$jspecview_common_Spectrum$I$jspecview_common_IntegralData',  function (gFront, spec, yOffset, ig) {
p$1.setColorFromToken$O$jspecview_common_ScriptToken.apply(this, [gFront, $I$(13).PEAKTABCOLOR]);
var iHandle=this.pd.integralShiftMode;
if (ig != null ) {
if ((!this.pd.ctrlPressed || this.pd.isIntegralDrag ) && !p$1.isOnSpectrum$I$I$I.apply(this, [this.pd.mouseX, this.pd.mouseY, -1]) ) {
ig=null;
} else if (iHandle == 0) {
iHandle=p$1.getShiftMode$I$I.apply(this, [this.pd.mouseX, this.pd.mouseY]);
if (iHandle == 0) iHandle=2147483647;
}}var y0=this.yValueMovedTo;
this.yValueMovedTo=(ig == null  ? spec.getYValueAt$D(this.xValueMovedTo) : ig.getPercentYValueAt$D(this.xValueMovedTo));
p$1.setCoordStr$D$D.apply(this, [this.xValueMovedTo, this.yValueMovedTo]);
if (iHandle != 0) {
p$1.setPlotColor$O$I.apply(this, [gFront, iHandle == 2147483647 ? -1 : 0]);
if (iHandle < 0 || iHandle == 2147483647 ) {
p$1.drawHandle$O$I$I$I$Z.apply(this, [gFront, this.xPixelPlot1, this.yPixelPlot0, 3, false]);
}if (iHandle > 0) {
p$1.drawHandle$O$I$I$I$Z.apply(this, [gFront, this.xPixelPlot0, this.yPixelPlot1, 3, false]);
}if (iHandle != 2147483647) return;
}if (ig != null ) this.g2d.setStrokeBold$O$Z(gFront, true);
if (Double.isNaN$D(y0) || this.pendingMeasurement != null  ) {
this.g2d.drawLine$O$I$I$I$I(gFront, this.xPixelMovedTo, this.yPixel0, this.xPixelMovedTo, this.yPixel1);
if (this.xPixelMovedTo2 >= 0) this.g2d.drawLine$O$I$I$I$I(gFront, this.xPixelMovedTo2, this.yPixel0, this.xPixelMovedTo2, this.yPixel1);
this.yValueMovedTo=NaN;
} else {
var y=(ig == null  ? yOffset + this.toPixelY$D(this.yValueMovedTo) : p$1.toPixelYint$D.apply(this, [this.yValueMovedTo / 100]));
if (y == this.fixY$I(y)) this.g2d.drawLine$O$I$I$I$I(gFront, this.xPixelMovedTo, y - 10, this.xPixelMovedTo, y + 10);
}if (ig != null ) this.g2d.setStrokeBold$O$Z(gFront, false);
}, p$1);

Clazz.newMeth(C$, 'setScale$I',  function (i) {
this.viewData.setScale$I$I$I$Z(i, this.xPixels, this.yPixels, this.spectra.get$I(i).isInverted$());
});

Clazz.newMeth(C$, 'draw2DUnits$O',  function (g) {
var nucleusX=this.getSpectrumAt$I(0).nucleusX;
var nucleusY=this.getSpectrumAt$I(0).nucleusY;
p$1.setColorFromToken$O$jspecview_common_ScriptToken.apply(this, [g, $I$(13).PLOTCOLOR]);
p$1.drawUnits$O$S$I$I$D$D.apply(this, [g, nucleusX, this.imageView.xPixel1 + 5 * this.pd.scalingFactor, this.yPixel1, 1, 1.0]);
p$1.drawUnits$O$S$I$I$D$D.apply(this, [g, nucleusY, this.imageView.xPixel0 - 5 * this.pd.scalingFactor, this.yPixel0, 1, 0]);
}, p$1);

Clazz.newMeth(C$, 'drawPeakTabs$O$O$jspecview_common_Spectrum',  function (gFront, g2, spec) {
var list=(this.nSpectra == 1 || this.iSpectrumSelected >= 0  ? spec.getPeakList$() : null);
if (list != null  && list.size$() > 0 ) {
if (this.piMouseOver != null  && this.piMouseOver.spectrum === spec   && this.pd.isMouseUp$() ) {
this.g2d.setGraphicsColor$O$javajs_api_GenericColor(g2, this.g2d.getColor4$I$I$I$I(240, 240, 240, 140));
p$1.drawPeak$O$jspecview_common_PeakInfo$I.apply(this, [g2, this.piMouseOver, 0]);
spec.setHighlightedPeak$jspecview_common_PeakInfo(this.piMouseOver);
} else {
spec.setHighlightedPeak$jspecview_common_PeakInfo(null);
}p$1.setColorFromToken$O$jspecview_common_ScriptToken.apply(this, [gFront, $I$(13).PEAKTABCOLOR]);
for (var i=list.size$(); --i >= 0; ) {
var p=list.get$I(i);
p$1.drawPeak$O$jspecview_common_PeakInfo$I.apply(this, [gFront, p, p === spec.getSelectedPeak$()  ? 14 : 7]);
}
}}, p$1);

Clazz.newMeth(C$, 'drawPeak$O$jspecview_common_PeakInfo$I',  function (g, pi, tickSize) {
if (this.pd.isPrinting) return;
var xMin=pi.getXMin$();
var xMax=pi.getXMax$();
if (xMin == xMax ) return;
p$1.drawBar$O$jspecview_common_PeakInfo$D$D$jspecview_common_ScriptToken$I.apply(this, [g, pi, xMin, xMax, null, tickSize]);
}, p$1);

Clazz.newMeth(C$, 'drawWidgets$O$O$I$Z$Z$Z$Z',  function (gFront, gBack, subIndex, needNewPins, doDraw1DObjects, doDraw1DY, postGrid) {
p$1.setWidgets$Z$I$Z.apply(this, [needNewPins, subIndex, doDraw1DObjects]);
if (this.pd.isPrinting && (this.imageView == null  ? !this.cur1D2Locked : this.sticky2Dcursor) ) return;
if (!this.pd.isPrinting && !postGrid ) {
if (doDraw1DObjects) {
p$1.fillBox$O$I$I$I$I$jspecview_common_ScriptToken.apply(this, [gFront, this.xPixel0, this.pin1Dx0.yPixel1, this.xPixel1, this.pin1Dx1.yPixel1 + 2, $I$(13).GRIDCOLOR]);
p$1.fillBox$O$I$I$I$I$jspecview_common_ScriptToken.apply(this, [gFront, this.pin1Dx0.xPixel0, this.pin1Dx0.yPixel1, this.pin1Dx1.xPixel0, this.pin1Dx1.yPixel1 + 2, $I$(13).PLOTCOLOR]);
} else {
p$1.fillBox$O$I$I$I$I$jspecview_common_ScriptToken.apply(this, [gFront, this.imageView.xPixel0, this.pin2Dx0.yPixel1, this.imageView.xPixel1, this.pin2Dx0.yPixel1 + 2, $I$(13).GRIDCOLOR]);
p$1.fillBox$O$I$I$I$I$jspecview_common_ScriptToken.apply(this, [gFront, this.pin2Dx0.xPixel0, this.pin2Dx0.yPixel1, this.pin2Dx1.xPixel0, this.pin2Dx1.yPixel1 + 2, $I$(13).PLOTCOLOR]);
p$1.fillBox$O$I$I$I$I$jspecview_common_ScriptToken.apply(this, [gFront, this.pin2Dy0.xPixel1, this.yPixel1, this.pin2Dy1.xPixel1 + 2, this.yPixel0, $I$(13).GRIDCOLOR]);
p$1.fillBox$O$I$I$I$I$jspecview_common_ScriptToken.apply(this, [gFront, this.pin2Dy0.xPixel1, this.pin2Dy0.yPixel1, this.pin2Dy1.xPixel1 + 2, this.pin2Dy1.yPixel0, $I$(13).PLOTCOLOR]);
}p$1.fillBox$O$I$I$I$I$jspecview_common_ScriptToken.apply(this, [gFront, this.pin1Dy0.xPixel1, this.yPixel1, this.pin1Dy1.xPixel1 + 2, this.yPixel0, $I$(13).GRIDCOLOR]);
if (doDraw1DY) p$1.fillBox$O$I$I$I$I$jspecview_common_ScriptToken.apply(this, [gFront, this.pin1Dy0.xPixel1, this.pin1Dy0.yPixel1, this.pin1Dy1.xPixel1 + 2, this.pin1Dy1.yPixel0, $I$(13).PLOTCOLOR]);
}for (var i=0; i < this.widgets.length; i++) {
var pw=this.widgets[i];
if (pw == null  || !pw.isPinOrCursor && !this.zoomEnabled  ) continue;
var isLockedCursor=(pw === this.cur1D2x1  || pw === this.cur1D2x2   || pw === this.cur2Dx0   || pw === this.cur2Dx1   || pw === this.cur2Dy  );
if ((pw.isPin || !pw.isPinOrCursor ) == postGrid ) continue;
if (pw.is2D) {
if (pw === this.cur2Dx0  && !doDraw1DObjects ) continue;
} else {
var isPin1Dy=(pw === this.pin1Dy0  || pw === this.pin1Dy1   || pw === this.pin1Dy01  );
if ((this.imageView != null  && doDraw1DObjects == isPin1Dy  ) || isPin1Dy && !doDraw1DY   || pw === this.cur1D2x1  && this.gs2dLinkedX == null    || pw === this.cur1D2x2  && this.gs2dLinkedY == null    || pw === this.zoomBox1D  && (this.pd.isIntegralDrag || this.pd.integralShiftMode != 0 )  ) {
if (!this.isLinked || this.imageView != null  ) continue;
}}if (this.pd.isPrinting && !isLockedCursor ) continue;
if (pw.isPinOrCursor) {
p$1.setColorFromToken$O$jspecview_common_ScriptToken.apply(this, [gFront, pw.color]);
this.g2d.drawLine$O$I$I$I$I(gFront, pw.xPixel0, pw.yPixel0, pw.xPixel1, pw.yPixel1);
pw.isVisible=true;
if (pw.isPin) p$1.drawHandle$O$I$I$I$Z.apply(this, [gFront, pw.xPixel0, pw.yPixel0, 2, !pw.isEnabled]);
} else if (pw.xPixel1 != pw.xPixel0) {
p$1.fillBox$O$I$I$I$I$jspecview_common_ScriptToken.apply(this, [gBack, pw.xPixel0, pw.yPixel0, pw.xPixel1, pw.yPixel1, pw === this.zoomBox1D  && this.pd.shiftPressed  ? $I$(13).ZOOMBOXCOLOR2 : $I$(13).ZOOMBOXCOLOR]);
}}
}, p$1);

Clazz.newMeth(C$, 'drawBar$O$jspecview_common_PeakInfo$D$D$jspecview_common_ScriptToken$I',  function (g, pi, xMin, xMax, whatColor, tickSize) {
var x1=this.toPixelX$D(xMin);
var x2=this.toPixelX$D(xMax);
if (x1 > x2) {
var tmp=x1;
x1=x2;
x2=tmp;
}x1=this.fixX$I(x1);
x2=this.fixX$I(x2);
if (x2 - x1 < 3) {
x1-=2;
x2+=2;
}if (pi != null ) pi.setPixelRange$I$I(x1, x2);
if (tickSize == 0) {
p$1.fillBox$O$I$I$I$I$jspecview_common_ScriptToken.apply(this, [g, x1, this.yPixel0, x2, this.yPixel0 + this.yPixels, whatColor]);
} else {
p$1.fillBox$O$I$I$I$I$jspecview_common_ScriptToken.apply(this, [g, x1, this.yPixel0 + 2, x2, this.yPixel0 + 5, whatColor]);
if (pi != null ) {
x1=((x1 + x2)/2|0);
p$1.fillBox$O$I$I$I$I$jspecview_common_ScriptToken.apply(this, [g, x1 - 1, this.yPixel0 + 2, x1 + 1, this.yPixel0 + 2 + tickSize , whatColor]);
}}}, p$1);

Clazz.newMeth(C$, 'drawIntegration$O$I$I$Z$jspecview_common_IntegralData$Z$Z',  function (gFront, index, yOffset, isGrey, iData, isContinuous, isSelected) {
if (iData != null ) {
if (this.haveIntegralDisplayed$I(index)) p$1.drawPlot$O$I$jspecview_common_Spectrum$Z$I$Z$jspecview_common_IntegralData$Z$Z$Z.apply(this, [gFront, index, this.spectra.get$I(index), true, yOffset, false, iData, true, false, false]);
p$1.drawIntegralValues$O$I$I.apply(this, [gFront, index, yOffset]);
}var ratios=this.getIntegrationRatios$I(index);
if (ratios != null ) p$1.drawAnnotations$O$javajs_util_Lst$jspecview_common_ScriptToken.apply(this, [gFront, ratios, $I$(13).INTEGRALPLOTCOLOR]);
}, p$1);

Clazz.newMeth(C$, 'getMeasurements$jspecview_common_Annotation_AType$I',  function (type, iSpec) {
var ad=this.getDialog$jspecview_common_Annotation_AType$I(type, iSpec);
return (ad == null  || ad.getData$().size$() == 0  || !ad.getState$()  ? null : ad.getData$());
}, p$1);

Clazz.newMeth(C$, 'drawPlot$O$I$jspecview_common_Spectrum$Z$I$Z$jspecview_common_IntegralData$Z$Z$Z',  function (g, index, spec, isContinuous, yOffset, isGrey, ig, isSelected, hasPendingIntegral, pointsOnly) {
var xyCoords=(ig == null  ? spec.getXYCoords$() : this.getIntegrationGraph$I(index).getXYCoords$());
var isIntegral=(ig != null );
var bsDraw=(isIntegral ? ig.getBitSet$() : null);
var fillPeaks=(hasPendingIntegral || spec.fillColor != null  && isSelected  );
var iColor=(isGrey ? -2 : isIntegral ? -1 : !this.allowStacking ? 0 : index);
p$1.setPlotColor$O$I.apply(this, [g, iColor]);
var plotOn=true;
var y0=this.toPixelY$D(0);
if (isIntegral) fillPeaks=!!(fillPeaks&((y0 == this.fixY$I(y0))));
 else y0=this.fixY$I(y0);
var cInt=(isIntegral || fillPeaks  ? this.pd.getColor$jspecview_common_ScriptToken($I$(13).INTEGRALPLOTCOLOR) : null);
var cFill=(cInt == null  || spec.fillColor == null   ? cInt : spec.fillColor);
var iFirst=this.viewData.getStartingPointIndex$I(index);
var iLast=this.viewData.getEndingPointIndex$I(index);
if (isContinuous && !pointsOnly ) {
--iLast;
var doLineTo=(isIntegral || this.pendingIntegral != null  ) && this.g2d.canDoLineTo$() ;
if (doLineTo) this.g2d.doStroke$O$Z(g, true);
var isDown=false;
for (var i=iFirst; i <= iLast; i++) {
var point1=xyCoords[i];
var point2=xyCoords[i + 1];
var y1=(isIntegral ? p$1.toPixelYint$D.apply(this, [point1.getYVal$()]) : this.toPixelY$D(point1.getYVal$()));
if (y1 == -2147483648) continue;
var y2=(isIntegral ? p$1.toPixelYint$D.apply(this, [point2.getYVal$()]) : this.toPixelY$D(point2.getYVal$()));
if (y2 == -2147483648) continue;
var xv1=point1.getXVal$();
var xv2=point2.getXVal$();
var x1=this.toPixelX$D(xv1);
var x2=this.toPixelX$D(xv2);
y1=this.fixY$I(yOffset + y1);
y2=this.fixY$I(yOffset + y2);
if (isIntegral) {
if (i == iFirst) {
this.xPixelPlot1=x1;
this.yPixelPlot0=y1;
}this.xPixelPlot0=x2;
this.yPixelPlot1=y2;
}if (x2 == x1 && y1 == y2 ) continue;
if (fillPeaks && hasPendingIntegral && this.pendingIntegral.overlaps$D$D(xv1, xv2)  ) {
if (cFill != null ) {
this.g2d.doStroke$O$Z(g, false);
this.g2d.setGraphicsColor$O$javajs_api_GenericColor(g, cFill);
}this.g2d.fillRect$O$I$I$I$I(g, Math.min(x1, x2), Math.min(y0, y1), Math.max(1, Math.abs(x2 - x1)), Math.abs(y0 - y1));
if (cFill != null ) {
this.g2d.doStroke$O$Z(g, false);
this.g2d.doStroke$O$Z(g, true);
isDown=false;
p$1.setPlotColor$O$I.apply(this, [g, iColor]);
}continue;
}if (y1 == y2 && (y1 == this.yPixel0) ) {
continue;
}if (bsDraw != null  && bsDraw.get$I(i) != plotOn  ) {
plotOn=bsDraw.get$I(i);
if (doLineTo && isDown ) {
this.g2d.doStroke$O$Z(g, false);
this.g2d.doStroke$O$Z(g, true);
isDown=false;
}if (!this.pd.isPrinting && this.pd.integralShiftMode != 0 ) p$1.setPlotColor$O$I.apply(this, [g, 0]);
 else if (plotOn) p$1.setColorFromToken$O$jspecview_common_ScriptToken.apply(this, [g, $I$(13).INTEGRALPLOTCOLOR]);
 else p$1.setPlotColor$O$I.apply(this, [g, -3]);
}if (this.pd.isPrinting && !plotOn ) continue;
if (isDown) {
this.g2d.lineTo$O$I$I(g, x2, y2);
} else {
this.g2d.drawLine$O$I$I$I$I(g, x1, y1, x2, y2);
isDown=doLineTo;
}}
if (doLineTo) this.g2d.doStroke$O$Z(g, false);
} else {
for (var i=iFirst; i <= iLast; i++) {
var point=xyCoords[i];
var y2=this.toPixelY$D(point.getYVal$());
if (y2 == -2147483648) continue;
var x1=this.toPixelX$D(point.getXVal$());
var y1=this.toPixelY$D(Math.max(this.getScale$().minYOnScale, 0));
y1=this.fixY$I(yOffset + y1);
y2=this.fixY$I(yOffset + y2);
if (y1 == y2 && (y1 == this.yPixel0 || y1 == this.yPixel1 ) ) continue;
if (pointsOnly) this.g2d.fillRect$O$I$I$I$I(g, x1 - 1, y2 - 1, 3, 3);
 else this.g2d.drawLine$O$I$I$I$I(g, x1, y1, x1, y2);
}
if (!pointsOnly && this.getScale$().isYZeroOnScale$() ) {
var y=yOffset + this.toPixelY$D(this.getScale$().spectrumYRef);
if (y == this.fixY$I(y)) this.g2d.drawLine$O$I$I$I$I(g, this.xPixel1, y, this.xPixel0, y);
}}}, p$1);

Clazz.newMeth(C$, 'drawFrame$O$I$Z$Z$Z',  function (g, iSpec, addCurrentBox, addSplitBox, drawUpDownArrows) {
if (!this.pd.gridOn || this.pd.isPrinting ) {
p$1.setColorFromToken$O$jspecview_common_ScriptToken.apply(this, [g, $I$(13).GRIDCOLOR]);
this.g2d.drawRect$O$I$I$I$I(g, this.xPixel0, this.yPixel0, this.xPixels, this.yPixels);
if (this.pd.isPrinting) return;
}p$1.setCurrentBoxColor$O.apply(this, [g]);
if (drawUpDownArrows) {
if (iSpec >= 0) {
p$1.setPlotColor$O$I.apply(this, [g, iSpec]);
p$1.fillArrow$O$I$I$I$Z.apply(this, [g, 3, this.xVArrows, ((this.yPixel00 + this.yPixel11)/2|0) - 9, true]);
p$1.fillArrow$O$I$I$I$Z.apply(this, [g, 4, this.xVArrows, ((this.yPixel00 + this.yPixel11)/2|0) + 9, true]);
p$1.setCurrentBoxColor$O.apply(this, [g]);
}p$1.fillArrow$O$I$I$I$Z.apply(this, [g, 3, this.xVArrows, ((this.yPixel00 + this.yPixel11)/2|0) - 9, false]);
p$1.fillCircle$O$I$I$Z.apply(this, [g, this.xVArrows, ((this.yPixel00 + this.yPixel11)/2|0), false]);
p$1.fillArrow$O$I$I$I$Z.apply(this, [g, 4, this.xVArrows, ((this.yPixel00 + this.yPixel11)/2|0) + 9, false]);
}if (this.imageView != null ) return;
if (addCurrentBox) {
var x1=this.xPixel00 + 10;
var x2=this.xPixel11 - 10;
var y1=this.yPixel00 + 1;
var y2=this.yPixel11 - 2;
this.g2d.drawLine$O$I$I$I$I(g, x1, y1, x2, y1);
this.g2d.drawLine$O$I$I$I$I(g, x2, y1, x2, y2);
this.g2d.drawLine$O$I$I$I$I(g, x1, y2, x2, y2);
this.splitterX=this.closerX=-2147483648;
p$1.drawBox$O$I$I$I$I$jspecview_common_ScriptToken.apply(this, [g, x2 - 10, y1, x2, y1 + 10, null]);
this.g2d.drawLine$O$I$I$I$I(g, x2 - 10, y1 + 10, x2, y1);
this.g2d.drawLine$O$I$I$I$I(g, x2, y1 + 10, x2 - 10, y1);
this.closerX=x2 - 10;
this.closerY=y1;
if (addSplitBox) {
x2-=10;
p$1.fillBox$O$I$I$I$I$jspecview_common_ScriptToken.apply(this, [g, x2 - 10, y1, x2, y1 + 10, null]);
this.splitterX=x2 - 10;
this.splitterY=y1;
}}}, p$1);

Clazz.newMeth(C$, 'drawGrid$O',  function (g) {
if (!this.pd.gridOn || this.imageView != null  ) return;
p$1.setColorFromToken$O$jspecview_common_ScriptToken.apply(this, [g, $I$(13).GRIDCOLOR]);
var lastX;
if (Double.isNaN$D(this.getScale$().firstX)) {
lastX=this.getScale$().maxXOnScale + this.getScale$().steps[0] / 2;
for (var val=this.getScale$().minXOnScale; val < lastX ; val+=this.getScale$().steps[0]) {
var x=this.toPixelX$D(val);
this.g2d.drawLine$O$I$I$I$I(g, x, this.yPixel0, x, this.yPixel1);
}
} else {
lastX=this.getScale$().maxXOnScale * 1.0001;
for (var val=this.getScale$().firstX; val <= lastX ; val+=this.getScale$().steps[0]) {
var x=this.toPixelX$D(val);
this.g2d.drawLine$O$I$I$I$I(g, x, this.yPixel0, x, this.yPixel1);
}
}for (var val=this.getScale$().firstY; val < this.getScale$().maxYOnScale + this.getScale$().steps[1] / 2 ; val+=this.getScale$().steps[1]) {
var y=this.toPixelY$D(val);
if (y == this.fixY$I(y)) this.g2d.drawLine$O$I$I$I$I(g, this.xPixel0, y, this.xPixel1, y);
}
}, p$1);

Clazz.newMeth(C$, 'drawXScale$O$jspecview_common_XYScaleConverter',  function (g, c) {
p$1.setColorFromToken$O$jspecview_common_ScriptToken.apply(this, [g, $I$(13).SCALECOLOR]);
if (this.pd.isPrinting) this.g2d.drawLine$O$I$I$I$I(g, c.getXPixel0$(), this.yPixel1, c.getXPixel0$() + c.getXPixels$() - 1, this.yPixel1);
var precision=this.getScale$().precision[0];
var font=this.pd.setFont$O$I$I$F$Z(g, c.getXPixels$(), 0, this.pd.isPrinting ? 10 : 12, false);
var y1=this.yPixel1;
var y2=this.yPixel1 + 4 * this.pd.scalingFactor;
var y3=this.yPixel1 + 2 * this.pd.scalingFactor;
var h=font.getHeight$();
var dx=c.toPixelX$D(this.getScale$().steps[0]) - c.toPixelX$D(0);
var maxWidth=Math.abs(dx * 0.95);
var firstX=this.getScale$().firstX - this.getScale$().steps[0];
var lastX=(this.getScale$().maxXOnScale + this.getScale$().steps[0]) * 1.0001;
for (var pass=0; pass < 2; pass++) {
if (pass == 1) $I$(9).fixScale$java_util_Map(this.mapX);
var prevX=1.0E10;
for (var val=firstX; val <= lastX ; val+=this.getScale$().steps[0]) {
var x=c.toPixelX$D(val);
var d=Double.valueOf$D(val);
var s;
switch (pass) {
case 0:
s=$I$(14).formatDecimalDbl$D$I(val, precision);
this.mapX.put$O$O(d, s);
p$1.drawTick$O$I$I$I$jspecview_common_XYScaleConverter.apply(this, [g, x, y1, y2, c]);
dx=Math.abs(prevX - val);
var ntick=this.getScale$().minorTickCounts[0];
if (ntick != 0) {
var step=dx / ntick;
for (var i=1; i < ntick; i++) {
var x1=val - i * step;
p$1.drawTick$O$I$I$I$jspecview_common_XYScaleConverter.apply(this, [g, c.toPixelX$D(x1), y1, y3, c]);
}
}prevX=val;
continue;
case 1:
s=this.mapX.get$O(d);
if (s == null  || x != c.fixX$I(x) ) continue;
var w=this.pd.getStringWidth$S(s);
var n=(x + (w/2|0) == c.fixX$I(x + (w/2|0)) ? 2 : 0);
if (n > 0) this.g2d.drawString$O$S$I$I(g, s, x - (w/n|0), y2 + h);
val+=Math.floor(w / maxWidth) * this.getScale$().steps[0];
break;
}
}
}
this.mapX.clear$();
}, p$1);

Clazz.newMeth(C$, 'drawTick$O$I$I$I$jspecview_common_XYScaleConverter',  function (g, x, y1, y2, c) {
if (x == c.fixX$I(x)) this.g2d.drawLine$O$I$I$I$I(g, x, y1, x, y2);
}, p$1);

Clazz.newMeth(C$, 'drawYScale$O$jspecview_common_XYScaleConverter',  function (g, c) {
var sd=c.getScale$();
var precision=sd.precision[1];
var font=this.pd.setFont$O$I$I$F$Z(g, c.getXPixels$(), 0, this.pd.isPrinting ? 10 : 12, false);
var h=font.getHeight$();
var max=sd.maxYOnScale + sd.steps[1] / 2;
var yLast=-2147483648;
p$1.setColorFromToken$O$jspecview_common_ScriptToken.apply(this, [g, $I$(13).SCALECOLOR]);
for (var pass=0; pass < 2; pass++) {
if (pass == 1) $I$(9).fixScale$java_util_Map(this.mapX);
for (var val=sd.firstY; val < max ; val+=sd.steps[1]) {
var d=Double.valueOf$D(val);
var x1=c.getXPixel0$();
var y=c.toPixelY$D(val);
if (y != c.fixY$I(y)) continue;
var s;
if (pass == 0) this.g2d.drawLine$O$I$I$I$I(g, x1, y, x1 - 3 * this.pd.scalingFactor, y);
if (Math.abs(y - yLast) <= h) continue;
yLast=y;
switch (pass) {
case 0:
s=$I$(14).formatDecimalDbl$D$I(val, precision);
this.mapX.put$O$O(d, s);
break;
case 1:
s=this.mapX.get$O(d);
if (s == null ) continue;
if (s.startsWith$S("0") && s.contains$CharSequence("E") ) s="0";
this.g2d.drawString$O$S$I$I(g, s, (x1 - 4 * this.pd.scalingFactor - this.pd.getStringWidth$S(s)), y + (h/3|0));
break;
}
}
}
this.mapX.clear$();
}, p$1);

Clazz.newMeth(C$, 'drawXUnits$O',  function (g) {
var units=this.spectra.get$I(0).getAxisLabel$Z(true);
if (units != null ) p$1.drawUnits$O$S$I$I$D$D.apply(this, [g, units, this.xPixel1 + 25 * this.pd.scalingFactor, this.yPixel1 + 5 * this.pd.scalingFactor, 1, 1]);
}, p$1);

Clazz.newMeth(C$, 'drawUnits$O$S$I$I$D$D',  function (g, s, x, y, hOff, vOff) {
p$1.setColorFromToken$O$jspecview_common_ScriptToken.apply(this, [g, $I$(13).UNITSCOLOR]);
this.pd.setFont$O$I$I$F$Z(g, (this.imageView == null  ? this : this.imageView).getXPixels$(), 3, 10, false);
this.g2d.drawString$O$S$I$I(g, s, ((x - this.pd.getStringWidth$S(s) * hOff)|0), ((y + this.pd.getFontHeight$() * vOff)|0));
}, p$1);

Clazz.newMeth(C$, 'drawYUnits$O',  function (g) {
var units=this.spectra.get$I(0).getAxisLabel$Z(false);
if (units != null ) p$1.drawUnits$O$S$I$I$D$D.apply(this, [g, units, (this.pd.isPrinting ? 30 : 5) * this.pd.scalingFactor, this.yPixel0 + (this.pd.isPrinting ? 0 : 5) * this.pd.scalingFactor, 0, -1]);
}, p$1);

Clazz.newMeth(C$, 'drawHighlightsAndPeakTabs$O$O$I',  function (gFront, gBack, iSpec) {
var md=p$1.getMeasurements$jspecview_common_Annotation_AType$I.apply(this, [$I$(5).PeakList, iSpec]);
var spec=this.spectra.get$I(iSpec);
if (this.pd.isPrinting) {
if (md != null ) {
p$1.setColorFromToken$O$jspecview_common_ScriptToken.apply(this, [gFront, $I$(13).PEAKTABCOLOR]);
p$1.printPeakList$O$jspecview_common_Spectrum$jspecview_common_PeakData.apply(this, [gFront, spec, md]);
}return;
}if (md == null ) {
for (var i=0; i < this.highlights.size$(); i++) {
var hl=this.highlights.get$I(i);
if (hl.spectrum === spec ) {
this.pd.setHighlightColor$javajs_api_GenericColor(hl.color);
p$1.drawBar$O$jspecview_common_PeakInfo$D$D$jspecview_common_ScriptToken$I.apply(this, [gBack, null, hl.x1, hl.x2, $I$(13).HIGHLIGHTCOLOR, 0]);
}}
if (this.pd.peakTabsOn) p$1.drawPeakTabs$O$O$jspecview_common_Spectrum.apply(this, [gFront, gBack, spec]);
}var y;
if (md != null ) {
y=(spec.isInverted$() ? this.yPixel1 - 10 * this.pd.scalingFactor : this.yPixel0);
p$1.setColorFromToken$O$jspecview_common_ScriptToken.apply(this, [gFront, $I$(13).PEAKTABCOLOR]);
for (var i=md.size$(); --i >= 0; ) {
var m=md.get$I(i);
var x=this.toPixelX$D(m.getXVal$());
this.g2d.drawLine$O$I$I$I$I(gFront, x, y, x, y + 10 * this.pd.scalingFactor);
}
if (p$1.isVisible$jspecview_api_AnnotationData.apply(this, [this.getDialog$jspecview_common_Annotation_AType$I($I$(5).PeakList, iSpec)])) {
y=this.toPixelY$D((md).getThresh$());
if (y == this.fixY$I(y) && !this.pd.isPrinting ) this.g2d.drawLine$O$I$I$I$I(gFront, this.xPixel0, y, this.xPixel1, y);
}}}, p$1);

Clazz.newMeth(C$, 'printPeakList$O$jspecview_common_Spectrum$jspecview_common_PeakData',  function (g, spec, data) {
var sdata=data.getMeasurementListArray$S(null);
if (sdata.length == 0) return;
this.pd.setFont$O$I$I$F$Z(g, this.xPixels, 0, 8, false);
var h=this.pd.getFontHeight$();
var xs=Clazz.array(Integer.TYPE, [data.size$()]);
var xs0=Clazz.array(Integer.TYPE, [data.size$()]);
var dx=0;
var s5=5 * this.pd.scalingFactor;
var s10=10 * this.pd.scalingFactor;
var s15=15 * this.pd.scalingFactor;
var s25=25 * this.pd.scalingFactor;
for (var i=0; i < sdata.length; i++) {
xs0[i]=this.toPixelX$D(Double.parseDouble$S(sdata[i][1]));
if (i == 0) {
xs[i]=xs0[i];
continue;
}xs[i]=Math.max(xs[i - 1] + h, xs0[i] + h);
dx+=(xs[i] - xs0[i]);
}
dx=(dx/(2 * sdata.length)|0);
if (xs[0] - dx < this.xPixel0 + s25) dx=xs[0] - (this.xPixel0 + s25);
for (var i=0; i < sdata.length; i++) xs[i]-=dx;

var inverted=spec.isInverted$();
var y4=this.pd.getStringWidth$S("99.9999");
var y2=(sdata[0].length >= 6 ? this.pd.getStringWidth$S("99.99") : 0);
var f=(inverted ? -1 : 1);
var y=(inverted ? this.yPixel1 : this.yPixel0) + f * (y2 + y4 + s15 );
for (var i=0; i < sdata.length; i++) {
this.g2d.drawLine$O$I$I$I$I(g, xs[i], y, xs[i], y + s5 * f);
this.g2d.drawLine$O$I$I$I$I(g, xs[i], y + s5 * f, xs0[i], y + s10 * f);
this.g2d.drawLine$O$I$I$I$I(g, xs0[i], y + s10 * f, xs0[i], y + s15 * f);
if (y2 > 0 && sdata[i][4].length$() > 0 ) this.g2d.drawLine$O$I$I$I$I(g, ((xs[i] + xs[i - 1])/2|0), y - y4 + s5, ((xs[i] + xs[i - 1])/2|0), y - y4 - s5 );
}
y-=f * 2 * this.pd.scalingFactor ;
if (y2 > 0) {
p$1.drawStringRotated$O$I$I$I$S.apply(this, [g, -90, xs[0] - s15, y, "  ppm"]);
p$1.drawStringRotated$O$I$I$I$S.apply(this, [g, -90, xs[0] - s15, y - y4 - s5 , " Hz"]);
}for (var i=data.size$(); --i >= 0; ) {
p$1.drawStringRotated$O$I$I$I$S.apply(this, [g, -90 * f, xs[i] + (f * h/3|0), y, sdata[i][1]]);
if (y2 > 0 && sdata[i][4].length$() > 0 ) {
var x=((xs[i] + xs[i - 1])/2|0) + (h/3|0);
p$1.drawStringRotated$O$I$I$I$S.apply(this, [g, -90, x, y - y4 - s5 , sdata[i][4]]);
}}
}, p$1);

Clazz.newMeth(C$, 'drawStringRotated$O$I$I$I$S',  function (g, angle, x, y, s) {
this.g2d.drawStringRotated$O$S$I$I$D(g, s, x, y, angle);
}, p$1);

Clazz.newMeth(C$, 'drawAnnotations$O$javajs_util_Lst$jspecview_common_ScriptToken',  function (g, annotations, whatColor) {
this.pd.setFont$O$I$I$F$Z(g, this.xPixels, 1, 18, false);
for (var i=annotations.size$(); --i >= 0; ) {
var note=annotations.get$I(i);
this.setAnnotationColor$O$jspecview_common_Annotation$jspecview_common_ScriptToken(g, note, whatColor);
var c=(note.is2D ? this.imageView : this);
var x=c.toPixelX$D(note.getXVal$());
var y=(note.isPixels$() ? ((this.yPixel0 + 10 + 10 * this.pd.scalingFactor  - note.getYVal$())|0) : note.is2D ? this.imageView.subIndexToPixelY$I((note.getYVal$()|0)) : this.toPixelY$D(note.getYVal$()));
this.g2d.drawString$O$S$I$I(g, note.text, x + note.offsetX * this.pd.scalingFactor, y - note.offsetY * this.pd.scalingFactor);
}
}, p$1);

Clazz.newMeth(C$, 'drawIntegralValues$O$I$I',  function (g, iSpec, yOffset) {
var integrals=p$1.getMeasurements$jspecview_common_Annotation_AType$I.apply(this, [$I$(5).Integration, iSpec]);
if (integrals != null ) {
if (this.pd.isPrinting) this.pd.setFont$O$I$I$F$Z(g, this.xPixels, 0, 8, false);
 else this.pd.setFont$O$I$I$F$Z(g, this.xPixels, 1, 12, false);
p$1.setColorFromToken$O$jspecview_common_ScriptToken.apply(this, [g, $I$(13).INTEGRALPLOTCOLOR]);
var h=this.pd.getFontHeight$();
this.g2d.setStrokeBold$O$Z(g, true);
for (var i=integrals.size$(); --i >= 0; ) {
var $in=integrals.get$I(i);
if ($in.getValue$() == 0 ) continue;
var x=this.toPixelX$D($in.getXVal2$());
var y1=yOffset * this.pd.scalingFactor + p$1.toPixelYint$D.apply(this, [$in.getYVal$()]);
var y2=yOffset * this.pd.scalingFactor + p$1.toPixelYint$D.apply(this, [$in.getYVal2$()]);
if (x != this.fixX$I(x) || y1 != this.fixY$I(y1)  || y2 != this.fixY$I(y2) ) continue;
if (!this.pd.isPrinting) this.g2d.drawLine$O$I$I$I$I(g, x, y1, x, y2);
var s="  " + $in.text;
this.g2d.drawString$O$S$I$I(g, s, x, ((y1 + y2)/2|0) + (h/3|0));
}
this.g2d.setStrokeBold$O$Z(g, false);
}if (iSpec == p$1.getFixedSelectedSpectrumIndex.apply(this, [])) this.selectedSpectrumIntegrals=integrals;
}, p$1);

Clazz.newMeth(C$, 'drawMeasurements$O$I',  function (g, iSpec) {
var md=p$1.getMeasurements$jspecview_common_Annotation_AType$I.apply(this, [$I$(5).Measurements, iSpec]);
if (md != null ) for (var i=md.size$(); --i >= 0; ) p$1.drawMeasurement$O$jspecview_common_Measurement.apply(this, [g, md.get$I(i)]);

if (iSpec == p$1.getFixedSelectedSpectrumIndex.apply(this, [])) this.selectedSpectrumMeasurements=md;
}, p$1);

Clazz.newMeth(C$, 'drawMeasurement$O$jspecview_common_Measurement',  function (g, m) {
if (m.text.length$() == 0 && m !== this.pendingMeasurement  ) return;
this.pd.setFont$O$I$I$F$Z(g, this.xPixels, 1, 12, false);
this.g2d.setGraphicsColor$O$javajs_api_GenericColor(g, (m === this.pendingMeasurement  ? this.pd.getColor$jspecview_common_ScriptToken($I$(13).PEAKTABCOLOR) : this.pd.BLACK));
var x1=this.toPixelX$D(m.getXVal$());
var y1=this.toPixelY$D(m.getYVal$());
var x2=this.toPixelX$D(m.getXVal2$());
if (Double.isNaN$D(m.getXVal$()) || x1 != this.fixX$I(x1)  || x2 != this.fixX$I(x2) ) return;
var drawString=(Math.abs(x1 - x2) >= 2);
var drawBaseLine=this.getScale$().isYZeroOnScale$() && m.spec.isHNMR$() ;
var x=((x1 + x2)/2|0);
this.g2d.setStrokeBold$O$Z(g, true);
if (drawString) this.g2d.drawLine$O$I$I$I$I(g, x1, y1, x2, y1);
if (drawBaseLine) this.g2d.drawLine$O$I$I$I$I(g, x1 + 1, this.yPixel1 - 1, x2, this.yPixel1 - 1);
this.g2d.setStrokeBold$O$Z(g, false);
if (drawString) this.g2d.drawString$O$S$I$I(g, m.text, x + m.offsetX, y1 - m.offsetY);
if (drawBaseLine) {
this.g2d.drawLine$O$I$I$I$I(g, x1, this.yPixel1, x1, this.yPixel1 - 6 * this.pd.scalingFactor);
this.g2d.drawLine$O$I$I$I$I(g, x2, this.yPixel1, x2, this.yPixel1 - 6 * this.pd.scalingFactor);
}}, p$1);

Clazz.newMeth(C$, 'getPinSelected$I$I',  function (xPixel, yPixel) {
if (this.widgets != null ) for (var i=0; i < this.widgets.length; i++) {
if (this.widgets[i] != null  && this.widgets[i].isPinOrCursor  && this.widgets[i].selected$I$I(xPixel, yPixel) ) {
return this.widgets[i];
}}
return null;
}, p$1);

Clazz.newMeth(C$, 'set2DCrossHairs$I$I',  function (xPixel, yPixel) {
var x;
if (xPixel == this.imageView.fixX$I(xPixel) && yPixel == this.fixY$I(yPixel) ) {
this.pin1Dx1.setX$D$I(x=this.imageView.toX$I(xPixel), this.toPixelX$D(x));
this.cur2Dx1.setX$D$I(x, xPixel);
p$1.setCurrentSubSpectrum$I.apply(this, [this.imageView.toSubspectrumIndex$I(yPixel)]);
if (this.isLinked) {
var y=this.imageView.toY$I(yPixel);
this.pd.set2DCrossHairsLinked$jspecview_common_GraphSet$D$D$Z(this, x, y, !this.sticky2Dcursor);
}}});

Clazz.newMeth(C$, 'reset2D$Z',  function (isX) {
if (isX) {
this.imageView.setView0$I$I$I$I(this.imageView.xPixel0, this.pin2Dy0.yPixel0, this.imageView.xPixel1, this.pin2Dy1.yPixel0);
this.doZoom$D$D$D$D$Z$Z$Z$Z$Z(0, this.getScale$().minY, 0, this.getScale$().maxY, true, false, false, false, true);
} else {
this.imageView.setView0$I$I$I$I(this.pin2Dx0.xPixel0, this.imageView.yPixel0, this.pin2Dx1.xPixel0, this.imageView.yPixel1);
}}, p$1);

Clazz.newMeth(C$, 'setAnnotationText$jspecview_common_Annotation',  function (a) {
var sval=this.pd.getInput$S$S$S("New text?", "Set Label", a.text);
if (sval == null ) return false;
if (sval.length$() == 0) this.annotations.removeObj$O(a);
 else a.text=sval;
return true;
}, p$1);

Clazz.newMeth(C$, 'checkIntegral$D$D$Z',  function (x1, x2, isFinal) {
var ad=this.getDialog$jspecview_common_Annotation_AType$I($I$(5).Integration, -1);
if (ad == null ) return false;
var integral=(ad.getData$()).addIntegralRegion$D$D(x1, x2);
if (isFinal && Clazz.instanceOf(ad, "jspecview.dialog.JSVDialog") ) (ad).update$jspecview_common_Coordinate$D$I(null, 0, 0);
if (Double.isNaN$D(x2)) return false;
this.pendingIntegral=(isFinal ? null : integral);
this.pd.isIntegralDrag=!isFinal;
this.selectedSpectrumIntegrals=null;
return true;
}, p$1);

Clazz.newMeth(C$, 'setToolTipForPixels$I$I',  function (xPixel, yPixel) {
if (this.iSpectrumMovedTo != this.iSpectrumClicked || this.pd.getCurrentGraphSet$() !== this  ) {
this.pd.setToolTipText$S("click spectrum to activate");
return;
}if (p$1.isSplitWidget$I$I.apply(this, [xPixel, yPixel])) {
this.pd.setToolTipText$S("click to " + (this.nSplit > 1 ? "combine" : "split"));
return;
}if (p$1.isCloserWidget$I$I.apply(this, [xPixel, yPixel])) {
this.pd.setToolTipText$S("click to close");
return;
}var pw=p$1.getPinSelected$I$I.apply(this, [xPixel, yPixel]);
var precisionX=this.getScale$().precision[0];
var precisionY=this.getScale$().precision[1];
if (pw != null ) {
if (p$1.setStartupPinTip.apply(this, [])) return;
var s;
if (pw === this.pin1Dx01  || pw === this.pin2Dx01  ) {
s=$I$(14,"formatDecimalDbl$D$I",[Math.min(this.pin1Dx0.getXVal$(), this.pin1Dx1.getXVal$()), precisionX]) + " - " + $I$(14,"formatDecimalDbl$D$I",[Math.max(this.pin1Dx0.getXVal$(), this.pin1Dx1.getXVal$()), precisionX]) ;
} else if (pw === this.pin1Dy01 ) {
s=$I$(14,"formatDecimalDbl$D$I",[Math.min(this.pin1Dy0.getYVal$(), this.pin1Dy1.getYVal$()), precisionY]) + " - " + $I$(14,"formatDecimalDbl$D$I",[Math.max(this.pin1Dy0.getYVal$(), this.pin1Dy1.getYVal$()), precisionY]) ;
} else if (pw === this.cur2Dy ) {
var isub=this.imageView.toSubspectrumIndex$I(pw.yPixel0);
s=p$1.get2DYLabel$I$I.apply(this, [isub, precisionX]);
} else if (pw === this.pin2Dy01 ) {
s="" + (Math.min(this.pin2Dy0.getYVal$(), this.pin2Dy1.getYVal$())|0) + " - " + (Math.max(this.pin2Dy0.getYVal$(), this.pin2Dy1.getYVal$())|0) ;
} else if (pw.isXtype) {
s=$I$(14,"formatDecimalDbl$D$I",[pw.getXVal$(), precisionX]);
} else if (pw.is2D) {
s="" + (pw.getYVal$()|0);
} else {
s=$I$(14,"formatDecimalDbl$D$I",[pw.getYVal$(), precisionY]);
}this.pd.setToolTipText$S(s);
return;
}var yPt;
if (this.imageView != null ) {
if (this.imageView.fixX$I(xPixel) == xPixel && this.fixY$I(yPixel) == yPixel ) {
var isub=this.imageView.toSubspectrumIndex$I(yPixel);
var s="y=" + p$1.get2DYLabel$I$I.apply(this, [isub, precisionX]) + " / x=" + $I$(14,"formatDecimalDbl$D$I",[this.imageView.toX$I(xPixel), precisionX]) + " " + this.getSpectrum$().getAxisLabel$Z(true) ;
this.pd.setToolTipText$S(s);
this.pd.coordStr=s;
return;
}if (!this.pd.display1D) {
this.pd.setToolTipText$S("");
this.pd.coordStr="";
return;
}}var xPt=this.toX$I(this.fixX$I(xPixel));
yPt=(this.imageView != null  && this.imageView.isXWithinRange$I(xPixel)  ? this.imageView.toSubspectrumIndex$I(this.fixY$I(yPixel)) : this.toY$I(this.fixY$I(yPixel)));
var xx=p$1.setCoordStr$D$D.apply(this, [xPt, yPt]);
var iSpec=p$1.getFixedSelectedSpectrumIndex.apply(this, []);
if (!p$1.isInPlotRegion$I$I.apply(this, [xPixel, yPixel])) {
yPt=NaN;
} else if (this.nSpectra == 1) {
} else if (this.haveIntegralDisplayed$I(iSpec)) {
yPt=this.getIntegrationGraph$I(iSpec).getPercentYValueAt$D(xPt);
xx+=", " + $I$(14).formatDecimalDbl$D$I(yPt, 1);
}this.pd.setToolTipText$S((this.selectedIntegral != null  ? "click to set value" : this.pendingMeasurement != null  || this.selectedMeasurement != null   ? (this.pd.hasFocus$() ? "Press ESC to delete " + (this.selectedIntegral != null  ? "integral, DEL to delete all visible, or N to normalize" : this.pendingMeasurement == null  ? "\"" + this.selectedMeasurement.text + "\" or DEL to delete all visible"  : "measurement") : "") : Double.isNaN$D(yPt) ? null : xx));
}, p$1);

Clazz.newMeth(C$, 'isFrameBox$I$I$I$I',  function (xPixel, yPixel, boxX, boxY) {
return Math.abs(xPixel - (boxX + 5)) < 5 && Math.abs(yPixel - (boxY + 5)) < 5 ;
}, p$1);

Clazz.newMeth(C$, 'setCoordStr$D$D',  function (xPt, yPt) {
var xx=$I$(14,"formatDecimalDbl$D$I",[xPt, this.getScale$().precision[0]]);
this.pd.coordStr="(" + xx + (this.haveSingleYScale || this.iSpectrumSelected >= 0  ? ", " + $I$(14,"formatDecimalDbl$D$I",[yPt, this.getScale$().precision[1]]) : "") + ")" ;
return xx;
}, p$1);

Clazz.newMeth(C$, 'setStartupPinTip',  function () {
if (this.pd.startupPinTip == null ) return false;
this.pd.setToolTipText$S(this.pd.startupPinTip);
this.pd.startupPinTip=null;
return true;
}, p$1);

Clazz.newMeth(C$, 'get2DYLabel$I$I',  function (isub, precision) {
var spec=this.getSpectrumAt$I(0).getSubSpectra$().get$I(isub);
return $I$(14,"formatDecimalDbl$D$I",[spec.getY2DPPM$(), precision]) + " PPM" + (spec.y2DUnits.equals$O("HZ") ? " (" + $I$(14,"formatDecimalDbl$D$I",[spec.getY2D$(), precision]) + " HZ) "  : "") ;
}, p$1);

Clazz.newMeth(C$, 'isOnSpectrum$I$I$I',  function (xPixel, yPixel, index) {
var xyCoords=null;
var isContinuous=true;
var isIntegral=(index < 0);
if (isIntegral) {
var ad=this.getDialog$jspecview_common_Annotation_AType$I($I$(5).Integration, -1);
if (ad == null ) return false;
xyCoords=(ad.getData$()).getXYCoords$();
index=p$1.getFixedSelectedSpectrumIndex.apply(this, []);
} else {
this.setScale$I(index);
var spec=this.spectra.get$I(index);
xyCoords=spec.xyCoords;
isContinuous=spec.isContinuous$();
}var yOffset=index * ((this.yPixels * (this.yStackOffsetPercent / 100.0))|0);
var ix0=this.viewData.getStartingPointIndex$I(index);
var ix1=this.viewData.getEndingPointIndex$I(index);
if (isContinuous) {
for (var i=ix0; i < ix1; i++) {
var point1=xyCoords[i];
var point2=xyCoords[i + 1];
var x1=this.toPixelX$D(point1.getXVal$());
var x2=this.toPixelX$D(point2.getXVal$());
var y1=(isIntegral ? p$1.toPixelYint$D.apply(this, [point1.getYVal$()]) : this.toPixelY$D(point1.getYVal$()));
var y2=(isIntegral ? p$1.toPixelYint$D.apply(this, [point2.getYVal$()]) : this.toPixelY$D(point2.getYVal$()));
if (y1 == -2147483648 || y2 == -2147483648 ) continue;
y1=this.fixY$I(y1) - yOffset;
y2=this.fixY$I(y2) - yOffset;
if (C$.isOnLine$I$I$I$I$I$I(xPixel, yPixel, x1, y1, x2, y2)) return true;
}
} else {
for (var i=ix0; i <= ix1; i++) {
var point=xyCoords[i];
var y2=this.toPixelY$D(point.getYVal$());
if (y2 == -2147483648) continue;
var x1=this.toPixelX$D(point.getXVal$());
var y1=this.toPixelY$D(Math.max(this.getScale$().minYOnScale, 0));
y1=this.fixY$I(y1);
y2=this.fixY$I(y2);
if (y1 == y2 && (y1 == this.yPixel0 || y1 == this.yPixel1 ) ) continue;
if (C$.isOnLine$I$I$I$I$I$I(xPixel, yPixel, x1, y1, x1, y2)) return true;
}
}return false;
}, p$1);

Clazz.newMeth(C$, 'distance$I$I',  function (dx, dy) {
return Math.sqrt(dx * dx + dy * dy);
}, 1);

Clazz.newMeth(C$, 'findCompatibleGraphSet$javajs_util_Lst$jspecview_common_Spectrum',  function (graphSets, spec) {
for (var i=0; i < graphSets.size$(); i++) if ($I$(15,"areXScalesCompatible$jspecview_common_Spectrum$jspecview_common_Spectrum$Z$Z",[spec, graphSets.get$I(i).getSpectrum$(), false, false])) return graphSets.get$I(i);

return null;
}, 1);

Clazz.newMeth(C$, 'isGoodEvent$jspecview_common_PlotWidget$jspecview_common_PlotWidget$Z',  function (zOrP, p, asX) {
return (p == null  ? (Math.abs(zOrP.xPixel1 - zOrP.xPixel0) > 5 && Math.abs(zOrP.yPixel1 - zOrP.yPixel0) > 5 ) : asX ? Math.abs(zOrP.xPixel0 - p.xPixel0) > 5 : Math.abs(zOrP.yPixel0 - p.yPixel0) > 5);
}, 1);

Clazz.newMeth(C$, 'isOnLine$I$I$I$I$I$I',  function (xPixel, yPixel, x1, y1, x2, y2) {
var dx1=Math.abs(x1 - xPixel);
if (dx1 < 2 && Math.abs(y1 - yPixel) < 2 ) return true;
var dx2=x2 - xPixel;
if (Math.abs(dx2) < 2 && Math.abs(y2 - yPixel) < 2 ) return true;
var dy12=y1 - y2;
if (Math.abs(dy12) > 2 && (y1 < yPixel) == (y2 < yPixel)  ) return false;
var dx12=x1 - x2;
if (Math.abs(dx12) > 2 && (x1 < xPixel) == (x2 < xPixel)  ) return false;
return (C$.distance$I$I(dx1, y1 - yPixel) + C$.distance$I$I(dx2, yPixel - y2) < C$.distance$I$I(dx12, dy12) + 2 );
}, 1);

Clazz.newMeth(C$, 'setFractionalPositions$jspecview_common_PanelData$javajs_util_Lst$jspecview_common_PanelData_LinkMode',  function (pd, graphSets, linkMode) {
var n=graphSets.size$();
var f=0;
var n2d=1;
var gs;
var y=0;
pd.isLinked=(linkMode !== $I$(6).NONE );
if (linkMode === $I$(6).NONE ) {
for (var i=0; i < n; i++) {
gs=graphSets.get$I(i);
f+=(gs.getSpectrumAt$I(0).is1D$() ? 1 : n2d) * gs.nSplit;
}
f=1 / f;
for (var i=0; i < n; i++) {
gs=graphSets.get$I(i);
gs.isLinked=false;
var g=(gs.getSpectrumAt$I(0).is1D$() ? f : n2d * f);
gs.fX0=0;
gs.fY0=y;
gs.fracX=1;
gs.fracY=g;
y+=g * gs.nSplit;
}
} else {
var gs2d=null;
var i2d=-1;
if (n == 2 || n == 3 ) for (var i=0; i < n; i++) {
gs=graphSets.get$I(i);
if (!gs.getSpectrum$().is1D$()) {
gs2d=gs;
if (i2d >= 0) i=-2;
i2d=i;
break;
}}
if (i2d == -2 || i2d == -1 && n != 2  ) {
C$.setFractionalPositions$jspecview_common_PanelData$javajs_util_Lst$jspecview_common_PanelData_LinkMode(pd, graphSets, $I$(6).NONE);
return;
}for (var i=0; i < n; i++) {
gs=graphSets.get$I(i);
gs.isLinked=true;
var s1=gs.getSpectrumAt$I(0);
var is1D=s1.is1D$();
if (is1D) {
if (gs2d != null ) {
var s2=gs2d.getSpectrumAt$I(0);
if ($I$(15).areLinkableX$jspecview_common_Spectrum$jspecview_common_Spectrum(s1, s2)) gs.gs2dLinkedX=gs2d;
if ($I$(15).areLinkableY$jspecview_common_Spectrum$jspecview_common_Spectrum(s1, s2)) gs.gs2dLinkedY=gs2d;
}gs.fX0=0;
gs.fY0=y;
gs.fracX=(gs2d == null  ? 1 : 0.5);
gs.fracY=(n == 3 || gs2d == null   ? 0.5 : 1);
y+=0.5;
} else {
gs.fX0=0.5;
gs.fY0=0;
gs.fracX=0.5;
gs.fracY=1;
}}
}}, 1);

Clazz.newMeth(C$, 'addAnnotation$javajs_util_Lst$S',  function (args, title) {
if (args.size$() == 0 || args.size$() == 1 && args.get$I(0).equalsIgnoreCase$S("none")  ) {
this.annotations=null;
this.lastAnnotation=null;
return null;
}if (args.size$() < 4 && this.lastAnnotation == null  ) this.lastAnnotation=p$1.getAnnotation$D$D$S$Z$Z$I$I.apply(this, [(this.getScale$().maxXOnScale + this.getScale$().minXOnScale) / 2, (this.getScale$().maxYOnScale + this.getScale$().minYOnScale) / 2, title, false, false, 0, 0]);
var annotation=p$1.getAnnotation$javajs_util_Lst$jspecview_common_Annotation.apply(this, [args, this.lastAnnotation]);
if (annotation == null ) return null;
if (this.annotations == null  && args.size$() == 1  && args.get$I(0).charAt$I(0) == "\"" ) {
var s=annotation.text;
this.getSpectrum$().setTitle$S(s);
return s;
}this.lastAnnotation=annotation;
p$1.addAnnotation$jspecview_common_Annotation$Z.apply(this, [annotation, false]);
return null;
});

Clazz.newMeth(C$, 'addHighlight$D$D$jspecview_common_Spectrum$javajs_api_GenericColor',  function (x1, x2, spec, color) {
if (spec == null ) spec=this.getSpectrumAt$I(0);
var hl=Clazz.new_([this, null, x1, x2, spec, (color == null  ? this.pd.getColor$jspecview_common_ScriptToken($I$(13).HIGHLIGHTCOLOR) : color)],$I$(16,1).c$$D$D$jspecview_common_Spectrum$javajs_api_GenericColor);
if (!this.highlights.contains$O(hl)) this.highlights.addLast$O(hl);
});

Clazz.newMeth(C$, 'addPeakHighlight$jspecview_common_PeakInfo',  function (peakInfo) {
for (var i=this.spectra.size$(); --i >= 0; ) {
var spec=this.spectra.get$I(i);
p$1.removeAllHighlights$jspecview_common_Spectrum.apply(this, [spec]);
if (peakInfo == null  || peakInfo.isClearAll$()  || spec !== peakInfo.spectrum  ) continue;
var peak=peakInfo.toString();
if (peak == null ) {
continue;
}var xMin=$I$(17).getQuotedAttribute$S$S(peak, "xMin");
var xMax=$I$(17).getQuotedAttribute$S$S(peak, "xMax");
if (xMin == null  || xMax == null  ) return;
var x1=$I$(17).parseDouble$S(xMin);
var x2=$I$(17).parseDouble$S(xMax);
if (Double.isNaN$D(x1) || Double.isNaN$D(x2) ) return;
this.pd.addHighlight$jspecview_common_GraphSet$D$D$jspecview_common_Spectrum$I$I$I$I(this, x1, x2, spec, 200, 140, 140, 100);
spec.setSelectedPeak$jspecview_common_PeakInfo(peakInfo);
if (this.getScale$().isInRangeX$D(x1) || this.getScale$().isInRangeX$D(x2) || x1 < this.getScale$().minX  && this.getScale$().maxX < x2    ) {
} else {
p$1.setZoomTo$I.apply(this, [0]);
}}
});

Clazz.newMeth(C$, 'advanceSubSpectrum$I',  function (dir) {
var spec0=this.getSpectrumAt$I(0);
var i=spec0.advanceSubSpectrum$I(dir);
if (spec0.isForcedSubset$()) this.viewData.setXRangeForSubSpectrum$jspecview_common_CoordinateA(this.getSpectrum$().getXYCoords$());
this.pd.notifySubSpectrumChange$I$jspecview_common_Spectrum(i, this.getSpectrum$());
});

Clazz.newMeth(C$, 'checkSpectrumClickedEvent$I$I$I',  function (xPixel, yPixel, clickCount) {
if (this.nextClickForSetPeak != null ) return false;
if (clickCount > 1 || this.pendingMeasurement != null   || !p$1.isInPlotRegion$I$I.apply(this, [xPixel, yPixel]) ) return false;
if (clickCount == 0) {
var isOnIntegral=p$1.isOnSpectrum$I$I$I.apply(this, [xPixel, yPixel, -1]);
this.pd.integralShiftMode=(isOnIntegral ? p$1.getShiftMode$I$I.apply(this, [xPixel, yPixel]) : 0);
this.pd.isIntegralDrag=(this.pd.integralShiftMode == 0 && (isOnIntegral || this.haveIntegralDisplayed$I(-1) && p$1.findMeasurement$jspecview_common_MeasurementData$I$I$I.apply(this, [this.getIntegrationGraph$I(-1), xPixel, yPixel, 0]) != null   ) );
if (this.pd.integralShiftMode != 0) return false;
}if (!this.showAllStacked) return false;
this.stackSelected=false;
for (var i=0; i < this.nSpectra; i++) {
if (!p$1.isOnSpectrum$I$I$I.apply(this, [xPixel, yPixel, i])) continue;
p$1.setSpectrumClicked$I.apply(this, [this.iPreviousSpectrumClicked=i]);
return false;
}
if (p$1.isDialogOpen.apply(this, [])) return false;
p$1.setSpectrumClicked$I.apply(this, [-1]);
return this.stackSelected=false;
});

Clazz.newMeth(C$, 'getShiftMode$I$I',  function (xPixel, yPixel) {
return (p$1.isStartEndIntegral$I$Z.apply(this, [xPixel, false]) ? yPixel : p$1.isStartEndIntegral$I$Z.apply(this, [xPixel, true]) ? -yPixel : 0);
}, p$1);

Clazz.newMeth(C$, 'isDialogOpen',  function () {
return (p$1.isVisible$jspecview_api_AnnotationData.apply(this, [this.getDialog$jspecview_common_Annotation_AType$I($I$(5).Integration, -1)]) || p$1.isVisible$jspecview_api_AnnotationData.apply(this, [this.getDialog$jspecview_common_Annotation_AType$I($I$(5).Measurements, -1)]) || p$1.isVisible$jspecview_api_AnnotationData.apply(this, [this.getDialog$jspecview_common_Annotation_AType$I($I$(5).PeakList, -1)])  );
}, p$1);

Clazz.newMeth(C$, 'isStartEndIntegral$I$Z',  function (xPixel, isEnd) {
return (isEnd ? this.xPixelPlot1 - xPixel < 20 : xPixel - this.xPixelPlot0 < 20);
}, p$1);

Clazz.newMeth(C$, 'checkWidgetEvent$I$I$Z',  function (xPixel, yPixel, isPress) {
if (!this.widgetsAreSet) return false;
this.widgetsAreSet=false;
var widget;
if (isPress) {
if (this.pd.clickCount == 2 && this.lastIntDragX != xPixel  && !p$1.is2dClick$I$I.apply(this, [xPixel, yPixel]) ) {
if (this.pendingMeasurement == null ) {
if (this.iSpectrumClicked == -1 && this.iPreviousSpectrumClicked >= 0 ) {
p$1.setSpectrumClicked$I.apply(this, [this.iPreviousSpectrumClicked]);
}p$1.processPendingMeasurement$I$I$I.apply(this, [xPixel, yPixel, 2]);
return true;
}} else if (!p$1.is2dClick$I$I.apply(this, [xPixel, yPixel])) {
if (p$1.isOnSpectrum$I$I$I.apply(this, [xPixel, yPixel, -1])) {
p$1.checkIntegral$D$D$Z.apply(this, [this.toX$I(xPixel), NaN, false]);
}if (this.lastIntDragX == xPixel) {
this.pd.isIntegralDrag=true;
if (!p$1.checkIntegral$D$D$Z.apply(this, [this.toX$I(xPixel), this.toX$I(xPixel), false])) return false;
}}if (this.pendingMeasurement != null ) return true;
widget=p$1.getPinSelected$I$I.apply(this, [xPixel, yPixel]);
if (widget == null ) {
yPixel=this.fixY$I(yPixel);
if (xPixel < this.xPixel1) {
if (this.pd.shiftPressed) p$1.setSpectrumClicked$I.apply(this, [this.iPreviousSpectrumClicked]);
xPixel=this.fixX$I(xPixel);
if (this.zoomBox1D == null ) p$1.newPins.apply(this, []);
this.zoomBox1D.setX$D$I(this.toX$I(xPixel), xPixel);
this.zoomBox1D.yPixel0=yPixel;
widget=this.zoomBox1D;
} else if (this.imageView != null  && xPixel < this.imageView.xPixel1 ) {
this.zoomBox2D.setX$D$I(this.imageView.toX$I(xPixel), this.imageView.fixX$I(xPixel));
this.zoomBox2D.yPixel0=yPixel;
widget=this.zoomBox2D;
}}this.pd.thisWidget=widget;
return false;
}this.nextClickForSetPeak=null;
widget=this.pd.thisWidget;
if (widget == null ) return false;
if (widget === this.zoomBox1D ) {
this.zoomBox1D.xPixel1=this.fixX$I(xPixel);
this.zoomBox1D.yPixel1=this.fixY$I(yPixel);
if (this.pd.isIntegralDrag && this.zoomBox1D.xPixel0 != this.zoomBox1D.xPixel1 ) {
if ((this.lastIntDragX <= xPixel) != (this.zoomBox1D.xPixel0 <= xPixel) ) {
this.zoomBox1D.xPixel0=this.lastIntDragX;
this.zoomBox1D.xPixel1=xPixel;
this.zoomBox1D.setXVal$D(this.toX$I(this.zoomBox1D.xPixel0));
}this.lastIntDragX=xPixel;
p$1.checkIntegral$D$D$Z.apply(this, [this.zoomBox1D.getXVal$(), this.toX$I(this.zoomBox1D.xPixel1), false]);
}return false;
}if (!this.zoomEnabled) return false;
if (widget === this.zoomBox2D ) {
this.zoomBox2D.xPixel1=this.imageView.fixX$I(xPixel);
this.zoomBox2D.yPixel1=this.fixY$I(yPixel);
return true;
}if (widget === this.cur2Dy ) {
yPixel=this.fixY$I(yPixel);
this.cur2Dy.yPixel0=this.cur2Dy.yPixel1=yPixel;
p$1.setCurrentSubSpectrum$I.apply(this, [this.imageView.toSubspectrumIndex$I(yPixel)]);
return true;
}if (widget === this.cur2Dx0  || widget === this.cur2Dx1  ) {
return false;
}if (widget === this.pin1Dx0  || widget === this.pin1Dx1   || widget === this.pin1Dx01  ) {
xPixel=this.fixX$I(xPixel);
widget.setX$D$I(p$1.toX0$I.apply(this, [xPixel]), xPixel);
if (widget === this.pin1Dx01 ) {
var dp=xPixel - (((this.pin1Dx0.xPixel0 + this.pin1Dx1.xPixel0)/2|0));
var dp1=(dp < 0 ? dp : dp);
var dp2=(dp < 0 ? dp : dp);
xPixel=this.pin1Dx0.xPixel0 + dp2;
var xPixel1=this.pin1Dx1.xPixel0 + dp1;
if (dp == 0 || this.fixX$I(xPixel) != xPixel  || this.fixX$I(xPixel1) != xPixel1 ) return true;
this.pin1Dx0.setX$D$I(p$1.toX0$I.apply(this, [xPixel]), xPixel);
this.pin1Dx1.setX$D$I(p$1.toX0$I.apply(this, [xPixel1]), xPixel1);
}this.doZoom$D$D$D$D$Z$Z$Z$Z$Z(this.pin1Dx0.getXVal$(), 0, this.pin1Dx1.getXVal$(), 0, true, false, false, true, false);
return true;
}if (widget === this.pin1Dy0  || widget === this.pin1Dy1   || widget === this.pin1Dy01  ) {
yPixel=this.fixY$I(yPixel);
widget.setY$D$I(p$1.toY0$I.apply(this, [yPixel]), yPixel);
if (widget === this.pin1Dy01 ) {
var dp=yPixel - ((this.pin1Dy0.yPixel0 + this.pin1Dy1.yPixel0)/2|0) + 1;
yPixel=this.pin1Dy0.yPixel0 + dp;
var yPixel1=this.pin1Dy1.yPixel0 + dp;
var y0=p$1.toY0$I.apply(this, [yPixel]);
var y1=p$1.toY0$I.apply(this, [yPixel1]);
if (Math.min(y0, y1) == this.getScale$().minY  || Math.max(y0, y1) == this.getScale$().maxY  ) return true;
this.pin1Dy0.setY$D$I(y0, yPixel);
this.pin1Dy1.setY$D$I(y1, yPixel1);
}this.doZoom$D$D$D$D$Z$Z$Z$Z$Z(0, this.pin1Dy0.getYVal$(), 0, this.pin1Dy1.getYVal$(), this.imageView == null , this.imageView == null , false, false, false);
return true;
}if (widget === this.pin2Dx0  || widget === this.pin2Dx1   || widget === this.pin2Dx01  ) {
xPixel=this.imageView.fixX$I(xPixel);
widget.setX$D$I(this.imageView.toX0$I(xPixel), xPixel);
if (widget === this.pin2Dx01 ) {
var dp=xPixel - ((this.pin2Dx0.xPixel0 + this.pin2Dx1.xPixel0)/2|0) + 1;
xPixel=this.pin2Dx0.xPixel0 + dp;
var xPixel1=this.pin2Dx1.xPixel0 + dp;
if (this.imageView.fixX$I(xPixel) != xPixel || this.imageView.fixX$I(xPixel1) != xPixel1 ) return true;
this.pin2Dx0.setX$D$I(this.imageView.toX0$I(xPixel), xPixel);
this.pin2Dx1.setX$D$I(this.imageView.toX0$I(xPixel1), xPixel1);
}if (!C$.isGoodEvent$jspecview_common_PlotWidget$jspecview_common_PlotWidget$Z(this.pin2Dx0, this.pin2Dx1, true)) {
p$1.reset2D$Z.apply(this, [true]);
return true;
}this.imageView.setView0$I$I$I$I(this.pin2Dx0.xPixel0, this.pin2Dy0.yPixel0, this.pin2Dx1.xPixel0, this.pin2Dy1.yPixel0);
this.doZoom$D$D$D$D$Z$Z$Z$Z$Z(this.pin2Dx0.getXVal$(), this.getScale$().minY, this.pin2Dx1.getXVal$(), this.getScale$().maxY, false, false, false, true, false);
return true;
}if (widget === this.pin2Dy0  || widget === this.pin2Dy1   || widget === this.pin2Dy01  ) {
yPixel=this.fixY$I(yPixel);
widget.setY$D$I(this.imageView.toSubspectrumIndex$I(yPixel), yPixel);
if (widget === this.pin2Dy01 ) {
var dp=yPixel - ((this.pin2Dy0.yPixel0 + this.pin2Dy1.yPixel0)/2|0) + 1;
yPixel=this.pin2Dy0.yPixel0 + dp;
var yPixel1=this.pin2Dy1.yPixel0 + dp;
if (yPixel != this.fixY$I(yPixel) || yPixel1 != this.fixY$I(yPixel1) ) return true;
this.pin2Dy0.setY$D$I(this.imageView.toSubspectrumIndex$I(yPixel), yPixel);
this.pin2Dy1.setY$D$I(this.imageView.toSubspectrumIndex$I(yPixel1), yPixel1);
}if (!C$.isGoodEvent$jspecview_common_PlotWidget$jspecview_common_PlotWidget$Z(this.pin2Dy0, this.pin2Dy1, false)) {
p$1.reset2D$Z.apply(this, [false]);
return true;
}this.imageView.setView0$I$I$I$I(this.pin2Dx0.xPixel0, this.pin2Dy0.yPixel0, this.pin2Dx1.xPixel1, this.pin2Dy1.yPixel1);
return true;
}return false;
});

Clazz.newMeth(C$, 'clearIntegrals$',  function () {
p$1.checkIntegral$D$D$Z.apply(this, [NaN, 0, false]);
});

Clazz.newMeth(C$, 'clearMeasurements$',  function () {
this.removeDialog$I$jspecview_common_Annotation_AType(p$1.getFixedSelectedSpectrumIndex.apply(this, []), $I$(5).Measurements);
});

Clazz.newMeth(C$, 'createGraphSetsAndSetLinkMode$jspecview_common_PanelData$jspecview_api_JSVPanel$javajs_util_Lst$I$I$jspecview_common_PanelData_LinkMode',  function (pd, jsvp, spectra, startIndex, endIndex, linkMode) {
var graphSets=Clazz.new_($I$(1,1));
for (var i=0; i < spectra.size$(); i++) {
var spec=spectra.get$I(i);
var graphSet=(linkMode === $I$(6).NONE  ? C$.findCompatibleGraphSet$javajs_util_Lst$jspecview_common_Spectrum(graphSets, spec) : null);
if (graphSet == null ) graphSets.addLast$O(graphSet=Clazz.new_(C$.c$$jspecview_common_PanelData,[jsvp.getPanelData$()]));
p$1.addSpec$jspecview_common_Spectrum.apply(graphSet, [spec]);
}
C$.setFractionalPositions$jspecview_common_PanelData$javajs_util_Lst$jspecview_common_PanelData_LinkMode(pd, graphSets, linkMode);
for (var i=graphSets.size$(); --i >= 0; ) {
p$1.initGraphSet$I$I.apply(graphSets.get$I(i), [startIndex, endIndex]);
$I$(18,"info$S",["JSVGraphSet " + (i + 1) + " nSpectra = " + graphSets.get$I(i).nSpectra ]);
}
return graphSets;
}, 1);

Clazz.newMeth(C$, 'drawGraphSet$O$O$O$I$I$I$I$I$I$Z$Z$Z',  function (gMain, gFront, gBack, width, height, left, right, top, bottom, isResized, taintedAll, pointsOnly) {
this.zoomEnabled=this.pd.getBoolean$jspecview_common_ScriptToken($I$(13).ENABLEZOOM);
this.height=height * this.pd.scalingFactor;
this.width=width * this.pd.scalingFactor;
this.left=left * this.pd.scalingFactor;
this.right=right * this.pd.scalingFactor;
this.top=top * this.pd.scalingFactor;
this.bottom=bottom * this.pd.scalingFactor;
this.haveSelectedSpectrum=false;
this.selectedSpectrumIntegrals=null;
this.selectedSpectrumMeasurements=null;
if (!this.pd.isPrinting && this.widgets != null  ) for (var j=0; j < this.widgets.length; j++) if (this.widgets[j] != null ) this.widgets[j].isVisible=false;

for (var iSplit=0; iSplit < this.nSplit; iSplit++) {
p$1.setPositionForFrame$I.apply(this, [iSplit]);
p$1.drawAll$O$O$O$I$Z$Z$Z.apply(this, [gMain, gFront, gBack, iSplit, isResized || this.nSplit > 1 , taintedAll, pointsOnly]);
}
p$1.setPositionForFrame$I.apply(this, [this.nSplit > 1 ? this.pd.currentSplitPoint : 0]);
if (this.pd.isPrinting) return;
});

Clazz.newMeth(C$, 'escapeKeyPressed$Z',  function (isDEL) {
if (this.zoomBox1D != null ) this.zoomBox1D.xPixel0=this.zoomBox1D.xPixel1=0;
if (this.zoomBox2D != null ) this.zoomBox2D.xPixel0=this.zoomBox2D.xPixel1=0;
if (!this.inPlotMove) return;
if (this.pendingMeasurement != null ) {
this.pendingMeasurement=null;
return;
}this.pd.thisWidget=null;
this.pendingMeasurement=null;
if (this.selectedSpectrumMeasurements != null  && this.selectedMeasurement != null  ) {
if (isDEL) this.selectedSpectrumMeasurements.clear$D$D(this.getScale$().minXOnScale, this.getScale$().maxXOnScale);
 else this.selectedSpectrumMeasurements.removeObj$O(this.selectedMeasurement);
this.selectedMeasurement=null;
p$1.updateDialog$jspecview_common_Annotation_AType$I.apply(this, [$I$(5).Measurements, -1]);
}if (this.selectedSpectrumIntegrals != null  && this.selectedIntegral != null  ) {
if (isDEL) this.selectedSpectrumIntegrals.clear$D$D(this.getScale$().minXOnScale, this.getScale$().maxXOnScale);
 else this.selectedSpectrumIntegrals.removeObj$O(this.selectedIntegral);
this.selectedIntegral=null;
p$1.updateDialog$jspecview_common_Annotation_AType$I.apply(this, [$I$(5).Integration, -1]);
}});

Clazz.newMeth(C$, 'findGraphSet$javajs_util_Lst$I$I',  function (graphSets, xPixel, yPixel) {
for (var i=graphSets.size$(); --i >= 0; ) if (p$1.hasPoint$I$I.apply(graphSets.get$I(i), [xPixel, yPixel])) return graphSets.get$I(i);

return null;
}, 1);

Clazz.newMeth(C$, 'findMatchingPeakInfo$jspecview_common_PeakInfo',  function (pi) {
var pi2=null;
for (var i=0; i < this.spectra.size$(); i++) if ((pi2=(this.spectra.get$I(i)).findMatchingPeakInfo$jspecview_common_PeakInfo(pi)) != null ) break;

return pi2;
});

Clazz.newMeth(C$, 'getCurrentSpectrumIndex$',  function () {
return (this.nSpectra == 1 ? 0 : this.iSpectrumSelected);
});

Clazz.newMeth(C$, 'getSelectedIntegral$',  function () {
return this.selectedIntegral;
});

Clazz.newMeth(C$, 'getShowAnnotation$jspecview_common_Annotation_AType$I',  function (type, i) {
var id=this.getDialog$jspecview_common_Annotation_AType$I(type, i);
return (id != null  && id.getState$() );
});

Clazz.newMeth(C$, 'hasFileLoaded$S',  function (filePath) {
for (var i=this.spectra.size$(); --i >= 0; ) if (this.spectra.get$I(i).getFilePathForwardSlash$().equals$O(filePath)) return true;

return false;
});

Clazz.newMeth(C$, 'haveSelectedSpectrum$',  function () {
return this.haveSelectedSpectrum;
});

Clazz.newMeth(C$, 'mouseClickedEvent$I$I$I$Z',  function (xPixel, yPixel, clickCount, isControlDown) {
this.selectedMeasurement=null;
this.selectedIntegral=null;
var isNextClick=this.nextClickForSetPeak;
this.nextClickForSetPeak=null;
if (p$1.checkArrowUpDownClick$I$I.apply(this, [xPixel, yPixel]) || p$1.checkArrowLeftRightClick$I$I.apply(this, [xPixel, yPixel]) ) return;
this.lastClickX=NaN;
this.lastPixelX=2147483647;
if (p$1.isSplitWidget$I$I.apply(this, [xPixel, yPixel])) {
this.splitStack$Z(this.nSplit == 1);
return;
}if (p$1.isCloserWidget$I$I.apply(this, [xPixel, yPixel])) {
this.pd.closeSpectrum$();
return;
}var pw=p$1.getPinSelected$I$I.apply(this, [xPixel, yPixel]);
if (pw != null ) {
p$1.setWidgetValueByUser$jspecview_common_PlotWidget.apply(this, [pw]);
return;
}var is2D=p$1.is2dClick$I$I.apply(this, [xPixel, yPixel]);
if (clickCount == 2 && this.iSpectrumClicked == -1  && this.iPreviousSpectrumClicked >= 0 ) {
p$1.setSpectrumClicked$I.apply(this, [this.iPreviousSpectrumClicked]);
}if (!is2D && isControlDown ) {
p$1.setSpectrumClicked$I.apply(this, [this.iPreviousSpectrumClicked]);
if (this.pendingMeasurement != null ) {
p$1.processPendingMeasurement$I$I$I.apply(this, [xPixel, yPixel, -3]);
} else if (this.iSpectrumClicked >= 0) {
p$1.processPendingMeasurement$I$I$I.apply(this, [xPixel, yPixel, 3]);
}return;
}this.lastXMax=NaN;
if (clickCount == 2) {
if (is2D) {
if (this.sticky2Dcursor) {
p$1.addAnnotation$jspecview_common_Annotation$Z.apply(this, [p$1.getAnnotation$D$D$S$Z$Z$I$I.apply(this, [this.imageView.toX$I(xPixel), this.imageView.toSubspectrumIndex$I(yPixel), this.pd.coordStr, false, true, 5, 5]), true]);
}this.sticky2Dcursor=true;
this.set2DCrossHairs$I$I(xPixel, yPixel);
return;
}if (p$1.isInTopBar$I$I.apply(this, [xPixel, yPixel])) {
this.doZoom$D$D$D$D$Z$Z$Z$Z$Z(p$1.toX0$I.apply(this, [this.xPixel0]), 0, p$1.toX0$I.apply(this, [this.xPixel1]), 0, true, false, false, true, true);
} else if (p$1.isInRightBar$I$I.apply(this, [xPixel, yPixel])) {
this.doZoom$D$D$D$D$Z$Z$Z$Z$Z(this.getScale$().minXOnScale, this.viewList.get$I(0).getScale$().minYOnScale, this.getScale$().maxXOnScale, this.viewList.get$I(0).getScale$().maxYOnScale, true, true, false, false, false);
} else if (p$1.isInTopBar2D$I$I.apply(this, [xPixel, yPixel])) {
p$1.reset2D$Z.apply(this, [true]);
} else if (p$1.isInRightBar2D$I$I.apply(this, [xPixel, yPixel])) {
p$1.reset2D$Z.apply(this, [false]);
} else if (this.pendingMeasurement != null ) {
p$1.processPendingMeasurement$I$I$I.apply(this, [xPixel, yPixel, -2]);
} else if (this.iSpectrumClicked >= 0) {
p$1.processPendingMeasurement$I$I$I.apply(this, [xPixel, yPixel, 2]);
}return;
}if (is2D) {
if (this.annotations != null ) {
var xy=Clazz.new_($I$(3,1)).set$D$D(this.imageView.toX$I(xPixel), this.imageView.toSubspectrumIndex$I(yPixel));
var a=p$1.findAnnotation2D$jspecview_common_Coordinate.apply(this, [xy]);
if (a != null  && p$1.setAnnotationText$jspecview_common_Annotation.apply(this, [a]) ) {
return;
}}if (clickCount == 1) this.sticky2Dcursor=false;
this.set2DCrossHairs$I$I(xPixel, yPixel);
return;
}if (p$1.isInPlotRegion$I$I.apply(this, [xPixel, yPixel])) {
if (this.selectedSpectrumIntegrals != null  && p$1.checkIntegralNormalizationClick$I$I.apply(this, [xPixel, yPixel]) ) return;
if (this.pendingMeasurement != null ) {
p$1.processPendingMeasurement$I$I$I.apply(this, [xPixel, yPixel, 1]);
return;
}p$1.setCoordClicked$I$D$D.apply(this, [xPixel, this.toX$I(xPixel), this.toY$I(yPixel)]);
p$1.updateDialog$jspecview_common_Annotation_AType$I.apply(this, [$I$(5).PeakList, -1]);
if (isNextClick != null ) {
this.nextClickForSetPeak=isNextClick;
this.shiftSpectrum$I$D$D(4, NaN, NaN);
this.nextClickForSetPeak=null;
return;
}} else {
p$1.setCoordClicked$I$D$D.apply(this, [0, NaN, 0]);
}this.pd.notifyPeakPickedListeners$jspecview_common_PeakPickEvent(null);
});

Clazz.newMeth(C$, 'is2dClick$I$I',  function (xPixel, yPixel) {
return (this.imageView != null  && xPixel == this.imageView.fixX$I(xPixel)  && yPixel == this.fixY$I(yPixel) );
}, p$1);

Clazz.newMeth(C$, 'updateDialog$jspecview_common_Annotation_AType$I',  function (type, iSpec) {
var ad=this.getDialog$jspecview_common_Annotation_AType$I(type, iSpec);
if (ad == null  || !p$1.isVisible$jspecview_api_AnnotationData.apply(this, [ad]) ) return;
var xRange=this.toX$I(this.xPixel1) - this.toX$I(this.xPixel0);
var yOffset=(this.getSpectrum$().isInverted$() ? this.yPixel1 - this.pd.mouseY : this.pd.mouseY - this.yPixel0);
(ad).update$jspecview_common_Coordinate$D$I(this.pd.coordClicked, xRange, yOffset);
}, p$1);

Clazz.newMeth(C$, 'isVisible$jspecview_api_AnnotationData',  function (ad) {
return (Clazz.instanceOf(ad, "jspecview.dialog.JSVDialog") && ad.isVisible$() );
}, p$1);

Clazz.newMeth(C$, 'mousePressedEvent$I$I$I',  function (xPixel, yPixel, clickCount) {
this.checkWidgetEvent$I$I$Z(xPixel, yPixel, true);
});

Clazz.newMeth(C$, 'mouseReleasedEvent$I$I',  function (xPixel, yPixel) {
if (this.pendingMeasurement != null ) {
if (Math.abs(this.toPixelX$D(this.pendingMeasurement.getXVal$()) - xPixel) < 2) this.pendingMeasurement=null;
p$1.processPendingMeasurement$I$I$I.apply(this, [xPixel, yPixel, -2]);
p$1.setToolTipForPixels$I$I.apply(this, [xPixel, yPixel]);
return;
}if (this.pd.integralShiftMode != 0) {
this.pd.integralShiftMode=0;
this.zoomBox1D.xPixel1=this.zoomBox1D.xPixel0;
return;
}if (this.iSpectrumMovedTo >= 0) this.setScale$I(this.iSpectrumMovedTo);
var thisWidget=this.pd.thisWidget;
if (this.pd.isIntegralDrag) {
if (C$.isGoodEvent$jspecview_common_PlotWidget$jspecview_common_PlotWidget$Z(this.zoomBox1D, null, true)) {
p$1.checkIntegral$D$D$Z.apply(this, [this.toX$I(this.zoomBox1D.xPixel0), this.toX$I(this.zoomBox1D.xPixel1), true]);
}this.zoomBox1D.xPixel1=this.zoomBox1D.xPixel0=0;
this.pendingIntegral=null;
this.pd.isIntegralDrag=false;
} else if (thisWidget === this.zoomBox2D ) {
if (!C$.isGoodEvent$jspecview_common_PlotWidget$jspecview_common_PlotWidget$Z(this.zoomBox2D, null, true)) return;
this.imageView.setZoom$I$I$I$I(this.zoomBox2D.xPixel0, this.zoomBox2D.yPixel0, this.zoomBox2D.xPixel1, this.zoomBox2D.yPixel1);
this.zoomBox2D.xPixel1=this.zoomBox2D.xPixel0;
this.doZoom$D$D$D$D$Z$Z$Z$Z$Z(this.imageView.toX$I(this.imageView.xPixel0), this.getScale$().minY, this.imageView.toX$I(this.imageView.xPixel0 + this.imageView.xPixels - 1), this.getScale$().maxY, false, false, false, true, true);
} else if (thisWidget === this.zoomBox1D ) {
if (!C$.isGoodEvent$jspecview_common_PlotWidget$jspecview_common_PlotWidget$Z(this.zoomBox1D, null, true)) return;
var x1=this.zoomBox1D.xPixel1;
var doY=(this.pd.shiftPressed);
this.doZoom$D$D$D$D$Z$Z$Z$Z$Z(this.toX$I(this.zoomBox1D.xPixel0), (doY ? this.toY$I(this.zoomBox1D.yPixel0) : 0), this.toX$I(x1), (doY ? this.toY$I(this.zoomBox1D.yPixel1) : 0), true, doY, true, true, true);
this.zoomBox1D.xPixel1=this.zoomBox1D.xPixel0;
} else if (thisWidget === this.pin1Dx0  || thisWidget === this.pin1Dx1   || thisWidget === this.cur2Dx0   || thisWidget === this.cur2Dx1  ) {
p$1.addCurrentZoom.apply(this, []);
}});

Clazz.newMeth(C$, 'mouseMovedEvent$I$I',  function (xPixel, yPixel) {
if (this.nSpectra > 1) {
var iFrame=this.getSplitPoint$I(yPixel);
p$1.setPositionForFrame$I.apply(this, [iFrame]);
p$1.setSpectrumMovedTo$I.apply(this, [this.nSplit > 1 ? iFrame : this.iSpectrumSelected]);
if (this.iSpectrumMovedTo >= 0) this.setScale$I(this.iSpectrumMovedTo);
}this.inPlotMove=p$1.isInPlotRegion$I$I.apply(this, [xPixel, yPixel]);
this.setXPixelMovedTo$D$D$I$I(1.7976931348623157E308, 1.7976931348623157E308, (this.inPlotMove ? xPixel : -1), -1);
if (this.inPlotMove) {
this.xValueMovedTo=this.toX$I(this.xPixelMovedTo);
this.yValueMovedTo=this.getSpectrum$().getYValueAt$D(this.xValueMovedTo);
}if (this.pd.integralShiftMode != 0) {
var ad=this.getDialog$jspecview_common_Annotation_AType$I($I$(5).Integration, -1);
var xy=(ad.getData$()).getXYCoords$();
var y=xy[this.pd.integralShiftMode > 0 ? xy.length - 1 : 0].getYVal$();
(ad.getData$()).shiftY$I$I$I$I(this.pd.integralShiftMode, p$1.toPixelYint$D.apply(this, [y]) + yPixel - (this.pd.integralShiftMode > 0 ? this.yPixelPlot1 : this.yPixelPlot0), this.yPixel0, this.yPixels);
} else if (this.pd.isIntegralDrag) {
} else if (this.pendingMeasurement != null ) {
p$1.processPendingMeasurement$I$I$I.apply(this, [xPixel, yPixel, 0]);
p$1.setToolTipForPixels$I$I.apply(this, [xPixel, yPixel]);
} else {
this.selectedMeasurement=(this.inPlotMove && this.selectedSpectrumMeasurements != null   ? p$1.findMeasurement$jspecview_common_MeasurementData$I$I$I.apply(this, [this.selectedSpectrumMeasurements, xPixel, yPixel, 0]) : null);
this.selectedIntegral=null;
if (this.inPlotMove && this.selectedSpectrumIntegrals != null   && this.selectedMeasurement == null  ) {
this.selectedIntegral=p$1.findMeasurement$jspecview_common_MeasurementData$I$I$I.apply(this, [this.selectedSpectrumIntegrals, xPixel, yPixel, 0]);
if (this.selectedIntegral == null ) this.selectedIntegral=p$1.findMeasurement$jspecview_common_MeasurementData$I$I$I.apply(this, [this.selectedSpectrumIntegrals, xPixel, yPixel, -5]);
}p$1.setToolTipForPixels$I$I.apply(this, [xPixel, yPixel]);
if (this.imageView == null ) {
this.piMouseOver=null;
var iSpec=(this.nSplit > 1 ? this.iSpectrumMovedTo : this.iSpectrumClicked);
if (!p$1.isDrawNoSpectra.apply(this, []) && iSpec >= 0 ) {
var spec=this.spectra.get$I(iSpec);
if (spec.getPeakList$() != null ) {
this.coordTemp.setXVal$D(this.toX$I(xPixel));
this.coordTemp.setYVal$D(this.toY$I(yPixel));
this.piMouseOver=spec.findPeakByCoord$I$jspecview_common_Coordinate(xPixel, this.coordTemp);
}}} else {
if (!this.pd.display1D && this.sticky2Dcursor ) {
this.set2DCrossHairs$I$I(xPixel, yPixel);
}}}});

Clazz.newMeth(C$, 'nextView$',  function () {
if (this.currentZoomIndex + 1 < this.viewList.size$()) p$1.setZoomTo$I.apply(this, [this.currentZoomIndex + 1]);
});

Clazz.newMeth(C$, 'previousView$',  function () {
if (this.currentZoomIndex > 0) p$1.setZoomTo$I.apply(this, [this.currentZoomIndex - 1]);
});

Clazz.newMeth(C$, 'resetView$',  function () {
p$1.setZoomTo$I.apply(this, [0]);
});

Clazz.newMeth(C$, 'removeAllHighlights$',  function () {
p$1.removeAllHighlights$jspecview_common_Spectrum.apply(this, [null]);
});

Clazz.newMeth(C$, 'removeHighlight$I',  function (index) {
this.highlights.removeItemAt$I(index);
});

Clazz.newMeth(C$, 'removeHighlight$D$D',  function (x1, x2) {
for (var i=this.highlights.size$(); --i >= 0; ) {
var h=this.highlights.get$I(i);
if (h.x1 == x1  && h.x2 == x2  ) this.highlights.removeItemAt$I(i);
}
});

Clazz.newMeth(C$, 'scaleYBy$D',  function (factor) {
if (this.imageView == null  && !this.zoomEnabled ) return;
this.viewData.scaleSpectrum$I$D(this.imageView == null  ? this.iSpectrumSelected : -2, factor);
if (this.imageView != null ) {
p$1.update2dImage$Z.apply(this, [false]);
p$1.resetPinsFromView.apply(this, []);
}this.pd.refresh$();
});

Clazz.newMeth(C$, 'selectSpectrum$S$S$S',  function (filePath, type, model) {
var haveFound=false;
for (var i=this.spectra.size$(); --i >= 0; ) if ((filePath == null  || this.getSpectrumAt$I(i).getFilePathForwardSlash$().equals$O(filePath) ) && (this.getSpectrumAt$I(i).matchesPeakTypeModel$S$S(type, model)) ) {
p$1.setSpectrumSelected$I.apply(this, [i]);
if (this.nSplit > 1) this.splitStack$Z(true);
haveFound=true;
}
if (this.nSpectra > 1 && !haveFound  && this.iSpectrumSelected >= 0  && !this.pd.isCurrentGraphSet$jspecview_common_GraphSet(this) ) p$1.setSpectrumSelected$I.apply(this, [-2147483648]);
return haveFound;
});

Clazz.newMeth(C$, 'selectPeakByFileIndex$S$S$S',  function (filePath, index, atomKey) {
var pi;
for (var i=this.spectra.size$(); --i >= 0; ) if ((pi=this.getSpectrumAt$I(i).selectPeakByFileIndex$S$S$S(filePath, index, atomKey)) != null ) return pi;

return null;
});

Clazz.newMeth(C$, 'setSelected$I',  function (i) {
if (i < 0) {
this.bsSelected.clearAll$();
p$1.setSpectrumClicked$I.apply(this, [-1]);
return;
}this.bsSelected.set$I(i);
p$1.setSpectrumClicked$I.apply(this, [(this.bsSelected.cardinality$() == 1 ? i : -1)]);
if (this.nSplit > 1 && i >= 0 ) this.pd.currentSplitPoint=i;
});

Clazz.newMeth(C$, 'setSelectedIntegral$D',  function (val) {
var spec=this.selectedIntegral.getSpectrum$();
this.getIntegrationGraph$I(this.getSpectrumIndex$jspecview_common_Spectrum(spec)).setSelectedIntegral$jspecview_common_Measurement$D(this.selectedIntegral, val);
});

Clazz.newMeth(C$, 'setShowAnnotation$jspecview_common_Annotation_AType$Boolean',  function (type, tfToggle) {
var id=this.getDialog$jspecview_common_Annotation_AType$I(type, -1);
if (id == null ) {
if (tfToggle != null  && tfToggle !== Boolean.TRUE  ) return;
if (type === $I$(5).PeakList  || type === $I$(5).Integration   || type === $I$(5).Measurements  ) this.pd.showDialog$jspecview_common_Annotation_AType(type);
return;
}if (tfToggle == null ) {
if (Clazz.instanceOf(id, "jspecview.dialog.JSVDialog")) (id).setVisible$Z(!(id).isVisible$());
 else this.pd.showDialog$jspecview_common_Annotation_AType(type);
return;
}var isON=tfToggle.booleanValue$();
if (isON) id.setState$Z(isON);
if (isON || Clazz.instanceOf(id, "jspecview.dialog.JSVDialog") ) this.pd.showDialog$jspecview_common_Annotation_AType(type);
if (!isON && Clazz.instanceOf(id, "jspecview.dialog.JSVDialog") ) (id).setVisible$Z(false);
});

Clazz.newMeth(C$, 'checkIntegralParams$jspecview_common_Parameters$S',  function (parameters, value) {
var spec=this.getSpectrum$();
if (!spec.canIntegrate$() || this.reversePlot ) return false;
var iSpec=p$1.getFixedSelectedSpectrumIndex.apply(this, []);
var ad=this.getDialog$jspecview_common_Annotation_AType$I($I$(5).Integration, -1);
if (value == null ) return true;
switch ($I$(19,"getMode$S",[value.toUpperCase$()])) {
case $I$(19).NA:
return false;
case $I$(19).CLEAR:
this.integrate$I$jspecview_common_Parameters(iSpec, null);
this.integrate$I$jspecview_common_Parameters(iSpec, parameters);
break;
case $I$(19).ON:
if (ad == null ) this.integrate$I$jspecview_common_Parameters(iSpec, parameters);
 else ad.setState$Z(true);
break;
case $I$(19).OFF:
if (ad != null ) ad.setState$Z(false);
break;
case $I$(19).TOGGLE:
if (ad == null ) this.integrate$I$jspecview_common_Parameters(iSpec, parameters);
 else ad.setState$Z(!ad.getState$());
break;
case $I$(19).AUTO:
if (ad == null ) {
this.checkIntegralParams$jspecview_common_Parameters$S(parameters, "ON");
ad=this.getDialog$jspecview_common_Annotation_AType$I($I$(5).Integration, -1);
}if (ad != null ) (ad.getData$()).autoIntegrate$();
break;
case $I$(19).LIST:
this.pd.showDialog$jspecview_common_Annotation_AType($I$(5).Integration);
break;
case $I$(19).MARK:
if (ad == null ) {
this.checkIntegralParams$jspecview_common_Parameters$S(parameters, "ON");
ad=this.getDialog$jspecview_common_Annotation_AType$I($I$(5).Integration, -1);
}if (ad != null ) (ad.getData$()).addMarks$S(value.substring$I(4).trim$());
break;
case $I$(19).MIN:
if (ad != null ) {
try {
var val=Double.parseDouble$S($I$(13).getTokens$S(value).get$I(1));
(ad.getData$()).setMinimumIntegral$D(val);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}break;
case $I$(19).UPDATE:
if (ad != null ) (ad.getData$()).update$jspecview_common_Parameters(parameters);
}
p$1.updateDialog$jspecview_common_Annotation_AType$I.apply(this, [$I$(5).Integration, -1]);
return true;
});

Clazz.newMeth(C$, 'setSpectrum$I$Z',  function (iSpec, fromSplit) {
if (fromSplit && this.nSplit > 1 ) {
if (this.nSplit > 1) p$1.setSpectrumClicked$I.apply(this, [iSpec]);
} else {
p$1.setSpectrumClicked$I.apply(this, [iSpec]);
this.stackSelected=false;
this.showAllStacked=false;
}if (iSpec >= 0) this.dialogsToFront$jspecview_common_Spectrum(this.getSpectrum$());
});

Clazz.newMeth(C$, 'setSpectrumJDX$jspecview_common_Spectrum',  function (spec) {
var pt=p$1.getFixedSelectedSpectrumIndex.apply(this, []);
this.spectra.removeItemAt$I(pt);
this.spectra.add$I$O(pt, spec);
this.pendingMeasurement=null;
this.clearViews$();
this.viewData.newSpectrum$javajs_util_Lst(this.spectra);
});

Clazz.newMeth(C$, 'setZoom$D$D$D$D',  function (x1, y1, x2, y2) {
p$1.setZoomTo$I.apply(this, [0]);
if (x1 == 0  && x2 == 0   && y1 == 0   && y2 == 0  ) {
p$1.newPins.apply(this, []);
this.imageView=null;
x1=this.getScale$().minXOnScale;
x2=this.getScale$().maxXOnScale;
} else {
this.doZoom$D$D$D$D$Z$Z$Z$Z$Z(x1, y1, x2, y2, true, (y1 != y2 ), false, true, true);
}});

Clazz.newMeth(C$, 'shiftSpectrum$I$D$D',  function (mode, xOld, xNew) {
var spec=this.getSpectrum$();
if (!spec.isNMR$() || !spec.is1D$() ) return false;
var ok=null;
var dx=0;
if (xNew == 1.7976931348623157E308 ) {
dx=-spec.addSpecShift$D(0);
} else {
switch (mode) {
case 3:
dx=xNew;
break;
case 1:
case 2:
this.nextClickMode=mode;
if (Double.isNaN$D(xOld)) {
ok=this.pd.getInput$S$S$S("Click on " + (mode == 1 ? "or beside a peak to set its chemical shift" : "the spectrum set the chemical shift at that point") + (xNew == -2147483648  ? "" : " to " + new Double(xNew).toString()) + "." , "Set Reference " + (mode == 1 ? "for Peak" : "at Point"), "OK");
this.nextClickForSetPeak=("OK".equals$O(ok) ? Double.valueOf$D(xNew) : null);
return false;
}this.nextClickForSetPeak=null;
case 4:
if (this.nextClickForSetPeak != null ) {
xNew=this.nextClickForSetPeak.doubleValue$();
this.nextClickForSetPeak=null;
}if (Double.isNaN$D(xOld)) xOld=this.lastClickX;
if (this.nextClickMode == 1) xOld=p$1.getNearestPeak$jspecview_common_Spectrum$D$D.apply(this, [spec, xOld, this.toY$I(this.pd.mouseY)]);
if (Double.isNaN$D(xNew)) try {
var s=this.pd.getInput$S$S$S("New chemical shift (set blank to reset)", "Set Reference", $I$(14,"formatDecimalDbl$D$I",[xOld, this.getScale$().precision[0]])).trim$();
if (s.length$() == 0) xNew=xOld - spec.addSpecShift$D(0);
 else xNew=Double.parseDouble$S(s);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return false;
} else {
throw e;
}
}
dx=xNew - xOld;
break;
}
}if (dx == 0 ) return false;
spec.addSpecShift$D(dx);
if (this.annotations != null ) for (var i=this.annotations.size$(); --i >= 0; ) if (this.annotations.get$I(i).spec === spec ) this.annotations.get$I(i).addSpecShift$D(dx);

if (this.dialogs != null ) for (var e, $e = this.dialogs.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) if (e.getValue$().getSpectrum$() === spec ) e.getValue$().setSpecShift$D(dx);

this.getScale$().addSpecShift$D(dx);
if (!Double.isNaN$D(this.lastClickX)) this.lastClickX+=dx;
p$1.updateDialogs.apply(this, []);
this.doZoom$D$D$D$D$Z$Z$Z$Z$Z(0, this.getScale$().minYOnScale, 0, this.getScale$().maxYOnScale, true, true, false, true, false);
this.pd.setTaintedAll$();
this.pd.repaint$();
return true;
});

Clazz.newMeth(C$, 'toPeak$I',  function (istep) {
istep*=(this.drawXAxisLeftToRight ? 1 : -1);
if (Double.isNaN$D(this.lastClickX)) this.lastClickX=this.lastPixelX=0;
var spec=this.getSpectrum$();
var coord=p$1.setCoordClicked$I$D$D.apply(this, [this.lastPixelX, this.lastClickX, 0]);
var iPeak=spec.setNextPeak$jspecview_common_Coordinate$I(coord, istep);
if (iPeak < 0) return;
var peak=spec.getPeakList$().get$I(iPeak);
spec.setSelectedPeak$jspecview_common_PeakInfo(peak);
p$1.setCoordClicked$I$D$D.apply(this, [peak.getXPixel$(), peak.getX$(), 0]);
this.pd.notifyPeakPickedListeners$jspecview_common_PeakPickEvent(Clazz.new_($I$(20,1).c$$O$jspecview_common_Coordinate$jspecview_common_PeakInfo,[this.jsvp, this.pd.coordClicked, peak]));
});

Clazz.newMeth(C$, 'scaleSelectedBy$D',  function (f) {
for (var i=this.bsSelected.nextSetBit$I(0); i >= 0; i=this.bsSelected.nextSetBit$I(i + 1)) this.viewData.scaleSpectrum$I$D(i, f);

});

Clazz.newMeth(C$, 'toString',  function () {
return "gs: " + this.nSpectra + " " + this.spectra + " " + this.spectra.get$I(0).getFilePath$() ;
});

Clazz.newMeth(C$, 'setXPointer$jspecview_common_Spectrum$D',  function (spec, x) {
if (spec != null ) p$1.setSpectrumClicked$I.apply(this, [this.getSpectrumIndex$jspecview_common_Spectrum(spec)]);
this.xValueMovedTo=this.lastClickX=x;
this.lastPixelX=this.toPixelX$D(x);
this.setXPixelMovedTo$D$D$I$I(x, 1.7976931348623157E308, 0, 0);
this.yValueMovedTo=NaN;
});

Clazz.newMeth(C$, 'setXPointer2$jspecview_common_Spectrum$D',  function (spec, x) {
if (spec != null ) p$1.setSpectrumClicked$I.apply(this, [this.getSpectrumIndex$jspecview_common_Spectrum(spec)]);
this.setXPixelMovedTo$D$D$I$I(1.7976931348623157E308, x, 0, 0);
});

Clazz.newMeth(C$, 'hasCurrentMeasurement$jspecview_common_Annotation_AType',  function (type) {
return ((type === $I$(5).Integration  ? this.selectedSpectrumIntegrals : this.selectedSpectrumMeasurements) != null );
});

Clazz.newMeth(C$, 'getDialog$jspecview_common_Annotation_AType$I',  function (type, iSpec) {
if (iSpec == -1) iSpec=this.getCurrentSpectrumIndex$();
return (this.dialogs == null  || iSpec < 0  ? null : this.dialogs.get$O(type + "_" + iSpec ));
});

Clazz.newMeth(C$, 'removeDialog$I$jspecview_common_Annotation_AType',  function (iSpec, type) {
if (this.dialogs != null  && iSpec >= 0 ) this.dialogs.remove$O(type + "_" + iSpec );
});

Clazz.newMeth(C$, 'addDialog$I$jspecview_common_Annotation_AType$jspecview_api_AnnotationData',  function (iSpec, type, dialog) {
if (this.dialogs == null ) this.dialogs=Clazz.new_($I$(4,1));
var key=type + "_" + iSpec ;
dialog.setGraphSetKey$S(key);
this.dialogs.put$O$O(key, dialog);
return dialog;
});

Clazz.newMeth(C$, 'removeDialog$jspecview_dialog_JSVDialog',  function (dialog) {
var key=dialog.getGraphSetKey$();
this.dialogs.remove$O(key);
var data=dialog.getData$();
if (data != null ) this.dialogs.put$O$O(key, data);
});

Clazz.newMeth(C$, 'getPeakListing$I$jspecview_common_Parameters$Z',  function (iSpec, p, forceNew) {
if (iSpec < 0) iSpec=this.getCurrentSpectrumIndex$();
if (iSpec < 0) return null;
var dialog=this.getDialog$jspecview_common_Annotation_AType$I($I$(5).PeakList, -1);
if (dialog == null ) {
if (!forceNew) return null;
this.addDialog$I$jspecview_common_Annotation_AType$jspecview_api_AnnotationData(iSpec, $I$(5).PeakList, dialog=Clazz.new_([$I$(5).PeakList, this.getSpectrum$()],$I$(21,1).c$$jspecview_common_Annotation_AType$jspecview_common_Spectrum));
}(dialog.getData$()).setPeakList$jspecview_common_Parameters$I$jspecview_common_ScaleData(p, -2147483648, this.viewData.getScale$());
if (Clazz.instanceOf(dialog, "jspecview.dialog.JSVDialog")) (dialog).setFields$();
return dialog.getData$();
});

Clazz.newMeth(C$, 'setPeakListing$Boolean',  function (tfToggle) {
var dialog=this.getDialog$jspecview_common_Annotation_AType$I($I$(5).PeakList, -1);
var ad=(Clazz.instanceOf(dialog, "jspecview.dialog.JSVDialog") ? dialog : null);
var isON=(tfToggle == null  ? ad == null  || !ad.isVisible$()  : tfToggle.booleanValue$());
if (isON) {
this.pd.showDialog$jspecview_common_Annotation_AType($I$(5).PeakList);
} else {
if (Clazz.instanceOf(dialog, "jspecview.dialog.JSVDialog")) (dialog).setVisible$Z(false);
}});

Clazz.newMeth(C$, 'haveIntegralDisplayed$I',  function (i) {
var ad=this.getDialog$jspecview_common_Annotation_AType$I($I$(5).Integration, i);
return (ad != null  && ad.getState$() );
});

Clazz.newMeth(C$, 'getIntegrationGraph$I',  function (i) {
var ad=this.getDialog$jspecview_common_Annotation_AType$I($I$(5).Integration, i);
return (ad == null  ? null : ad.getData$());
});

Clazz.newMeth(C$, 'setIntegrationRatios$S',  function (value) {
var iSpec=p$1.getFixedSelectedSpectrumIndex.apply(this, []);
if (this.aIntegrationRatios == null ) this.aIntegrationRatios=Clazz.array(java.lang.Object, [this.nSpectra]);
this.aIntegrationRatios[iSpec]=$I$(22,"getIntegrationRatiosFromString$jspecview_common_Spectrum$S",[this.getSpectrum$(), value]);
});

Clazz.newMeth(C$, 'getIntegrationRatios$I',  function (i) {
return (this.aIntegrationRatios == null  ? null : this.aIntegrationRatios[i]);
});

Clazz.newMeth(C$, 'integrate$I$jspecview_common_Parameters',  function (iSpec, parameters) {
var spec=this.getSpectrumAt$I(iSpec);
if (parameters == null  || !spec.canIntegrate$() ) {
this.removeDialog$I$jspecview_common_Annotation_AType(iSpec, $I$(5).Integration);
return false;
}this.addDialog$I$jspecview_common_Annotation_AType$jspecview_api_AnnotationData(iSpec, $I$(5).Integration, Clazz.new_($I$(22,1).c$$jspecview_common_Spectrum$jspecview_common_Parameters,[spec, parameters]));
return true;
});

Clazz.newMeth(C$, 'getIntegration$I$jspecview_common_Parameters$Z',  function (iSpec, p, forceNew) {
if (iSpec < 0) iSpec=this.getCurrentSpectrumIndex$();
if (iSpec < 0) return null;
var dialog=this.getDialog$jspecview_common_Annotation_AType$I($I$(5).Integration, -1);
if (dialog == null ) {
if (!forceNew) return null;
dialog=this.addDialog$I$jspecview_common_Annotation_AType$jspecview_api_AnnotationData(iSpec, $I$(5).Integration, Clazz.new_([this.getSpectrum$(), p],$I$(22,1).c$$jspecview_common_Spectrum$jspecview_common_Parameters));
}return dialog.getData$();
});

Clazz.newMeth(C$, 'getMeasurementInfo$jspecview_common_Annotation_AType$I',  function (type, iSpec) {
var md;
switch (type) {
case $I$(5).PeakList:
md=this.getPeakListing$I$jspecview_common_Parameters$Z(iSpec, null, false);
break;
case $I$(5).Integration:
md=this.getIntegration$I$jspecview_common_Parameters$Z(iSpec, null, false);
break;
default:
return null;
}
if (md == null ) return null;
var info=Clazz.new_($I$(4,1));
md.getInfo$java_util_Map(info);
return info;
});

Clazz.newMeth(C$, 'getInfo$S$I',  function (key, iSpec) {
var spectraInfo=Clazz.new_($I$(4,1));
if ("".equals$O(key)) {
spectraInfo.put$O$O("KEYS", "viewInfo spectra");
} else if ("viewInfo".equalsIgnoreCase$S(key)) return this.getScale$().getInfo$java_util_Map(spectraInfo);
var specInfo=Clazz.new_($I$(1,1));
spectraInfo.put$O$O("spectra", specInfo);
for (var i=0; i < this.nSpectra; i++) {
if (iSpec >= 0 && i != iSpec ) continue;
var spec=this.spectra.get$I(i);
var info=spec.getInfo$S(key);
if (iSpec >= 0 && key != null   && (info.size$() == 2 || key.equalsIgnoreCase$S("id") ) ) {
if (info.size$() == 2) info.remove$O("id");
return info;
}$I$(23,"putInfo$S$java_util_Map$S$O",[key, info, "type", spec.getDataType$()]);
$I$(23,"putInfo$S$java_util_Map$S$O",[key, info, "titleLabel", spec.getTitleLabel$()]);
$I$(23,"putInfo$S$java_util_Map$S$O",[key, info, "filePath", spec.getFilePath$().replace$C$C("\\", "/")]);
$I$(23,"putInfo$S$java_util_Map$S$O",[key, info, "PeakList", ($I$(23).isMatch$S$S(key, "PeakList") ? this.getMeasurementInfo$jspecview_common_Annotation_AType$I($I$(5).PeakList, i) : null)]);
$I$(23,"putInfo$S$java_util_Map$S$O",[key, info, "Integration", ($I$(23).isMatch$S$S(key, "Integration") ? this.getMeasurementInfo$jspecview_common_Annotation_AType$I($I$(5).Integration, i) : null)]);
if (iSpec >= 0) return info;
specInfo.addLast$O(info);
}
return spectraInfo;
});

Clazz.newMeth(C$, 'getTitle$Z',  function (forPrinting) {
return (this.nSpectra == 1 || this.iSpectrumSelected >= 0 && (!forPrinting || this.nSplit == 1 )   ? this.getSpectrum$().getTitle$() : null);
});

Clazz.newMeth(C$, 'getCurrentView$',  function () {
this.setScale$I(p$1.getFixedSelectedSpectrumIndex.apply(this, []));
return this.viewData.getScale$();
});

Clazz.newMeth(C$, 'set2DXY$D$D$Z',  function (x, y, isLocked) {
var p;
if (this.gs2dLinkedX != null ) {
p=this.toPixelX$D(x);
if (p != this.fixX$I(p)) {
p=-2147483648;
x=1.7976931348623157E308;
}this.cur1D2x1.setX$D$I(x, p);
}if (this.gs2dLinkedY != null ) {
p=this.toPixelX$D(y);
if (p != this.fixX$I(p)) {
p=-2147483648;
y=1.7976931348623157E308;
}this.cur1D2x2.setX$D$I(y, p);
}this.cur1D2Locked=isLocked;
});

Clazz.newMeth(C$, 'dialogsToFront$jspecview_common_Spectrum',  function (spec) {
if (this.dialogs == null ) return;
if (spec == null ) spec=this.getSpectrum$();
for (var e, $e = this.dialogs.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) {
var ad=e.getValue$();
if (p$1.isVisible$jspecview_api_AnnotationData.apply(this, [ad])) {
if (spec == null ) (ad).setVisible$Z(true);
 else (ad).setFocus$Z(ad.getSpectrum$() === spec );
}}
});

Clazz.newMeth(C$, 'setPlotColors$O',  function (oColors) {
var colors=oColors;
if (colors.length > this.nSpectra) {
var tmpPlotColors=Clazz.array($I$(24), [this.nSpectra]);
System.arraycopy$O$I$O$I$I(colors, 0, tmpPlotColors, 0, this.nSpectra);
colors=tmpPlotColors;
} else if (this.nSpectra > colors.length) {
var tmpPlotColors=Clazz.array($I$(24), [this.nSpectra]);
var numAdditionColors=this.nSpectra - colors.length;
System.arraycopy$O$I$O$I$I(colors, 0, tmpPlotColors, 0, colors.length);
for (var i=0, j=colors.length; i < numAdditionColors; i++, j++) tmpPlotColors[j]=p$1.generateRandomColor.apply(this, []);

colors=tmpPlotColors;
}this.plotColors=colors;
});

Clazz.newMeth(C$, 'disposeImage',  function () {
{
if (this.image2D != null) this.image2D.parentNode.removeChild(this.image2D);
}
this.image2D=null;
this.jsvp=null;
this.pd=null;
this.highlights=null;
this.plotColors=null;
}, p$1);

Clazz.newMeth(C$, 'generateRandomColor',  function () {
while (true){
var red=((Math.random() * 255)|0);
var green=((Math.random() * 255)|0);
var blue=((Math.random() * 255)|0);
var randomColor=this.g2d.getColor3$I$I$I(red, green, blue);
if (randomColor.getRGB$() != 0) return randomColor;
}
}, p$1);

Clazz.newMeth(C$, 'setPlotColor0$O',  function (oColor) {
this.plotColors[0]=oColor;
});

Clazz.newMeth(C$, 'getPlotColor$I',  function (index) {
if (index >= this.plotColors.length) return null;
return this.plotColors[index];
});

Clazz.newMeth(C$, 'setColorFromToken$O$jspecview_common_ScriptToken',  function (og, whatColor) {
if (whatColor != null ) this.g2d.setGraphicsColor$O$javajs_api_GenericColor(og, whatColor === $I$(13).PLOTCOLOR  ? this.plotColors[0] : this.pd.getColor$jspecview_common_ScriptToken(whatColor));
}, p$1);

Clazz.newMeth(C$, 'setPlotColor$O$I',  function (og, i) {
var c;
switch (i) {
case -3:
c=C$.veryLightGrey;
break;
case -2:
c=this.pd.BLACK;
break;
case -1:
c=this.pd.getColor$jspecview_common_ScriptToken($I$(13).INTEGRALPLOTCOLOR);
break;
default:
c=this.plotColors[i];
break;
}
this.g2d.setGraphicsColor$O$javajs_api_GenericColor(og, c);
}, p$1);

Clazz.newMeth(C$, 'draw2DImage',  function () {
if (this.imageView != null ) this.g2d.drawGrayScaleImage$O$O$I$I$I$I$I$I$I$I(this.gMain, this.image2D, this.imageView.xPixel0, this.imageView.yPixel0, this.imageView.xPixel0 + this.imageView.xPixels - 1, this.imageView.yPixel0 + this.imageView.yPixels - 1, this.imageView.xView1, this.imageView.yView1, this.imageView.xView2, this.imageView.yView2);
}, p$1);

Clazz.newMeth(C$, 'get2DImage$jspecview_common_Spectrum',  function (spec0) {
this.imageView=Clazz.new_($I$(25,1));
this.imageView.set$jspecview_common_ScaleData(this.viewList.get$I(0).getScale$());
if (!p$1.update2dImage$Z.apply(this, [true])) return false;
this.imageView.resetZoom$();
this.sticky2Dcursor=true;
return true;
}, p$1);

Clazz.newMeth(C$, 'update2dImage$Z',  function (isCreation) {
this.imageView.set$jspecview_common_ScaleData(this.viewData.getScale$());
var spec=this.getSpectrumAt$I(0);
var buffer=this.imageView.get2dBuffer$jspecview_common_Spectrum$Z(spec, !isCreation);
if (buffer == null ) {
this.image2D=null;
this.imageView=null;
return false;
}if (isCreation) {
buffer=this.imageView.adjustView$jspecview_common_Spectrum$jspecview_common_ViewData(spec, this.viewData);
this.imageView.resetView$();
}this.image2D=this.g2d.newGrayScaleImage$O$O$I$I$IA(this.gMain, this.image2D, this.imageView.imageWidth, this.imageView.imageHeight, buffer);
p$1.setImageWindow.apply(this, []);
return true;
}, p$1);

Clazz.newMeth(C$, 'getAnnotation$D$D$S$Z$Z$I$I',  function (x, y, text, isPixels, is2d, offsetX, offsetY) {
return Clazz.new_($I$(26,1)).setCA$D$D$jspecview_common_Spectrum$S$javajs_api_GenericColor$Z$Z$I$I(x, y, this.getSpectrum$(), text, this.pd.BLACK, isPixels, is2d, offsetX, offsetY);
}, p$1);

Clazz.newMeth(C$, 'getAnnotation$javajs_util_Lst$jspecview_common_Annotation',  function (args, lastAnnotation) {
return $I$(27,"getColoredAnnotation$org_jmol_api_GenericGraphics$jspecview_common_Spectrum$javajs_util_Lst$jspecview_common_Annotation",[this.g2d, this.getSpectrum$(), args, lastAnnotation]);
}, p$1);

Clazz.newMeth(C$, 'fillBox$O$I$I$I$I$jspecview_common_ScriptToken',  function (g, x0, y0, x1, y1, whatColor) {
p$1.setColorFromToken$O$jspecview_common_ScriptToken.apply(this, [g, whatColor]);
this.g2d.fillRect$O$I$I$I$I(g, Math.min(x0, x1), Math.min(y0, y1), Math.abs(x0 - x1), Math.abs(y0 - y1));
}, p$1);

Clazz.newMeth(C$, 'drawBox$O$I$I$I$I$jspecview_common_ScriptToken',  function (g, x0, y0, x1, y1, whatColor) {
p$1.setColorFromToken$O$jspecview_common_ScriptToken.apply(this, [g, whatColor]);
this.g2d.drawRect$O$I$I$I$I(g, Math.min(x0, x1), Math.min(y0, y1), Math.abs(x0 - x1) - 1, Math.abs(y0 - y1) - 1);
}, p$1);

Clazz.newMeth(C$, 'drawHandle$O$I$I$I$Z',  function (g, x, y, size, outlineOnly) {
if (outlineOnly) this.g2d.drawRect$O$I$I$I$I(g, x - size, y - size, size * 2, size * 2);
 else this.g2d.fillRect$O$I$I$I$I(g, x - size, y - size, size * 2 + 1, size * 2 + 1);
}, p$1);

Clazz.newMeth(C$, 'setCurrentBoxColor$O',  function (g) {
this.g2d.setGraphicsColor$O$javajs_api_GenericColor(g, this.pd.BLACK);
}, p$1);

Clazz.newMeth(C$, 'fillArrow$O$I$I$I$Z',  function (g, type, x, y, doFill) {
var f=1;
switch (type) {
case 1:
case 3:
f=-1;
break;
}
var axPoints=Clazz.array(Integer.TYPE, -1, [x - 5, x - 5, x + 5, x + 5, x + 8, x, x - 8]);
var ayPoints=Clazz.array(Integer.TYPE, -1, [y + 5 * f, y - f, y - f, y + 5 * f, y + 5 * f, y + 10 * f, y + 5 * f]);
switch (type) {
case 1:
case 2:
if (doFill) this.g2d.fillPolygon$O$IA$IA$I(g, ayPoints, axPoints, 7);
 else this.g2d.drawPolygon$O$IA$IA$I(g, ayPoints, axPoints, 7);
break;
case 3:
case 4:
if (doFill) this.g2d.fillPolygon$O$IA$IA$I(g, axPoints, ayPoints, 7);
 else this.g2d.drawPolygon$O$IA$IA$I(g, axPoints, ayPoints, 7);
}
}, p$1);

Clazz.newMeth(C$, 'fillCircle$O$I$I$Z',  function (g, x, y, doFill) {
if (doFill) this.g2d.fillCircle$O$I$I$I(g, x - 4, y - 4, 8);
 else this.g2d.drawCircle$O$I$I$I(g, x - 4, y - 4, 8);
}, p$1);

Clazz.newMeth(C$, 'setAnnotationColor$O$jspecview_common_Annotation$jspecview_common_ScriptToken',  function (g, note, whatColor) {
if (whatColor != null ) {
p$1.setColorFromToken$O$jspecview_common_ScriptToken.apply(this, [g, whatColor]);
return;
}var color=null;
if (Clazz.instanceOf(note, "jspecview.common.ColoredAnnotation")) color=(note).getColor$();
if (color == null ) color=this.pd.BLACK;
this.g2d.setGraphicsColor$O$javajs_api_GenericColor(g, color);
});

Clazz.newMeth(C$, 'setSolutionColor$jspecview_api_VisibleInterface$Z$Z',  function (vi, isNone, asFitted) {
for (var i=0; i < this.nSpectra; i++) {
var spec=this.spectra.get$I(i);
var color=(isNone || !spec.canShowSolutionColor$()  ? -1 : vi.getColour$jspecview_common_Spectrum$Z(spec, asFitted));
spec.setFillColor$javajs_api_GenericColor(color == -1 ? null : this.pd.vwr.parameters.getColor1$I(color));
}
});

Clazz.newMeth(C$, 'setIRMode$jspecview_common_Spectrum_IRMode$S',  function (mode, type) {
for (var i=0; i < this.nSpectra; i++) {
var spec=this.spectra.get$I(i);
if (!spec.dataType.equals$O(type)) continue;
var spec2=$I$(15).taConvert$jspecview_common_Spectrum$jspecview_common_Spectrum_IRMode(spec, mode);
if (spec2 !== spec ) this.pd.setSpecForIRMode$jspecview_common_Spectrum(spec2);
}
});

Clazz.newMeth(C$, 'getSpectrumCount$',  function () {
return 0;
});

Clazz.newMeth(C$, 'invertYAxis$',  function () {
this.viewList.get$I(0).init$javajs_util_Lst$D$D$Z(null, 0, 0, this.getSpectrum$().invertYAxis$().isContinuous$());
this.resetViewCompletely$();
});

C$.$static$=function(){C$.$static$=0;
C$.RT2=Math.sqrt(2.0);
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.GraphSet, "Highlight", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['x1','x2'],'O',['color','javajs.api.GenericColor','spectrum','jspecview.common.Spectrum']]]

Clazz.newMeth(C$, 'toString',  function () {
return "highlight " + new Double(this.x1).toString() + " " + new Double(this.x2).toString() + " " + this.spectrum ;
});

Clazz.newMeth(C$, 'c$$D$D$jspecview_common_Spectrum$javajs_api_GenericColor',  function (x1, x2, spec, color) {
;C$.$init$.apply(this);
this.x1=x1;
this.x2=x2;
this.color=color;
this.spectrum=spec;
}, 1);

Clazz.newMeth(C$, 'equals$O',  function (obj) {
if (!(Clazz.instanceOf(obj, "jspecview.common.GraphSet.Highlight"))) return false;
var hl=obj;
return ((hl.x1 == this.x1 ) && (hl.x2 == this.x2 ) );
});

Clazz.newMeth(C$, 'hashCode$',  function () {
return ((this.x1 * 1000 + this.x2 * 1000000)|0);
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:05 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
