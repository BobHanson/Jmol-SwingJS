(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[];
/*e*/var C$=Clazz.newClass(P$, "ExportType", null, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getType$S',  function (type) {
type=type.toUpperCase$();
if (type.equalsIgnoreCase$S("Original...")) return C$.SOURCE;
if (type.startsWith$S("XML")) return C$.AML;
for (var mode, $mode = 0, $$mode = C$.values$(); $mode<$$mode.length&&((mode=($$mode[$mode])),1);$mode++) if (mode.name$().equals$O(type)) return mode;

return C$.UNK;
}, 1);

Clazz.newMeth(C$, 'isExportMode$S',  function (ext) {
return (C$.getType$S(ext) !== C$.UNK );
}, 1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "UNK", 0, []);
Clazz.newEnumConst($vals, C$.c$, "SOURCE", 1, []);
Clazz.newEnumConst($vals, C$.c$, "DIF", 2, []);
Clazz.newEnumConst($vals, C$.c$, "FIX", 3, []);
Clazz.newEnumConst($vals, C$.c$, "SQZ", 4, []);
Clazz.newEnumConst($vals, C$.c$, "PAC", 5, []);
Clazz.newEnumConst($vals, C$.c$, "XY", 6, []);
Clazz.newEnumConst($vals, C$.c$, "DIFDUP", 7, []);
Clazz.newEnumConst($vals, C$.c$, "PNG", 8, []);
Clazz.newEnumConst($vals, C$.c$, "JPG", 9, []);
Clazz.newEnumConst($vals, C$.c$, "SVG", 10, []);
Clazz.newEnumConst($vals, C$.c$, "SVGI", 11, []);
Clazz.newEnumConst($vals, C$.c$, "CML", 12, []);
Clazz.newEnumConst($vals, C$.c$, "AML", 13, []);
Clazz.newEnumConst($vals, C$.c$, "PDF", 14, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:28 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
