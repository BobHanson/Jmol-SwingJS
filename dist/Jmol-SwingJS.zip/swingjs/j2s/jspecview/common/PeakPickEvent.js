(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "PeakPickEvent", null, 'java.util.EventObject');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['coord','jspecview.common.Coordinate','peakInfo','jspecview.common.PeakInfo']]]

Clazz.newMeth(C$, 'c$$O$jspecview_common_Coordinate$jspecview_common_PeakInfo',  function (source, coord, peakInfo) {
;C$.superclazz.c$$O.apply(this,[source]);C$.$init$.apply(this);
this.coord=coord;
this.peakInfo=(peakInfo == null  ? null : peakInfo);
}, 1);

Clazz.newMeth(C$, 'getCoord$',  function () {
return this.coord;
});

Clazz.newMeth(C$, 'getPeakInfo$',  function () {
return this.peakInfo;
});

Clazz.newMeth(C$, 'toString',  function () {
return (this.peakInfo == null  ? null : this.peakInfo.toString());
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:06 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
