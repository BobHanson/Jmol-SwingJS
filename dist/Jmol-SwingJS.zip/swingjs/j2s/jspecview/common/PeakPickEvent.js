(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "PeakPickEvent", null, 'java.util.EventObject');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['coord','jspecview.common.Coordinate','peakInfo','jspecview.common.PeakInfo']]]

Clazz.newMeth(C$, 'c$$O$jspecview_common_Coordinate$jspecview_common_PeakInfo',  function (source, coord, peakInfo) {
;C$.superclazz.c$$O.apply(this,[source]);C$.$init$.apply(this);
this.coord=coord;
this.peakInfo=(peakInfo == null  ? null : peakInfo);
}, 1);

Clazz.newMeth(C$, 'getCoord$',  function () {
return this.coord;
});

Clazz.newMeth(C$, 'getPeakInfo$',  function () {
return this.peakInfo;
});

Clazz.newMeth(C$, 'toString',  function () {
return (this.peakInfo == null  ? null : this.peakInfo.toString());
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:52 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
