(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[[0,'javajs.util.Lst','jspecview.common.Coordinate','org.jmol.util.Logger','jspecview.source.JDXDataObject',['jspecview.common.Spectrum','.IRMode'],'java.util.Hashtable','jspecview.common.Parameters','jspecview.source.JDXSourceStreamTokenizer','jspecview.common.PeakInfo','javajs.util.PT']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Spectrum", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'jspecview.source.JDXDataObject');
C$.$classes$=[['IRMode',25]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.id="";
this.peakList=Clazz.new_($I$(1,1));
this.specShift=0;
this.userYFactor=1;
},1);

C$.$fields$=[['Z',['isForcedSubset','exportXAxisLeftToRight'],'D',['specShift','userYFactor'],'I',['currentSubSpectrumIndex'],'S',['id','peakXLabel','peakYLabel','titleLabel'],'O',['fillColor','javajs.api.GenericColor','subSpectra','javajs.util.Lst','+peakList','selectedPeak','jspecview.common.PeakInfo','+highlightedPeak','convertedSpectrum','jspecview.common.Spectrum']]]

Clazz.newMeth(C$, 'dispose$',  function () {
});

Clazz.newMeth(C$, 'isForcedSubset$',  function () {
return this.isForcedSubset;
});

Clazz.newMeth(C$, 'setId$S',  function (id) {
this.id=id;
});

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.headerTable=Clazz.new_($I$(1,1));
this.xyCoords=Clazz.array($I$(2), [0]);
this.parent=this;
}, 1);

Clazz.newMeth(C$, 'copy$',  function () {
var newSpectrum=Clazz.new_(C$);
this.copyTo$jspecview_source_JDXDataObject(newSpectrum);
newSpectrum.setPeakList$javajs_util_Lst$S$S(this.peakList, this.peakXLabel, null);
newSpectrum.fillColor=this.fillColor;
return newSpectrum;
});

Clazz.newMeth(C$, 'getXYCoords$',  function () {
return this.getCurrentSubSpectrum$().xyCoords;
});

Clazz.newMeth(C$, 'getPeakList$',  function () {
return this.peakList;
});

Clazz.newMeth(C$, 'setPeakList$javajs_util_Lst$S$S',  function (list, peakXLabel, peakYLabel) {
this.peakList=list;
this.peakXLabel=peakXLabel;
this.peakYLabel=peakYLabel;
for (var i=list.size$(); --i >= 0; ) this.peakList.get$I(i).spectrum=this;

if ($I$(3).debugging) $I$(3,"info$S",["Spectrum " + this.getTitle$() + " peaks: " + list.size$() ]);
return list.size$();
});

Clazz.newMeth(C$, 'selectPeakByFileIndex$S$S$S',  function (filePath, index, atomKey) {
if (this.peakList != null  && this.peakList.size$() > 0  && (atomKey == null  || this.sourceID.equals$O(index) ) ) for (var i=0; i < this.peakList.size$(); i++) if (this.peakList.get$I(i).checkFileIndex$S$S$S(filePath, index, atomKey)) {
System.out.println$S("selecting peak by FileIndex " + this + " " + this.peakList.get$I(i) );
return (this.selectedPeak=this.peakList.get$I(i));
}
return null;
});

Clazz.newMeth(C$, 'selectPeakByFilePathTypeModel$S$S$S',  function (filePath, type, model) {
if (this.peakList != null  && this.peakList.size$() > 0 ) for (var i=0; i < this.peakList.size$(); i++) if (this.peakList.get$I(i).checkFileTypeModel$S$S$S(filePath, type, model)) {
System.out.println$S("selecting peak byFilePathTypeModel " + this + " " + this.peakList.get$I(i) );
return (this.selectedPeak=this.peakList.get$I(i));
}
return null;
});

Clazz.newMeth(C$, 'matchesPeakTypeModel$S$S',  function (type, model) {
if (type.equals$O("ID")) return (this.sourceID.equalsIgnoreCase$S(model));
if (this.peakList != null  && this.peakList.size$() > 0 ) for (var i=0; i < this.peakList.size$(); i++) if (this.peakList.get$I(i).checkTypeModel$S$S(type, model)) return true;

return false;
});

Clazz.newMeth(C$, 'setSelectedPeak$jspecview_common_PeakInfo',  function (peak) {
this.selectedPeak=peak;
});

Clazz.newMeth(C$, 'setHighlightedPeak$jspecview_common_PeakInfo',  function (peak) {
this.highlightedPeak=peak;
});

Clazz.newMeth(C$, 'getSelectedPeak$',  function () {
return this.selectedPeak;
});

Clazz.newMeth(C$, 'getModelPeakInfoForAutoSelectOnLoad$',  function () {
if (this.peakList != null ) for (var i=0; i < this.peakList.size$(); i++) if (this.peakList.get$I(i).autoSelectOnLoad$()) return this.peakList.get$I(i);

return null;
});

Clazz.newMeth(C$, 'getAssociatedPeakInfo$I$jspecview_common_Coordinate',  function (xPixel, coord) {
this.selectedPeak=this.findPeakByCoord$I$jspecview_common_Coordinate(xPixel, coord);
return (this.selectedPeak == null  ? this.getBasePeakInfo$() : this.selectedPeak);
});

Clazz.newMeth(C$, 'findPeakByCoord$I$jspecview_common_Coordinate',  function (xPixel, coord) {
if (coord != null  && this.peakList != null   && this.peakList.size$() > 0 ) {
var xVal=coord.getXVal$();
var iBest=-1;
var dBest=1.0E100;
for (var i=0; i < this.peakList.size$(); i++) {
var d=this.peakList.get$I(i).checkRange$I$D(xPixel, xVal);
if (d < dBest ) {
dBest=d;
iBest=i;
}}
if (iBest >= 0) return this.peakList.get$I(iBest);
}return null;
});

Clazz.newMeth(C$, 'getPeakTitle$',  function () {
return (this.selectedPeak != null  ? this.selectedPeak.getTitle$() : this.highlightedPeak != null  ? this.highlightedPeak.getTitle$() : this.getTitleLabel$());
});

Clazz.newMeth(C$, 'getTitleLabel$',  function () {
if (this.titleLabel != null ) return this.titleLabel;
var type=(this.peakList == null  || this.peakList.size$() == 0  ? this.getQualifiedDataType$() : this.peakList.get$I(0).getType$());
if (type != null  && type.startsWith$S("NMR") ) {
if (this.nucleusY != null  && !this.nucleusY.equals$O("?") ) {
type="2D" + type;
} else {
type=$I$(4,"getNominalSpecFreq$S$D",[this.nucleusX, this.getObservedFreq$()]) + " MHz " + this.nucleusX + " " + type ;
}}return this.titleLabel=(type != null  && type.length$() > 0  ? type + " " : "") + this.getTitle$();
});

Clazz.newMeth(C$, 'setNextPeak$jspecview_common_Coordinate$I',  function (coord, istep) {
if (this.peakList == null  || this.peakList.size$() == 0 ) return -1;
var x0=coord.getXVal$() + istep * 1.0E-6;
var ipt1=-1;
var ipt2=-1;
var dmin1=1.7976931348623157E308 * istep;
var dmin2=0;
for (var i=this.peakList.size$(); --i >= 0; ) {
var x=this.peakList.get$I(i).getX$();
if (istep > 0) {
if (x > x0  && x < dmin1  ) {
ipt1=i;
dmin1=x;
} else if (x < x0  && x - x0 < dmin2  ) {
ipt2=i;
dmin2=x - x0;
}} else {
if (x < x0  && x > dmin1  ) {
ipt1=i;
dmin1=x;
} else if (x > x0  && x - x0 > dmin2  ) {
ipt2=i;
dmin2=x - x0;
}}}
if (ipt1 < 0) {
if (ipt2 < 0) return -1;
ipt1=ipt2;
}return ipt1;
});

Clazz.newMeth(C$, 'getPercentYValueAt$D',  function (x) {
if (!this.isContinuous$()) return NaN;
return this.getYValueAt$D(x);
});

Clazz.newMeth(C$, 'getYValueAt$D',  function (x) {
return $I$(2).getYValueAt$jspecview_common_CoordinateA$D(this.xyCoords, x);
});

Clazz.newMeth(C$, 'setUserYFactor$D',  function (userYFactor) {
this.userYFactor=userYFactor;
});

Clazz.newMeth(C$, 'getUserYFactor$',  function () {
return this.userYFactor;
});

Clazz.newMeth(C$, 'getConvertedSpectrum$',  function () {
return this.convertedSpectrum;
});

Clazz.newMeth(C$, 'setConvertedSpectrum$jspecview_common_Spectrum',  function (spectrum) {
this.convertedSpectrum=spectrum;
});

Clazz.newMeth(C$, 'taConvert$jspecview_common_Spectrum$jspecview_common_Spectrum_IRMode',  function (spectrum, mode) {
if (!spectrum.isContinuous$()) return spectrum;
switch (mode) {
case $I$(5).NO_CONVERT:
return spectrum;
case $I$(5).TO_ABS:
if (!spectrum.isTransmittance$()) return spectrum;
break;
case $I$(5).TO_TRANS:
if (!spectrum.isAbsorbance$()) return spectrum;
break;
case $I$(5).TOGGLE:
break;
}
var spec=spectrum.getConvertedSpectrum$();
return (spec != null  ? spec : spectrum.isAbsorbance$() ? C$.toT$jspecview_common_Spectrum(spectrum) : C$.toA$jspecview_common_Spectrum(spectrum));
}, 1);

Clazz.newMeth(C$, 'toT$jspecview_common_Spectrum',  function (spectrum) {
if (!spectrum.isAbsorbance$()) return null;
var xyCoords=spectrum.getXYCoords$();
var newXYCoords=Clazz.array($I$(2), [xyCoords.length]);
if (!$I$(2).isYInRange$jspecview_common_CoordinateA$D$D(xyCoords, 0, 4.0)) xyCoords=$I$(2).normalise$jspecview_common_CoordinateA$D$D(xyCoords, 0, 4.0);
for (var i=0; i < xyCoords.length; i++) newXYCoords[i]=Clazz.new_($I$(2,1)).set$D$D(xyCoords[i].getXVal$(), C$.toTransmittance$D(xyCoords[i].getYVal$()));

return C$.newSpectrum$jspecview_common_Spectrum$jspecview_common_CoordinateA$S(spectrum, newXYCoords, "TRANSMITTANCE");
}, 1);

Clazz.newMeth(C$, 'toA$jspecview_common_Spectrum',  function (spectrum) {
if (!spectrum.isTransmittance$()) return null;
var xyCoords=spectrum.getXYCoords$();
var newXYCoords=Clazz.array($I$(2), [xyCoords.length]);
var isPercent=$I$(2).isYInRange$jspecview_common_CoordinateA$D$D(xyCoords, -2, 2);
for (var i=0; i < xyCoords.length; i++) newXYCoords[i]=Clazz.new_($I$(2,1)).set$D$D(xyCoords[i].getXVal$(), C$.toAbsorbance$D$Z(xyCoords[i].getYVal$(), isPercent));

return C$.newSpectrum$jspecview_common_Spectrum$jspecview_common_CoordinateA$S(spectrum, newXYCoords, "ABSORBANCE");
}, 1);

Clazz.newMeth(C$, 'newSpectrum$jspecview_common_Spectrum$jspecview_common_CoordinateA$S',  function (spectrum, newXYCoords, units) {
var specNew=spectrum.copy$();
specNew.setOrigin$S("JSpecView Converted");
specNew.setOwner$S("JSpecView Generated");
specNew.setXYCoords$jspecview_common_CoordinateA(newXYCoords);
specNew.setYUnits$S(units);
spectrum.setConvertedSpectrum$jspecview_common_Spectrum(specNew);
specNew.setConvertedSpectrum$jspecview_common_Spectrum(spectrum);
return specNew;
}, 1);

Clazz.newMeth(C$, 'toAbsorbance$D$Z',  function (x, isPercent) {
return (Math.min(4.0, isPercent ? 2 - C$.log10$D(x) : -C$.log10$D(x)));
}, 1);

Clazz.newMeth(C$, 'toTransmittance$D',  function (x) {
return (x <= 0  ? 1 : Math.pow(10, -x));
}, 1);

Clazz.newMeth(C$, 'log10$D',  function (value) {
return Math.log(value) / Math.log(10);
}, 1);

Clazz.newMeth(C$, 'process$javajs_util_Lst$jspecview_common_Spectrum_IRMode',  function (specs, irMode) {
if (irMode === $I$(5).TO_ABS  || irMode === $I$(5).TO_TRANS  ) for (var i=0; i < specs.size$(); i++) specs.set$I$O(i, C$.taConvert$jspecview_common_Spectrum$jspecview_common_Spectrum_IRMode(specs.get$I(i), irMode));

return true;
}, 1);

Clazz.newMeth(C$, 'getSubSpectra$',  function () {
return this.subSpectra;
});

Clazz.newMeth(C$, 'getCurrentSubSpectrum$',  function () {
return (this.subSpectra == null  ? this : this.subSpectra.get$I(this.currentSubSpectrumIndex));
});

Clazz.newMeth(C$, 'advanceSubSpectrum$I',  function (dir) {
return this.setCurrentSubSpectrum$I(this.currentSubSpectrumIndex + dir);
});

Clazz.newMeth(C$, 'setCurrentSubSpectrum$I',  function (n) {
return (this.currentSubSpectrumIndex=$I$(2,"intoRange$I$I$I",[n, 0, this.subSpectra.size$() - 1]));
});

Clazz.newMeth(C$, 'addSubSpectrum$jspecview_common_Spectrum$Z',  function (spectrum, forceSub) {
if (!forceSub && (this.is1D$() || this.blockID != spectrum.blockID  )  || !C$.allowSubSpec$jspecview_common_Spectrum$jspecview_common_Spectrum(this, spectrum) ) return false;
this.isForcedSubset=forceSub;
if (this.subSpectra == null ) {
this.subSpectra=Clazz.new_($I$(1,1));
this.addSubSpectrum$jspecview_common_Spectrum$Z(this, true);
}this.subSpectra.addLast$O(spectrum);
spectrum.parent=this;
return true;
});

Clazz.newMeth(C$, 'getSubIndex$',  function () {
return (this.subSpectra == null  ? -1 : this.currentSubSpectrumIndex);
});

Clazz.newMeth(C$, 'setExportXAxisDirection$Z',  function (leftToRight) {
this.exportXAxisLeftToRight=leftToRight;
});

Clazz.newMeth(C$, 'isExportXAxisLeftToRight$',  function () {
return this.exportXAxisLeftToRight;
});

Clazz.newMeth(C$, 'getInfo$S',  function (key) {
var info=Clazz.new_($I$(6,1));
if ("id".equalsIgnoreCase$S(key)) {
info.put$O$O(key, this.id);
return info;
}var keys=null;
if ("".equals$O(key)) {
keys="id specShift header";
}info.put$O$O("id", this.id);
$I$(7,"putInfo$S$java_util_Map$S$O",[key, info, "specShift", Double.valueOf$D(this.specShift)]);
var justHeader=("header".equals$O(key));
if (!justHeader && key != null   && keys == null  ) {
for (var i=this.headerTable.size$(); --i >= 0; ) {
var entry=this.headerTable.get$I(i);
if (entry[0].equalsIgnoreCase$S(key) || entry[2].equalsIgnoreCase$S(key) ) {
info.put$O$O(key, entry[1]);
return info;
}}
}var head=Clazz.new_($I$(6,1));
var list=this.getHeaderRowDataAsArray$();
for (var i=0; i < list.length; i++) {
var label=$I$(8).cleanLabel$S(list[i][0]);
if (keys != null ) {
keys+=" " + label;
continue;
}if (key != null  && !justHeader  && !label.equals$O(key) ) continue;
var val=C$.fixInfoValue$S(list[i][1]);
if (key == null ) {
var data=Clazz.new_($I$(6,1));
data.put$O$O("value", val);
data.put$O$O("index", Integer.valueOf$I(i + 1));
info.put$O$O(label, data);
} else {
info.put$O$O(label, val);
}}
if (head.size$() > 0) info.put$O$O("header", head);
if (!justHeader) {
if (keys != null ) {
keys+="  titleLabel type isHZToPPM subSpectrumCount";
} else {
$I$(7,"putInfo$S$java_util_Map$S$O",[key, info, "titleLabel", this.getTitleLabel$()]);
$I$(7,"putInfo$S$java_util_Map$S$O",[key, info, "type", this.getDataType$()]);
$I$(7,"putInfo$S$java_util_Map$S$O",[key, info, "isHZToPPM", Boolean.valueOf$Z(this.isHZtoPPM$())]);
$I$(7,"putInfo$S$java_util_Map$S$O",[key, info, "subSpectrumCount", Integer.valueOf$I(this.subSpectra == null  ? 0 : this.subSpectra.size$())]);
}}if (keys != null ) info.put$O$O("KEYS", keys);
return info;
});

Clazz.newMeth(C$, 'fixInfoValue$S',  function (info) {
try {
return (Integer.valueOf$S(info));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
try {
return (Double.valueOf$S(info));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
return info;
}, 1);

Clazz.newMeth(C$, 'findMatchingPeakInfo$jspecview_common_PeakInfo',  function (pi) {
for (var i=0; i < this.peakList.size$(); i++) if (this.peakList.get$I(i).checkTypeMatch$jspecview_common_PeakInfo(pi)) return this.peakList.get$I(i);

return null;
});

Clazz.newMeth(C$, 'getBasePeakInfo$',  function () {
return (this.peakList.size$() == 0 ? Clazz.new_($I$(9,1)) : Clazz.new_([" baseModel=\"\" " + this.peakList.get$I(0)],$I$(9,1).c$$S));
});

Clazz.newMeth(C$, 'getAxisLabel$Z',  function (isX) {
var label=(isX ? this.peakXLabel : this.peakYLabel);
if (label == null ) label=(isX ? this.xLabel : this.yLabel);
if (label == null ) label=(isX ? this.xUnits : this.yUnits);
return (label == null  ? "" : label.equalsIgnoreCase$S("WAVENUMBERS") ? "1/cm" : label.equalsIgnoreCase$S("nanometers") ? "nm" : label);
});

Clazz.newMeth(C$, 'findXForPeakNearest$D',  function (x) {
return $I$(2,"findXForPeakNearest$jspecview_common_CoordinateA$D$Z",[this.xyCoords, x, this.isInverted$()]);
});

Clazz.newMeth(C$, 'addSpecShift$D',  function (dx) {
if (dx != 0 ) {
this.specShift+=dx;
$I$(2).shiftX$jspecview_common_CoordinateA$D(this.xyCoords, dx);
if (this.subSpectra != null ) for (var i=this.subSpectra.size$(); --i >= 0; ) {
var spec=this.subSpectra.get$I(i);
if (spec !== this  && spec !== this.parent  ) spec.addSpecShift$D(dx);
}
}return this.specShift;
});

Clazz.newMeth(C$, 'allowSubSpec$jspecview_common_Spectrum$jspecview_common_Spectrum',  function (s1, s2) {
return (s1.is1D$() == s2.is1D$()  && s1.xUnits.equalsIgnoreCase$S(s2.xUnits)  && s1.isHNMR$() == s2.isHNMR$()  );
}, 1);

Clazz.newMeth(C$, 'areXScalesCompatible$jspecview_common_Spectrum$jspecview_common_Spectrum$Z$Z',  function (s1, s2, isSubspecCheck, isLinkCheck) {
var isNMR1=s1.isNMR$();
if (isNMR1 != s2.isNMR$()  || s1.isContinuous$() != s2.isContinuous$()   || !isLinkCheck && !C$.areUnitsCompatible$S$S(s1.xUnits, s2.xUnits)  ) return false;
if (isSubspecCheck) {
if (s1.is1D$() != s2.is1D$() ) return false;
} else if (isLinkCheck) {
if (!isNMR1) return true;
} else if (!s1.is1D$() || !s2.is1D$() ) {
return false;
}return (!isNMR1 || s2.is1D$() && s1.parent.nucleusX.equals$O(s2.parent.nucleusX)  );
}, 1);

Clazz.newMeth(C$, 'areUnitsCompatible$S$S',  function (u1, u2) {
if (u1.equalsIgnoreCase$S(u2)) return true;
u1=u1.toUpperCase$();
u2=u2.toUpperCase$();
return (u1.equals$O("HZ") && u2.equals$O("PPM")  || u1.equals$O("PPM") && u2.equals$O("HZ")  );
}, 1);

Clazz.newMeth(C$, 'areLinkableX$jspecview_common_Spectrum$jspecview_common_Spectrum',  function (s1, s2) {
return (s1.isNMR$() && s2.isNMR$() && s1.nucleusX.equals$O(s2.nucleusX)  );
}, 1);

Clazz.newMeth(C$, 'areLinkableY$jspecview_common_Spectrum$jspecview_common_Spectrum',  function (s1, s2) {
return (s1.isNMR$() && s2.isNMR$() && s1.nucleusX.equals$O(s2.nucleusY)  );
}, 1);

Clazz.newMeth(C$, 'getPeakWidth$',  function () {
var w=this.getLastX$() - this.getFirstX$();
return (w / 100);
});

Clazz.newMeth(C$, 'setSimulated$S',  function (filePath) {
this.isSimulation=true;
var s=this.sourceID;
if (s.length$() == 0) s=$I$(10).rep$S$S$S(filePath, "http://SIMULATION/", "");
if (s.indexOf$S("MOL=") >= 0) s="";
this.title="SIMULATED " + $I$(10).rep$S$S$S(s, "$", "");
});

Clazz.newMeth(C$, 'setFillColor$javajs_api_GenericColor',  function (color) {
this.fillColor=color;
if (this.convertedSpectrum != null ) this.convertedSpectrum.fillColor=color;
});

Clazz.newMeth(C$, 'toString',  function () {
return this.getTitleLabel$() + (this.xyCoords == null  ? "" : " xyCoords.length=" + this.xyCoords.length);
});
;
(function(){/*e*/var C$=Clazz.newClass(P$.Spectrum, "IRMode", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getMode$S',  function (value) {
switch ((value == null  ? "I" : value.toUpperCase$().charAt$I(0)).$c()) {
case 65:
return C$.TO_ABS;
case 84:
return (value.equalsIgnoreCase$S("TOGGLE") ? C$.TOGGLE : C$.TO_TRANS);
case 78:
return C$.NO_CONVERT;
default:
return C$.TOGGLE;
}
}, 1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "NO_CONVERT", 0, []);
Clazz.newEnumConst($vals, C$.c$, "TO_TRANS", 1, []);
Clazz.newEnumConst($vals, C$.c$, "TO_ABS", 2, []);
Clazz.newEnumConst($vals, C$.c$, "TOGGLE", 3, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:29 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
