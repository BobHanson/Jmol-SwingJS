(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[[0,'jspecview.common.Parameters','javajs.util.DF','javajs.util.AU',['jspecview.common.Annotation','.AType']]],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MeasurementData", null, 'javajs.util.Lst', 'jspecview.api.AnnotationData');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.isON=true;
},1);

C$.$fields$=[['Z',['isON'],'I',['precision'],'S',['units','key'],'O',['type','jspecview.common.Annotation.AType','spec','jspecview.common.Spectrum','myParams','jspecview.common.Parameters']]
,['O',['HEADER','String[]']]]

Clazz.newMeth(C$, 'c$$jspecview_common_Annotation_AType$jspecview_common_Spectrum',  function (type, spec) {
Clazz.super_(C$, this);
this.type=type;
this.spec=spec;
this.myParams=Clazz.new_($I$(1,1)).setName$S("MeasurementData");
}, 1);

Clazz.newMeth(C$, 'getMeasurements$',  function () {
return this;
});

Clazz.newMeth(C$, 'getAType$',  function () {
return this.type;
});

Clazz.newMeth(C$, 'getState$',  function () {
return this.isON;
});

Clazz.newMeth(C$, 'setState$Z',  function (b) {
this.isON=b;
});

Clazz.newMeth(C$, 'setMeasurements$javajs_util_Lst',  function (measurements) {
});

Clazz.newMeth(C$, 'getParameters$',  function () {
return this.myParams;
});

Clazz.newMeth(C$, 'getDataHeader$',  function () {
return C$.HEADER;
});

Clazz.newMeth(C$, 'getMeasurementListArray$S',  function (units) {
this.units=units;
var ddata=this.getMeasurementListArrayReal$S(units);
var precisionX=(this.spec.isNMR$() ? 4 : 2);
var precisionDX=(this.spec.isHNMR$() && units.equals$O("ppm")  ? 4 : 2);
var data=Clazz.array(String, [this.size$(), null]);
for (var i=this.size$(); --i >= 0; ) data[i]=Clazz.array(String, -1, ["" + (i + 1), $I$(2).formatDecimalDbl$D$I(ddata[i][0], precisionX), $I$(2).formatDecimalDbl$D$I(ddata[i][1], precisionX), $I$(2).formatDecimalDbl$D$I(ddata[i][2], precisionDX)]);

return data;
});

Clazz.newMeth(C$, 'getMeasurementListArrayReal$S',  function (units) {
var toHz=this.spec.isNMR$() && units.equalsIgnoreCase$S("HZ") ;
var data=$I$(3,"newDouble2$I",[this.size$()]);
for (var pt=0, i=this.size$(); --i >= 0; ) {
var y=this.get$I(i).getValue$();
if (toHz) y*=this.spec.getObservedFreq$();
data[pt++]=Clazz.array(Double.TYPE, -1, [this.get$I(i).getXVal$(), this.get$I(i).getXVal2$(), y]);
}
return data;
});

Clazz.newMeth(C$, 'checkParameters$jspecview_common_MeasurementData$jspecview_common_ColorParameters',  function (md, p) {
if (md.size$() == 0) return false;
var myParams=md.getParameters$();
switch (md.getAType$()) {
case $I$(4).Integration:
break;
case $I$(4).PeakList:
return (p.peakListInterpolation.equals$O(myParams.peakListInterpolation) && p.peakListThreshold == myParams.peakListThreshold  );
case $I$(4).Measurements:
break;
case $I$(4).NONE:
}
return false;
}, 1);

Clazz.newMeth(C$, 'getSpectrum$',  function () {
return this.spec;
});

Clazz.newMeth(C$, 'getData$',  function () {
return this;
});

Clazz.newMeth(C$, 'clear$D$D',  function (x1, x2) {
for (var i=this.size$(); --i >= 0; ) {
var $in=this.get$I(i);
if ($in.text.length$() == 0 || $in.overlaps$D$D(x1, x2) ) {
this.removeItemAt$I(i);
}}
});

Clazz.newMeth(C$, 'find$D',  function (x) {
for (var i=this.size$(); --i >= 0; ) {
var $in=this.get$I(i);
if ($in.overlaps$D$D(x, x)) {
return i;
}}
return -1;
});

Clazz.newMeth(C$, 'setSpecShift$D',  function (dx) {
for (var i=this.size$(); --i >= 0; ) {
var m=this.get$I(i);
var x=m.getXVal$() + dx;
m.setXVal$D(x);
m.setValue$D(x);
m.text=$I$(2).formatDecimalDbl$D$I(x, this.precision);
}
});

Clazz.newMeth(C$, 'getGraphSetKey$',  function () {
return this.key;
});

Clazz.newMeth(C$, 'setGraphSetKey$S',  function (key) {
this.key=key;
});

Clazz.newMeth(C$, 'isVisible$',  function () {
return true;
});

Clazz.newMeth(C$, 'getInfo$java_util_Map',  function (info) {
info.put$O$O("header", this.getDataHeader$());
info.put$O$O("table", this.getMeasurementListArrayReal$S("ppm"));
if (this.units != null ) info.put$O$O("units", this.units);
});

C$.$static$=function(){C$.$static$=0;
C$.HEADER=Clazz.array(String, -1, ["", "start", "end", "value"]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:05 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
