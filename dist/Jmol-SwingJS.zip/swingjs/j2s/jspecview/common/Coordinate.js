(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[[0,'jspecview.common.CoordComparator','javajs.util.Lst','java.util.StringTokenizer','java.util.Arrays']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Coordinate");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.xVal=0;
this.yVal=0;
},1);

C$.$fields$=[['D',['xVal','yVal']]
,['O',['c','java.util.Comparator']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'set$D$D',  function (x, y) {
this.xVal=x;
this.yVal=y;
return this;
});

Clazz.newMeth(C$, 'getXVal$',  function () {
return this.xVal;
});

Clazz.newMeth(C$, 'getYVal$',  function () {
return this.yVal;
});

Clazz.newMeth(C$, 'setXVal$D',  function (val) {
this.xVal=val;
});

Clazz.newMeth(C$, 'setYVal$D',  function (val) {
this.yVal=val;
});

Clazz.newMeth(C$, 'copy$',  function () {
return Clazz.new_(C$).set$D$D(this.xVal, this.yVal);
});

Clazz.newMeth(C$, 'equals$jspecview_common_Coordinate',  function (coord) {
return (coord.xVal == this.xVal  && coord.yVal == this.yVal  );
});

Clazz.newMeth(C$, 'toString',  function () {
return "[" + new Double(this.xVal).toString() + ", " + new Double(this.yVal).toString() + "]" ;
});

Clazz.newMeth(C$, 'isYInRange$jspecview_common_CoordinateA$D$D',  function (xyCoords, min, max) {
return (C$.getMinY$jspecview_common_CoordinateA$I$I(xyCoords, 0, xyCoords.length - 1) >= min  && C$.getMaxY$jspecview_common_CoordinateA$I$I(xyCoords, 0, xyCoords.length - 1) >= max  );
}, 1);

Clazz.newMeth(C$, 'normalise$jspecview_common_CoordinateA$D$D',  function (xyCoords, min, max) {
var newXYCoords=Clazz.array(C$, [xyCoords.length]);
var minY=C$.getMinY$jspecview_common_CoordinateA$I$I(xyCoords, 0, xyCoords.length - 1);
var maxY=C$.getMaxY$jspecview_common_CoordinateA$I$I(xyCoords, 0, xyCoords.length - 1);
var factor=(maxY - minY) / (max - min);
for (var i=0; i < xyCoords.length; i++) newXYCoords[i]=Clazz.new_(C$).set$D$D(xyCoords[i].getXVal$(), ((xyCoords[i].getYVal$() - minY) / factor) - min);

return newXYCoords;
}, 1);

Clazz.newMeth(C$, 'reverse$jspecview_common_CoordinateA',  function (x) {
var n=x.length;
for (var i=0; i < n; i++) {
var v=x[i];
x[i]=x[--n];
x[n]=v;
}
return x;
}, 1);

Clazz.newMeth(C$, 'parseDSV$S$D$D',  function (dataPoints, xFactor, yFactor) {
var point;
var xval=0;
var yval=0;
var xyCoords=Clazz.new_($I$(2,1));
var delim=" \t\n\r\f,;";
var st=Clazz.new_($I$(3,1).c$$S$S,[dataPoints, delim]);
var tmp1;
var tmp2;
while (st.hasMoreTokens$()){
tmp1=st.nextToken$().trim$();
tmp2=st.nextToken$().trim$();
xval=Double.parseDouble$S(tmp1);
yval=Double.parseDouble$S(tmp2);
point=Clazz.new_(C$).set$D$D(xval * xFactor, yval * yFactor);
xyCoords.addLast$O(point);
}
var coord=Clazz.array(C$, [xyCoords.size$()]);
return xyCoords.toArray$OA(coord);
}, 1);

Clazz.newMeth(C$, 'deltaX$D$D$I',  function (last, first, numPoints) {
return (last - first) / (numPoints - 1);
}, 1);

Clazz.newMeth(C$, 'removeScale$jspecview_common_CoordinateA$D$D',  function (xyCoords, xScale, yScale) {
C$.applyScale$jspecview_common_CoordinateA$D$D(xyCoords, (1 / xScale), (1 / yScale));
}, 1);

Clazz.newMeth(C$, 'applyScale$jspecview_common_CoordinateA$D$D',  function (xyCoords, xScale, yScale) {
if (xScale != 1  || yScale != 1  ) {
for (var i=0; i < xyCoords.length; i++) {
xyCoords[i].setXVal$D(xyCoords[i].getXVal$() * xScale);
xyCoords[i].setYVal$D(xyCoords[i].getYVal$() * yScale);
}
}}, 1);

Clazz.newMeth(C$, 'getMinX$jspecview_common_CoordinateA$I$I',  function (coords, start, end) {
var min=1.7976931348623157E308;
for (var index=start; index <= end; index++) {
var tmp=coords[index].getXVal$();
if (tmp < min ) min=tmp;
}
return min;
}, 1);

Clazz.newMeth(C$, 'getMinX$javajs_util_Lst$jspecview_common_ViewData',  function (spectra, vd) {
var min=1.7976931348623157E308;
for (var i=0; i < spectra.size$(); i++) {
var xyCoords=spectra.get$I(i).getXYCoords$();
var tmp=C$.getMinX$jspecview_common_CoordinateA$I$I(xyCoords, vd.getStartingPointIndex$I(i), vd.getEndingPointIndex$I(i));
if (tmp < min ) min=tmp;
}
return min;
}, 1);

Clazz.newMeth(C$, 'getMaxX$jspecview_common_CoordinateA$I$I',  function (coords, start, end) {
var max=-1.7976931348623157E308;
for (var index=start; index <= end; index++) {
var tmp=coords[index].getXVal$();
if (tmp > max ) max=tmp;
}
return max;
}, 1);

Clazz.newMeth(C$, 'getMaxX$javajs_util_Lst$jspecview_common_ViewData',  function (spectra, vd) {
var max=-1.7976931348623157E308;
for (var i=0; i < spectra.size$(); i++) {
var xyCoords=spectra.get$I(i).getXYCoords$();
var tmp=C$.getMaxX$jspecview_common_CoordinateA$I$I(xyCoords, vd.getStartingPointIndex$I(i), vd.getEndingPointIndex$I(i));
if (tmp > max ) max=tmp;
}
return max;
}, 1);

Clazz.newMeth(C$, 'getMinY$jspecview_common_CoordinateA$I$I',  function (coords, start, end) {
var min=1.7976931348623157E308;
for (var index=start; index <= end; index++) {
var tmp=coords[index].getYVal$();
if (tmp < min ) min=tmp;
}
return min;
}, 1);

Clazz.newMeth(C$, 'getMinYUser$javajs_util_Lst$jspecview_common_ViewData',  function (spectra, vd) {
var min=1.7976931348623157E308;
for (var i=0; i < spectra.size$(); i++) {
var u=spectra.get$I(i).getUserYFactor$();
var yref=spectra.get$I(i).getYRef$();
var xyCoords=spectra.get$I(i).getXYCoords$();
var tmp=(C$.getMinY$jspecview_common_CoordinateA$I$I(xyCoords, vd.getStartingPointIndex$I(i), vd.getEndingPointIndex$I(i)) - yref) * u + yref;
if (tmp < min ) min=tmp;
}
return min;
}, 1);

Clazz.newMeth(C$, 'getMaxY$jspecview_common_CoordinateA$I$I',  function (coords, start, end) {
var max=-1.7976931348623157E308;
for (var index=start; index <= end; index++) {
var tmp=coords[index].getYVal$();
if (tmp > max ) max=tmp;
}
return max;
}, 1);

Clazz.newMeth(C$, 'getMaxYUser$javajs_util_Lst$jspecview_common_ViewData',  function (spectra, vd) {
var max=-1.7976931348623157E308;
for (var i=0; i < spectra.size$(); i++) {
var u=spectra.get$I(i).getUserYFactor$();
var yref=spectra.get$I(i).getYRef$();
var xyCoords=spectra.get$I(i).getXYCoords$();
var tmp=(C$.getMaxY$jspecview_common_CoordinateA$I$I(xyCoords, vd.getStartingPointIndex$I(i), vd.getEndingPointIndex$I(i)) - yref) * u + yref;
if (tmp > max ) max=tmp;
}
return max;
}, 1);

Clazz.newMeth(C$, 'getYValueAt$jspecview_common_CoordinateA$D',  function (xyCoords, xPt) {
var i=C$.getNearestIndexForX$jspecview_common_CoordinateA$D(xyCoords, xPt);
if (i == 0 || i == xyCoords.length ) return NaN;
var x1=xyCoords[i].getXVal$();
var x0=xyCoords[i - 1].getXVal$();
var y1=xyCoords[i].getYVal$();
var y0=xyCoords[i - 1].getYVal$();
if (x1 == x0 ) return y1;
return y0 + (y1 - y0) / (x1 - x0) * (xPt - x0);
}, 1);

Clazz.newMeth(C$, 'intoRange$I$I$I',  function (i, i0, i1) {
return Math.max(Math.min(i, i1), i0);
}, 1);

Clazz.newMeth(C$, 'getNearestIndexForX$jspecview_common_CoordinateA$D',  function (xyCoords, xPt) {
var x=Clazz.new_(C$).set$D$D(xPt, 0);
var i=$I$(4).binarySearch$OA$O$java_util_Comparator(xyCoords, x, C$.c);
if (i < 0) i=-1 - i;
if (i < 0) return 0;
if (i > xyCoords.length - 1) return xyCoords.length - 1;
return i;
}, 1);

Clazz.newMeth(C$, 'findXForPeakNearest$jspecview_common_CoordinateA$D$Z',  function (xyCoords, x, isMin) {
var pt=C$.getNearestIndexForX$jspecview_common_CoordinateA$D(xyCoords, x);
var f=(isMin ? -1 : 1);
while (pt < xyCoords.length - 1 && f * (xyCoords[pt + 1].yVal - xyCoords[pt].yVal) > 0  )++pt;

while (pt >= 1 && f * (xyCoords[pt - 1].yVal - xyCoords[pt].yVal) > 0  )--pt;

if (pt == 0 || pt == xyCoords.length - 1 ) return xyCoords[pt].xVal;
return C$.parabolicInterpolation$jspecview_common_CoordinateA$I(xyCoords, pt);
}, 1);

Clazz.newMeth(C$, 'parabolicInterpolation$jspecview_common_CoordinateA$I',  function (xyCoords, pt) {
var alpha=xyCoords[pt - 1].yVal;
var beta=xyCoords[pt].yVal;
var gamma=xyCoords[pt + 1].yVal;
var p=(alpha - gamma) / 2 / (alpha - 2 * beta + gamma) ;
return xyCoords[pt].xVal + p * (xyCoords[pt + 1].xVal - xyCoords[pt].xVal);
}, 1);

Clazz.newMeth(C$, 'getPickedCoordinates$jspecview_common_CoordinateA$jspecview_common_Coordinate$jspecview_common_Coordinate$jspecview_common_Coordinate',  function (coordsClicked, coordClicked, coord, actualCoord) {
if (coordClicked == null ) return false;
var x=coordClicked.getXVal$();
coord.setXVal$D(x);
coord.setYVal$D(coordClicked.getYVal$());
if (actualCoord == null ) return true;
var pt=C$.getNearestIndexForX$jspecview_common_CoordinateA$D(coordsClicked, x);
actualCoord.setXVal$D(coordsClicked[pt].getXVal$());
actualCoord.setYVal$D(coordsClicked[pt].getYVal$());
return true;
}, 1);

Clazz.newMeth(C$, 'shiftX$jspecview_common_CoordinateA$D',  function (xyCoords, dx) {
for (var i=xyCoords.length; --i >= 0; ) xyCoords[i].xVal+=dx;

}, 1);

Clazz.newMeth(C$, 'getNearestXWithYAbove$jspecview_common_CoordinateA$D$D$Z$Z',  function (xyCoords, x, y, inverted, andGreaterThanX) {
var pt=C$.getNearestIndexForX$jspecview_common_CoordinateA$D(xyCoords, x);
var f=(inverted ? -1 : 1);
if (andGreaterThanX) while (pt < xyCoords.length && f * (xyCoords[pt].yVal - y) < 0  )++pt;

 else while (pt >= 0 && f * (xyCoords[pt].yVal - y) < 0  )--pt;

if (pt == -1 || pt == xyCoords.length ) return NaN;
return C$.findXForPeakNearest$jspecview_common_CoordinateA$D$Z(xyCoords, xyCoords[pt].getXVal$(), inverted);
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.c=Clazz.new_($I$(1,1));
};
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:28 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
