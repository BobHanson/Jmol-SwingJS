(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "IntegralComparator", null, null, 'java.util.Comparator');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$jspecview_common_Measurement$jspecview_common_Measurement','compare$O$O'],  function (m1, m2) {
return (m1.getXVal$() < m2.getXVal$()  ? -1 : m1.getXVal$() > m2.getXVal$()  ? 1 : 0);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:28 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
