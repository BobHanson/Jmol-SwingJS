(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "IntegralComparator", null, null, 'java.util.Comparator');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$jspecview_common_Measurement$jspecview_common_Measurement','compare$O$O'],  function (m1, m2) {
return (m1.getXVal$() < m2.getXVal$()  ? -1 : m1.getXVal$() > m2.getXVal$()  ? 1 : 0);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:05 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
