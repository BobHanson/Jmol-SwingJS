(function(){var P$=Clazz.newPackage("jspecview.common"),p$1={},I$=[[0,'jspecview.common.Coordinate']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ScaleData");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.firstX=NaN;
this.precision=Clazz.array(Integer.TYPE, [2]);
this.exportPrecision=Clazz.array(Integer.TYPE, [2]);
this.steps=Clazz.array(Double.TYPE, [2]);
this.minorTickCounts=Clazz.array(Integer.TYPE, [2]);
this.spectrumScaleFactor=1;
this.spectrumYRef=0;
this.userYFactor=1;
},1);

C$.$fields$=[['Z',['isShiftZoomedY'],'D',['initMinYOnScale','initMaxYOnScale','initMinY','initMaxY','minX','maxX','firstX','minXOnScale','maxXOnScale','specShift','minYOnScale','maxYOnScale','minY','maxY','spectrumScaleFactor','spectrumYRef','userYFactor','firstY','minY2D','maxY2D','xFactorForScale','yFactorForScale'],'I',['startDataPointIndex','endDataPointIndex','pointCount'],'O',['precision','int[]','+exportPrecision','steps','double[]','minorTickCounts','int[]']]
,['O',['NTICKS','int[]','LOGTICKS','double[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I',  function (iStart, iEnd) {
;C$.$init$.apply(this);
this.startDataPointIndex=iStart;
this.endDataPointIndex=iEnd;
this.pointCount=this.endDataPointIndex - this.startDataPointIndex + 1;
}, 1);

Clazz.newMeth(C$, 'c$$jspecview_common_CoordinateA$I$I$Z$Z',  function (coords, start, end, isContinuous, isInverted) {
;C$.$init$.apply(this);
this.minX=$I$(1).getMinX$jspecview_common_CoordinateA$I$I(coords, start, end);
this.maxX=$I$(1).getMaxX$jspecview_common_CoordinateA$I$I(coords, start, end);
this.minY=$I$(1).getMinY$jspecview_common_CoordinateA$I$I(coords, start, end);
if (this.minY > 0  && !isContinuous ) this.minY=0;
this.maxY=$I$(1).getMaxY$jspecview_common_CoordinateA$I$I(coords, start, end);
this.setScale$Z$Z(isContinuous, isInverted);
}, 1);

Clazz.newMeth(C$, 'setScale$Z$Z',  function (isContinuous, isInverted) {
p$1.setXScale.apply(this, []);
if (!isContinuous) this.maxXOnScale+=this.steps[0] / 2;
this.setYScale$D$D$Z$Z(this.minY, this.maxY, true, isInverted);
});

Clazz.newMeth(C$, 'setXScale',  function () {
var xStep=p$1.setScaleParams$D$D$I.apply(this, [this.minX, this.maxX, 0]);
this.firstX=Math.floor(this.minX / xStep) * xStep;
if (Math.abs((this.minX - this.firstX) / xStep) > 1.0E-4 ) this.firstX+=xStep;
this.minXOnScale=this.minX;
this.maxXOnScale=this.maxX;
}, p$1);

Clazz.newMeth(C$, 'isYZeroOnScale$',  function () {
return (this.minYOnScale < this.spectrumYRef  && this.maxYOnScale > this.spectrumYRef  );
});

Clazz.newMeth(C$, 'setYScale$D$D$Z$Z',  function (minY, maxY, setScaleMinMax, isInverted) {
if (minY == 0  && maxY == 0  ) maxY=1;
if (this.isShiftZoomedY) {
minY=this.minYOnScale;
maxY=this.maxYOnScale;
}var yStep=p$1.setScaleParams$D$D$I.apply(this, [minY, maxY, 1]);
var dy=(isInverted ? yStep / 2 : yStep / 4);
var dy2=(isInverted ? yStep / 4 : yStep / 2);
if (!this.isShiftZoomedY) {
this.minYOnScale=(minY == 0  ? 0 : setScaleMinMax ? dy * Math.floor(minY / dy) : minY);
this.maxYOnScale=(setScaleMinMax ? dy2 * Math.ceil(maxY * 1.05 / dy2) : maxY);
}this.firstY=(minY == 0  ? 0 : Math.floor(minY / dy) * dy);
if (this.minYOnScale < 0  && this.maxYOnScale > 0  ) {
this.firstY=0;
while (this.firstY - yStep > this.minYOnScale )this.firstY-=yStep;

} else if (this.minYOnScale != 0  && Math.abs((minY - this.firstY) / dy) > 1.0E-4  ) {
this.firstY+=dy;
}if (setScaleMinMax) {
this.initMinYOnScale=this.minYOnScale;
this.initMaxYOnScale=this.maxYOnScale;
this.initMinY=minY;
this.initMaxY=maxY;
}});

Clazz.newMeth(C$, 'scale2D$D',  function (f) {
var dy=this.maxY - this.minY;
if (f == 1 ) {
this.maxY=this.initMaxY;
this.minY=this.initMinY;
return;
}this.maxY=this.minY + dy / f;
});

Clazz.newMeth(C$, 'setXRange$D$D',  function (x1, x2) {
this.minX=x1;
this.maxX=x2;
p$1.setXScale.apply(this, []);
});

Clazz.newMeth(C$, 'getXRange$I$jspecview_common_CoordinateA$D$D$I$I$IA$IA',  function (i, xyCoords, initX, finalX, iStart, iEnd, startIndices, endIndices) {
var index=0;
var ptCount=0;
for (index=iStart; index <= iEnd; index++) {
if (xyCoords[index].getXVal$() >= initX ) {
startIndices[i]=index;
ptCount=1;
break;
}}
while (++index <= iEnd && xyCoords[index].getXVal$() <= finalX  ){
++ptCount;
}
endIndices[i]=startIndices[i] + ptCount - 1;
return ptCount;
}, 1);

Clazz.newMeth(C$, 'setScaleParams$D$D$I',  function (min, max, i) {
var dx=(max == min  ? 1 : Math.abs(max - min) / 14);
var log=Math.log10(Math.abs(dx));
var exp=(Math.floor(log)|0);
this.exportPrecision[i]=exp;
this.precision[i]=(exp <= 0 ? Math.min(8, 1 - exp) : exp > 3 ? -2 : 0);
var j=0;
var dec=Math.pow(10, log - exp);
while (dec > C$.NTICKS[j] ){
++j;
}
this.steps[i]=Math.pow(10, exp) * C$.NTICKS[j];
log=Math.log10(Math.abs(this.steps[i] * 100010.0));
var mantissa=log - Math.floor(log);
var n=0;
for (j=0; j < C$.NTICKS.length; j++) if (Math.abs(mantissa - C$.LOGTICKS[j]) < 0.001 ) {
n=C$.NTICKS[j];
break;
}
this.minorTickCounts[i]=n;
return this.steps[i];
}, p$1);

Clazz.newMeth(C$, 'isInRangeX$D',  function (x) {
return (x >= this.minX  && x <= this.maxX  );
});

Clazz.newMeth(C$, 'addSpecShift$D',  function (dx) {
this.specShift+=dx;
this.minX+=dx;
this.maxX+=dx;
this.minXOnScale+=dx;
this.maxXOnScale+=dx;
this.firstX+=dx;
});

Clazz.newMeth(C$, 'getInfo$java_util_Map',  function (info) {
info.put$O$O("specShift", Double.valueOf$D(this.specShift));
info.put$O$O("minX", Double.valueOf$D(this.minX));
info.put$O$O("maxX", Double.valueOf$D(this.maxX));
info.put$O$O("minXOnScale", Double.valueOf$D(this.minXOnScale));
info.put$O$O("maxXOnScale", Double.valueOf$D(this.maxXOnScale));
info.put$O$O("minY", Double.valueOf$D(this.minY));
info.put$O$O("maxY", Double.valueOf$D(this.maxY));
info.put$O$O("minYOnScale", Double.valueOf$D(this.minYOnScale));
info.put$O$O("maxYOnScale", Double.valueOf$D(this.maxYOnScale));
info.put$O$O("minorTickCountX", Integer.valueOf$I(this.minorTickCounts[0]));
info.put$O$O("xStep", Double.valueOf$D(this.steps[0]));
return info;
});

Clazz.newMeth(C$, 'setMinMax$D$D$D$D',  function (minX, maxX, minY, maxY) {
this.minX=minX;
this.maxX=maxX;
this.minY=minY;
this.maxY=maxY;
});

Clazz.newMeth(C$, 'toX$I$I$Z',  function (xPixel, xPixel1, drawXAxisLeftToRight) {
return p$1.toXScaled$I$I$Z$D.apply(this, [xPixel, xPixel1, drawXAxisLeftToRight, this.xFactorForScale]);
});

Clazz.newMeth(C$, 'toX0$I$I$I$Z',  function (xPixel, xPixel0, xPixel1, drawXAxisLeftToRight) {
return p$1.toXScaled$I$I$Z$D.apply(this, [xPixel, xPixel1, drawXAxisLeftToRight, (this.maxXOnScale - this.minXOnScale) / (xPixel1 - xPixel0)]);
});

Clazz.newMeth(C$, 'toXScaled$I$I$Z$D',  function (xPixel, xPixel1, drawXAxisLeftToRight, factor) {
return (drawXAxisLeftToRight ? this.maxXOnScale - (xPixel1 - xPixel) * factor : this.minXOnScale + (xPixel1 - xPixel) * factor);
}, p$1);

Clazz.newMeth(C$, 'toPixelX$D$I$I$Z',  function (dx, xPixel0, xPixel1, drawXAxisLeftToRight) {
return p$1.toPixelXScaled$D$I$I$Z$D.apply(this, [dx, xPixel0, xPixel1, drawXAxisLeftToRight, this.xFactorForScale]);
});

Clazz.newMeth(C$, 'toPixelX0$D$I$I$Z',  function (dx, xPixel0, xPixel1, drawXAxisLeftToRight) {
return p$1.toPixelXScaled$D$I$I$Z$D.apply(this, [dx, xPixel0, xPixel1, drawXAxisLeftToRight, (this.maxXOnScale - this.minXOnScale) / (xPixel1 - xPixel0)]);
});

Clazz.newMeth(C$, 'toPixelXScaled$D$I$I$Z$D',  function (dx, xPixel0, xPixel1, drawXAxisLeftToRight, factor) {
var x=(((dx - this.minXOnScale) / factor)|0);
return (drawXAxisLeftToRight ? xPixel0 + x : xPixel1 - x);
}, p$1);

Clazz.newMeth(C$, 'toY$I$I',  function (yPixel, yPixel0) {
return this.maxYOnScale + (yPixel0 - yPixel) * this.yFactorForScale;
});

Clazz.newMeth(C$, 'toY0$I$I$I',  function (yPixel, yPixel0, yPixel1) {
var factor=(this.maxYOnScale - this.minYOnScale) / (yPixel1 - yPixel0);
var y=this.maxYOnScale + (yPixel0 - yPixel) * factor;
return Math.max(this.minYOnScale, Math.min(y, this.maxYOnScale));
});

Clazz.newMeth(C$, 'toPixelY$D$I',  function (yVal, yPixel1) {
return (Double.isNaN$D(yVal) ? -2147483648 : yPixel1 - ((((yVal - this.spectrumYRef) * this.userYFactor + this.spectrumYRef - this.minYOnScale) / this.yFactorForScale)|0));
});

Clazz.newMeth(C$, 'toPixelY0$D$I$I',  function (y, yPixel0, yPixel1) {
var factor=(this.maxYOnScale - this.minYOnScale) / (yPixel1 - yPixel0);
return ((yPixel0 + (this.maxYOnScale - y) / factor)|0);
});

Clazz.newMeth(C$, 'setXYScale$I$I$Z',  function (xPixels, yPixels, isInverted) {
var yRef=this.spectrumYRef;
var f=this.spectrumScaleFactor;
var useInit=(f != 1  || this.isShiftZoomedY );
var minY=(useInit ? this.initMinYOnScale : this.minY);
var maxY=(useInit ? this.initMaxYOnScale : this.maxY);
if (useInit && yRef < minY  ) yRef=minY;
if (useInit && yRef > maxY  ) yRef=maxY;
this.setYScale$D$D$Z$Z((minY - yRef) / f + yRef, (maxY - yRef) / f + yRef, f == 1 , isInverted);
this.xFactorForScale=(this.maxXOnScale - this.minXOnScale) / (xPixels - 1);
this.yFactorForScale=(this.maxYOnScale - this.minYOnScale) / (yPixels - 1);
});

Clazz.newMeth(C$, 'copyScaleFactors$jspecview_common_ScaleDataA$jspecview_common_ScaleDataA',  function (sdFrom, sdTo) {
for (var i=0; i < sdFrom.length; i++) {
sdTo[i].spectrumScaleFactor=sdFrom[i].spectrumScaleFactor;
sdTo[i].spectrumYRef=sdFrom[i].spectrumYRef;
sdTo[i].userYFactor=sdFrom[i].userYFactor;
sdTo[i].specShift=sdFrom[i].specShift;
sdTo[i].isShiftZoomedY=sdFrom[i].isShiftZoomedY;
}
}, 1);

Clazz.newMeth(C$, 'copyYScales$jspecview_common_ScaleDataA$jspecview_common_ScaleDataA',  function (sdFrom, sdTo) {
for (var i=0; i < sdFrom.length; i++) {
sdTo[i].initMinYOnScale=sdFrom[i].initMinYOnScale;
sdTo[i].initMaxYOnScale=sdFrom[i].initMaxYOnScale;
sdTo[i].minY=sdFrom[i].minY;
sdTo[i].maxY=sdFrom[i].maxY;
if (sdFrom[i].isShiftZoomedY) {
sdTo[i].isShiftZoomedY=true;
sdTo[i].minYOnScale=sdFrom[i].minYOnScale;
sdTo[i].maxYOnScale=sdFrom[i].maxYOnScale;
}}
}, 1);

Clazz.newMeth(C$, 'setDataPointIndices$javajs_util_Lst$D$D$I$IA$IA',  function (graphsTemp, initX, finalX, minPoints, startIndices, endIndices) {
var nSpectraOK=0;
var nSpectra=graphsTemp.size$();
for (var i=0; i < nSpectra; i++) {
var xyCoords=graphsTemp.get$I(i).getXYCoords$();
if (C$.getXRange$I$jspecview_common_CoordinateA$D$D$I$I$IA$IA(i, xyCoords, initX, finalX, 0, xyCoords.length - 1, startIndices, endIndices) >= minPoints) ++nSpectraOK;
}
return (nSpectraOK == nSpectra);
}, 1);

Clazz.newMeth(C$, 'fixScale$java_util_Map',  function (map) {
if (map.isEmpty$()) return;
while (true){
for (var entry, $entry = map.entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) {
var s=entry.getValue$();
var pt=s.indexOf$S("E");
if (pt >= 0) s=s.substring$I$I(0, pt);
if (s.indexOf$S(".") < 0) return;
if (!s.endsWith$S("0") && !s.endsWith$S(".") ) return;
}
for (var entry, $entry = map.entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) {
var s=entry.getValue$();
var pt=s.indexOf$S("E");
if (pt >= 0) entry.setValue$O(s.substring$I$I(0, pt - 1) + s.substring$I(pt));
 else entry.setValue$O(s.substring$I$I(0, s.length$() - 1));
}
}
}, 1);

Clazz.newMeth(C$, 'scaleBy$D',  function (f) {
if (this.isShiftZoomedY) {
var center=(this.isYZeroOnScale$() ? this.spectrumYRef : (this.minYOnScale + this.maxYOnScale) / 2);
this.minYOnScale=center - (center - this.minYOnScale) / f;
this.maxYOnScale=center - (center - this.maxYOnScale) / f;
} else {
this.spectrumScaleFactor*=f;
}});

C$.$static$=function(){C$.$static$=0;
C$.NTICKS=Clazz.array(Integer.TYPE, -1, [2, 5, 10, 10]);
C$.LOGTICKS=Clazz.array(Double.TYPE, -1, [Math.log10(2), Math.log10(5), 0, 1]);
};
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:06 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
