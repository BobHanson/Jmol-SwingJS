(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[[0,'jspecview.common.Coordinate']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Measurement", null, 'jspecview.common.Annotation');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.pt2=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['D',['value'],'O',['pt2','jspecview.common.Coordinate']]]

Clazz.newMeth(C$, 'setM1$D$D$jspecview_common_Spectrum',  function (x, y, spec) {
this.setA$D$D$jspecview_common_Spectrum$S$Z$Z$I$I(x, y, spec, "", false, false, 0, 6);
this.setPt2$D$D(this.getXVal$(), this.getYVal$());
return this;
});

Clazz.newMeth(C$, 'copyM$',  function () {
var m=Clazz.new_(C$);
m.setA$D$D$jspecview_common_Spectrum$S$Z$Z$I$I(this.getXVal$(), this.getYVal$(), this.spec, this.text, false, false, this.offsetX, this.offsetY);
m.setPt2$D$D(this.pt2.getXVal$(), this.pt2.getYVal$());
return m;
});

Clazz.newMeth(C$, 'setPt2$jspecview_common_Spectrum$Z',  function (spec, doSetPt2) {
this.spec=spec;
if (doSetPt2) this.setPt2$D$D(this.getXVal$(), this.getYVal$());
return this;
});

Clazz.newMeth(C$, 'setPt2$D$D',  function (x, y) {
this.pt2.setXVal$D(x);
this.pt2.setYVal$D(y);
this.value=Math.abs(x - this.getXVal$());
this.text=this.spec.setMeasurementText$jspecview_common_Measurement(this);
});

Clazz.newMeth(C$, 'getSpectrum$',  function () {
return this.spec;
});

Clazz.newMeth(C$, 'setValue$D',  function (value) {
this.value=value;
this.text=this.spec.setMeasurementText$jspecview_common_Measurement(this);
});

Clazz.newMeth(C$, 'getValue$',  function () {
return this.value;
});

Clazz.newMeth(C$, 'getXVal2$',  function () {
return this.pt2.getXVal$();
});

Clazz.newMeth(C$, 'getYVal2$',  function () {
return this.pt2.getYVal$();
});

Clazz.newMeth(C$, 'addSpecShift$D',  function (dx) {
this.setXVal$D(this.getXVal$() + dx);
this.pt2.setXVal$D(this.pt2.getXVal$() + dx);
});

Clazz.newMeth(C$, 'setYVal2$D',  function (y2) {
this.pt2.setYVal$D(y2);
});

Clazz.newMeth(C$, 'overlaps$D$D',  function (x1, x2) {
return (Math.min(this.getXVal$(), this.getXVal2$()) < Math.max(x1, x2)  && Math.max(this.getXVal$(), this.getXVal2$()) > Math.min(x1, x2)  );
});

Clazz.newMeth(C$, 'toString',  function () {
return "[" + new Double(this.getXVal$()).toString() + "," + new Double(this.pt2.getXVal$()).toString() + "]" ;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:52 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
