(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "PeakPick", null, 'jspecview.common.Measurement');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'setValue$D$D$jspecview_common_Spectrum$S$D',  function (x, y, spec, text, value) {
if (text == null ) {
this.set$D$D(x, y);
this.setPt2$jspecview_common_Spectrum$Z(spec, false);
} else {
this.setA$D$D$jspecview_common_Spectrum$S$Z$Z$I$I(x, y, spec, text, false, false, 0, 6);
this.value=value;
this.setPt2$D$D(this.getXVal$(), this.getYVal$());
}return this;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:57 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
