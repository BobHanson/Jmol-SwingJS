(function(){var P$=Clazz.newPackage("jspecview.common"),p$1={},I$=[[0,['jspecview.common.Spectrum','.IRMode'],'jspecview.tree.SimpleTree','javajs.util.Lst','jspecview.common.RepaintManager','org.jmol.util.Logger','jspecview.common.ScriptTokenizer','jspecview.common.ScriptToken','jspecview.common.Parameters','javajs.util.PT','jspecview.common.JSVFileManager',['jspecview.common.PanelData','.LinkMode'],['jspecview.common.Annotation','.AType'],'jspecview.common.PeakInfo','jspecview.common.Spectrum','jspecview.common.PanelNode','javajs.util.SB','Thread','java.util.Hashtable','java.net.URL','jspecview.source.JDXSource','jspecview.source.JDXReader','jspecview.api.JSVPanel','jspecview.common.PrintLayout','jspecview.common.ExportType','javajs.util.OC','java.io.File','javajs.util.CU','java.util.Arrays']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JSViewer", null, null, ['org.jmol.api.PlatformViewer', 'javajs.api.BytePoster']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.irMode=$I$(1).NO_CONVERT;
this.allowMenu=true;
this.initialStartIndex=-1;
this.initialEndIndex=-1;
this.recentScript="";
this.maximumSize=2147483647;
this.popupAllowMenu=true;
this.popupZoomEnabled=true;
this.nmrMaxY=NaN;
this.recentStackPercent=5;
this.recentOpenURL="http://";
this.recentSimulation="tylenol";
},1);

C$.$fields$=[['Z',['loadImaginary','interfaceOverlaid','autoIntegrate','autoShowLegend','allowMenu','isSingleThreaded','isApplet','isSigned','popupAllowMenu','popupZoomEnabled','overlayLegendVisible'],'F',['nmrMaxY'],'I',['initialStartIndex','initialEndIndex','maximumSize','screenHeight','screenWidth','fileCount','nViews','scriptLevelCount','recentStackPercent'],'S',['recentScript','appletName','fullName','syncID','returnFromJmolModel','integrationRatios','defaultLoadScript','recentOpenURL','recentURL','recentSimulation'],'O',['si','jspecview.api.ScriptInterface','g2d','org.jmol.api.GenericGraphics','spectraTree','jspecview.api.JSVTree','currentSource','jspecview.source.JDXSource','panelNodes','javajs.util.Lst','parameters','jspecview.common.ColorParameters','repaintManager','jspecview.common.RepaintManager','selectedPanel','jspecview.api.JSVPanel','mainPanel','jspecview.api.JSVMainPanel','properties','java.util.Properties','scriptQueue','javajs.util.Lst','fileHelper','jspecview.api.JSVFileHelper','jsvpPopupMenu','jspecview.popup.JSVGenericPopup','dialogManager','jspecview.dialog.DialogManager','viewDialog','jspecview.dialog.JSVDialog','+overlayLegendDialog','irMode','jspecview.common.Spectrum.IRMode','obscureTitleFromUser','Boolean','html5Applet','jspecview.api.js.JSVAppletObject','display','java.lang.Object','apiPlatform','org.jmol.api.GenericPlatform','lastPrintLayout','jspecview.common.PrintLayout','offWindowFrame','java.lang.Object']]
,['Z',['isJS','isSwingJS'],'S',['testScript'],'O',['jmolObject','jspecview.api.js.JSVToJSmolInterface']]]

Clazz.newMeth(C$, 'setProperty$S$S',  function (key, value) {
if (this.properties != null ) this.properties.setProperty$S$S(key, value);
});

Clazz.newMeth(C$, 'setNode$jspecview_common_PanelNode',  function (node) {
if (node.jsvp !== this.selectedPanel ) this.si.siSetSelectedPanel$jspecview_api_JSVPanel(node.jsvp);
this.si.siSendPanelChange$();
this.si.siNodeSet$jspecview_common_PanelNode(node);
});

Clazz.newMeth(C$, 'c$$jspecview_api_ScriptInterface$Z$Z',  function (si, isApplet, isJSApplet) {
;C$.$init$.apply(this);
this.si=si;
this.isApplet=isApplet;
C$.isJS=isApplet && isJSApplet ;
var jmol=null;
{
self.Jmol && (jmol = Jmol);
}
C$.jmolObject=jmol;
this.isSigned=si.isSigned$();
this.apiPlatform=this.getPlatformInterface$S("Platform");
this.apiPlatform.setViewer$org_jmol_api_PlatformViewer$O(this, this.display);
this.g2d=this.getPlatformInterface$S("G2D");
this.spectraTree=Clazz.new_($I$(2,1).c$$jspecview_common_JSViewer,[this]);
this.parameters=this.getPlatformInterface$S("Parameters");
this.parameters.setName$S("applet");
this.fileHelper=(this.getPlatformInterface$S("FileHelper")).set$jspecview_common_JSViewer(this);
this.isSingleThreaded=this.apiPlatform.isSingleThreaded$();
this.panelNodes=Clazz.new_($I$(3,1));
this.repaintManager=Clazz.new_($I$(4,1).c$$jspecview_common_JSViewer,[this]);
if (!isApplet) this.setPopupMenu$Z$Z(true, true);
}, 1);

Clazz.newMeth(C$, 'setPopupMenu$Z$Z',  function (allowMenu, zoomEnabled) {
this.popupAllowMenu=allowMenu;
this.popupZoomEnabled=zoomEnabled;
});

Clazz.newMeth(C$, 'showMenu$I$I',  function (x, y) {
if (!this.popupAllowMenu) return;
if (this.jsvpPopupMenu == null ) {
try {
this.jsvpPopupMenu=this.getPlatformInterface$S("Popup");
this.jsvpPopupMenu.jpiInitialize$org_jmol_api_PlatformViewer$S(this, this.isApplet ? "appletMenu" : "appMenu");
this.jsvpPopupMenu.setEnabled$Z$Z(this.popupAllowMenu, this.popupZoomEnabled);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
$I$(5).error$S(e + " initializing popup menu");
return;
} else {
throw e;
}
}
}this.jsvpPopupMenu.jpiShow$I$I(x, y);
});

Clazz.newMeth(C$, 'runScriptNow$S',  function (script) {
System.out.println$S(this.checkScript$S(script));
++this.scriptLevelCount;
if (script == null ) script="";
script=script.trim$();
if (script.startsWith$S("!")) script=script.substring$I(1).trim$();
 else if (script.startsWith$S(">")) {
$I$(5).error$S(script);
return true;
}if (script.indexOf$S("<PeakData") >= 0) {
this.syncScript$S(script);
return true;
}$I$(5).info$S("RUNSCRIPT " + script);
var isOK=true;
var nErrorsLeft=10;
var commandTokens=Clazz.new_($I$(6,1).c$$S$Z,[script, true]);
var msg=null;
while (commandTokens != null  && commandTokens.hasMoreTokens$()  && nErrorsLeft > 0  && isOK ){
var token=commandTokens.nextToken$();
var eachParam=Clazz.new_($I$(6,1).c$$S$Z,[token, false]);
var key=$I$(7).getKey$jspecview_common_ScriptTokenizer(eachParam);
if (key == null ) continue;
var st=$I$(7).getScriptToken$S(key);
var value=$I$(7).getValue$jspecview_common_ScriptToken$jspecview_common_ScriptTokenizer$S(st, eachParam, token);
try {
switch (st) {
case $I$(7).UNKNOWN:
$I$(5).info$S("Unrecognized parameter: " + key);
--nErrorsLeft;
break;
default:
if (this.selectedPanel == null ) break;
this.parameters.set$jspecview_common_PanelData$jspecview_common_ScriptToken$S(this.pd$(), st, value);
this.si.siUpdateBoolean$jspecview_common_ScriptToken$Z(st, $I$(8).isTrue$S(value));
break;
case $I$(7).PEAKCALLBACKFUNCTIONNAME:
case $I$(7).SYNCCALLBACKFUNCTIONNAME:
case $I$(7).COORDCALLBACKFUNCTIONNAME:
case $I$(7).LOADFILECALLBACKFUNCTIONNAME:
this.si.siExecSetCallback$jspecview_common_ScriptToken$S(st, value);
break;
case $I$(7).DEFAULTLOADSCRIPT:
value=$I$(9).rep$S$S$S(value, "\'\'", "\"");
this.defaultLoadScript=(value.length$() > 0 ? value : null);
break;
case $I$(7).DEFAULTNMRNORMALIZATION:
this.nmrMaxY=$I$(9).parseDouble$S(value);
break;
case $I$(7).AUTOINTEGRATE:
this.autoIntegrate=$I$(8).isTrue$S(value);
break;
case $I$(7).CLOSE:
p$1.execClose$S.apply(this, [value]);
break;
case $I$(7).DEBUG:
$I$(5,"setLogLevel$I",[value.toLowerCase$().equals$O("high") ? 6 : $I$(8).isTrue$S(value) ? 5 : 4]);
break;
case $I$(7).GETPROPERTY:
var info=(this.selectedPanel == null  ? null : this.getPropertyAsJavaObject$S(value));
if (info != null ) this.selectedPanel.showMessage$S$S($I$(9).toJSON$S$O(null, info), value);
break;
case $I$(7).HELP:
p$1.execHelp$S.apply(this, [value]);
break;
case $I$(7).HIDDEN:
this.si.siExecHidden$Z($I$(8).isTrue$S(value));
break;
case $I$(7).INTEGRATIONRATIOS:
this.integrationRatios=value;
p$1.execIntegrate$S.apply(this, [null]);
break;
case $I$(7).INTERFACE:
this.interfaceOverlaid=this.checkOvelayInterface$S(value);
break;
case $I$(7).INTEGRALOFFSET:
case $I$(7).INTEGRALRANGE:
p$1.execSetIntegralParameter$jspecview_common_ScriptToken$D.apply(this, [st, Double.parseDouble$S(value)]);
break;
case $I$(7).INVERTY:
p$1.execZoom$S.apply(this, ["invertY"]);
break;
case $I$(7).JMOL:
this.si.syncToJmol$S(value);
break;
case $I$(7).JSV:
this.syncScript$S($I$(9).trimQuotes$S(value));
break;
case $I$(7).LOAD:
if (value.length$() == 0) {
if (this.defaultLoadScript != null ) this.runScriptNow$S(this.defaultLoadScript);
break;
}this.execLoad$S$S(value, (this.defaultLoadScript == null  ? "" : this.defaultLoadScript + ";") + commandTokens.getRemainingScript$());
msg=(this.selectedPanel == null  ? null : this.si.siLoaded$S(value));
commandTokens=null;
break;
case $I$(7).LOADIMAGINARY:
this.loadImaginary=$I$(8).isTrue$S(value);
break;
case $I$(7).PEAK:
p$1.execPeak$S.apply(this, [value]);
break;
case $I$(7).PEAKLIST:
p$1.execPeakList$S.apply(this, [value]);
break;
case $I$(7).SCALEBY:
p$1.scaleSelectedBy$javajs_util_Lst$S.apply(this, [this.panelNodes, value]);
break;
case $I$(7).SCRIPT:
if (value.equals$O("") || value.toLowerCase$().startsWith$S("inline") ) {
p$1.execScriptInline$S.apply(this, [value]);
} else {
var s=$I$(10).getFileAsString$S(value);
if (s != null  && this.scriptLevelCount < 100 ) this.runScriptNow$S(s);
}break;
case $I$(7).SELECT:
p$1.execSelect$S.apply(this, [value]);
break;
case $I$(7).SPECTRUM:
case $I$(7).SPECTRUMNUMBER:
if (!p$1.setSpectrum$S.apply(this, [value])) isOK=false;
break;
case $I$(7).STACKOFFSETY:
p$1.execOverlayOffsetY$I.apply(this, [$I$(9,"parseInt$S",["" + new Double($I$(9).parseDouble$S(value)).toString()])]);
break;
case $I$(7).TEST:
this.si.siExecTest$S(value);
break;
case $I$(7).OVERLAY:
case $I$(7).VIEW:
this.execView$S$Z(value, true);
break;
case $I$(7).HIGHLIGHT:
isOK=p$1.highlight$S.apply(this, [token]);
break;
case $I$(7).FINDX:
case $I$(7).GETSOLUTIONCOLOR:
case $I$(7).INTEGRATION:
case $I$(7).INTEGRATE:
case $I$(7).IRMODE:
case $I$(7).LABEL:
case $I$(7).LINK:
case $I$(7).OVERLAYSTACKED:
case $I$(7).PRINT:
case $I$(7).SETPEAK:
case $I$(7).SETX:
case $I$(7).SHIFTX:
case $I$(7).SHOWERRORS:
case $I$(7).SHOWMEASUREMENTS:
case $I$(7).SHOWMENU:
case $I$(7).SHOWKEY:
case $I$(7).SHOWPEAKLIST:
case $I$(7).SHOWINTEGRATION:
case $I$(7).SHOWPROPERTIES:
case $I$(7).SHOWSOURCE:
case $I$(7).YSCALE:
case $I$(7).WRITE:
case $I$(7).ZOOM:
if (p$1.isClosed.apply(this, [])) {
isOK=false;
break;
}switch (st) {
default:
break;
case $I$(7).FINDX:
this.pd$().findX$jspecview_common_Spectrum$D(null, Double.parseDouble$S(value));
break;
case $I$(7).GETSOLUTIONCOLOR:
p$1.show$S.apply(this, ["solutioncolor" + value.toLowerCase$()]);
break;
case $I$(7).INTEGRATION:
case $I$(7).INTEGRATE:
p$1.execIntegrate$S.apply(this, [value]);
break;
case $I$(7).IRMODE:
p$1.execIRMode$S.apply(this, [value]);
break;
case $I$(7).LABEL:
this.pd$().addAnnotation$javajs_util_Lst($I$(7).getTokens$S(value));
break;
case $I$(7).LINK:
this.pd$().linkSpectra$jspecview_common_PanelData_LinkMode($I$(11).getMode$S(value));
break;
case $I$(7).OVERLAYSTACKED:
this.pd$().splitStack$Z(!$I$(8).isTrue$S(value));
break;
case $I$(7).PRINT:
msg=p$1.execWrite$S.apply(this, [null]);
break;
case $I$(7).SETPEAK:
case $I$(7).SETX:
case $I$(7).SHIFTX:
p$1.execShiftSpectrum$jspecview_common_ScriptToken$S.apply(this, [st, token]);
break;
case $I$(7).SHOWERRORS:
p$1.show$S.apply(this, ["errors"]);
break;
case $I$(7).SHOWINTEGRATION:
this.pd$().showAnnotation$jspecview_common_Annotation_AType$Boolean($I$(12).Integration, $I$(8).getTFToggle$S(value));
break;
case $I$(7).SHOWKEY:
p$1.setOverlayLegendVisibility$Boolean$Z.apply(this, [$I$(8).getTFToggle$S(value), true]);
break;
case $I$(7).SHOWMEASUREMENTS:
this.pd$().showAnnotation$jspecview_common_Annotation_AType$Boolean($I$(12).Measurements, $I$(8).getTFToggle$S(value));
break;
case $I$(7).SHOWMENU:
this.showMenu$I$I(-2147483648, 0);
break;
case $I$(7).SHOWPEAKLIST:
this.pd$().showAnnotation$jspecview_common_Annotation_AType$Boolean($I$(12).PeakList, $I$(8).getTFToggle$S(value));
break;
case $I$(7).SHOWPROPERTIES:
p$1.show$S.apply(this, ["properties"]);
break;
case $I$(7).SHOWSOURCE:
p$1.show$S.apply(this, ["source"]);
break;
case $I$(7).YSCALE:
p$1.setYScale$S.apply(this, [value]);
break;
case $I$(7).WINDOW:
this.si.siNewWindow$Z$Z($I$(8).isTrue$S(value), false);
break;
case $I$(7).WRITE:
msg=p$1.execWrite$S.apply(this, [value]);
break;
case $I$(7).ZOOM:
isOK=p$1.execZoom$S.apply(this, [value]);
break;
}
break;
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
msg=e.toString();
$I$(5,"error$S",[e.toString()]);
isOK=false;
--nErrorsLeft;
} else {
throw e;
}
}
}
--this.scriptLevelCount;
this.si.siExecScriptComplete$S$Z(msg, true);
return isOK;
});

Clazz.newMeth(C$, 'execShiftSpectrum$jspecview_common_ScriptToken$S',  function (st, script) {
var tokens=$I$(7).getTokens$S(script);
var xOld=NaN;
var xNew=NaN;
switch (tokens.size$()) {
case 2:
var value=tokens.get$I(1);
if (value.equals$O("")) value="?";
xNew=value.equalsIgnoreCase$S("NONE") ? 1.7976931348623157E308 : value.equalsIgnoreCase$S("?") ? NaN : Double.parseDouble$S(value);
break;
case 3:
xOld=Double.parseDouble$S(tokens.get$I(1));
xNew=Double.parseDouble$S(tokens.get$I(2));
break;
default:
Double.parseDouble$S("");
}
var mode=0;
switch (st) {
case $I$(7).SETPEAK:
mode=1;
break;
case $I$(7).SETX:
mode=2;
break;
case $I$(7).SHIFTX:
mode=3;
if (Double.isNaN$D(xNew)) Double.parseDouble$S("");
break;
default:
return;
}
this.pd$().shiftSpectrum$I$D$D(mode, xOld, xNew);
}, p$1);

Clazz.newMeth(C$, 'execClose$S',  function (value) {
var fromScript=(!value.startsWith$S("!"));
if (!fromScript) value=value.substring$I(1);
this.close$S($I$(9).trimQuotes$S(value));
if (!fromScript || this.panelNodes.size$() == 0 ) this.si.siValidateAndRepaint$Z(true);
}, p$1);

Clazz.newMeth(C$, 'checkOvelayInterface$S',  function (value) {
return (value.equalsIgnoreCase$S("single") || value.equalsIgnoreCase$S("overlay") );
});

Clazz.newMeth(C$, 'execPeak$S',  function (value) {
try {
var tokens=$I$(7,"getTokens$S",[$I$(9,"rep$S$S$S",[value, "#", "INDEX="])]);
value=" type=\"" + tokens.get$I(0).toUpperCase$() + "\" _match=\"" + $I$(9,"trimQuotes$S",[tokens.get$I(1).toUpperCase$()]) + "\"" ;
if (tokens.size$() > 2 && tokens.get$I(2).equalsIgnoreCase$S("all") ) value+=" title=\"ALL\"";
this.processPeakPickEvent$O$Z(Clazz.new_($I$(13,1).c$$S,[value]), false);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'execPeakList$S',  function (value) {
var p=this.parameters;
var b=$I$(8).getTFToggle$S(value);
if (value.indexOf$S("=") < 0) {
if (!p$1.isClosed.apply(this, [])) this.pd$().getPeakListing$jspecview_common_Parameters$Boolean(null, b);
} else {
var tokens=$I$(7).getTokens$S(value);
var threshold=p.peakListThreshold;
var interp=p.peakListInterpolation;
try {
for (var i=tokens.size$(); --i >= 0; ) {
var token=tokens.get$I(i);
var pt=token.indexOf$S("=");
if (pt <= 0) continue;
var key=token.substring$I$I(0, pt);
value=token.substring$I(pt + 1);
if (key.startsWith$S("thr")) {
threshold=Double.valueOf$S(value).doubleValue$();
} else if (key.startsWith$S("int")) {
interp=(value.equalsIgnoreCase$S("none") ? "NONE" : "parabolic");
}}
p.peakListThreshold=threshold;
p.peakListInterpolation=interp;
if (!p$1.isClosed.apply(this, [])) this.pd$().getPeakListing$jspecview_common_Parameters$Boolean(p, Boolean.TRUE);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}}, p$1);

Clazz.newMeth(C$, 'highlight$S',  function (value) {
var tokens=$I$(7).getTokens$S(value);
var n=tokens.size$();
switch (n) {
case 3:
case 5:
case 6:
case 7:
break;
case 2:
case 4:
if (tokens.get$I(n - 1).equalsIgnoreCase$S("OFF")) break;
default:
return false;
}
if (!p$1.isClosed.apply(this, [])) {
var x1=(n > 1 ? $I$(9,"parseDouble$S",[tokens.get$I(1)]) : NaN);
var x2=(n > 2 ? $I$(9,"parseDouble$S",[tokens.get$I(2)]) : NaN);
var r=p$1.getRGB$S.apply(this, [n > 3 ? tokens.get$I(3) : "100"]);
var g=p$1.getRGB$S.apply(this, [n > 4 ? tokens.get$I(4) : "100"]);
var b=p$1.getRGB$S.apply(this, [n > 5 ? tokens.get$I(5) : "100"]);
var a=p$1.getRGB$S.apply(this, [n > 6 ? tokens.get$I(6) : "100"]);
if (Double.isNaN$D(x1) || Double.isNaN$D(x2) ) {
this.pd$().removeAllHighlights$();
} else {
this.pd$().removeHighlight$D$D(x1, x2);
if (a < 0) a=150;
if (r >= 0 && g >= 0  && b >= 0 ) this.pd$().addHighlight$jspecview_common_GraphSet$D$D$jspecview_common_Spectrum$I$I$I$I(null, x1, x2, null, r, g, b, a);
}p$1.repaint$Z.apply(this, [true]);
}return true;
}, p$1);

Clazz.newMeth(C$, 'getRGB$S',  function (s) {
var f=$I$(9).parseDouble$S(s);
return ((Double.isNaN$D(f) ? -1 : f > 1  ? f : f * 255)|0);
}, p$1);

Clazz.newMeth(C$, 'execZoom$S',  function (value) {
var x1=0;
var x2=0;
var y1=0;
var y2=0;
value=$I$(9).rep$S$S$S(value, " - ", " ").replace$C$C(",", " ");
var tokens=$I$(7).getTokens$S(value);
switch (tokens.size$()) {
default:
return false;
case 0:
var v=this.pd$().getCurrentGraphSet$().getCurrentView$();
value=new Float(Math.round$D(v.minXOnScale * 100) / 100.0).toString() + "," + new Float(Math.round$D(v.maxXOnScale * 100) / 100.0).toString();
value=this.selectedPanel.getInput$S$S$S("Enter zoom range x1 x2", "Zoom", value);
return (value == null  || p$1.execZoom$S.apply(this, [value]) );
case 1:
value=tokens.get$I(0);
if (value.equalsIgnoreCase$S("next")) {
this.pd$().nextView$();
} else if (value.toLowerCase$().startsWith$S("prev")) {
this.pd$().previousView$();
} else if (value.equalsIgnoreCase$S("out")) {
this.pd$().resetView$();
} else if (value.equalsIgnoreCase$S("clear")) {
this.pd$().clearAllView$();
} else if (value.equalsIgnoreCase$S("invertY")) {
this.pd$().getCurrentGraphSet$().invertYAxis$();
}return true;
case 2:
x1=Double.parseDouble$S(tokens.get$I(0));
x2=Double.parseDouble$S(tokens.get$I(1));
break;
case 3:
var xy=tokens.get$I(0);
if (xy.equalsIgnoreCase$S("X")) {
x1=Double.parseDouble$S(tokens.get$I(1));
x2=Double.parseDouble$S(tokens.get$I(2));
} else if (xy.equalsIgnoreCase$S("Y")) {
y1=Double.parseDouble$S(tokens.get$I(1));
y2=Double.parseDouble$S(tokens.get$I(2));
}break;
case 4:
x1=Double.parseDouble$S(tokens.get$I(0));
y1=Double.parseDouble$S(tokens.get$I(1));
x2=Double.parseDouble$S(tokens.get$I(2));
y2=Double.parseDouble$S(tokens.get$I(3));
}
this.pd$().setZoom$D$D$D$D(x1, y1, x2, y2);
return true;
}, p$1);

Clazz.newMeth(C$, 'scaleSelectedBy$javajs_util_Lst$S',  function (nodes, value) {
try {
var f=Double.parseDouble$S(value);
for (var i=nodes.size$(); --i >= 0; ) nodes.get$I(i).pd$().scaleSelectedBy$D(f);

} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'pd$',  function () {
return (this.selectedPanel == null  ? null : this.selectedPanel.getPanelData$());
});

Clazz.newMeth(C$, 'isClosed',  function () {
return (this.pd$() == null );
}, p$1);

Clazz.newMeth(C$, 'execSelect$S',  function (value) {
if (value.startsWith$S("ID ")) {
if (!p$1.isClosed.apply(this, [])) try {
this.pd$().selectSpectrum$S$S$S$Z(null, "ID", $I$(9,"trimQuotes$S",[value.substring$I(3)]), true);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
return;
}var nodes=this.panelNodes;
for (var i=nodes.size$(); --i >= 0; ) nodes.get$I(i).pd$().selectFromEntireSet$I(-2147483648);

var speclist=Clazz.new_($I$(3,1));
p$1.fillSpecList$S$javajs_util_Lst$Z.apply(this, [value, speclist, false]);
}, p$1);

Clazz.newMeth(C$, 'execView$S$Z',  function (value, fromScript) {
if (value.equals$O("")) {
this.checkOverlay$();
return;
}var speclist=Clazz.new_($I$(3,1));
var strlist=p$1.fillSpecList$S$javajs_util_Lst$Z.apply(this, [value, speclist, true]);
if (speclist.size$() > 0) this.si.siOpenDataOrFile$O$S$javajs_util_Lst$S$I$I$Z$S$S(null, strlist, speclist, strlist, -1, -1, false, null, null);
if (!fromScript) {
this.si.siValidateAndRepaint$Z(false);
}});

Clazz.newMeth(C$, 'execIRMode$S',  function (value) {
var mode=$I$(1).getMode$S(value);
var type=this.pd$().getSpectrum$().dataType;
for (var i=this.panelNodes.size$(); --i >= 0; ) this.panelNodes.get$I(i).pd$().setIRMode$jspecview_common_Spectrum_IRMode$S(mode, type);

this.setIRmode$S(value);
}, p$1);

Clazz.newMeth(C$, 'execIntegrate$S',  function (value) {
if (p$1.isClosed.apply(this, [])) return;
this.pd$().checkIntegral$jspecview_common_Parameters$S(this.parameters, value);
if (this.integrationRatios != null ) this.pd$().setIntegrationRatios$S(this.integrationRatios);
this.integrationRatios=null;
p$1.repaint$Z.apply(this, [true]);
}, p$1);

Clazz.newMeth(C$, 'repaint$Z',  function (andTaintAll) {
this.selectedPanel.doRepaint$Z(andTaintAll);
}, p$1);

Clazz.newMeth(C$, 'execSetIntegralParameter$jspecview_common_ScriptToken$D',  function (st, value) {
var p=this.parameters;
switch (st) {
case $I$(7).INTEGRALRANGE:
p.integralRange=value;
break;
case $I$(7).INTEGRALOFFSET:
p.integralOffset=value;
break;
}
if (!p$1.isClosed.apply(this, [])) this.pd$().checkIntegral$jspecview_common_Parameters$S(this.parameters, "update");
}, p$1);

Clazz.newMeth(C$, 'setYScale$S',  function (value) {
var tokens=$I$(7).getTokens$S(value);
var pt=0;
var isAll=false;
if (tokens.size$() > 1 && tokens.get$I(0).equalsIgnoreCase$S("ALL") ) {
isAll=true;
++pt;
}var y1=Double.parseDouble$S(tokens.get$I(pt++));
var y2=Double.parseDouble$S(tokens.get$I(pt));
if (isAll) {
var spec=this.pd$().getSpectrum$();
for (var i=this.panelNodes.size$(); --i >= 0; ) {
var node=this.panelNodes.get$I(i);
if (node.source !== this.currentSource ) continue;
if ($I$(14,"areXScalesCompatible$jspecview_common_Spectrum$jspecview_common_Spectrum$Z$Z",[spec, node.getSpectrum$(), false, false])) node.pd$().setZoom$D$D$D$D(0, y1, 0, y2);
}
} else {
this.pd$().setZoom$D$D$D$D(0, y1, 0, y2);
}}, p$1);

Clazz.newMeth(C$, 'setOverlayLegendVisibility$Boolean$Z',  function (tftoggle, doSet) {
if (doSet) this.overlayLegendVisible=(tftoggle == null  ? !this.overlayLegendVisible : tftoggle === Boolean.TRUE );
var node=$I$(15).findNode$jspecview_api_JSVPanel$javajs_util_Lst(this.selectedPanel, this.panelNodes);
for (var i=this.panelNodes.size$(); --i >= 0; ) p$1.showOverlayLegend$jspecview_common_PanelNode$Z.apply(this, [this.panelNodes.get$I(i), this.panelNodes.get$I(i) === node  && this.overlayLegendVisible ]);

}, p$1);

Clazz.newMeth(C$, 'showOverlayLegend$jspecview_common_PanelNode$Z',  function (node, visible) {
var legend=node.legend;
if (legend == null  && visible ) {
legend=node.setLegend$jspecview_dialog_JSVDialog(node.pd$().getNumberOfSpectraInCurrentSet$() > 1 && node.pd$().getNumberOfGraphSets$() == 1  ? this.getDialog$jspecview_common_Annotation_AType$jspecview_common_Spectrum($I$(12).OverlayLegend, null) : null);
}if (legend != null ) legend.setVisible$Z(visible);
}, p$1);

Clazz.newMeth(C$, 'syncScript$S',  function (peakScript) {
if (peakScript.equals$O("TEST")) peakScript=C$.testScript;
$I$(5).info$S("JSViewer.syncScript Jmol>JSV " + peakScript);
if (peakScript.indexOf$S("<PeakData") < 0) {
if (peakScript.startsWith$S("JSVSTR:")) {
this.si.syncToJmol$S(peakScript);
return;
}this.runScriptNow$S(peakScript);
if (peakScript.indexOf$S("#SYNC_PEAKS") >= 0) p$1.syncPeaksAfterSyncScript.apply(this, []);
return;
}$I$(5).info$S(">>toJSV>> " + peakScript);
var sourceID=$I$(9).getQuotedAttribute$S$S(peakScript, "sourceID");
var type;
var model;
var file;
var jmolSource;
var index;
var atomKey;
if (sourceID == null ) {
file=$I$(9).getQuotedAttribute$S$S(peakScript, "file");
index=$I$(9).getQuotedAttribute$S$S(peakScript, "index");
if (file == null  || index == null  ) return;
file=$I$(9).rep$S$S$S(file, "#molfile", "");
model=$I$(9).getQuotedAttribute$S$S(peakScript, "model");
jmolSource=$I$(9).getQuotedAttribute$S$S(peakScript, "src");
var modelSent=(jmolSource != null  && jmolSource.startsWith$S("Jmol")  ? null : this.returnFromJmolModel);
if (model != null  && modelSent != null   && !model.equals$O(modelSent) ) {
$I$(5).info$S("JSV ignoring model " + model + "; should be " + modelSent );
return;
}this.returnFromJmolModel=null;
if (this.panelNodes.size$() == 0 || !p$1.checkFileAlreadyLoaded$S.apply(this, [file]) ) {
$I$(5).info$S("file " + file + " not found -- JSViewer closing all and reopening" );
this.si.siSyncLoad$S(file);
}type=$I$(9).getQuotedAttribute$S$S(peakScript, "type");
atomKey=null;
} else {
file=null;
index=model=sourceID;
atomKey="," + $I$(9).getQuotedAttribute$S$S(peakScript, "atom") + "," ;
type="ID";
jmolSource=sourceID;
}var pi=p$1.selectPanelByPeak$S$S$S.apply(this, [file, index, atomKey]);
var pd=this.pd$();
pd.selectSpectrum$S$S$S$Z(file, type, model, true);
this.si.siSendPanelChange$();
pd.addPeakHighlight$jspecview_common_PeakInfo(pi);
p$1.repaint$Z.apply(this, [true]);
if (jmolSource == null  || (pi != null  && pi.getAtoms$() != null  ) ) this.si.syncToJmol$S(p$1.jmolSelect$jspecview_common_PeakInfo.apply(this, [pi]));
});

Clazz.newMeth(C$, 'syncPeaksAfterSyncScript',  function () {
var source=this.currentSource;
if (source == null ) return;
try {
var file="file=" + $I$(9,"esc$S",[source.getFilePath$()]);
var peaks=source.getSpectra$().get$I(0).getPeakList$();
var sb=Clazz.new_($I$(16,1));
sb.append$S("[");
var n=peaks.size$();
for (var i=0; i < n; i++) {
var s=peaks.get$I(i).toString();
s=s + " " + file ;
sb.append$S($I$(9).esc$S(s));
if (i > 0) sb.append$S(",");
}
sb.append$S("]");
this.si.syncToJmol$S("Peaks: " + sb);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'checkFileAlreadyLoaded$S',  function (fileName) {
if (p$1.isClosed.apply(this, [])) return false;
if (this.pd$().hasFileLoaded$S(fileName)) return true;
for (var i=this.panelNodes.size$(); --i >= 0; ) if (this.panelNodes.get$I(i).pd$().hasFileLoaded$S(fileName)) {
this.si.siSetSelectedPanel$jspecview_api_JSVPanel(this.panelNodes.get$I(i).jsvp);
return true;
}
return false;
}, p$1);

Clazz.newMeth(C$, 'selectPanelByPeak$S$S$S',  function (file, index, atomKey) {
if (this.panelNodes == null ) return null;
var pi=null;
for (var i=this.panelNodes.size$(); --i >= 0; ) this.panelNodes.get$I(i).pd$().addPeakHighlight$jspecview_common_PeakInfo(null);

pi=this.pd$().selectPeakByFileIndex$S$S$S(file, index, atomKey);
if (pi != null ) {
this.setNode$jspecview_common_PanelNode($I$(15).findNode$jspecview_api_JSVPanel$javajs_util_Lst(this.selectedPanel, this.panelNodes));
} else {
for (var i=this.panelNodes.size$(); --i >= 0; ) {
var node=this.panelNodes.get$I(i);
if ((pi=node.pd$().selectPeakByFileIndex$S$S$S(file, index, atomKey)) != null ) {
this.setNode$jspecview_common_PanelNode(node);
break;
}}
}return pi;
}, p$1);

Clazz.newMeth(C$, 'processPeakPickEvent$O$Z',  function (eventObj, isApp) {
var pi;
if (Clazz.instanceOf(eventObj, "jspecview.common.PeakInfo")) {
pi=eventObj;
var pi2=this.pd$().findMatchingPeakInfo$jspecview_common_PeakInfo(pi);
if (pi2 == null ) {
if (!"ALL".equals$O(pi.getTitle$())) return;
var node=null;
for (var i=0; i < this.panelNodes.size$(); i++) if ((pi2=this.panelNodes.get$I(i).pd$().findMatchingPeakInfo$jspecview_common_PeakInfo(pi)) != null ) {
node=this.panelNodes.get$I(i);
break;
}
if (node == null ) return;
this.setNode$jspecview_common_PanelNode(node);
}pi=pi2;
} else {
var e=(eventObj);
this.si.siSetSelectedPanel$jspecview_api_JSVPanel(e.getSource$());
pi=e.getPeakInfo$();
}this.pd$().addPeakHighlight$jspecview_common_PeakInfo(pi);
p$1.syncToJmol$jspecview_common_PeakInfo.apply(this, [pi]);
if (pi.isClearAll$()) p$1.repaint$Z.apply(this, [false]);
 else this.pd$().selectSpectrum$S$S$S$Z(pi.getFilePath$(), pi.getType$(), pi.getModel$(), true);
this.si.siCheckCallbacks$S(pi.getTitle$());
});

Clazz.newMeth(C$, 'newStructToJmol$S',  function (data) {
$I$(5).info$S("sending new structure to Jmol:\n" + data);
this.si.syncToJmol$S("struct:" + data);
});

Clazz.newMeth(C$, 'syncToJmol$jspecview_common_PeakInfo',  function (pi) {
p$1.repaint$Z.apply(this, [true]);
this.returnFromJmolModel=pi.getModel$();
this.si.syncToJmol$S(p$1.jmolSelect$jspecview_common_PeakInfo.apply(this, [pi]));
}, p$1);

Clazz.newMeth(C$, 'sendPanelChange$',  function () {
var pd=this.pd$();
var spec=pd.getSpectrum$();
var pi=spec.getSelectedPeak$();
if (pi == null ) pi=spec.getModelPeakInfoForAutoSelectOnLoad$();
if (pi == null ) pi=spec.getBasePeakInfo$();
pd.addPeakHighlight$jspecview_common_PeakInfo(pi);
$I$(5,"info$S",[$I$(17).currentThread$() + "JSViewer sendFrameChange " + this.selectedPanel ]);
p$1.syncToJmol$jspecview_common_PeakInfo.apply(this, [pi]);
});

Clazz.newMeth(C$, 'jmolSelect$jspecview_common_PeakInfo',  function (pi) {
var script=("IR".equals$O(pi.getType$()) || "RAMAN".equals$O(pi.getType$())  ? "vibration ON; selectionHalos OFF;" : "vibration OFF; selectionhalos " + (pi.getAtoms$() == null  ? "OFF" : "ON"));
return "Select: " + pi + " script=\"" + script + " \" sourceID=\"" + this.pd$().getSpectrum$().sourceID + "\"" ;
}, p$1);

Clazz.newMeth(C$, 'getPropertyAsJavaObject$S',  function (key) {
var map=Clazz.new_($I$(18,1));
if ("SOURCEID".equalsIgnoreCase$S(key)) {
map.put$O$O(key, (this.pd$() == null  ? "" : this.pd$().getSpectrum$().sourceID));
return map;
}if (key != null  && key.startsWith$S("DATA_") ) {
map.put$O$O(key, "" + $I$(10,"cacheGet$S",[key.substring$I(5)]));
return map;
}var isAll=false;
if (key != null  && key.toUpperCase$().startsWith$S("ALL ")  || "all".equalsIgnoreCase$S(key) ) {
key=key.substring$I(3).trim$();
isAll=true;
}if ("".equals$O(key)) key=null;
if ("NAMES".equalsIgnoreCase$S(key) || "KEYS".equalsIgnoreCase$S(key) ) key="";
var map0=this.pd$().getInfo$Z$S(true, key);
if (!isAll && map0 != null  ) return map0;
if (map0 != null ) map.put$O$O("current", map0);
var info=Clazz.new_($I$(3,1));
for (var i=0; i < this.panelNodes.size$(); i++) {
var jsvp=this.panelNodes.get$I(i).jsvp;
if (jsvp == null ) continue;
info.addLast$O(this.panelNodes.get$I(i).getInfo$S(key));
}
map.put$O$O("items", info);
return map;
});

Clazz.newMeth(C$, 'getCoordinate$',  function () {
if (!p$1.isClosed.apply(this, [])) {
var coord=this.pd$().getClickedCoordinate$();
if (coord != null ) return new Double(coord.getXVal$()).toString() + " " + new Double(coord.getYVal$()).toString() ;
}return "";
});

Clazz.newMeth(C$, 'fillSpecList$S$javajs_util_Lst$Z',  function (value, speclist, isView) {
var prefix="1.";
var list;
var list0=null;
var isNone=(value.equalsIgnoreCase$S("NONE"));
if (isNone || value.equalsIgnoreCase$S("all") ) value="*";
if (value.indexOf$S("*") < 0) {
var tokens=value.split$S(" ");
var sb=Clazz.new_($I$(16,1));
for (var i=0; i < tokens.length; i++) {
var pt=tokens[i].indexOf$I(".");
if (pt != tokens[i].lastIndexOf$I(".")) tokens[i]=tokens[i].substring$I$I(0, pt + 1) + tokens[i].substring$I(pt + 1).replace$C$C(".", "_");
sb.append$S(tokens[i]).append$S(" ");
}
value=sb.toString().trim$();
}if (value.equals$O("*")) {
list=$I$(7,"getTokens$S",[$I$(15).getSpectrumListAsString$javajs_util_Lst(this.panelNodes)]);
} else if (value.startsWith$S("\"") || value.startsWith$S("\'") ) {
list=$I$(7).getTokens$S(value);
} else {
value=$I$(9).rep$S$S$S(value, "_", " _ ");
value=$I$(9).rep$S$S$S(value, "-", " - ");
list=$I$(7).getTokens$S(value);
list0=$I$(7,"getTokens$S",[$I$(15).getSpectrumListAsString$javajs_util_Lst(this.panelNodes)]);
if (list0.size$() == 0) return null;
}var id0=(p$1.isClosed.apply(this, []) ? prefix : $I$(15).findNode$jspecview_api_JSVPanel$javajs_util_Lst(this.selectedPanel, this.panelNodes).id);
id0=id0.substring$I$I(0, id0.indexOf$S(".") + 1);
var sb=Clazz.new_($I$(16,1));
var n=list.size$();
var idLast=null;
for (var i=0; i < n; i++) {
var id=list.get$I(i);
var userYFactor=NaN;
var isubspec=-1;
if (i + 1 < n && list.get$I(i + 1).equals$O("*") ) {
i+=2;
userYFactor=Double.parseDouble$S(list.get$I(i));
} else if (i + 1 < n && list.get$I(i + 1).equals$O("_") ) {
i+=2;
isubspec=Integer.parseInt$S(list.get$I(i));
}if (id.equals$O("-")) {
if (idLast == null ) idLast=list0.get$I(0);
id=(i + 1 == n ? list0.get$I(list0.size$() - 1) : list.get$I(++i));
if (!id.contains$CharSequence(".")) id=id0 + id;
var pt=0;
while (pt < list0.size$() && !list0.get$I(pt).equals$O(idLast) )++pt;

++pt;
while (pt < list0.size$() && !idLast.equals$O(id) ){
var node=$I$(15,"findNodeById$S$javajs_util_Lst",[(idLast=list0.get$I(pt++)), this.panelNodes]);
speclist.addLast$O(node.pd$().getSpectrumAt$I(0));
sb.append$S(",").append$S(idLast);
}
continue;
}var node;
if (id.startsWith$S("\'") && id.endsWith$S("\'") ) id="\"" + $I$(9).trim$S$S(id, "\'") + "\"" ;
if (id.startsWith$S("\"")) {
id=$I$(9).trim$S$S(id, "\"");
var pn=this.panelNodes.size$();
for (var j=0; j < pn; j++) {
node=this.panelNodes.get$I(j);
if (node.fileName != null  && node.fileName.startsWith$S(id)  || node.frameTitle != null  && node.frameTitle.startsWith$S(id)  ) {
p$1.addSpecToList$jspecview_common_PanelData$D$I$javajs_util_Lst$Z.apply(this, [node.pd$(), userYFactor, -1, speclist, isView]);
sb.append$S(",").append$S(node.id);
}}
continue;
}if (!id.contains$CharSequence(".")) id=id0 + id;
node=$I$(15).findNodeById$S$javajs_util_Lst(id, this.panelNodes);
if (node == null ) continue;
idLast=id;
p$1.addSpecToList$jspecview_common_PanelData$D$I$javajs_util_Lst$Z.apply(this, [node.pd$(), userYFactor, isubspec, speclist, isView]);
sb.append$S(",").append$S(id);
if (isubspec > 0) sb.append$S(".").appendI$I(isubspec);
}
if (isView && speclist.size$() > 0 ) {
var node=$I$(15,"findNodeById$S$javajs_util_Lst",[sb.substring$I(1), this.panelNodes]);
if (node != null ) {
this.setNode$jspecview_common_PanelNode(node);
speclist.clear$();
}}return (isNone ? "NONE" : sb.length$() > 0 ? sb.toString().substring$I(1) : null);
}, p$1);

Clazz.newMeth(C$, 'addSpecToList$jspecview_common_PanelData$D$I$javajs_util_Lst$Z',  function (pd, userYFactor, isubspec, list, isView) {
if (isView) {
var spec=pd.getSpectrumAt$I(0);
spec.setUserYFactor$D(Double.isNaN$D(userYFactor) ? 1 : userYFactor);
pd.addToList$I$javajs_util_Lst(isubspec - 1, list);
} else {
pd.selectFromEntireSet$I(isubspec - 1);
}}, p$1);

Clazz.newMeth(C$, 'getSolutionColor$Z',  function (asFitted) {
var spectrum=this.pd$().getSpectrum$();
var vi=(spectrum.canShowSolutionColor$() ? C$.getInterface$S("jspecview.common.Visible") : null);
return (vi == null  ? -1 : vi.getColour$jspecview_common_Spectrum$Z(spectrum, asFitted));
});

Clazz.newMeth(C$, 'openDataOrFile$O$S$javajs_util_Lst$S$I$I$Z$S',  function (data, name, specs, strUrl, firstSpec, lastSpec, isAppend, id) {
if ("NONE".equals$O(name)) {
this.close$S("View*");
return 0;
}this.si.writeStatus$S("");
var filePath=null;
var newPath=null;
var fileName=null;
var isView=false;
if (strUrl != null  && strUrl.startsWith$S("cache://") ) {
{
data = Jmol.Cache.get(name = strUrl);
}
}var file=null;
if (data != null ) {
try {
fileName=name;
newPath=filePath=$I$(10).getFullPathName$S(name);
} catch (e) {
if (Clazz.exceptionOf(e,"jspecview.exception.JSVException")){
} else {
throw e;
}
}
} else if (specs != null ) {
isView=true;
newPath=fileName=filePath="View" + (++this.nViews);
} else if (strUrl != null ) {
try {
file=this.apiPlatform.newFile$S(strUrl);
var u=Clazz.new_([$I$(10).appletDocumentBase, strUrl, null],$I$(19,1).c$$java_net_URL$S$java_net_URLStreamHandler);
filePath=u.toString();
this.recentURL=filePath;
fileName=$I$(10).getTagName$S(filePath);
} catch (e) {
if (Clazz.exceptionOf(e,"java.net.MalformedURLException")){
fileName=file.getName$();
newPath=filePath=file.getFullPath$();
this.recentURL=null;
} else {
throw e;
}
}
}var pt=-1;
if ((pt=$I$(15).isOpen$javajs_util_Lst$S(this.panelNodes, filePath)) >= 0 || (pt=$I$(15).isOpen$javajs_util_Lst$S(this.panelNodes, strUrl)) >= 0 ) {
if (isView) {
--this.nViews;
this.setNode$jspecview_common_PanelNode(this.panelNodes.get$I(pt));
} else {
this.si.writeStatus$S(filePath + " is already open");
}return -1;
}if (!isAppend && !isView ) this.close$S("all");
this.si.setCursor$I(3);
try {
this.si.siSetCurrentSource$jspecview_source_JDXSource(isView ? $I$(20).createView$javajs_util_Lst(specs) : $I$(21,"createJDXSource$org_jmol_api_GenericFileInterface$O$S$Z$Z$I$I$D",[file, data, filePath, this.obscureTitleFromUser === Boolean.TRUE , this.loadImaginary, firstSpec, lastSpec, this.nmrMaxY]));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
{
alert(e.toString())
}
this.si.setCursor$I(0);
if (this.isApplet) {
this.selectedPanel.showMessage$S$S(e.toString(), "Error Opening File");
}return -3;
} else {
throw e;
}
}
this.si.setCursor$I(0);
System.gc$();
if (newPath == null ) {
newPath=this.currentSource.getFilePath$();
if (newPath != null ) fileName=newPath.substring$I(newPath.lastIndexOf$S("/") + 1);
} else {
this.currentSource.setFilePath$S(newPath);
}if (id == null  && !isView ) id=newPath;
if (id != null ) this.currentSource.setID$S(id);
this.si.siSetLoaded$S$S(fileName, newPath);
var spec=this.currentSource.getJDXSpectrum$I(0);
if (spec == null ) {
return -4;
}specs=this.currentSource.getSpectra$();
$I$(14).process$javajs_util_Lst$jspecview_common_Spectrum_IRMode(specs, this.irMode);
var autoOverlay=this.interfaceOverlaid || spec.isAutoOverlayFromJmolClick$() ;
var combine=isView || autoOverlay && this.currentSource.isCompoundSource  ;
if (combine) {
this.combineSpectra$S((isView ? strUrl : null));
} else {
this.splitSpectra$();
}this.pd$().setTaintedAll$();
if (!isView) this.si.siUpdateRecentMenus$S(filePath);
return 0;
});

Clazz.newMeth(C$, 'close$S',  function (value) {
var n0=0;
var pt=(value == null  ? -2 : value.indexOf$S(">"));
if (pt > 0) {
n0=$I$(9,"parseInt$S",[value.substring$I(pt + 1).trim$()]);
value=value.substring$I$I(0, pt).trim$();
}if ("*".equals$O(value)) value="all";
var isAll=(value === "all" );
if (value == null  || n0 == 0 && value.equalsIgnoreCase$S("all")  ) {
this.closeSource$jspecview_source_JDXSource(null);
return;
}var isViews=value.equalsIgnoreCase$S("views");
var list=Clazz.new_($I$(3,1));
var source;
value=value.replace$C$C("\\", "/");
var n=this.panelNodes.size$();
var nMax=n - n0;
if (value.endsWith$S("*")) {
value=value.substring$I$I(0, value.length$() - 1);
for (var i=n; --i >= 0; ) if (this.panelNodes.get$I(i).fileName.startsWith$S(value)) list.addLast$O(this.panelNodes.get$I(i).source);

} else if (value.equalsIgnoreCase$S("selected")) {
var lastSource=null;
for (var i=n; --i >= 0; ) {
source=this.panelNodes.get$I(i).source;
if (this.panelNodes.get$I(i).isSelected && (lastSource == null  || lastSource !== source  ) ) list.addLast$O(source);
lastSource=source;
}
} else if (isAll || isViews || value.equalsIgnoreCase$S("simulations")  ) {
for (var n1=0, i=n; --i >= 0 && n1 < nMax ; ) if (isAll ? true : isViews ? this.panelNodes.get$I(i).isView : this.panelNodes.get$I(i).isSimulation) {
list.addLast$O(this.panelNodes.get$I(i).source);
++n1;
}
} else {
source=(value.length$() == 0 ? this.currentSource : $I$(15).findSourceByNameOrId$S$javajs_util_Lst(value, this.panelNodes));
if (source != null ) list.addLast$O(source);
}for (var i=list.size$(); --i >= 0; ) this.closeSource$jspecview_source_JDXSource(list.get$I(i));

if (this.selectedPanel == null  && this.panelNodes.size$() > 0 ) this.si.siSetSelectedPanel$jspecview_api_JSVPanel($I$(15).getLastFileFirstNode$javajs_util_Lst(this.panelNodes));
});

Clazz.newMeth(C$, 'execLoad$S$S',  function (value, script) {
var applet=this.html5Applet;
var isID=false;

isID = (applet && applet._viewSet != null && !value.startsWith("ID"));
if (isID) {
applet._search(value);
return;
}var tokens=$I$(7).getTokens$S(value);
var filename=tokens.get$I(0);
var id=null;
var pt=0;
if (filename.equalsIgnoreCase$S("ID")) {
id=$I$(9,"trimQuotes$S",[tokens.get$I(1)]);
filename=tokens.get$I(2);
pt=2;
}var isAppend=filename.equalsIgnoreCase$S("APPEND");
var isCheck=filename.equalsIgnoreCase$S("CHECK");
if (isAppend || isCheck ) ++pt;
if (pt > 0) filename=tokens.get$I(pt);
if (script == null ) script=this.defaultLoadScript;
if (filename.equals$O("?")) {
this.openFileFromDialog$Z$Z$S$S(isAppend, false, null, script);
return;
}if (filename.equals$O("http://?")) {
this.openFileFromDialog$Z$Z$S$S(isAppend, true, null, null);
return;
}if (filename.equals$O("$?") || filename.equals$O("$H1?") ) {
this.openFileFromDialog$Z$Z$S$S(isAppend, true, "H1", null);
return;
}if (filename.equals$O("$C13?")) {
this.openFileFromDialog$Z$Z$S$S(isAppend, true, "C13", null);
return;
}var isH1=filename.equalsIgnoreCase$S("MOL") || filename.equalsIgnoreCase$S("H1") ;
var isC13=filename.equalsIgnoreCase$S("C13");
if (isH1 || isC13 ) filename="http://SIMULATION/" + (isH1 ? "H1/" : "C13/") + "MOL=" + $I$(9,"trimQuotes$S",[tokens.get$I(++pt)]) ;
if (!isCheck && !isAppend ) {
if (filename.equals$O("\"\"") && this.currentSource != null  ) filename=this.currentSource.getFilePath$();
this.close$S("all");
}filename=$I$(9).trimQuotes$S(filename);
var isSimulation=filename.startsWith$S("$");
if (isSimulation) {
if (!filename.startsWith$S("$H1") && !filename.startsWith$S("$C13") ) filename="$H1/" + filename.substring$I(1);
filename="http://SIMULATION/" + filename.substring$I(1);
}var firstSpec=(pt + 1 < tokens.size$() ? Integer.valueOf$S(tokens.get$I(++pt)).intValue$() : -1);
var lastSpec=(pt + 1 < tokens.size$() ? Integer.valueOf$S(tokens.get$I(++pt)).intValue$() : firstSpec);
this.si.siOpenDataOrFile$O$S$javajs_util_Lst$S$I$I$Z$S$S(null, null, null, filename, firstSpec, lastSpec, isAppend, script, id);
if (isSimulation) {
this.close$S("views");
this.execView$S$Z("*", true);
}});

Clazz.newMeth(C$, 'combineSpectra$S',  function (name) {
var source=this.currentSource;
var specs=source.getSpectra$();
var haveSimulation=false;
for (var i=specs.size$(); --i >= 0; ) if (specs.get$I(i).isSimulation) {
haveSimulation=true;
break;
}
var jsvp=this.si.siGetNewJSVPanel2$javajs_util_Lst(specs);
jsvp.setTitle$S(source.getTitle$());
if (jsvp.getTitle$().equals$O("")) {
jsvp.getPanelData$().setViewTitle$S(source.getFilePath$());
jsvp.setTitle$S(name);
}this.si.siSetPropertiesFromPreferences$jspecview_api_JSVPanel$Z(jsvp, true);
this.spectraTree.createTree$I$jspecview_source_JDXSource$jspecview_api_JSVPanelA(++this.fileCount, source, Clazz.array($I$(22), -1, [jsvp])).getPanelNode$().isView=true;
var node=$I$(15).findNode$jspecview_api_JSVPanel$javajs_util_Lst(this.selectedPanel, this.panelNodes);
node.setFrameTitle$S(name);
node.isView=true;
if (this.autoShowLegend && this.pd$().getNumberOfGraphSets$() == 1 ) node.setLegend$jspecview_dialog_JSVDialog(this.getDialog$jspecview_common_Annotation_AType$jspecview_common_Spectrum($I$(12).OverlayLegend, null));
this.si.siSetMenuEnables$jspecview_common_PanelNode$Z(node, false);
if (haveSimulation) this.pd$().splitStack$Z(true);
});

Clazz.newMeth(C$, 'closeSource$jspecview_source_JDXSource',  function (source) {
var rootNode=this.spectraTree.getRootNode$();
var fileName=(source == null  ? null : source.getFilePath$());
var toDelete=Clazz.new_($I$(3,1));
var enume=rootNode.children$();
while (enume.hasMoreElements$()){
var node=enume.nextElement$();
if (fileName == null  || node.getPanelNode$().source.matchesFilePath$S(fileName) ) {
$I$(5,"info$S",["Closing " + node.getPanelNode$().source.getFilePath$()]);
for (var e=node.children$(); e.hasMoreElements$(); ) {
var childNode=e.nextElement$();
toDelete.addLast$O(childNode);
this.panelNodes.removeObj$O(childNode.getPanelNode$());
}
toDelete.addLast$O(node);
if (fileName != null ) break;
}}
this.spectraTree.deleteNodes$javajs_util_Lst(toDelete);
if (source == null ) {
if (this.currentSource != null ) this.currentSource.dispose$();
this.currentSource=null;
if (this.selectedPanel != null ) this.selectedPanel.dispose$();
} else {
}if (this.currentSource === source ) {
this.si.siSetSelectedPanel$jspecview_api_JSVPanel(null);
this.si.siSetCurrentSource$jspecview_source_JDXSource(null);
}var max=0;
for (var i=0; i < this.panelNodes.size$(); i++) {
var f=$I$(9,"parseDouble$S",[this.panelNodes.get$I(i).id]);
if (f >= max + 1 ) max=(Math.floor(f)|0);
}
this.fileCount=max;
System.gc$();
if ($I$(5).debugging) $I$(5).checkMemory$();
this.si.siSourceClosed$jspecview_source_JDXSource(source);
});

Clazz.newMeth(C$, 'setFrameAndTreeNode$I',  function (i) {
if (this.panelNodes == null  || i < 0  || i >= this.panelNodes.size$() ) return;
this.setNode$jspecview_common_PanelNode(this.panelNodes.get$I(i));
});

Clazz.newMeth(C$, 'selectFrameNode$jspecview_api_JSVPanel',  function (jsvp) {
var node=$I$(15).findNode$jspecview_api_JSVPanel$javajs_util_Lst(jsvp, this.panelNodes);
if (node == null ) return null;
this.spectraTree.setPath$jspecview_api_JSVTreePath(this.spectraTree.newTreePath$OA(node.treeNode.getPath$()));
p$1.setOverlayLegendVisibility$Boolean$Z.apply(this, [null, false]);
return node;
});

Clazz.newMeth(C$, 'setSpectrum$S',  function (value) {
if (value.indexOf$I(".") >= 0) {
var node=$I$(15).findNodeById$S$javajs_util_Lst(value, this.panelNodes);
if (node == null ) return false;
this.setNode$jspecview_common_PanelNode(node);
} else {
var n=$I$(9).parseInt$S(value);
if (n <= 0) {
this.checkOverlay$();
return false;
}this.setFrameAndTreeNode$I(n - 1);
}return true;
}, p$1);

Clazz.newMeth(C$, 'splitSpectra$',  function () {
var source=this.currentSource;
var specs=source.getSpectra$();
var panels=Clazz.array($I$(22), [specs.size$()]);
var jsvp=null;
for (var i=0; i < specs.size$(); i++) {
var spec=specs.get$I(i);
jsvp=this.si.siGetNewJSVPanel$jspecview_common_Spectrum(spec);
this.si.siSetPropertiesFromPreferences$jspecview_api_JSVPanel$Z(jsvp, true);
panels[i]=jsvp;
}
this.spectraTree.createTree$I$jspecview_source_JDXSource$jspecview_api_JSVPanelA(++this.fileCount, source, panels);
this.si.siGetNewJSVPanel$jspecview_common_Spectrum(null);
var node=$I$(15).findNode$jspecview_api_JSVPanel$javajs_util_Lst(this.selectedPanel, this.panelNodes);
this.si.siSetMenuEnables$jspecview_common_PanelNode$Z(node, true);
});

Clazz.newMeth(C$, 'selectedTreeNode$jspecview_api_JSVTreeNode',  function (node) {
if (node == null ) {
return;
}if (node.isLeaf$()) {
this.setNode$jspecview_common_PanelNode(node.getPanelNode$());
} else {
System.out.println$S("not a leaf");
}this.si.siSetCurrentSource$jspecview_source_JDXSource(node.getPanelNode$().source);
});

Clazz.newMeth(C$, 'dispose$',  function () {
this.fileHelper=null;
if (this.viewDialog != null ) this.viewDialog.dispose$();
this.viewDialog=null;
if (this.overlayLegendDialog != null ) this.overlayLegendDialog.dispose$();
this.overlayLegendDialog=null;
if (this.jsvpPopupMenu != null ) {
this.jsvpPopupMenu.jpiDispose$();
this.jsvpPopupMenu=null;
}if (this.panelNodes != null ) for (var i=this.panelNodes.size$(); --i >= 0; ) {
this.panelNodes.get$I(i).dispose$();
this.panelNodes.removeItemAt$I(i);
}
});

Clazz.newMeth(C$, 'runScript$S',  function (script) {
if (this.scriptQueue == null ) this.si.siProcessCommand$S(script);
 else this.scriptQueue.addLast$O(script);
});

Clazz.newMeth(C$, 'requestRepaint$',  function () {
if (this.selectedPanel != null ) this.repaintManager.refresh$();
});

Clazz.newMeth(C$, 'repaintDone$',  function () {
this.repaintManager.repaintDone$();
});

Clazz.newMeth(C$, 'checkOverlay$',  function () {
if (this.mainPanel != null ) p$1.markSelectedPanels$javajs_util_Lst$I.apply(this, [this.panelNodes, this.mainPanel.getCurrentPanelIndex$()]);
this.viewDialog=this.getDialog$jspecview_common_Annotation_AType$jspecview_common_Spectrum($I$(12).Views, null);
});

Clazz.newMeth(C$, 'markSelectedPanels$javajs_util_Lst$I',  function (panelNodes, ip) {
for (var i=panelNodes.size$(); --i >= 0; ) panelNodes.get$I(i).isSelected=(ip == i);

}, p$1);

Clazz.newMeth(C$, 'execOverlayOffsetY$I',  function (offset) {
if (offset == -2147483648) {
if (this.selectedPanel == null ) return;
var soffset=this.selectedPanel.getInput$S$S$S("Enter a vertical offset in percent for stacked plots", "Overlay", "" + this.recentStackPercent);
var f=$I$(9).parseDouble$S(soffset);
if (Double.isNaN$D(f)) return;
offset=(f|0);
}this.recentStackPercent=offset;
this.parameters.viewOffset=offset;
if (p$1.isClosed.apply(this, [])) this.pd$().setYStackOffsetPercent$I(offset);
}, p$1);

Clazz.newMeth(C$, 'execScriptInline$S',  function (script) {
if (script.length$() > 0) script=script.substring$I(6).trim$();
if (script.length$() == 0) script=this.selectedPanel.getInput$S$S$S("Enter a JSpecView script", "Script", this.recentScript);
if (script == null ) return;
this.recentScript=script;
this.runScriptNow$S(script);
}, p$1);

Clazz.newMeth(C$, 'setDisplay$O',  function (canvas) {
this.apiPlatform.setViewer$org_jmol_api_PlatformViewer$O(this, this.display=canvas);
var wh=Clazz.array(Integer.TYPE, [2]);
this.apiPlatform.getFullScreenDimensions$O$IA(canvas, wh);
this.setScreenDimension$I$I(wh[0], wh[1]);
});

Clazz.newMeth(C$, 'setScreenDimension$I$I',  function (width, height) {
height=Math.min(height, this.maximumSize);
width=Math.min(width, this.maximumSize);
if (this.screenWidth == width && this.screenHeight == height ) return;
this.resizeImage$I$I(width, height);
});

Clazz.newMeth(C$, 'resizeImage$I$I',  function (width, height) {
if (width > 0) {
this.screenWidth=width;
this.screenHeight=height;
} else {
width=(this.screenWidth == 0 ? this.screenWidth=500 : this.screenWidth);
height=(this.screenHeight == 0 ? this.screenHeight=500 : this.screenHeight);
}this.g2d.setWindowParameters$I$I(width, height);
});

Clazz.newMeth(C$, 'updateJS$',  function () {
if (this.selectedPanel != null ) this.selectedPanel.paintComponent$O(this.apiPlatform.getGraphics$O(null));
});

Clazz.newMeth(C$, 'processMouseEvent$I$I$I$I$J',  function (id, x, y, modifiers, time) {
return (this.selectedPanel != null  && this.selectedPanel.processMouseEvent$I$I$I$I$J(id, x, y, modifiers, time) );
});

Clazz.newMeth(C$, 'processTwoPointGesture$DAAA',  function (touches) {
if (!p$1.isClosed.apply(this, [])) this.selectedPanel.processTwoPointGesture$DAAA(touches);
});

Clazz.newMeth(C$, 'processKeyEvent$O',  function (event) {
if (!p$1.isClosed.apply(this, [])) this.selectedPanel.processKeyEvent$O(event);
});

Clazz.newMeth(C$, 'getApplet$',  function () {
return this.html5Applet;
});

Clazz.newMeth(C$, 'openFileAsyncSpecial$S$I',  function (fileName, flags) {
var ans=(this.currentSource == null  ? "NO" : this.getDialogManager$().getDialogInput$O$S$S$I$O$OA$S(this, "Do you want to append this file? (Answer NO to replace.)", "Drag/Drop Action", 3, null, null, "YES"));
if (ans == null ) return;
var pre=(ans.toLowerCase$().startsWith$S("y") ? "append" : "");
var post=(pre === ""  ? "" : "; view *");
this.runScript$S("load " + pre + " \"" + fileName + "\"" + post );
});

Clazz.newMeth(C$, 'getHeight$',  function () {
return this.screenHeight;
});

Clazz.newMeth(C$, 'getWidth$',  function () {
return this.screenWidth;
});

Clazz.newMeth(C$, 'getPlatformInterface$S',  function (type) {
return C$.getInterface$S("jspecview." + (C$.isJS ? "js2d.Js" : "java.Awt") + type );
});

Clazz.newMeth(C$, 'getDialogManager$',  function () {
if (this.dialogManager != null ) return this.dialogManager;
this.dialogManager=this.getPlatformInterface$S("DialogManager");
return this.dialogManager.set$jspecview_common_JSViewer(this);
});

Clazz.newMeth(C$, 'getDialog$jspecview_common_Annotation_AType$jspecview_common_Spectrum',  function (type, spec) {
var root="jspecview.dialog.";
switch (type) {
case $I$(12).Integration:
return (C$.getInterface$S(root + "IntegrationDialog")).setParams$S$jspecview_common_JSViewer$jspecview_common_Spectrum("Integration for " + spec, this, spec);
case $I$(12).Measurements:
return (C$.getInterface$S(root + "MeasurementsDialog")).setParams$S$jspecview_common_JSViewer$jspecview_common_Spectrum("Measurements for " + spec, this, spec);
case $I$(12).PeakList:
return (C$.getInterface$S(root + "PeakListDialog")).setParams$S$jspecview_common_JSViewer$jspecview_common_Spectrum("Peak List for " + spec, this, spec);
case $I$(12).OverlayLegend:
return this.overlayLegendDialog=(C$.getInterface$S(root + "OverlayLegendDialog")).setParams$S$jspecview_common_JSViewer$jspecview_common_Spectrum(this.pd$().getViewTitle$(), this, null);
case $I$(12).Views:
return this.viewDialog=(C$.getInterface$S(root + "ViewsDialog")).setParams$S$jspecview_common_JSViewer$jspecview_common_Spectrum("View/Combine/Close Spectra", this, null);
default:
return null;
}
});

Clazz.newMeth(C$, 'show$S',  function (what) {
this.getDialogManager$();
if (what.equals$O("properties")) {
this.dialogManager.showProperties$O$jspecview_common_Spectrum(null, this.pd$().getSpectrum$());
} else if (what.equals$O("errors")) {
this.dialogManager.showSourceErrors$O$jspecview_source_JDXSource(null, this.currentSource);
} else if (what.equals$O("source")) {
if (this.currentSource == null ) {
if (this.panelNodes.size$() > 0) this.dialogManager.showMessageDialog$O$S$S$I(null, "Please Select a Spectrum", "Select Spectrum", 0);
return;
}this.dialogManager.showSource$O$jspecview_common_Spectrum(this, this.pd$().getSpectrum$());
} else if (what.startsWith$S("solutioncolorfill")) {
if (what.indexOf$S("all") >= 0) {
for (var i=this.panelNodes.size$(); --i >= 0; ) this.panelNodes.get$I(i).pd$().setSolutionColor$S(what);

} else {
this.pd$().setSolutionColor$S(what);
}} else if (what.startsWith$S("solutioncolor")) {
var msg=this.getSolutionColorStr$Z(what.indexOf$S("false") < 0);
msg="background-color:rgb(" + msg + ")'><br />Predicted Solution Colour- RGB(" + msg + ")<br /><br />" ;
if (C$.isJS) {
this.dialogManager.showMessage$O$S$S(this, "<div style='width:100%;height:100%;" + msg + "</div>" , "Predicted Colour");
} else {
this.selectedPanel.showMessage$S$S("<html><body style='" + msg + "</body></html>" , "Predicted Colour");
}}}, p$1);

Clazz.newMeth(C$, 'getDialogPrint$Z',  function (isJob) {
if (!C$.isJS) try {
var pl=(this.getPlatformInterface$S("PrintDialog")).set$O$jspecview_common_PrintLayout$Z(this.offWindowFrame, this.lastPrintLayout, isJob).getPrintLayout$();
if (pl != null ) this.lastPrintLayout=pl;
return pl;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
return Clazz.new_([this.pd$()],$I$(23,1).c$$jspecview_common_PanelData);
});

Clazz.newMeth(C$, 'setIRmode$S',  function (mode) {
if (mode.equals$O("AtoT")) {
this.irMode=$I$(1).TO_TRANS;
} else if (mode.equals$O("TtoA")) {
this.irMode=$I$(1).TO_ABS;
} else {
this.irMode=$I$(1).getMode$S(mode);
}});

Clazz.newMeth(C$, 'getOptionFromDialog$SA$S$S',  function (items, title, label) {
return this.getDialogManager$().getOptionFromDialog$O$SA$jspecview_api_JSVPanel$S$S(null, items, this.selectedPanel, title, label);
});

Clazz.newMeth(C$, 'print$S',  function (fileName) {
return p$1.execWrite$S.apply(this, ["PDF \"" + fileName + "\"" ]);
});

Clazz.newMeth(C$, 'execWrite$S',  function (value) {
if (C$.isJS && value == null  ) value="PDF";
var msg=(C$.getInterface$S("jspecview.export.Exporter")).write$jspecview_common_JSViewer$javajs_util_Lst$Z(this, value == null  ? null : $I$(7).getTokens$S(value), false);
this.si.writeStatus$S(msg);
return msg;
}, p$1);

Clazz.newMeth(C$, 'export$S$I',  function (type, n) {
if (type == null ) type="XY";
var pd=this.pd$();
var nMax=pd.getNumberOfSpectraInCurrentSet$();
if (n < -1 || n >= nMax ) return "Maximum spectrum index (0-based) is " + (nMax - 1) + "." ;
var spec=(n < 0 ? pd.getSpectrum$() : pd.getSpectrumAt$I(n));
try {
return (C$.getInterface$S("jspecview.export.Exporter")).exportTheSpectrum$jspecview_common_JSViewer$jspecview_common_ExportType$javajs_util_OC$jspecview_common_Spectrum$I$I$jspecview_common_PanelData$Z(this, $I$(24).getType$S(type), null, spec, 0, spec.getXYCoords$().length - 1, null, type.equalsIgnoreCase$S("PDF"));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
$I$(5,"error$S",[e.toString()]);
return null;
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'postByteArray$S$BA',  function (fileName, bytes) {
return $I$(10).postByteArray$S$BA(fileName, bytes);
});

Clazz.newMeth(C$, 'getOutputChannel$S$Z',  function (fileName, isBinary) {
var os=null;
{
while (fileName.startsWith("/")) fileName = fileName.substring(1);
}
return Clazz.new_($I$(25,1)).setParams$javajs_api_BytePoster$S$Z$java_io_OutputStream(this, fileName, !isBinary, os);
});

Clazz.newMeth(C$, 'getInterface$S',  function (name) {
try {
var x=Clazz.forName(name);
return (x == null  ? null : x.newInstance$());
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
$I$(5).error$S("Interface.java Error creating instance for " + name + ": \n" + e );
return null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'showMessage$S',  function (msg) {
if (this.selectedPanel != null  && msg != null  ) this.selectedPanel.showMessage$S$S(msg, null);
});

Clazz.newMeth(C$, 'openFileFromDialog$Z$Z$S$S',  function (isAppend, isURL, simulationType, script) {
var url=null;
if (simulationType != null ) {
url=this.fileHelper.getUrlFromDialog$S$S("Enter the name or identifier of a compound", this.recentSimulation);
if (url == null ) return;
this.recentSimulation=url;
url="$" + simulationType + "/" + url ;
} else if (isURL) {
url=this.fileHelper.getUrlFromDialog$S$S("Enter the URL of a JCAMP-DX File", this.recentURL == null  ? this.recentOpenURL : this.recentURL);
if (url == null ) return;
this.recentOpenURL=url;
} else {
var userData=Clazz.array(java.lang.Object, -1, [Boolean.valueOf$Z(isAppend), script]);
var file=this.fileHelper.showFileOpenDialog$O$OA(this.mainPanel, userData);
if (file != null ) url=file.getFullPath$();
}if (url != null ) this.runScriptNow$S("load " + (isAppend ? "APPEND " : "") + "\"" + url + "\"" + (script == null  ? "" : ";" + script) );
});

Clazz.newMeth(C$, 'openFile$S$Z',  function (fileName, closeFirst) {
if (closeFirst && this.panelNodes != null  ) {
var source=$I$(15,"findSourceByNameOrId$S$javajs_util_Lst",[(Clazz.new_($I$(26,1).c$$S,[fileName])).getAbsolutePath$(), this.panelNodes]);
if (source != null ) this.closeSource$jspecview_source_JDXSource(source);
}this.si.siOpenDataOrFile$O$S$javajs_util_Lst$S$I$I$Z$S$S(null, null, null, fileName, -1, -1, true, this.defaultLoadScript, null);
});

Clazz.newMeth(C$, 'selectPanel$jspecview_api_JSVPanel$javajs_util_Lst',  function (jsvp, panelNodes) {
var iPanel=-1;
if (panelNodes != null ) {
for (var i=panelNodes.size$(); --i >= 0; ) {
var j=panelNodes.get$I(i).jsvp;
if (j === jsvp ) {
iPanel=i;
} else {
j.setEnabled$Z(false);
j.setFocusable$Z(false);
j.getPanelData$().closeAllDialogsExcept$jspecview_common_Annotation_AType($I$(12).NONE);
}}
p$1.markSelectedPanels$javajs_util_Lst$I.apply(this, [panelNodes, iPanel]);
}return iPanel;
});

Clazz.newMeth(C$, 'checkAutoIntegrate$',  function () {
if (this.autoIntegrate) this.pd$().integrateAll$jspecview_common_ColorParameters(this.parameters);
});

Clazz.newMeth(C$, 'parseInitScript$S',  function (params) {
if (params == null ) params="";
var allParamTokens=Clazz.new_($I$(6,1).c$$S$Z,[params, true]);
if ($I$(5).debugging) {
$I$(5).info$S("Running in DEBUG mode");
}while (allParamTokens.hasMoreTokens$()){
var token=allParamTokens.nextToken$();
var eachParam=Clazz.new_($I$(6,1).c$$S$Z,[token, false]);
var key=eachParam.nextToken$();
if (key.equalsIgnoreCase$S("SET")) key=eachParam.nextToken$();
key=key.toUpperCase$();
var st=$I$(7).getScriptToken$S(key);
var value=$I$(7).getValue$jspecview_common_ScriptToken$jspecview_common_ScriptTokenizer$S(st, eachParam, token);
$I$(5).info$S("KEY-> " + key + " VALUE-> " + value + " : " + st );
try {
switch (st) {
default:
this.parameters.set$jspecview_common_PanelData$jspecview_common_ScriptToken$S(null, st, value);
break;
case $I$(7).UNKNOWN:
break;
case $I$(7).APPLETID:
this.fullName=this.appletName + "__" + (this.appletName=value) + "__" ;
var applet=null;
{
self.Jmol && (applet = Jmol._applets[value]);
}
this.html5Applet=applet;
break;
case $I$(7).AUTOINTEGRATE:
this.autoIntegrate=$I$(8).isTrue$S(value);
break;
case $I$(7).COMPOUNDMENUON:
break;
case $I$(7).APPLETREADYCALLBACKFUNCTIONNAME:
case $I$(7).COORDCALLBACKFUNCTIONNAME:
case $I$(7).LOADFILECALLBACKFUNCTIONNAME:
case $I$(7).PEAKCALLBACKFUNCTIONNAME:
case $I$(7).SYNCCALLBACKFUNCTIONNAME:
this.si.siExecSetCallback$jspecview_common_ScriptToken$S(st, value);
break;
case $I$(7).ENDINDEX:
this.initialEndIndex=Integer.parseInt$S(value);
break;
case $I$(7).INTERFACE:
this.checkOvelayInterface$S(value);
break;
case $I$(7).IRMODE:
this.setIRmode$S(value);
break;
case $I$(7).MENUON:
this.allowMenu=Boolean.parseBoolean$S(value);
break;
case $I$(7).OBSCURE:
if (this.obscureTitleFromUser == null ) this.obscureTitleFromUser=Boolean.valueOf$S(value);
break;
case $I$(7).STARTINDEX:
this.initialStartIndex=Integer.parseInt$S(value);
break;
case $I$(7).SYNCID:
this.fullName=this.appletName + "__" + (this.syncID=value) + "__" ;
break;
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}
});

Clazz.newMeth(C$, 'getSolutionColorStr$Z',  function (asFit) {
var pt=$I$(27,"colorPtFromInt$I$javajs_util_P3d",[this.getSolutionColor$Z(asFit), null]);
return (pt.x|0) + "," + (pt.y|0) + "," + (pt.z|0) ;
});

Clazz.newMeth(C$, 'checkCommandLineForTip$C$S$Z',  function (c, cmd, oneLineOnly) {
var isHelp=(c == "\u0001");
if (!isHelp && c != "\u0000" ) {
if (c != "\t" && (c == "\n" || c.$c() < 32   || c.$c() > 126  ) ) return null;
cmd+=(Character.isISOControl$C(c) ? "" : "" + c);
}var tip;
if (cmd.indexOf$S(";") >= 0) cmd=cmd.substring$I(cmd.lastIndexOf$S(";") + 1);
var ret=null;
while (cmd.startsWith$S(" "))cmd=cmd.substring$I(1);

if (cmd.length$() == 0 && !isHelp ) {
tip="";
} else {
var tokens=$I$(7).getTokens$S(cmd);
if (tokens.size$() == 0 && !isHelp ) return "";
var isExact=(cmd.endsWith$S(" ") || tokens.size$() > 1 && oneLineOnly  );
var list=$I$(7,"getScriptTokenList$S$Z",[tokens.size$() == 0 ? null : tokens.get$I(0), isExact]);
switch (list.size$()) {
case 0:
tip="?";
break;
case 1:
var st=list.get$I(0);
tip=st.getTip$();
try {
if (tip.indexOf$S("TRUE") >= 0) tip=" (" + this.parameters.getBoolean$jspecview_common_ScriptToken(st) + ")" ;
 else if (st.name$().indexOf$S("COLOR") >= 0) tip=" (" + $I$(27,"toRGBHexString$javajs_api_GenericColor",[this.parameters.getElementColor$jspecview_common_ScriptToken(st)]) + ")" ;
 else tip="";
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return null;
} else {
throw e;
}
}
if (c == "\t" || isExact  || !oneLineOnly ) {
tip=st.name$() + " " + st.getTip$() + tip + " " + st.getDescription$() ;
if (c == "\t") ret=st.name$() + " ";
break;
}tip=st.name$() + " " + tip ;
break;
default:
tip=$I$(7).getNameList$javajs_util_Lst(list);
}
}if (oneLineOnly) {
this.si.writeStatus$S(tip);
} else {
ret=tip;
}return ret;
});

Clazz.newMeth(C$, 'checkScript$S',  function (script) {
return this.checkCommandLineForTip$C$S$Z("\u0000", script, false);
});

Clazz.newMeth(C$, 'execHelp$S',  function (value) {
var s=this.checkCommandLineForTip$C$S$Z("\u0001", value, false);
if (s.indexOf$S(" ") < 0 && s.indexOf$S(",") > 0 ) {
var tokens=$I$(9).split$S$S(s, ",");
$I$(28).sort$OA(tokens);
s="";
for (var i=0; i < tokens.length; i++) {
var st=$I$(7).getScriptToken$S(tokens[i]);
s+=tokens[i] + " " + st.getTip$() + "\n  " + st.getDescription$() + "\n\n" ;
}
this.getDialogManager$().showMessage$O$S$S(null, s, "HELP " + value);
} else {
this.selectedPanel.showMessage$S$S(s, "Help " + value);
}System.out.println$S(s);
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.testScript="<PeakData  index=\"1\" title=\"\" model=\"~1.1\" type=\"1HNMR\" xMin=\"3.2915\" xMax=\"3.2965\" atoms=\"15,16,17,18,19,20\" multiplicity=\"\" integral=\"1\"> src=\"JPECVIEW\" file=\"http://SIMULATION/$caffeine\"";
C$.isSwingJS=false;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:28 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
