(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[[0,'javajs.util.CU','jspecview.common.ColoredAnnotation']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Annotation", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'jspecview.common.Coordinate');
C$.$classes$=[['AType',25]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.text="";
},1);

C$.$fields$=[['Z',['isPixels','is2D'],'I',['offsetX','offsetY'],'S',['text'],'O',['spec','jspecview.common.Spectrum']]]

Clazz.newMeth(C$, 'setA$D$D$jspecview_common_Spectrum$S$Z$Z$I$I',  function (x, y, spec, text, isPixels, is2D, offsetX, offsetY) {
this.set$D$D(x, y);
this.spec=spec;
this.text=text;
this.isPixels=isPixels;
this.is2D=is2D;
this.offsetX=offsetX;
this.offsetY=offsetY;
return this;
});

Clazz.newMeth(C$, 'setSpec$jspecview_common_Spectrum',  function (spec) {
this.spec=spec;
return this;
});

Clazz.newMeth(C$, 'addSpecShift$D',  function (dx) {
this.setXVal$D(this.getXVal$() + dx);
});

Clazz.newMeth(C$, 'isPixels$',  function () {
return this.isPixels;
});

Clazz.newMeth(C$, 'toString',  function () {
return "[" + new Double(this.getXVal$()).toString() + ", " + new Double(this.getYVal$()).toString() + "," + this.text + "]" ;
});

Clazz.newMeth(C$, 'getColoredAnnotation$org_jmol_api_GenericGraphics$jspecview_common_Spectrum$javajs_util_Lst$jspecview_common_Annotation',  function (g2d, spec, args, lastAnnotation) {
var arg;
var xPt=0;
var yPt=1;
var colorPt=2;
var textPt=3;
var nArgs=args.size$();
try {
switch (nArgs) {
default:
return null;
case 1:
arg=args.get$I(0);
xPt=yPt=-1;
if (arg.charAt$I(0) == "\"") {
textPt=0;
colorPt=-1;
} else {
colorPt=0;
textPt=-1;
}break;
case 2:
xPt=yPt=-1;
arg=args.get$I(0);
if (arg.charAt$I(0) == "\"") {
textPt=0;
colorPt=1;
} else {
colorPt=0;
textPt=1;
}break;
case 3:
case 4:
arg=args.get$I(2);
if (arg.charAt$I(0) == "\"") {
textPt=2;
colorPt=(nArgs == 4 ? 3 : -1);
} else {
colorPt=2;
textPt=(nArgs == 4 ? 3 : -1);
}arg=args.get$I(2);
if (arg.charAt$I(0) == "\"") {
textPt=2;
colorPt=-1;
} else {
colorPt=2;
textPt=-1;
}}
if (lastAnnotation == null  && (xPt < 0 || yPt < 0  || textPt < 0  || colorPt < 0 ) ) return null;
var x=(xPt < 0 ? lastAnnotation.getXVal$() : Double.valueOf$S(args.get$I(xPt)).doubleValue$());
var y=(yPt < 0 ? lastAnnotation.getYVal$() : Double.valueOf$S(args.get$I(yPt)).doubleValue$());
var color=(colorPt < 0 ? (lastAnnotation).getColor$() : g2d.getColor1$I($I$(1,"getArgbFromString$S",[args.get$I(colorPt)])));
var text;
if (textPt < 0) {
text=lastAnnotation.text;
} else {
text=args.get$I(textPt);
if (text.charAt$I(0) == "\"") text=text.substring$I$I(1, text.length$() - 1);
}return Clazz.new_($I$(2,1)).setCA$D$D$jspecview_common_Spectrum$S$javajs_api_GenericColor$Z$Z$I$I(x, y, spec, text, color, false, false, 0, 0);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return null;
} else {
throw e;
}
}
}, 1);
;
(function(){/*e*/var C$=Clazz.newClass(P$.Annotation, "AType", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "Integration", 0, []);
Clazz.newEnumConst($vals, C$.c$, "PeakList", 1, []);
Clazz.newEnumConst($vals, C$.c$, "Measurements", 2, []);
Clazz.newEnumConst($vals, C$.c$, "OverlayLegend", 3, []);
Clazz.newEnumConst($vals, C$.c$, "Views", 4, []);
Clazz.newEnumConst($vals, C$.c$, "NONE", 5, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:51 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
