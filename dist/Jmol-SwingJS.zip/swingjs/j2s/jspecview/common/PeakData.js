(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[[0,'javajs.util.DF','jspecview.common.Coordinate','jspecview.common.PeakPick']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PeakData", null, 'jspecview.common.MeasurementData');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['thresh','minY','maxY']]
,['O',['HNMR_HEADER','String[]']]]

Clazz.newMeth(C$, 'c$$jspecview_common_Annotation_AType$jspecview_common_Spectrum',  function (type, spec) {
;C$.superclazz.c$$jspecview_common_Annotation_AType$jspecview_common_Spectrum.apply(this,[type, spec]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getThresh$',  function () {
return this.thresh;
});

Clazz.newMeth(C$, 'getDataHeader$',  function () {
return (this.spec.isHNMR$() ? C$.HNMR_HEADER : Clazz.array(String, -1, ["peak", this.spec.getXUnits$(), this.spec.getYUnits$()]));
});

Clazz.newMeth(C$, 'getMeasurementListArray$S',  function (units) {
var data=Clazz.array(String, [this.size$(), null]);
var last=Clazz.array(Double.TYPE, -1, [-1.0E100, 1.0E100, 1.0E100]);
var ddata;
for (var pt=0, i=this.size$(); --i >= 0; pt++) {
ddata=this.spec.getPeakListArray$jspecview_common_Measurement$DA$D(this.get$I(i), last, this.maxY);
if (ddata.length == 2) data[pt]=Clazz.array(String, -1, ["" + (pt + 1), $I$(1).formatDecimalDbl$D$I(ddata[0], 2), $I$(1).formatDecimalDbl$D$I(ddata[1], 4)]);
 else data[pt]=Clazz.array(String, -1, ["" + (pt + 1), $I$(1).formatDecimalDbl$D$I(ddata[0], 4), $I$(1).formatDecimalDbl$D$I(ddata[1], 4), $I$(1).formatDecimalDbl$D$I(ddata[2], 2), (ddata[3] == 0  ? "" : $I$(1).formatDecimalDbl$D$I(ddata[3], 2)), (ddata[4] == 0  ? "" : $I$(1).formatDecimalDbl$D$I(ddata[4], 2)), (ddata[5] == 0  ? "" : $I$(1).formatDecimalDbl$D$I(ddata[5], 2))]);
}
return data;
});

Clazz.newMeth(C$, 'getMeasurementListArrayReal$S',  function (units) {
var data=Clazz.array(Double.TYPE, [this.size$(), null]);
var last=Clazz.array(Double.TYPE, -1, [-1.0E100, 1.0E100, 1.0E100]);
for (var pt=0, i=this.size$(); --i >= 0; pt++) data[pt]=this.spec.getPeakListArray$jspecview_common_Measurement$DA$D(this.get$I(i), last, this.maxY);

return data;
});

Clazz.newMeth(C$, 'getInfo$java_util_Map',  function (info) {
info.put$O$O("interpolation", this.myParams.peakListInterpolation);
info.put$O$O("threshold", Double.valueOf$D(this.myParams.peakListThreshold));
C$.superclazz.prototype.getInfo$java_util_Map.apply(this, [info]);
});

Clazz.newMeth(C$, 'setPeakList$jspecview_common_Parameters$I$jspecview_common_ScaleData',  function (p, precision, view) {
this.precision=(precision == -2147483648 ? this.spec.getDefaultUnitPrecision$() : precision);
var xyCoords=this.spec.getXYCoords$();
if (xyCoords.length < 3) return;
this.clear$();
if (p != null ) {
this.myParams.peakListInterpolation=p.peakListInterpolation;
this.myParams.peakListThreshold=p.peakListThreshold;
}var doInterpolate=(this.myParams.peakListInterpolation.equals$O("parabolic"));
var isInverted=this.spec.isInverted$();
this.minY=view.minYOnScale;
this.maxY=view.maxYOnScale;
var minX=view.minXOnScale;
var maxX=view.maxXOnScale;
this.thresh=this.myParams.peakListThreshold;
if (Double.isNaN$D(this.thresh)) this.thresh=this.myParams.peakListThreshold=(this.minY + this.maxY) / 2;
var yLast=0;
var y3=Clazz.array(Double.TYPE, -1, [xyCoords[0].getYVal$(), yLast=xyCoords[1].getYVal$(), 0]);
var n=0;
if (isInverted) for (var i=2; i < xyCoords.length; i++) {
var y=y3[i % 3]=xyCoords[i].getYVal$();
if (yLast < this.thresh  && y3[(i - 2) % 3] > yLast   && yLast < y  ) {
var x=(doInterpolate ? $I$(2).parabolicInterpolation$jspecview_common_CoordinateA$I(xyCoords, i - 1) : xyCoords[i - 1].getXVal$());
if (x >= minX  || x <= maxX  ) {
var m=Clazz.new_($I$(3,1)).setValue$D$D$jspecview_common_Spectrum$S$D(x, y, this.spec, null, 0);
this.addLast$O(m);
if (++n == 100) break;
}}yLast=y;
}
 else for (var i=2; i < xyCoords.length; i++) {
var y=y3[i % 3]=xyCoords[i].getYVal$();
if (yLast > this.thresh  && y3[(i - 2) % 3] < yLast   && yLast > y  ) {
var x=(doInterpolate ? $I$(2).parabolicInterpolation$jspecview_common_CoordinateA$I(xyCoords, i - 1) : xyCoords[i - 1].getXVal$());
if (x >= minX  && x <= maxX  ) {
var m=Clazz.new_($I$(3,1)).setValue$D$D$jspecview_common_Spectrum$S$D(x, y, this.spec, $I$(1).formatDecimalDbl$D$I(x, precision), x);
this.addLast$O(m);
if (++n == 100) break;
}}yLast=y;
}
});

C$.$static$=function(){C$.$static$=0;
C$.HNMR_HEADER=Clazz.array(String, -1, ["peak", "shift/ppm", "intens", "shift/hz", "diff/hz", "2-diff", "3-diff"]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:28 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
