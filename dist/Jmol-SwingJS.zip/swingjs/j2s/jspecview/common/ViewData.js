(function(){var P$=Clazz.newPackage("jspecview.common"),p$1={},I$=[[0,'jspecview.common.ScaleData','jspecview.common.Coordinate']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ViewData");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['nSpectra','iThisScale'],'O',['scaleData','jspecview.common.ScaleData[]','thisScale','jspecview.common.ScaleData','spectra','javajs.util.Lst']]]

Clazz.newMeth(C$, 'getScaleData$',  function () {
return this.scaleData;
});

Clazz.newMeth(C$, 'getScale$',  function () {
return this.thisScale;
});

Clazz.newMeth(C$, 'c$$javajs_util_Lst$D$D$IA$IA$Z$Z',  function (spectra, yPt1, yPt2, startList, endList, isContinuous, is2D) {
;C$.$init$.apply(this);
this.nSpectra=(is2D ? 1 : spectra.size$());
this.scaleData=Clazz.array($I$(1), [this.nSpectra]);
for (var j=0; j < this.nSpectra; j++) this.scaleData[j]=Clazz.new_($I$(1,1).c$$I$I,[startList[j], endList[j]]);

this.init$javajs_util_Lst$D$D$Z(spectra, yPt1, yPt2, isContinuous);
}, 1);

Clazz.newMeth(C$, 'c$$javajs_util_Lst$D$D$Z',  function (spectra, yPt1, yPt2, isContinuous) {
;C$.$init$.apply(this);
this.nSpectra=spectra.size$();
var n=spectra.get$I(0).getXYCoords$().length;
this.scaleData=Clazz.array($I$(1), [1]);
this.scaleData[0]=Clazz.new_($I$(1,1).c$$I$I,[0, n - 1]);
this.init$javajs_util_Lst$D$D$Z(spectra, yPt1, yPt2, isContinuous);
}, 1);

Clazz.newMeth(C$, 'init$javajs_util_Lst$D$D$Z',  function (spectra, yPt1, yPt2, isContinuous) {
if (spectra == null ) spectra=this.spectra;
 else this.spectra=spectra;
this.thisScale=this.scaleData[this.iThisScale=0];
for (var i=0; i < this.scaleData.length; i++) {
this.scaleData[i].userYFactor=spectra.get$I(i).getUserYFactor$();
this.scaleData[i].spectrumYRef=spectra.get$I(i).getYRef$();
}
this.resetScaleFactors$();
var minX=$I$(2).getMinX$javajs_util_Lst$jspecview_common_ViewData(spectra, this);
var maxX=$I$(2).getMaxX$javajs_util_Lst$jspecview_common_ViewData(spectra, this);
var minY=$I$(2).getMinYUser$javajs_util_Lst$jspecview_common_ViewData(spectra, this);
var maxY=$I$(2).getMaxYUser$javajs_util_Lst$jspecview_common_ViewData(spectra, this);
if (yPt1 != yPt2 ) {
minY=yPt1;
maxY=yPt2;
if (minY > maxY ) {
var t=minY;
minY=maxY;
maxY=t;
}}var isInverted=spectra.get$I(0).isInverted$();
for (var i=0; i < this.scaleData.length; i++) {
this.scaleData[i].setMinMax$D$D$D$D(minX, maxX, minY, maxY);
this.scaleData[i].setScale$Z$Z(isContinuous, isInverted);
}
});

Clazz.newMeth(C$, 'newSpectrum$javajs_util_Lst',  function (spectra) {
this.init$javajs_util_Lst$D$D$Z(spectra, 0, 0, false);
});

Clazz.newMeth(C$, 'setXRangeForSubSpectrum$jspecview_common_CoordinateA',  function (xyCoords) {
p$1.setXRange$I$jspecview_common_CoordinateA$D$D$I$I.apply(this, [0, xyCoords, this.scaleData[0].minX, this.scaleData[0].maxX, 0, xyCoords.length - 1]);
});

Clazz.newMeth(C$, 'setXRange$I$jspecview_common_CoordinateA$D$D$I$I',  function (i, xyCoords, initX, finalX, iStart, iEnd) {
var index=0;
var ptCount=0;
for (index=iStart; index <= iEnd; index++) {
var x=xyCoords[index].getXVal$();
if (x >= initX ) {
this.scaleData[i % this.scaleData.length].startDataPointIndex=index;
break;
}}
for (; index <= iEnd; index++) {
var x=xyCoords[index].getXVal$();
++ptCount;
if (x >= finalX ) {
break;
}}
this.scaleData[i % this.scaleData.length].endDataPointIndex=index;
return ptCount;
}, p$1);

Clazz.newMeth(C$, 'getStartingPointIndex$I',  function (i) {
return this.scaleData[i % this.scaleData.length].startDataPointIndex;
});

Clazz.newMeth(C$, 'getEndingPointIndex$I',  function (i) {
return this.scaleData[i % this.scaleData.length].endDataPointIndex;
});

Clazz.newMeth(C$, 'areYScalesSame$I$I',  function (i, j) {
i%=this.scaleData.length;
j%=this.scaleData.length;
return (this.scaleData[i].minYOnScale == this.scaleData[j].minYOnScale  && this.scaleData[i].maxYOnScale == this.scaleData[j].maxYOnScale  );
});

Clazz.newMeth(C$, 'setScale$I$I$I$Z',  function (i, xPixels, yPixels, isInverted) {
this.iThisScale=i % this.scaleData.length;
this.thisScale=this.scaleData[this.iThisScale];
this.thisScale.setXYScale$I$I$Z(xPixels, yPixels, isInverted);
});

Clazz.newMeth(C$, 'resetScaleFactors$',  function () {
for (var i=0; i < this.scaleData.length; i++) this.scaleData[i].spectrumScaleFactor=1;

});

Clazz.newMeth(C$, 'scaleSpectrum$I$D',  function (i, f) {
if (f <= 0  || i >= this.nSpectra ) return;
if (i == -2) {
this.thisScale.scale2D$D(f);
return;
}if (i < 0) for (i=0; i < this.scaleData.length; i++) this.scaleData[i].scaleBy$D(f);

 else this.scaleData[i % this.scaleData.length].scaleBy$D(f);
});

Clazz.newMeth(C$, 'getNewScales$I$Z$D$D',  function (iSelected, isXOnly, y1, y2) {
if (isXOnly) return this.scaleData;
iSelected%=this.scaleData.length;
var f1=(y1 - this.thisScale.minYOnScale) / (this.thisScale.maxYOnScale - this.thisScale.minYOnScale);
var f2=(y2 - this.thisScale.minYOnScale) / (this.thisScale.maxYOnScale - this.thisScale.minYOnScale);
var sd=Clazz.array($I$(1), [this.scaleData.length]);
for (var i=0; i < this.scaleData.length; i++) sd[i]=(iSelected >= 0 && i != iSelected  ? this.scaleData[i] : Clazz.new_($I$(1,1)));

$I$(1).copyScaleFactors$jspecview_common_ScaleDataA$jspecview_common_ScaleDataA(this.scaleData, sd);
$I$(1).copyYScales$jspecview_common_ScaleDataA$jspecview_common_ScaleDataA(this.scaleData, sd);
for (var i=0; i < this.scaleData.length; i++) {
if (iSelected >= 0 && i != iSelected ) continue;
sd[i].isShiftZoomedY=true;
sd[i].minYOnScale=this.scaleData[i].minYOnScale * (1 - f1) + f1 * this.scaleData[i].maxYOnScale;
sd[i].maxYOnScale=this.scaleData[i].minYOnScale * (1 - f2) + f2 * this.scaleData[i].maxYOnScale;
}
return sd;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:52 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
