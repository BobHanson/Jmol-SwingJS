(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Integral", null, 'jspecview.common.Measurement');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'setInt$D$D$jspecview_common_Spectrum$D$D$D',  function (x1, y1, spec, value, x2, y2) {
this.setA$D$D$jspecview_common_Spectrum$S$Z$Z$I$I(x1, y1, spec, "", false, false, 0, 6);
this.setPt2$D$D(x2, y2);
this.setValue$D(value);
return this;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:05 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
