(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Integral", null, 'jspecview.common.Measurement');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'setInt$D$D$jspecview_common_Spectrum$D$D$D',  function (x1, y1, spec, value, x2, y2) {
this.setA$D$D$jspecview_common_Spectrum$S$Z$Z$I$I(x1, y1, spec, "", false, false, 0, 6);
this.setPt2$D$D(x2, y2);
this.setValue$D(value);
return this;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:28 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
