(function(){var P$=Clazz.newPackage("jspecview.common"),p$1={},I$=[[0,'javajs.util.PT']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PeakInfo");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['xMin','xMax','yMin','yMax'],'I',['px0','px1'],'S',['stringInfo','type','type2','index','file','filePathForwardSlash','title','model','atoms','id','_match','atomKey'],'O',['spectrum','jspecview.common.Spectrum']]
,['O',['nullPeakInfo','jspecview.common.PeakInfo']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S',  function (s) {
;C$.$init$.apply(this);
this.stringInfo=s;
this.type=$I$(1).getQuotedAttribute$S$S(s, "type");
if (this.type == null ) this.type="";
this.type=this.type.toUpperCase$();
var pt=this.type.indexOf$I("/");
this.type2=(pt < 0 ? "" : C$.fixType$S(this.type.substring$I(this.type.indexOf$I("/") + 1)));
if (pt >= 0) this.type=C$.fixType$S(this.type.substring$I$I(0, pt)) + "/" + this.type2 ;
 else this.type=C$.fixType$S(this.type);
this.id=$I$(1).getQuotedAttribute$S$S(s, "id");
this.index=$I$(1).getQuotedAttribute$S$S(s, "index");
this.file=$I$(1).getQuotedAttribute$S$S(s, "file");
System.out.println$S("pi file=" + this.file);
this.filePathForwardSlash=(this.file == null  ? null : this.file.replace$C$C("\\", "/"));
this.model=$I$(1).getQuotedAttribute$S$S(s, "model");
var isBaseModel=s.contains$CharSequence("baseModel=\"\"");
if (!isBaseModel) this.atoms=$I$(1).getQuotedAttribute$S$S(s, "atoms");
this.atomKey="," + this.atoms + "," ;
this.title=$I$(1).getQuotedAttribute$S$S(s, "title");
this._match=$I$(1).getQuotedAttribute$S$S(s, "_match");
this.xMax=$I$(1,"parseDouble$S",[$I$(1).getQuotedAttribute$S$S(s, "xMax")]);
this.xMin=$I$(1,"parseDouble$S",[$I$(1).getQuotedAttribute$S$S(s, "xMin")]);
this.yMax=$I$(1,"parseDouble$S",[$I$(1).getQuotedAttribute$S$S(s, "yMax")]);
this.yMin=$I$(1,"parseDouble$S",[$I$(1).getQuotedAttribute$S$S(s, "yMin")]);
}, 1);

Clazz.newMeth(C$, 'isClearAll$',  function () {
return (this.spectrum == null );
});

Clazz.newMeth(C$, 'getType$',  function () {
return this.type;
});

Clazz.newMeth(C$, 'getAtoms$',  function () {
return this.atoms;
});

Clazz.newMeth(C$, 'getXMax$',  function () {
return this.xMax;
});

Clazz.newMeth(C$, 'getXMin$',  function () {
return this.xMin;
});

Clazz.newMeth(C$, 'getYMin$',  function () {
return this.yMin;
});

Clazz.newMeth(C$, 'getYMax$',  function () {
return this.yMax;
});

Clazz.newMeth(C$, 'getX$',  function () {
return (this.xMax + this.xMin) / 2;
});

Clazz.newMeth(C$, 'getMatch$',  function () {
return this._match;
});

Clazz.newMeth(C$, 'fixType$S',  function (type) {
return (type.equals$O("HNMR") ? "1HNMR" : type.equals$O("CNMR") ? "13CNMR" : type);
}, 1);

Clazz.newMeth(C$, 'toString',  function () {
return this.stringInfo;
});

Clazz.newMeth(C$, 'getIndex$',  function () {
return this.index;
});

Clazz.newMeth(C$, 'getTitle$',  function () {
return this.title;
});

Clazz.newMeth(C$, 'checkFileIndex$S$S$S',  function (filePath, sIndex, sAtomKey) {
return (sAtomKey != null  ? this.atomKey.indexOf$S(sAtomKey) >= 0 : sIndex.equals$O(this.index) && (filePath.equals$O(this.file) || filePath.equals$O(this.filePathForwardSlash) ) );
});

Clazz.newMeth(C$, 'checkFileTypeModel$S$S$S',  function (filePath, type, model) {
return filePath.equals$O(this.file) && p$1.checkModel$S.apply(this, [model]) && this.type.endsWith$S(type)  ;
});

Clazz.newMeth(C$, 'checkTypeModel$S$S',  function (type, model) {
return p$1.checkType$S.apply(this, [type]) && p$1.checkModel$S.apply(this, [model]) ;
});

Clazz.newMeth(C$, 'checkModel$S',  function (model) {
return (model != null  && model.equals$O(this.model) );
}, p$1);

Clazz.newMeth(C$, 'checkType$S',  function (type) {
return (type.endsWith$S(this.type));
}, p$1);

Clazz.newMeth(C$, 'checkTypeMatch$jspecview_common_PeakInfo',  function (pi) {
return (p$1.checkType$S.apply(this, [pi.type]) && (p$1.checkId$S.apply(this, [pi._match]) || p$1.checkModel$S.apply(this, [pi._match]) || this.title.toUpperCase$().indexOf$S(pi._match) >= 0  ) );
});

Clazz.newMeth(C$, 'checkId$S',  function (match) {
if (match == null ) return false;
return (this.id != null  && match.toUpperCase$().startsWith$S("ID=")  && match.substring$I(3).equals$O(this.id)  || (match=match.toUpperCase$()).startsWith$S("INDEX=") && match.equals$O("INDEX=" + this.index)   || match.startsWith$S("#=") && match.equals$O("#=" + this.index)  );
}, p$1);

Clazz.newMeth(C$, 'getModel$',  function () {
return this.model;
});

Clazz.newMeth(C$, 'getFilePath$',  function () {
return this.file;
});

Clazz.newMeth(C$, 'autoSelectOnLoad$',  function () {
return (this.type.startsWith$S("GC"));
});

Clazz.newMeth(C$, 'setPixelRange$I$I',  function (x0, x1) {
this.px0=x0;
this.px1=x1;
});

Clazz.newMeth(C$, 'checkRange$I$D',  function (xPixel, xVal) {
if (xPixel != 2147483647 ? (this.px0 <= xPixel && this.px1 >= xPixel ) : xVal >= this.xMin  && xVal <= this.xMax  ) {
return Math.abs(xVal - this.getX$());
}return 1.0E100;
});

Clazz.newMeth(C$, 'getXPixel$',  function () {
return ((this.px0 + this.px1)/2|0);
});

C$.$static$=function(){C$.$static$=0;
C$.nullPeakInfo=Clazz.new_(C$);
};
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:52 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
