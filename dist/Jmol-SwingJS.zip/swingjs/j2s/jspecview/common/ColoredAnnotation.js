(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ColoredAnnotation", null, 'jspecview.common.Annotation');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['color','javajs.api.GenericColor']]]

Clazz.newMeth(C$, 'getColor$',  function () {
return this.color;
});

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'setCA$D$D$jspecview_common_Spectrum$S$javajs_api_GenericColor$Z$Z$I$I',  function (x, y, spec, text, color, isPixels, is2D, offsetX, offsetY) {
this.setA$D$D$jspecview_common_Spectrum$S$Z$Z$I$I(x, y, spec, text, isPixels, is2D, offsetX, offsetY);
this.color=color;
return this;
});
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:04 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
