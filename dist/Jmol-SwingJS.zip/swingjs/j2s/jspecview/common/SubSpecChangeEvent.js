(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "SubSpecChangeEvent");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['isub'],'S',['title']]]

Clazz.newMeth(C$, 'c$$I$S',  function (isub, title) {
;C$.$init$.apply(this);
this.isub=isub;
this.title=title;
}, 1);

Clazz.newMeth(C$, 'isValid$',  function () {
return (this.title != null );
});

Clazz.newMeth(C$, 'getSubIndex$',  function () {
return this.isub;
});

Clazz.newMeth(C$, 'toString',  function () {
return this.title;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:06 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
