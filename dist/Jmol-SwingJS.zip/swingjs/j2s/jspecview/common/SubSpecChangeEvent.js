(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "SubSpecChangeEvent");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['isub'],'S',['title']]]

Clazz.newMeth(C$, 'c$$I$S',  function (isub, title) {
;C$.$init$.apply(this);
this.isub=isub;
this.title=title;
}, 1);

Clazz.newMeth(C$, 'isValid$',  function () {
return (this.title != null );
});

Clazz.newMeth(C$, 'getSubIndex$',  function () {
return this.isub;
});

Clazz.newMeth(C$, 'toString',  function () {
return this.title;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:57 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
