(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[[0,'javajs.util.PT']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ScriptTokenizer");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.pt=-1;
this.doCheck=true;
},1);

C$.$fields$=[['Z',['isCmd','doCheck'],'I',['pt','len'],'S',['str']]]

Clazz.newMeth(C$, 'c$$S$Z',  function (str, isCmd) {
;C$.$init$.apply(this);
this.str=str;
this.len=str.length$();
this.isCmd=isCmd;
}, 1);

Clazz.newMeth(C$, 'nextStringToken$jspecview_common_ScriptTokenizer$Z',  function (eachParam, removeQuotes) {
var s=eachParam.nextToken$();
return (removeQuotes && s.charAt$I(0) == "\""  && s.endsWith$S("\"")  && s.length$() > 1  ? $I$(1).trimQuotes$S(s) : s);
}, 1);

Clazz.newMeth(C$, 'nextToken$',  function () {
if (this.doCheck) this.hasMoreTokens$();
var pt0=this.pt;
var inQuote=(this.str.charAt$I(this.pt) == "\"");
while (++this.pt < this.len){
switch ((this.str.charCodeAt$I(this.pt))) {
case 34:
if (inQuote) {
if (this.isCmd) {
inQuote=false;
continue;
}++this.pt;
break;
}if (this.isCmd) inQuote=true;
continue;
case 32:
if (!this.isCmd && !inQuote ) break;
continue;
case 59:
case 10:
if (this.isCmd && !inQuote ) break;
continue;
default:
continue;
}
break;
}
this.doCheck=true;
return this.str.substring$I$I(pt0, this.pt);
});

Clazz.newMeth(C$, 'hasMoreTokens$',  function () {
while (++this.pt < this.len){
switch ((this.str.charCodeAt$I(this.pt))) {
case 32:
case 59:
case 10:
continue;
}
break;
}
this.doCheck=false;
return (this.pt < this.len);
});

Clazz.newMeth(C$, 'getRemainingScript$',  function () {
return this.str.substring$I(this.pt);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:29 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
