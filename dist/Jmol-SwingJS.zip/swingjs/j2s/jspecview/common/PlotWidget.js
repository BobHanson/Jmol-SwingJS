(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[[0,'jspecview.common.ScriptToken']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PlotWidget", null, 'jspecview.common.Coordinate');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.isEnabled=true;
this.isVisible=false;
this.color=$I$(1).PLOTCOLOR;
},1);

C$.$fields$=[['Z',['isPin','isPinOrCursor','isXtype','is2D','is2Donly','isEnabled','isVisible'],'I',['xPixel0','yPixel0','xPixel1','yPixel1'],'S',['name'],'O',['color','jspecview.common.ScriptToken']]]

Clazz.newMeth(C$, 'toString',  function () {
return this.name + (!this.isPinOrCursor ? "" + this.xPixel0 + " " + this.yPixel0 + " / " + this.xPixel1 + " " + this.yPixel1  : " x=" + new Double(this.getXVal$()).toString() + "/" + this.xPixel0 + " y=" + new Double(this.getYVal$()).toString() + "/" + this.yPixel0 );
});

Clazz.newMeth(C$, 'c$$S',  function (name) {
Clazz.super_(C$, this);
this.name=name;
this.isPin=(name.charAt$I(0) == "p");
this.isPinOrCursor=(name.charAt$I(0) != "z");
this.isXtype=(name.indexOf$S("x") >= 0);
this.is2D=(name.indexOf$S("2D") >= 0);
this.is2Donly=(this.is2D && name.charAt$I(0) == "p" );
}, 1);

Clazz.newMeth(C$, 'selected$I$I',  function (xPixel, yPixel) {
return (this.isVisible && Math.abs(xPixel - this.xPixel0) < 5  && Math.abs(yPixel - this.yPixel0) < 5 );
});

Clazz.newMeth(C$, 'setX$D$I',  function (x, xPixel) {
this.setXVal$D(x);
this.xPixel0=this.xPixel1=xPixel;
});

Clazz.newMeth(C$, 'setY$D$I',  function (y, yPixel) {
this.setYVal$D(y);
this.yPixel0=this.yPixel1=yPixel;
});

Clazz.newMeth(C$, 'getValue$',  function () {
return (this.isXtype ? this.getXVal$() : this.getYVal$());
});

Clazz.newMeth(C$, 'setEnabled$Z',  function (enabled) {
this.isEnabled=enabled;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:52 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
