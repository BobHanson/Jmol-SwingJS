(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[[0,'javajs.export.PDFCreator','java.util.Hashtable','jspecview.common.JSVersion']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PDFWriter", null, null, ['org.jmol.api.GenericGraphics', 'jspecview.api.JSVPdfWriter']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.rgb=Clazz.array(Float.TYPE, [3]);
},1);

C$.$fields$=[['Z',['inPath'],'S',['date'],'O',['g2d','org.jmol.api.GenericGraphics','pdf','javajs.export.PDFCreator','rgb','float[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.pdf=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'createPdfDocument$jspecview_api_JSVPanel$jspecview_common_PrintLayout$java_io_OutputStream',  function (panel, pl, os) {
var isLandscape=pl.layout.equals$O("landscape");
this.date=pl.date;
this.pdf.setOutputStream$java_io_OutputStream(os);
this.g2d=panel.getPanelData$().g2d;
try {
this.pdf.newDocument$I$I$Z(pl.paperWidth, pl.paperHeight, isLandscape);
var ht=Clazz.new_($I$(2,1));
ht.put$O$O("Producer", $I$(3).VERSION);
ht.put$O$O("Creator", "JSpecView " + $I$(3).VERSION);
ht.put$O$O("Author", "JSpecView");
if (this.date != null ) ht.put$O$O("CreationDate", this.date);
this.pdf.addInfo$java_util_Map(ht);
panel.getPanelData$().printPdf$org_jmol_api_GenericGraphics$jspecview_common_PrintLayout(this, pl);
this.pdf.closeDocument$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
panel.showMessage$S$S(e.toString(), "PDF Creation Error");
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'canDoLineTo$',  function () {
return true;
});

Clazz.newMeth(C$, 'doStroke$O$Z',  function (g, isBegin) {
this.inPath=isBegin;
if (!this.inPath) this.pdf.stroke$();
});

Clazz.newMeth(C$, 'drawCircle$O$I$I$I',  function (g, x, y, diameter) {
this.pdf.doCircle$I$I$I$Z(x, y, ((diameter / 2.0)|0), false);
});

Clazz.newMeth(C$, 'drawLine$O$I$I$I$I',  function (g, x0, y0, x1, y1) {
this.pdf.moveto$I$I(x0, y0);
this.pdf.lineto$I$I(x1, y1);
if (!this.inPath) this.pdf.stroke$();
});

Clazz.newMeth(C$, 'drawPolygon$O$IA$IA$I',  function (g, axPoints, ayPoints, nPoints) {
this.pdf.doPolygon$IA$IA$I$Z(axPoints, ayPoints, nPoints, false);
});

Clazz.newMeth(C$, 'drawRect$O$I$I$I$I',  function (g, x, y, width, height) {
this.pdf.doRect$I$I$I$I$Z(x, y, width, height, false);
});

Clazz.newMeth(C$, 'drawString$O$S$I$I',  function (g, s, x, y) {
this.pdf.drawStringRotated$S$I$I$I(s, x, y, 0);
});

Clazz.newMeth(C$, 'drawStringRotated$O$S$I$I$D',  function (g, s, x, y, angle) {
this.pdf.drawStringRotated$S$I$I$I(s, x, y, (angle|0));
});

Clazz.newMeth(C$, 'fillBackground$O$javajs_api_GenericColor',  function (g, bgcolor) {
});

Clazz.newMeth(C$, 'fillCircle$O$I$I$I',  function (g, x, y, diameter) {
this.pdf.doCircle$I$I$I$Z(x, y, ((diameter / 2.0)|0), true);
});

Clazz.newMeth(C$, 'fillPolygon$O$IA$IA$I',  function (g, ayPoints, axPoints, nPoints) {
this.pdf.doPolygon$IA$IA$I$Z(axPoints, ayPoints, nPoints, true);
});

Clazz.newMeth(C$, 'fillRect$O$I$I$I$I',  function (g, x, y, width, height) {
this.pdf.doRect$I$I$I$I$Z(x, y, width, height, true);
});

Clazz.newMeth(C$, 'lineTo$O$I$I',  function (g, x, y) {
this.pdf.lineto$I$I(x, y);
});

Clazz.newMeth(C$, 'setGraphicsColor$O$javajs_api_GenericColor',  function (g, c) {
var p=c.getRGB$();
this.rgb[0]=(p >> 16) & 255;
this.rgb[1]=(p >> 8) & 255;
this.rgb[2]=(p & 255);
this.pdf.setColor$FA$Z(this.rgb, true);
this.pdf.setColor$FA$Z(this.rgb, false);
});

Clazz.newMeth(C$, 'setFont$O$org_jmol_util_Font',  function (g, font) {
var fname="/Helvetica";
switch (font.idFontStyle) {
case 1:
fname+="-Bold";
break;
case 3:
fname+="-BoldOblique";
break;
case 2:
fname+="-Oblique";
break;
}
this.pdf.setFont$S$F(fname, font.fontSizeNominal);
return font;
});

Clazz.newMeth(C$, 'setStrokeBold$O$Z',  function (g, tf) {
this.pdf.setLineWidth$F(tf ? 2 : 1);
});

Clazz.newMeth(C$, 'translateScale$O$D$D$D',  function (g, x, y, scale) {
this.pdf.translateScale$F$F$F(x, y, scale);
});

Clazz.newMeth(C$, 'newGrayScaleImage$O$O$I$I$IA',  function (g, image, width, height, buffer) {
this.pdf.addImageResource$O$I$I$IA$Z(image, width, height, buffer, false);
return image;
});

Clazz.newMeth(C$, 'drawGrayScaleImage$O$O$I$I$I$I$I$I$I$I',  function (g, image, destX0, destY0, destX1, destY1, srcX0, srcY0, srcX1, srcY1) {
this.pdf.drawImage$O$I$I$I$I$I$I$I$I(image, destX0, destY0, destX1, destY1, srcX0, srcY0, srcX1, srcY1);
});

Clazz.newMeth(C$, 'setWindowParameters$I$I',  function (width, height) {
});

Clazz.newMeth(C$, 'getColor1$I',  function (argb) {
return this.g2d.getColor1$I(argb);
});

Clazz.newMeth(C$, 'getColor3$I$I$I',  function (red, green, blue) {
return this.g2d.getColor3$I$I$I(red, green, blue);
});

Clazz.newMeth(C$, 'getColor4$I$I$I$I',  function (r, g, b, a) {
return this.g2d.getColor4$I$I$I$I(r, g, b, a);
});
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:52 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
