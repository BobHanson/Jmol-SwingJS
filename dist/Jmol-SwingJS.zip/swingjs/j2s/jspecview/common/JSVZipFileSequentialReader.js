(function(){var P$=Clazz.newPackage("jspecview.common"),p$1={},I$=[[0,'java.io.StringReader','java.util.zip.ZipInputStream','org.jmol.util.Logger','javajs.util.SB']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JSVZipFileSequentialReader", null, 'java.io.BufferedReader', 'jspecview.api.JSVZipReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.buf=Clazz.array(Byte.TYPE, [1024]);
this.cr="\u0000";
},1);

C$.$fields$=[['C',['cr'],'I',['ptMark','lineCount','len','pt'],'S',['data','startCode'],'O',['subFileList','String[]','zis','java.util.zip.ZipInputStream','ze','java.util.zip.ZipEntry','buf','byte[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$java_io_Reader.apply(this,[Clazz.new_($I$(1,1).c$$S,[""])]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'set$java_io_InputStream$SA$S',  function (bis, subFileList, startCode) {
this.subFileList=subFileList;
this.zis=Clazz.new_($I$(2,1).c$$java_io_InputStream,[bis]);
this.startCode=startCode;
p$1.nextEntry.apply(this, []);
return this;
});

Clazz.newMeth(C$, 'close$',  function () {
try {
this.zis.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'mark$I',  function (limit) {
this.ptMark=this.pt;
if (this.len == 0) {
this.readLine$();
this.pt=this.ptMark;
}});

Clazz.newMeth(C$, 'reset$',  function () {
this.pt=this.ptMark;
});

Clazz.newMeth(C$, 'read$CA$I$I',  function (chars, chPt, chLen) {
var l=Math.min(this.len - this.pt, chLen);
this.data.getChars$I$I$CA$I(0, l, chars, chPt);
return l;
});

Clazz.newMeth(C$, 'readLine$',  function () {
while (this.ze != null ){
try {
var line=p$1.getEntryLine.apply(this, []);
if (line != null ) return line;
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
break;
} else {
throw e;
}
}
p$1.nextEntry.apply(this, []);
}
return null;
});

Clazz.newMeth(C$, 'nextEntry',  function () {
this.len=this.pt=0;
this.cr="\u0000";
this.lineCount=0;
try {
while ((this.ze=this.zis.getNextEntry$()) != null )if (p$1.isEntryOK$S.apply(this, [this.ze.getName$()])) return;

} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.ze=null;
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'isEntryOK$S',  function (name) {
if (this.subFileList == null  || this.subFileList.length == 1 ) return true;
for (var i=this.subFileList.length; --i >= 0; ) if (this.subFileList[i].equals$O(name)) {
$I$(3).info$S("...reading zip entry " + name);
return true;
}
$I$(3).info$S("...skipping zip entry " + name);
return false;
}, p$1);

Clazz.newMeth(C$, 'getEntryLine',  function () {
var line=null;
while (this.len >= 0 && (this.pt < this.len || this.zis.available$() == 1 ) ){
var pt0=this.pt;
var ch=" ";
while (this.pt < this.len && ch != this.cr ){
switch ((ch=this.data.charAt$I(this.pt++)).$c()) {
case 10:
if (this.cr == "\r") {
pt0=this.pt;
continue;
}this.cr="\n";
break;
case 13:
if (this.cr == "\n") continue;
this.cr="\r";
break;
}
}
if (line == null ) line=Clazz.new_($I$(4,1));
if (this.pt != pt0) line.append$S(this.data.substring$I$I(pt0, this.pt + (ch == this.cr ? -1 : 0)));
if (ch == this.cr || this.zis.available$() != 1  || (this.len=this.zis.read$BA$I$I(this.buf, 0, 1024)) < 0 ) {
if (this.lineCount++ == 0 && this.startCode != null   && line.indexOf$S(this.startCode) < 0 ) return null;
return line.toString();
}this.pt=0;
this.data= String.instantialize(this.buf, 0, this.len);
if (this.data.indexOf$I("\u0000") >= 0) return null;
}
return (line == null  ? null : line.toString());
}, p$1);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:51 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
