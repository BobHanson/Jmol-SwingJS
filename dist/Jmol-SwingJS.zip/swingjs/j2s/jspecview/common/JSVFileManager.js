(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[[0,'java.util.Hashtable','javajs.util.SB','java.io.BufferedReader','java.io.InputStreamReader','java.io.StringReader','org.jmol.util.Logger','java.net.URL','javajs.util.PT','java.io.BufferedInputStream','jspecview.common.JSViewer','javajs.util.AU','javajs.util.Encoding','javajs.util.JSJSONParser','jspecview.common.JSVersion','javajs.util.BS','javajs.util.P3d']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JSVFileManager");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['I',['stringCount'],'S',['jsDocumentBase','nciResolver','nmrdbServerH1','nmrdbServerC13'],'O',['appletDocumentBase','java.net.URL','viewer','jspecview.common.JSViewer','urlPrefixes','String[]','htCorrelationCache','java.util.Map']]]

Clazz.newMeth(C$, 'isApplet$',  function () {
return (C$.appletDocumentBase != null );
});

Clazz.newMeth(C$, 'getFileAsString$S',  function (name) {
if (name == null ) return null;
var br;
var sb=Clazz.new_($I$(2,1));
try {
br=C$.getBufferedReaderFromName$S$S(name, null);
var line;
while ((line=br.readLine$()) != null ){
sb.append$S(line);
sb.appendC$C("\n");
}
br.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return null;
} else {
throw e;
}
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'getBufferedReaderForInputStream$java_io_InputStream',  function ($in) {
try {
return Clazz.new_([Clazz.new_($I$(4,1).c$$java_io_InputStream$S,[$in, "UTF-8"])],$I$(3,1).c$$java_io_Reader);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getBufferedReaderForStringOrBytes$O',  function (stringOrBytes) {
return (stringOrBytes == null  ? null : Clazz.new_([Clazz.new_([Clazz.instanceOf(stringOrBytes, "java.lang.String") ? stringOrBytes :  String.instantialize(stringOrBytes)],$I$(5,1).c$$S)],$I$(3,1).c$$java_io_Reader));
}, 1);

Clazz.newMeth(C$, 'getBufferedReaderFromName$S$S',  function (name, startCode) {
if (name == null ) throw Clazz.new_(Clazz.load('jspecview.exception.JSVException').c$$S,["Cannot find " + name]);
$I$(6).info$S("JSVFileManager getBufferedReaderFromName " + name);
var path=C$.getFullPathName$S(name);
if (!path.equals$O(name)) $I$(6).info$S("JSVFileManager getBufferedReaderFromName " + path);
return C$.getUnzippedBufferedReaderFromName$S$S(path, startCode);
}, 1);

Clazz.newMeth(C$, 'getFullPathName$S',  function (name) {
try {
if (C$.appletDocumentBase == null ) {
if (C$.isURL$S(name)) {
var url=Clazz.new_($I$(7,1).c$$java_net_URL$S$java_net_URLStreamHandler,[null, name, null]);
return url.toString();
}return C$.newFile$S(name).getFullPath$();
}if (name.indexOf$S(":\\") == 1 || name.indexOf$S(":/") == 1 ) name="file:///" + name;
 else if (name.startsWith$S("cache://")) return name;
var url=Clazz.new_($I$(7,1).c$$java_net_URL$S$java_net_URLStreamHandler,[C$.appletDocumentBase, name, null]);
return url.toString();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
throw Clazz.new_(Clazz.load('jspecview.exception.JSVException').c$$S,["Cannot create path for " + name]);
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'isURL$S',  function (name) {
for (var i=C$.urlPrefixes.length; --i >= 0; ) if (name.startsWith$S(C$.urlPrefixes[i])) return true;

return false;
}, 1);

Clazz.newMeth(C$, 'urlTypeIndex$S',  function (name) {
for (var i=0; i < C$.urlPrefixes.length; ++i) {
if (name.startsWith$S(C$.urlPrefixes[i])) {
return i;
}}
return -1;
}, 1);

Clazz.newMeth(C$, 'isLocal$S',  function (fileName) {
if (fileName == null ) return false;
var itype=C$.urlTypeIndex$S(fileName);
return (itype < 0 || itype == 4 );
}, 1);

Clazz.newMeth(C$, 'getUnzippedBufferedReaderFromName$S$S',  function (name, startCode) {
var subFileList=null;
if (name.indexOf$S("|") >= 0) {
subFileList=$I$(8).split$S$S(name, "|");
if (subFileList != null  && subFileList.length > 0 ) name=subFileList[0];
}if (name.startsWith$S("http://SIMULATION/")) return C$.getSimulationReader$S(name);
try {
var ret=C$.getInputStream$S$Z$BA(name, true, null);
if (Clazz.instanceOf(ret, "javajs.util.SB") || Clazz.instanceOf(ret, "java.lang.String") ) return Clazz.new_([Clazz.new_([ret.toString()],$I$(5,1).c$$S)],$I$(3,1).c$$java_io_Reader);
if (C$.isAB$O(ret)) return Clazz.new_([Clazz.new_([ String.instantialize(ret)],$I$(5,1).c$$S)],$I$(3,1).c$$java_io_Reader);
var bis=Clazz.new_($I$(9,1).c$$java_io_InputStream,[ret]);
var $in=bis;
if (C$.isGzip$java_io_InputStream(bis)) $in=($I$(10).getInterface$S("jspecview.common.JSVZipUtil")).newGZIPInputStream$java_io_InputStream($in);
return Clazz.new_([Clazz.new_($I$(4,1).c$$java_io_InputStream$S,[$in, "UTF-8"])],$I$(3,1).c$$java_io_Reader);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
throw e;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getAbbrSimulationFileName$S',  function (name) {
var type=C$.getSimulationType$S(name);
var filename=C$.getAbbreviatedSimulationName$S$S$Z(name, type, true);
return filename;
}, 1);

Clazz.newMeth(C$, 'getAbbreviatedSimulationName$S$S$Z',  function (name, type, addProtocol) {
return (name.indexOf$S("MOL=") >= 0 ? (addProtocol ? "http://SIMULATION/" : "") + "MOL=" + C$.getSimulationHash$S$S(name, type)  : name);
}, 1);

Clazz.newMeth(C$, 'getSimulationHash$S$S',  function (name, type) {
var code=type + Math.abs(name.substring$I(name.indexOf$S("V2000") + 1).hashCode$());
if ($I$(6).debugging) System.out.println$S("JSVFileManager hash for " + name + " = " + code );
return code;
}, 1);

Clazz.newMeth(C$, 'getSimulationFileData$S$S',  function (name, type) {
return C$.cacheGet$S(name.startsWith$S("MOL=") ? name.substring$I(4) : C$.getAbbreviatedSimulationName$S$S$Z(name, type, false));
}, 1);

Clazz.newMeth(C$, 'cachePut$S$S',  function (name, data) {
if ($I$(6).debugging) $I$(6).debug$S("JSVFileManager cachePut " + data + " for " + name );
if (data != null ) C$.htCorrelationCache.put$O$O(name, data);
}, 1);

Clazz.newMeth(C$, 'cacheGet$S',  function (key) {
var data=C$.htCorrelationCache.get$O(key);
if ($I$(6).debugging) $I$(6).info$S("JSVFileManager cacheGet " + data + " for " + key );
return data;
}, 1);

Clazz.newMeth(C$, 'getSimulationReader$S',  function (name) {
var data=C$.cacheGet$S(name);
if (data == null ) C$.cachePut$S$S(name, data=C$.getNMRSimulationJCampDX$S(name.substring$I("http://SIMULATION/".length$())));
return C$.getBufferedReaderForStringOrBytes$O(data);
}, 1);

Clazz.newMeth(C$, 'isAB$O',  function (x) {
return $I$(11).isAB$O(x);
}, 1);

Clazz.newMeth(C$, 'isZipFile$java_io_InputStream',  function (is) {
try {
var abMagic=Clazz.array(Byte.TYPE, [4]);
is.mark$I(5);
var countRead=is.read$BA$I$I(abMagic, 0, 4);
is.reset$();
return (countRead == 4 && abMagic[0] == 80  && abMagic[1] == 75  && abMagic[2] == 3  && abMagic[3] == 4 );
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
throw Clazz.new_(Clazz.load('jspecview.exception.JSVException').c$$S,[e.toString()]);
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'isGzip$java_io_InputStream',  function (is) {
try {
var abMagic=Clazz.array(Byte.TYPE, [4]);
is.mark$I(5);
var countRead=is.read$BA$I$I(abMagic, 0, 4);
is.reset$();
return (countRead == 4 && abMagic[0] == 31  && abMagic[1] == -117 );
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
throw Clazz.new_(Clazz.load('jspecview.exception.JSVException').c$$S,[e.toString()]);
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getStreamAsBytes$java_io_BufferedInputStream$javajs_util_OC',  function (bis, out) {
try {
var buf=Clazz.array(Byte.TYPE, [1024]);
var bytes=(out == null  ? Clazz.array(Byte.TYPE, [4096]) : null);
var len=0;
var totalLen=0;
while ((len=bis.read$BA$I$I(buf, 0, 1024)) > 0){
totalLen+=len;
if (out == null ) {
if (totalLen >= bytes.length) bytes=$I$(11).ensureLengthByte$BA$I(bytes, totalLen * 2);
System.arraycopy$O$I$O$I$I(buf, 0, bytes, totalLen - len, len);
} else {
out.write$BA$I$I(buf, 0, len);
}}
bis.close$();
if (out == null ) {
return $I$(11).arrayCopyByte$BA$I(bytes, totalLen);
}return totalLen + " bytes";
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
throw Clazz.new_(Clazz.load('jspecview.exception.JSVException').c$$S,[e.toString()]);
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'postByteArray$S$BA',  function (fileName, bytes) {
var ret=null;
try {
ret=C$.getInputStream$S$Z$BA(fileName, false, bytes);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
ret=e.toString();
} else {
throw e;
}
}
if (Clazz.instanceOf(ret, "java.lang.String")) return ret;
try {
ret=C$.getStreamAsBytes$java_io_BufferedInputStream$javajs_util_OC(ret, null);
} catch (e) {
if (Clazz.exceptionOf(e,"jspecview.exception.JSVException")){
try {
(ret).close$();
} catch (e1) {
if (Clazz.exceptionOf(e1,"Exception")){
} else {
throw e1;
}
}
} else {
throw e;
}
}
return (ret == null  ? "" : C$.fixUTF$BA(ret));
}, 1);

Clazz.newMeth(C$, 'getUTFEncoding$BA',  function (bytes) {
if (bytes.length >= 3 && bytes[0] == -17  && bytes[1] == -69  && bytes[2] == -65 ) return $I$(12).UTF8;
if (bytes.length >= 4 && bytes[0] == 0  && bytes[1] == 0  && bytes[2] == -2  && bytes[3] == -1 ) return $I$(12).UTF_32BE;
if (bytes.length >= 4 && bytes[0] == -1  && bytes[1] == -2  && bytes[2] == 0  && bytes[3] == 0 ) return $I$(12).UTF_32LE;
if (bytes.length >= 2 && bytes[0] == -1  && bytes[1] == -2 ) return $I$(12).UTF_16LE;
if (bytes.length >= 2 && bytes[0] == -2  && bytes[1] == -1 ) return $I$(12).UTF_16BE;
return $I$(12).NONE;
}, 1);

Clazz.newMeth(C$, 'fixUTF$BA',  function (bytes) {
var encoding=C$.getUTFEncoding$BA(bytes);
if (encoding !== $I$(12).NONE ) try {
var s= String.instantialize(bytes, encoding.name$().replace$C$C("_", "-"));
switch (encoding) {
case $I$(12).UTF8:
case $I$(12).UTF_16BE:
case $I$(12).UTF_16LE:
s=s.substring$I(1);
break;
default:
break;
}
return s;
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
$I$(6).error$S("fixUTF error " + e);
} else {
throw e;
}
}
return  String.instantialize(bytes);
}, 1);

Clazz.newMeth(C$, 'getInputStream$S$Z$BA',  function (name, showMsg, postBytes) {
var isURL=C$.isURL$S(name);
var isApplet=(C$.appletDocumentBase != null );
var $in=null;
var post=null;
var iurl;
if (isURL && (iurl=name.indexOf$S("?POST?")) >= 0 ) {
post=name.substring$I(iurl + 6);
name=name.substring$I$I(0, iurl);
}if (isApplet || isURL ) {
var url;
try {
url=Clazz.new_($I$(7,1).c$$java_net_URL$S$java_net_URLStreamHandler,[C$.appletDocumentBase, name, null]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
throw Clazz.new_(Clazz.load('jspecview.exception.JSVException').c$$S,["Cannot read " + name]);
} else {
throw e;
}
}
$I$(6,"info$S",["JSVFileManager opening URL " + url + (post == null  ? "" : " with POST of " + post.length$() + " bytes" ) ]);
$in=C$.viewer.apiPlatform.getURLContents$java_net_URL$BA$S$Z(url, postBytes, post, false);
} else {
if (showMsg) $I$(6).info$S("JSVFileManager opening file " + name);
$in=C$.viewer.apiPlatform.getBufferedFileInputStream$S(name);
}if (Clazz.instanceOf($in, "java.lang.String")) throw Clazz.new_(Clazz.load('jspecview.exception.JSVException').c$$S,["\n" + $in]);
return $in;
}, 1);

Clazz.newMeth(C$, 'getNMRSimulationJCampDX$S',  function (name) {
var pt=0;
var molFile=null;
var type=C$.getSimulationType$S(name);
if (name.startsWith$S(type)) name=name.substring$I(type.length$() + 1);
var isInline=name.startsWith$S("MOL=");
if (isInline) {
name=name.substring$I(4);
pt=name.indexOf$S("/n__Jmol");
if (pt > 0) name=name.substring$I$I(0, pt) + $I$(8,"rep$S$S$S",[name.substring$I(pt), "/n", "\n"]);
molFile=name=$I$(8).rep$S$S$S(name, "\\n", "\n");
}var key="" + C$.getSimulationHash$S$S(name, type);
if ($I$(6).debugging) $I$(6,"info$S",["JSVFileManager type=" + type + " key=" + key + " name=" + name ]);
var jcamp=C$.cacheGet$S(key);
if (jcamp != null ) return jcamp;
var src=(isInline ? null : $I$(8,"rep$S$S$S",[C$.nciResolver, "%FILE", $I$(8).escapeUrl$S(name)]));
if (!isInline && (molFile=C$.getFileAsString$S(src)) == null   || molFile.indexOf$S("<html") >= 0 ) {
$I$(6).error$S("no MOL data returned by NCI");
return null;
}var is13C=type.equals$O("C13");
var url=(is13C ? C$.nmrdbServerC13 : C$.nmrdbServerH1);
var json=C$.getFileAsString$S(url + molFile);
var map=(Clazz.new_($I$(13,1))).parseMap$S$Z(json, true);
C$.cachePut$S$S("json", json);
if (is13C) map=map.get$O("result");
var jsonMolFile=map.get$O("molfile");
if (jsonMolFile == null ) {
System.out.println$S("JSVFileManager: no MOL file returned from EPFL");
jsonMolFile=molFile;
} else {
System.out.println$S("JSVFileManager: MOL file hash=" + jsonMolFile.hashCode$());
}var atomMap=C$.getAtomMap$S$S(jsonMolFile, molFile);
C$.cachePut$S$S("mol", molFile);
{
if (!isInline) Jmol.Cache.put("http://SIMULATION/" + type +
"/" + name + "#molfile", molFile.getBytes());
}
var xml="<Signals src=" + $I$(8,"esc$S",[$I$(8,"rep$S$S$S",[is13C ? C$.nmrdbServerC13 : C$.nmrdbServerH1, "?POST?molfile=", ""])]) + ">\n" ;
if (is13C) {
var spec=map.get$O("spectrum13C");
jcamp=(spec.get$O("jcamp")).get$O("value");
var lst=spec.get$O("predCSNuc");
var sb=Clazz.new_($I$(2,1));
for (var i=lst.size$(); --i >= 0; ) {
map=lst.get$I(i);
sb.append$S("<Signal ");
C$.setAttr$javajs_util_SB$S$S$java_util_Map(sb, "type", "nucleus", map);
if (atomMap == null ) C$.setAttr$javajs_util_SB$S$S$java_util_Map(sb, "atoms", "assignment", map);
 else sb.append$S("atoms=\"").appendI$I(atomMap[$I$(8,"parseInt$S",[map.get$O("assignment")])]).append$S("\" ");
C$.setAttr$javajs_util_SB$S$S$java_util_Map(sb, "multiplicity", "multiplicity", map);
map=map.get$O("integralData");
C$.setAttr$javajs_util_SB$S$S$java_util_Map(sb, "xMin", "from", map);
C$.setAttr$javajs_util_SB$S$S$java_util_Map(sb, "xMax", "to", map);
C$.setAttr$javajs_util_SB$S$S$java_util_Map(sb, "integral", "value", map);
sb.append$S("></Signal>\n");
}
sb.append$S("</Signals>");
xml+=sb.toString();
} else {
xml=$I$(8,"rep$S$S$S",[map.get$O("xml"), "<Signals>", xml]);
if (atomMap != null ) {
var sb=Clazz.new_($I$(2,1));
var signals=$I$(8,"split$S$S",[xml, " atoms=\""]);
sb.append$S(signals[0]);
for (var i=1; i < signals.length; i++) {
var s=signals[i];
var a=$I$(8).parseInt$S(s);
sb.append$S(" atoms=\"").appendI$I(atomMap[a]).append$S(s.substring$I(s.indexOf$S("\"")));
}
xml=sb.toString();
}xml=$I$(8).rep$S$S$S(xml, "</", "\n</");
xml=$I$(8).rep$S$S$S(xml, "><", ">\n<");
xml=$I$(8).rep$S$S$S(xml, "\\\"", "\"");
jcamp=map.get$O("jcamp");
}if ($I$(6).debugging) $I$(6).info$S(xml);
C$.cachePut$S$S("xml", xml);
jcamp="##TITLE=" + (isInline ? "JMOL SIMULATION/" + type : name) + "\n" + jcamp.substring$I(jcamp.indexOf$S("\n##") + 1) ;
pt=molFile.indexOf$S("\n");
pt=molFile.indexOf$S$I("\n", pt + 1);
if (pt > 0 && pt == molFile.indexOf$S("\n \n") ) molFile=molFile.substring$I$I(0, pt + 1) + "Created " + C$.viewer.apiPlatform.getDateFormat$S("8824") + " by JSpecView " + $I$(14).VERSION + molFile.substring$I(pt + 1) ;
pt=0;
pt=jcamp.indexOf$S("##.");
var id=C$.getAbbreviatedSimulationName$S$S$Z(name, type, false);
var pt1=id.indexOf$S("id=\'");
if (isInline && pt1 > 0 ) id=id.substring$I$I(pt1 + 4, (id + "'").indexOf$S$I("\'", pt1 + 4));
jcamp=jcamp.substring$I$I(0, pt) + "##$MODELS=\n<Models>\n" + "<ModelData id=" + $I$(8).esc$S(id) + " type=\"MOL\" src=" + $I$(8).esc$S(src) + ">\n" + molFile + "</ModelData>\n</Models>\n" + "##$SIGNALS=\n" + xml + "\n" + jcamp.substring$I(pt) ;
C$.cachePut$S$S("jcamp", jcamp);
C$.cachePut$S$S(key, jcamp);
return jcamp;
}, 1);

Clazz.newMeth(C$, 'getAtomMap$S$S',  function (jsonMolFile, jmolMolFile) {
var acJson=C$.getCoord$S(jsonMolFile);
var acJmol=C$.getCoord$S(jmolMolFile);
var n=acJson.length;
if (n != acJmol.length) return null;
var map=Clazz.array(Integer.TYPE, [n]);
var bs=Clazz.new_($I$(15,1));
bs.setBits$I$I(0, n);
var haveMap=false;
for (var i=0; i < n; i++) {
var a=acJson[i];
for (var j=bs.nextSetBit$I(0); j >= 0; j=bs.nextSetBit$I(j + 1)) {
if (a.distanceSquared$javajs_util_T3d(acJmol[j]) < 0.1 ) {
bs.clear$I(j);
map[i]=j;
if (i != j) haveMap=true;
break;
}}
}
return (haveMap ? map : null);
}, 1);

Clazz.newMeth(C$, 'getCoord$S',  function (mol) {
var lines=$I$(8).split$S$S(mol, "\n");
var data=Clazz.array(Double.TYPE, [3]);
var n=Integer.parseInt$S(lines[3].substring$I$I(0, 3).trim$());
var pts=Clazz.array($I$(16), [n]);
for (var i=0; i < n; i++) {
var line=lines[4 + i];
$I$(8,"parseDoubleArrayInfested$SA$DA",[$I$(8,"getTokens$S",[line.substring$I$I(0, 31)]), data]);
pts[i]=$I$(16).new3$D$D$D(data[0], data[1], data[2]);
}
return pts;
}, 1);

Clazz.newMeth(C$, 'setAttr$javajs_util_SB$S$S$java_util_Map',  function (sb, mykey, lucsKey, map) {
sb.append$S(mykey + "=\"").appendO$O(map.get$O(lucsKey)).append$S("\" ");
}, 1);

Clazz.newMeth(C$, 'getResource$O$S$SA',  function (object, fileName, error) {
var url=null;
try {
if ((url=object.getClass$().getResource$S(fileName)) == null ) error[0]="Couldn't find file: " + fileName;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
error[0]="Exception " + e + " in getResource " + fileName ;
} else {
throw e;
}
}
return url;
}, 1);

Clazz.newMeth(C$, 'getResourceString$O$S$SA',  function (object, name, error) {
var url=C$.getResource$O$S$SA(object, name, error);
if (url == null ) {
error[0]="Error loading resource " + name;
return null;
}if (Clazz.instanceOf(url, "java.lang.String")) {
return C$.getFileAsString$S(url);
}var sb=Clazz.new_($I$(2,1));
try {
var br=Clazz.new_([Clazz.new_([(url).getContent$(), "UTF-8"],$I$(4,1).c$$java_io_InputStream$S)],$I$(3,1).c$$java_io_Reader);
var line;
while ((line=br.readLine$()) != null )sb.append$S(line).append$S("\n");

br.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
error[0]=e.toString();
} else {
throw e;
}
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'getJmolFilePath$S',  function (filePath) {
try {
filePath=C$.getFullPathName$S(filePath);
} catch (e) {
if (Clazz.exceptionOf(e,"jspecview.exception.JSVException")){
return null;
} else {
throw e;
}
}
return (C$.appletDocumentBase == null  ? filePath.replace$C$C("\\", "/") : filePath);
}, 1);

Clazz.newMeth(C$, 'getTagName$S',  function (fileName) {
if (fileName == null ) return "String" + (++C$.stringCount);
if (C$.isURL$S(fileName)) {
try {
if (fileName.startsWith$S("http://SIMULATION/")) return C$.getAbbrSimulationFileName$S(fileName);
var name=(Clazz.new_($I$(7,1).c$$java_net_URL$S$java_net_URLStreamHandler,[null, fileName, null])).getFile$();
return name.substring$I(name.lastIndexOf$I("/") + 1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
return null;
} else {
throw e;
}
}
}return C$.newFile$S(fileName).getName$();
}, 1);

Clazz.newMeth(C$, 'newFile$S',  function (fileName) {
return C$.viewer.apiPlatform.newFile$S(fileName);
}, 1);

Clazz.newMeth(C$, 'setDocumentBase$jspecview_common_JSViewer$java_net_URL',  function (v, documentBase) {
C$.viewer=v;
C$.appletDocumentBase=documentBase;
}, 1);

Clazz.newMeth(C$, 'getSimulationType$S',  function (filePath) {
return (filePath.indexOf$S("C13/") >= 0 ? "C13" : "H1");
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.jsDocumentBase="";
C$.urlPrefixes=Clazz.array(String, -1, ["http:", "https:", "ftp:", "http://SIMULATION/", "file:"]);
C$.htCorrelationCache=Clazz.new_($I$(1,1));
C$.nciResolver="https://cactus.nci.nih.gov/chemical/structure/%FILE/file?format=sdf&get3d=True";
C$.nmrdbServerH1="https://www.nmrdb.org/tools/jmol/predict.php?POST?molfile=";
C$.nmrdbServerC13="https://www.nmrdb.org/service/jsmol13c?POST?molfile=";
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:56 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
