(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[[0,'java.util.zip.GZIPInputStream','jspecview.common.JSVZipFileSequentialReader']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JSVZipUtil", null, null, 'jspecview.api.JSVZipInterface');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'newGZIPInputStream$java_io_InputStream',  function (bis) {
return Clazz.new_($I$(1,1).c$$java_io_InputStream$I,[bis, 512]);
});

Clazz.newMeth(C$, 'newJSVZipFileSequentialReader$java_io_InputStream$SA$S',  function ($in, subFileList, startCode) {
return Clazz.new_($I$(2,1)).set$java_io_InputStream$SA$S($in, subFileList, startCode);
});
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:05 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
