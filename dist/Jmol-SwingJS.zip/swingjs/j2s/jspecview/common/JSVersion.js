(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[[0,'java.io.BufferedInputStream','java.util.Properties','javajs.util.PT']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JSVersion");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['I',['versionInt'],'S',['VERSION_SHORT','VERSION','date','majorVersion']]]

C$.$static$=function(){C$.$static$=0;
{
var tmpVersion=null;
var tmpDate=null;
{
var bis=null;
var is=null;
try {
var s=null;
{
s = "core/Jmol.properties";
}
is=Clazz.getClass(C$).getClassLoader$().getResourceAsStream$S(s);
bis=Clazz.new_($I$(1,1).c$$java_io_InputStream,[is]);
var props=Clazz.new_($I$(2,1));
props.load$java_io_InputStream(bis);
s=props.getProperty$S$S("Jmol.___JmolVersion", tmpVersion);
if (s != null  && s.lastIndexOf$S("\"") > 0 ) s=s.substring$I$I(0, s.lastIndexOf$S("\"") + 1);
tmpVersion=$I$(3).trimQuotes$S(s);
tmpDate=$I$(3,"trimQuotes$S",[props.getProperty$S$S("Jmol.___JmolDate", tmpDate)]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
} finally {
if (bis != null ) {
try {
bis.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}if (is != null ) {
try {
is.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}}
}if (tmpDate != null ) {
tmpDate=tmpDate.substring$I$I(7, 23);
}C$.VERSION_SHORT=(tmpVersion != null  ? tmpVersion : "(Unknown_version)");
var mv=(tmpVersion != null  ? tmpVersion : "(Unknown_version)");
C$.date=(tmpDate != null  ? tmpDate : "");
C$.VERSION=C$.VERSION_SHORT + (C$.date == null  ? "" : " " + C$.date);
var v=-1;
if (tmpVersion != null ) try {
var s=C$.VERSION_SHORT;
var major="";
var i=s.indexOf$S(".");
if (i < 0) {
v=100000 * Integer.parseInt$S(s);
s=null;
}if (s != null ) {
v=100000 * Integer.parseInt$S(major=s.substring$I$I(0, i));
s=s.substring$I(i + 1);
i=s.indexOf$S(".");
if (i < 0) {
v+=1000 * Integer.parseInt$S(s);
s=null;
}if (s != null ) {
var m=s.substring$I$I(0, i);
major+="." + m;
mv=major;
v+=1000 * Integer.parseInt$S(m);
s=s.substring$I(i + 1);
i=s.indexOf$S("_");
if (i >= 0) s=s.substring$I$I(0, i);
i=s.indexOf$S(" ");
if (i >= 0) s=s.substring$I$I(0, i);
v+=Integer.parseInt$S(s);
}}} catch (e) {
if (Clazz.exceptionOf(e,"NumberFormatException")){
} else {
throw e;
}
}
C$.majorVersion=mv;
C$.versionInt=v;
};
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-12 20:44:02 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
