(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[[0,'javajs.util.SB','jspecview.common.Parameters']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PanelNode");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['isSelected','isView','isSimulation'],'S',['fileName','id','frameTitle'],'O',['treeNode','jspecview.api.JSVTreeNode','source','jspecview.source.JDXSource','jsvp','jspecview.api.JSVPanel','legend','jspecview.dialog.JSVDialog']]]

Clazz.newMeth(C$, 'c$$S$S$jspecview_source_JDXSource$jspecview_api_JSVPanel',  function (id, fileName, source, jsvp) {
;C$.$init$.apply(this);
this.id=id;
this.source=source;
this.fileName=fileName;
this.isSimulation=(source.getFilePath$().indexOf$S("http://SIMULATION/") >= 0);
this.jsvp=jsvp;
if (jsvp != null ) {
this.pd$().getSpectrumAt$I(0).setId$S(id);
this.frameTitle=jsvp.getTitle$();
}}, 1);

Clazz.newMeth(C$, 'setTreeNode$jspecview_api_JSVTreeNode',  function (node) {
this.treeNode=node;
});

Clazz.newMeth(C$, 'getTreeNode$',  function () {
return this.treeNode;
});

Clazz.newMeth(C$, 'dispose$',  function () {
this.source.dispose$();
if (this.jsvp != null ) this.jsvp.dispose$();
this.source=null;
this.jsvp=null;
this.legend=null;
});

Clazz.newMeth(C$, 'pd$',  function () {
return this.jsvp.getPanelData$();
});

Clazz.newMeth(C$, 'getSpectrum$',  function () {
return this.pd$().getSpectrum$();
});

Clazz.newMeth(C$, 'setLegend$jspecview_dialog_JSVDialog',  function (legend) {
if (this.legend != null ) this.legend.dispose$();
this.legend=legend;
return legend;
});

Clazz.newMeth(C$, 'toString',  function () {
return ((this.id == null  ? "" : this.id + ": ") + (this.frameTitle == null  ? this.fileName : this.frameTitle));
});

Clazz.newMeth(C$, 'findSourceByNameOrId$S$javajs_util_Lst',  function (id, panelNodes) {
for (var i=panelNodes.size$(); --i >= 0; ) {
var node=panelNodes.get$I(i);
if (id.equals$O(node.id) || id.equals$O(node.source.getSpectra$().get$I(0).sourceID) || node.source.matchesFilePath$S(id)  ) return node.source;
}
for (var i=panelNodes.size$(); --i >= 0; ) {
var node=panelNodes.get$I(i);
if (id.equals$O(node.fileName)) return node.source;
}
return null;
}, 1);

Clazz.newMeth(C$, 'findNodeById$S$javajs_util_Lst',  function (id, panelNodes) {
if (id != null ) for (var i=panelNodes.size$(); --i >= 0; ) if (id.equals$O(panelNodes.get$I(i).id) || id.equals$O(panelNodes.get$I(i).frameTitle) ) return panelNodes.get$I(i);

return null;
}, 1);

Clazz.newMeth(C$, 'findNode$jspecview_api_JSVPanel$javajs_util_Lst',  function (jsvp, panelNodes) {
for (var i=panelNodes.size$(); --i >= 0; ) if (panelNodes.get$I(i).jsvp === jsvp ) return panelNodes.get$I(i);

return null;
}, 1);

Clazz.newMeth(C$, 'getSpectrumListAsString$javajs_util_Lst',  function (panelNodes) {
var sb=Clazz.new_($I$(1,1));
for (var i=0; i < panelNodes.size$(); i++) {
var node=panelNodes.get$I(i);
if (!node.isView) sb.append$S(" ").append$S(node.id);
}
return sb.toString().trim$();
}, 1);

Clazz.newMeth(C$, 'isOpen$javajs_util_Lst$S',  function (panelNodes, filePath) {
var pt=-1;
if (filePath != null ) for (var i=panelNodes.size$(); --i >= 0; ) {
if (panelNodes.get$I(i).source.matchesFilePath$S(filePath) || filePath.equals$O(panelNodes.get$I(i).frameTitle) ) return pt;
}
return -1;
}, 1);

Clazz.newMeth(C$, 'setFrameTitle$S',  function (name) {
this.frameTitle=name;
});

Clazz.newMeth(C$, 'getLastFileFirstNode$javajs_util_Lst',  function (panelNodes) {
var n=panelNodes.size$();
var node=(n == 0 ? null : panelNodes.get$I(n - 1));
for (var i=n - 1; --i >= 0; ) {
if (panelNodes.get$I(i).source !== node.source ) break;
node=panelNodes.get$I(i);
}
return (node == null  ? null : node.jsvp);
}, 1);

Clazz.newMeth(C$, 'getInfo$S',  function (key) {
var info=this.pd$().getInfo$Z$S(false, key);
$I$(2).putInfo$S$java_util_Map$S$O(key, info, "panelId", this.id);
$I$(2).putInfo$S$java_util_Map$S$O(key, info, "panelFileName", this.fileName);
$I$(2,"putInfo$S$java_util_Map$S$O",[key, info, "panelSource", this.source.getFilePath$()]);
return info;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:57 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
