(function(){var P$=Clazz.newPackage("jspecview.common"),I$=[[0,'javajs.api.GenericColor','java.util.Hashtable','jspecview.common.ScriptToken','javajs.util.CU','java.util.StringTokenizer','javajs.util.Lst']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ColorParameters", null, 'jspecview.common.Parameters');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['isDefault'],'S',['titleFontName','displayFontName'],'O',['elementColors','java.util.Map','plotColors','javajs.api.GenericColor[]']]
,['O',['BLACK','javajs.api.GenericColor','+RED','+LIGHT_GRAY','+DARK_GRAY','+BLUE','+WHITE','defaultPlotColors','javajs.api.GenericColor[]','defaultPlotColorNames','String[]']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
C$.BLACK=this.getColor3$I$I$I(0, 0, 0);
C$.RED=this.getColor3$I$I$I(255, 0, 0);
C$.LIGHT_GRAY=this.getColor3$I$I$I(200, 200, 200);
C$.DARK_GRAY=this.getColor3$I$I$I(80, 80, 80);
C$.BLUE=this.getColor3$I$I$I(0, 0, 255);
C$.WHITE=this.getColor3$I$I$I(255, 255, 255);
this.elementColors=Clazz.new_($I$(2,1));
this.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).TITLECOLOR, C$.BLACK);
this.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).UNITSCOLOR, C$.RED);
this.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).SCALECOLOR, C$.BLACK);
this.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).COORDINATESCOLOR, C$.RED);
this.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).GRIDCOLOR, C$.LIGHT_GRAY);
this.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).PLOTCOLOR, C$.BLUE);
this.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).PLOTAREACOLOR, C$.WHITE);
this.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).BACKGROUNDCOLOR, this.getColor3$I$I$I(192, 192, 192));
this.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).INTEGRALPLOTCOLOR, C$.RED);
this.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).PEAKTABCOLOR, C$.RED);
this.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor($I$(3).HIGHLIGHTCOLOR, C$.DARK_GRAY);
for (var i=0; i < 8; i++) C$.defaultPlotColors[i]=this.getColorFromString$S(C$.defaultPlotColorNames[i]);

this.plotColors=Clazz.array($I$(1), [8]);
System.arraycopy$O$I$O$I$I(C$.defaultPlotColors, 0, this.plotColors, 0, 8);
}, 1);

Clazz.newMeth(C$, 'setFor$jspecview_api_JSVPanel$jspecview_common_ColorParameters$Z',  function (jsvp, ds, includeMeasures) {
if (ds == null ) ds=this;
if (includeMeasures) jsvp.getPanelData$().setBooleans$jspecview_common_Parameters$jspecview_common_ScriptToken(ds, null);
var pd=jsvp.getPanelData$();
if (pd.getCurrentPlotColor$I(1) != null ) pd.setPlotColors$javajs_api_GenericColorA(this.plotColors);
pd.setColorOrFont$jspecview_common_ColorParameters$jspecview_common_ScriptToken(ds, null);
});

Clazz.newMeth(C$, 'set$jspecview_common_PanelData$jspecview_common_ScriptToken$S',  function (pd, st, value) {
var param=null;
switch (st) {
default:
this.setP$jspecview_common_PanelData$jspecview_common_ScriptToken$S(pd, st, value);
return;
case $I$(3).PLOTCOLORS:
if (pd == null ) this.getPlotColors$S(value);
 else pd.setPlotColors$javajs_api_GenericColorA(this.getPlotColors$S(value));
return;
case $I$(3).BACKGROUNDCOLOR:
case $I$(3).COORDINATESCOLOR:
case $I$(3).GRIDCOLOR:
case $I$(3).HIGHLIGHTCOLOR:
case $I$(3).INTEGRALPLOTCOLOR:
case $I$(3).PEAKTABCOLOR:
case $I$(3).PLOTAREACOLOR:
case $I$(3).PLOTCOLOR:
case $I$(3).SCALECOLOR:
case $I$(3).TITLECOLOR:
case $I$(3).UNITSCOLOR:
param=this.setColorFromString$jspecview_common_ScriptToken$S(st, value);
break;
case $I$(3).TITLEFONTNAME:
case $I$(3).DISPLAYFONTNAME:
param=this.getFontName$jspecview_common_ScriptToken$S(st, value);
break;
}
if (pd == null ) return;
if (param != null ) pd.setColorOrFont$jspecview_common_ColorParameters$jspecview_common_ScriptToken(this, st);
});

Clazz.newMeth(C$, 'getElementColor$jspecview_common_ScriptToken',  function (st) {
return this.elementColors.get$O(st);
});

Clazz.newMeth(C$, 'setColor$jspecview_common_ScriptToken$javajs_api_GenericColor',  function (st, color) {
if (color != null ) this.elementColors.put$O$O(st, color);
return color;
});

Clazz.newMeth(C$, 'copy$',  function () {
return this.copy$S(this.name);
});

Clazz.newMeth(C$, 'setElementColors$jspecview_common_ColorParameters',  function (p) {
this.displayFontName=p.displayFontName;
for (var entry, $entry = p.elementColors.entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) this.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor(entry.getKey$(), entry.getValue$());

return this;
});

Clazz.newMeth(C$, 'getColorFromString$S',  function (name) {
return this.getColor1$I($I$(4).getArgbFromString$S(name));
});

Clazz.newMeth(C$, 'getPlotColors$S',  function (plotColorsStr) {
if (plotColorsStr == null ) {
this.plotColors[0]=this.getElementColor$jspecview_common_ScriptToken($I$(3).PLOTCOLOR);
return this.plotColors;
}var st=Clazz.new_($I$(5,1).c$$S$S,[plotColorsStr, ",;.- "]);
var colors=Clazz.new_($I$(6,1));
try {
while (st.hasMoreTokens$())colors.addLast$O(this.getColorFromString$S(st.nextToken$()));

} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return null;
} else {
throw e;
}
}
return colors.toArray$OA(Clazz.array($I$(1), [colors.size$()]));
});

Clazz.newMeth(C$, 'setColorFromString$jspecview_common_ScriptToken$S',  function (st, value) {
return this.setColor$jspecview_common_ScriptToken$javajs_api_GenericColor(st, this.getColorFromString$S(value));
});

Clazz.newMeth(C$, 'getFontName$jspecview_common_ScriptToken$S',  function (st, value) {
var isValid=this.isValidFontName$S(value);
switch (st) {
case $I$(3).TITLEFONTNAME:
return (isValid ? this.titleFontName=value : this.titleFontName);
case $I$(3).DISPLAYFONTNAME:
return (isValid ? this.displayFontName=value : this.displayFontName);
}
return null;
});

C$.$static$=function(){C$.$static$=0;
C$.defaultPlotColors=Clazz.array($I$(1), [8]);
C$.defaultPlotColorNames=Clazz.array(String, -1, ["black", "darkGreen", "darkred", "orange", "magenta", "cyan", "maroon", "darkGray"]);
};
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:04 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
