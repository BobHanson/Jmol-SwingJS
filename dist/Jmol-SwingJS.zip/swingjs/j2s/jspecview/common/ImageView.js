(function(){var P$=Clazz.newPackage("jspecview.common"),p$1={},I$=[[0,'jspecview.common.ScaleData','jspecview.common.Coordinate']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ImageView", null, null, 'jspecview.common.XYScaleConverter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.minX=NaN;
},1);

C$.$fields$=[['D',['grayFactorLast','averageGray','minX','maxX','minY','maxY','minZ','maxZ'],'I',['xPixel0','yPixel0','xPixel1','yPixel1','imageWidth','imageHeight','xPixels','yPixels','xPixelZoom1','yPixelZoom1','xPixelZoom2','yPixelZoom2','xView1','yView1','xView2','yView2'],'O',['buf2d','int[]','scaleData','jspecview.common.ScaleData']]]

Clazz.newMeth(C$, 'set$jspecview_common_ScaleData',  function (view) {
if (Double.isNaN$D(this.minX)) {
this.minX=view.minX;
this.maxX=view.maxX;
}this.minZ=view.minY;
this.maxZ=view.maxY;
this.scaleData=Clazz.new_($I$(1,1));
});

Clazz.newMeth(C$, 'setZoom$I$I$I$I',  function (xPixel1, yPixel1, xPixel2, yPixel2) {
this.xPixelZoom1=Math.min(xPixel1, xPixel2);
this.yPixelZoom1=Math.min(yPixel1, yPixel2);
this.xPixelZoom2=Math.max(xPixel1, xPixel2);
this.yPixelZoom2=Math.max(yPixel1, yPixel2);
this.setView$();
});

Clazz.newMeth(C$, 'setXY0$jspecview_common_Spectrum$I$I',  function (spec, xPixel, yPixel) {
this.xPixel0=xPixel;
this.yPixel0=yPixel;
this.xPixel1=this.xPixel0 + this.xPixels - 1;
this.yPixel1=this.yPixel0 + this.yPixels - 1;
this.setMinMaxY$jspecview_common_Spectrum(spec);
});

Clazz.newMeth(C$, 'setPixelWidthHeight$I$I',  function (xPixels, yPixels) {
this.xPixels=xPixels;
this.yPixels=yPixels;
});

Clazz.newMeth(C$, 'resetView$',  function () {
this.xView1=0;
this.yView1=0;
this.xView2=this.imageWidth - 1;
this.yView2=this.imageHeight - 1;
});

Clazz.newMeth(C$, 'setView$',  function () {
if (this.xPixelZoom1 == 0) this.resetZoom$();
var x1=this.toImageX$I(this.xPixelZoom1);
var y1=this.toImageY$I(this.yPixelZoom1);
var x2=this.toImageX$I(this.xPixelZoom2);
var y2=this.toImageY$I(this.yPixelZoom2);
this.xView1=Math.min(x1, x2);
this.yView1=Math.min(y1, y2);
this.xView2=Math.max(x1, x2);
this.yView2=Math.max(y1, y2);
p$1.setScaleData.apply(this, []);
this.resetZoom$();
});

Clazz.newMeth(C$, 'resetZoom$',  function () {
this.xPixelZoom1=this.xPixel0;
this.yPixelZoom1=this.yPixel0;
this.xPixelZoom2=this.xPixel1;
this.yPixelZoom2=this.yPixel1;
});

Clazz.newMeth(C$, 'toImageX$I',  function (xPixel) {
return this.xView1 + (Math.floor((xPixel - this.xPixel0) / (this.xPixels - 1.0) * (this.xView2 - this.xView1))|0);
});

Clazz.newMeth(C$, 'toImageY$I',  function (yPixel) {
return this.yView1 + (Math.floor((yPixel - this.yPixel0) / (this.yPixels - 1.0) * (this.yView2 - this.yView1))|0);
});

Clazz.newMeth(C$, 'toImageX0$I',  function (xPixel) {
return $I$(2,"intoRange$I$I$I",[(((1.0 * xPixel - this.xPixel0) / (this.xPixels - 1) * (this.imageWidth - 1))|0), 0, this.imageWidth - 1]);
});

Clazz.newMeth(C$, 'toImageY0$I',  function (yPixel) {
return $I$(2,"intoRange$I$I$I",[(((1.0 * yPixel - this.yPixel0) / (this.yPixels - 1) * (this.imageHeight - 1))|0), 0, this.imageHeight - 1]);
});

Clazz.newMeth(C$, 'isXWithinRange$I',  function (xPixel) {
return (xPixel >= this.xPixel0 - 5 && xPixel < this.xPixel0 + this.xPixels + 5  );
});

Clazz.newMeth(C$, 'toSubspectrumIndex$I',  function (yPixel) {
return $I$(2,"intoRange$I$I$I",[this.imageHeight - 1 - this.toImageY$I(yPixel) , 0, this.imageHeight - 1]);
});

Clazz.newMeth(C$, 'toX0$I',  function (xPixel) {
return this.maxX + (this.minX - this.maxX) * (this.fixX$I(xPixel) - this.xPixel0) / (this.xPixels - 1);
});

Clazz.newMeth(C$, 'toPixelX0$D',  function (x) {
return this.xPixel1 - (((x - this.minX) / (this.maxX - this.minX) * (this.xPixels - 1))|0);
});

Clazz.newMeth(C$, 'toPixelY0$D',  function (ysub) {
return this.yPixel1 - ((ysub / (this.imageHeight - 1) * (this.yPixels - 1))|0);
});

Clazz.newMeth(C$, 'subIndexToPixelY$I',  function (subIndex) {
var f=1.0 * (this.imageHeight - 1 - subIndex - this.yView1 ) / (this.yView2 - this.yView1);
var y=this.yPixel0 + ((f * (this.yPixels - 1))|0);
return y;
});

Clazz.newMeth(C$, 'fixSubIndex$I',  function (subIndex) {
return $I$(2).intoRange$I$I$I(subIndex, this.imageHeight - 1 - this.yView2 , this.imageHeight - 1 - this.yView1 );
});

Clazz.newMeth(C$, 'setView0$I$I$I$I',  function (xp1, yp1, xp2, yp2) {
var x1=this.toImageX0$I(xp1);
var y1=this.toImageY0$I(yp1);
var x2=this.toImageX0$I(xp2);
var y2=this.toImageY0$I(yp2);
this.xView1=Math.min(x1, x2);
this.yView1=Math.min(y1, y2);
this.xView2=Math.max(x1, x2);
this.yView2=Math.max(y1, y2);
this.resetZoom$();
});

Clazz.newMeth(C$, 'get2dBuffer$jspecview_common_Spectrum$Z',  function (spec, forceNew) {
var subSpectra=spec.getSubSpectra$();
if (subSpectra == null  || !subSpectra.get$I(0).isContinuous$() ) return null;
var xyCoords=spec.getXYCoords$();
var nSpec=subSpectra.size$();
this.imageWidth=xyCoords.length;
this.imageHeight=nSpec;
var grayFactor=255 / (this.maxZ - this.minZ);
if (!forceNew && this.buf2d != null   && grayFactor == this.grayFactorLast  ) return this.buf2d;
this.grayFactorLast=grayFactor;
var pt=this.imageWidth * this.imageHeight;
var buf=(this.buf2d == null  || this.buf2d.length != pt  ? Clazz.array(Integer.TYPE, [pt]) : this.buf2d);
var totalGray=0;
for (var i=0; i < nSpec; i++) {
var points=subSpectra.get$I(i).xyCoords;
if (points.length != xyCoords.length) return null;
for (var j=0; j < xyCoords.length; j++) {
var y=points[j].getYVal$();
var gray=255 - $I$(2,"intoRange$I$I$I",[(((y - this.minZ) * grayFactor)|0), 0, 255]);
buf[--pt]=gray;
totalGray+=gray;
}
}
this.averageGray=(1 - totalGray / (this.imageWidth * this.imageHeight) / 255 );
System.out.println$S("Average gray = " + new Double(this.averageGray).toString());
return (this.buf2d=buf);
});

Clazz.newMeth(C$, 'adjustView$jspecview_common_Spectrum$jspecview_common_ViewData',  function (spec, view) {
var i=0;
var isLow=false;
while (((isLow=(this.averageGray < 0.05 )) || this.averageGray > 0.3  ) && i++ < 10 ){
view.scaleSpectrum$I$D(-2, isLow ? 2 : 0.5);
this.set$jspecview_common_ScaleData(view.getScale$());
this.get2dBuffer$jspecview_common_Spectrum$Z(spec, false);
}
return this.buf2d;
});

Clazz.newMeth(C$, 'getBuffer$',  function () {
return this.buf2d;
});

Clazz.newMeth(C$, 'setMinMaxY$jspecview_common_Spectrum',  function (spec) {
var subSpectra=spec.getSubSpectra$();
var spec0=subSpectra.get$I(0);
this.maxY=spec0.getY2D$();
this.minY=subSpectra.get$I(subSpectra.size$() - 1).getY2D$();
if (spec0.y2DUnits.equalsIgnoreCase$S("Hz")) {
this.maxY/=spec0.freq2dY;
this.minY/=spec0.freq2dY;
}p$1.setScaleData.apply(this, []);
});

Clazz.newMeth(C$, 'setScaleData',  function () {
this.scaleData.minY=this.minY;
this.scaleData.maxY=this.maxY;
this.scaleData.setYScale$D$D$Z$Z(this.toY$I(this.yPixel0), this.toY$I(this.yPixel1), false, false);
}, p$1);

Clazz.newMeth(C$, 'fixX$I',  function (xPixel) {
return (xPixel < this.xPixel0 ? this.xPixel0 : xPixel > this.xPixel1 ? this.xPixel1 : xPixel);
});

Clazz.newMeth(C$, 'fixY$I',  function (yPixel) {
return $I$(2).intoRange$I$I$I(yPixel, this.yPixel0, this.yPixel1);
});

Clazz.newMeth(C$, 'getScale$',  function () {
return this.scaleData;
});

Clazz.newMeth(C$, 'toX$I',  function (xPixel) {
return this.maxX + (this.minX - this.maxX) * this.toImageX$I(this.fixX$I(xPixel)) / (this.imageWidth - 1);
});

Clazz.newMeth(C$, 'toY$I',  function (yPixel) {
var isub=this.toSubspectrumIndex$I(yPixel);
return this.maxY + (this.minY - this.maxY) * isub / (this.imageHeight - 1);
});

Clazz.newMeth(C$, 'toPixelX$D',  function (x) {
var x0=this.toX$I(this.xPixel0);
var x1=this.toX$I(this.xPixel1);
return this.xPixel0 + (((x - x0) / (x1 - x0) * (this.xPixels - 1))|0);
});

Clazz.newMeth(C$, 'toPixelY$D',  function (y) {
var f=(y - this.scaleData.minYOnScale) / (this.scaleData.maxYOnScale - this.scaleData.minYOnScale);
return ((this.yPixel0 + f * this.yPixels)|0);
});

Clazz.newMeth(C$, 'getXPixels$',  function () {
return this.xPixels;
});

Clazz.newMeth(C$, 'getYPixels$',  function () {
return this.yPixels;
});

Clazz.newMeth(C$, 'getXPixel0$',  function () {
return this.xPixel0;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:28 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
