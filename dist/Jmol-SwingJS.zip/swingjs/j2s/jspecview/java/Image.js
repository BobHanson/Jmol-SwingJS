(function(){var P$=Clazz.newPackage("jspecview.java"),I$=[[0,'java.awt.image.DirectColorModel','java.awt.Toolkit','java.awt.MediaTracker','java.awt.image.PixelGrabber','java.awt.AlphaComposite','jspecview.java.AwtColor','java.awt.Color','java.awt.image.BufferedImage','java.awt.image.Raster','java.awt.image.SinglePixelPackedSampleModel','java.awt.image.DataBufferInt','jspecview.common.JSViewer','java.awt.RenderingHints']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Image");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['rgbColorModel','java.awt.image.DirectColorModel','sampleModelBitMasks','int[]']]]

Clazz.newMeth(C$, 'createImage$O',  function (data) {
if (Clazz.instanceOf(data, "java.net.URL")) return $I$(2).getDefaultToolkit$().createImage$java_net_URL(data);
if (Clazz.instanceOf(data, "java.lang.String")) return $I$(2).getDefaultToolkit$().createImage$S(data);
if (Clazz.instanceOf(data, Clazz.array(Byte.TYPE, -1))) return $I$(2).getDefaultToolkit$().createImage$BA(data);
return null;
}, 1);

Clazz.newMeth(C$, 'waitForDisplay$org_jmol_api_PlatformViewer$O',  function (viewer, image) {
var display=null;
var mediaTracker=Clazz.new_($I$(3,1).c$$java_awt_Component,[display]);
var rnd=((Math.random() * 100000)|0);
mediaTracker.addImage$java_awt_Image$I(image, rnd);
mediaTracker.waitForID$I(rnd);
}, 1);

Clazz.newMeth(C$, 'getWidth$O',  function (image) {
return (image).getWidth$java_awt_image_ImageObserver(null);
}, 1);

Clazz.newMeth(C$, 'getHeight$O',  function (image) {
return (image).getHeight$java_awt_image_ImageObserver(null);
}, 1);

Clazz.newMeth(C$, 'grabPixels$O$I$I$IA',  function (imageobj, width, height, pixels) {
var image=imageobj;
var pixelGrabber=(pixels == null  ? Clazz.new_($I$(4,1).c$$java_awt_Image$I$I$I$I$Z,[image, 0, 0, width, height, true]) : Clazz.new_($I$(4,1).c$$java_awt_Image$I$I$I$I$IA$I$I,[image, 0, 0, width, height, pixels, 0, width]));
try {
pixelGrabber.grabPixels$();
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
return null;
} else {
throw e;
}
}
return pixelGrabber.getPixels$();
}, 1);

Clazz.newMeth(C$, 'drawImageToBuffer$O$O$O$I$I$I',  function (gOffscreen, imageOffscreen, imageobj, width, height, bgcolor) {
var g=gOffscreen;
var image=imageobj;
var width0=image.getWidth$java_awt_image_ImageObserver(null);
var height0=image.getHeight$java_awt_image_ImageObserver(null);
if (Clazz.instanceOf(g, "java.awt.Graphics2D")) {
(g).setComposite$java_awt_Composite($I$(5).getInstance$I$F(5, 1.0));
g.setColor$java_awt_Color(bgcolor == 0 ? Clazz.new_($I$(6,1).c$$I$I$I$I,[0, 0, 0, 0]) : Clazz.new_($I$(6,1).c$$I,[bgcolor]));
g.fillRect$I$I$I$I(0, 0, width, height);
(g).setComposite$java_awt_Composite($I$(5).getInstance$I$F(3, 1.0));
g.drawImage$java_awt_Image$I$I$I$I$I$I$I$I$java_awt_image_ImageObserver(image, 0, 0, width, height, 0, 0, width0, height0, null);
} else {
g.clearRect$I$I$I$I(0, 0, width, height);
g.drawImage$java_awt_Image$I$I$I$I$I$I$I$I$java_awt_image_ImageObserver(image, 0, 0, width, height, 0, 0, width0, height0, null);
}return C$.grabPixels$O$I$I$IA(imageOffscreen, width, height, null);
}, 1);

Clazz.newMeth(C$, 'getTextPixels$S$org_jmol_util_Font$O$O$I$I$I',  function (text, font3d, gObj, image, width, height, ascent) {
var g=gObj;
g.setColor$java_awt_Color($I$(7).black);
g.fillRect$I$I$I$I(0, 0, width, height);
g.setColor$java_awt_Color($I$(7).white);
g.setFont$java_awt_Font(font3d.font);
g.drawString$S$I$I(text, 0, ascent);
return C$.grabPixels$O$I$I$IA(image, width, height, null);
}, 1);

Clazz.newMeth(C$, 'newBufferedImage$O$I$I',  function (image, w, h) {
return Clazz.new_([w, h, (image).getType$()],$I$(8,1).c$$I$I$I);
}, 1);

Clazz.newMeth(C$, 'newBufferedImage$I$I',  function (w, h) {
return Clazz.new_($I$(8,1).c$$I$I$I,[w, h, 2]);
}, 1);

Clazz.newMeth(C$, 'allocateRgbImage$I$I$IA$I$Z',  function (windowWidth, windowHeight, pBuffer, windowSize, backgroundTransparent) {
return Clazz.new_([C$.rgbColorModel, $I$(9,"createWritableRaster$java_awt_image_SampleModel$java_awt_image_DataBuffer$java_awt_Point",[Clazz.new_($I$(10,1).c$$I$I$I$IA,[3, windowWidth, windowHeight, C$.sampleModelBitMasks]), Clazz.new_($I$(11,1).c$$IA$I,[pBuffer, windowSize]), null]), false, null],$I$(8,1).c$$java_awt_image_ColorModel$java_awt_image_WritableRaster$Z$java_util_Hashtable);
}, 1);

Clazz.newMeth(C$, 'getStaticGraphics$O$Z',  function (image, backgroundTransparent) {
var g2d=(image).createGraphics$();
if (!$I$(12).isJS) {
g2d.setRenderingHint$java_awt_RenderingHints_Key$O($I$(13).KEY_TEXT_ANTIALIASING, $I$(13).VALUE_TEXT_ANTIALIAS_ON);
g2d.setRenderingHint$java_awt_RenderingHints_Key$O($I$(13).KEY_ANTIALIASING, $I$(13).VALUE_ANTIALIAS_OFF);
g2d.setRenderingHint$java_awt_RenderingHints_Key$O($I$(13).KEY_RENDERING, $I$(13).VALUE_RENDER_SPEED);
}return g2d;
}, 1);

Clazz.newMeth(C$, 'getGraphics$O',  function (image) {
return (image).getGraphics$();
}, 1);

Clazz.newMeth(C$, 'drawImage$O$O$I$I$I$I',  function (g, img, x, y, width, height) {
(g).drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(img, x, y, null);
}, 1);

Clazz.newMeth(C$, 'flush$O',  function (image) {
if (!$I$(12).isJS) (image).flush$();
}, 1);

Clazz.newMeth(C$, 'disposeGraphics$O',  function (graphicForText) {
(graphicForText).dispose$();
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.rgbColorModel=Clazz.new_($I$(1,1).c$$I$I$I$I$I,[24, 16711680, 65280, 255, 0]);
C$.sampleModelBitMasks=Clazz.array(Integer.TYPE, -1, [16711680, 65280, 255]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:52 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
