(function(){var P$=Clazz.newPackage("jspecview.java"),I$=[[0,'java.util.Hashtable']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AwtDialogFileFilter", null, 'javax.swing.filechooser.FileFilter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.filters=null;
this.description=null;
},1);

C$.$fields$=[['S',['description'],'O',['filters','java.util.Hashtable']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.filters=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'c$$SA',  function (filters) {
C$.c$$SA$S.apply(this, [filters, null]);
}, 1);

Clazz.newMeth(C$, 'c$$SA$S',  function (filters, description) {
C$.c$.apply(this, []);
for (var i=0; i < filters.length; i++) {
this.addExtension$S(filters[i]);
}
this.setDescription$S(description);
}, 1);

Clazz.newMeth(C$, 'accept$java_io_File',  function (f) {
if (f == null  || f.isDirectory$() ) return (f != null );
var extension=this.getExtension$java_io_File(f);
return (extension != null  && this.filters.containsKey$O(extension) );
});

Clazz.newMeth(C$, 'getExtension$java_io_File',  function (f) {
if (f != null ) {
var filename=f.getName$();
var i=filename.lastIndexOf$I(".");
if (i > 0 && i < filename.length$() - 1 ) {
return filename.substring$I(i + 1).toLowerCase$();
}}return null;
});

Clazz.newMeth(C$, 'addExtension$S',  function (extension) {
if (this.filters == null ) {
this.filters=Clazz.new_($I$(1,1).c$$I,[5]);
}this.filters.put$O$O(extension.toLowerCase$(), this);
});

Clazz.newMeth(C$, 'getDescription$',  function () {
return this.description;
});

Clazz.newMeth(C$, 'setDescription$S',  function (description) {
this.description=description;
});
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:52 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
