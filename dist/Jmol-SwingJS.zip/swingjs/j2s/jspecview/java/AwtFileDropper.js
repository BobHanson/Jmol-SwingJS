(function(){var P$=Clazz.newPackage("jspecview.java"),I$=[[0,'org.jmol.util.Logger','javax.swing.JOptionPane','java.awt.datatransfer.DataFlavor','javajs.util.SB','javajs.util.PT']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AwtFileDropper", null, null, ['jspecview.api.JSVFileDropper', 'java.awt.dnd.DropTargetListener']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['vwr','jspecview.common.JSViewer']]
,['I',['lastSelection']]]

Clazz.newMeth(C$, 'set$jspecview_common_JSViewer',  function (viewer) {
this.vwr=viewer;
return this;
});

Clazz.newMeth(C$, 'dragEnter$java_awt_dnd_DropTargetDragEvent',  function (dtde) {
dtde.acceptDrag$I(dtde.getSourceActions$());
});

Clazz.newMeth(C$, 'dragOver$java_awt_dnd_DropTargetDragEvent',  function (dtde) {
});

Clazz.newMeth(C$, 'dragExit$java_awt_dnd_DropTargetEvent',  function (dtde) {
});

Clazz.newMeth(C$, 'dropActionChanged$java_awt_dnd_DropTargetDragEvent',  function (dtde) {
});

Clazz.newMeth(C$, 'drop$java_awt_dnd_DropTargetDropEvent',  function (dtde) {
$I$(1).debug$S("Drop detected...");
var t=dtde.getTransferable$();
var isAccepted=false;
var doAppend=false;
if (this.vwr.currentSource != null ) {
var options=Clazz.array(java.lang.Object, -1, ["Replace", "Append", "Cancel"]);
var ret=$I$(2).showOptionDialog$java_awt_Component$O$S$I$I$javax_swing_Icon$OA$O(null, "Select an option", "JSpecView File Drop", -1, 3, null, options, options[C$.lastSelection]);
if (ret < 0 || ret == 2 ) return;
C$.lastSelection=ret;
doAppend=(ret == 1);
}var prefix=(doAppend ? "" : "close ALL;");
var postfix=(doAppend ? "view all;overlayStacked false" : "overlay ALL");
var cmd="LOAD APPEND ";
var fileToLoad=null;
if (t.isDataFlavorSupported$java_awt_datatransfer_DataFlavor($I$(3).javaFileListFlavor)) {
var o=null;
try {
dtde.acceptDrop$I(3);
o=t.getTransferData$java_awt_datatransfer_DataFlavor($I$(3).javaFileListFlavor);
isAccepted=true;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
$I$(1).error$S("transfer failed");
} else {
throw e;
}
}
if (Clazz.instanceOf(o, "java.util.List")) {
var list=o;
dtde.getDropTargetContext$().dropComplete$Z(true);
dtde=null;
var sb=Clazz.new_($I$(4,1));
sb.append$S(prefix);
for (var i=0; i < list.size$(); i++) sb.append$S(cmd + $I$(5,"esc$S",[list.get$I(i).getAbsolutePath$()]) + ";" );

sb.append$S(postfix);
cmd=sb.toString();
$I$(1,"info$S",["Drop command = " + cmd]);
this.vwr.runScript$S(cmd);
return;
}}$I$(1).debug$S("browsing supported flavours to find something useful...");
var df=t.getTransferDataFlavors$();
if (df == null  || df.length == 0 ) return;
for (var i=0; i < df.length; ++i) {
var flavor=df[i];
var o=null;
if (true) {
$I$(1).info$S("df " + i + " flavor " + flavor );
$I$(1,"info$S",["  class: " + flavor.getRepresentationClass$().getName$()]);
$I$(1,"info$S",["  mime : " + flavor.getMimeType$()]);
}if (flavor.getMimeType$().startsWith$S("text/uri-list") && flavor.getRepresentationClass$().getName$().equals$O("java.lang.String") ) {
try {
if (!isAccepted) dtde.acceptDrop$I(3);
isAccepted=true;
o=t.getTransferData$java_awt_datatransfer_DataFlavor(flavor);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
$I$(1).errorEx$S$Throwable(null, e);
} else {
throw e;
}
}
if (Clazz.instanceOf(o, "java.lang.String")) {
dtde.getDropTargetContext$().dropComplete$Z(true);
if ($I$(1).debugging) $I$(1,"debug$S",["  String: " + o.toString()]);
fileToLoad=o.toString();
break;
}} else if (flavor.getMimeType$().equals$O("application/x-java-serialized-object; class=java.lang.String")) {
try {
if (!isAccepted) dtde.acceptDrop$I(3);
isAccepted=true;
o=t.getTransferData$java_awt_datatransfer_DataFlavor(df[i]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
$I$(1).errorEx$S$Throwable(null, e);
} else {
throw e;
}
}
if (Clazz.instanceOf(o, "java.lang.String")) {
var content=o;
dtde.getDropTargetContext$().dropComplete$Z(true);
if ($I$(1).debugging) $I$(1).debug$S("  String: " + content);
if (content.startsWith$S("file:/")) {
fileToLoad=content;
break;
}}}}
if (!isAccepted) dtde.rejectDrop$();
if (fileToLoad != null ) {
cmd=prefix + cmd + $I$(5).esc$S(fileToLoad) + "\";" + postfix ;
$I$(1,"info$S",["Drop command = " + cmd]);
this.vwr.runScriptNow$S(cmd);
}});

C$.$static$=function(){C$.$static$=0;
C$.lastSelection=0;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:07 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
