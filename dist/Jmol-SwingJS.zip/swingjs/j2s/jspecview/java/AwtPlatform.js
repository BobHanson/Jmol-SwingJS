(function(){var P$=Clazz.newPackage("jspecview.java"),I$=[[0,'jspecview.java.Display','jspecview.java.Mouse','jspecview.java.Image','jspecview.java.AwtFont','java.awt.GraphicsEnvironment','java.text.SimpleDateFormat','jspecview.java.AwtFile','javajs.util.Rdr','javax.swing.JOptionPane','org.jmol.i18n.GT']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AwtPlatform", null, null, 'org.jmol.api.GenericPlatform');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['vwr','org.jmol.api.PlatformViewer']]]

Clazz.newMeth(C$, 'setViewer$org_jmol_api_PlatformViewer$O',  function (viewer, display) {
this.vwr=viewer;
});

Clazz.newMeth(C$, 'convertPointFromScreen$O$javajs_util_P3d',  function (display, ptTemp) {
$I$(1).convertPointFromScreen$O$javajs_util_P3d(display, ptTemp);
});

Clazz.newMeth(C$, 'getFullScreenDimensions$O$IA',  function (display, widthHeight) {
$I$(1).getFullScreenDimensions$O$IA(display, widthHeight);
});

Clazz.newMeth(C$, 'getMenuPopup$S$C',  function (menuStructure, type) {
return null;
});

Clazz.newMeth(C$, 'hasFocus$O',  function (display) {
return $I$(1).hasFocus$O(display);
});

Clazz.newMeth(C$, 'prompt$S$S$SA$Z',  function (label, data, list, asButtons) {
return $I$(1).prompt$S$S$SA$Z(label, data, list, asButtons);
});

Clazz.newMeth(C$, 'requestFocusInWindow$O',  function (display) {
$I$(1).requestFocusInWindow$O(display);
});

Clazz.newMeth(C$, 'repaint$O',  function (display) {
$I$(1).repaint$O(display);
});

Clazz.newMeth(C$, 'setTransparentCursor$O',  function (display) {
$I$(1).setTransparentCursor$O(display);
});

Clazz.newMeth(C$, 'setCursor$I$O',  function (c, display) {
$I$(1).setCursor$I$O(c, display);
});

Clazz.newMeth(C$, 'getMouseManager$D$O',  function (ignored, jsvp) {
return Clazz.new_($I$(2,1).c$$jspecview_api_JSVPanel,[jsvp]);
});

Clazz.newMeth(C$, 'allocateRgbImage$I$I$IA$I$Z$Z',  function (windowWidth, windowHeight, pBuffer, windowSize, backgroundTransparent, isImageWrite) {
return $I$(3).allocateRgbImage$I$I$IA$I$Z(windowWidth, windowHeight, pBuffer, windowSize, backgroundTransparent);
});

Clazz.newMeth(C$, 'createImage$O',  function (data) {
return $I$(3).createImage$O(data);
});

Clazz.newMeth(C$, 'disposeGraphics$O',  function (gOffscreen) {
$I$(3).disposeGraphics$O(gOffscreen);
});

Clazz.newMeth(C$, 'drawImage$O$O$I$I$I$I$Z',  function (g, img, x, y, width, height, isDTI) {
$I$(3).drawImage$O$O$I$I$I$I(g, img, x, y, width, height);
});

Clazz.newMeth(C$, 'grabPixels$O$I$I$IA',  function (imageobj, width, height, pixels) {
return $I$(3).grabPixels$O$I$I$IA(imageobj, width, height, pixels);
});

Clazz.newMeth(C$, 'drawImageToBuffer$O$O$O$I$I$I',  function (gOffscreen, imageOffscreen, imageobj, width, height, bgcolor) {
return $I$(3).drawImageToBuffer$O$O$O$I$I$I(gOffscreen, imageOffscreen, imageobj, width, height, bgcolor);
});

Clazz.newMeth(C$, 'getTextPixels$S$org_jmol_util_Font$O$O$I$I$I',  function (text, font3d, gObj, image, width, height, ascent) {
return $I$(3).getTextPixels$S$org_jmol_util_Font$O$O$I$I$I(text, font3d, gObj, image, width, height, ascent);
});

Clazz.newMeth(C$, 'flushImage$O',  function (imagePixelBuffer) {
$I$(3).flush$O(imagePixelBuffer);
});

Clazz.newMeth(C$, 'getGraphics$O',  function (image) {
return $I$(3).getGraphics$O(image);
});

Clazz.newMeth(C$, 'getImageHeight$O',  function (image) {
return (image == null  ? -1 : $I$(3).getHeight$O(image));
});

Clazz.newMeth(C$, 'getImageWidth$O',  function (image) {
return (image == null  ? -1 : $I$(3).getWidth$O(image));
});

Clazz.newMeth(C$, 'getStaticGraphics$O$Z',  function (image, backgroundTransparent) {
return $I$(3).getStaticGraphics$O$Z(image, backgroundTransparent);
});

Clazz.newMeth(C$, 'newBufferedImage$O$I$I',  function (image, w, h) {
return $I$(3).newBufferedImage$O$I$I(image, w, h);
});

Clazz.newMeth(C$, 'newOffScreenImage$I$I',  function (w, h) {
return $I$(3).newBufferedImage$I$I(w, h);
});

Clazz.newMeth(C$, 'waitForDisplay$O$O',  function (ignored, image) {
$I$(3).waitForDisplay$org_jmol_api_PlatformViewer$O(this.vwr, image);
return true;
});

Clazz.newMeth(C$, 'fontStringWidth$org_jmol_util_Font$S',  function (font, text) {
return $I$(4,"stringWidth$O$S",[font.getFontMetrics$(), text]);
});

Clazz.newMeth(C$, 'getFontAscent$O',  function (fontMetrics) {
return $I$(4).getAscent$O(fontMetrics);
});

Clazz.newMeth(C$, 'getFontDescent$O',  function (fontMetrics) {
return $I$(4).getDescent$O(fontMetrics);
});

Clazz.newMeth(C$, 'getFontMetrics$org_jmol_util_Font$O',  function (font, graphics) {
return $I$(4).getFontMetrics$org_jmol_util_Font$O(font, graphics);
});

Clazz.newMeth(C$, 'newFont$S$Z$Z$F',  function (fontFace, isBold, isItalic, fontSize) {
return $I$(4).newFont$S$Z$Z$F(fontFace, isBold, isItalic, fontSize);
});

Clazz.newMeth(C$, 'getJsObjectInfo$OA$S$OA',  function (jsObject, method, args) {
return null;
});

Clazz.newMeth(C$, 'isHeadless$',  function () {
return $I$(5).isHeadless$();
});

Clazz.newMeth(C$, 'isSingleThreaded$',  function () {
return false;
});

Clazz.newMeth(C$, 'notifyEndOfRendering$',  function () {
});

Clazz.newMeth(C$, 'getWindow$java_awt_Container',  function (p) {
while (p != null ){
if (Clazz.instanceOf(p, "java.awt.Frame")) return p;
 else if (Clazz.instanceOf(p, "javax.swing.JDialog")) return p;
 else if (Clazz.instanceOf(p, "jspecview.java.JmolFrame")) return (p).getFrame$();
p=p.getParent$();
}
return null;
}, 1);

Clazz.newMeth(C$, 'getDateFormat$S',  function (isoType) {
if (isoType == null ) {
isoType="EEE, d MMM yyyy HH:mm:ss Z";
} else if (isoType.contains$CharSequence("8824")) {
return "D:" + Clazz.new_($I$(6,1).c$$S,["YYYYMMddHHmmssX"]).format$java_util_Date(Clazz.new_(java.util.Date)) + "'00'" ;
} else if (isoType.contains$CharSequence("8601")) {
return Clazz.new_($I$(6,1).c$$S,["yyyy-MM-dd\'T\'HH:mm:ss"]).format$java_util_Date(Clazz.new_(java.util.Date));
}return Clazz.new_($I$(6,1).c$$S,[isoType]).format$java_util_Date(Clazz.new_(java.util.Date));
});

Clazz.newMeth(C$, 'newFile$S',  function (name) {
return Clazz.new_($I$(7,1).c$$S,[name]);
});

Clazz.newMeth(C$, 'getBufferedFileInputStream$S',  function (name) {
return $I$(7).getBufferedFileInputStream$S(name);
});

Clazz.newMeth(C$, 'getURLContents$java_net_URL$BA$S$Z',  function (url, outputBytes, post, asString) {
var ret=$I$(7).getURLContents$java_net_URL$BA$S(url, outputBytes, post);
try {
return (!asString ? ret : Clazz.instanceOf(ret, "java.lang.String") ? ret :  String.instantialize($I$(8).getStreamAsBytes$java_io_BufferedInputStream$javajs_util_OC(ret, null)));
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
return "" + e;
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'getLocalUrl$S',  function (fileName) {
return null;
});

Clazz.newMeth(C$, 'getImageDialog$S$java_util_Map',  function (title, imageMap) {
return null;
});

Clazz.newMeth(C$, 'forceAsyncLoad$S',  function (filename) {
return false;
});

Clazz.newMeth(C$, 'isJS$',  function () {
return false;
});

Clazz.newMeth(C$, 'getInChI$',  function () {
return null;
});

Clazz.newMeth(C$, 'confirm$S$S',  function (msg, msgNo) {
var ret=$I$(9,"showConfirmDialog$java_awt_Component$O",[null, $I$(10).$$S(msg)]);
switch (ret) {
case 0:
return ret;
case 2:
if (false &&true) return ret;
case 1:
default:
return (msgNo != null  && $I$(9,"showConfirmDialog$java_awt_Component$O",[null, $I$(10).$$S(msgNo)]) == 0  ? 1 : 2);
}
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:07 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
