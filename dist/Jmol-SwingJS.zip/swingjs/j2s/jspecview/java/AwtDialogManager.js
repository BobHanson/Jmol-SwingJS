(function(){var P$=Clazz.newPackage("jspecview.java"),I$=[[0,'jspecview.java.AwtDialog','javax.swing.JOptionPane','javax.swing.JDialog','javax.swing.JComboBox','java.awt.Dimension','javax.swing.JPanel','java.awt.FlowLayout','javax.swing.JButton','java.awt.BorderLayout','javax.swing.JLabel','javax.swing.JTable','javax.swing.JScrollPane','javax.swing.JTextArea','java.awt.Font']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AwtDialogManager", null, 'jspecview.dialog.DialogManager', ['javax.swing.event.ListSelectionListener', 'java.awt.event.WindowListener', 'java.awt.event.ActionListener', 'java.awt.event.FocusListener']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'getDialog$jspecview_dialog_JSVDialog',  function (jsvDialog) {
return Clazz.new_([this, jsvDialog, this.registerDialog$jspecview_dialog_JSVDialog(jsvDialog)],$I$(1,1).c$$jspecview_dialog_DialogManager$jspecview_dialog_JSVDialog$S);
});

Clazz.newMeth(C$, 'getDialogInput$O$S$S$I$O$OA$S',  function (parentComponent, phrase, title, msgType, icon, objects, defaultStr) {
return $I$(2).showInputDialog$java_awt_Component$O$S$I$javax_swing_Icon$OA$O(parentComponent, phrase, title, msgType, icon, objects, defaultStr);
});

Clazz.newMeth(C$, 'getOptionFromDialog$O$SA$jspecview_api_JSVPanel$S$S',  function (frame, items, jsvp, title, label) {
var dialog=Clazz.new_($I$(3,1).c$$java_awt_Frame$S$Z,[frame, title, true]);
dialog.setResizable$Z(false);
dialog.setSize$I$I(200, 100);
var panel=jsvp;
dialog.setLocation$I$I(((panel.getLocation$().x + panel.getSize$().width)/2|0), ((panel.getLocation$().y + panel.getSize$().height)/2|0));
var cb=Clazz.new_($I$(4,1).c$$OA,[items]);
var d=Clazz.new_($I$(5,1).c$$I$I,[120, 25]);
cb.setPreferredSize$java_awt_Dimension(d);
cb.setMaximumSize$java_awt_Dimension(d);
cb.setMinimumSize$java_awt_Dimension(d);
var p=Clazz.new_([Clazz.new_($I$(7,1))],$I$(6,1).c$$java_awt_LayoutManager);
var button=Clazz.new_($I$(8,1).c$$S,["OK"]);
p.add$java_awt_Component(cb);
p.add$java_awt_Component(button);
dialog.getContentPane$().setLayout$java_awt_LayoutManager(Clazz.new_($I$(9,1)));
dialog.getContentPane$().add$java_awt_Component$O(Clazz.new_($I$(10,1).c$$S$I,[label, 0]), "North");
dialog.getContentPane$().add$java_awt_Component(p);
var ret=Clazz.array(Integer.TYPE, -1, [-2147483648]);
button.addActionListener$java_awt_event_ActionListener(((P$.AwtDialogManager$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "AwtDialogManager$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.$finals$.ret[0]=this.$finals$.cb.getSelectedIndex$();
this.$finals$.dialog.dispose$();
});
})()
), Clazz.new_(P$.AwtDialogManager$1.$init$,[this, {dialog:dialog,ret:ret,cb:cb}])));
dialog.setVisible$Z(true);
dialog.dispose$();
return ret[0];
});

Clazz.newMeth(C$, 'getLocationOnScreen$O',  function (component) {
var pt=(component).getLocationOnScreen$();
return Clazz.array(Integer.TYPE, -1, [pt.x, pt.y]);
});

Clazz.newMeth(C$, 'showMessageDialog$O$S$S$I',  function (parentComponent, msg, title, msgType) {
$I$(2).showMessageDialog$java_awt_Component$O$S$I(parentComponent, msg, title, msgType);
});

Clazz.newMeth(C$, 'showProperties$O$jspecview_common_Spectrum',  function (frame, spectrum) {
var rowData=spectrum.getHeaderRowDataAsArray$();
var columnNames=Clazz.array(String, -1, ["Label", "Description"]);
var table=Clazz.new_($I$(11,1).c$$OAA$OA,[rowData, columnNames]);
table.setPreferredScrollableViewportSize$java_awt_Dimension(Clazz.new_($I$(5,1).c$$I$I,[400, 195]));
var scrollPane=Clazz.new_($I$(12,1).c$$java_awt_Component,[table]);
$I$(2).showMessageDialog$java_awt_Component$O$S$I(frame, scrollPane, "Header Information", -1);
});

Clazz.newMeth(C$, 'showMessage$O$S$S',  function (frame, text, title) {
var dialog=Clazz.new_($I$(3,1).c$$java_awt_Frame$S$Z,[null, title, true]);
dialog.setLayout$java_awt_LayoutManager(Clazz.new_($I$(9,1)));
var t=Clazz.new_($I$(13,1));
t.setText$S(text);
t.setCaretPosition$I(0);
t.setFont$java_awt_Font(Clazz.new_($I$(14,1).c$$S$I$I,[null, 0, 12]));
var scrollPane=Clazz.new_($I$(12,1).c$$java_awt_Component,[t]);
scrollPane.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(5,1).c$$I$I,[600, 400]));
scrollPane.setMinimumSize$java_awt_Dimension(Clazz.new_($I$(5,1).c$$I$I,[600, 400]));
dialog.getContentPane$().add$java_awt_Component$O(scrollPane, "Center");
dialog.pack$();
dialog.setVisible$Z(true);
});

Clazz.newMeth(C$, 'valueChanged$javax_swing_event_ListSelectionEvent',  function (e) {
var adjusting=e.getValueIsAdjusting$();
var lsm=e.getSource$();
var selector=this.getSelectorName$O(lsm);
if (selector == null ) return;
var index=lsm.getLeadSelectionIndex$();
this.processTableEvent$S$I$I$Z(selector, index, -1, adjusting);
});

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.processClick$S((e.getSource$()).getName$());
});

Clazz.newMeth(C$, 'focusGained$java_awt_event_FocusEvent',  function (e) {
this.processClick$S((e.getSource$()).registryKey + "/FOCUS");
});

Clazz.newMeth(C$, 'windowClosing$java_awt_event_WindowEvent',  function (e) {
this.processWindowClosing$S((e.getSource$()).getName$());
});

Clazz.newMeth(C$, 'windowActivated$java_awt_event_WindowEvent',  function (arg0) {
});

Clazz.newMeth(C$, 'windowClosed$java_awt_event_WindowEvent',  function (arg0) {
});

Clazz.newMeth(C$, 'windowDeactivated$java_awt_event_WindowEvent',  function (arg0) {
});

Clazz.newMeth(C$, 'windowDeiconified$java_awt_event_WindowEvent',  function (arg0) {
});

Clazz.newMeth(C$, 'windowIconified$java_awt_event_WindowEvent',  function (arg0) {
});

Clazz.newMeth(C$, 'windowOpened$java_awt_event_WindowEvent',  function (arg0) {
});

Clazz.newMeth(C$, 'focusLost$java_awt_event_FocusEvent',  function (e) {
});
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:52 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
