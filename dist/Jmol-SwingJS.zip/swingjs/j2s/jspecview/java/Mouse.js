(function(){var P$=Clazz.newPackage("jspecview.java"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Mouse", null, 'jspecview.app.GenericMouse', ['java.awt.event.MouseWheelListener', 'java.awt.event.MouseListener', 'java.awt.event.MouseMotionListener', 'java.awt.event.KeyListener']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$jspecview_api_JSVPanel',  function (jsvp) {
;C$.superclazz.c$$jspecview_api_JSVPanel.apply(this,[jsvp]);C$.$init$.apply(this);
var display=jsvp;
display.addKeyListener$java_awt_event_KeyListener(this);
display.addMouseListener$java_awt_event_MouseListener(this);
display.addMouseMotionListener$java_awt_event_MouseMotionListener(this);
display.addMouseWheelListener$java_awt_event_MouseWheelListener(this);
}, 1);

Clazz.newMeth(C$, 'dispose$',  function () {
var display=this.jsvp;
display.removeMouseListener$java_awt_event_MouseListener(this);
display.removeMouseMotionListener$java_awt_event_MouseMotionListener(this);
display.removeMouseWheelListener$java_awt_event_MouseWheelListener(this);
display.removeKeyListener$java_awt_event_KeyListener(this);
C$.superclazz.prototype.dispose$.apply(this, []);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:07 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
