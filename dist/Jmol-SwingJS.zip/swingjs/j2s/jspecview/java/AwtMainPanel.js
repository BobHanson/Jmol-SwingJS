(function(){var P$=Clazz.newPackage("jspecview.java"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "AwtMainPanel", null, 'javax.swing.JPanel', 'jspecview.api.JSVMainPanel');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['currentPanelIndex'],'O',['selectedPanel','jspecview.api.JSVPanel']]]

Clazz.newMeth(C$, 'getCurrentPanelIndex$',  function () {
return this.currentPanelIndex;
});

Clazz.newMeth(C$, 'c$$java_awt_BorderLayout',  function (borderLayout) {
;C$.superclazz.c$$java_awt_LayoutManager.apply(this,[borderLayout]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'dispose$',  function () {
});

Clazz.newMeth(C$, 'getTitle$',  function () {
return null;
});

Clazz.newMeth(C$, 'setTitle$S',  function (title) {
});

Clazz.newMeth(C$, 'setSelectedPanel$jspecview_common_JSViewer$jspecview_api_JSVPanel$javajs_util_Lst',  function (viewer, jsvp, panelNodes) {
if (jsvp !== this.selectedPanel ) {
if (this.selectedPanel != null ) this.remove$java_awt_Component(this.selectedPanel);
if (jsvp != null ) this.add$java_awt_Component$O(jsvp, "Center");
this.selectedPanel=jsvp;
}var i=viewer.selectPanel$jspecview_api_JSVPanel$javajs_util_Lst(jsvp, panelNodes);
if (i >= 0) this.currentPanelIndex=i;
this.setVisible$Z(true);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:57 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
