(function(){var P$=Clazz.newPackage("jspecview.java"),p$1={},I$=[[0,'javax.swing.JComboBox','javax.swing.ButtonGroup','javax.swing.JButton','javax.swing.JCheckBox','javax.swing.JRadioButton','jspecview.common.PrintLayout','javax.print.attribute.standard.MediaSizeName','javax.swing.ImageIcon','javax.swing.border.TitledBorder','javax.swing.JPanel','java.awt.GridBagLayout','java.awt.Insets','java.awt.GridBagConstraints']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AwtPrintDialog", null, 'javax.swing.JDialog', 'jspecview.api.JSVPrintDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.layoutButtonGroup=Clazz.new_($I$(2,1));
this.fontButtonGroup=Clazz.new_($I$(2,1));
this.positionButtonGroup=Clazz.new_($I$(2,1));
this.previewButton=Clazz.new_($I$(3,1));
this.cancelButton=Clazz.new_($I$(3,1));
this.printButton=Clazz.new_($I$(3,1));
this.pdfButton=Clazz.new_($I$(3,1));
this.scaleXCheckBox=Clazz.new_($I$(4,1));
this.scaleYCheckBox=Clazz.new_($I$(4,1));
this.gridCheckBox=Clazz.new_($I$(4,1));
this.titleCheckBox=Clazz.new_($I$(4,1));
this.landscapeRadioButton=Clazz.new_($I$(5,1));
this.topLeftRadioButton=Clazz.new_($I$(5,1));
this.centerRadioButton=Clazz.new_($I$(5,1));
this.portraitRadioButton=Clazz.new_($I$(5,1));
this.fitToPageRadioButton=Clazz.new_($I$(5,1));
this.chooseFontRadioButton=Clazz.new_($I$(5,1));
this.defaultFontRadioButton=Clazz.new_($I$(5,1));
},1);

C$.$fields$=[['O',['layoutButtonGroup','javax.swing.ButtonGroup','+fontButtonGroup','+positionButtonGroup','pl','jspecview.common.PrintLayout','+plNew','previewButton','javax.swing.JButton','+cancelButton','+printButton','+pdfButton','scaleXCheckBox','javax.swing.JCheckBox','+scaleYCheckBox','+gridCheckBox','+titleCheckBox','landscapeRadioButton','javax.swing.JRadioButton','+topLeftRadioButton','+centerRadioButton','+portraitRadioButton','+fitToPageRadioButton','+chooseFontRadioButton','+defaultFontRadioButton']]
,['O',['paperComboBox','javax.swing.JComboBox','previewPortraitCenterIcon','javax.swing.ImageIcon','+previewPortraitDefaultIcon','+previewPortraitFitIcon','+previewLandscapeCenterIcon','+previewLandscapeDefaultIcon','+previewLandscapeFitIcon']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$java_awt_Frame$S$Z.apply(this,[null, "Print layout", true]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'set$O$jspecview_common_PrintLayout$Z',  function (frame, pl, isJob) {
if (pl == null ) pl=Clazz.new_($I$(6,1).c$$jspecview_common_PanelData,[null]);
this.pl=pl;
try {
p$1.jbInit$Z.apply(this, [isJob]);
this.setSize$I$I(320, 250);
this.setResizable$Z(false);
this.pack$();
this.pdfButton.requestFocusInWindow$();
this.setVisible$Z(true);
return this;
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
ex.printStackTrace$();
return null;
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'setStaticElements$',  function () {
if (C$.previewLandscapeFitIcon != null ) return;
C$.paperComboBox.addItem$O($I$(7).NA_LETTER);
C$.paperComboBox.addItem$O($I$(7).NA_LEGAL);
C$.paperComboBox.addItem$O($I$(7).ISO_A4);
C$.paperComboBox.addItem$O($I$(7).ISO_B4);
C$.previewPortraitCenterIcon=C$.getIcon$S("portraitCenter");
C$.previewPortraitDefaultIcon=C$.getIcon$S("portraitDefault");
C$.previewPortraitFitIcon=C$.getIcon$S("portraitFit");
C$.previewLandscapeCenterIcon=C$.getIcon$S("landscapeCenter");
C$.previewLandscapeDefaultIcon=C$.getIcon$S("landscapeDefault");
C$.previewLandscapeFitIcon=C$.getIcon$S("landscapeFit");
}, 1);

Clazz.newMeth(C$, 'getIcon$S',  function (name) {
return Clazz.new_([Clazz.getClass(C$).getResource$S("icons/" + name + ".gif" )],$I$(8,1).c$$java_net_URL);
}, 1);

Clazz.newMeth(C$, 'jbInit$Z',  function (isJob) {
this.layoutButtonGroup.add$javax_swing_AbstractButton(this.portraitRadioButton);
this.layoutButtonGroup.add$javax_swing_AbstractButton(this.landscapeRadioButton);
this.positionButtonGroup.add$javax_swing_AbstractButton(this.centerRadioButton);
this.positionButtonGroup.add$javax_swing_AbstractButton(this.fitToPageRadioButton);
this.positionButtonGroup.add$javax_swing_AbstractButton(this.topLeftRadioButton);
this.fontButtonGroup.add$javax_swing_AbstractButton(this.defaultFontRadioButton);
this.fontButtonGroup.add$javax_swing_AbstractButton(this.chooseFontRadioButton);
C$.setStaticElements$();
var layoutBorder=Clazz.new_($I$(9,1).c$$S,["Layout"]);
layoutBorder.setTitleJustification$I(2);
this.cancelButton.setText$S("Cancel");
this.cancelButton.addActionListener$java_awt_event_ActionListener(((P$.AwtPrintDialog$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "AwtPrintDialog$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.java.AwtPrintDialog'].cancelButton_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['jspecview.java.AwtPrintDialog'], [e]);
});
})()
), Clazz.new_(P$.AwtPrintDialog$1.$init$,[this, null])));
this.printButton.setToolTipText$S("");
this.printButton.setText$S("Print");
this.printButton.addActionListener$java_awt_event_ActionListener(((P$.AwtPrintDialog$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "AwtPrintDialog$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.java.AwtPrintDialog'].printButton_actionPerformed$Z.apply(this.b$['jspecview.java.AwtPrintDialog'], [false]);
});
})()
), Clazz.new_(P$.AwtPrintDialog$2.$init$,[this, null])));
this.pdfButton.setToolTipText$S("");
this.pdfButton.setText$S("Create PDF");
this.pdfButton.addActionListener$java_awt_event_ActionListener(((P$.AwtPrintDialog$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "AwtPrintDialog$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.java.AwtPrintDialog'].printButton_actionPerformed$Z.apply(this.b$['jspecview.java.AwtPrintDialog'], [true]);
});
})()
), Clazz.new_(P$.AwtPrintDialog$3.$init$,[this, null])));
var layoutContentPanel=Clazz.new_($I$(10,1));
var layoutPanel=Clazz.new_($I$(10,1));
var buttonPanel=Clazz.new_($I$(10,1));
layoutPanel.setBorder$javax_swing_border_Border(layoutBorder);
layoutPanel.setLayout$java_awt_LayoutManager(Clazz.new_($I$(11,1)));
this.landscapeRadioButton.setActionCommand$S("Landscape");
this.landscapeRadioButton.setText$S("Landscape");
this.landscapeRadioButton.addActionListener$java_awt_event_ActionListener(((P$.AwtPrintDialog$4||
(function(){/*a*/var C$=Clazz.newClass(P$, "AwtPrintDialog$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.java.AwtPrintDialog'].landscapeRadioButton_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['jspecview.java.AwtPrintDialog'], [e]);
});
})()
), Clazz.new_(P$.AwtPrintDialog$4.$init$,[this, null])));
layoutContentPanel.setLayout$java_awt_LayoutManager(Clazz.new_($I$(11,1)));
this.scaleXCheckBox.setText$S("X-Scale");
this.scaleYCheckBox.setText$S("Y-Scale");
this.previewButton.setBorder$javax_swing_border_Border(null);
this.previewButton.setIcon$javax_swing_Icon(C$.previewLandscapeDefaultIcon);
this.gridCheckBox.setText$S("Grid");
this.topLeftRadioButton.setActionCommand$S("Default");
this.topLeftRadioButton.setText$S("Top Left");
this.topLeftRadioButton.addActionListener$java_awt_event_ActionListener(((P$.AwtPrintDialog$5||
(function(){/*a*/var C$=Clazz.newClass(P$, "AwtPrintDialog$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.java.AwtPrintDialog'].defaultPosRadioButton_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['jspecview.java.AwtPrintDialog'], [e]);
});
})()
), Clazz.new_(P$.AwtPrintDialog$5.$init$,[this, null])));
this.centerRadioButton.setActionCommand$S("Center");
this.centerRadioButton.setText$S("Center");
this.centerRadioButton.addActionListener$java_awt_event_ActionListener(((P$.AwtPrintDialog$6||
(function(){/*a*/var C$=Clazz.newClass(P$, "AwtPrintDialog$6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.java.AwtPrintDialog'].centerRadioButton_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['jspecview.java.AwtPrintDialog'], [e]);
});
})()
), Clazz.new_(P$.AwtPrintDialog$6.$init$,[this, null])));
this.portraitRadioButton.setActionCommand$S("Portrait");
this.portraitRadioButton.setText$S("Portrait");
this.portraitRadioButton.addActionListener$java_awt_event_ActionListener(((P$.AwtPrintDialog$7||
(function(){/*a*/var C$=Clazz.newClass(P$, "AwtPrintDialog$7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.java.AwtPrintDialog'].portraitRadioButton_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['jspecview.java.AwtPrintDialog'], [e]);
});
})()
), Clazz.new_(P$.AwtPrintDialog$7.$init$,[this, null])));
this.fitToPageRadioButton.setActionCommand$S("Fit To Page");
this.fitToPageRadioButton.setText$S("Fit to Page");
this.fitToPageRadioButton.addActionListener$java_awt_event_ActionListener(((P$.AwtPrintDialog$8||
(function(){/*a*/var C$=Clazz.newClass(P$, "AwtPrintDialog$8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jspecview.java.AwtPrintDialog'].fitToPageRadioButton_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['jspecview.java.AwtPrintDialog'], [e]);
});
})()
), Clazz.new_(P$.AwtPrintDialog$8.$init$,[this, null])));
this.chooseFontRadioButton.setText$S("Choose font");
this.defaultFontRadioButton.setText$S("Use default");
this.titleCheckBox.setText$S("Title");
this.getContentPane$().add$java_awt_Component$O(buttonPanel, "South");
if (isJob) buttonPanel.add$java_awt_Component$O(this.printButton, null);
buttonPanel.add$java_awt_Component$O(this.pdfButton, null);
buttonPanel.add$java_awt_Component$O(this.cancelButton, null);
var insets=Clazz.new_($I$(12,1).c$$I$I$I$I,[0, 0, 0, 0]);
this.getContentPane$().add$java_awt_Component$O(layoutContentPanel, "Center");
layoutContentPanel.add$java_awt_Component$O(layoutPanel, Clazz.new_($I$(13,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I,[0, 0, 1, 1, 0.5, 0.0, 10, 1, insets, 0, 0]));
layoutPanel.add$java_awt_Component$O(this.landscapeRadioButton, Clazz.new_($I$(13,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I,[0, 0, 1, 1, 1.0, 1.0, 18, 0, insets, 0, 0]));
layoutPanel.add$java_awt_Component$O(this.portraitRadioButton, Clazz.new_($I$(13,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I,[0, 1, 1, 1, 1.0, 1.0, 18, 0, insets, 0, 0]));
layoutPanel.add$java_awt_Component$O(this.titleCheckBox, Clazz.new_($I$(13,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I,[0, 4, 1, 1, 1.0, 1.0, 18, 0, insets, 0, 0]));
layoutPanel.add$java_awt_Component$O(this.gridCheckBox, Clazz.new_($I$(13,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I,[0, 5, 1, 1, 1.0, 1.0, 18, 0, insets, 0, 0]));
layoutPanel.add$java_awt_Component$O(this.fitToPageRadioButton, Clazz.new_($I$(13,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I,[1, 0, 1, 1, 1.0, 1.0, 18, 0, insets, 0, 0]));
layoutPanel.add$java_awt_Component$O(this.topLeftRadioButton, Clazz.new_($I$(13,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I,[1, 1, 1, 1, 1.0, 1.0, 18, 0, insets, 0, 0]));
layoutPanel.add$java_awt_Component$O(this.centerRadioButton, Clazz.new_($I$(13,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I,[1, 2, 1, 1, 1.0, 1.0, 18, 0, insets, 0, 0]));
layoutPanel.add$java_awt_Component$O(this.scaleXCheckBox, Clazz.new_($I$(13,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I,[1, 4, 1, 1, 1.0, 1.0, 18, 0, insets, 0, 0]));
layoutPanel.add$java_awt_Component$O(this.scaleYCheckBox, Clazz.new_($I$(13,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I,[1, 5, 1, 1, 1.0, 1.0, 18, 0, insets, 0, 0]));
layoutPanel.add$java_awt_Component$O(this.previewButton, Clazz.new_($I$(13,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I,[2, 0, 1, 5, 0.0, 1.0, 18, 1, insets, 0, 0]));
layoutPanel.add$java_awt_Component$O(C$.paperComboBox, Clazz.new_($I$(13,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I,[2, 5, 1, 1, 1.0, 1.0, 18, 1, insets, 0, 0]));
p$1.setDefaults.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'portraitRadioButton_actionPerformed$java_awt_event_ActionEvent',  function (e) {
p$1.setPreview.apply(this, []);
});

Clazz.newMeth(C$, 'landscapeRadioButton_actionPerformed$java_awt_event_ActionEvent',  function (e) {
p$1.setPreview.apply(this, []);
});

Clazz.newMeth(C$, 'centerRadioButton_actionPerformed$java_awt_event_ActionEvent',  function (e) {
p$1.setPreview.apply(this, []);
});

Clazz.newMeth(C$, 'fitToPageRadioButton_actionPerformed$java_awt_event_ActionEvent',  function (e) {
p$1.setPreview.apply(this, []);
});

Clazz.newMeth(C$, 'setPreview',  function () {
var layout=" PL".indexOf$I(this.layoutButtonGroup.getSelection$().getActionCommand$().charAt$I(0));
var position=" DCF".indexOf$I(this.positionButtonGroup.getSelection$().getActionCommand$().charAt$I(0));
var icon=null;
switch ((layout << 4) + position) {
default:
case 17:
icon=C$.previewPortraitDefaultIcon;
break;
case 18:
icon=C$.previewPortraitCenterIcon;
break;
case 19:
icon=C$.previewPortraitFitIcon;
break;
case 33:
icon=C$.previewLandscapeDefaultIcon;
break;
case 34:
icon=C$.previewLandscapeCenterIcon;
break;
case 35:
icon=C$.previewLandscapeFitIcon;
break;
}
this.previewButton.setIcon$javax_swing_Icon(icon);
}, p$1);

Clazz.newMeth(C$, 'defaultPosRadioButton_actionPerformed$java_awt_event_ActionEvent',  function (e) {
p$1.setPreview.apply(this, []);
});

Clazz.newMeth(C$, 'setDefaults',  function () {
this.landscapeRadioButton.setSelected$Z(this.pl.layout.equals$O("landscape"));
this.portraitRadioButton.setSelected$Z(!this.landscapeRadioButton.isSelected$());
this.scaleXCheckBox.setSelected$Z(this.pl.showXScale);
this.scaleYCheckBox.setSelected$Z(this.pl.showYScale);
this.gridCheckBox.setSelected$Z(this.pl.showGrid);
this.titleCheckBox.setSelected$Z(this.pl.showTitle);
this.fitToPageRadioButton.setSelected$Z(this.pl.position.equals$O("fit to page"));
this.centerRadioButton.setSelected$Z(this.pl.position.equals$O("center"));
this.topLeftRadioButton.setSelected$Z(this.pl.position.equals$O("default"));
this.defaultFontRadioButton.setSelected$Z(this.pl.font == null );
for (var i=0; i < C$.paperComboBox.getItemCount$(); i++) if (this.pl.paper == null  || C$.paperComboBox.getItemAt$I(i).equals$O(this.pl.paper) ) {
C$.paperComboBox.setSelectedIndex$I(i);
break;
}
p$1.setPreview.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'printButton_actionPerformed$Z',  function (asPDF) {
this.plNew=Clazz.new_($I$(6,1).c$$jspecview_common_PanelData,[null]);
this.plNew.layout=this.layoutButtonGroup.getSelection$().getActionCommand$().toLowerCase$();
this.plNew.font=null;
this.plNew.position=this.positionButtonGroup.getSelection$().getActionCommand$().toLowerCase$();
this.plNew.showGrid=this.gridCheckBox.isSelected$();
this.plNew.showXScale=this.scaleXCheckBox.isSelected$();
this.plNew.showYScale=this.scaleYCheckBox.isSelected$();
this.plNew.showTitle=this.titleCheckBox.isSelected$();
this.plNew.paper=C$.paperComboBox.getSelectedItem$();
this.plNew.asPDF=asPDF;
this.dispose$();
});

Clazz.newMeth(C$, 'getPrintLayout$',  function () {
return this.plNew;
});

Clazz.newMeth(C$, 'cancelButton_actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.dispose$();
});

C$.$static$=function(){C$.$static$=0;
C$.paperComboBox=Clazz.new_($I$(1,1));
};
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:29 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
