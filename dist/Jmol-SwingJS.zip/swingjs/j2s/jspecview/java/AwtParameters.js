(function(){var P$=Clazz.newPackage("jspecview.java"),I$=[[0,'java.awt.GraphicsEnvironment','java.util.Arrays','jspecview.java.AwtColor']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AwtParameters", null, 'jspecview.common.ColorParameters');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'isValidFontName$S',  function (name) {
var g=$I$(1).getLocalGraphicsEnvironment$();
var fontList=$I$(2,"asList$OA",[g.getAvailableFontFamilyNames$()]);
for (var s, $s = fontList.iterator$(); $s.hasNext$()&&((s=($s.next$())),1);) if (name.equalsIgnoreCase$S(s)) return true;

return false;
});

Clazz.newMeth(C$, 'getColor1$I',  function (rgb) {
return Clazz.new_($I$(3,1).c$$I,[rgb]);
});

Clazz.newMeth(C$, 'getColor3$I$I$I',  function (r, g, b) {
return Clazz.new_($I$(3,1).c$$I$I$I,[r, g, b]);
});

Clazz.newMeth(C$, 'copy$S',  function (newName) {
return (Clazz.new_(C$).setName$S(newName)).setElementColors$jspecview_common_ColorParameters(this);
});
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:29 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
