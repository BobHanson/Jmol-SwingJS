(function(){var P$=Clazz.newPackage("jspecview.java"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "DialogTableModel", null, 'javax.swing.table.AbstractTableModel');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['asString'],'O',['columnNames','String[]','data','Object[][]']]]

Clazz.newMeth(C$, 'c$$SA$OAA$Z',  function (columnNames, data, asString) {
Clazz.super_(C$, this);
this.columnNames=columnNames;
this.data=data;
this.asString=asString;
}, 1);

Clazz.newMeth(C$, 'getColumnCount$',  function () {
return this.columnNames.length;
});

Clazz.newMeth(C$, 'getRowCount$',  function () {
return this.data.length;
});

Clazz.newMeth(C$, 'getColumnName$I',  function (col) {
return this.columnNames[col];
});

Clazz.newMeth(C$, 'getValueAt$I$I',  function (row, col) {
var o=this.data[row][col];
return (this.asString ? " " + o + " "  : o);
});

Clazz.newMeth(C$, 'getColumnClass$I',  function (c) {
return this.getValueAt$I$I(0, c).getClass$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:07 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
