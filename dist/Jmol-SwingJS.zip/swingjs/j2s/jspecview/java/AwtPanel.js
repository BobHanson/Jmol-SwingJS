(function(){var P$=Clazz.newPackage("jspecview.java"),p$1={},I$=[[0,'javax.swing.ToolTipManager','jspecview.common.PanelData','javax.swing.BorderFactory','java.awt.Color','java.awt.Cursor','javax.swing.JOptionPane','org.jmol.util.Logger','java.awt.print.PrinterJob','jspecview.common.JSViewer','javax.print.attribute.HashPrintRequestAttributeSet','javax.print.attribute.standard.OrientationRequested','javajs.util.PT','javax.print.attribute.standard.MediaSizeName','java.awt.Dimension','org.jmol.util.Font','javax.imageio.ImageIO','javax.swing.SwingUtilities',['jspecview.java.AwtPanel','.RequestThread']]],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AwtPanel", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'javax.swing.JPanel', ['jspecview.api.JSVPanel', 'java.awt.print.Printable']);
C$.$classes$=[['RequestThread',1]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['apiPlatform','org.jmol.api.GenericPlatform','pd','jspecview.common.PanelData','vwr','jspecview.common.JSViewer','mouse','org.jmol.api.GenericMouseInterface','bgcolor','javajs.api.GenericColor']]]

Clazz.newMeth(C$, 'getApiPlatform$',  function () {
return this.apiPlatform;
});

Clazz.newMeth(C$, 'getPanelData$',  function () {
return this.pd;
});

Clazz.newMeth(C$, 'getEmptyPanel$jspecview_common_JSViewer',  function (viewer) {
return Clazz.new_(C$.c$$jspecview_common_JSViewer$Z,[viewer, false]);
}, 1);

Clazz.newMeth(C$, 'getPanelOne$jspecview_common_JSViewer$jspecview_common_Spectrum',  function (viewer, spectrum) {
$I$(1).sharedInstance$().setInitialDelay$I(0);
var p=Clazz.new_(C$.c$$jspecview_common_JSViewer$Z,[viewer, true]);
p.pd.initOne$jspecview_common_Spectrum(spectrum);
return p;
}, 1);

Clazz.newMeth(C$, 'getPanelMany$jspecview_common_JSViewer$javajs_util_Lst',  function (viewer, spectra) {
var p=Clazz.new_(C$.c$$jspecview_common_JSViewer$Z,[viewer, true]);
p.pd.initMany$javajs_util_Lst$I$I(spectra, viewer.initialStartIndex, viewer.initialEndIndex);
return p;
}, 1);

Clazz.newMeth(C$, 'c$$jspecview_common_JSViewer$Z',  function (viewer, withPD) {
Clazz.super_(C$, this);
this.vwr=viewer;
this.pd=(withPD ? Clazz.new_($I$(2,1).c$$jspecview_api_JSVPanel$jspecview_common_JSViewer,[this, viewer]) : null);
this.apiPlatform=viewer.apiPlatform;
this.mouse=this.apiPlatform.getMouseManager$D$O(0, this);
this.setBorder$javax_swing_border_Border($I$(3,"createLineBorder$java_awt_Color",[$I$(4).BLACK]));
this.setCursor$java_awt_Cursor($I$(5).getDefaultCursor$());
}, 1);

Clazz.newMeth(C$, 'getTitle$',  function () {
return this.pd.getTitle$();
});

Clazz.newMeth(C$, 'dispose$',  function () {
if (this.pd != null ) this.pd.dispose$();
this.pd=null;
this.mouse.dispose$();
});

Clazz.newMeth(C$, 'setTitle$S',  function (title) {
this.pd.title=title;
this.setName$S(title);
});

Clazz.newMeth(C$, 'setColorOrFont$jspecview_common_ColorParameters$jspecview_common_ScriptToken',  function (ds, st) {
this.pd.setColorOrFont$jspecview_common_ColorParameters$jspecview_common_ScriptToken(ds, st);
});

Clazz.newMeth(C$, 'setBackgroundColor$javajs_api_GenericColor',  function (color) {
this.setBackground$java_awt_Color((this.bgcolor=color));
});

Clazz.newMeth(C$, 'getBackgroundColor$',  function () {
return this.bgcolor;
});

Clazz.newMeth(C$, 'doRepaint$Z',  function (andTaintAll) {
if (andTaintAll) this.pd.setTaintedAll$();
if (!this.pd.isPrinting) this.vwr.requestRepaint$();
});

Clazz.newMeth(C$, 'update$java_awt_Graphics',  function (g) {
this.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics',  function (g) {
if (this.vwr == null  || this.pd == null   || this.pd.graphSets == null   || this.pd.isPrinting ) return;
C$.superclazz.prototype.paintComponent$java_awt_Graphics.apply(this, [g]);
try {
this.pd.g2d=this.pd.g2d0;
g.setColor$java_awt_Color(this.getBackground$());
g.fillRect$I$I$I$I(0, 0, this.getWidth$(), this.getHeight$());
this.pd.drawGraph$O$O$O$I$I$Z(g, g, g, this.getWidth$(), this.getHeight$(), false);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$S("Exception while painting " + e);
e.printStackTrace$();
} else {
throw e;
}
}
this.vwr.repaintDone$();
});

Clazz.newMeth(C$, 'getInput$S$S$S',  function (message, title, sval) {
var ret=$I$(6).showInputDialog$java_awt_Component$O$S$I$javax_swing_Icon$OA$O(this, message, title, 3, null, null, sval);
this.getFocusNow$Z(true);
return ret;
});

Clazz.newMeth(C$, 'showMessage$S$S',  function (msg, title) {
$I$(7).info$S(msg);
if (title != null ) $I$(6,"showMessageDialog$java_awt_Component$O$S$I",[this, msg, title, (msg.startsWith$S("<html>") ? 1 : -1)]);
this.getFocusNow$Z(true);
});

Clazz.newMeth(C$, 'printPanel$jspecview_common_PrintLayout$java_io_OutputStream$S',  function (pl, os, title) {
pl.title=title;
pl.date=this.apiPlatform.getDateFormat$S("8824");
this.pd.setPrint$jspecview_common_PrintLayout$S(pl, os == null  ? pl.font : "Helvetica");
try {
var pj=(os == null  ? $I$(8).getPrinterJob$() : null);
if (pj != null ) {
if (title.length$() > 30) title=title.substring$I$I(0, 30);
pj.setJobName$S(title);
pj.setPrintable$java_awt_print_Printable(this);
}if (pj == null  || pj.printDialog$() ) {
try {
if (pj == null ) {
var d=p$1.getDimension$javax_print_attribute_standard_MediaSizeName.apply(this, [pl.paper]);
pl.paperWidth=d.width;
pl.paperHeight=d.height;
($I$(9).getInterface$S("jspecview.common.PDFWriter")).createPdfDocument$jspecview_api_JSVPanel$jspecview_common_PrintLayout$java_io_OutputStream(this, pl, os);
} else {
var aset=Clazz.new_($I$(10,1));
aset.add$javax_print_attribute_Attribute(pl.layout.equals$O("landscape") ? $I$(11).LANDSCAPE : $I$(11).PORTRAIT);
aset.add$javax_print_attribute_Attribute(pl.paper);
pj.print$javax_print_attribute_PrintRequestAttributeSet(aset);
}} catch (ex) {
if (Clazz.exceptionOf(ex,"java.awt.print.PrinterException")){
var s=ex.getMessage$();
if (s == null ) return;
s=$I$(12).rep$S$S$S(s, "not accepting job.", "not accepting jobs.");
this.showMessage$S$S(s, "Printer Error");
} else {
throw ex;
}
}
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$O(e);
} else {
throw e;
}
} finally {
this.pd.setPrint$jspecview_common_PrintLayout$S(null, null);
}
});

Clazz.newMeth(C$, 'getDimension$javax_print_attribute_standard_MediaSizeName',  function (paper) {
if (paper === $I$(13).NA_LETTER ) {
return Clazz.new_($I$(14,1).c$$I$I,[612, 792]);
}if (paper === $I$(13).NA_LEGAL ) {
return Clazz.new_($I$(14,1).c$$I$I,[612, 1008]);
}if (paper === $I$(13).ISO_A4 ) {
return Clazz.new_($I$(14,1).c$$I$I,[595, 841]);
}return Clazz.new_($I$(14,1).c$$I$I,[708, 1000]);
}, p$1);

Clazz.newMeth(C$, 'print$java_awt_Graphics$java_awt_print_PageFormat$I',  function (g, pf, pi) {
return this.pd.print$O$D$D$D$D$D$D$Z$I(g, pf.getImageableHeight$(), pf.getImageableWidth$(), pf.getImageableX$(), pf.getImageableY$(), pf.getPaper$().getHeight$(), pf.getPaper$().getWidth$(), pf.getOrientation$() == 1, pi);
});

Clazz.newMeth(C$, 'getFontFaceID$S',  function (name) {
return $I$(15).getFontFaceID$S("SansSerif");
});

Clazz.newMeth(C$, 'saveImage$S$org_jmol_api_GenericFileInterface$javajs_util_OC',  function (type, file, out) {
var msg="OK";
try {
var image=this.createImage$I$I(this.getWidth$(), this.getHeight$());
this.paint$java_awt_Graphics(image.getGraphics$());
$I$(16).write$java_awt_image_RenderedImage$S$java_io_File(image, type, file);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
msg=e.toString();
this.showMessage$S$S(msg, "Error Saving Image");
} else {
throw e;
}
}
return null;
});

Clazz.newMeth(C$, 'getFocusNow$Z',  function (asThread) {
if (asThread) $I$(17,"invokeLater$Runnable",[Clazz.new_($I$(18,1),[this, null])]);
 else this.requestFocusInWindow$();
if (this.pd != null ) this.pd.dialogsToFront$jspecview_common_Spectrum(null);
});

Clazz.newMeth(C$, 'toString',  function () {
return this.pd.getSpectrumAt$I(0).toString();
});

Clazz.newMeth(C$, 'processMouseEvent$I$I$I$I$J',  function (id, x, y, modifiers, time) {
return this.mouse.processEvent$I$I$I$I$J(id, x, y, modifiers, time);
});

Clazz.newMeth(C$, 'processKeyEvent$O',  function (event) {
this.mouse.processKeyEvent$O(event);
});

Clazz.newMeth(C$, 'processTwoPointGesture$DAAA',  function (touches) {
});

Clazz.newMeth(C$, 'showMenu$I$I',  function (x, y) {
this.vwr.showMenu$I$I(x, y);
});

Clazz.newMeth(C$, 'paintComponent$O',  function (display) {
C$.superclazz.prototype.paintComponent$java_awt_Graphics.apply(this, [display]);
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.AwtPanel, "RequestThread", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'Runnable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$',  function () {
this.b$['javax.swing.JComponent'].requestFocusInWindow$.apply(this.b$['javax.swing.JComponent'], []);
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:52 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
