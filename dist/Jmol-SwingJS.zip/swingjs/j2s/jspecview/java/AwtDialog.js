(function(){var P$=Clazz.newPackage("jspecview.java"),p$1={},I$=[[0,'javax.swing.BorderFactory','java.awt.Insets','java.util.Hashtable','javax.swing.JButton','java.awt.Dimension','java.awt.GridBagConstraints','javax.swing.JCheckBox','javax.swing.JLabel','javax.swing.JComboBox','javax.swing.JTextField','javax.swing.JScrollPane','jspecview.java.DialogTableModel','javax.swing.JTable','javajs.api.GenericColor',['jspecview.java.AwtDialog','.ColorRenderer'],['jspecview.java.AwtDialog','.TitleRenderer'],'java.awt.Toolkit','java.awt.Point','javax.swing.JPanel',['jspecview.common.Annotation','.AType'],'java.awt.GridBagLayout','javax.swing.JSplitPane']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AwtDialog", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'javax.swing.JDialog', 'jspecview.api.PlatformDialog');
C$.$classes$=[['ColorRenderer',0],['TitleRenderer',0]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.haveTwoPanels=true;
this.buttonInsets=Clazz.new_($I$(2,1).c$$I$I$I$I,[5, 5, 5, 5]);
this.panelInsets=Clazz.new_($I$(2,1).c$$I$I$I$I,[0, 0, 2, 2]);
this.defaultHeight=350;
this.selectedRow=-1;
},1);

C$.$fields$=[['Z',['haveColors','tableCellAlignLeft','haveTwoPanels'],'I',['iRow','defaultHeight','selectedRow'],'S',['optionKey','registryKey'],'O',['options','java.util.Map','manager','jspecview.dialog.DialogManager','$type','jspecview.common.Annotation.AType','leftPanel','javax.swing.JPanel','mainSplitPane','javax.swing.JSplitPane','rightPanel','javax.swing.JPanel','+thisPanel','dataTable','javax.swing.JTable','buttonInsets','java.awt.Insets','+panelInsets','tableModel','jspecview.java.DialogTableModel']]]

Clazz.newMeth(C$, 'c$$jspecview_dialog_DialogManager$jspecview_dialog_JSVDialog$S',  function (manager, jsvDialog, registryKey) {
Clazz.super_(C$, this);
this.manager=manager;
this.registryKey=registryKey;
this.$type=jsvDialog.getAType$();
this.optionKey=jsvDialog.optionKey;
this.options=jsvDialog.options;
if (this.options == null ) this.options=Clazz.new_($I$(3,1));
this.addFocusListener$java_awt_event_FocusListener(manager);
}, 1);

Clazz.newMeth(C$, 'setFocus$Z',  function (tf) {
if (tf) {
this.requestFocus$();
this.toFront$();
}});

Clazz.newMeth(C$, 'setVisible$Z',  function (tf) {
C$.superclazz.prototype.setVisible$Z.apply(this, [tf]);
});

Clazz.newMeth(C$, 'dispose$',  function () {
C$.superclazz.prototype.dispose$.apply(this, []);
});

Clazz.newMeth(C$, 'getColumnCentering$I',  function (column) {
return this.tableCellAlignLeft ? 2 : column == 0 ? 0 : 4;
});

Clazz.newMeth(C$, 'addButton$S$S',  function (name, text) {
var btn=Clazz.new_($I$(4,1));
btn.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(5,1).c$$I$I,[120, 25]));
btn.setText$S(text);
btn.setName$S(this.registryKey + "/" + name );
btn.addActionListener$java_awt_event_ActionListener(this.manager);
this.thisPanel.add$java_awt_Component$O(btn, Clazz.new_($I$(6,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I,[0, this.iRow++, 3, 1, 0.0, 0.0, 10, 0, this.buttonInsets, 0, 0]));
return btn;
});

Clazz.newMeth(C$, 'addCheckBox$S$S$I$Z',  function (name, title, level, isSelected) {
if (name == null ) {
this.iRow=0;
this.thisPanel=this.rightPanel;
return null;
}var cb=Clazz.new_($I$(7,1));
cb.setSelected$Z(isSelected);
cb.setText$S(title);
cb.setName$S(this.registryKey + "/" + name );
cb.addActionListener$java_awt_event_ActionListener(this.manager);
var insets=Clazz.new_($I$(2,1).c$$I$I$I$I,[0, 20 * level, 2, 2]);
this.thisPanel.add$java_awt_Component$O(cb, Clazz.new_($I$(6,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I,[0, this.iRow++, 1, 1, 0.0, 0.0, 17, 0, insets, 0, 0]));
return cb;
});

Clazz.newMeth(C$, 'addPanelLine$S$S$javax_swing_JComponent$S',  function (name, label, obj, units) {
this.thisPanel.add$java_awt_Component$O(Clazz.new_([label == null  ? name : label],$I$(8,1).c$$S), Clazz.new_($I$(6,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I,[0, this.iRow, 1, 1, 0.0, 0.0, 13, 0, this.panelInsets, 0, 0]));
if (units == null ) {
this.thisPanel.add$java_awt_Component$O(obj, Clazz.new_($I$(6,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I,[1, this.iRow, 2, 1, 0.0, 0.0, 17, 0, this.panelInsets, 0, 0]));
} else {
this.thisPanel.add$java_awt_Component$O(obj, Clazz.new_($I$(6,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I,[1, this.iRow, 1, 1, 0.0, 0.0, 10, 0, this.panelInsets, 0, 0]));
this.thisPanel.add$java_awt_Component$O(Clazz.new_($I$(8,1).c$$S,[units]), Clazz.new_($I$(6,1).c$$I$I$I$I$D$D$I$I$java_awt_Insets$I$I,[2, this.iRow, 1, 1, 0.0, 0.0, 17, 0, this.panelInsets, 0, 0]));
}++this.iRow;
}, p$1);

Clazz.newMeth(C$, 'addSelectOption$S$S$SA$I$Z',  function (name, label, info, iPt, visible) {
var combo=Clazz.new_($I$(9,1).c$$OA,[info]);
combo.setSelectedIndex$I(iPt);
combo.setName$S(this.registryKey + "/" + name );
if (visible) {
combo.addActionListener$java_awt_event_ActionListener(this.manager);
p$1.addPanelLine$S$S$javax_swing_JComponent$S.apply(this, [name, label, combo, null]);
}return combo;
});

Clazz.newMeth(C$, 'addTextField$S$S$S$S$S$Z',  function (name, label, value, units, defaultValue, visible) {
var key=this.optionKey + "_" + name ;
if (value == null ) {
value=this.options.get$O(key);
if (value == null ) this.options.put$O$O(key, (value=defaultValue));
}var obj=Clazz.new_($I$(10,1).c$$S,[value]);
obj.setName$S(this.registryKey + "/" + name );
if (visible) {
obj.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(5,1).c$$I$I,[75, 25]));
obj.addActionListener$java_awt_event_ActionListener(this.manager);
p$1.addPanelLine$S$S$javax_swing_JComponent$S.apply(this, [name, label, obj, units]);
}return obj;
});

Clazz.newMeth(C$, 'createTable$OAA$SA$IA',  function (data, header, widths) {
try {
var scrollPane=Clazz.new_([this.dataTable=p$1.getDataTable$OAA$SA$IA$I.apply(this, [data, header, widths, (this.leftPanel == null  ? this.defaultHeight : this.leftPanel.getHeight$() - 50)])],$I$(11,1).c$$java_awt_Component);
if (this.mainSplitPane == null ) {
this.getContentPane$().add$java_awt_Component(scrollPane);
} else {
this.mainSplitPane.setRightComponent$java_awt_Component(scrollPane);
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
this.validate$();
this.repaint$();
});

Clazz.newMeth(C$, 'endLayout$',  function () {
this.getContentPane$().removeAll$();
this.getContentPane$().add$java_awt_Component(this.mainSplitPane);
this.pack$();
});

Clazz.newMeth(C$, 'getDataTable$OAA$SA$IA$I',  function (data, columnNames, columnWidths, height) {
this.selectedRow=-1;
this.tableModel=Clazz.new_($I$(12,1).c$$SA$OAA$Z,[columnNames, data, !this.haveColors]);
var table=Clazz.new_($I$(13,1).c$$javax_swing_table_TableModel,[this.tableModel]);
table.setSelectionMode$I(0);
if (this.haveColors) table.setDefaultRenderer$Class$javax_swing_table_TableCellRenderer(Clazz.getClass($I$(14),['getOpacity255$','getRGB$','setOpacity255$I']), Clazz.new_($I$(15,1),[this, null]));
table.setDefaultRenderer$Class$javax_swing_table_TableCellRenderer(Clazz.getClass(String), Clazz.new_($I$(16,1),[this, null]));
table.setCellSelectionEnabled$Z(true);
var selector=table.getSelectionModel$();
selector.addListSelectionListener$javax_swing_event_ListSelectionListener(this.manager);
this.manager.registerSelector$S$O(this.registryKey + "/ROW", selector);
selector=table.getColumnModel$().getSelectionModel$();
selector.addListSelectionListener$javax_swing_event_ListSelectionListener(this.manager);
this.manager.registerSelector$S$O(this.registryKey + "/COL", selector);
var n=0;
for (var i=0; i < columnNames.length; i++) {
table.getColumnModel$().getColumn$I(i).setPreferredWidth$I(columnWidths[i]);
n+=columnWidths[i];
}
table.setPreferredScrollableViewportSize$java_awt_Dimension(Clazz.new_($I$(5,1).c$$I$I,[n, height]));
return table;
}, p$1);

Clazz.newMeth(C$, 'getSelectedIndex$O',  function (c) {
return (c).getSelectedIndex$();
});

Clazz.newMeth(C$, 'getSelectedItem$O',  function (combo) {
return (combo).getSelectedItem$();
});

Clazz.newMeth(C$, 'getText$O',  function (o) {
return (Clazz.instanceOf(o, "javax.swing.text.JTextComponent") ? (o).getText$() : (o).getText$());
});

Clazz.newMeth(C$, 'isSelected$O',  function (chkbox) {
return (chkbox).isSelected$();
});

Clazz.newMeth(C$, 'selectTableRow$I',  function (i) {
this.selectedRow=i;
this.dataTable.clearSelection$();
this.tableModel.fireTableDataChanged$();
});

Clazz.newMeth(C$, 'setCellSelectionEnabled$Z',  function (enabled) {
this.dataTable.setCellSelectionEnabled$Z(enabled);
});

Clazz.newMeth(C$, 'setEnabled$O$Z',  function (btn, b) {
(btn).setEnabled$Z(b);
});

Clazz.newMeth(C$, 'setIntLocation$IA',  function (loc) {
var d=$I$(17).getDefaultToolkit$().getScreenSize$();
loc[0]=Math.min(d.width - 50, loc[0]);
loc[1]=Math.min(d.height - 50, loc[1]);
var pt=Clazz.new_($I$(18,1).c$$I$I,[loc[0], loc[1]]);
this.setLocation$java_awt_Point(pt);
});

Clazz.newMeth(C$, 'setPreferredSize$I$I',  function (width, height) {
this.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(5,1).c$$I$I,[width, height]));
});

Clazz.newMeth(C$, 'setSelected$O$Z',  function (chkbox, b) {
(chkbox).setSelected$Z(b);
});

Clazz.newMeth(C$, 'setSelectedIndex$O$I',  function (combo, i) {
(combo).setSelectedIndex$I(i);
});

Clazz.newMeth(C$, 'setText$O$S',  function (o, text) {
if (Clazz.instanceOf(o, "javax.swing.text.JTextComponent")) (o).setText$S(text);
 else (o).setText$S(text);
});

Clazz.newMeth(C$, 'startLayout$',  function () {
this.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(5,1).c$$I$I,[600, 370]));
this.getContentPane$().removeAll$();
this.thisPanel=this.rightPanel=Clazz.new_($I$(19,1));
switch (this.$type) {
case $I$(20).Integration:
case $I$(20).Measurements:
case $I$(20).PeakList:
case $I$(20).NONE:
break;
case $I$(20).OverlayLegend:
this.tableCellAlignLeft=true;
this.haveColors=true;
this.haveTwoPanels=false;
break;
case $I$(20).Views:
this.rightPanel=Clazz.new_([Clazz.new_($I$(21,1))],$I$(19,1).c$$java_awt_LayoutManager);
}
if (this.haveTwoPanels) {
this.thisPanel=this.leftPanel=Clazz.new_([Clazz.new_($I$(21,1))],$I$(19,1).c$$java_awt_LayoutManager);
this.leftPanel.setMinimumSize$java_awt_Dimension(Clazz.new_($I$(5,1).c$$I$I,[200, 300]));
this.mainSplitPane=Clazz.new_($I$(22,1).c$$I,[1]);
this.mainSplitPane.setOneTouchExpandable$Z(true);
this.mainSplitPane.setResizeWeight$D(0);
this.mainSplitPane.setLeftComponent$java_awt_Component(this.leftPanel);
this.mainSplitPane.setRightComponent$java_awt_Component(Clazz.new_($I$(11,1).c$$java_awt_Component,[this.rightPanel]));
}});
;
(function(){/*c*/var C$=Clazz.newClass(P$.AwtDialog, "ColorRenderer", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.JLabel', 'javax.swing.table.TableCellRenderer');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.setOpaque$Z(true);
}, 1);

Clazz.newMeth(C$, 'getTableCellRendererComponent$javax_swing_JTable$O$Z$Z$I$I',  function (table, color, isSelected, hasFocus, row, column) {
var border;
this.setBackground$java_awt_Color(color);
if (isSelected) {
border=$I$(1,"createMatteBorder$I$I$I$I$java_awt_Color",[2, 5, 2, 5, table.getSelectionBackground$()]);
this.setBorder$javax_swing_border_Border(border);
} else {
border=$I$(1,"createMatteBorder$I$I$I$I$java_awt_Color",[2, 5, 2, 5, table.getBackground$()]);
this.setBorder$javax_swing_border_Border(border);
}return this;
});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.AwtDialog, "TitleRenderer", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.JLabel', 'javax.swing.table.TableCellRenderer');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.setOpaque$Z(true);
}, 1);

Clazz.newMeth(C$, 'getTableCellRendererComponent$javax_swing_JTable$O$Z$Z$I$I',  function (table, title, isSelected, hasFocus, row, column) {
this.setHorizontalAlignment$I(this.b$['jspecview.java.AwtDialog'].getColumnCentering$I.apply(this.b$['jspecview.java.AwtDialog'], [column]));
this.setText$S(title.toString());
isSelected=(row == this.b$['jspecview.java.AwtDialog'].selectedRow);
this.setBackground$java_awt_Color(isSelected ? table.getSelectionBackground$() : table.getBackground$());
return this;
});
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:07 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
