(function(){var P$=Clazz.newPackage("jspecview.java"),p$1={},I$=[[0,'java.beans.PropertyChangeSupport','StringBuilder','javajs.util.PT','org.jmol.util.Logger','java.awt.datatransfer.DataFlavor','java.beans.PropertyChangeEvent']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FileDropperJmol", null, null, 'java.awt.dnd.DropTargetListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['fd_oldFileName'],'O',['fd_propSupport','java.beans.PropertyChangeSupport','pcl','java.beans.PropertyChangeListener']]]

Clazz.newMeth(C$, 'c$$org_jmol_api_PlatformViewer',  function (viewer) {
;C$.$init$.apply(this);
this.fd_oldFileName="";
this.fd_propSupport=Clazz.new_($I$(1,1).c$$O,[this]);
this.addPropertyChangeListener$java_beans_PropertyChangeListener((this.pcl=((P$.FileDropperJmol$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "FileDropperJmol$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.beans.PropertyChangeListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'propertyChange$java_beans_PropertyChangeEvent',  function (evt) {
this.b$['jspecview.java.FileDropperJmol'].doDrop$java_beans_PropertyChangeEvent.apply(this.b$['jspecview.java.FileDropperJmol'], [evt]);
});
})()
), Clazz.new_(P$.FileDropperJmol$1.$init$,[this, null]))));
}, 1);

Clazz.newMeth(C$, 'dispose$',  function () {
this.removePropertyChangeListener$java_beans_PropertyChangeListener(this.pcl);
});

Clazz.newMeth(C$, 'loadFile$S',  function (fname) {
fname=fname.replace$C$C("\\", "/").trim$();
if (fname.indexOf$S("://") < 0) fname=(fname.startsWith$S("/") ? "file://" : "file:///") + fname;
}, p$1);

Clazz.newMeth(C$, 'loadFiles$java_util_List',  function (fileList) {
var sb=Clazz.new_($I$(2,1));
for (var i=0; i < fileList.size$(); ++i) {
var f=fileList.get$I(i);
var fname=f.getAbsolutePath$();
fname=fname.replace$C$C("\\", "/").trim$();
fname=(fname.startsWith$S("/") ? "file://" : "file:///") + fname;
sb.append$S("load ").append$S(i == 0 ? "" : "APPEND ").append$S($I$(3).esc$S(fname)).append$S(";\n");
}
sb.append$S("frame *;reset;");
}, p$1);

Clazz.newMeth(C$, 'doDrop$java_beans_PropertyChangeEvent',  function (evt) {
if (evt.getPropertyName$() == "inline") {
}});

Clazz.newMeth(C$, 'addPropertyChangeListener$java_beans_PropertyChangeListener',  function (l) {
this.fd_propSupport.addPropertyChangeListener$java_beans_PropertyChangeListener(l);
});

Clazz.newMeth(C$, 'removePropertyChangeListener$java_beans_PropertyChangeListener',  function (l) {
this.fd_propSupport.removePropertyChangeListener$java_beans_PropertyChangeListener(l);
});

Clazz.newMeth(C$, 'dragOver$java_awt_dnd_DropTargetDragEvent',  function (dtde) {
if ($I$(4).debugging) $I$(4).debug$S("DropOver detected...");
});

Clazz.newMeth(C$, 'dragEnter$java_awt_dnd_DropTargetDragEvent',  function (dtde) {
if ($I$(4).debugging) $I$(4).debug$S("DropEnter detected...");
dtde.acceptDrag$I(3);
});

Clazz.newMeth(C$, 'dragExit$java_awt_dnd_DropTargetEvent',  function (dtde) {
if ($I$(4).debugging) $I$(4).debug$S("DropExit detected...");
});

Clazz.newMeth(C$, 'dropActionChanged$java_awt_dnd_DropTargetDragEvent',  function (dtde) {
});

Clazz.newMeth(C$, 'drop$java_awt_dnd_DropTargetDropEvent',  function (dtde) {
if ($I$(4).debugging) $I$(4).debug$S("Drop detected...");
var t=dtde.getTransferable$();
var isAccepted=false;
if (t.isDataFlavorSupported$java_awt_datatransfer_DataFlavor($I$(5).javaFileListFlavor)) {
while (true){
var o=null;
try {
dtde.acceptDrop$I(3);
o=t.getTransferData$java_awt_datatransfer_DataFlavor($I$(5).javaFileListFlavor);
isAccepted=true;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
$I$(4).error$S("transfer failed");
} else {
throw e;
}
}
if (Clazz.instanceOf(o, "java.util.List")) {
var fileList=o;
var length=fileList.size$();
if (length == 1) {
var fileName=fileList.get$I(0).getAbsolutePath$().trim$();
if (fileName.endsWith$S(".bmp")) break;
dtde.getDropTargetContext$().dropComplete$Z(true);
p$1.loadFile$S.apply(this, [fileName]);
return;
}dtde.getDropTargetContext$().dropComplete$Z(true);
p$1.loadFiles$java_util_List.apply(this, [fileList]);
return;
}break;
}
}if ($I$(4).debugging) $I$(4).debug$S("browsing supported flavours to find something useful...");
var df=t.getTransferDataFlavors$();
if (df == null  || df.length == 0 ) return;
for (var i=0; i < df.length; ++i) {
var flavor=df[i];
var o=null;
if (true) {
$I$(4).info$S("df " + i + " flavor " + flavor );
$I$(4,"info$S",["  class: " + flavor.getRepresentationClass$().getName$()]);
$I$(4,"info$S",["  mime : " + flavor.getMimeType$()]);
}if (flavor.getMimeType$().startsWith$S("text/uri-list") && flavor.getRepresentationClass$().getName$().equals$O("java.lang.String") ) {
try {
if (!isAccepted) dtde.acceptDrop$I(3);
isAccepted=true;
o=t.getTransferData$java_awt_datatransfer_DataFlavor(flavor);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
$I$(4).errorEx$S$Throwable(null, e);
} else {
throw e;
}
}
if (Clazz.instanceOf(o, "java.lang.String")) {
if ($I$(4).debugging) {
$I$(4,"debug$S",["  String: " + o.toString()]);
}p$1.loadFile$S.apply(this, [o.toString()]);
dtde.getDropTargetContext$().dropComplete$Z(true);
return;
}} else if (flavor.getMimeType$().equals$O("application/x-java-serialized-object; class=java.lang.String")) {
try {
if (!isAccepted) dtde.acceptDrop$I(3);
isAccepted=true;
o=t.getTransferData$java_awt_datatransfer_DataFlavor(df[i]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
$I$(4).errorEx$S$Throwable(null, e);
} else {
throw e;
}
}
if (Clazz.instanceOf(o, "java.lang.String")) {
var content=o;
if ($I$(4).debugging) {
$I$(4).debug$S("  String: " + content);
}if (content.startsWith$S("file:/")) {
p$1.loadFile$S.apply(this, [content]);
} else {
var pce=Clazz.new_($I$(6,1).c$$O$S$O$O,[this, "inline", this.fd_oldFileName, content]);
this.fd_propSupport.firePropertyChange$java_beans_PropertyChangeEvent(pce);
}dtde.getDropTargetContext$().dropComplete$Z(true);
return;
}}}
if (!isAccepted) dtde.rejectDrop$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:07 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
