(function(){var P$=Clazz.newPackage("jspecview.java"),I$=[[0,'javax.swing.JFileChooser','jspecview.java.AwtDialogFileFilter','jspecview.common.ExportType','java.io.File','jspecview.java.AwtFile','javax.swing.JOptionPane']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AwtFileHelper", null, null, 'jspecview.api.JSVFileHelper');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['useDirLastOpened','useDirLastExported'],'S',['dirLastOpened','dirLastExported'],'O',['fc','javax.swing.JFileChooser','vwr','jspecview.common.JSViewer']]]

Clazz.newMeth(C$, 'set$jspecview_common_JSViewer',  function (viewer) {
this.vwr=viewer;
return this;
});

Clazz.newMeth(C$, 'setFileChooser$jspecview_common_ExportType',  function (imode) {
if (this.fc == null ) this.fc=Clazz.new_($I$(1,1));
var filter=Clazz.new_($I$(2,1));
this.fc.resetChoosableFileFilters$();
switch (imode) {
case $I$(3).UNK:
filter=Clazz.new_($I$(2,1));
filter.addExtension$S("xml");
filter.addExtension$S("aml");
filter.addExtension$S("cml");
filter.setDescription$S("CML/XML Files");
this.fc.setFileFilter$javax_swing_filechooser_FileFilter(filter);
filter=Clazz.new_($I$(2,1));
filter.addExtension$S("jdx");
filter.addExtension$S("dx");
filter.setDescription$S("JCAMP-DX Files");
this.fc.setFileFilter$javax_swing_filechooser_FileFilter(filter);
break;
case $I$(3).XY:
case $I$(3).FIX:
case $I$(3).PAC:
case $I$(3).SQZ:
case $I$(3).DIF:
case $I$(3).DIFDUP:
case $I$(3).SOURCE:
filter.addExtension$S("jdx");
filter.addExtension$S("dx");
filter.setDescription$S("JCAMP-DX Files");
break;
default:
filter.addExtension$S(imode.toString().toLowerCase$());
filter.setDescription$S(imode + " Files");
}
this.fc.setFileFilter$javax_swing_filechooser_FileFilter(filter);
});

Clazz.newMeth(C$, 'showFileOpenDialog$O$OA',  function (panelOrFrame, userData) {
this.setFileChooser$jspecview_common_ExportType($I$(3).UNK);
return this.getFile$S$O$Z("", panelOrFrame, false);
});

Clazz.newMeth(C$, 'getFile$S$O$Z',  function (name, panelOrFrame, isSave) {
var c=panelOrFrame;
this.fc.setSelectedFile$java_io_File(Clazz.new_($I$(4,1).c$$S,[name]));
if (isSave) {
this.fc.setFileSelectionMode$I(0);
if (this.useDirLastExported) this.fc.setCurrentDirectory$java_io_File(Clazz.new_($I$(4,1).c$$S,[this.dirLastExported]));
} else {
this.fc.setFileSelectionMode$I(2);
if (this.useDirLastOpened) this.fc.setCurrentDirectory$java_io_File(Clazz.new_($I$(4,1).c$$S,[this.dirLastOpened]));
}var returnVal=(isSave ? this.fc.showSaveDialog$java_awt_Component(c) : this.fc.showOpenDialog$java_awt_Component(c));
if (returnVal != 0) return null;
var file=Clazz.new_([this.fc.getSelectedFile$().getAbsolutePath$()],$I$(5,1).c$$S);
if (isSave) {
this.vwr.setProperty$S$S("directoryLastExportedFile", this.dirLastExported=file.getParent$());
if (file.exists$()) {
var option=$I$(6,"showConfirmDialog$java_awt_Component$O$S$I$I",[c, "Overwrite " + file.getName$() + "?" , "Confirm Overwrite Existing File", 0, 3]);
if (option == 1) return null;
}} else {
this.vwr.setProperty$S$S("directoryLastOpenedFile", this.dirLastOpened=file.getParent$());
}return file;
});

Clazz.newMeth(C$, 'setDirLastExported$S',  function (name) {
return this.dirLastExported=name;
});

Clazz.newMeth(C$, 'getUrlFromDialog$S$S',  function (info, msg) {
return $I$(6).showInputDialog$java_awt_Component$O$S$I$javax_swing_Icon$OA$O(null, info, "Open URL", -1, null, null, msg);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:29 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
