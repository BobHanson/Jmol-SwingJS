(function(){var P$=Clazz.newPackage("jspecview.js2d"),I$=[[0,'javajs.util.PT','jspecview.js2d.JsFile']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JsFileHelper", null, null, 'jspecview.api.JSVFileHelper');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['vwr','jspecview.common.JSViewer']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'set$jspecview_common_JSViewer',  function (viewer) {
this.vwr=viewer;
return this;
});

Clazz.newMeth(C$, 'getFile$S$O$Z',  function (fileName, panelOrFrame, isSave) {
var f=null;
fileName=$I$(1,"rep$S$S$S",[fileName, "=", "_"]);
{
f = prompt("Enter a file name:", fileName);
}
return (f == null  ? null : Clazz.new_($I$(2,1).c$$S,[f]));
});

Clazz.newMeth(C$, 'setDirLastExported$S',  function (name) {
return name;
});

Clazz.newMeth(C$, 'setFileChooser$jspecview_common_ExportType',  function (pdf) {
});

Clazz.newMeth(C$, 'showFileOpenDialog$O$OA',  function (panelOrFrame, userData) {
var applet=this.vwr.html5Applet;
{
Jmol.loadFileAsynchronously(this, applet, "?", userData);
}
return null;
});

Clazz.newMeth(C$, 'setData$S$O$OA',  function (fileName, data, userInfo) {
if (fileName == null ) return;
if (data == null ) {
this.vwr.selectedPanel.showMessage$S$S(fileName, "File Open Error");
return;
}var script=(userInfo == null  ? null : "");
var isAppend=false;
{
isAppend = userInfo[0];
script = userInfo[1];
}
this.vwr.si.siOpenDataOrFile$O$S$javajs_util_Lst$S$I$I$Z$S$S( String.instantialize(data), "cache://" + fileName, null, null, -1, -1, isAppend, null, null);
if (script != null ) this.vwr.runScript$S(script);
});

Clazz.newMeth(C$, 'getUrlFromDialog$S$S',  function (info, msg) {
{
return prompt(info, msg);
}
});
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:29 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
