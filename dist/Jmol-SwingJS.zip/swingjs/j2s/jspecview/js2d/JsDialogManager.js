(function(){var P$=Clazz.newPackage("jspecview.js2d"),I$=[[0,'jspecview.js2d.JsDialog','org.jmol.awtjs.swing.JDialog','jspecview.js2d.DialogTableModel','org.jmol.awtjs.swing.JTable','org.jmol.awtjs.swing.Dimension','org.jmol.awtjs.swing.JScrollPane','org.jmol.awtjs.swing.JLabel','org.jmol.awtjs.swing.JEditorPane','javajs.util.PT']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JsDialogManager", null, 'jspecview.dialog.DialogManager');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'getDialog$jspecview_dialog_JSVDialog',  function (jsvDialog) {
return Clazz.new_([this, jsvDialog, this.registerDialog$jspecview_dialog_JSVDialog(jsvDialog)],$I$(1,1).c$$jspecview_dialog_DialogManager$jspecview_dialog_JSVDialog$S);
});

Clazz.newMeth(C$, 'getDialogInput$O$S$S$I$O$OA$S',  function (parentComponent, phrase, title, msgType, icon, objects, defaultStr) {
{
return prompt(phrase, defaultStr);
}
});

Clazz.newMeth(C$, 'showMessageDialog$O$S$S$I',  function (parentComponent, msg, title, msgType) {
{
alert(msg);
}
});

Clazz.newMeth(C$, 'getLocationOnScreen$O',  function (component) {
return Clazz.array(Integer.TYPE, [2]);
});

Clazz.newMeth(C$, 'getOptionFromDialog$O$SA$jspecview_api_JSVPanel$S$S',  function (frame, items, jsvp, dialogName, labelName) {
return this.vwr.html5Applet.getOption(items, dialogName, labelName);
});

Clazz.newMeth(C$, 'showProperties$O$jspecview_common_Spectrum',  function (frame, spectrum) {
var dialog=Clazz.new_($I$(2,1));
dialog.setTitle$S("Header Information");
var rowData=spectrum.getHeaderRowDataAsArray$();
var columnNames=Clazz.array(String, -1, ["Label", "Description"]);
var tableModel=Clazz.new_($I$(3,1).c$$SA$OAA$Z$Z,[columnNames, rowData, false, true]);
var table=Clazz.new_($I$(4,1).c$$org_jmol_awtjs_swing_AbstractTableModel,[tableModel]);
table.setPreferredScrollableViewportSize$org_jmol_awtjs_swing_Dimension(Clazz.new_($I$(5,1).c$$I$I,[400, 195]));
var scrollPane=Clazz.new_($I$(6,1).c$$org_jmol_awtjs_swing_JComponent,[table]);
dialog.getContentPane$().add$org_jmol_awtjs_swing_Component(scrollPane);
dialog.pack$();
dialog.setVisible$Z(true);
dialog.toFront$();
});

Clazz.newMeth(C$, 'showMessage$O$S$S',  function (frame, text, title) {
var dialog=Clazz.new_($I$(2,1));
{
dialog.manager = this;
}
dialog.setTitle$S(title);
var pane;
if (text.indexOf$S("</div>") >= 0) {
pane=Clazz.new_($I$(7,1).c$$S,[text]);
} else {
pane=Clazz.new_($I$(8,1));
pane.setText$S(text);
}dialog.getContentPane$().add$org_jmol_awtjs_swing_Component(pane);
dialog.pack$();
dialog.setVisible$Z(true);
dialog.toFront$();
});

Clazz.newMeth(C$, 'actionPerformed$S',  function (eventId) {
var pt=eventId.indexOf$S("/JT");
if (pt >= 0) {
var pt2=eventId.lastIndexOf$S("_");
var pt1=eventId.lastIndexOf$S$I("_", pt2 - 1);
var irow=$I$(9,"parseInt$S",[eventId.substring$I$I(pt1 + 1, pt2)]);
var icol=$I$(9,"parseInt$S",[eventId.substring$I(pt2 + 1)]);
this.processTableEvent$S$I$I$Z(eventId.substring$I$I(0, pt) + "/ROWCOL", irow, icol, false);
return;
}this.processClick$S(eventId);
});
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:07 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
