(function(){var P$=Clazz.newPackage("jspecview.js2d"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Image");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getWidth$O',  function (canvas) {
{
return (canvas.imageWidth ? canvas.imageWidth : canvas.width);
}
}, 1);

Clazz.newMeth(C$, 'getHeight$O',  function (canvas) {
{
return (canvas.imageHeight ? canvas.imageHeight : canvas.height);
}
}, 1);

Clazz.newMeth(C$, 'grabPixels$O$I$I',  function (context, width, height) {
var data=null;
{
if (context._buf32) return context._buf32; // non-canvas internal buffer for image writing
data = context.getImageData(0, 0, width, height).data;
}
return C$.toIntARGB$IA(data);
}, 1);

Clazz.newMeth(C$, 'toIntARGB$IA',  function (imgData) {
var n=(imgData.length/4|0);
var iData=Clazz.array(Integer.TYPE, [n]);
for (var i=0, j=0; i < n; j++) {
iData[i++]=(imgData[j++] << 16) | (imgData[j++] << 8) | imgData[j++] | -16777216 ;
}
return iData;
}, 1);

Clazz.newMeth(C$, 'fromIntARGB$IA$IA',  function (buf32, buf8) {
var n=buf8.length >> 2;
for (var i=0, j=0; i < n; i++) {
buf8[j++]=(buf32[i] >> 16) & 255;
buf8[j++]=(buf32[i] >> 8) & 255;
buf8[j++]=buf32[i] & 255;
buf8[j++]=255;
}
}, 1);

Clazz.newMeth(C$, 'getTextPixels$S$org_jmol_util_Font$O$I$I$I',  function (text, font3d, context, width, height, ascent) {
{
context.fillStyle = "#000000";
context.fillRect(0, 0, width, height);
context.fillStyle = "#FFFFFF";
context.font = font3d.font;
context.fillText(text, 0, ascent);
}
return C$.grabPixels$O$I$I(context, width, height);
}, 1);

Clazz.newMeth(C$, 'allocateRgbImage$I$I$IA$I$Z$O',  function (windowWidth, windowHeight, pBuffer, windowSize, backgroundTransparent, canvas) {
{
if (canvas == null) canvas = {width:windowWidth,height:windowHeight};
canvas.buf32 = pBuffer;
}
}, 1);

Clazz.newMeth(C$, 'getStaticGraphics$O$Z',  function (canvas, backgroundTransparent) {
return C$.getGraphics$O(canvas);
}, 1);

Clazz.newMeth(C$, 'getGraphics$O',  function (canvas) {
{
return canvas.getContext("2d");
}
}, 1);

Clazz.newMeth(C$, 'drawImage$O$O$I$I$I$I',  function (context, canvas, x, y, width, height) {
{
this.fromIntARGB(canvas.buf32, canvas.buf8);
context.putImageData(canvas.imgdata,x,y);
}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-04 15:08:07 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
