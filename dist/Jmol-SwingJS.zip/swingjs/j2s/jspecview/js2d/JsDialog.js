(function(){var P$=Clazz.newPackage("jspecview.js2d"),p$1={},I$=[[0,'org.jmol.awtjs.swing.Insets','java.util.Hashtable','org.jmol.awtjs.swing.Color','org.jmol.awtjs.swing.JButton','org.jmol.awtjs.swing.Dimension','org.jmol.awtjs.swing.GridBagConstraints','org.jmol.awtjs.swing.JCheckBox','org.jmol.awtjs.swing.JLabel','org.jmol.awtjs.swing.JComboBox','org.jmol.awtjs.swing.JTextField','org.jmol.awtjs.swing.JScrollPane','jspecview.js2d.DialogTableModel','org.jmol.awtjs.swing.JTable','org.jmol.awtjs.swing.JPanel','org.jmol.awtjs.swing.FlowLayout',['jspecview.common.Annotation','.AType'],'org.jmol.awtjs.swing.GridBagLayout','org.jmol.awtjs.swing.JSplitPane']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JsDialog", null, 'org.jmol.awtjs.swing.JDialog', 'jspecview.api.PlatformDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.haveTwoPanels=true;
this.buttonInsets=Clazz.new_($I$(1,1).c$$I$I$I$I,[5, 5, 5, 5]);
this.panelInsets=Clazz.new_($I$(1,1).c$$I$I$I$I,[0, 0, 2, 2]);
this.selectedRow=-1;
},1);

C$.$fields$=[['Z',['haveColors','tableCellAlignLeft','haveTwoPanels'],'I',['iRow','selectedRow'],'S',['optionKey','registryKey'],'O',['options','java.util.Map','manager','jspecview.dialog.DialogManager','type','jspecview.common.Annotation.AType','leftPanel','org.jmol.awtjs.swing.JPanel','mainSplitPane','org.jmol.awtjs.swing.JSplitPane','rightPanel','org.jmol.awtjs.swing.JPanel','+thisPanel','dataTable','org.jmol.awtjs.swing.JTable','buttonInsets','org.jmol.awtjs.swing.Insets','+panelInsets']]]

Clazz.newMeth(C$, 'c$$jspecview_dialog_DialogManager$jspecview_dialog_JSVDialog$S',  function (manager, jsvDialog, registryKey) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
this.defaultHeight=350;
this.manager=manager;
this.registryKey=registryKey;
this.optionKey=jsvDialog.optionKey;
this.type=jsvDialog.getAType$();
this.options=jsvDialog.options;
if (this.options == null ) this.options=Clazz.new_($I$(2,1));
this.getContentPane$().setBackground$javajs_api_GenericColor($I$(3).get3$I$I$I(230, 230, 230));
this.toFront$();
}, 1);

Clazz.newMeth(C$, 'onFocus$',  function () {
this.toFront$();
});

Clazz.newMeth(C$, 'setFocus$Z',  function (tf) {
if (tf) {
this.toFront$();
}});

Clazz.newMeth(C$, 'addButton$S$S',  function (name, text) {
var btn=Clazz.new_($I$(4,1));
btn.setPreferredSize$org_jmol_awtjs_swing_Dimension(Clazz.new_($I$(5,1).c$$I$I,[120, 25]));
btn.setText$S(text);
btn.setName$S(this.registryKey + "/" + name );
btn.addActionListener$O(this.manager);
this.thisPanel.add$org_jmol_awtjs_swing_JComponent$O(btn, Clazz.new_($I$(6,1).c$$I$I$I$I$D$D$I$I$org_jmol_awtjs_swing_Insets$I$I,[0, this.iRow++, 3, 1, 0.0, 0.0, 10, 0, this.buttonInsets, 0, 0]));
return btn;
});

Clazz.newMeth(C$, 'dispose$',  function () {
C$.superclazz.prototype.dispose$.apply(this, []);
});

Clazz.newMeth(C$, 'addCheckBox$S$S$I$Z',  function (name, title, level, isSelected) {
if (name == null ) {
this.iRow=0;
this.thisPanel=this.rightPanel;
return null;
}var cb=Clazz.new_($I$(7,1));
cb.setSelected$Z(isSelected);
cb.setText$S(title);
cb.setName$S(this.registryKey + "/" + name );
cb.addActionListener$O(this.manager);
var insets=Clazz.new_($I$(1,1).c$$I$I$I$I,[0, 20 * level, 2, 2]);
this.thisPanel.add$org_jmol_awtjs_swing_JComponent$O(cb, Clazz.new_($I$(6,1).c$$I$I$I$I$D$D$I$I$org_jmol_awtjs_swing_Insets$I$I,[0, this.iRow++, 1, 1, 0.0, 0.0, 17, 0, insets, 0, 0]));
return cb;
});

Clazz.newMeth(C$, 'addPanelLine$S$S$org_jmol_awtjs_swing_JComponent$S',  function (name, label, obj, units) {
this.thisPanel.add$org_jmol_awtjs_swing_JComponent$O(Clazz.new_([label == null  ? name : label],$I$(8,1).c$$S), Clazz.new_($I$(6,1).c$$I$I$I$I$D$D$I$I$org_jmol_awtjs_swing_Insets$I$I,[0, this.iRow, 1, 1, 0.0, 0.0, 13, 0, this.panelInsets, 0, 0]));
if (units == null ) {
this.thisPanel.add$org_jmol_awtjs_swing_JComponent$O(obj, Clazz.new_($I$(6,1).c$$I$I$I$I$D$D$I$I$org_jmol_awtjs_swing_Insets$I$I,[1, this.iRow, 2, 1, 0.0, 0.0, 17, 0, this.panelInsets, 0, 0]));
} else {
this.thisPanel.add$org_jmol_awtjs_swing_JComponent$O(obj, Clazz.new_($I$(6,1).c$$I$I$I$I$D$D$I$I$org_jmol_awtjs_swing_Insets$I$I,[1, this.iRow, 1, 1, 0.0, 0.0, 10, 0, this.panelInsets, 0, 0]));
this.thisPanel.add$org_jmol_awtjs_swing_JComponent$O(Clazz.new_($I$(8,1).c$$S,[units]), Clazz.new_($I$(6,1).c$$I$I$I$I$D$D$I$I$org_jmol_awtjs_swing_Insets$I$I,[2, this.iRow, 1, 1, 0.0, 0.0, 17, 0, this.panelInsets, 0, 0]));
}++this.iRow;
}, p$1);

Clazz.newMeth(C$, 'addSelectOption$S$S$SA$I$Z',  function (name, label, info, iPt, visible) {
var combo=Clazz.new_($I$(9,1).c$$SA,[info]);
combo.setSelectedIndex$I(iPt);
combo.setName$S(this.registryKey + "/" + name );
if (visible) {
combo.addActionListener$O(this.manager);
p$1.addPanelLine$S$S$org_jmol_awtjs_swing_JComponent$S.apply(this, [name, label, combo, null]);
}return combo;
});

Clazz.newMeth(C$, 'addTextField$S$S$S$S$S$Z',  function (name, label, value, units, defaultValue, visible) {
var key=this.optionKey + "_" + name ;
if (value == null ) {
value=this.options.get$O(key);
if (value == null ) this.options.put$O$O(key, (value=defaultValue));
}var obj=Clazz.new_($I$(10,1).c$$S,[value]);
obj.setName$S(this.registryKey + "/" + name );
if (visible) {
obj.setPreferredSize$org_jmol_awtjs_swing_Dimension(Clazz.new_($I$(5,1).c$$I$I,[45, 15]));
obj.addActionListener$O(this.manager);
p$1.addPanelLine$S$S$org_jmol_awtjs_swing_JComponent$S.apply(this, [name, label, obj, units]);
}return obj;
});

Clazz.newMeth(C$, 'createTable$OAA$SA$IA',  function (data, header, widths) {
try {
var scrollPane=Clazz.new_([this.dataTable=p$1.getDataTable$OAA$SA$IA$I.apply(this, [data, header, widths, (this.leftPanel == null  ? this.defaultHeight : this.leftPanel.getHeight$() - 50)])],$I$(11,1).c$$org_jmol_awtjs_swing_JComponent);
if (this.mainSplitPane == null ) {
this.getContentPane$().add$org_jmol_awtjs_swing_Component(scrollPane);
} else {
this.mainSplitPane.setRightComponent$org_jmol_awtjs_swing_JComponent(scrollPane);
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
this.validate$();
this.repaint$();
});

Clazz.newMeth(C$, 'endLayout$',  function () {
this.getContentPane$().removeAll$();
this.getContentPane$().add$org_jmol_awtjs_swing_Component(this.mainSplitPane);
this.pack$();
});

Clazz.newMeth(C$, 'getDataTable$OAA$SA$IA$I',  function (data, columnNames, columnWidths, height) {
this.selectedRow=-1;
var tableModel=Clazz.new_($I$(12,1).c$$SA$OAA$Z$Z,[columnNames, data, !this.haveColors, this.tableCellAlignLeft]);
var table=Clazz.new_($I$(13,1).c$$org_jmol_awtjs_swing_AbstractTableModel,[tableModel]);
var selector=table.getSelectionModel$();
selector.addListSelectionListener$O(this.manager);
this.manager.registerSelector$S$O(this.registryKey + "/ROW", selector);
selector=table.getColumnModel$().getSelectionModel$();
selector.addListSelectionListener$O(this.manager);
this.manager.registerSelector$S$O(this.registryKey + "/COLUMN", selector);
var n=0;
for (var i=0; i < columnNames.length; i++) {
table.getColumnModel$().getColumn$I(i).setPreferredWidth$I(columnWidths[i]);
n+=columnWidths[i];
}
return table;
}, p$1);

Clazz.newMeth(C$, 'getSelectedIndex$O',  function (c) {
return (c).getSelectedIndex$();
});

Clazz.newMeth(C$, 'getSelectedItem$O',  function (combo) {
return (combo).getSelectedItem$();
});

Clazz.newMeth(C$, 'getText$O',  function (o) {
return (o).getText$();
});

Clazz.newMeth(C$, 'isSelected$O',  function (chkbox) {
return (chkbox).isSelected$();
});

Clazz.newMeth(C$, 'selectTableRow$I',  function (i) {
this.selectedRow=i;
this.dataTable.clearSelection$();
if (this.selectedRow >= 0) {
this.dataTable.setRowSelectionAllowed$Z(true);
this.dataTable.setRowSelectionInterval$I$I(this.selectedRow, this.selectedRow + 1);
this.repaint$();
}});

Clazz.newMeth(C$, 'setCellSelectionEnabled$Z',  function (enabled) {
this.dataTable.setCellSelectionEnabled$Z(enabled);
});

Clazz.newMeth(C$, 'setEnabled$O$Z',  function (btn, b) {
(btn).setEnabled$Z(b);
});

Clazz.newMeth(C$, 'setIntLocation$IA',  function (loc) {
var d=Clazz.new_($I$(5,1).c$$I$I,[0, 0]);
{
SwingController.getScreenDimensions(d);
}
loc[0]=Math.min(d.width - 50, loc[0]);
loc[1]=Math.min(d.height - 50, loc[1]);
this.setLocation$IA(loc);
});

Clazz.newMeth(C$, 'setPreferredSize$I$I',  function (width, height) {
this.setPreferredSize$org_jmol_awtjs_swing_Dimension(Clazz.new_($I$(5,1).c$$I$I,[width, height]));
});

Clazz.newMeth(C$, 'setSelected$O$Z',  function (chkbox, b) {
(chkbox).setSelected$Z(b);
});

Clazz.newMeth(C$, 'setSelectedIndex$O$I',  function (combo, i) {
(combo).setSelectedIndex$I(i);
});

Clazz.newMeth(C$, 'setText$O$S',  function (o, text) {
(o).setText$S(text);
});

Clazz.newMeth(C$, 'startLayout$',  function () {
this.setPreferredSize$org_jmol_awtjs_swing_Dimension(Clazz.new_($I$(5,1).c$$I$I,[600, 370]));
this.getContentPane$().removeAll$();
this.thisPanel=this.rightPanel=Clazz.new_([Clazz.new_($I$(15,1))],$I$(14,1).c$$org_jmol_awtjs_swing_LayoutManager);
switch (this.type) {
case $I$(16).Integration:
case $I$(16).Measurements:
case $I$(16).PeakList:
case $I$(16).NONE:
break;
case $I$(16).OverlayLegend:
this.tableCellAlignLeft=true;
this.haveColors=true;
this.haveTwoPanels=false;
break;
case $I$(16).Views:
this.rightPanel=Clazz.new_([Clazz.new_($I$(17,1))],$I$(14,1).c$$org_jmol_awtjs_swing_LayoutManager);
}
if (this.haveTwoPanels) {
this.thisPanel=this.leftPanel=Clazz.new_([Clazz.new_($I$(17,1))],$I$(14,1).c$$org_jmol_awtjs_swing_LayoutManager);
this.leftPanel.setMinimumSize$org_jmol_awtjs_swing_Dimension(Clazz.new_($I$(5,1).c$$I$I,[200, 300]));
this.mainSplitPane=Clazz.new_($I$(18,1).c$$I,[1]);
this.mainSplitPane.setLeftComponent$org_jmol_awtjs_swing_JComponent(this.leftPanel);
this.mainSplitPane.setRightComponent$org_jmol_awtjs_swing_JComponent(Clazz.new_($I$(11,1).c$$org_jmol_awtjs_swing_JComponent,[this.rightPanel]));
}});

Clazz.newMeth(C$, 'getColumnCentering$I',  function (column) {
return this.tableCellAlignLeft ? 2 : column == 0 ? 0 : 4;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:29 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
