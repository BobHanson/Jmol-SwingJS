(function(){var P$=Clazz.newPackage("jspecview.js2d"),I$=[[0,'org.jmol.awtjs.swing.Color']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JsParameters", null, 'jspecview.common.ColorParameters');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'isValidFontName$S',  function (name) {
return true;
});

Clazz.newMeth(C$, 'getColor1$I',  function (rgb) {
return $I$(1).get1$I(rgb);
});

Clazz.newMeth(C$, 'getColor3$I$I$I',  function (r, g, b) {
return $I$(1).get3$I$I$I(r, g, b);
});

Clazz.newMeth(C$, 'copy$S',  function (newName) {
return (Clazz.new_(C$).setName$S(newName)).setElementColors$jspecview_common_ColorParameters(this);
});
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:53 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
