(function(){var P$=Clazz.newPackage("jspecview.js2d"),p$1={},I$=[[0,'javajs.util.CU']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DialogTableModel", null, null, 'org.jmol.awtjs.swing.AbstractTableModel');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['asString','tableCellAlignLeft'],'I',['thisCol'],'O',['columnNames','String[]','data','Object[][]','widths','int[]']]]

Clazz.newMeth(C$, 'c$$SA$OAA$Z$Z',  function (columnNames, data, asString, tableCellAlignLeft) {
;C$.$init$.apply(this);
this.columnNames=columnNames;
this.data=data;
this.asString=asString;
this.widths=(data.length == 0 ? Clazz.array(Integer.TYPE, [0]) : Clazz.array(Integer.TYPE, [data[0].length]));
this.tableCellAlignLeft=tableCellAlignLeft;
}, 1);

Clazz.newMeth(C$, 'getColumnCount$',  function () {
return this.columnNames.length;
});

Clazz.newMeth(C$, 'getRowCount$',  function () {
return this.data.length;
});

Clazz.newMeth(C$, 'getColumnName$I',  function (col) {
return this.columnNames[col];
});

Clazz.newMeth(C$, 'getValueAt$I$I',  function (row, col) {
var o=this.data[row][col];
return (this.asString ? " " + o + " "  : o);
});

Clazz.newMeth(C$, 'getColumn$I',  function (i) {
this.thisCol=i;
return this;
});

Clazz.newMeth(C$, 'setPreferredWidth$I',  function (n) {
this.widths[this.thisCol]=n;
});

Clazz.newMeth(C$, 'toHTML$javajs_util_SB$S$javajs_util_BS',  function (sb, id, selectedRows) {
if (this.data == null  || this.data[0] == null   || this.data[0].length == 0 ) return;
var nrows=this.data.length;
var ncols=this.columnNames.length;
for (var i=-1; i < nrows; i++) {
var rowid=id + "_" + i ;
sb.append$S("\n<tr id='" + rowid + "' class='JTable_" + (i == -1 ? "header" : "row") + "' style='height:25px'>" );
for (var j=0; j < ncols; j++) {
if (i == -1) p$1.getCellHtml$javajs_util_SB$S$I$I$O$Z.apply(this, [sb, id + "_h" + j , i, j, this.columnNames[j], false]);
 else p$1.getCellHtml$javajs_util_SB$S$I$I$O$Z.apply(this, [sb, rowid + "_" + j , i, j, this.data[i][j], selectedRows.get$I(i)]);
}
sb.append$S("</tr>");
}
});

Clazz.newMeth(C$, 'getCellHtml$javajs_util_SB$S$I$I$O$Z',  function (sb, id, iRow, iCol, o, isSelected) {
var style=p$1.getCellStyle$S$I$I$O$Z.apply(this, [id, iRow, iCol, o, isSelected]);
sb.append$S("<td id='" + id + "'" + style + " onclick=SwingController.click(this)>" + o + "</td>" );
}, p$1);

Clazz.newMeth(C$, 'getCellStyle$S$I$I$O$Z',  function (id, iRow, iCol, o, isSelected) {
var style="padding:1px 1px 1px 1px";
if (iRow < 0) {
style+=";font-weight:bold";
} else {
if (Clazz.instanceOf(o, "javajs.api.GenericColor")) {
style+=";background-color:" + $I$(1).toCSSString$javajs_api_GenericColor(o);
} else {
if (this.asString) o=" " + o + " " ;
style+=";text-align:";
if (this.tableCellAlignLeft) style+="left";
 else if (iCol == 0) style+="center";
 else style+="right";
style+=";border:" + (isSelected ? 3 : 1) + "px solid #000" ;
}}return " style='" + style + "'" ;
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:29 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
