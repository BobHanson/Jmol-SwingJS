(function(){var P$=Clazz.newPackage("jspecview.js2d"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Display");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getFullScreenDimensions$O$IA',  function (canvas, widthHeight) {
{
widthHeight[0] = canvas.width;
widthHeight[1] = canvas.height;
}
}, 1);

Clazz.newMeth(C$, 'hasFocus$O',  function (canvas) {
return true;
}, 1);

Clazz.newMeth(C$, 'requestFocusInWindow$O',  function (canvas) {
}, 1);

Clazz.newMeth(C$, 'repaint$O',  function (canvas) {
}, 1);

Clazz.newMeth(C$, 'renderScreenImage$org_jmol_api_PlatformViewer$O$O',  function (viewer, g, size) {
{

}
}, 1);

Clazz.newMeth(C$, 'setTransparentCursor$O',  function (canvas) {
}, 1);

Clazz.newMeth(C$, 'setCursor$I$O',  function (c, canvas) {
}, 1);

Clazz.newMeth(C$, 'prompt$S$S$SA$Z',  function (label, data, list, asButtons) {
{
var s = prompt(label, data);
if (s != null)return s;
}
return "null";
}, 1);

Clazz.newMeth(C$, 'convertPointFromScreen$O$javajs_util_P3d',  function (canvas, ptTemp) {
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-24 19:46:53 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
