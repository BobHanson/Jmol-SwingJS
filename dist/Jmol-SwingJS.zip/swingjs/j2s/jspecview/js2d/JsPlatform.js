(function(){var P$=Clazz.newPackage("jspecview.js2d"),I$=[[0,'jspecview.app.GenericMouse','jspecview.js2d.Display','jspecview.js2d.Image','jspecview.js2d.JsFont','jspecview.js2d.JsFile','javajs.util.Rdr']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JsPlatform", null, null, 'org.jmol.api.GenericPlatform');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['canvas','java.lang.Object','viewer','org.jmol.api.PlatformViewer','context','java.lang.Object']]]

Clazz.newMeth(C$, 'isJS$',  function () {
return true;
});

Clazz.newMeth(C$, 'setViewer$org_jmol_api_PlatformViewer$O',  function (viewer, canvas) {
var context="";
this.viewer=viewer;
this.canvas=canvas;
{
if (canvas != null) { context = canvas.getContext("2d");
canvas.imgdata = context.getImageData(0, 0, canvas.width, canvas.height);
canvas.buf8 = canvas.imgdata.data;
}
}
if (context !== "" ) this.context=context;
});

Clazz.newMeth(C$, 'isSingleThreaded$',  function () {
return true;
});

Clazz.newMeth(C$, 'getJsObjectInfo$OA$S$OA',  function (jsObject, method, args) {
{
return (method == null ? null : method == "localName" ? jsObject[0]["nodeName"] : args == null ? jsObject[0][method] : jsObject[0][method](args[0]));
}
});

Clazz.newMeth(C$, 'isHeadless$',  function () {
return false;
});

Clazz.newMeth(C$, 'getMouseManager$D$O',  function (privateKey, jsvp) {
return Clazz.new_($I$(1,1).c$$jspecview_api_JSVPanel,[jsvp]);
});

Clazz.newMeth(C$, 'convertPointFromScreen$O$javajs_util_P3d',  function (canvas, ptTemp) {
$I$(2).convertPointFromScreen$O$javajs_util_P3d(canvas, ptTemp);
});

Clazz.newMeth(C$, 'getFullScreenDimensions$O$IA',  function (canvas, widthHeight) {
$I$(2).getFullScreenDimensions$O$IA(canvas, widthHeight);
});

Clazz.newMeth(C$, 'getMenuPopup$S$C',  function (menuStructure, type) {
return null;
});

Clazz.newMeth(C$, 'hasFocus$O',  function (canvas) {
return $I$(2).hasFocus$O(canvas);
});

Clazz.newMeth(C$, 'prompt$S$S$SA$Z',  function (label, data, list, asButtons) {
return $I$(2).prompt$S$S$SA$Z(label, data, list, asButtons);
});

Clazz.newMeth(C$, 'drawImage$O$O$I$I$I$I$Z',  function (context, canvas, x, y, width, height, isDTI) {
$I$(3).drawImage$O$O$I$I$I$I(context, canvas, x, y, width, height);
});

Clazz.newMeth(C$, 'requestFocusInWindow$O',  function (canvas) {
$I$(2).requestFocusInWindow$O(canvas);
});

Clazz.newMeth(C$, 'repaint$O',  function (canvas) {
$I$(2).repaint$O(canvas);
});

Clazz.newMeth(C$, 'setTransparentCursor$O',  function (canvas) {
$I$(2).setTransparentCursor$O(canvas);
});

Clazz.newMeth(C$, 'setCursor$I$O',  function (c, canvas) {
$I$(2).setCursor$I$O(c, canvas);
});

Clazz.newMeth(C$, 'allocateRgbImage$I$I$IA$I$Z$Z',  function (windowWidth, windowHeight, pBuffer, windowSize, backgroundTransparent, isImageWrite) {
return $I$(3,"allocateRgbImage$I$I$IA$I$Z$O",[windowWidth, windowHeight, pBuffer, windowSize, backgroundTransparent, (isImageWrite ? null : this.canvas)]);
});

Clazz.newMeth(C$, 'notifyEndOfRendering$',  function () {
});

Clazz.newMeth(C$, 'createImage$O',  function (data) {
return null;
});

Clazz.newMeth(C$, 'disposeGraphics$O',  function (gOffscreen) {
});

Clazz.newMeth(C$, 'grabPixels$O$I$I$IA',  function (canvas, width, height, pixels) {
{
if (canvas.image && (width != canvas.width || height != canvas.height)) Jmol.setCanvasImage(canvas, width, height);
if (canvas.buf32) return canvas.buf32;
}
var buf=$I$(3,"grabPixels$O$I$I",[$I$(3).getGraphics$O(canvas), width, height]);
{
canvas.buf32 = buf;
}
return buf;
});

Clazz.newMeth(C$, 'drawImageToBuffer$O$O$O$I$I$I',  function (gOffscreen, imageOffscreen, canvas, width, height, bgcolor) {
return this.grabPixels$O$I$I$IA(canvas, width, height, null);
});

Clazz.newMeth(C$, 'getTextPixels$S$org_jmol_util_Font$O$O$I$I$I',  function (text, font3d, context, image, width, height, ascent) {
return $I$(3).getTextPixels$S$org_jmol_util_Font$O$I$I$I(text, font3d, context, width, height, ascent);
});

Clazz.newMeth(C$, 'flushImage$O',  function (imagePixelBuffer) {
});

Clazz.newMeth(C$, 'getGraphics$O',  function (canvas) {
return (canvas == null  ? this.context : (this.context=$I$(3,"getGraphics$O",[this.canvas=canvas])));
});

Clazz.newMeth(C$, 'getImageHeight$O',  function (canvas) {
return (canvas == null  ? -1 : $I$(3).getHeight$O(canvas));
});

Clazz.newMeth(C$, 'getImageWidth$O',  function (canvas) {
return (canvas == null  ? -1 : $I$(3).getWidth$O(canvas));
});

Clazz.newMeth(C$, 'getStaticGraphics$O$Z',  function (image, backgroundTransparent) {
return $I$(3).getStaticGraphics$O$Z(image, backgroundTransparent);
});

Clazz.newMeth(C$, 'newBufferedImage$O$I$I',  function (image, w, h) {
{
if (self.Jmol && Jmol.getHiddenCanvas) return Jmol.getHiddenCanvas(this.vwr.html5Applet, "stereoImage", w, h);
}
return null;
});

Clazz.newMeth(C$, 'newOffScreenImage$I$I',  function (w, h) {
{
if (self.Jmol && Jmol.getHiddenCanvas) return Jmol.getHiddenCanvas(this.vwr.html5Applet, "textImage", w, h);
}
return null;
});

Clazz.newMeth(C$, 'waitForDisplay$O$O',  function (echoNameAndPath, zipBytes) {
return false;
});

Clazz.newMeth(C$, 'fontStringWidth$org_jmol_util_Font$S',  function (font, text) {
return $I$(4).stringWidth$org_jmol_util_Font$S(font, text);
});

Clazz.newMeth(C$, 'getFontAscent$O',  function (context) {
return $I$(4).getAscent$O(context);
});

Clazz.newMeth(C$, 'getFontDescent$O',  function (context) {
return $I$(4).getDescent$O(context);
});

Clazz.newMeth(C$, 'getFontMetrics$org_jmol_util_Font$O',  function (font, context) {
return $I$(4).getFontMetrics$org_jmol_util_Font$O(font, context);
});

Clazz.newMeth(C$, 'newFont$S$Z$Z$F',  function (fontFace, isBold, isItalic, fontSize) {
return $I$(4).newFont$S$Z$Z$F$S(fontFace, isBold, isItalic, fontSize, "px");
});

Clazz.newMeth(C$, 'getDateFormat$S',  function (isoType) {
{
if (isoType == null) { } else if (isoType.indexOf("8824") >= 0) { var d = new Date();
var x = d.toString().split(" ");
var MM = "0" + d.getMonth(); MM = MM.substring(MM.length - 2);
var dd = "0" + d.getDate(); dd = dd.substring(dd.length - 2);
return x[3] + MM + dd + x[4].replace(/\:/g,"") + x[5].substring(3,6) + "'" + x[5].substring(6,8) + "'" } else if (isoType.indexOf("8601") >= 0){ var d = new Date();
var x = d.toString().split(" ");
var MM = "0" + d.getMonth(); MM = MM.substring(MM.length - 2);
var dd = "0" + d.getDate(); dd = dd.substring(dd.length - 2);
return x[3] + MM + dd + x[4].replace(/\:/g,"") + x[5].substring(3,6) + "'" + x[5].substring(6,8) + "'" } return ("" + (new Date())).split(" (")[0];
}
});

Clazz.newMeth(C$, 'newFile$S',  function (name) {
return Clazz.new_($I$(5,1).c$$S,[name]);
});

Clazz.newMeth(C$, 'getBufferedFileInputStream$S',  function (name) {
return null;
});

Clazz.newMeth(C$, 'getURLContents$java_net_URL$BA$S$Z',  function (url, outputBytes, post, asString) {
var ret=$I$(5).getURLContents$java_net_URL$BA$S(url, outputBytes, post);
try {
return (!asString ? ret : Clazz.instanceOf(ret, "java.lang.String") ? ret : Clazz.instanceOf(ret, "javajs.util.SB") ? (ret).toString() : Clazz.instanceOf(ret, Clazz.array(Byte.TYPE, -1)) ?  String.instantialize(ret) :  String.instantialize($I$(6).getStreamAsBytes$java_io_BufferedInputStream$javajs_util_OC(ret, null)));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return "" + e;
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'getLocalUrl$S',  function (fileName) {
return null;
});

Clazz.newMeth(C$, 'getImageDialog$S$java_util_Map',  function (title, imageMap) {
return null;
});

Clazz.newMeth(C$, 'forceAsyncLoad$S',  function (filename) {
return false;
});

Clazz.newMeth(C$, 'getInChI$',  function () {
return null;
});

Clazz.newMeth(C$, 'confirm$S$S',  function (msg, msgNo) {
var ok=confirm(msg) ||false;
if (ok) return 0;
if (msgNo != null ) ok=confirm(msgNo) ||false;
return (ok ? 1 : 2);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:58 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
