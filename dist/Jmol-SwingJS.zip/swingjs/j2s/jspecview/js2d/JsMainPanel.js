(function(){var P$=Clazz.newPackage("jspecview.js2d"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "JsMainPanel", null, null, 'jspecview.api.JSVMainPanel');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['visible','focusable','enabled'],'I',['currentPanelIndex'],'S',['title'],'O',['selectedPanel','jspecview.api.JSVPanel']]]

Clazz.newMeth(C$, 'getCurrentPanelIndex$',  function () {
return this.currentPanelIndex;
});

Clazz.newMeth(C$, 'dispose$',  function () {
});

Clazz.newMeth(C$, 'getTitle$',  function () {
return this.title;
});

Clazz.newMeth(C$, 'setTitle$S',  function (title) {
this.title=title;
});

Clazz.newMeth(C$, 'setSelectedPanel$jspecview_common_JSViewer$jspecview_api_JSVPanel$javajs_util_Lst',  function (viewer, jsvp, panelNodes) {
if (jsvp !== this.selectedPanel ) this.selectedPanel=jsvp;
var i=viewer.selectPanel$jspecview_api_JSVPanel$javajs_util_Lst(jsvp, panelNodes);
if (i >= 0) this.currentPanelIndex=i;
this.visible=true;
});

Clazz.newMeth(C$, 'getHeight$',  function () {
return (this.selectedPanel == null  ? 0 : this.selectedPanel.getHeight$());
});

Clazz.newMeth(C$, 'getWidth$',  function () {
return (this.selectedPanel == null  ? 0 : this.selectedPanel.getWidth$());
});

Clazz.newMeth(C$, 'isEnabled$',  function () {
return this.enabled;
});

Clazz.newMeth(C$, 'isFocusable$',  function () {
return this.focusable;
});

Clazz.newMeth(C$, 'isVisible$',  function () {
return this.visible;
});

Clazz.newMeth(C$, 'setEnabled$Z',  function (b) {
this.enabled=b;
});

Clazz.newMeth(C$, 'setFocusable$Z',  function (b) {
this.focusable=b;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:58 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
