(function(){var P$=Clazz.newPackage("jspecview.js2d"),I$=[[0,'org.jmol.awtjs2d.JSPopupHelper','jspecview.popup.JSVPopupResourceBundle']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JsPopup", null, 'jspecview.popup.JSVGenericPopup');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.helper=Clazz.new_($I$(1,1).c$$org_jmol_popup_GenericPopup,[this]);
}, 1);

Clazz.newMeth(C$, 'jpiInitialize$org_jmol_api_PlatformViewer$S',  function (viewer, menu) {
var bundle=Clazz.new_($I$(2,1));
this.initialize$jspecview_common_JSViewer$org_jmol_popup_PopupResource$S(viewer, bundle, menu);
});

Clazz.newMeth(C$, 'menuShowPopup$org_jmol_api_SC$I$I',  function (popup, x, y) {
try {
(popup).show$org_jmol_awtjs_swing_Component$I$I(this.isTainted ? this.vwr.getApplet$() : null, x, y);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'getImageIcon$S',  function (fileName) {
return null;
});

Clazz.newMeth(C$, 'menuFocusCallback$S$S$Z',  function (name, actionCommand, b) {
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-09-06 21:15:58 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
