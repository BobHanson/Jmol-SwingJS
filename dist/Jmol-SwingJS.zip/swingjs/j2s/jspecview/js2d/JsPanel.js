(function(){var P$=Clazz.newPackage("jspecview.js2d"),I$=[[0,'org.jmol.util.Logger','jspecview.common.PanelData','org.jmol.util.Font','jspecview.common.JSViewer','javajs.util.Base64']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JsPanel", null, null, 'jspecview.api.JSVPanel');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['name'],'O',['apiPlatform','org.jmol.api.GenericPlatform','pd','jspecview.common.PanelData','mouse','org.jmol.api.GenericMouseInterface','vwr','jspecview.common.JSViewer','bgcolor','javajs.api.GenericColor']]]

Clazz.newMeth(C$, 'finalize$',  function () {
$I$(1).info$S("JSVPanel " + this + " finalized" );
});

Clazz.newMeth(C$, 'getApiPlatform$',  function () {
return this.apiPlatform;
});

Clazz.newMeth(C$, 'getPanelData$',  function () {
return this.pd;
});

Clazz.newMeth(C$, 'getEmptyPanel$jspecview_common_JSViewer',  function (viewer) {
var p=Clazz.new_(C$.c$$jspecview_common_JSViewer$Z,[viewer, false]);
p.pd=null;
return p;
}, 1);

Clazz.newMeth(C$, 'getPanelMany$jspecview_common_JSViewer$javajs_util_Lst',  function (viewer, spectra) {
var p=Clazz.new_(C$.c$$jspecview_common_JSViewer$Z,[viewer, true]);
p.pd.initMany$javajs_util_Lst$I$I(spectra, viewer.initialStartIndex, viewer.initialEndIndex);
return p;
}, 1);

Clazz.newMeth(C$, 'c$$jspecview_common_JSViewer$Z',  function (viewer, withPd) {
;C$.$init$.apply(this);
this.vwr=viewer;
this.pd=(withPd ? Clazz.new_($I$(2,1).c$$jspecview_api_JSVPanel$jspecview_common_JSViewer,[this, viewer]) : null);
this.apiPlatform=viewer.apiPlatform;
this.mouse=this.apiPlatform.getMouseManager$D$O(0, this);
}, 1);

Clazz.newMeth(C$, 'getTitle$',  function () {
return this.pd.getTitle$();
});

Clazz.newMeth(C$, 'dispose$',  function () {
if (this.pd != null ) this.pd.dispose$();
this.pd=null;
this.mouse.dispose$();
this.mouse=null;
});

Clazz.newMeth(C$, 'setTitle$S',  function (title) {
this.pd.title=title;
this.name=title;
});

Clazz.newMeth(C$, 'setColorOrFont$jspecview_common_ColorParameters$jspecview_common_ScriptToken',  function (ds, st) {
this.pd.setColorOrFont$jspecview_common_ColorParameters$jspecview_common_ScriptToken(ds, st);
});

Clazz.newMeth(C$, 'setBackgroundColor$javajs_api_GenericColor',  function (color) {
this.bgcolor=color;
});

Clazz.newMeth(C$, 'getInput$S$S$S',  function (message, title, sval) {
var ret=null;
{
ret = prompt(message, sval);
}
this.getFocusNow$Z(true);
return ret;
});

Clazz.newMeth(C$, 'showMessage$S$S',  function (msg, title) {
$I$(1).info$S(msg);
if (this.vwr.html5Applet != null ) this.vwr.html5Applet._showStatus(msg, title);
this.getFocusNow$Z(true);
});

Clazz.newMeth(C$, 'getFocusNow$Z',  function (asThread) {
if (this.pd != null ) this.pd.dialogsToFront$jspecview_common_Spectrum(null);
});

Clazz.newMeth(C$, 'getFontFaceID$S',  function (name) {
return $I$(3).getFontFaceID$S("SansSerif");
});

Clazz.newMeth(C$, 'doRepaint$Z',  function (andTaintAll) {
if (this.pd == null ) return;
if (andTaintAll) this.pd.setTaintedAll$();
if (!this.pd.isPrinting) this.vwr.requestRepaint$();
});

Clazz.newMeth(C$, 'paintComponent$O',  function (context) {
var contextFront=null;
var contextRear=null;
{
contextFront = context.canvas.frontLayer.getContext("2d");
contextRear = context;
}
if (this.vwr == null ) return;
if (this.pd == null ) {
if (this.bgcolor == null ) this.bgcolor=this.vwr.g2d.getColor1$I(-1);
this.vwr.g2d.fillBackground$O$javajs_api_GenericColor(context, this.bgcolor);
this.vwr.g2d.fillBackground$O$javajs_api_GenericColor(contextRear, this.bgcolor);
this.vwr.g2d.fillBackground$O$javajs_api_GenericColor(contextFront, this.bgcolor);
return;
}if (this.pd.graphSets == null  || this.pd.isPrinting ) return;
this.pd.g2d=this.pd.g2d0;
this.pd.drawGraph$O$O$O$I$I$Z(context, contextFront, contextRear, this.getWidth$(), this.getHeight$(), false);
this.vwr.repaintDone$();
});

Clazz.newMeth(C$, 'printPanel$jspecview_common_PrintLayout$java_io_OutputStream$S',  function (pl, os, title) {
pl.title=title;
pl.date=this.apiPlatform.getDateFormat$S("8824");
this.pd.setPrint$jspecview_common_PrintLayout$S(pl, "Helvetica");
try {
($I$(4).getInterface$S("jspecview.common.PDFWriter")).createPdfDocument$jspecview_api_JSVPanel$jspecview_common_PrintLayout$java_io_OutputStream(this, pl, os);
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
this.showMessage$S$S(ex.toString(), "creating PDF");
} else {
throw ex;
}
} finally {
this.pd.setPrint$jspecview_common_PrintLayout$S(null, null);
}
});

Clazz.newMeth(C$, 'saveImage$S$org_jmol_api_GenericFileInterface$javajs_util_OC',  function (type, file, out) {
var fname=file.getName$();
var isPNG=type.equals$O("png");
var s=(isPNG ? "png" : "jpeg");
{
s = viewer.display.toDataURL(s);
if (!isPNG && s.contains("/png")) fname = fname.split('.jp')[0] + ".png";
}
try {
out=this.vwr.getOutputChannel$S$Z(fname, true);
var data=$I$(5).decodeBase64$S(s);
out.write$BA$I$I(data, 0, data.length);
out.closeChannel$();
return "OK " + out.getByteCount$() + " bytes" ;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return e.toString();
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'hasFocus$',  function () {
return false;
});

Clazz.newMeth(C$, 'repaint$',  function () {
});

Clazz.newMeth(C$, 'setToolTipText$S',  function (s) {
var x=this.pd.mouseX;
var y=this.pd.mouseY;
if (this.vwr.html5Applet != null ) this.vwr.html5Applet._showTooltip(s, x, y);
});

Clazz.newMeth(C$, 'getHeight$',  function () {
return this.vwr.getHeight$();
});

Clazz.newMeth(C$, 'getWidth$',  function () {
return this.vwr.getWidth$();
});

Clazz.newMeth(C$, 'isEnabled$',  function () {
return false;
});

Clazz.newMeth(C$, 'isFocusable$',  function () {
return false;
});

Clazz.newMeth(C$, 'isVisible$',  function () {
return false;
});

Clazz.newMeth(C$, 'setEnabled$Z',  function (b) {
});

Clazz.newMeth(C$, 'setFocusable$Z',  function (b) {
});

Clazz.newMeth(C$, 'toString',  function () {
return (this.pd == null  ? "<closed>" : "" + this.pd.getSpectrumAt$I(0));
});

Clazz.newMeth(C$, 'processMouseEvent$I$I$I$I$J',  function (id, x, y, modifiers, time) {
return this.mouse != null  && this.mouse.processEvent$I$I$I$I$J(id, x, y, modifiers, time) ;
});

Clazz.newMeth(C$, 'processKeyEvent$O',  function (event) {
this.mouse.processKeyEvent$O(event);
});

Clazz.newMeth(C$, 'processTwoPointGesture$DAAA',  function (touches) {
if (this.mouse != null ) this.mouse.processTwoPointGesture$DAAA(touches);
});

Clazz.newMeth(C$, 'showMenu$I$I',  function (x, y) {
this.vwr.showMenu$I$I(x, y);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-08-13 20:20:29 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
