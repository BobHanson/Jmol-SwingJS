(function(){var P$=Clazz.newPackage("org.jmol.modelkit"),p$1={},I$=[[0,'org.jmol.modelkit.ModelKitPopupResourceBundle','org.jmol.i18n.GT']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ModelKitPopup", null, 'org.jmol.popup.JmolGenericPopup');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.hidden=false;
this.allowPopup=true;
this.bondRotationName=".modelkitMenu.bondMenu.rotateBondP!RD";
},1);

C$.$fields$=[['Z',['hidden','allowPopup','haveOperators'],'S',['activeMenu','bondRotationName'],'O',['modelkit','org.jmol.modelkit.ModelKit','bondRotationCheckBox','org.jmol.api.SC','+prevBondCheckBox']]
,['O',['bundle','org.jmol.popup.PopupResource']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'getBundle$S',  function (menu) {
return C$.bundle;
});

Clazz.newMeth(C$, 'jpiShow$I$I',  function (x, y) {
if (!this.hidden) {
this.updateCheckBoxesForModelKit$S(null);
C$.superclazz.prototype.jpiShow$I$I.apply(this, [x, y]);
}});

Clazz.newMeth(C$, 'jpiUpdateComputedMenus$',  function () {
this.htMenus.get$O("xtalMenu").setEnabled$Z(this.modelkit.setHasUnitCell$());
if (this.modelkit.checkNewModel$()) {
this.haveOperators=false;
this.updateOperatorMenu$();
}this.updateAllXtalMenuOptions$();
});

Clazz.newMeth(C$, 'appUpdateForShow$',  function () {
this.jpiUpdateComputedMenus$();
});

Clazz.newMeth(C$, 'hidePopup$',  function () {
this.menuHidePopup$org_jmol_api_SC(this.popupMenu);
});

Clazz.newMeth(C$, 'clearLastModelSet$',  function () {
this.modelkit.lastModelSet=null;
});

Clazz.newMeth(C$, 'updateOperatorMenu$',  function () {
if (this.haveOperators) return;
this.haveOperators=true;
var menu=this.htMenus.get$O("xtalOp!PersistMenu");
if (menu != null ) p$1.addAllCheckboxItems$org_jmol_api_SC$SA.apply(this, [menu, this.modelkit.getAllOperators$()]);
});

Clazz.newMeth(C$, 'addAllCheckboxItems$org_jmol_api_SC$SA',  function (menu, labels) {
this.menuRemoveAll$org_jmol_api_SC$I(menu, 0);
var subMenu=menu;
var pt=(labels.length > 32 ? 0 : -2147483648);
for (var i=0; i < labels.length; i++) {
if (pt >= 0 && (pt++ % 32) == 0 ) {
var id="mtsymop" + pt + "Menu" ;
subMenu=this.menuNewSubMenu$S$S((i + 1) + "..." + Math.min(i + 32, labels.length) , this.menuGetId$org_jmol_api_SC(menu) + "." + id );
this.menuAddSubMenu$org_jmol_api_SC$org_jmol_api_SC(menu, subMenu);
this.htMenus.put$O$O(id, subMenu);
pt=1;
}if (i == 0) this.menuEnable$org_jmol_api_SC$Z(this.menuCreateItem$org_jmol_api_SC$S$S$S(subMenu, $I$(2).$$S("none"), "draw sym_* delete", null), true);
var sym=labels[i];
this.menuEnable$org_jmol_api_SC$Z(this.menuCreateItem$org_jmol_api_SC$S$S$S(subMenu, sym, sym, subMenu.getName$() + "." + "mkop_" + (i + 1) ), true);
}
}, p$1);

Clazz.newMeth(C$, 'updateAllXtalMenuOptions$',  function () {
var text="";
switch (this.modelkit.getMKState$()) {
case 0:
text=" (not enabled)";
break;
case 1:
text=" (view)";
break;
case 2:
text=" (edit)";
break;
}
p$1.setLabel$S$S.apply(this, ["xtalModePersistMenu", "Crystal Mode: " + text]);
text=this.modelkit.getCenterText$();
p$1.setLabel$S$S.apply(this, ["xtalSelPersistMenu", "Center: " + (text == null  ? "(not selected)" : text)]);
text=this.modelkit.getSymopText$();
p$1.setLabel$S$S.apply(this, ["operator", text == null  ? "(no operator selected)" : text]);
switch (this.modelkit.getSymEditState$()) {
case 0:
text="do not apply symmetry";
break;
case 64:
text="retain local symmetry";
break;
case 32:
text="apply local symmetry";
break;
case 128:
text="apply full symmetry";
break;
}
p$1.setLabel$S$S.apply(this, ["xtalEditOptPersistMenu", "Edit option: " + text]);
switch (this.modelkit.getUnitCellState$()) {
case 0:
text="packed";
break;
case 256:
text="unpacked" + (this.modelkit.viewOffset == null  ? "(no view offset)" : "(view offset=" + this.modelkit.viewOffset + ")" );
break;
}
p$1.setLabel$S$S.apply(this, ["xtalPackingPersistMenu", "Packing: " + text]);
});

Clazz.newMeth(C$, 'setLabel$S$S',  function (key, label) {
this.menuSetLabel$org_jmol_api_SC$S(this.htMenus.get$O(key), label);
}, p$1);

Clazz.newMeth(C$, 'setActiveMenu$S',  function (name) {
var active=(name.indexOf$S("xtalMenu") >= 0 ? "xtalMenu" : name.indexOf$S("atomMenu") >= 0 ? "atomMenu" : name.indexOf$S("bondMenu") >= 0 ? "bondMenu" : null);
if (active != null ) {
this.activeMenu=active;
if ((active == "xtalMenu") == (this.modelkit.getMKState$() == 0) ) this.modelkit.setMKState$I(active == "xtalMenu" ? 1 : 0);
this.vwr.refresh$I$S(1, "modelkit");
if (active == "bondMenu" && this.prevBondCheckBox == null  ) this.prevBondCheckBox=this.htMenus.get$O("assignBond_pP!RD");
} else if (name.indexOf$S("optionsMenu") >= 0) {
this.htMenus.get$O("undo").setEnabled$Z(this.vwr.undoMoveAction$I$I(4165, 1275068425) > 0);
this.htMenus.get$O("redo").setEnabled$Z(this.vwr.undoMoveAction$I$I(4140, 1275068425) > 0);
}return active;
});

Clazz.newMeth(C$, 'appUpdateSpecialCheckBoxValue$org_jmol_api_SC$S$Z',  function (source, actionCommand, selected) {
if (source == null  || !selected ) return;
var name=source.getName$();
if (!this.updatingForShow && this.setActiveMenu$S(name) != null  ) {
this.exitBondRotation$();
var text=source.getText$();
if (this.activeMenu == "bondMenu") {
if (name.equals$O(this.bondRotationName)) {
this.bondRotationCheckBox=source;
} else {
this.prevBondCheckBox=source;
}}this.modelkit.setHoverLabel$S$S(this.activeMenu, text);
}});

Clazz.newMeth(C$, 'exitBondRotation$',  function () {
this.modelkit.exitBondRotation$S(this.prevBondCheckBox == null  ? null : this.prevBondCheckBox.getText$());
if (this.bondRotationCheckBox != null ) this.bondRotationCheckBox.setSelected$Z(false);
if (this.prevBondCheckBox != null ) this.prevBondCheckBox.setSelected$Z(true);
});

Clazz.newMeth(C$, 'appGetBooleanProperty$S',  function (name) {
if (name.startsWith$S("mk")) {
return (this.modelkit.getProperty$S(name.substring$I(2))).booleanValue$();
}return this.vwr.getBooleanProperty$S(name);
});

Clazz.newMeth(C$, 'getUnknownCheckBoxScriptToRun$org_jmol_api_SC$S$S$Z',  function (item, name, what, TF) {
if (name.startsWith$S("mk")) {
this.modelkit.processMKPropertyItem$S$Z(name, TF);
return null;
}var element=this.modelkit.getElementFromUser$();
if (element == null ) return null;
this.menuSetLabel$org_jmol_api_SC$S(item, element);
item.setActionCommand$S("assignAtom_" + element + "P!:??" );
this.modelkit.setHoverLabel$S$S("atomMenu", "Click or click+drag for " + element);
return "set picking assignAtom_" + element;
});

Clazz.newMeth(C$, 'menuFocusCallback$S$S$Z',  function (name, actionCommand, gained) {
if (gained && !this.modelkit.processSymop$S$Z(name, true) ) {
this.setActiveMenu$S(name);
}this.exitBondRotation$();
});

Clazz.newMeth(C$, 'menuClickCallback$org_jmol_api_SC$S',  function (source, script) {
if (this.modelkit.processSymop$S$Z(source.getName$(), false)) return;
if (script.equals$O("clearQPersist")) {
for (var item, $item = this.htCheckbox.values$().iterator$(); $item.hasNext$()&&((item=($item.next$())),1);) {
if (item.getActionCommand$().indexOf$S(":??") < 0) continue;
this.menuSetLabel$org_jmol_api_SC$S(item, "??");
item.setActionCommand$S("_??P!:");
item.setSelected$Z(false);
}
this.appRunScript$S("set picking assignAtom_C");
return;
}this.doMenuClickCallback$org_jmol_api_SC$S(source, script);
});

Clazz.newMeth(C$, 'getScriptForCallback$org_jmol_api_SC$S$S',  function (source, id, script) {
if (script.startsWith$S("mk")) {
this.modelkit.processXtalClick$S$S(id, script);
script=null;
}return script;
});

Clazz.newMeth(C$, 'appRunSpecialCheckBox$org_jmol_api_SC$S$S$Z',  function (item, basename, script, TF) {
if (basename.indexOf$S("assignAtom_Xx") == 0) {
this.modelkit.resetAtomPickType$();
}return C$.superclazz.prototype.appRunSpecialCheckBox$org_jmol_api_SC$S$S$Z.apply(this, [item, basename, script, TF]);
});

Clazz.newMeth(C$, 'updateCheckBoxesForModelKit$S',  function (menuName) {
var thisBondType="assignBond_" + this.modelkit.pickBondAssignType;
var thisAtomType="assignAtom_" + this.modelkit.pickAtomAssignType + "P" ;
for (var entry, $entry = this.htCheckbox.entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) {
var key=entry.getKey$();
var item=entry.getValue$();
if (key.startsWith$S(thisBondType) || key.startsWith$S(thisAtomType) ) {
item.setSelected$Z(false);
item.setSelected$Z(true);
}}
});

C$.$static$=function(){C$.$static$=0;
C$.bundle=Clazz.new_($I$(1,1).c$$S$java_util_Properties,[null, null]);
};
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-08-23 15:03:08 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
