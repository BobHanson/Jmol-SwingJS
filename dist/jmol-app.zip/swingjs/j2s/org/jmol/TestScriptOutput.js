(function(){var P$=Clazz.newPackage("org.jmol"),I$=[['org.jmol.api.JmolViewer']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "TestScriptOutput");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'main', function (args) {
Clazz.new_(C$);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
var viewer = (I$[1]||$incl$(1)).allocateViewer$O$org_jmol_api_JmolAdapter(null, null);
var jmolScript = "print \'hello world: \u000a\' + getProperty(\'appletInfo\')";
var strOutput = viewer.scriptWaitStatus$S$S(jmolScript, null);
System.out.println$S(strOutput);
}, 1);
})();
//Created 2018-07-22 20:22:13 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
