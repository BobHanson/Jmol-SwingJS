(function(){var P$=Clazz.newPackage("org.jmol"),I$=[];
var C$=Clazz.newClass(P$, "TestScriptOutput");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'main$SA', function (args) {
Clazz.new_(C$);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
var viewer=Clazz.load('org.jmol.api.JmolViewer').allocateViewer$O$org_jmol_api_JmolAdapter(null, null);
var jmolScript="print \'hello world: \n\' + getProperty(\'appletInfo\')";
var strOutput=viewer.scriptWaitStatus$S$S(jmolScript, null);
System.out.println$S(strOutput);
}, 1);
})();
;Clazz.setTVer('3.2.2.06');//Created 2018-09-17 22:04:09 Java2ScriptVisitor version 3.2.2.06 net.sf.j2s.core.jar version 3.2.2.06
