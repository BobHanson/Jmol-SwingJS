(function(){var P$=Clazz.newPackage("org.jmol.minimize"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "MinAngle", null, 'org.jmol.minimize.MinObject');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.theta0=NaN;
},1);

C$.$fields$=[['D',['ka','theta0'],'I',['sbType'],'O',['sbKey','Integer']]]

Clazz.newMeth(C$, 'c$$IA', function (data) {
Clazz.super_(C$, this);
this.data=data;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-05-29 12:12:24 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
