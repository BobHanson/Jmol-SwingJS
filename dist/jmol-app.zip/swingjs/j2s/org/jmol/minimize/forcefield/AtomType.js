(function(){var P$=Clazz.newPackage("org.jmol.minimize.forcefield"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "AtomType");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['sbmb','arom','pilp'],'D',['formalCharge','fcadj'],'I',['elemNo','mmType','hType','mltb','val'],'S',['descr','smartsCode']]]

Clazz.newMeth(C$, 'c$$I$I$I$D$I$S$S',  function (elemNo, mmType, hType, formalCharge, val, descr, smartsCode) {
;C$.$init$.apply(this);
this.elemNo=elemNo;
this.mmType=mmType;
this.hType=hType;
this.formalCharge=formalCharge;
this.val=val;
this.descr=descr;
this.smartsCode=smartsCode;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-08-23 15:03:08 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
