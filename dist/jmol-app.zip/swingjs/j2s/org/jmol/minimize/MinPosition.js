(function(){var P$=Clazz.newPackage("org.jmol.minimize"),I$=[];
var C$=Clazz.newClass(P$, "MinPosition", null, 'org.jmol.minimize.MinObject');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$IA$DA', function (data, ddata) {
Clazz.super_(C$, this,1);
this.data=data;
this.ddata=ddata;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.04');//Created 2018-11-15 12:07:08 Java2ScriptVisitor version 3.2.4.04 net.sf.j2s.core.jar version 3.2.4.04
