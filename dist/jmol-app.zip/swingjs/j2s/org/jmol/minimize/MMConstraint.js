(function(){var P$=Clazz.newPackage("org.jmol.minimize"),I$=[];
var C$=Clazz.newClass(P$, "MMConstraint");

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.indexes=null;
this.value=0;
this.type=0;
this.minList=null;
this.nAtoms=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.minList=Clazz.array(Integer.TYPE, [4]);
}, 1);

Clazz.newMeth(C$, 'c$$IA$D', function (indexes, value) {
C$.$init$.apply(this);
this.value=value;
this.indexes=indexes;
}, 1);

Clazz.newMeth(C$, 'set$I$javajs_util_BS$IA', function (steps, bsAtoms, atomMap) {
this.nAtoms=Math.abs(this.indexes[0]);
this.type=this.nAtoms - 2;
for (var j=1; j <= this.nAtoms; j++) {
if (steps <= 0 || !bsAtoms.get$I(this.indexes[j]) ) {
this.indexes[0]=-this.nAtoms;
break;
}this.minList[j - 1]=atomMap[this.indexes[j]];
}
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-07-14 10:23:40 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
