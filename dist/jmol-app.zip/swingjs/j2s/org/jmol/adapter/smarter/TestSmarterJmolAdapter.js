(function(){var P$=Clazz.newPackage("org.jmol.adapter.smarter"),I$=[['java.io.File','javajs.util.PT','org.jmol.adapter.smarter.TestSmarterJmolAdapter$1','org.jmol.util.Logger','org.jmol.adapter.smarter.TestSmarterJmolAdapterImpl','org.jmol.util.JUnitLogger','java.io.FileInputStream','java.util.zip.GZIPInputStream','java.io.BufferedInputStream','org.jmol.adapter.smarter.SmarterJmolAdapter','javajs.util.Rdr','javajs.util.BinaryDocument','java.util.Hashtable']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "TestSmarterJmolAdapter", null, 'junit.framework.TestSuite');
C$.testOne = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.datafileDirectory = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.datafileDirectory = "../Jmol-datafiles";
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$Class$S', function (theClass, name) {
C$.superclazz.c$$Class$S.apply(this, [theClass, name]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$Class', function (theClass) {
C$.superclazz.c$$Class.apply(this, [theClass]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (name) {
C$.superclazz.c$$S.apply(this, [name]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'suite', function () {
var result = Clazz.new_(C$.c$$S,["Test for org.jmol.adapter.smarter.SmarterJmolAdapter"]);
result.datafileDirectory=System.getProperty("test.datafile.directory", result.datafileDirectory);
result.addDirectory$S$S$S("adf", "adf;out", "Adf");
result.addDirectory$S$S$S("aims", "in", "Aims");
result.addDirectory$S$S$S("aminoacids", "mol", "Mol");
result.addDirectory$S$S$S("aminoacids", "pdb", "Pdb");
result.addDirectory$S$S$S("animations", "cml", "XmlCml");
result.addDirectory$S$S$S("animations", "pdb;pdb.gz", "Pdb");
result.addDirectory$S$S$S("animations", "xyz", "Xyz");
result.addDirectory$S$S$S("castep", "cell;phonon", "Castep");
result.addDirectory$S$S$S("cif", "mmcif", "MMCif");
result.addDirectory$S$S$S("cif", "cif", "Cif");
result.addDirectory$S$S$S("cif", "mmtf", "MMTF");
result.addDirectory$S$S$S("c3xml", "c3xml", "XmlChem3d");
result.addDirectory$S$S$S("cml", "cml", "XmlCml");
result.addDirectory$S$S$S("crystal", "out;outp", "Crystal");
result.addDirectory$S$S$S("crystals", "mol", "Mol");
result.addDirectory$S$S$S("crystals", "pdb", "Pdb");
result.addDirectory$S$S$S("csf", "csf", "Csf");
result.addDirectory$S$S$S("cube", "cub.gz;cube.gz", "Cube");
result.addDirectory$S$S$S("dgrid", "adf", "Dgrid");
result.addDirectory$S$S$S("dmol", "outmol", "Dmol");
result.addDirectory$S$S$S("folding", "xyz;xyz.gz", "FoldingXyz");
result.addDirectory$S$S$S("../Jmol-FAH/projects", "xyz;xyz.gz", "FoldingXyz");
result.addDirectory$S$S$S("gamess", "log;out", ";Gamess;GamessUS;GamessUK;");
result.addDirectory$S$S$S("gaussian", "log;out", "Gaussian");
result.addDirectory$S$S$S("gennbo", "out;36;37", "GenNBO");
result.addDirectory$S$S$S("ghemical", "gpr", "GhemicalMM");
result.addDirectory$S$S$S("gromacs", "gro", "Gromacs");
result.addDirectory$S$S$S("gulp", "gout;got", "Gulp");
result.addDirectory$S$S$S("hyperchem", "hin", "HyperChem");
result.addDirectory$S$S$S("hyperchem", "hpr", "HyperChem");
result.addDirectory$S$S$S("jaguar", "out", "Jaguar");
result.addDirectory$S$S$S("modifiedGroups", "cif", "MMCif");
result.addDirectory$S$S$S("modifiedGroups", "pdb", "Pdb");
result.addDirectory$S$S$S("mol", "v3000;mol;sdf", "Mol");
result.addDirectory$S$S$S("mol2", "mol2", "Mol2");
result.addDirectory$S$S$S("molpro", "xml", "XmlMolpro");
result.addDirectory$S$S$S("mopac", "arc;archive", "MopacArchive");
result.addDirectory$S$S$S("mopac", "out", "Mopac");
result.addDirectory$S$S$S("mopac", "gpt2", "MopacGraphf");
result.addDirectory$S$S$S("mopac", "mgf", "MopacGraphf");
result.addDirectory$S$S$S("odyssey", "odydata", "Odyssey");
result.addDirectory$S$S$S("odyssey", "xodydata", "XmlOdyssey");
result.addDirectory$S$S$S("nwchem", "nwo", "NWChem");
result.addDirectory$S$S$S("pdb", "pdb;pdb.gz", "Pdb");
result.addDirectory$S$S$S("pymol", "pse", "PyMOL");
result.addDirectory$S$S$S("quantumEspresso", "out", "Espresso");
result.addDirectory$S$S$S("psi3", "out", "Psi");
result.addDirectory$S$S$S("qchem", "out", "Qchem");
result.addDirectory$S$S$S("shelx", "res", "Shelx");
result.addDirectory$S$S$S("siesta", "fdf;out", "Siesta");
result.addDirectory$S$S$S("spartan", "smol", "SpartanSmol");
result.addDirectory$S$S$S("spartan", "txt;sp4", "Spartan");
result.addDirectory$S$S$S("sparchive", "sparchive;spartan", "Spartan");
result.addDirectory$S$S$S("vasp", "xml", "XmlVasp");
result.addDirectory$S$S$S("vasp", "dat", "VaspOutcar");
result.addDirectory$S$S$S("vasp", "poscar", "VaspPoscar");
result.addDirectory$S$S$S("wien2k", "struct", "Wien2k");
result.addDirectory$S$S$S("webmo", "mo", "WebMO");
result.addDirectory$S$S$S("xsd", "xsd", "XmlXsd");
result.addDirectory$S$S$S("xyz", "xyz", "Xyz");
result.addDirectory$S$S$S("zmatrix", "txt;zmat", "Input");
result.addDirectory$S$S$S("zmatrix", "inp", "=Input");
return result;
}, 1);

Clazz.newMeth(C$, 'addDirectory$S$S$S', function (directory, ext, typeAllowed) {
if (C$.testOne != null  && !directory.equals$O(C$.testOne) ) return;
var dir = Clazz.new_((I$[1]||$incl$(1)).c$$S$S,[this.datafileDirectory, directory]);
var exts = (I$[2]||$incl$(2)).split$S$S(ext, ";");
for (var ie = 0; ie < exts.length; ie++) {
var e = exts[ie];
var files = dir.list$java_io_FilenameFilter(((
(function(){var C$=Clazz.newClass(P$, "TestSmarterJmolAdapter$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.io.FilenameFilter', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['accept$java_io_File$S','accept'], function (dir, name) {
return name.endsWith$S("." + this.$finals.e);
});
})()
), Clazz.new_((I$[3]||$incl$(3)).$init$, [this, {e: e}])));
if (files == null ) {
(I$[4]||$incl$(4)).warn$S("No files in directory [" + directory + "] for extension [" + e + "]" );
} else {
for (var i = 0; i < files.length; i++) p$.addFile$Z$S$S$S.apply(this, [e.endsWith$S(".gz"), directory, files[i], typeAllowed]);

}}
});

Clazz.newMeth(C$, 'addFile$Z$S$S$S', function (gzipped, directory, filename, typeAllowed) {
var file = Clazz.new_((I$[1]||$incl$(1)).c$$java_io_File$S,[Clazz.new_((I$[1]||$incl$(1)).c$$S$S,[this.datafileDirectory, directory]), filename]);
var test = Clazz.new_((I$[5]||$incl$(5)).c$$java_io_File$Z$S,[file, gzipped, typeAllowed]);
this.addTest$junit_framework_Test(test);
});
})();
//Created 2018-07-22 20:22:13 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
