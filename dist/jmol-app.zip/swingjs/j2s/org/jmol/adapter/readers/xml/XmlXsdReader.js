(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.xml"),I$=[[0,'javajs.util.BS','org.jmol.adapter.smarter.Atom','javajs.util.PT']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "XmlXsdReader", null, 'org.jmol.adapter.readers.xml.XmlReader');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.bsBackbone=null;
this.iChain=0;
this.iGroup=0;
this.iAtom=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.bsBackbone=Clazz.new_(Clazz.load('javajs.util.BS'));
this.iChain=-1;
this.iGroup=0;
this.iAtom=0;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'processXml$org_jmol_adapter_readers_xml_XmlReader$O', function (parent, saxReader) {
parent.htParams.put$TK$TV("backboneAtoms", this.bsBackbone);
this.processXml2$org_jmol_adapter_readers_xml_XmlReader$O(parent, saxReader);
this.asc.atomSymbolicMap.clear$();
});

Clazz.newMeth(C$, 'processStartElement$S$S', function (localName, nodeName) {
var tokens;
if ("molecule".equals$O(localName)) {
this.asc.newAtomSet$();
this.asc.setAtomSetName$S(this.atts.get$O("name"));
return;
}if ("linearchain".equals$O(localName)) {
this.iGroup=0;
this.iChain++;
}if ("repeatunit".equals$O(localName)) {
this.iGroup++;
}if ("atom3d".equals$O(localName)) {
this.atom=Clazz.new_(Clazz.load('org.jmol.adapter.smarter.Atom'));
this.atom.elementSymbol=this.atts.get$O("components");
this.atom.atomName=this.atts.get$O("id");
this.atom.atomSerial=++this.iAtom;
if (this.iChain >= 0) this.parent.setChainID$org_jmol_adapter_smarter_Atom$S(this.atom, "" + String.fromCharCode(((this.iChain - 1) % 26 + 65)));
this.atom.group3="UNK";
if (this.iGroup == 0) this.iGroup=1;
this.atom.sequenceNumber=this.iGroup;
var xyz=this.atts.get$O("xyz");
if (xyz != null ) {
tokens=Clazz.load('javajs.util.PT').getTokens$S(xyz.replace$C$C(",", " "));
this.atom.set$F$F$F(this.parseFloatStr$S(tokens[0]), this.parseFloatStr$S(tokens[1]), this.parseFloatStr$S(tokens[2]));
}var isBackbone="1".equals$O(this.atts.get$O("isbackboneatom"));
if (isBackbone) this.bsBackbone.set$I(this.iAtom);
return;
}if ("bond".equals$O(localName)) {
var atoms=$I$(3).split$S$S(this.atts.get$O("connects"), ",");
var order=1;
if (this.atts.containsKey$O("type")) {
var type=this.atts.get$O("type");
if (type.equals$O("Double")) order=2;
 else if (type.equals$O("Triple")) order=3;
}this.asc.addNewBondFromNames$S$S$I(atoms[0], atoms[1], order);
return;
}});

Clazz.newMeth(C$, 'processEndElement$S', function (localName) {
if ("atom3d".equalsIgnoreCase$S(localName)) {
if (this.atom.elementSymbol != null  && !Float.isNaN$F(this.atom.z) ) {
this.parent.setAtomCoord$org_jmol_adapter_smarter_Atom(this.atom);
this.asc.addAtomWithMappedName$org_jmol_adapter_smarter_Atom(this.atom);
}this.atom=null;
return;
}this.setKeepChars$Z(false);
});
})();
;Clazz.setTVer('3.2.2.06');//Created 2018-09-17 22:03:40 Java2ScriptVisitor version 3.2.2.06 net.sf.j2s.core.jar version 3.2.2.06
