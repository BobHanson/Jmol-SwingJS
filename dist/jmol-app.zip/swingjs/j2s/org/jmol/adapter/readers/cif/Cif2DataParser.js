(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.cif"),I$=[['javajs.util.PT','javajs.util.Lst','java.util.Hashtable']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Cif2DataParser", null, 'javajs.util.CifDataParser');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getVersion', function () {
return 2;
});

Clazz.newMeth(C$, 'toUnicode$S', function (data) {
return data;
});

Clazz.newMeth(C$, 'isQuote$C', function (ch) {
switch (ch.$c()) {
case 1:
case 39:
case 34:
case 91:
case 93:
case 123:
case 125:
case 59:
return true;
}
return false;
});

Clazz.newMeth(C$, 'getQuotedStringOrObject$C', function (ch) {
return p$.processQuotedString.apply(this, []);
});

Clazz.newMeth(C$, 'preprocessString', function () {
this.line=(this.ich == 0 ? this.str : this.str.substring(this.ich));
return this.setString$S(this.processSemiString());
});

Clazz.newMeth(C$, 'processQuotedString', function () {
var str = null;
var quoteChar = this.str.charAt(this.ich);
var tripleChar = null;
try {
switch (quoteChar.$c()) {
case 1:
str=this.str.substring(1, (this.ich=this.str.indexOf("\u0001", this.ich + 1)));
this.ich++;
break;
case 91:
return this.readList();
case 93:
this.ich++;
return "]";
case 123:
return this.readTable();
case 125:
this.ich++;
return "}";
case 39:
case 34:
if (this.str.indexOf("\'\'\'") == this.ich) tripleChar="\'\'\'";
 else if (this.str.indexOf("\"\"\"") == this.ich) tripleChar="\"\"\"";
var nchar = (tripleChar == null  ? 1 : 3);
var pt = this.ich + nchar;
var pt1 = 0;
while ((pt1=(tripleChar == null  ? this.str.indexOf(quoteChar, pt) : this.str.indexOf(tripleChar, pt))) < 0){
if (this.readLine() == null ) break;
this.str += this.line;
}
this.ich=pt1 + nchar;
this.cch=this.str.length$();
str=this.str.substring(pt, pt1);
break;
}
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
System.out.println$S("exception in Cif2DataParser ; " + e);
} else {
throw e;
}
}
return (this.cterm == "\u0000" || this.asObject  ? str : (I$[1]||$incl$(1)).esc$S(str));
});

Clazz.newMeth(C$, 'processSemiString', function () {
var pt1;
var pt2;
var str = this.preprocessSemiString();
if (str.indexOf(";") != 1 && (pt1=str.indexOf("\\")) > 1  && ((pt2=str.indexOf("\u000a")) > pt1 || pt2 < 0 ) ) {
var prefix = str.substring(1, pt1);
str=(I$[1]||$incl$(1)).rep$S$S$S(str, "\n" + prefix, "\u000a");
str="\1" + str.substring(str.charAt(pt1 + 1) == "\\" ? pt1 + 1 : pt2 < 0 ? str.length$() - 1 : pt2 + 1);
}this.ich=0;
return p$.fixLineFolding$S.apply(this, [str]);
});

Clazz.newMeth(C$, 'readList', function () {
this.ich++;
var cterm0 = this.cterm;
this.cterm="]";
var ns = this.nullString;
this.nullString=null;
var lst = (this.asObject ? Clazz.new_((I$[2]||$incl$(2))) : null);
var n = 0;
var str = "";
while (true){
var value = (this.asObject ? this.getNextTokenObject() : this.getNextToken());
if (value == null  || value.equals$O("]") ) break;
if (this.asObject) {
lst.addLast$TV(value);
} else {
if (n++ > 0) str += ",";
str += value;
}}
this.cterm=cterm0;
this.nullString=ns;
return (this.asObject ? lst : "[" + str + "]" );
});

Clazz.newMeth(C$, 'readTable', function () {
this.ich++;
var cterm0 = this.cterm;
this.cterm="}";
var ns = this.nullString;
this.nullString=null;
var map = (this.asObject ? Clazz.new_((I$[3]||$incl$(3))) : null);
var n = 0;
var str = "";
while (true){
var key = this.getNextToken();
if (key == null  || key.equals$O("}") ) break;
while (p$.isSpaceOrColon$I.apply(this, [this.ich]))this.ich++;

if (this.asObject) {
map.put$TK$TV(key, this.getNextTokenObject());
} else {
if (n++ > 0) str += ",";
str += key + " : " + this.getNextToken() ;
}}
this.cterm=cterm0;
this.nullString=ns;
return (this.asObject ? map : "{" + str + "}" );
});

Clazz.newMeth(C$, 'isSpaceOrColon$I', function (ich) {
if (ich < this.cch) switch ((this.line.charCodeAt(ich))) {
case 32:
case 9:
case 10:
case 58:
return true;
}
return false;
});

Clazz.newMeth(C$, 'unquoted$S', function (s) {
if (this.cterm == "\u0000" && !this.asObject ) return s;
var n = s.length$();
if (n > 0) {
var c = s.charAt(0);
if ((I$[1]||$incl$(1)).isDigit$C(c) || c == "-"  || c == "." && n > 1  ) {
var pt = s.indexOf("(");
var isFloat = (s.indexOf(".") >= 0);
if (n > 1 && pt > 0  && s.indexOf(")", pt + 1) == n - 1 ) s=s.substring(0, pt);
try {
if (isFloat) {
var f = Float.parseFloat(s);
if (this.asObject) return Float.$valueOf(f);
s="" + new Float(f).toString();
if (s.indexOf(".") < 0 && s.indexOf("E") < 0 ) s += ".0";
return s;
}var i = Integer.parseInt(s);
return (this.asObject ? Integer.$valueOf(i) : "" + i);
} catch (e) {
}
}}return (this.asObject ? s : (I$[1]||$incl$(1)).esc$S(s));
});

Clazz.newMeth(C$, 'fixLineFolding$S', function (str) {
if (str.indexOf("\\") < 0) return str;
var n = str.length$();
if (str.endsWith$S("\\\u0001")) str=str.substring(0, n - 1) + "\n\1";
var pt = 0;
while ((pt=str.indexOf("\\", pt + 1)) >= 0){
var eol = str.indexOf("\u000a", pt);
if (eol < 0) break;
for (var i = eol; --i > pt; ) {
var ch = str.charAt(i);
if (!(I$[1]||$incl$(1)).isWhitespace$C(ch)) {
if (ch == "\\") {
pt=i;
break;
}pt=eol;
break;
}}
if (pt < eol) str=str.substring(0, pt) + str.substring(eol + 1);
}
return str;
});

Clazz.newMeth(C$, 'getArrayFromStringList$S$I', function (s, n) {
var f = Clazz.array(Float.TYPE, [n]);
(I$[1]||$incl$(1)).parseFloatArrayInfested$SA$FA((I$[1]||$incl$(1)).getTokens$S(s.$replace(",", " ").$replace("[", " ")), f);
var d = Clazz.array(Double.TYPE, [n]);
for (var i = 0; i < n; i++) d[i]=f[i];

return d;
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-07-22 20:21:42 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
