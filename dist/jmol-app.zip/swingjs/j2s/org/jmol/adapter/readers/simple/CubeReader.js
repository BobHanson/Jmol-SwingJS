(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.simple"),I$=[['javajs.util.PT']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "CubeReader", null, 'org.jmol.adapter.smarter.AtomSetCollectionReader');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.ac = 0;
this.isAngstroms = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.isAngstroms = false;
}, 1);

Clazz.newMeth(C$, 'initializeReader', function () {
this.asc.newAtomSet();
p$.readTitleLines.apply(this, []);
p$.readAtomCountAndOrigin.apply(this, []);
this.readLines$I(3);
p$.readAtoms.apply(this, []);
this.applySymmetryAndSetTrajectory();
this.continuing=false;
});

Clazz.newMeth(C$, 'readTitleLines', function () {
if (this.rd().indexOf("#JVXL") == 0) while (this.rd().indexOf("#") == 0){
}
this.checkCurrentLineForScript();
var name = this.line.trim();
this.rd();
this.checkCurrentLineForScript();
this.asc.setAtomSetName$S(name + " - " + this.line.trim() );
});

Clazz.newMeth(C$, 'readAtomCountAndOrigin', function () {
this.rd();
this.isAngstroms=(this.line.indexOf("ANGSTROMS") >= 0);
var tokens = this.getTokens();
if (tokens[0].charAt(0) == "+") tokens[0]=tokens[0].substring(1);
this.ac=Math.abs(this.parseIntStr$S(tokens[0]));
});

Clazz.newMeth(C$, 'readAtoms', function () {
var f = (this.isAngstroms ? 1 : 0.5291772);
for (var i = 0; i < this.ac; ++i) {
var tokens = (I$[1]||$incl$(1)).getTokens$S(this.rd());
this.setAtomCoordScaled$org_jmol_adapter_smarter_Atom$SA$I$F(null, tokens, 2, f).elementNumber=($s$[0] = this.parseIntStr$S(tokens[0]), $s$[0]);
}
});
var $s$ = new Int16Array(1);

Clazz.newMeth(C$);
})();
//Created 2018-07-22 20:21:44 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
