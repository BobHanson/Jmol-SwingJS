(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.xml"),I$=[[0,'org.xml.sax.InputSource','org.jmol.util.Logger']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "XmlHandler", null, 'org.xml.sax.helpers.DefaultHandler');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.xmlReader=null;
this.debugContext=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.debugContext="";
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'parseXML$org_jmol_adapter_readers_xml_XmlReader$O$java_io_BufferedReader', function (xmlReader, saxReaderObj, reader) {
this.xmlReader=xmlReader;
var saxReader=saxReaderObj;
saxReader.setFeature$S$Z("http://xml.org/sax/features/validation", false);
saxReader.setFeature$S$Z("http://xml.org/sax/features/namespaces", true);
saxReader.setEntityResolver$org_xml_sax_EntityResolver(this);
saxReader.setContentHandler$org_xml_sax_ContentHandler(this);
saxReader.setErrorHandler$org_xml_sax_ErrorHandler(this);
var is=Clazz.new_(Clazz.load('org.xml.sax.InputSource').c$$java_io_Reader,[reader]);
is.setSystemId$S("foo");
saxReader.parse$org_xml_sax_InputSource(is);
});

Clazz.newMeth(C$, 'startDocument$', function () {
});

Clazz.newMeth(C$, 'endDocument$', function () {
this.xmlReader.endDocument$();
});

Clazz.newMeth(C$, 'startElement$S$S$S$org_xml_sax_Attributes', function (namespaceURI, localName, nodeName, attributes) {
this.xmlReader.atts.clear$();
for (var i=attributes.getLength$(); --i >= 0; ) this.xmlReader.atts.put$TK$TV(attributes.getLocalName$I(i).toLowerCase$(), attributes.getValue$I(i));

if (Clazz.load('org.jmol.util.Logger').debugging) {
this.debugContext += " " + localName;
$I$(2).debug$S("start " + this.debugContext);
}this.xmlReader.processStartElement$S$S(localName.toLowerCase$(), nodeName.toLowerCase$());
});

Clazz.newMeth(C$, 'endElement$S$S$S', function (uri, localName, qName) {
if ($I$(2).debugging) {
if ($I$(2).debugging) {
$I$(2).debug$S("end " + this.debugContext);
}this.debugContext=this.debugContext.substring$I$I(0, this.debugContext.lastIndexOf$S(" "));
}this.xmlReader.processEndElement$S(localName.toLowerCase$());
});

Clazz.newMeth(C$, 'characters$CA$I$I', function (ch, start, length) {
if (this.xmlReader.keepChars) this.xmlReader.chars.appendCB$CA$I$I(ch, start, length);
});

Clazz.newMeth(C$, 'resolveEntity$S$S$S$S', function (name, publicId, baseURI, systemId) {
if ($I$(2).debugging) {
$I$(2).debug$S("Not resolving this:\n      name: " + name + "\n  systemID: " + systemId + "\n  publicID: " + publicId + "\n   baseURI: " + baseURI );
}return null;
});

Clazz.newMeth(C$, 'error$org_xml_sax_SAXParseException', function (exception) {
$I$(2).error$S("SAX ERROR:" + exception.getMessage$());
});

Clazz.newMeth(C$, 'fatalError$org_xml_sax_SAXParseException', function (exception) {
$I$(2).error$S("SAX FATAL:" + exception.getMessage$());
});

Clazz.newMeth(C$, 'warning$org_xml_sax_SAXParseException', function (exception) {
$I$(2).warn$S("SAX WARNING:" + exception.getMessage$());
});
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-27 03:04:54 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
