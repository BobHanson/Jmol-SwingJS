(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.simple"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "TinkerReader", null, 'org.jmol.adapter.readers.simple.FoldingXyzReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-08-23 15:03:03 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
