(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.pymol"),I$=[['java.util.Hashtable','javajs.util.BS']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "PyMOLGroup");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.name = null;
this.objectNameID = null;
this.list = null;
this.object = null;
this.visible = false;
this.occluded = false;
this.bsAtoms = null;
this.firstAtom = 0;
this.type = 0;
this.parent = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.list = Clazz.new_((I$[1]||$incl$(1)));
this.visible = true;
this.occluded = false;
this.bsAtoms = Clazz.new_((I$[2]||$incl$(2)));
}, 1);

Clazz.newMeth(C$, 'c$$S', function (name) {
C$.$init$.apply(this);
this.name=name;
}, 1);

Clazz.newMeth(C$, 'addList$org_jmol_adapter_readers_pymol_PyMOLGroup', function (child) {
var group = this.list.get$O(child.name);
if (group != null ) return;
this.list.put$TK$TV(child.name, child);
child.parent=this;
});

Clazz.newMeth(C$, 'set', function () {
if (this.parent != null ) return;
});

Clazz.newMeth(C$, 'addGroupAtoms$javajs_util_BS', function (bs) {
this.bsAtoms.or$javajs_util_BS(bs);
if (this.parent != null ) this.parent.addGroupAtoms$javajs_util_BS(this.bsAtoms);
});

Clazz.newMeth(C$, 'toString', function () {
return this.name;
});

Clazz.newMeth(C$);
})();
//Created 2018-07-22 20:21:43 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
