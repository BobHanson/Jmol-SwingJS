(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.pymol"),I$=[];
var C$=Clazz.newClass(P$, "PyMOLGroup");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.name=null;
this.objectNameID=null;
this.list=null;
this.object=null;
this.visible=false;
this.occluded=false;
this.bsAtoms=null;
this.firstAtom=0;
this.type=0;
this.parent=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.list=Clazz.new_(Clazz.load('java.util.Hashtable'));
this.visible=true;
this.occluded=false;
this.bsAtoms=Clazz.new_(Clazz.load('javajs.util.BS'));
}, 1);

Clazz.newMeth(C$, 'c$$S', function (name) {
C$.$init$.apply(this);
this.name=name;
}, 1);

Clazz.newMeth(C$, 'addList$org_jmol_adapter_readers_pymol_PyMOLGroup', function (child) {
var group=this.list.get$O(child.name);
if (group != null ) return;
this.list.put$TK$TV(child.name, child);
child.parent=this;
});

Clazz.newMeth(C$, 'set$', function () {
if (this.parent != null ) return;
});

Clazz.newMeth(C$, 'addGroupAtoms$javajs_util_BS', function (bs) {
this.bsAtoms.or$javajs_util_BS(bs);
if (this.parent != null ) this.parent.addGroupAtoms$javajs_util_BS(this.bsAtoms);
});

Clazz.newMeth(C$, 'toString', function () {
return this.name;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-20 14:22:17 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
