(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.cif"),I$=[];
var C$=Clazz.newClass(P$, "Cif2Reader", null, 'org.jmol.adapter.readers.cif.CifReader');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getCifDataParser$', function () {
return Clazz.new_(Clazz.load('org.jmol.adapter.readers.cif.Cif2DataParser')).set$javajs_api_GenericLineReader$java_io_BufferedReader$Z(this, null, this.debugging);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-20 14:22:16 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
