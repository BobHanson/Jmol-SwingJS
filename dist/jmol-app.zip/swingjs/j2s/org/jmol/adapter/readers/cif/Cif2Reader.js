(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.cif"),I$=[['org.jmol.adapter.readers.cif.Cif2DataParser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Cif2Reader", null, 'org.jmol.adapter.readers.cif.CifReader');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getCifDataParser', function () {
return Clazz.new_((I$[1]||$incl$(1))).set$javajs_api_GenericLineReader$java_io_BufferedReader$Z(this, null, this.debugging);
});

Clazz.newMeth(C$);
})();
//Created 2018-07-22 20:21:42 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
