(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.quantum"),I$=[['org.jmol.api.JmolAdapter','java.util.Hashtable','javajs.util.Lst','org.jmol.adapter.readers.quantum.BasisFunctionReader','javajs.util.PT','javajs.util.AU','org.jmol.util.Logger',['org.jmol.adapter.readers.quantum.QchemReader','.MOInfo'],'org.jmol.quantum.QS']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "QchemReader", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.jmol.adapter.readers.quantum.MOReader');
var p$=C$.prototype;
C$.$DC_LIST = null;
C$.$DS_LIST = null;
C$.$FC_LIST = null;
C$.$FS_LIST = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.$DC_LIST = "DXX   DYY   DZZ   DXY   DXZ   DYZ";
C$.$DS_LIST = "D3    D4    D2    D5    D1";
C$.$FC_LIST = "XXX   YYY   ZZZ   XYY   XXY   XXZ   XZZ   YZZ   YYZ   XYZ";
C$.$FS_LIST = "F4    F5    F3    F6    F2    F7    F1";
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.calculationNumber = 0;
this.isFirstJob = false;
this.alphas = null;
this.betas = null;
this.nBasis = 0;
this.dFixed = false;
this.fFixed = false;
this.dList = null;
this.fList = null;
this.dSpherical = false;
this.fSpherical = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.calculationNumber = 1;
this.isFirstJob = true;
this.alphas = null;
this.betas = null;
this.nBasis = 0;
this.dFixed = false;
this.fFixed = false;
this.dList = "";
this.fList = "";
this.dSpherical = false;
this.fSpherical = false;
}, 1);

Clazz.newMeth(C$, 'initializeReader', function () {
this.energyUnits="au";
});

Clazz.newMeth(C$, 'checkLine', function () {
if (this.line.indexOf("Standard Nuclear Orientation") >= 0) {
p$.readAtoms.apply(this, []);
this.moData=null;
return true;
}if (this.line.indexOf("Total energy") >= 0 || this.line.indexOf("total energy") >= 0  || this.line.indexOf("Energy is") >= 0 ) {
if (this.line.indexOf("Excitation") == -1) p$.readEnergy.apply(this, []);
return true;
}if (this.line.indexOf("Requested basis set is") >= 0) {
p$.readCalculationType.apply(this, []);
return true;
}if (this.line.indexOf("VIBRATIONAL FREQUENCIES") >= 0) {
p$.readFrequencies.apply(this, []);
return true;
}if (this.line.indexOf("Mulliken Net Atomic Charges") >= 0) {
p$.readPartialCharges.apply(this, []);
return true;
}if (this.line.startsWith$S("Job ") || this.line.startsWith$S("Running Job") ) {
if (this.isFirstJob && this.line.startsWith$S("Running") ) this.calculationNumber=0;
this.calculationNumber++;
this.isFirstJob=false;
this.moData=null;
return true;
}if (this.line.indexOf("Basis set in general basis input format") >= 0) {
if (this.moData == null ) {
p$.readBasis.apply(this, []);
}return true;
}if (this.moData == null ) return true;
if (this.line.indexOf("Orbital Energies (a.u.) and Symmetries") >= 0) {
p$.readESym$Z.apply(this, [true]);
return true;
}if (this.line.indexOf("Orbital Energies (a.u.)") >= 0) {
p$.readESym$Z.apply(this, [false]);
return true;
}if (this.line.indexOf("MOLECULAR ORBITAL COEFFICIENTS") >= 0) {
if (this.filterMO()) p$.readQchemMolecularOrbitals.apply(this, []);
return true;
}return this.checkNboLine();
});

Clazz.newMeth(C$, 'readCalculationType', function () {
this.calculationType=this.line.substring(this.line.indexOf("set is") + 6).trim();
});

Clazz.newMeth(C$, 'readAtoms', function () {
this.asc.newAtomSet();
this.setMOData$Z(true);
this.dFixed=this.fFixed=false;
this.readLines$I(2);
var tokens;
while (this.rd() != null  && !this.line.startsWith$S(" --") ){
tokens=this.getTokens();
if (tokens.length < 5) continue;
var symbol = tokens[1];
if ((I$[1]||$incl$(1)).getElementNumber$S(symbol) > 0) this.addAtomXYZSymName$SA$I$S$S(tokens, 2, symbol, null);
}
this.asc.setAtomSetModelProperty$S$S(".PATH", "Job " + this.calculationNumber);
});

Clazz.newMeth(C$, 'readFrequencies', function () {
while (this.rd() != null  && this.line.indexOf("STANDARD") < 0 ){
if (!this.line.startsWith$S(" Frequency:")) this.discardLinesUntilStartsWith$S(" Frequency:");
var frequencies = this.getTokens();
var frequencyCount = frequencies.length - 1;
var ignore = Clazz.array(Boolean.TYPE, [frequencyCount]);
var ac = this.asc.getLastAtomSetAtomCount();
var iAtom0 = this.asc.ac;
for (var i = 0; i < frequencyCount; ++i) {
ignore[i]=!this.doGetVibration$I(++this.vibrationNumber);
if (ignore[i]) continue;
this.asc.cloneLastAtomSet();
this.asc.setAtomSetFrequency$I$S$S$S$S(this.vibrationNumber, "Job " + this.calculationNumber, null, frequencies[i + 1], null);
}
this.discardLinesUntilStartsWith$S("               X");
this.fillFrequencyData$I$I$I$ZA$Z$I$I$IA$I$SAA(iAtom0, ac, ac, ignore, true, 0, 0, null, 0, null);
this.discardLinesUntilBlank();
}
});

Clazz.newMeth(C$, 'readPartialCharges', function () {
this.readLines$I(3);
var atoms = this.asc.atoms;
var ac = this.asc.getLastAtomSetAtomCount();
for (var i = 0; i < ac && this.rd() != null  ; ++i) atoms[i].partialCharge=this.parseFloatStr$S(this.getTokens()[2]);

});

Clazz.newMeth(C$, 'readEnergy', function () {
var ac = this.asc.getLastAtomSetAtomCount();
var tokens = this.getTokens();
var energyKey = "E(" + tokens[0] + ")" ;
var energyString = tokens[tokens.length - 1];
this.asc.setAtomSetEnergy$S$F(energyString, this.parseFloatStr$S(energyString));
this.asc.setAtomSetName$S(energyKey + " = " + energyString );
this.asc.setModelInfoForSet$S$O$I("name", energyKey + " " + energyString , ac);
});

Clazz.newMeth(C$, 'readBasis', function () {
this.moData=Clazz.new_((I$[2]||$incl$(2)));
var ac = 1;
var shellCount = 0;
var gaussianCount = 0;
this.shells=Clazz.new_((I$[3]||$incl$(3)));
var gdata = Clazz.new_((I$[3]||$incl$(3)));
var tokens;
this.discardLinesUntilStartsWith$S("$basis");
this.rd();
while (this.rd() != null ){
if (this.line.startsWith$S("****")) {
ac++;
if (this.rd() != null  && this.line.startsWith$S("$end") ) break;
continue;
}shellCount++;
var slater = Clazz.array(Integer.TYPE, [4]);
tokens=this.getTokens();
slater[0]=ac;
slater[1]=(I$[4]||$incl$(4)).getQuantumShellTagID$S(tokens[0]);
slater[2]=gaussianCount + 1;
var nGaussians = this.parseIntStr$S(tokens[1]);
slater[3]=nGaussians;
this.shells.addLast$TV(slater);
gaussianCount+=nGaussians;
for (var i = 0; i < nGaussians; i++) {
gdata.addLast$TV((I$[5]||$incl$(5)).getTokens$S(this.rd()));
}
}
this.gaussians=(I$[6]||$incl$(6)).newFloat2$I(gaussianCount);
for (var i = 0; i < gaussianCount; i++) {
tokens=gdata.get$I(i);
this.gaussians[i]=Clazz.array(Float.TYPE, [tokens.length]);
for (var j = 0; j < tokens.length; j++) this.gaussians[i][j]=this.parseFloatStr$S(tokens[j]);

}
if (this.debugging) {
(I$[7]||$incl$(7)).debug$S(shellCount + " slater shells read");
(I$[7]||$incl$(7)).debug$S(gaussianCount + " gaussian primitives read");
}this.discardLinesUntilStartsWith$S(" There are");
tokens=this.getTokens();
this.nBasis=this.parseIntStr$S(tokens[5]);
});

Clazz.newMeth(C$, 'readESym$Z', function (haveSym) {
this.alphas=Clazz.array((I$[8]||$incl$(8)), [this.nBasis]);
this.betas=Clazz.array((I$[8]||$incl$(8)), [this.nBasis]);
var moInfos;
var ne = 0;
var readBetas = false;
this.discardLinesUntilStartsWith$S(" Alpha");
var tokens = this.getTokens();
moInfos=this.alphas;
for (var e = 0; e < 2; e++) {
var nMO = 0;
while (this.rd() != null ){
if (this.line.startsWith$S(" -- ")) {
ne=0;
if (this.line.indexOf("Vacant") < 0) {
if (this.line.indexOf("Occupied") > 0) ne=1;
}this.rd();
}if (this.line.startsWith$S(" -------")) {
e=2;
break;
}var nOrbs = this.getTokens().length;
if (nOrbs == 0 || this.line.startsWith$S(" Warning") ) {
this.discardLinesUntilStartsWith$S(" Beta");
readBetas=true;
moInfos=this.betas;
break;
}if (haveSym) tokens=(I$[5]||$incl$(5)).getTokens$S(this.rd());
for (var i = 0, j = 0; i < nOrbs; i++, j+=2) {
var info = Clazz.new_((I$[8]||$incl$(8)), [this, null]);
info.ne=ne;
if (haveSym) info.moSymmetry=tokens[j] + tokens[j + 1] + " " ;
moInfos[nMO]=info;
nMO++;
}
}
}
if (!readBetas) this.betas=this.alphas;
});

Clazz.newMeth(C$, 'readQchemMolecularOrbitals', function () {
var orbitalType = this.getTokens()[0];
this.alphaBeta="A";
p$.readMOs$Z$org_jmol_adapter_readers_quantum_QchemReader_MOInfoA.apply(this, [orbitalType.equals$O("RESTRICTED"), this.alphas]);
if (orbitalType.equals$O("ALPHA")) {
this.discardLinesUntilContains$S("BETA");
this.alphaBeta="B";
p$.readMOs$Z$org_jmol_adapter_readers_quantum_QchemReader_MOInfoA.apply(this, [false, this.betas]);
}var isOK = true;
if (this.dList.length$() > 0) {
if (this.dSpherical) isOK=this.getDFMap$S$S$I$S$I("DS", this.dList, 3, C$.$DS_LIST, 2);
 else isOK=this.getDFMap$S$S$I$S$I("DC", this.dList, 4, C$.$DC_LIST, 3);
if (!isOK) {
(I$[7]||$incl$(7)).error$S("atomic orbital order is unrecognized -- skipping reading of MOs. dList=" + this.dList);
this.shells=null;
}}if (this.fList.length$() > 0) {
if (this.fSpherical) isOK=this.getDFMap$S$S$I$S$I("FS", this.fList, 5, C$.$FS_LIST, 2);
 else isOK=this.getDFMap$S$S$I$S$I("FC", this.fList, 6, C$.$FC_LIST, 3);
if (!isOK) {
(I$[7]||$incl$(7)).error$S("atomic orbital order is unrecognized -- skipping reading of MOs. fList=" + this.fList);
this.shells=null;
}}this.setMOData$Z(this.shells == null );
this.shells=null;
});

Clazz.newMeth(C$, 'readMOs$Z$org_jmol_adapter_readers_quantum_QchemReader_MOInfoA', function (restricted, moInfos) {
var mos = (I$[6]||$incl$(6)).createArrayOfHashtable$I(6);
var mocoef = (I$[6]||$incl$(6)).newFloat2$I(6);
var moid = Clazz.array(Integer.TYPE, [6]);
var tokens;
var energy;
var nMOs = 0;
while (this.rd().length$() > 2){
tokens=this.getTokens();
var nMO = tokens.length;
energy=(I$[5]||$incl$(5)).getTokens$S(this.rd().substring(13));
for (var i = 0; i < nMO; i++) {
moid[i]=this.parseIntStr$S(tokens[i]) - 1;
mocoef[i]=Clazz.array(Float.TYPE, [this.nBasis]);
mos[i]=Clazz.new_((I$[2]||$incl$(2)));
}
for (var i = 0, pt = 0; i < this.nBasis; i++) {
tokens=(I$[5]||$incl$(5)).getTokens$S(this.rd());
var s = this.line.substring(12, 17).trim();
var ch = s.charAt(0);
switch (ch.$c()) {
case 100:
s=s.substring(s.length$() - 3).toUpperCase();
if (s.startsWith$S("D ")) {
if (!this.dFixed) this.fixSlaterTypes$I$I(4, 3);
s="D" + s.charAt(2);
this.dSpherical=true;
}if (this.dList.indexOf(s) < 0) this.dList += s + " ";
this.dFixed=true;
break;
case 102:
s=s.substring(s.length$() - 3).toUpperCase();
if (s.startsWith$S("F ")) {
if (!this.fFixed) this.fixSlaterTypes$I$I(6, 5);
s="F" + s.charAt(2);
this.fSpherical=true;
}if (this.fList.indexOf(s) < 0) this.fList += s + " ";
this.fFixed=true;
break;
default:
if (!(I$[9]||$incl$(9)).isQuantumBasisSupported$C(ch)) continue;
break;
}
for (var j = tokens.length - nMO, k = 0; k < nMO; j++, k++) mocoef[k][pt]=this.parseFloatStr$S(tokens[j]);

pt++;
}
for (var i = 0; i < nMO; i++) {
var moInfo = moInfos[moid[i]];
mos[i].put$TK$TV("energy", Float.$valueOf(energy[i]));
mos[i].put$TK$TV("coefficients", mocoef[i]);
var label = this.alphaBeta;
var ne = moInfo.ne;
if (restricted) ne=this.alphas[moid[i]].ne + this.betas[moid[i]].ne;
mos[i].put$TK$TV("occupancy", Float.$valueOf(ne));
switch (ne) {
case 2:
label="AB";
break;
case 1:
break;
case 0:
if (restricted) label="V";
 else label="V" + label;
break;
}
mos[i].put$TK$TV("symmetry", moInfo.moSymmetry + label + "(" + (moid[i] + 1) + ")" );
this.orbitals.addLast$TV(mos[i]);
}
nMOs+=nMO;
}
return nMOs;
});
;
(function(){var C$=Clazz.newClass(P$.QchemReader, "MOInfo", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.ne = 0;
this.moSymmetry = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.ne = 0;
this.moSymmetry = "";
}, 1);

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
//Created 2018-07-22 20:21:44 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
