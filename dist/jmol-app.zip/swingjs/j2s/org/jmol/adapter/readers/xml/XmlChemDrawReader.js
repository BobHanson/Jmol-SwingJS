(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.xml"),p$1={},I$=[[0,'javajs.util.Lst','javajs.util.BS','org.jmol.adapter.smarter.Atom','org.jmol.api.JmolAdapter','javajs.util.PT']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "XmlChemDrawReader", null, 'org.jmol.adapter.readers.xml.XmlReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.minX=1.7976931348623157E308;
this.minY=1.7976931348623157E308;
this.minZ=1.7976931348623157E308;
this.maxZ=-1.7976931348623157E308;
this.maxY=-1.7976931348623157E308;
this.maxX=-1.7976931348623157E308;
this.bonds=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['Z',['optimize2D','is3D'],'D',['minX','minY','minZ','maxZ','maxY','maxX'],'O',['bonds','javajs.util.Lst','warningAtom','org.jmol.adapter.smarter.Atom']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'processXml$org_jmol_adapter_readers_xml_XmlReader$O',  function (parent, saxReader) {
this.optimize2D=this.checkFilterKey$S("2D");
this.processXml2$org_jmol_adapter_readers_xml_XmlReader$O(parent, saxReader);
this.filter=parent.filter;
});

Clazz.newMeth(C$, 'processStartElement$S$S',  function (localName, nodeName) {
if ("fragment".equals$O(localName)) {
return;
}if ("n".equals$O(localName)) {
if (this.asc.bsAtoms == null ) this.asc.bsAtoms=Clazz.new_($I$(2,1));
var nodeType=this.atts.get$O("nodetype");
if ("Fragment".equals$O(nodeType)) return;
var isNickname="Nickname".equals$O(nodeType);
var isConnectionPt="ExternalConnectionPoint".equals$O(nodeType);
var warning=this.atts.get$O("warning");
this.atom=Clazz.new_($I$(3,1));
this.atom.atomName=this.atts.get$O("id");
var element=this.atts.get$O("element");
this.atom.elementNumber=($s$[0] = (warning != null  ? 0 : element == null  ? 6 : Integer.parseInt$S(element)), $s$[0]);
element=$I$(4).getElementSymbol$I(this.atom.elementNumber);
var isotope=this.atts.get$O("isotope");
if (isotope != null ) element=isotope + element;
this.setElementAndIsotope$org_jmol_adapter_smarter_Atom$S(this.atom, element);
var s=this.atts.get$O("charge");
if (s != null ) {
this.atom.formalCharge=Integer.parseInt$S(s);
}if (this.atts.containsKey$O("xyz")) {
this.is3D=true;
p$1.setAtom$S.apply(this, ["xyz"]);
} else if (this.atts.containsKey$O("p")) {
p$1.setAtom$S.apply(this, ["p"]);
}this.asc.addAtomWithMappedName$org_jmol_adapter_smarter_Atom(this.atom);
if (warning != null ) {
this.atom.atomName=$I$(5).rep$S$S$S(warning, "&apos;", "\'");
this.warningAtom=this.atom;
} else {
this.warningAtom=null;
}if (!isConnectionPt && !isNickname ) {
this.asc.bsAtoms.set$I(this.atom.index);
}return;
}if ("s".equals$O(localName)) {
if (this.warningAtom != null ) {
this.setKeepChars$Z(true);
}}if ("b".equals$O(localName)) {
var atom1=this.atts.get$O("b");
var atom2=this.atts.get$O("e");
var invertEnds=false;
var order=(this.atts.containsKey$O("order") ? this.parseIntStr$S(this.atts.get$O("order")) : 1);
var buf=this.atts.get$O("display");
if (buf != null ) {
if (buf.equals$O("WedgeEnd")) {
invertEnds=true;
order=1025;
} else if (buf.equals$O("WedgeBegin")) {
order=1025;
} else if (buf.equals$O("Hash") || buf.equals$O("WedgedHashBegin") ) {
order=1041;
} else if (buf.equals$O("WedgedHashEnd")) {
invertEnds=true;
order=1041;
}}this.bonds.addLast$O(Clazz.array(java.lang.Object, -1, [(invertEnds ? atom2 : atom1), (invertEnds ? atom1 : atom2), Integer.valueOf$I(order)]));
return;
}});

Clazz.newMeth(C$, 'setAtom$S',  function (key) {
var xyz=this.atts.get$O(key);
var tokens=$I$(5).getTokens$S(xyz);
var x=this.parseDoubleStr$S(tokens[0]);
var y=-this.parseDoubleStr$S(tokens[1]);
var z=(key === "xyz"  ? this.parseDoubleStr$S(tokens[2]) : 0);
if (x < this.minX ) this.minX=x;
if (x > this.maxX ) this.maxX=x;
if (y < this.minY ) this.minY=y;
if (y > this.maxY ) this.maxY=y;
if (z < this.minZ ) this.minZ=z;
if (z > this.maxZ ) this.maxZ=z;
this.atom.set$D$D$D(x, y, z);
}, p$1);

Clazz.newMeth(C$, 'processEndElement$S',  function (localName) {
if ("s".equals$O(localName)) {
if (this.warningAtom != null ) {
var group=this.chars.toString();
this.warningAtom.atomName+=": " + group;
this.parent.appendLoadNote$S("Warning: " + this.warningAtom.atomName);
this.warningAtom=null;
}}this.setKeepChars$Z(false);
});

Clazz.newMeth(C$, 'finalizeSubclassReader$',  function () {
p$1.fixConnections.apply(this, []);
p$1.center.apply(this, []);
System.out.println$S("bsAtoms = " + this.asc.bsAtoms);
this.asc.setInfo$S$O("minimize3D", Boolean.valueOf$Z(this.is3D));
this.set2D$();
this.asc.setInfo$S$O("is2D", Boolean.valueOf$Z(!this.is3D));
if (!this.is3D) this.asc.setModelInfoForSet$S$O$I("dimension", "2D", this.asc.iSet);
this.parent.appendLoadNote$S("ChemDraw CDXML: " + (this.is3D ? "3D" : "2D"));
});

Clazz.newMeth(C$, 'fixConnections',  function () {
for (var i=0, n=this.bonds.size$(); i < n; i++) {
var o=this.bonds.get$I(i);
var b=this.asc.addNewBondFromNames$S$S$I(o[0], o[1], (o[2]).intValue$());
if (b == null ) continue;
var a1=this.asc.atoms[b.atomIndex1];
var a2=this.asc.atoms[b.atomIndex2];
var pt=(!this.asc.bsAtoms.get$I(b.atomIndex1) ? a1 : !this.asc.bsAtoms.get$I(b.atomIndex2) ? a2 : null);
if (pt == null ) continue;
for (var j=this.asc.bsAtoms.nextSetBit$I(0); j >= 0; j=this.asc.bsAtoms.nextSetBit$I(j + 1)) {
var a=this.asc.atoms[j];
if (Math.abs(a.x - pt.x) < 0.1  && Math.abs(a.y - pt.y) < 0.1  ) {
if (pt === a1 ) {
b.atomIndex1=(a1=a).index;
} else {
b.atomIndex2=(a2=a).index;
}break;
}}
b.distance=a1.distance$javajs_util_T3d(a2);
}
}, p$1);

Clazz.newMeth(C$, 'center',  function () {
if (this.minX > this.maxX ) return;
var sum=0;
var n=0;
if (this.is3D) {
for (var i=this.asc.bondCount; --i >= 0; ) {
if (this.asc.atoms[this.asc.bonds[i].atomIndex1].elementNumber > 1 && this.asc.atoms[this.asc.bonds[i].atomIndex2].elementNumber > 1 ) {
sum+=this.asc.bonds[i].distance;
++n;
}}
}var f=1;
if (sum > 0 ) {
f=1.45 * n / sum;
}var cx=(this.maxX + this.minX) / 2;
var cy=(this.maxY + this.minY) / 2;
var cz=(this.maxZ + this.minZ) / 2;
for (var i=this.asc.ac; --i >= 0; ) {
var a=this.asc.atoms[i];
a.x=(a.x - cx) * f;
a.y=(a.y - cy) * f;
a.z=(a.z - cz) * f;
}
}, p$1);
var $s$ = new Int16Array(1);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-08-23 15:03:03 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
