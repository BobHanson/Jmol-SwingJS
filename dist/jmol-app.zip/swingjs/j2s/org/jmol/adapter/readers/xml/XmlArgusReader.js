(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.xml"),p$1={},I$=[[0,'org.jmol.adapter.smarter.Atom']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "XmlArgusReader", null, 'org.jmol.adapter.readers.xml.XmlReader');
C$.keepCharsList=null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.keepCharsList=Clazz.array(String, -1, ["name", "x", "y", "z", "formalchg", "atomkey", "atsym", "e00", "e01", "e02", "e03", "e10", "e11", "e12", "e13", "e20", "e21", "e22", "e23", "e30", "e31", "e32", "e33"]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.atomName1=null;
this.atomName2=null;
this.bondOrder=0;
this.elementContext=0;
this.trans=null;
this.ptTrans=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'processStartElement$S$S', function (localName, nodeName) {
for (var i=C$.keepCharsList.length; --i >= 0; ) if (C$.keepCharsList[i].equals$O(localName)) {
this.setKeepChars$Z(true);
break;
}
if ("molecule".equals$O(localName)) {
this.asc.newAtomSet$();
return;
}if ("atom".equals$O(localName)) {
this.elementContext=2;
this.atom=Clazz.new_(Clazz.load('org.jmol.adapter.smarter.Atom'));
return;
}if ("bond".equals$O(localName)) {
this.elementContext=3;
this.atomName1=null;
this.atomName2=null;
this.bondOrder=p$1.parseBondToken$S.apply(this, [this.atts.get$O("order")]);
return;
}if ("transformmat".equals$O(localName)) {
this.elementContext=4;
this.trans=Clazz.array(Float.TYPE, [16]);
return;
}});

Clazz.newMeth(C$, 'parseBondToken$S', function (str) {
var floatOrder=this.parseFloatStr$S(str);
if (Float.isNaN$F(floatOrder) && str.length$() >= 1 ) {
str=str.toUpperCase$();
switch ((str.charCodeAt$I(0))) {
case 83:
return 1;
case 68:
return 2;
case 84:
return 3;
case 65:
return 515;
}
return this.parseIntStr$S(str);
}if (floatOrder == 1.5 ) return 515;
if (floatOrder == 2 ) return 2;
if (floatOrder == 3 ) return 3;
return 1;
}, p$1);

Clazz.newMeth(C$, 'processEndElement$S', function (localName) {
var n=this.chars.length$();
if (n > 0 && this.chars.charAt$I(n - 1) == "\n" ) this.chars.setLength$I(n - 1);
if ("molecule".equals$O(localName)) {
this.elementContext=0;
return;
}if ("atom".equals$O(localName)) {
if (this.atom.elementSymbol != null  && !Float.isNaN$F(this.atom.z) ) {
this.parent.setAtomCoord$org_jmol_adapter_smarter_Atom(this.atom);
this.asc.addAtomWithMappedName$org_jmol_adapter_smarter_Atom(this.atom);
}this.atom=null;
this.elementContext=0;
return;
}if ("bond".equals$O(localName)) {
if (this.atomName2 != null ) this.asc.addNewBondFromNames$S$S$I(this.atomName1, this.atomName2, this.bondOrder);
this.elementContext=0;
return;
}if ("transformmat".equals$O(localName)) {
this.elementContext=0;
this.parent.setTransform$F$F$F$F$F$F$F$F$F(this.trans[0], this.trans[1], this.trans[2], this.trans[4], this.trans[5], this.trans[6], this.trans[8], this.trans[9], this.trans[10]);
return;
}if (this.elementContext == 1) {
if ("name".equals$O(localName)) {
this.asc.setAtomSetName$S(this.chars.toString());
this.setKeepChars$Z(false);
}return;
}if (this.atom != null  && this.elementContext == 2 ) {
if ("x".equals$O(localName)) {
this.atom.x=this.parseFloatStr$S(this.chars.toString());
} else if ("y".equals$O(localName)) {
this.atom.y=this.parseFloatStr$S(this.chars.toString());
return;
} else if ("z".equals$O(localName)) {
this.atom.z=this.parseFloatStr$S(this.chars.toString());
return;
} else if ("atsym".equals$O(localName)) {
this.atom.elementSymbol=this.chars.toString();
return;
} else if ("formalchg".equals$O(localName)) {
this.atom.formalCharge=this.parseIntStr$S(this.chars.toString());
} else if ("atomkey".equals$O(localName)) {
this.atom.atomName=this.chars.toString();
}this.setKeepChars$Z(false);
return;
}if (this.elementContext == 3) {
if ("atomkey".equals$O(localName)) {
if (this.atomName1 == null ) this.atomName1=this.chars.toString();
 else this.atomName2=this.chars.toString();
this.setKeepChars$Z(false);
}return;
}if (this.elementContext == 4) {
this.trans[this.ptTrans++]=this.parseFloatStr$S(this.chars.toString());
this.setKeepChars$Z(false);
return;
}});
})();
;Clazz.setTVer('3.2.4.04');//Created 2018-11-15 12:06:58 Java2ScriptVisitor version 3.2.4.04 net.sf.j2s.core.jar version 3.2.4.04
