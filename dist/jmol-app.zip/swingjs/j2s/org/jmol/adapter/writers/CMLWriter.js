(function(){var P$=Clazz.newPackage("org.jmol.adapter.writers"),I$=[[0,'javajs.util.SB','org.jmol.viewer.Viewer','org.jmol.api.Interface','javajs.util.BS','javajs.util.PT','org.jmol.util.Edge']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CMLWriter", null, null, 'org.jmol.api.JmolWriter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['addBonds','doTransform','allTrajectories'],'I',['atomsMax'],'O',['vwr','org.jmol.viewer.Viewer','oc','javajs.util.OC']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'set$org_jmol_viewer_Viewer$javajs_util_OC$OA',  function (viewer, out, data) {
this.vwr=viewer;
this.oc=(this.oc == null  ? this.vwr.getOutputChannel$S$SA(null, null) : this.oc);
this.atomsMax=(data[0]).intValue$();
this.addBonds=(data[1]).booleanValue$();
this.doTransform=(data[2]).booleanValue$();
this.allTrajectories=(data[3]).booleanValue$();
});

Clazz.newMeth(C$, 'write$javajs_util_BS',  function (bs) {
var sb=Clazz.new_($I$(1,1));
var nAtoms=bs.cardinality$();
if (nAtoms == 0) return "";
if ($I$(2).isJS) $I$(3).getInterface$S$org_jmol_viewer_Viewer$S("javajs.util.XmlUtil", this.vwr, "file");
C$.openTag$javajs_util_SB$S(sb, "molecule");
C$.openTag$javajs_util_SB$S(sb, "atomArray");
var bsAtoms=Clazz.new_($I$(4,1));
var atoms=this.vwr.ms.at;
for (var i=bs.nextSetBit$I(0); i >= 0; i=bs.nextSetBit$I(i + 1)) {
if (--this.atomsMax < 0) break;
var atom=atoms[i];
var name=atom.getAtomName$();
$I$(5).rep$S$S$S(name, "\"", "\'\'");
bsAtoms.set$I(atom.i);
C$.appendTag$javajs_util_SB$S$SA(sb, "atom", Clazz.array(String, -1, ["id", "a" + (atom.i + 1), "title", atom.getAtomName$(), "elementType", atom.getElementSymbol$(), "x3", "" + new Double(atom.x).toString(), "y3", "" + new Double(atom.y).toString(), "z3", "" + new Double(atom.z).toString()]));
}
C$.closeTag$javajs_util_SB$S(sb, "atomArray");
if (this.addBonds) {
C$.openTag$javajs_util_SB$S(sb, "bondArray");
var bondCount=this.vwr.ms.bondCount;
var bonds=this.vwr.ms.bo;
for (var i=0; i < bondCount; i++) {
var bond=bonds[i];
var a1=bond.atom1;
var a2=bond.atom2;
if (!bsAtoms.get$I(a1.i) || !bsAtoms.get$I(a2.i) ) continue;
var order=$I$(6).getCmlBondOrder$I(bond.order);
if (order == null ) continue;
C$.appendTag$javajs_util_SB$S$SA(sb, "bond", Clazz.array(String, -1, ["atomRefs2", "a" + (bond.atom1.i + 1) + " a" + (bond.atom2.i + 1) , "order", order]));
}
C$.closeTag$javajs_util_SB$S(sb, "bondArray");
}C$.closeTag$javajs_util_SB$S(sb, "molecule");
return sb.toString();
});

Clazz.newMeth(C$, 'openTag$javajs_util_SB$S',  function (sb, name) {
sb.append$S("<").append$S(name).append$S(">\n");
}, 1);

Clazz.newMeth(C$, 'appendTag$javajs_util_SB$S$SA',  function (sb, name, attributes) {
sb.append$S("<").append$S(name);
for (var i=0; i < attributes.length; i++) {
sb.append$S(" ").append$S(attributes[i]).append$S("=\"").append$S(attributes[++i]).append$S("\"");
}
sb.append$S("/>\n");
}, 1);

Clazz.newMeth(C$, 'closeTag$javajs_util_SB$S',  function (sb, name) {
sb.append$S("</").append$S(name).append$S(">\n");
}, 1);

Clazz.newMeth(C$, 'toString',  function () {
return (this.oc == null  ? "" : this.oc.toString());
});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-08-23 15:03:04 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
