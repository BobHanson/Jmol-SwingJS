(function(){var P$=Clazz.newPackage("org.jmol.modelsetbio"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "PhosphorusPolymer", null, 'org.jmol.modelsetbio.BioPolymer');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$org_jmol_modelsetbio_MonomerA', function (monomers) {
Clazz.super_(C$, this);
this.set$org_jmol_modelsetbio_MonomerA(monomers);
this.hasStructure=true;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-05-29 12:12:26 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
