(function(){var P$=Clazz.newPackage("org.jmol.modelsetbio"),I$=[];
var C$=Clazz.newClass(P$, "CarbohydratePolymer", null, 'org.jmol.modelsetbio.BioPolymer');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$org_jmol_modelsetbio_MonomerA', function (monomers) {
Clazz.super_(C$, this,1);
this.set$org_jmol_modelsetbio_MonomerA(monomers);
this.type=3;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-27 03:05:05 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
