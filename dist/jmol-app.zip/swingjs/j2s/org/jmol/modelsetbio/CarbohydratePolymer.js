(function(){var P$=Clazz.newPackage("org.jmol.modelsetbio"),I$=[];
var C$=Clazz.newClass(P$, "CarbohydratePolymer", null, 'org.jmol.modelsetbio.BioPolymer');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$org_jmol_modelsetbio_MonomerA', function (monomers) {
Clazz.super_(C$, this,1);
this.set$org_jmol_modelsetbio_MonomerA(monomers);
this.type=3;
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-07-22 20:21:56 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
