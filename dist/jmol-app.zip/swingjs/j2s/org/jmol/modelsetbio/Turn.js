(function(){var P$=Clazz.newPackage("org.jmol.modelsetbio"),I$=[[0,'org.jmol.c.STR']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Turn", null, 'org.jmol.modelsetbio.ProteinStructure');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$org_jmol_modelsetbio_AlphaPolymer$I$I', function (apolymer, monomerIndex, monomerCount) {
Clazz.super_(C$, this,1);
this.setupPS$org_jmol_modelsetbio_AlphaPolymer$org_jmol_c_STR$I$I(apolymer, $I$(1).TURN, monomerIndex, monomerCount);
this.subtype=$I$(1).TURN;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-07-14 10:23:43 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
