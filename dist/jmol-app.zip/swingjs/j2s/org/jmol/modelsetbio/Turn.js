(function(){var P$=Clazz.newPackage("org.jmol.modelsetbio"),I$=[[0,'org.jmol.c.STR']],$I$=function(i,n){return(i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i};
/*c*/var C$=Clazz.newClass(P$, "Turn", null, 'org.jmol.modelsetbio.ProteinStructure');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$org_jmol_modelsetbio_AlphaPolymer$I$I', function (apolymer, monomerIndex, monomerCount) {
Clazz.super_(C$, this);
this.setupPS$org_jmol_modelsetbio_AlphaPolymer$org_jmol_c_STR$I$I(apolymer, $I$(1).TURN, monomerIndex, monomerCount);
this.subtype=$I$(1).TURN;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-18 20:01:14 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
