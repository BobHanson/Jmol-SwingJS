(function(){var P$=Clazz.newPackage("org.jmol.awt"),I$=[[0,'org.jmol.awt.AwtPopupHelper']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AwtJmolPopup", null, 'org.jmol.popup.JmolPopup');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.helper=Clazz.new_($I$(1,1).c$$org_jmol_popup_GenericPopup,[this]);
}, 1);

Clazz.newMeth(C$, 'addMenu$S$S$org_jmol_api_SC$S$org_jmol_popup_PopupResource',  function (id, item, subMenu, label, popupResourceBundle) {
var c=subMenu;
c.deferred=true;
c.jm.addMenuListener$javax_swing_event_MenuListener(((P$.AwtJmolPopup$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "AwtJmolPopup$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'javax.swing.event.MenuListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'menuSelected$javax_swing_event_MenuEvent',  function (e) {
if (this.$finals$.c.deferred) {
this.$finals$.c.deferred=false;
if (this.$finals$.item.indexOf$S("Computed") < 0) this.b$['org.jmol.popup.GenericPopup'].addMenuItems$S$S$org_jmol_api_SC$org_jmol_popup_PopupResource.apply(this.b$['org.jmol.popup.GenericPopup'], [this.$finals$.id, this.$finals$.item, this.$finals$.subMenu, this.$finals$.popupResourceBundle]);
this.b$['org.jmol.popup.JmolPopup'].appCheckSpecialMenu$S$org_jmol_api_SC$S.apply(this.b$['org.jmol.popup.JmolPopup'], [this.$finals$.item, this.$finals$.subMenu, this.$finals$.label]);
this.b$['org.jmol.awt.AwtJmolPopup'].updateAwtMenus$S.apply(this.b$['org.jmol.awt.AwtJmolPopup'], [this.$finals$.item]);
}});

Clazz.newMeth(C$, 'menuDeselected$javax_swing_event_MenuEvent',  function (e) {
});

Clazz.newMeth(C$, 'menuCanceled$javax_swing_event_MenuEvent',  function (e) {
});
})()
), Clazz.new_(P$.AwtJmolPopup$1.$init$,[this, {popupResourceBundle:popupResourceBundle,subMenu:subMenu,item:item,label:label,id:id,c:c}])));
});

Clazz.newMeth(C$, 'updateAwtMenus$S',  function (item) {
switch ((item.charCodeAt$I(0))) {
case 99:
this.updateConfigurationComputedMenu$();
break;
case 102:
this.updateFileMenu$();
break;
case 101:
this.updateElementsComputedMenu$javajs_util_BS(this.vwr.getElementsPresentBitSet$I(this.modelIndex));
break;
case 70:
this.updateFRAMESbyModelComputedMenu$();
break;
case 108:
this.updateLanguageSubmenu$();
break;
case 109:
this.updateModelSetComputedMenu$();
break;
case 80:
if (item.equals$O("PDBheteroComputedMenu")) this.updateHeteroComputedMenu$java_util_Map(this.vwr.ms.getHeteroList$I(this.modelIndex));
 else if (item.equals$O("PDBnucleicResiduesComputedMenu")) this.updatePDBResidueComputedMenus$();
 else if (item.equals$O("PDBaaResiduesComputedMenu")) this.updatePDBResidueComputedMenus$();
 else if (item.equals$O("PDBaaResiduesComputedMenu")) this.updatePDBResidueComputedMenus$();
break;
case 115:
switch ((item.charCodeAt$I(1))) {
case 112:
this.updateSpectraMenu$();
break;
case 99:
this.updateSceneComputedMenu$();
break;
case 101:
this.updatePDBResidueComputedMenus$();
break;
case 117:
this.updateSurfMoComputedMenu$java_util_Map(this.modelInfo.get$O("moData"));
break;
case 121:
this.updateAboutSubmenu$();
break;
}
break;
case 83:
if (item.indexOf$S("Select") >= 0) this.updateSYMMETRYSelectComputedMenu$();
 else this.updateSYMMETRYShowComputedMenu$();
break;
}
this.updateFileTypeDependentMenus$();
for (var i=this.Special.size$(); --i >= 0; ) this.updateSpecialMenuItem$org_jmol_api_SC(this.Special.get$I(i));

});

Clazz.newMeth(C$, 'menuShowPopup$org_jmol_api_SC$I$I',  function (popup, x, y) {
try {
((popup).jc).show$java_awt_Component$I$I(this.vwr.display, x, y);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'getUnknownCheckBoxScriptToRun$org_jmol_api_SC$S$S$Z',  function (item, name, what, TF) {
return null;
});

Clazz.newMeth(C$, 'getImageIcon$S',  function (fileName) {
return null;
});

Clazz.newMeth(C$, 'menuFocusCallback$S$S$Z',  function (name, actionCommand, b) {
});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-08-23 15:03:05 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
