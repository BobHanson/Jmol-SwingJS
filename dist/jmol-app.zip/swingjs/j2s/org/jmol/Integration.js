(function(){var P$=Clazz.newPackage("org.jmol"),I$=[[0,'java.awt.Dimension','org.jmol.api.JmolViewer','org.jmol.adapter.smarter.SmarterJmolAdapter','javax.swing.JFrame',['org.jmol.Integration','.ApplicationCloser'],['org.jmol.Integration','.JmolPanel'],'javax.swing.JPanel','java.awt.BorderLayout','org.openscience.jmol.app.jmolpanel.console.AppConsole','org.jmol.util.Logger']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Integration", function(){
Clazz.newInstance(this, arguments,0,C$);
});

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'main$SA', function (argv) {
var frame=Clazz.new_(Clazz.load('javax.swing.JFrame').c$$S,["Hello"]);
frame.addWindowListener$java_awt_event_WindowListener(Clazz.new_(Clazz.load(['org.jmol.Integration','.ApplicationCloser'])));
frame.setSize$I$I(410, 700);
var contentPane=frame.getContentPane$();
var jmolPanel=Clazz.new_(Clazz.load(['org.jmol.Integration','.JmolPanel']));
jmolPanel.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(1).c$$I$I,[400, 400]));
var panel=Clazz.new_(Clazz.load('javax.swing.JPanel'));
panel.setLayout$java_awt_LayoutManager(Clazz.new_(Clazz.load('java.awt.BorderLayout')));
panel.add$java_awt_Component(jmolPanel);
var panel2=Clazz.new_($I$(7));
panel2.setLayout$java_awt_LayoutManager(Clazz.new_($I$(8)));
panel2.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(1).c$$I$I,[400, 300]));
var console=Clazz.new_(Clazz.load('org.openscience.jmol.app.jmolpanel.console.AppConsole').c$$org_jmol_api_JmolViewer$java_awt_Container$S,[jmolPanel.viewer, panel2, "History State Clear"]);
jmolPanel.viewer.setJmolCallbackListener$org_jmol_api_JmolCallbackListener(console);
panel.add$S$java_awt_Component("South", panel2);
contentPane.add$java_awt_Component(panel);
frame.setVisible$Z(true);
var strError=jmolPanel.viewer.openFile$S("http://chemapps.stolaf.edu/jmol/docs/examples-11/data/caffeine.xyz");
if (strError == null ) jmolPanel.viewer.evalString$S("delay; move 360 0 0 0 0 0 0 0 4;");
 else Clazz.load('org.jmol.util.Logger').error$S(strError);
}, 1);
;
(function(){var C$=Clazz.newClass(P$.Integration, "ApplicationCloser", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'java.awt.event.WindowAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'windowClosing$java_awt_event_WindowEvent', function (e) {
System.exit$I(0);
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.Integration, "JmolPanel", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'javax.swing.JPanel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.viewer=null;
this.currentSize=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.currentSize=Clazz.new_(Clazz.load('java.awt.Dimension'));
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.viewer=Clazz.load('org.jmol.api.JmolViewer').allocateViewer$O$org_jmol_api_JmolAdapter$S$java_net_URL$java_net_URL$S$org_jmol_api_JmolStatusListener(this, Clazz.new_(Clazz.load('org.jmol.adapter.smarter.SmarterJmolAdapter')), null, null, null, null, null);
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
this.getSize$java_awt_Dimension(this.currentSize);
this.viewer.renderScreenImage$O$I$I(g, this.currentSize.width, this.currentSize.height);
});
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.04');//Created 2018-11-15 12:07:26 Java2ScriptVisitor version 3.2.4.04 net.sf.j2s.core.jar version 3.2.4.04
