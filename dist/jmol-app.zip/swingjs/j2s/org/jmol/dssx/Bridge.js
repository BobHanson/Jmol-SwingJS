(function(){var P$=Clazz.newPackage("org.jmol.dssx"),I$=[['java.lang.Boolean','org.jmol.util.Escape']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Bridge");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.a = null;
this.b = null;
this.ladder = null;
this.isAntiparallel = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$org_jmol_modelset_Atom$org_jmol_modelset_Atom$java_util_Map', function (a, b, htLadders) {
C$.$init$.apply(this);
this.a=a;
this.b=b;
this.ladder=Clazz.array(Integer.TYPE, [2, 2]);
this.ladder[0][0]=this.ladder[0][1]=Math.min(a.i, b.i);
this.ladder[1][0]=this.ladder[1][1]=Math.max(a.i, b.i);
p$.addLadder$java_util_Map.apply(this, [htLadders]);
}, 1);

Clazz.newMeth(C$, 'addBridge$org_jmol_dssx_Bridge$java_util_Map', function (bridge, htLadders) {
if (bridge.isAntiparallel != this.isAntiparallel  || !p$.canAdd$org_jmol_dssx_Bridge.apply(this, [bridge])  || !bridge.canAdd$org_jmol_dssx_Bridge(this) ) return false;
p$.extendLadder$I$I.apply(this, [bridge.ladder[0][0], bridge.ladder[1][0]]);
p$.extendLadder$I$I.apply(this, [bridge.ladder[0][1], bridge.ladder[1][1]]);
bridge.ladder=this.ladder;
if (bridge.ladder !== this.ladder ) {
htLadders.remove$O(bridge.ladder);
p$.addLadder$java_util_Map.apply(this, [htLadders]);
}return true;
});

Clazz.newMeth(C$, 'addLadder$java_util_Map', function (htLadders) {
htLadders.put$TK$TV(this.ladder, (this.isAntiparallel ? (I$[1]||$incl$(1)).TRUE : (I$[1]||$incl$(1)).FALSE));
});

Clazz.newMeth(C$, 'canAdd$org_jmol_dssx_Bridge', function (bridge) {
var index1 = bridge.a.i;
var index2 = bridge.b.i;
return (this.isAntiparallel ? (index1 >= this.ladder[0][1] && index2 <= this.ladder[1][0]  || index1 <= this.ladder[0][0] && index2 >= this.ladder[1][1]  ) : (index1 <= this.ladder[0][0] && index2 <= this.ladder[1][0]  || index1 >= this.ladder[0][1] && index2 >= this.ladder[1][1]  ));
});

Clazz.newMeth(C$, 'extendLadder$I$I', function (index1, index2) {
if (this.ladder[0][0] > index1) this.ladder[0][0]=index1;
if (this.ladder[0][1] < index1) this.ladder[0][1]=index1;
if (this.ladder[1][0] > index2) this.ladder[1][0]=index2;
if (this.ladder[1][1] < index2) this.ladder[1][1]=index2;
});

Clazz.newMeth(C$, 'toString', function () {
return (this.isAntiparallel ? "a " : "p ") + this.a + " - " + this.b + "\t" + (I$[2]||$incl$(2)).e$O(this.ladder) ;
});

Clazz.newMeth(C$);
})();
//Created 2018-07-22 20:21:49 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
