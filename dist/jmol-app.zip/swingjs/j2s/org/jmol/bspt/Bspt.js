(function(){var P$=Clazz.newPackage("org.jmol.bspt"),I$=[['org.jmol.bspt.Leaf','org.jmol.bspt.CubeIterator']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Bspt");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.treeDepth = 0;
this.dimMax = 0;
this.index = 0;
this.eleRoot = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I$I', function (dimMax, index) {
C$.$init$.apply(this);
this.dimMax=dimMax;
this.index=index;
this.reset();
}, 1);

Clazz.newMeth(C$, 'reset', function () {
this.eleRoot=Clazz.new_((I$[1]||$incl$(1)).c$$org_jmol_bspt_Bspt$org_jmol_bspt_Leaf$I,[this, null, 0]);
this.treeDepth=1;
});

Clazz.newMeth(C$, 'addTuple$javajs_util_T3', function (tuple) {
this.eleRoot=this.eleRoot.addTuple$I$javajs_util_T3(0, tuple);
});

Clazz.newMeth(C$, 'stats', function () {
});

Clazz.newMeth(C$, 'allocateCubeIterator', function () {
return Clazz.new_((I$[2]||$incl$(2)).c$$org_jmol_bspt_Bspt,[this]);
});

Clazz.newMeth(C$);
})();
//Created 2018-07-22 20:21:49 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
