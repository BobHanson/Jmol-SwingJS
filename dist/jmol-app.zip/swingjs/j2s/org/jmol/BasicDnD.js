(function(){var P$=Clazz.newPackage("org.jmol"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "BasicDnD");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-05-29 12:12:39 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
