(function(){var P$=Clazz.newPackage("org.jmol"),I$=[['junit.framework.TestSuite','org.jmol.adapter.smarter.TestSmarterJmolAdapter','org.jmol.api.TestScripts','org.jmol.smiles.TestSmilesParser','org.jmol.util.AllTests']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "AllTests");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'suite', function () {
var suite = Clazz.new_((I$[1]||$incl$(1)).c$$S,["Test for org.jmol"]);
suite.addTest$junit_framework_Test((I$[2]||$incl$(2)).suite());
suite.addTest$junit_framework_Test((I$[3]||$incl$(3)).suite());
suite.addTestSuite$Class(Clazz.getClass((I$[4]||$incl$(4))));
suite.addTest$junit_framework_Test((I$[5]||$incl$(5)).suite());
return suite;
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-07-22 20:22:13 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
