(function(){var P$=Clazz.newPackage("org.jmol"),I$=[];
var C$=Clazz.newClass(P$, "AllTests");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'suite$', function () {
var suite=Clazz.new_(Clazz.load('junit.framework.TestSuite').c$$S,["Test for org.jmol"]);
suite.addTest$junit_framework_Test(Clazz.load('org.jmol.adapter.smarter.TestSmarterJmolAdapter').suite$());
suite.addTest$junit_framework_Test(Clazz.load('org.jmol.api.TestScripts').suite$());
suite.addTestSuite$Class(Clazz.getClass(Clazz.load('org.jmol.smiles.TestSmilesParser')));
suite.addTest$junit_framework_Test(Clazz.load('org.jmol.util.AllTests').suite$());
return suite;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-27 03:05:20 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
