(function(){var P$=Clazz.newPackage("org.jmol.awtjs2d"),I$=[['javajs.util.OC','org.jmol.viewer.Viewer','javajs.util.PT']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "JSFile", null, null, 'org.jmol.api.GenericFileInterface');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.name = null;
this.fullName = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'newFile$S', function (name) {
return Clazz.new_(C$.c$$S,[name]);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (name) {
C$.$init$.apply(this);
this.name=name.$replace("\\", "/");
this.fullName=name;
if (!this.fullName.startsWith$S("/") && (I$[1]||$incl$(1)).urlTypeIndex$S(name) < 0 ) this.fullName=(I$[2]||$incl$(2)).jsDocumentBase + "/" + this.fullName ;
this.fullName=(I$[3]||$incl$(3)).rep$S$S$S(this.fullName, "/./", "/");
name=name.substring(name.lastIndexOf("/") + 1);
}, 1);

Clazz.newMeth(C$, 'getParentAsFile', function () {
var pt = this.fullName.lastIndexOf("/");
return (pt < 0 ? null : Clazz.new_(C$.c$$S,[this.fullName.substring(0, pt)]));
});

Clazz.newMeth(C$, 'getFullPath', function () {
return this.fullName;
});

Clazz.newMeth(C$, 'getName', function () {
return this.name;
});

Clazz.newMeth(C$, 'isDirectory', function () {
return this.fullName.endsWith$S("/");
});

Clazz.newMeth(C$, 'length$', function () {
return 0;
});

Clazz.newMeth(C$, 'getURLContents$java_net_URL$BA$S', function (url, outputBytes, post) {
try {
var conn = url.openConnection();
if (outputBytes != null ) conn.outputBytes$BA(outputBytes);
 else if (post != null ) conn.outputString$S(post);
return conn.getContents();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
return e.toString();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-07-22 20:21:48 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
