(function(){var P$=Clazz.newPackage("org.jmol.i18n"),I$=[['org.jmol.viewer.Viewer','org.jmol.util.Logger','org.jmol.api.Interface','java.util.Hashtable','javajs.util.PT']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Resource");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.resource = null;
this.resourceMap = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$O$S', function (resource, className) {
C$.$init$.apply(this);
if (className == null ) this.resourceMap=resource;
 else this.resource=resource;
}, 1);

Clazz.newMeth(C$, 'getResource$org_jmol_viewer_Viewer$S$S', function (vwr, className, name) {
var poData = null;
if (vwr != null  && vwr.isApplet ) {
var fname = (I$[1]||$incl$(1)).appletIdiomaBase + "/" + name + ".po" ;
(I$[2]||$incl$(2)).info$S("Loading language resource " + fname);
poData=vwr.getFileAsString3$S$Z$S(fname, false, "gt");
return C$.getResourceFromPO$S(poData);
}className += name + ".Messages_" + name ;
var o = (I$[3]||$incl$(3)).getInterface$S$org_jmol_viewer_Viewer$S(className, vwr, "gt");
return (o == null  ? null : Clazz.new_(C$.c$$O$S,[o, className]));
}, 1);

Clazz.newMeth(C$, 'getString$S', function (string) {
try {
return (this.resource == null  ? this.resourceMap.get$O(string) : this.resource.getString$S(string));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
return null;
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'getLanguage', function () {
var language = null;
{
language = Jmol.featureDetection.getDefaultLanguage().replace(/-/g,'_');
}
return language;
}, 1);

Clazz.newMeth(C$, 'getResourceFromPO$S', function (data) {
if (data == null  || data.length$() == 0 ) return null;
var map = Clazz.new_((I$[4]||$incl$(4)));
try {
var lines = (I$[5]||$incl$(5)).split$S$S(data, "\u000a");
var mode = 0;
var msgstr = "";
var msgid = "";
for (var i = 0; i < lines.length; i++) {
var line = lines[i];
if (line.length$() <= 2) {
if (mode == 2 && msgstr.length$() != 0  && msgid.length$() != 0 ) map.put$TK$TV(msgid, msgstr);
mode=0;
} else if (line.indexOf("msgid") == 0) {
mode=1;
msgid=C$.fix$S(line);
} else if (line.indexOf("msgstr") == 0) {
mode=2;
msgstr=C$.fix$S(line);
} else if (mode == 1) {
msgid += C$.fix$S(line);
} else if (mode == 2) {
msgstr += C$.fix$S(line);
}}
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
(I$[2]||$incl$(2)).info$S(map.size() + " translations loaded");
return (map.size() == 0 ? null : Clazz.new_(C$.c$$O$S,[map, null]));
}, 1);

Clazz.newMeth(C$, 'fix$S', function (line) {
if (line.indexOf("\\\"") >= 0) line=(I$[5]||$incl$(5)).rep$S$S$S(line, "\\\"", "\"");
return (I$[5]||$incl$(5)).rep$S$S$S(line.substring(line.indexOf("\"") + 1, line.lastIndexOf("\"")), "\\n", "\u000a");
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-07-22 20:21:51 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
