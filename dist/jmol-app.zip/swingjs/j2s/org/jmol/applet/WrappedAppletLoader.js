(function(){var P$=Clazz.newPackage("org.jmol.applet"),I$=[['org.jmol.util.Logger','org.jmol.applet.TickerThread','org.jmol.api.Interface','Thread']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "WrappedAppletLoader", null, 'Thread');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.applet = null;
this.isSigned = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_applet_Applet$Z', function (applet, isSigned) {
Clazz.super_(C$, this,1);
this.applet=applet;
this.isSigned=isSigned;
}, 1);

Clazz.newMeth(C$, 'run', function () {
var startTime = System.currentTimeMillis();
if ((I$[1]||$incl$(1)).debugging) {
(I$[1]||$incl$(1)).debug$S("WrappedAppletLoader.run(org.jmol.applet.Jmol)");
}var tickerThread = Clazz.new_((I$[2]||$incl$(2)).c$$java_applet_Applet,[this.applet]);
tickerThread.start();
try {
var jmol = (this.applet).wrappedApplet=(I$[3]||$incl$(3)).getOption$S$org_jmol_viewer_Viewer$S("applet.Jmol", null, null);
jmol.setApplet$java_applet_Applet$Z(this.applet, this.isSigned);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
(I$[1]||$incl$(1)).errorEx$S$Throwable("Could not instantiate applet", e);
} else {
throw e;
}
}
var loadTimeSeconds = ((System.currentTimeMillis() - startTime + 500)/1000|0);
if ((I$[1]||$incl$(1)).debugging) (I$[1]||$incl$(1)).debug$S("applet load time = " + loadTimeSeconds + " seconds" );
tickerThread.keepRunning=false;
tickerThread.interrupt();
this.applet.repaint();
});

Clazz.newMeth(C$);
})();
//Created 2018-07-22 20:21:47 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
