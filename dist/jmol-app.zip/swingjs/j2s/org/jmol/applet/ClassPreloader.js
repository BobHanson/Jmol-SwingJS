(function(){var P$=Clazz.newPackage("org.jmol.applet"),I$=[['org.jmol.util.Logger']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ClassPreloader", null, 'Thread');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.appletWrapper = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$org_jmol_applet_AppletWrapper', function (appletWrapper) {
Clazz.super_(C$, this,1);
this.appletWrapper=appletWrapper;
}, 1);

Clazz.newMeth(C$, 'run', function () {
var className;
this.setPriority$I(this.getPriority() - 1);
while ((className=this.appletWrapper.getNextPreloadClassName()) != null ){
try {
var lastCharIndex = className.length$() - 1;
var constructOne = className.charAt(lastCharIndex) == "+";
System.out.println$S("ClassPreloader - " + className);
if (constructOne) className=className.substring(0, lastCharIndex);
var preloadClass = Clazz.forName(className);
if (constructOne) preloadClass.newInstance();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
(I$[1]||$incl$(1)).fatalEx$S$Throwable("error preloading " + className, e);
} else {
throw e;
}
}
}
});

Clazz.newMeth(C$);
})();
//Created 2018-07-22 20:21:47 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
