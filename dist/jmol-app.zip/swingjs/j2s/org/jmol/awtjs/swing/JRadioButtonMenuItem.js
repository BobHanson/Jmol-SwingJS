(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[];
var C$=Clazz.newClass(P$, "JRadioButtonMenuItem", null, 'org.jmol.awtjs.swing.JMenuItem');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.isRadio = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.isRadio = true;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$$S$I.apply(this, ["rad", 3]);
C$.$init$.apply(this);
}, 1);
})();
//Created 2018-07-22 20:21:48 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
