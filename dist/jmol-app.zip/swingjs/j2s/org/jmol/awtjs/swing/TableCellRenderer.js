(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "TableCellRenderer");
})();
;Clazz.setTVer('3.2.5-v1');//Created 2019-11-26 23:53:12 Java2ScriptVisitor version 3.2.5-v1 net.sf.j2s.core.jar version 3.2.5-v1
