(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[['javajs.util.SB']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "JButton", null, 'org.jmol.awtjs.swing.AbstractButton');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$$S.apply(this, ["btnJB"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'toHTML', function () {
var sb = Clazz.new_((I$[1]||$incl$(1)));
sb.append$S("<input type=button id='" + this.id + "' class='JButton' style='" + this.getCSSstyle$I$I(80, 0) + "' onclick='SwingController.click(this)' value='" + this.text + "'/>" );
return sb.toString();
});
})();
//Created 2018-07-22 20:21:48 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
