(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[];
var C$=Clazz.newClass(P$, "JMenuItem", null, 'org.jmol.awtjs.swing.AbstractButton');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.btnType = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (text) {
C$.superclazz.c$$S.apply(this, ["btn"]);
C$.$init$.apply(this);
this.setText$S(text);
this.btnType=(text == null  ? 0 : 1);
}, 1);

Clazz.newMeth(C$, 'c$$S$I', function (type, i) {
C$.superclazz.c$$S.apply(this, [type]);
C$.$init$.apply(this);
this.btnType=i;
}, 1);

Clazz.newMeth(C$, 'toHTML', function () {
return this.htmlMenuOpener$S("li") + (this.text == null  ? "" : "<a>" + p$.htmlLabel.apply(this, []) + "</a>" ) + "</li>" ;
});

Clazz.newMeth(C$, 'getHtmlDisabled', function () {
return " class=\"ui-state-disabled\"";
});

Clazz.newMeth(C$, 'htmlLabel', function () {
return (this.btnType == 1 ? this.text : "<label><input id=\"" + this.id + "-" + (this.btnType == 3 ? "r" : "c") + "b\" type=\"" + (this.btnType == 3 ? "radio\" name=\"" + this.htmlName : "checkbox") + "\" " + (this.selected ? "checked" : "") + " />" + this.text + "</label>" );
});

Clazz.newMeth(C$);
})();
//Created 2018-07-22 20:21:48 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
