(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[];
var C$=Clazz.newClass(P$, "ButtonGroup");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.id=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.id=Clazz.load('javajs.awt.Component').newID$S("bg");
}, 1);

Clazz.newMeth(C$, 'add$javajs_awt_SC', function (item) {
(item).htmlName=this.id;
});
})();
;Clazz.setTVer('3.2.4.04');//Created 2018-11-15 12:07:02 Java2ScriptVisitor version 3.2.4.04 net.sf.j2s.core.jar version 3.2.4.04
