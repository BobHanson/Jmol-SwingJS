(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[];
var C$=Clazz.newClass(P$, "JLabel", null, 'org.jmol.awtjs.swing.JComponent');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (text) {
C$.superclazz.c$$S.apply(this, ["lblJL"]);
C$.$init$.apply(this);
this.text=text;
}, 1);

Clazz.newMeth(C$, 'toHTML$', function () {
var sb=Clazz.new_(Clazz.load('javajs.util.SB'));
sb.append$S("<span id='" + this.id + "' class='JLabel' style='" + this.getCSSstyle$I$I(0, 0) + "'>" );
sb.append$S(this.text);
sb.append$S("</span>");
return sb.toString();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.06');//Created 2018-09-17 22:03:43 Java2ScriptVisitor version 3.2.2.06 net.sf.j2s.core.jar version 3.2.2.06
