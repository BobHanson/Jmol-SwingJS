(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[[0,'javajs.util.SB']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JLabel", null, 'org.jmol.awtjs.swing.JComponent');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$S',  function (text) {
;C$.superclazz.c$$S.apply(this,["lblJL"]);C$.$init$.apply(this);
this.text=text;
}, 1);

Clazz.newMeth(C$, 'toHTML$',  function () {
var sb=Clazz.new_($I$(1,1));
sb.append$S("<span id='" + this.id + "' class='JLabel' style='" + this.getCSSstyle$I$I(0, 0) + "'>" );
sb.append$S(this.text);
sb.append$S("</span>");
return sb.toString();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-08-23 15:03:05 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
