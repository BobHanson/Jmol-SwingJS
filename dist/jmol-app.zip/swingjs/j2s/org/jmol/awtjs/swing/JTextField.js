(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[];
var C$=Clazz.newClass(P$, "JTextField", null, 'org.jmol.awtjs.swing.JComponent');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (value) {
C$.superclazz.c$$S.apply(this, ["txtJT"]);
C$.$init$.apply(this);
this.text=value;
}, 1);

Clazz.newMeth(C$, 'toHTML$', function () {
var sb=Clazz.new_(Clazz.load('javajs.util.SB'));
sb.append$S("<input type=text id='" + this.id + "' class='JTextField' style='" + this.getCSSstyle$I$I(0, 0) + "' value='" + this.text + "' onkeyup	=SwingController.click(this,event)	>" );
return sb.toString();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.04');//Created 2018-11-15 12:07:02 Java2ScriptVisitor version 3.2.4.04 net.sf.j2s.core.jar version 3.2.4.04
