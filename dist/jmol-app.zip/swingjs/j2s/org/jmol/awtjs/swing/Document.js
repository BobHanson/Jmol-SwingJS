(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Document");
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-05-29 12:12:20 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
