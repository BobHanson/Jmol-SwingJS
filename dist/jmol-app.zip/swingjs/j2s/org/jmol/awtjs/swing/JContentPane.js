(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[[0,'javajs.util.SB']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "JContentPane", null, 'org.jmol.awtjs.swing.JComponent');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$$S.apply(this, ["JCP"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'toHTML$', function () {
var sb=Clazz.new_($I$(1));
sb.append$S("\n<div id='" + this.id + "' class='JContentPane' style='" + this.getCSSstyle$I$I(100, 100) + "'>\n" );
if (this.list != null ) for (var i=0; i < this.list.size$(); i++) sb.append$S(this.list.get$I(i).toHTML$());

sb.append$S("\n</div>\n");
return sb.toString();
});
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-04-16 17:36:50 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
