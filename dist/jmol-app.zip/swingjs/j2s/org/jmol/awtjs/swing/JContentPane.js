(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[];
var C$=Clazz.newClass(P$, "JContentPane", null, 'org.jmol.awtjs.swing.JComponent');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$$S.apply(this, ["JCP"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'toHTML$', function () {
var sb=Clazz.new_(Clazz.load('javajs.util.SB'));
sb.append$S("\n<div id='" + this.id + "' class='JContentPane' style='" + this.getCSSstyle$I$I(100, 100) + "'>\n" );
if (this.list != null ) for (var i=0; i < this.list.size$(); i++) sb.append$S(this.list.get$I(i).toHTML$());

sb.append$S("\n</div>\n");
return sb.toString();
});
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-27 03:04:57 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
