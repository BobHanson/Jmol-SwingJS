(function(){var P$=Clazz.newPackage("org.jmol.console"),I$=[];
var C$=Clazz.newClass(P$, "JmolToggleButton", null, 'javax.swing.JToggleButton', 'org.jmol.api.JmolAbstractButton');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$javax_swing_ImageIcon', function (ii) {
C$.superclazz.c$$javax_swing_Icon.apply(this, [ii]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'addConsoleListener$O', function (console) {
this.addActionListener$java_awt_event_ActionListener(console);
});

Clazz.newMeth(C$, 'getKey$', function () {
return null;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-20 14:22:23 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
