(function(){var P$=Clazz.newPackage("org.jmol.console"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "JmolToggleButton", null, 'javax.swing.JToggleButton', 'org.jmol.api.JmolAbstractButton');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$javax_swing_ImageIcon', function (ii) {
;C$.superclazz.c$$javax_swing_Icon.apply(this,[ii]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'addConsoleListener$O', function (console) {
this.addActionListener$java_awt_event_ActionListener(console);
});

Clazz.newMeth(C$, 'getKey$', function () {
return null;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-18 20:01:07 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
