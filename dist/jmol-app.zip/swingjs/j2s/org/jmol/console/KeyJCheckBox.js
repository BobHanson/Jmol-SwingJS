(function(){var P$=Clazz.newPackage("org.jmol.console"),I$=[['org.jmol.console.GenericConsole']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "KeyJCheckBox", null, 'javax.swing.JCheckBox', 'org.jmol.api.JmolAbstractButton');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.key = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getKey', function () {
return this.key;
});

Clazz.newMeth(C$, 'c$$S$S$java_util_Map$Z', function (key, label, menuMap, isChecked) {
C$.superclazz.c$$S$Z.apply(this, [(I$[1]||$incl$(1)).getLabelWithoutMnemonic$S(label), isChecked]);
C$.$init$.apply(this);
(I$[1]||$incl$(1)).map$O$S$S$java_util_Map(this, this.key=key, label, menuMap);
}, 1);

Clazz.newMeth(C$, 'addConsoleListener$O', function (console) {
});

Clazz.newMeth(C$);
})();
//Created 2018-07-22 20:21:49 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
