(function(){var P$=Clazz.newPackage("org.jmol.console"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "JmolLabel", null, 'javax.swing.JLabel', 'org.jmol.api.JmolAbstractButton');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$S$I',  function (text, horizontalAlignment) {
;C$.superclazz.c$$S$I.apply(this,[text, horizontalAlignment]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getKey$',  function () {
return null;
});

Clazz.newMeth(C$, 'isSelected$',  function () {
return false;
});

Clazz.newMeth(C$, 'setMnemonic$C',  function (mnemonic) {
});

Clazz.newMeth(C$, 'addConsoleListener$O',  function (console) {
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-08-23 15:03:06 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
