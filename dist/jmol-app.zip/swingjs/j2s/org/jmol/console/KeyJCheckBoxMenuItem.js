(function(){var P$=Clazz.newPackage("org.jmol.console"),I$=[[0,'org.jmol.console.GenericConsole']],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "KeyJCheckBoxMenuItem", null, 'javax.swing.JCheckBoxMenuItem', 'org.jmol.api.JmolAbstractButton');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['key']]]

Clazz.newMeth(C$, 'getKey$', function () {
return this.key;
});

Clazz.newMeth(C$, 'c$$S$S$java_util_Map$Z', function (key, label, menuMap, isChecked) {
;C$.superclazz.c$$S$Z.apply(this,[$I$(1).getLabelWithoutMnemonic$S(label), isChecked]);C$.$init$.apply(this);
$I$(1,"map$O$S$S$java_util_Map",[this, this.key=key, label, menuMap]);
}, 1);

Clazz.newMeth(C$, 'addConsoleListener$O', function (console) {
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-05-29 12:12:21 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
