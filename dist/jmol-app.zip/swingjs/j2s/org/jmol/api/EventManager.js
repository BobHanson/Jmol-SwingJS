(function(){var P$=Clazz.newPackage("org.jmol.api"),I$=[];
var C$=Clazz.newInterface(P$, "EventManager");
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-27 03:04:56 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
