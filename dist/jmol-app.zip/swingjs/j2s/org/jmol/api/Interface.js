(function(){var P$=Clazz.newPackage("org.jmol.api"),I$=[['org.jmol.util.Logger']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Interface");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getInterface$S$org_jmol_viewer_Viewer$S', function (name, vwr, state) {
try {
var x = null;
{
x = Clazz._4Name (name, vwr && vwr.html5Applet, state);
}
return (x == null  ? null : x.newInstance());
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
(I$[1]||$incl$(1)).error$S("Interface.java Error creating instance for " + name + ": \n" + e );
return null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getOption$S$org_jmol_viewer_Viewer$S', function (className, vwr, state) {
return C$.getInterface$S$org_jmol_viewer_Viewer$S("org.jmol." + className, vwr, state);
}, 1);

Clazz.newMeth(C$, 'getUtil$S$org_jmol_viewer_Viewer$S', function (name, vwr, state) {
return C$.getInterface$S$org_jmol_viewer_Viewer$S("org.jmol.util." + name, vwr, state);
}, 1);

Clazz.newMeth(C$, 'getSymmetry$org_jmol_viewer_Viewer$S', function (vwr, state) {
return C$.getInterface$S$org_jmol_viewer_Viewer$S("org.jmol.symmetry.Symmetry", vwr, state);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-07-22 20:21:46 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
