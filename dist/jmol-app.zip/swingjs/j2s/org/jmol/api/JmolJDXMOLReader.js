(function(){var P$=Clazz.newPackage("org.jmol.api"),I$=[];
var C$=Clazz.newInterface(P$, "JmolJDXMOLReader");
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-07-14 10:23:32 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
