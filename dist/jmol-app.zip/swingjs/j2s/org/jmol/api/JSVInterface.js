(function(){var P$=Clazz.newPackage("org.jmol.api"),I$=[];
var C$=Clazz.newInterface(P$, "JSVInterface");
})();
;Clazz.setTVer('3.2.4.04');//Created 2018-11-15 12:07:00 Java2ScriptVisitor version 3.2.4.04 net.sf.j2s.core.jar version 3.2.4.04
