(function(){var P$=Clazz.newPackage("org.jmol.api"),I$=[];
var C$=Clazz.newInterface(P$, "JmolJSpecView");
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-20 18:11:28 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
