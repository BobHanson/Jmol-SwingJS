(function(){var P$=Clazz.newPackage("org.jmol.api"),I$=[['Boolean','java.io.File','org.jmol.api.TestScripts$1','org.jmol.api.TestScripts$2','org.jmol.api.TestScriptsImpl','org.jmol.util.JUnitLogger','javax.swing.JFrame','java.util.Hashtable','java.lang.Boolean','org.openscience.jmol.app.Jmol','org.jmol.util.Profiling','java.io.BufferedReader','java.io.FileReader','org.jmol.api.JmolViewer','org.jmol.adapter.smarter.SmarterJmolAdapter']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "TestScriptsImpl", null, 'junit.framework.TestCase');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.file = null;
this.checkOnly = false;
this.performance = false;
this.nbExecutions = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_io_File$Z$Z', function (file, checkOnly, performance) {
C$.superclazz.c$$S.apply(this, ["testFile"]);
C$.$init$.apply(this);
this.file=file;
this.checkOnly=checkOnly;
this.performance=performance;
var nbExec = 1;
try {
nbExec=Integer.parseInt(System.getProperty("test.nbExecutions", "1"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.NumberFormatException")){
} else {
throw e;
}
}
this.nbExecutions=nbExec;
}, 1);

Clazz.newMeth(C$, 'runTest', function () {
this.testScript();
});

Clazz.newMeth(C$, 'testScript', function () {
(I$[6]||$incl$(6)).setInformation$S(this.file.getPath());
if (this.performance) {
this.runPerformanceTest();
return;
}this.runSimpleTest();
});

Clazz.newMeth(C$, 'runPerformanceTest', function () {
var frame = Clazz.new_((I$[7]||$incl$(7)));
var viewerOptions = Clazz.new_((I$[8]||$incl$(8)));
if (this.checkOnly) viewerOptions.put$TK$TV("check", (I$[9]||$incl$(9)).TRUE);
var jmol = (I$[10]||$incl$(10)).getJmol$javax_swing_JFrame$I$I$java_util_Map(frame, 500, 500, viewerOptions);
var viewer = jmol.vwr;
var beginFull = (I$[11]||$incl$(11)).getTime();
for (var i = 0; i < this.nbExecutions; i++) {
viewer.scriptWaitStatus$S$S("set defaultDirectory \"" + this.file.getParent().$replace("\\", "/") + "\"" , "");
var lineNum = 0;
var reader = null;
try {
reader=Clazz.new_((I$[12]||$incl$(12)).c$$java_io_Reader,[Clazz.new_((I$[13]||$incl$(13)).c$$java_io_File,[this.file])]);
var line = null;
var beginScript = (I$[11]||$incl$(11)).getTime();
while ((line=reader.readLine()) != null ){
lineNum++;
var begin = (I$[11]||$incl$(11)).getTime();
if (line.indexOf("TESTBLOCKSTART") >= 0) {
var s = "";
while ((line=reader.readLine()) != null  && line.indexOf("TESTBLOCKEND") < 0 ){
s += line + "\n";
lineNum++;
}
line=s;
}var info = viewer.scriptWaitStatus$S$S(line, "scriptTerminated");
var end = (I$[11]||$incl$(11)).getTime();
if ((info != null ) && (info.size() > 0) ) {
var error = info.get$I(0).toString();
if (Clazz.instanceOf(info.get$I(0), "java.util.List")) {
var vector = info.get$I(0);
if (vector.size() > 0) {
if (Clazz.instanceOf(vector.get$I(0), "java.util.List")) {
vector=vector.get$I(0);
error=vector.get$I(vector.size() - 1).toString();
}}}if (!error.equalsIgnoreCase$S("Jmol script terminated successfully")) {
junit.framework.Assert.fail$S("Error in script [" + this.file.getPath() + "] " + "at line " + lineNum + " (" + line + "):\n" + error );
}}if ((end - begin) > 0) {
p$.outputPerformanceMessage$J$S.apply(this, [end - begin, "execute [" + line + "]" ]);
}}
var endScript = (I$[11]||$incl$(11)).getTime();
p$.outputPerformanceMessage$J$S.apply(this, [endScript - beginScript, "execute script [" + this.file.getPath() + "]" ]);
} catch (e$$) {
if (Clazz.exceptionOf(e$$, "java.io.FileNotFoundException")){
var e = e$$;
{
junit.framework.Assert.fail$S("File " + this.file.getPath() + " not found" );
}
} else if (Clazz.exceptionOf(e$$, "java.io.IOException")){
var e = e$$;
{
junit.framework.Assert.fail$S("Error reading line " + lineNum + " of " + this.file.getPath() );
}
} else {
throw e$$;
}
} finally {
if (reader != null ) {
try {
reader.close();
} catch (e) {
if (Clazz.exceptionOf(e, "java.io.IOException")){
} else {
throw e;
}
}
}}
}
var endFull = (I$[11]||$incl$(11)).getTime();
if (this.nbExecutions > 1) {
p$.outputPerformanceMessage$J$S.apply(this, [endFull - beginFull, this.nbExecutions + " of script"]);
}});

Clazz.newMeth(C$, 'runSimpleTest', function () {
(I$[6]||$incl$(6)).setInformation$S(this.file.getPath());
var viewer = (I$[14]||$incl$(14)).allocateViewer$O$org_jmol_api_JmolAdapter$S$java_net_URL$java_net_URL$S$org_jmol_api_JmolStatusListener(Clazz.new_((I$[7]||$incl$(7))), Clazz.new_((I$[15]||$incl$(15))), null, null, null, this.checkOnly ? "-n -c -l " : "-n -l ", null);
var s = viewer.evalFile$S(this.file.getPath() + " -noqueue");
junit.framework.Assert.assertNull$S$O("Error in script [" + this.file.getPath() + ":\n" + s , s);
});

Clazz.newMeth(C$, 'outputPerformanceMessage$J$S', function (duration, message) {
var time = "            " + duration;
time=time.substring(Math.min(12, time.length$() - 12));
System.err.println$S(time + (I$[11]||$incl$(11)).getUnit() + ": " + message );
});

Clazz.newMeth(C$, 'getName', function () {
if (this.file != null ) {
return C$.superclazz.prototype.getName.apply(this, []) + " [" + this.file.getPath() + "]" ;
}return C$.superclazz.prototype.getName.apply(this, []);
});

Clazz.newMeth(C$, 'setUp', function () {
C$.superclazz.prototype.setUp.apply(this, []);
(I$[6]||$incl$(6)).activateLogger();
(I$[6]||$incl$(6)).setInformation$S(null);
});

Clazz.newMeth(C$, 'tearDown', function () {
C$.superclazz.prototype.tearDown.apply(this, []);
(I$[6]||$incl$(6)).setInformation$S(null);
this.file=null;
});

Clazz.newMeth(C$);
})();
//Created 2018-07-22 20:22:13 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
