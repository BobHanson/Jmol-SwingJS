(function(){var P$=Clazz.newPackage("org.jmol.modelset"),I$=[['org.jmol.util.BSUtil','javajs.util.SB','org.jmol.util.Escape']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "StateScript");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.modelIndex = 0;
this.bsBonds = null;
this.bsAtoms1 = null;
this.bsAtoms2 = null;
this.script1 = null;
this.script2 = null;
this.inDefinedStateBlock = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I$S$javajs_util_BS$javajs_util_BS$javajs_util_BS$S$Z', function (modelIndex, script1, bsBonds, bsAtoms1, bsAtoms2, script2, inDefinedStateBlock) {
C$.$init$.apply(this);
this.modelIndex=modelIndex;
this.script1=script1;
this.bsBonds=(I$[1]||$incl$(1)).copy$javajs_util_BS(bsBonds);
this.bsAtoms1=(I$[1]||$incl$(1)).copy$javajs_util_BS(bsAtoms1);
this.bsAtoms2=(I$[1]||$incl$(1)).copy$javajs_util_BS(bsAtoms2);
this.script2=script2;
this.inDefinedStateBlock=inDefinedStateBlock;
}, 1);

Clazz.newMeth(C$, 'isValid', function () {
return this.script1 != null  && this.script1.length$() > 0  && (this.bsBonds == null  || this.bsBonds.nextSetBit$I(0) >= 0 )  && (this.bsAtoms1 == null  || this.bsAtoms1.nextSetBit$I(0) >= 0 )  && (this.bsAtoms2 == null  || this.bsAtoms2.nextSetBit$I(0) >= 0 ) ;
});

Clazz.newMeth(C$, 'toString', function () {
if (!this.isValid()) return "";
var sb = (I$[2]||$incl$(2)).newS$S(this.script1);
if (this.bsBonds != null ) sb.append$S(" ").append$S((I$[3]||$incl$(3)).eBond$javajs_util_BS(this.bsBonds));
if (this.bsAtoms1 != null ) sb.append$S(" ").append$S((I$[3]||$incl$(3)).eBS$javajs_util_BS(this.bsAtoms1));
if (this.bsAtoms2 != null ) sb.append$S(" ").append$S((I$[3]||$incl$(3)).eBS$javajs_util_BS(this.bsAtoms2));
if (this.script2 != null ) sb.append$S(" ").append$S(this.script2);
var s = sb.toString();
if (!s.endsWith$S(";")) s += ";";
return s;
});

Clazz.newMeth(C$, 'isConnect', function () {
return (this.script1.indexOf("connect") >= 0);
});

Clazz.newMeth(C$, 'deleteAtoms$I$javajs_util_BS$javajs_util_BS', function (modelIndex, bsBonds, bsAtoms) {
if (modelIndex == this.modelIndex) return false;
if (modelIndex > this.modelIndex) {
return true;
}(I$[1]||$incl$(1)).deleteBits$javajs_util_BS$javajs_util_BS(this.bsBonds, bsBonds);
(I$[1]||$incl$(1)).deleteBits$javajs_util_BS$javajs_util_BS(this.bsAtoms1, bsAtoms);
(I$[1]||$incl$(1)).deleteBits$javajs_util_BS$javajs_util_BS(this.bsAtoms2, bsAtoms);
return this.isValid();
});

Clazz.newMeth(C$, 'setModelIndex$I', function (index) {
this.modelIndex=index;
});

Clazz.newMeth(C$);
})();
//Created 2018-07-22 20:21:56 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
