(function(){var P$=Clazz.newPackage("org.jmol.modelset"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "TickInfo");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.id="";
this.type=" ";
this.signFactor=1;
},1);

C$.$fields$=[['D',['first','signFactor'],'S',['id','type'],'O',['ticks','javajs.util.P3d','tickLabelFormats','String[]','scale','javajs.util.P3d','+reference']]]

Clazz.newMeth(C$, 'c$$javajs_util_P3d',  function (ticks) {
;C$.$init$.apply(this);
this.ticks=ticks;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-08-23 15:03:09 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
