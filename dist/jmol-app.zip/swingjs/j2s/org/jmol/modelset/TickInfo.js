(function(){var P$=Clazz.newPackage("org.jmol.modelset"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "TickInfo");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.id="";
this.type=" ";
this.signFactor=1;
},1);

C$.$fields$=[['F',['first','signFactor'],'S',['id','type'],'O',['ticks','javajs.util.P3','tickLabelFormats','String[]','scale','javajs.util.P3','+reference']]]

Clazz.newMeth(C$, 'c$$javajs_util_P3', function (ticks) {
;C$.$init$.apply(this);
this.ticks=ticks;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-18 20:01:13 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
