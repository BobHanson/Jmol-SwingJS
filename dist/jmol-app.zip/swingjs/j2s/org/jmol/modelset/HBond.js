(function(){var P$=Clazz.newPackage("org.jmol.modelset"),I$=[[0,'org.jmol.util.Logger']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "HBond", null, 'org.jmol.modelset.Bond');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['energy']]]

Clazz.newMeth(C$, 'c$$org_jmol_modelset_Atom$org_jmol_modelset_Atom$I$H$H$D',  function (atom1, atom2, order, mad, colix, energy) {
;C$.superclazz.c$$org_jmol_modelset_Atom$org_jmol_modelset_Atom$I$H$H.apply(this,[atom1, atom2, order, mad, colix]);C$.$init$.apply(this);
this.energy=energy;
if ($I$(1).debugging) $I$(1,"debug$S",["HBond energy = " + new Double(energy).toString() + " #" + this.getIdentity$() ]);
}, 1);

Clazz.newMeth(C$, 'getEnergy$',  function () {
return this.energy;
});

Clazz.newMeth(C$, 'getEnergy$D$D$D$D',  function (distAH, distCH, distCD, distAD) {
var energy=Long.$ival(Math.round$D(-27888.0 / distAH - -27888.0 / distAD + -27888.0 / distCD - -27888.0 / distCH));
return energy;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-08-23 15:03:09 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
