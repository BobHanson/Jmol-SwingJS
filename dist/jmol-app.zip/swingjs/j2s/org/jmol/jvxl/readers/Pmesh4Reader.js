(function(){var P$=Clazz.newPackage("org.jmol.jvxl.readers"),I$=[['org.jmol.jvxl.data.JvxlCoder','org.jmol.util.Logger','javajs.util.CU','javajs.util.P4']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Pmesh4Reader", null, 'org.jmol.jvxl.readers.PolygonFileReader');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.nPolygons = 0;
this.pmeshError = null;
this.type = null;
this.color = 0;
this.transparency = 0;
this.nX = 0;
this.nY = 0;
this.tokens = null;
this.iToken = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.tokens = Clazz.array(java.lang.String, [0]);
this.iToken = 0;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init2$org_jmol_jvxl_readers_SurfaceGenerator$java_io_BufferedReader', function (sg, br) {
this.init2PFR$org_jmol_jvxl_readers_SurfaceGenerator$java_io_BufferedReader(sg, br);
var fileName = (sg.getReaderData())[0];
if (fileName == null ) return;
this.params.fullyLit=true;
this.type="pmesh4";
this.jvxlFileHeaderBuffer.append$S(this.type + " file format\nvertices and triangles only\n");
(I$[1]||$incl$(1)).jvxlCreateHeaderWithoutTitleOrAtoms$org_jmol_jvxl_data_VolumeData$javajs_util_SB(this.volumeData, this.jvxlFileHeaderBuffer);
});

Clazz.newMeth(C$, 'getSurfaceData', function () {
this.rd();
if (p$.readVerticesAndPolygons.apply(this, [])) (I$[2]||$incl$(2)).info$S(this.type + " file contains " + this.nVertices + " 4D vertices and " + this.nPolygons + " polygons for " + this.nTriangles + " triangles" );
 else (I$[2]||$incl$(2)).error$S(this.params.fileName + ": " + (this.pmeshError == null  ? "Error reading pmesh4 data " : this.pmeshError) );
});

Clazz.newMeth(C$, 'readVerticesAndPolygons', function () {
try {
p$.readColor.apply(this, []);
this.nY=p$.getInt.apply(this, []);
this.nX=p$.getInt.apply(this, []);
p$.readVertices.apply(this, []);
p$.createMesh.apply(this, []);
return true;
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
if (this.pmeshError == null ) this.pmeshError=this.type + " ERROR: " + e ;
} else {
throw e;
}
}
return false;
});

Clazz.newMeth(C$, 'readColor', function () {
this.color=(I$[3]||$incl$(3)).colorTriadToFFRGB$F$F$F(p$.getFloat.apply(this, []), p$.getFloat.apply(this, []), p$.getFloat.apply(this, []));
this.transparency=p$.getFloat.apply(this, []);
});

Clazz.newMeth(C$, 'readVertices', function () {
this.nVertices=this.nX * this.nY;
this.iToken=2147483647;
this.pmeshError=this.type + " ERROR: invalid vertex list";
for (var i = 0; i < this.nVertices; i++) {
var pt = (I$[4]||$incl$(4)).new4$F$F$F$F(p$.getFloat.apply(this, []), p$.getFloat.apply(this, []), p$.getFloat.apply(this, []), p$.getFloat.apply(this, []));
if ((I$[2]||$incl$(2)).debugging) (I$[2]||$incl$(2)).debug$S(i + ": " + pt );
this.addVertexCopy$javajs_util_T3$F$I$Z(pt, 0, i, false);
this.iToken=2147483647;
}
this.pmeshError=null;
return true;
});

Clazz.newMeth(C$, 'createMesh', function () {
for (var i = 0; i < this.nX - 1; i++) {
for (var j = 0; j < this.nY - 1; j++) {
this.nTriangles+=2;
this.addTriangleCheck$I$I$I$I$I$Z$I(i * this.nY + j, (i + 1) * this.nY + j, (i + 1) * this.nY + j + 1, 3, 0, false, this.color);
this.addTriangleCheck$I$I$I$I$I$Z$I((i + 1) * this.nY + j + 1, i * this.nY + j + 1, i * this.nY + j, 3, 0, false, this.color);
}
}
});

Clazz.newMeth(C$, 'nextToken', function () {
while (this.iToken >= this.tokens.length){
this.iToken=0;
this.rd();
this.tokens=this.getTokens();
}
return this.tokens[this.iToken++];
});

Clazz.newMeth(C$, 'getInt', function () {
return this.parseIntStr$S(p$.nextToken.apply(this, []));
});

Clazz.newMeth(C$, 'getFloat', function () {
return this.parseFloatStr$S(p$.nextToken.apply(this, []));
});
})();
//Created 2018-07-22 20:21:53 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
