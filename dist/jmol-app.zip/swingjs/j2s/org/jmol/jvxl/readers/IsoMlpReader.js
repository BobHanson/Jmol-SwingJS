(function(){var P$=Clazz.newPackage("org.jmol.jvxl.readers"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "IsoMlpReader", null, 'org.jmol.jvxl.readers.IsoMepReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'init$org_jmol_jvxl_readers_SurfaceGenerator', function (sg) {
this.initIMR$org_jmol_jvxl_readers_SurfaceGenerator(sg);
this.type="Mlp";
});
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-18 20:01:10 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
