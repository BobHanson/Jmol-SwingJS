(function(){var P$=Clazz.newPackage("org.jmol.jvxl.readers"),I$=[['javajs.util.SB','javajs.util.PT','org.jmol.jvxl.readers.VolumeFileReader']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ApbsReader", null, 'org.jmol.jvxl.readers.VolumeFileReader');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init2$org_jmol_jvxl_readers_SurfaceGenerator$java_io_BufferedReader', function (sg, br) {
this.init2VFR$org_jmol_jvxl_readers_SurfaceGenerator$java_io_BufferedReader(sg, br);
if (this.params.thePlane == null ) this.params.insideOut=!this.params.insideOut;
this.isAngstroms=true;
this.nSurfaces=1;
});

Clazz.newMeth(C$, 'readParameters', function () {
this.jvxlFileHeaderBuffer=(I$[1]||$incl$(1)).newS$S(this.skipComments$Z(false));
while (this.line != null  && this.line.length$() == 0 )this.rd();

this.jvxlFileHeaderBuffer.append$S("APBS OpenDx DATA ").append$S(this.line).append$S("\u000a");
this.jvxlFileHeaderBuffer.append$S("see http://apbs.sourceforge.net\u000a");
var atomLine = this.rd();
var tokens = (I$[2]||$incl$(2)).getTokens$S(atomLine);
if (tokens.length >= 4) {
this.volumetricOrigin.set$F$F$F(this.parseFloatStr$S(tokens[1]), this.parseFloatStr$S(tokens[2]), this.parseFloatStr$S(tokens[3]));
}(I$[3]||$incl$(3)).checkAtomLine$Z$Z$S$S$javajs_util_SB(this.isXLowToHigh, this.isAngstroms, tokens[0], atomLine, this.jvxlFileHeaderBuffer);
this.readVoxelVector$I(0);
this.readVoxelVector$I(1);
this.readVoxelVector$I(2);
this.rd();
tokens=this.getTokens();
for (var i = 0; i < 3; i++) this.voxelCounts[i]=this.parseIntStr$S(tokens[i + 5]);

this.rd();
});
})();
//Created 2018-07-22 20:21:52 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
