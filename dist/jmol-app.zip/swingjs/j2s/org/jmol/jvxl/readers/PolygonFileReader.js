(function(){var P$=Clazz.newPackage("org.jmol.jvxl.readers"),I$=[];
var C$=Clazz.newClass(P$, "PolygonFileReader", null, 'org.jmol.jvxl.readers.SurfaceFileReader');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.nVertices=0;
this.nTriangles=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init2PFR$org_jmol_jvxl_readers_SurfaceGenerator$java_io_BufferedReader', function (sg, br) {
this.init2SFR$org_jmol_jvxl_readers_SurfaceGenerator$java_io_BufferedReader(sg, br);
this.jvxlFileHeaderBuffer=Clazz.new_(Clazz.load('javajs.util.SB'));
this.jvxlFileHeaderBuffer.append$S("#created ").append$S("" + Clazz.new_(Clazz.load('java.util.Date'))).append$S("\n");
this.vertexDataOnly=true;
});

Clazz.newMeth(C$, 'readVolumeParameters$Z', function (isMapData) {
return true;
});

Clazz.newMeth(C$, 'readVolumeData$Z', function (isMapData) {
return true;
});

Clazz.newMeth(C$, 'readSurfaceData$Z', function (isMapData) {
this.getSurfaceData$();
});
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-20 14:22:27 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
