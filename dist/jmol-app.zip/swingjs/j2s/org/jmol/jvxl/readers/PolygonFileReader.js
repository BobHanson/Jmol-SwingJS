(function(){var P$=Clazz.newPackage("org.jmol.jvxl.readers"),I$=[['javajs.util.SB','java.util.Date']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "PolygonFileReader", null, 'org.jmol.jvxl.readers.SurfaceFileReader');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.nVertices = 0;
this.nTriangles = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init2PFR$org_jmol_jvxl_readers_SurfaceGenerator$java_io_BufferedReader', function (sg, br) {
this.init2SFR$org_jmol_jvxl_readers_SurfaceGenerator$java_io_BufferedReader(sg, br);
this.jvxlFileHeaderBuffer=Clazz.new_((I$[1]||$incl$(1)));
this.jvxlFileHeaderBuffer.append$S("#created ").append$S("" + Clazz.new_((I$[2]||$incl$(2)))).append$S("\u000a");
this.vertexDataOnly=true;
});

Clazz.newMeth(C$, 'readVolumeParameters$Z', function (isMapData) {
return true;
});

Clazz.newMeth(C$, 'readVolumeData$Z', function (isMapData) {
return true;
});

Clazz.newMeth(C$, 'readSurfaceData$Z', function (isMapData) {
this.getSurfaceData();
});
})();
//Created 2018-07-22 20:21:53 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
