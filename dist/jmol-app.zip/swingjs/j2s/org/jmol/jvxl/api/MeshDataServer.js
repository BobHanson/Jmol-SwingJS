(function(){var P$=Clazz.newPackage("org.jmol.jvxl.api"),I$=[];
var C$=Clazz.newInterface(P$, "MeshDataServer", null, null, 'org.jmol.jvxl.api.VertexDataServer');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
;Clazz.setTVer('3.2.4.04');//Created 2018-11-15 12:07:05 Java2ScriptVisitor version 3.2.4.04 net.sf.j2s.core.jar version 3.2.4.04
