(function(){var P$=Clazz.newPackage("org.jmol.popup"),I$=[['org.jmol.popup.AwtSwingPopupHelper','org.jmol.i18n.GT','org.jmol.popup.MainPopupResourceBundle']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "JmolAwtPopup", null, 'org.jmol.popup.JmolGenericPopup');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.helper=Clazz.new_((I$[1]||$incl$(1)).c$$org_jmol_api_GenericMenuInterface,[this]);
}, 1);

Clazz.newMeth(C$, 'jpiInitialize$org_jmol_api_PlatformViewer$S', function (vwr, menu) {
var doTranslate = (I$[2]||$incl$(2)).setDoTranslate$Z(true);
var bundle = Clazz.new_((I$[3]||$incl$(3)).c$$S$java_util_Properties,[this.strMenuStructure=menu, this.menuText]);
this.initialize$org_jmol_viewer_Viewer$org_jmol_popup_PopupResource$S(vwr, bundle, bundle.getMenuName());
(I$[2]||$incl$(2)).setDoTranslate$Z(doTranslate);
});

Clazz.newMeth(C$, 'menuShowPopup$javajs_awt_SC$I$I', function (popup, x, y) {
try {
((popup).jc).show$java_awt_Component$I$I(this.vwr.display, x, y);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'menuSetCheckBoxOption$javajs_awt_SC$S$S', function (item, name, what) {
return null;
});

Clazz.newMeth(C$, 'getImageIcon$S', function (fileName) {
return null;
});

Clazz.newMeth(C$, 'menuFocusCallback$S$S$Z', function (name, actionCommand, b) {
});
})();
//Created 2018-07-22 20:21:57 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
