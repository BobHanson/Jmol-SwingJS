(function(){var P$=Clazz.newPackage("org.jmol.multitouch"),I$=[['javajs.util.P3','org.jmol.util.Logger']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "JmolMultiTouchClientAdapter", null, null, 'org.jmol.multitouch.JmolMultiTouchAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.actionManager = null;
this.$isServer = false;
this.vwr = null;
this.screen = null;
this.ptTemp = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.screen = Clazz.array(Integer.TYPE, [2]);
this.ptTemp = Clazz.new_((I$[1]||$incl$(1)));
}, 1);

Clazz.newMeth(C$, 'isServer', function () {
return this.$isServer;
});

Clazz.newMeth(C$, 'setMultiTouchClient$org_jmol_viewer_Viewer$org_jmol_multitouch_JmolMultiTouchClient$Z', function (vwr, client, isSimulation) {
this.vwr=vwr;
this.actionManager=client;
vwr.apiPlatform.getFullScreenDimensions$O$IA(vwr.display, this.screen);
if ((I$[2]||$incl$(2)).debugging) (I$[2]||$incl$(2)).debug$S("screen resolution: " + this.screen[0] + " x " + this.screen[1] );
return true;
});

Clazz.newMeth(C$, 'mouseMoved$I$I', function (x, y) {
});

Clazz.newMeth(C$, 'fixXY$F$F$Z', function (x, y, isAbsolute) {
this.ptTemp.set$F$F$F(x * this.screen[0], y * this.screen[1], NaN);
if (isAbsolute) this.vwr.apiPlatform.convertPointFromScreen$O$javajs_util_P3(this.vwr.display, this.ptTemp);
});

Clazz.newMeth(C$);
})();
//Created 2018-07-22 20:21:57 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
