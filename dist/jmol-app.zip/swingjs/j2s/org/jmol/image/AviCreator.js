(function(){var P$=Clazz.newPackage("org.jmol.image"),I$=[];
var C$=Clazz.newClass(P$, "AviCreator", null, null, 'org.jmol.api.JmolMovieCreatorInterface');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.errorMsg=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['createMovie$org_jmol_viewer_Viewer$SA$I$I$I$S','createMovie$'], function (vwr, files, width, height, fps, fileName) {
return this.errorMsg;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-20 18:11:14 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
