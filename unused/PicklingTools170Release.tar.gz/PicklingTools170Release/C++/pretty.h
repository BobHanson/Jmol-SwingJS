

// Backwards compatibility:  should include opalprint.h directly
// This file is deprecated
#include "opalprint.h"

