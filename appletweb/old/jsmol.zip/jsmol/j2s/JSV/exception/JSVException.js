Clazz.declarePackage ("JSV.exception");
Clazz.load (["java.lang.Exception"], "JSV.exception.JSVException", null, function () {
c$ = Clazz.declareType (JSV.exception, "JSVException", Exception);
});
